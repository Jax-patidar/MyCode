package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_DEPENDENTS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_DEPENDENTS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_DEPENDENTS_Key;

@Repository
public interface CpAppInTaxDependentsRepository extends CrudRepository<CP_APP_IN_TAX_DEPENDENTS_Cargo, CP_APP_IN_TAX_DEPENDENTS_Key>{

	
	@Query("select c from CP_APP_IN_TAX_DEPENDENTS_Cargo c where c.app_number =?1 and c.src_app_ind = ?2")
	public CP_APP_IN_TAX_DEPENDENTS_Collection loadTaxInfo(Integer appNumber, String src_ind);
	
	@Query("select c from CP_APP_IN_TAX_DEPENDENTS_Cargo c where c.app_number =?1 and c.src_app_ind = ?2 and c.indv_seq_num = ?3")
	public CP_APP_IN_TAX_DEPENDENTS_Collection loadTaxDepIndvInfo(Integer appNumber, String src_ind,
			Integer indv_seq_num);

	@Transactional
	@Modifying
	@Query("DELETE from CP_APP_IN_TAX_DEPENDENTS_Cargo where app_number =?1 and indv_seq_num = ?2 and src_app_ind = ?3")
	public void deleteTaxDepData(Integer appNum, Integer indv_seq_num, String src_ind);
	
	
	@Query("select c from CP_APP_IN_TAX_DEPENDENTS_Cargo c where c.app_number =?1")
	public CP_APP_IN_TAX_DEPENDENTS_Collection loadTaxInfoByAppNum(Integer appNumber);
}
