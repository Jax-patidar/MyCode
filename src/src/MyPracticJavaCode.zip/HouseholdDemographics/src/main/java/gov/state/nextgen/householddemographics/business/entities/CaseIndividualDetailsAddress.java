package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ransahu
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseIndividualDetailsAddress implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4857355993577490740L;

	private String addressLine;

	private String city;

	private String state;

	private String zipcode;

	private String apt;

	/**
	 * @return the addressLine
	 */
	public String getAddressLine() {
		return addressLine;
	}

	/**
	 * @param addressLine the addressLine to set
	 */
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the zipcode
	 */
	public String getZipcode() {
		return zipcode;
	}

	/**
	 * @param zipcode the zipcode to set
	 */
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	/**
	 * @return the apt
	 */
	public String getApt() {
		return apt;
	}

	/**
	 * @param apt the apt to set
	 */
	public void setApt(String apt) {
		this.apt = apt;
	}

}
