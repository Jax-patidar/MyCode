package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_IN_SCHLE_Collection extends AbstractCollection{
	
	/**
    *
    */
   private static final long serialVersionUID = 1L;
   private static final String PACKAGE = "gov.state.nextgen.nonfinancialinformation.business.entities.APP_IN_SCHLE";

	public void addCargo(final APP_IN_SCHLE_Cargo newCargo) {
		add(newCargo);
	}

	/**
	 * Returns the package name.
	 *
	 * @return
	 *         gov.state.nextgen.nonfinancialinformation.business.entities.APP_IN_SCHLE_Collection
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Returns cargo.
	 *
	 * @return java.lang.String
	 */
	public APP_IN_SCHLE_Cargo getCargo() {
		if (size() == 0) {
			add(new APP_IN_SCHLE_Cargo());
		}
		return (APP_IN_SCHLE_Cargo) get(0);
	}

	/**
	 * Sets cargo values.
	 *
	 * @param newCargo
	 *            The newCargo to set
	 */

	public void setCargo(final APP_IN_SCHLE_Cargo newCargo) {
		if (size() == 0) {
			add(newCargo);
		} else {
			set(0, newCargo);
		}
	}

	/**
	 * Sets cargo array into collection.
	 *
	 * @param cbArray
	 *            The cbArray to set
	 */

	public void setResults(final APP_IN_SCHLE_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets a cargo into particular index of the collection
	 *
	 * @param cb
	 *            The cbarray to set
	 * @param idx
	 *            The idx to set
	 */

	public void setResults(final int idx, final APP_IN_SCHLE_Cargo cb) {
		set(idx, cb);
	}

	/**
	 * Sets a cargo into particular index of the collection
	 *
	 * @param obj
	 *            The cbarray to set
	 */

	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_SCHLE_Cargo[]) {
			final APP_IN_SCHLE_Cargo[] cbArray = (APP_IN_SCHLE_Cargo[]) obj;
			for (int i = 0; i < cbArray.length; i++) {
				add(cbArray[i]);
			}
		}
	}

	/**
	 * Returns cargo array.
	 *
	 * @return
	 *         gov.state.nextgen.nonfinancialinformation.business.entities.APP_IN_SCHLE_Collection
	 *         []
	 */
	public APP_IN_SCHLE_Cargo[] getResults() {
		final APP_IN_SCHLE_Cargo[] cbArray = new APP_IN_SCHLE_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * Returns a particular cargo.
	 *
	 * @return
	 *         gov.state.nextgen.nonfinancialinformation.business.entities.APP_IN_SCHLE_Collection
	 */
	public APP_IN_SCHLE_Cargo getResult(final int idx) {
		return (APP_IN_SCHLE_Cargo) get(idx);
	}

	/**
	 * Returns size of a collection.
	 *
	 * @return int
	 */
	public int getResultsSize() {
		return size();
	}

	/** This one for clone Results */
	public APP_IN_SCHLE_Cargo[] cloneResults() {
		final APP_IN_SCHLE_Cargo[] rescargo = new APP_IN_SCHLE_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_SCHLE_Cargo cargo = getResult(i);
			rescargo[i] = new APP_IN_SCHLE_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setAdapt_record_id(cargo.getAdapt_record_id());
			rescargo[i].setAdaptRecordId(cargo.getAdaptRecordId());
			rescargo[i].setAddr_zip4(cargo.getAddr_zip4());
			rescargo[i].setChg_dt(cargo.getChg_dt());
			rescargo[i].setChld_care_ind(cargo.getChld_care_ind());
			rescargo[i].setDirty(cargo.isDirty());
			rescargo[i].setEcp_id(cargo.getEcp_id());
			rescargo[i].setEduc_cd(cargo.getEduc_cd());
			rescargo[i].setEnd_dt(cargo.getEnd_dt());
			rescargo[i].setEnrl_stat_cd(cargo.getEnrl_stat_cd());
			rescargo[i].setFed_fund_wrk_study_prg_ind(cargo.getFed_fund_wrk_study_prg_ind());
			rescargo[i].setFed_sta_fund_wrk_study_prg_ind(cargo.getFed_sta_fund_wrk_study_prg_ind());
			rescargo[i].setHs_grad_dt(cargo.getHs_grad_dt());
			rescargo[i].setHs_grad_stat_cd(cargo.getHs_grad_stat_cd());
			rescargo[i].setImmunization_received_ind(cargo.getImmunization_received_ind());
			rescargo[i].setIsfc_dy_care_ind(cargo.getIsfc_dy_care_ind());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setSchl_plcm_ind(cargo.getSchl_plcm_ind());
			rescargo[i].setSchool_city_adr(cargo.getSchool_city_adr());
			rescargo[i].setSchool_l1_adr(cargo.getSchool_l1_adr());
			rescargo[i].setSchool_l2_adr(cargo.getSchool_l2_adr());
			rescargo[i].setSchool_name(cargo.getSchool_name());
			rescargo[i].setSchool_sta_adr(cargo.getSchool_sta_adr());
			rescargo[i].setSchool_sta_adr_cd(cargo.getSchool_sta_adr_cd());
			rescargo[i].setSchool_type_cd(cargo.getSchool_type_cd());
			rescargo[i].setSchool_zip_adr(cargo.getSchool_zip_adr());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setWork_stdy_ind(cargo.getWork_stdy_ind());
		}
		return rescargo;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_SCHLE_Cargo getCargo(final int idx) {
		return (APP_IN_SCHLE_Cargo) get(idx);
	}



}
