package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;


/**
 * @author ransahu
 *
 */
@Entity
@Table(name = "cp_rmb_request_detail")
@IdClass(CpRmbRequestDetailsPrimaryKey.class)
public class CpRmbRequestDetails_Cargo extends AbstractCargo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1432769865213257718L;

	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column(name = "cp_rmb_request_detail_id")
	private Long cpRmbRequestDetailId;

	@Column(name = "cp_rmb_request_id")
	private Long cpRmbRequestId;

	@Column(columnDefinition = "json")
	private String form_status_req;
	
	/**
	 * @return the cpRmbRequestDetailId
	 */
	public Long getCpRmbRequestDetailId() {
		return cpRmbRequestDetailId;
	}

	/**
	 * @param cpRmbRequestDetailId the cpRmbRequestDetailId to set
	 */
	public void setCpRmbRequestDetailId(Long cpRmbRequestDetailId) {
		this.cpRmbRequestDetailId = cpRmbRequestDetailId;
	}

	/**
	 * @return the cpRmbRequestId
	 */
	public Long getCpRmbRequestId() {
		return cpRmbRequestId;
	}

	/**
	 * @param cpRmbRequestId the cpRmbRequestId to set
	 */
	public void setCpRmbRequestId(Long cpRmbRequestId) {
		this.cpRmbRequestId = cpRmbRequestId;
	}

	public String getForm_status_req() {
		return form_status_req;
	}

	public void setForm_status_req(String form_status_req) {
		this.form_status_req = form_status_req;
	}

	/**
	 * @return the formStatusReqJson
	 */


}
