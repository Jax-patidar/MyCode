package gov.state.nextgen.householddemographics.business.rules;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.AppRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.AppSbmsRepository;
import gov.state.nextgen.householddemographics.data.db2.CP_APP_RGST_Repository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;
import gov.state.nextgen.householddemographics.data.db2.NewBornChildInformationRepo;

@Service("ReportMyChangeBO")
public class ReportMyChangeBO extends AbstractBO {

	@Autowired
	private CpAppIndvRepository cpAppIndvRepository;
	@Autowired
	private HouseholdRelationshipRepo appHshlRltRepository;
	@Autowired
	private CP_APP_RGST_Repository cpAppRgstRepository;
	@Autowired
	protected NewBornChildInformationRepo newBornChildInformationRepo;
	@Autowired
	AppSbmsRepository appsbms;
	@Autowired
	CpAppPgmRqstRepository appPrgmRqstRepo;
	@Autowired
	AppRqstRepository appRqstRepo;

	// Data Fetching methods
	public APP_INDV_Cargo getAppIndvByAppNumIndvSeqSrcAppInd(String appNum, int indvSeqNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppIndvByAppNumIndvSeqSrcAppInd() - START");
		APP_INDV_Cargo appIndvCargo = null;
		try {
			if (appNum != null) {
				appIndvCargo = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNum),
						indvSeqNum);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppIndvByAppNumIndvSeqSrcAppInd() - END");
			return appIndvCargo;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}

	}

	public APP_INDV_Cargo getAppIndvByAppNumIndvSeqNum(String appNum, Integer indvSeqNumber) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppIndvByAppNumIndvSeqNum() - START");
		APP_INDV_Cargo appIndvCargo = null;
		try {
			appIndvCargo = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNum), indvSeqNumber);
		} catch(Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppIndvByAppNumIndvSeqNum() - END");
		return appIndvCargo;
	}
	public APP_INDV_Cargo[] getAppIndvArrByAppNum(String appNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppIndvArrByAppNum() - START");
		APP_INDV_Cargo[] appIndvArr = null;
		try {
			appIndvArr = cpAppIndvRepository.getByAppNum(Integer.parseInt(appNum));
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppIndvArrByAppNum() - END");
		return appIndvArr;
	}

	public APP_INDV_Cargo[] getAppIndvArrByAppNumIndvSeq(String appNum, int indvSeqNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppIndvArrByAppNumIndvSeq() - START");
		APP_INDV_Cargo[] appIndvArr = null;
		try {
			appIndvArr = cpAppIndvRepository.findByAppNumIndvSeqNumArray(Integer.parseInt(appNum), indvSeqNum);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw createFwException(getClass().getName(), "getAppIndvArrByAppNumIndvSeq", e);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppIndvArrByAppNumIndvSeq() - END");
		return appIndvArr;
	}

	public List<CP_APP_HSHL_RLT_Cargo> getHshlRltArrByAppNumSrcIndv(String appNum, int srcIndvSeqNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getHshlRltArrByAppNumSrcIndv() - START");
		List<CP_APP_HSHL_RLT_Cargo> list = null;
		try {
			list = appHshlRltRepository.findByAppNumSrcIndvSeqNum(Integer.parseInt(appNum), srcIndvSeqNum);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw createFwException(getClass().getName(), "getHshlRltArrByAppNumSrcIndv", e);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getHshlRltArrByAppNumSrcIndv() - END");
		return list;
	}

	public List<CP_APP_HSHL_RLT_Cargo> getHshlRltArrByAppNumRefIndv(String appNum, int refIndvSeqNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getHshlRltArrByAppNumRefIndv() - START");
		List<CP_APP_HSHL_RLT_Cargo> list = null;
		try {
			list = appHshlRltRepository.findByAppNumRefIndvSeqNum(Integer.parseInt(appNum), refIndvSeqNum);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getHshlRltArrByAppNumRefIndv() - END");
		return list;
	}
	
	public List<CP_APP_HSHL_RLT_Cargo> getHshlRltArrByAppSrcRefIndv(CP_APP_HSHL_RLT_Cargo cargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getHshlRltArrByAppNumSrcIndv() - START");
		List<CP_APP_HSHL_RLT_Cargo> list = null;
		try {
			list = appHshlRltRepository.findByAppNumSrcRefIndvSeqNum(Integer.parseInt(cargo.getApp_num()), cargo.getSrcIndvSeqNum(), cargo.getRefIndvSeqNum());
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw createFwException(getClass().getName(), "getHshlRltArrByAppNumSrcIndv", e);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getHshlRltArrByAppNumSrcIndv() - END");
		return list;
	}

	public List<CP_APP_RGST_Cargo> getAppRgstByAppNum(String appNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppRgstByAppNum() - START");
		List<CP_APP_RGST_Cargo> appRgstList = null;
		try {
			appRgstList = cpAppRgstRepository.getRgstListByAppNum(Integer.parseInt(appNum));
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppRgstByAppNum() - END");
		return appRgstList;
	}
	
	public APP_IN_NEWB_Collection getNewBornInfoByAppNum(String appNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getNewBornInfoByAppNum() - START");
		APP_IN_NEWB_Collection appNewBornColl = null;
		try {
			if (appNum != null) {
				appNewBornColl = newBornChildInformationRepo.getByAppNum(Integer.parseInt(appNum));
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getNewBornInfoByAppNum() - END");
			return appNewBornColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}

	}
	
	public APP_IN_NEWB_Cargo getNewBornInfoByAppNumInfoId(String appNum, String newBornInfoId) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getNewBornInfoByAppNumInfoId() - START");
		
		APP_IN_NEWB_Cargo cargo = new APP_IN_NEWB_Cargo();
		try {
			if (appNum != null) {
				cargo = newBornChildInformationRepo.findByAppNumnewBornInfoId(Integer.parseInt(appNum), newBornInfoId);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getNewBornInfoByAppNumInfoId() - END");
			return cargo;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}
	
	public APP_IN_NEWB_Cargo getNewBornInfoByAppNumIndvSeqNum(String appNum, Integer indvSeqNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getNewBornInfoByAppNumIndvSeqNum() - START");
		
		APP_IN_NEWB_Cargo cargo = new APP_IN_NEWB_Cargo();
		try {
			if (appNum != null) {
				cargo = newBornChildInformationRepo.findByAppNumIndvSeqNum(Integer.parseInt(appNum), indvSeqNum);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getNewBornInfoByAppNumIndvSeqNum() - END");
			return cargo;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}
	
//Save Methods
	public void saveAppIndvCargo(APP_INDV_Cargo appIndvCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.saveAppIndvCargo() - START");
		try {
			//set update date
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			appIndvCargo.setUpdate_dt(currentTimeStamp);
			
			cpAppIndvRepository.save(appIndvCargo);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.saveAppIndvCargo() - END");

	}

	public void saveAppHshlRltCargo(CP_APP_HSHL_RLT_Cargo receivedHshlCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.saveAppHshlRltCargo() - START");
		try {
			appHshlRltRepository.save(receivedHshlCargo);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.saveAppHshlRltCargo() - END");

	}
	
	public void saveAllRgstCargos(CP_APP_RGST_Collection appRgstCollection) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.saveAllRgstCargos() - START");
		try {
			if (null != appRgstCollection && !appRgstCollection.isEmpty()) {
				cpAppRgstRepository.saveAll(appRgstCollection);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.saveAllRgstCargos() - END");

	}
	
	public APP_IN_NEWB_Cargo saveNewBornInfo(APP_IN_NEWB_Cargo cargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.saveNewBornInfo() - START");
		try {
			cargo = newBornChildInformationRepo.save(cargo);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.saveNewBornInfo() - END");
			return cargo;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}

	}

	// Delete methods
	public void deleteAppIndvCargo(APP_INDV_Cargo appIndvCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.deleteAppIndvCargo() - START");
		try {
			cpAppIndvRepository.delete(appIndvCargo);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.deleteAppIndvCargo() - END");

	}

	public void deleteAppHshlRltCargo(CP_APP_HSHL_RLT_Cargo receivedHshlCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.deleteAppHshlRltCargo() - START");
		try {
			if(receivedHshlCargo != null) {
				  appHshlRltRepository.delete(receivedHshlCargo);
			} 
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.deleteAppHshlRltCargo() - END");

	}
	
	public void deleteNewBornDetails(APP_IN_NEWB_Cargo receivedNewBornCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.deleteNewBornDetails() - START");
		try {
			newBornChildInformationRepo.delete(receivedNewBornCargo);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.deleteNewBornDetails() - END");

	}

	// Business methods
	public void removeMovedOutIndvDetails(APP_INDV_Cargo receivedCargo, CP_APP_HSHL_RLT_Cargo receivedHshlCargo)
			throws FwException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.removeMovedOutIndvDetails() - START");
		try {
			if (null != receivedCargo.getMovedout_other_ind()
					&& receivedCargo.getMovedout_other_ind().equalsIgnoreCase("Y")) {
				deleteAppIndvCargo(receivedCargo);
				deleteAppHshlRltCargo(receivedHshlCargo);
			} else {
				updateMovedOutDetails(receivedCargo,receivedHshlCargo);
			}
		} catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.removeMovedOutIndvDetails() - END");
	}
	
	public void updateMovedOutDetails(APP_INDV_Cargo receivedCargo, CP_APP_HSHL_RLT_Cargo receivedHshlCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.updateMovedOutDetails() - START");
		try {
			APP_INDV_Cargo appIndvcargo = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeqSrcAppInd(Integer.parseInt(receivedCargo.getApp_num()),
					receivedCargo.getIndv_seq_num());
			if (null != appIndvcargo) {
				receivedCargo = appIndvcargo;
					receivedCargo.setLeft_home_dt(null);
					receivedCargo.setMovedout_other_ind("N");
					receivedCargo.setMove_out_ind("N");
					saveAppIndvCargo(receivedCargo);
					if(receivedHshlCargo !=null) {
						List<CP_APP_HSHL_RLT_Cargo> hshlRltList = getHshlRltArrByAppNumRefIndv(
								receivedHshlCargo.getApp_num(), receivedHshlCargo.getRefIndvSeqNum());
						if (hshlRltList != null && !hshlRltList.isEmpty()) {
							receivedHshlCargo = hshlRltList.get(0);
								receivedHshlCargo.setPnp_tghr_sw(null);
								saveAppHshlRltCargo(receivedHshlCargo);
						}
					}
			}
		} catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.updateMovedOutDetails() - END");

	}
	
	public CP_APP_RGST_Cargo populateHomeOrMailingDtls(String appNumber, String pageId, Integer indvSeqNum,
			CP_APP_RGST_Cargo receivedRgstCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populateHomeOrMailingDtls() - START");
		CP_APP_RGST_Cargo existingRgstcargo = null;
		try {
			existingRgstcargo = cpAppRgstRepository.getCpAppRgstDetails(Integer.parseInt(appNumber), indvSeqNum);
			if (null == existingRgstcargo) {
				existingRgstcargo = new CP_APP_RGST_Cargo();
				existingRgstcargo.setApp_num(appNumber);
				existingRgstcargo.setIndv_seq_num(indvSeqNum);
				existingRgstcargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
				existingRgstcargo = populateRgstVthDefaultValues(existingRgstcargo, pageId);
			}
			if (null != pageId && (HouseHoldDemoGraphicsConstants.RCMAB.equalsIgnoreCase(pageId) || HouseHoldDemoGraphicsConstants.RCHAM.equalsIgnoreCase(pageId))) {
				existingRgstcargo.setAlt_l1_adr(receivedRgstCargo.getAlt_l1_adr());
				if(isStringEmptyOrNull(receivedRgstCargo.getAlt_l1_adr())) {
					existingRgstcargo.setAlt_l1_adr(receivedRgstCargo.getAlt_st_adr());
				}
				existingRgstcargo.setAlt_l2_adr(receivedRgstCargo.getAlt_l2_adr());
				existingRgstcargo.setAlt_city_adr(receivedRgstCargo.getAlt_city_adr());
				existingRgstcargo.setAlt_sta_adr(receivedRgstCargo.getAlt_sta_adr());
				existingRgstcargo.setAlt_zip_adr(receivedRgstCargo.getAlt_zip_adr());
				existingRgstcargo.setMail_addr_chg_begin_dt(receivedRgstCargo.getMail_addr_chg_begin_dt());
			}
			if (null != pageId && HouseHoldDemoGraphicsConstants.RCHAB.equalsIgnoreCase(pageId)) {
				existingRgstcargo.setHshl_l1_adr(receivedRgstCargo.getHshl_l1_adr());
				existingRgstcargo.setHshl_l2_adr(receivedRgstCargo.getHshl_l2_adr());
				existingRgstcargo.setHshl_city_adr(receivedRgstCargo.getHshl_city_adr());
				existingRgstcargo.setHshl_sta_adr(receivedRgstCargo.getHshl_sta_adr());
				existingRgstcargo.setHshl_zip_adr(receivedRgstCargo.getHshl_zip_adr());
				existingRgstcargo.setHome_addr_chg_begin_dt(receivedRgstCargo.getHome_addr_chg_begin_dt());
			}

		} catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populateHomeOrMailingDtls() - END");
		return existingRgstcargo;
	}
	
	
	public void removePassedAwayInfo(String appNum, Integer indvSeqNumber) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.removePassedAwayInfo() - START");
		APP_INDV_Cargo appIndvCargo = null;
		try {
			
			appIndvCargo = getAppIndvByAppNumIndvSeqNum(appNum,indvSeqNumber);
			if(null != appIndvCargo) {
				if(appIndvCargo.getPassedaway_other_ind() != null && FwConstants.YES.equalsIgnoreCase(appIndvCargo.getPassedaway_other_ind()))
				{
					deleteAppIndvCargo(appIndvCargo);
					CP_APP_HSHL_RLT_Cargo receivedHshlCargo=new CP_APP_HSHL_RLT_Cargo();
					receivedHshlCargo.setApp_num(appNum);
					receivedHshlCargo.setRefIndvSeqNum(indvSeqNumber);
					receivedHshlCargo.setSrcAppIndiv(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
					receivedHshlCargo.setSrcIndvSeqNum(1);
					deleteAppHshlRltCargo(receivedHshlCargo);
				}
				else
				{
					appIndvCargo.setDecease_dt(null);
					appIndvCargo.setDeceased_ind(FwConstants.NO);
					saveAppIndvCargo(appIndvCargo);
					List<CP_APP_HSHL_RLT_Cargo> hshlRltList = getHshlRltArrByAppNumRefIndv(appNum,indvSeqNumber);
					if (hshlRltList != null && !hshlRltList.isEmpty()) {
						CP_APP_HSHL_RLT_Cargo receivedHshlCargo = hshlRltList.get(0);
						receivedHshlCargo.setRltCd(FwConstants.SPACE);
						saveAppHshlRltCargo(receivedHshlCargo);
					}
				}
			}
		}catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.removePassedAwayInfo() - END");
	}
	
	public void clearRmcHomeOrMailingAddress(String appNumber, String pageId, Integer indvSeqNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.removePassedAwayInfo() - START");
		CP_APP_RGST_Cargo existingRgstcargo = null;
		try {
			existingRgstcargo = cpAppRgstRepository.getCpAppRgstDetails(Integer.parseInt(appNumber), indvSeqNum);
			if (null == existingRgstcargo) {
				existingRgstcargo = new CP_APP_RGST_Cargo();
				existingRgstcargo.setApp_num(appNumber);
				existingRgstcargo.setIndv_seq_num(indvSeqNum);
				existingRgstcargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
				existingRgstcargo = populateRgstVthDefaultValues(existingRgstcargo, pageId);
			} else {
				existingRgstcargo = populateRgstVthDefaultValues(existingRgstcargo, pageId);
			}
			cpAppRgstRepository.save(existingRgstcargo);
		} catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.clearRmcHomeOrMailingAddress() - END");
	}

	public CP_APP_RGST_Cargo populateRgstVthDefaultValues(CP_APP_RGST_Cargo existingRgstcargo, String pageId) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populateRgstVthDefaultValues() - START");
		try {
			//Since this is common method for both Home/Mailing address, while clearing from Mailing address(RCMAS), Home address
			//must not get cleared
			if (null != pageId && !pageId.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.RCMAS)) {

				existingRgstcargo.setHshl_l1_adr(FwConstants.EMPTY_STRING);
				existingRgstcargo.setHshl_l2_adr(FwConstants.EMPTY_STRING);
				existingRgstcargo.setHshl_city_adr(FwConstants.EMPTY_STRING);
				existingRgstcargo.setHshl_sta_adr(FwConstants.EMPTY_STRING);
				existingRgstcargo.setHshl_zip_adr(FwConstants.EMPTY_STRING);
			}
			//Since this is common method for both Home/Mailing address, while clearing from Home address(RCHAS), Mailing address
			//must not get cleared
			if (null != pageId && (!pageId.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.RCHAS) || pageId.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.RCHAM))) {
				existingRgstcargo.setAlt_l1_adr(FwConstants.EMPTY_STRING);
				existingRgstcargo.setAlt_st_adr(FwConstants.EMPTY_STRING);
				existingRgstcargo.setAlt_l2_adr(FwConstants.EMPTY_STRING);
				existingRgstcargo.setAlt_city_adr(FwConstants.EMPTY_STRING);
				existingRgstcargo.setAlt_sta_adr(FwConstants.EMPTY_STRING);
				existingRgstcargo.setAlt_zip_adr(FwConstants.EMPTY_STRING);
			}
		} catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populateRgstVthDefaultValues() - END");
		return existingRgstcargo;
	}
	
	public List<CP_APP_RGST_Cargo> appendIndvNameAge(List<CP_APP_RGST_Cargo> appRgstList) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.appendIndvNameAge() - START");
		List<CP_APP_RGST_Cargo> listToSend = null;
		try {
			listToSend = new ArrayList<>();
			for (CP_APP_RGST_Cargo appRgstCargo : appRgstList) {
				APP_INDV_Cargo[] appIndvArr = getAppIndvArrByAppNumIndvSeq(appRgstCargo.getApp_num(),
						appRgstCargo.getIndv_seq_num());
				APP_INDV_Cargo appIndvCargo = (null != appIndvArr && appIndvArr.length > 0) ? appIndvArr[0] : null;
				if (null != appIndvCargo) {
					appIndvCargo.setFst_nam(
							null != appIndvCargo.getFst_nam() ? appIndvCargo.getFst_nam() : FwConstants.EMPTY_STRING);
					appIndvCargo.setLast_nam(
							null != appIndvCargo.getLast_nam() ? appIndvCargo.getLast_nam() : FwConstants.EMPTY_STRING);
				}
				listToSend.add(appRgstCargo);
			}
		} catch (FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.appendIndvNameAge() - END");
		return listToSend;
	}
	
	public int calculateAge(Date birthDate)
	{
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.calculateAge() - Start");
		int years = 0;
		int months = 0;

		try {
			if (null == birthDate) {
				return 0;
			}

			// create calendar object for birth day
			Calendar birthDay = Calendar.getInstance();
			birthDay.setTimeInMillis(birthDate.getTime());

			// create calendar object for current day
			long currentTime = System.currentTimeMillis();
			Calendar now = Calendar.getInstance();
			now.setTimeInMillis(currentTime);

			// Get difference between years
			years = now.get(Calendar.YEAR) - birthDay.get(Calendar.YEAR);
			int currMonth = now.get(Calendar.MONTH) + 1;
			int birthMonth = birthDay.get(Calendar.MONTH) + 1;

			// Get difference between months
			months = currMonth - birthMonth;

			// if month difference is in negative then reduce years by one
			// and calculate the number of months.
			if (months < 0) {
				years--;
				months = 12 - birthMonth + currMonth;
				if (now.get(Calendar.DATE) < birthDay.get(Calendar.DATE))
					months--;
			} else if (months == 0 && now.get(Calendar.DATE) < birthDay.get(Calendar.DATE)) {
				years--;
				months = 11;
			}

			if (months == 12) {
				years++;
			}

		} catch (Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.calculateAge() - End");
		return years;
	}
	
	public APP_INDV_Collection loadActiveIndvdtl(String appNum) {
		try {
			return cpAppIndvRepository.getAppActiveIndvCargoByAppNum(Integer.parseInt(appNum));
		} catch(Exception fe) {
        	throw fe;
		}
	}

	public List<CP_APP_RGST_Cargo> sendOnlyValidAddrDtls(List<CP_APP_RGST_Cargo> appRgstList, String pageId) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.sendOnlyValidAddrDtls() - Start");
		List<CP_APP_RGST_Cargo> validRgstList = new ArrayList<>();
		List<String> mailingAddrPages = Arrays.asList(HouseHoldDemoGraphicsConstants.RCMAS,
				HouseHoldDemoGraphicsConstants.RCMAB,HouseHoldDemoGraphicsConstants.RCHAM);
		List<String> homeAddrPages = Arrays.asList(HouseHoldDemoGraphicsConstants.RCHAS,
				HouseHoldDemoGraphicsConstants.RCHAB);
		try {

			for (CP_APP_RGST_Cargo appRgstCargo : appRgstList) {
				if (!isStringEmptyOrNull(pageId)) {
					if (mailingAddrPages.contains(pageId) && !isStringEmptyOrNull(appRgstCargo.getAlt_l1_adr())) {
						validRgstList.add(appRgstCargo);
					}
					if (homeAddrPages.contains(pageId) && (!isStringEmptyOrNull(appRgstCargo.getHshl_l1_adr()) || !isStringEmptyOrNull(appRgstCargo.getAlt_l1_adr())
							|| !isStringEmptyOrNull(appRgstCargo.getAlt_st_adr()))) {
						validRgstList.add(appRgstCargo);
					}
				}
			}
		} catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.sendOnlyValidAddrDtls() - End");
		return validRgstList;
	}
	
	public boolean isStringEmptyOrNull(String string) {
		return (null == string || string.isEmpty());
	}
	public Integer getIntValue(String string) {
		return (null != string && string.chars().allMatch(x -> Character.isDigit(x))) ? Integer.parseInt(string) : null;
	}
	
	public APP_INDV_Cargo populatePersonalInfo(APP_INDV_Cargo existingAppIndvCargo,
			APP_INDV_Cargo receivedAppIndvCargo,boolean isNewRecord) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populatePersonalInfo() - START");
		try {
			existingAppIndvCargo = populateDefaultInfo(existingAppIndvCargo);
			receivedAppIndvCargo = populateDefaultInfo(receivedAppIndvCargo);
			if (isNewRecord) {
				return buildNewPersnInfoCargo(existingAppIndvCargo, receivedAppIndvCargo);
			}
			if (isStringEmptyOrNull(existingAppIndvCargo.getChange_description())) {
				existingAppIndvCargo.setChange_description(existingAppIndvCargo.getFst_nam() + FwConstants.COMMA
						+ existingAppIndvCargo.getLast_nam() + FwConstants.COMMA + existingAppIndvCargo.getMid_init()
						+ FwConstants.COMMA + existingAppIndvCargo.getSuffix_name() + FwConstants.COMMA
						+ existingAppIndvCargo.getSex_ind());
			}

			if (!compareString(existingAppIndvCargo.getFst_nam(), receivedAppIndvCargo.getFst_nam())) {
				existingAppIndvCargo.setFst_nam(receivedAppIndvCargo.getFst_nam());
			}
			if (!compareString(existingAppIndvCargo.getLast_nam(), receivedAppIndvCargo.getLast_nam())) {
				existingAppIndvCargo.setLast_nam(receivedAppIndvCargo.getLast_nam());
			}
			if (!compareString(existingAppIndvCargo.getMid_init(), receivedAppIndvCargo.getMid_init())) {
				existingAppIndvCargo.setMid_init(receivedAppIndvCargo.getMid_init());
			}
			if (!compareString(existingAppIndvCargo.getSuffix_name(), receivedAppIndvCargo.getSuffix_name())) {
				existingAppIndvCargo.setSuffix_name(receivedAppIndvCargo.getSuffix_name());
			}
			if (!compareString(existingAppIndvCargo.getSex_ind(), receivedAppIndvCargo.getSex_ind())) {
				existingAppIndvCargo.setSex_ind(receivedAppIndvCargo.getSex_ind());
			}

			existingAppIndvCargo.setPersoninfo_change_dt(receivedAppIndvCargo.getPersoninfo_change_dt());

			existingAppIndvCargo.setInfoChangeDesc(populateInfoChangeDesc(existingAppIndvCargo));

		} catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populatePersonalInfo() - END");
		return existingAppIndvCargo;
	}
	
	public void removePersonalInfo(String appNum, Integer indvSeqNumber) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.removePersonalInfo() - START");
		APP_INDV_Cargo appIndvCargo = null;
		try {
			
			appIndvCargo = getAppIndvByAppNumIndvSeqNum(appNum,indvSeqNumber);
			if(null != appIndvCargo) {
				appIndvCargo.setPersoninfo_change_dt(null);
				appIndvCargo = revertAppIndvData(appIndvCargo);
				appIndvCargo.setChange_description(FwConstants.EMPTY_STRING);
				saveAppIndvCargo(appIndvCargo);
			}
		}catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.removePersonalInfo() - END");
	}

	private APP_INDV_Cargo revertAppIndvData(APP_INDV_Cargo appIndvCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.revertAppIndvData() - START");
		String[] personalChangeInfo = null;
		try {
			if (!isStringEmptyOrNull(appIndvCargo.getChange_description())
					&& appIndvCargo.getChange_description().contains(HouseHoldDemoGraphicsConstants.COMMA)) {
				personalChangeInfo = appIndvCargo.getChange_description()
						.split(HouseHoldDemoGraphicsConstants.COMMA);
			}
			if (null != personalChangeInfo && personalChangeInfo.length > 0) {
				if (!isStringEmptyOrNull(personalChangeInfo[0])) {
					appIndvCargo.setFst_nam(personalChangeInfo[0]);
				}
				if (!isStringEmptyOrNull(personalChangeInfo[1])) {
					appIndvCargo.setLast_nam(personalChangeInfo[1]);
				}
				if (!isStringEmptyOrNull(personalChangeInfo[2])) {
					appIndvCargo.setMid_init(personalChangeInfo[2]);
				}
				if (!isStringEmptyOrNull(personalChangeInfo[3])) {
					appIndvCargo.setSuffix_name(personalChangeInfo[3]);
				}
				if (!isStringEmptyOrNull(personalChangeInfo[4])) {
					appIndvCargo.setSex_ind(personalChangeInfo[4]);
				}
			}
		} catch (Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.revertAppIndvData() - END");
		return appIndvCargo;

	}

	public APP_INDV_Cargo populateDefaultInfo(APP_INDV_Cargo appIndvCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populateDefaultInfo() - START");
		try {
			appIndvCargo.setFst_nam(isStringEmptyOrNull(appIndvCargo.getFst_nam()) ? FwConstants.EMPTY_STRING
					: appIndvCargo.getFst_nam());
			appIndvCargo.setLast_nam(isStringEmptyOrNull(appIndvCargo.getLast_nam()) ? FwConstants.EMPTY_STRING
					: appIndvCargo.getLast_nam());
			appIndvCargo.setMid_init(isStringEmptyOrNull(appIndvCargo.getMid_init()) ? FwConstants.EMPTY_STRING
					: appIndvCargo.getMid_init());
			appIndvCargo.setSuffix_name(isStringEmptyOrNull(appIndvCargo.getSuffix_name()) ? FwConstants.EMPTY_STRING
					: appIndvCargo.getSuffix_name());
			appIndvCargo.setSex_ind(isStringEmptyOrNull(appIndvCargo.getSex_ind()) ? FwConstants.EMPTY_STRING
					: appIndvCargo.getSex_ind());

		} catch (Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populateDefaultInfo() - END");
		return appIndvCargo;
	}
	public APP_INDV_Cargo buildNewPersnInfoCargo(APP_INDV_Cargo existingAppIndvCargo,
			APP_INDV_Cargo receivedAppIndvCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.buildNewPersnInfoCargo() - START");
		StringBuilder persnInfoChangeDesc = new StringBuilder();
		try {
			if (!isStringEmptyOrNull(receivedAppIndvCargo.getFst_nam())) {
				existingAppIndvCargo.setFst_nam(receivedAppIndvCargo.getFst_nam());
				persnInfoChangeDesc.append(receivedAppIndvCargo.getFst_nam());
			}
			persnInfoChangeDesc.append(FwConstants.COMMA);
			if (!isStringEmptyOrNull(receivedAppIndvCargo.getLast_nam())) {
				existingAppIndvCargo.setLast_nam(receivedAppIndvCargo.getLast_nam());
				persnInfoChangeDesc.append(receivedAppIndvCargo.getLast_nam());
			}
			persnInfoChangeDesc.append(FwConstants.COMMA);
			existingAppIndvCargo.setMid_init(receivedAppIndvCargo.getMid_init());
			persnInfoChangeDesc.append(receivedAppIndvCargo.getMid_init());
			persnInfoChangeDesc.append(FwConstants.COMMA);
			existingAppIndvCargo.setSuffix_name(receivedAppIndvCargo.getSuffix_name());
			persnInfoChangeDesc.append(receivedAppIndvCargo.getSuffix_name());
			persnInfoChangeDesc.append(FwConstants.COMMA);
			existingAppIndvCargo.setSex_ind(receivedAppIndvCargo.getSex_ind());
			persnInfoChangeDesc.append(receivedAppIndvCargo.getSex_ind());
			existingAppIndvCargo.setPersoninfo_change_dt(receivedAppIndvCargo.getPersoninfo_change_dt());
			existingAppIndvCargo.setChange_description(persnInfoChangeDesc.toString());
			existingAppIndvCargo.setInfoChangeDesc(FwConstants.FIRST_NAME + FwConstants.COMMA + FwConstants.LAST_NAME
					+ FwConstants.COMMA + FwConstants.MIDDLE_INITIAL + FwConstants.COMMA + FwConstants.SUFFIX
					+ FwConstants.COMMA + FwConstants.GENDER);

		} catch (Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.buildNewPersnInfoCargo() - END");
		return existingAppIndvCargo;
	}
	
	public boolean compareString(String a, String b) {
		return (!isStringEmptyOrNull(a) && !isStringEmptyOrNull(b) && a.equalsIgnoreCase(b));
	}
	public String[] splitByComma(String personalInfoDesc) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.splitByComma() - START");
		String[] descArr = null;
		try {
			if (!isStringEmptyOrNull(personalInfoDesc)) {
				descArr = personalInfoDesc.split(FwConstants.COMMA);
			}
		} catch (Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.splitByComma() - END");
		return descArr;
	}
	public String populateInfoChangeDesc(APP_INDV_Cargo exsitingAppIndvCargo) {
		StringBuilder infoChangeDesc = new StringBuilder();
		String[] descArr = null;
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populateInfoChangeDesc() - START");
		try {
			descArr = splitByComma(exsitingAppIndvCargo.getChange_description());
			if (null != descArr && descArr.length > 0) {
				if (!compareString(descArr[0], exsitingAppIndvCargo.getFst_nam())) {
					infoChangeDesc.append(FwConstants.FIRST_NAME);
				}
				infoChangeDesc.append(FwConstants.COMMA);
				if (!compareString(descArr[1], exsitingAppIndvCargo.getLast_nam())) {
					infoChangeDesc.append(FwConstants.LAST_NAME);
				}
				infoChangeDesc.append(FwConstants.COMMA);
				if (!compareString(descArr[2], exsitingAppIndvCargo.getMid_init())) {
					infoChangeDesc.append(FwConstants.MIDDLE_INITIAL);
				}
				infoChangeDesc.append(FwConstants.COMMA);
				if (!compareString(descArr[3], exsitingAppIndvCargo.getSuffix_name())) {
					infoChangeDesc.append(FwConstants.SUFFIX);
				}
				infoChangeDesc.append(FwConstants.COMMA);
				if (!compareString(descArr[4], exsitingAppIndvCargo.getSex_ind())) {
					infoChangeDesc.append(FwConstants.GENDER);
				}
			}

		} catch (Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populateInfoChangeDesc() - END");
		return infoChangeDesc.toString();
	}
	public CP_APP_RGST_Cargo populateHomeLessDtls(String appNumber,Integer indvSeqNum,
			CP_APP_RGST_Cargo receivedRgstCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populateHomeLessDtls() - START");
		CP_APP_RGST_Cargo existingRgstcargo = null;
		try {
			existingRgstcargo = cpAppRgstRepository.getCpAppRgstDetails(Integer.parseInt(appNumber), indvSeqNum);
			if (null == existingRgstcargo) {
				existingRgstcargo = new CP_APP_RGST_Cargo();
				existingRgstcargo.setApp_num(appNumber);
				existingRgstcargo.setIndv_seq_num(indvSeqNum);
				existingRgstcargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
				existingRgstcargo = populateRgstVthDefaultValues(existingRgstcargo, HouseHoldDemoGraphicsConstants.RCHAS);	
			}
			existingRgstcargo.setAlt_l1_adr(receivedRgstCargo.getAlt_l1_adr());
			if(isStringEmptyOrNull(receivedRgstCargo.getAlt_l1_adr())) {
				existingRgstcargo.setAlt_l1_adr(receivedRgstCargo.getAlt_st_adr());
			}
			existingRgstcargo.setAlt_l2_adr(receivedRgstCargo.getAlt_l2_adr());
			existingRgstcargo.setAlt_city_adr(receivedRgstCargo.getAlt_city_adr());
			existingRgstcargo.setAlt_sta_adr(receivedRgstCargo.getAlt_sta_adr());
			existingRgstcargo.setAlt_zip_adr(receivedRgstCargo.getAlt_zip_adr());
			existingRgstcargo.setHshl_zip_adr(receivedRgstCargo.getHshl_zip_adr());
			existingRgstcargo.setMail_addr_chg_begin_dt(receivedRgstCargo.getMail_addr_chg_begin_dt());
			existingRgstcargo.setCnty_num(receivedRgstCargo.getCnty_num());			
			existingRgstcargo.setHless_sw(HouseHoldDemoGraphicsConstants.Y);
			existingRgstcargo.setHomeless_a_ind(receivedRgstCargo.getHomeless_a_ind());
		}catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.populateHomeLessDtls() - END");
		return existingRgstcargo;
	}
	public void clearRmcHomelessAddress(String appNumber, Integer indvSeqNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.clearRmcHomelessAddress() - START");
		CP_APP_RGST_Cargo existingRgstcargo = null;
		try {
			existingRgstcargo = cpAppRgstRepository.getCpAppRgstDetails(Integer.parseInt(appNumber), indvSeqNum);
			if (null == existingRgstcargo) {
				existingRgstcargo = new CP_APP_RGST_Cargo();
				existingRgstcargo.setApp_num(appNumber);
				existingRgstcargo.setIndv_seq_num(indvSeqNum);
				existingRgstcargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
				existingRgstcargo = populateRgstVthDefaultValues(existingRgstcargo, HouseHoldDemoGraphicsConstants.RCMAS);
				
			} else {
				existingRgstcargo = populateRgstVthDefaultValues(existingRgstcargo, HouseHoldDemoGraphicsConstants.RCMAS);
			}
			existingRgstcargo.setMail_addr_chg_begin_dt(null);
			existingRgstcargo.setHless_sw(HouseHoldDemoGraphicsConstants.N);
			existingRgstcargo.setCnty_num(FwConstants.EMPTY_STRING);
			cpAppRgstRepository.save(existingRgstcargo);
		} catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.clearRmcHomelessAddress() - END");
	}
	public void removeOtherPersonalInfo(String appNum, Integer indvSeqNumber) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.removeOtherPersonalInfo() - START");
		APP_INDV_Cargo appIndvCargo = null;
		try {
			
			appIndvCargo = getAppIndvByAppNumIndvSeqNum(appNum,indvSeqNumber);
			if(null != appIndvCargo) {
				appIndvCargo.setOth_info_change_dt(null);
				appIndvCargo.setPers_info_change_desc(FwConstants.EMPTY_STRING);
				saveAppIndvCargo(appIndvCargo);
			}
		}catch (Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.removeOtherPersonalInfo() - END");
	}
	
	public void getAppPgmData(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppPgmData() - START", fwTxn);
		Map<Object, Object> pageCollection = fwTxn.getPageCollection();
		try {
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			APP_PGM_RQST_Collection appPgmRqstCollection = appPrgmRqstRepo.getDetails(Integer.parseInt(appNumber));
			pageCollection.put("APP_PGM_RQST_Collection", appPgmRqstCollection);
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ReportMyChangeBO.getAppPgmData()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getAppPgmData",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getAppPgmData() - END", fwTxn);

	}
	public void getSBMSData(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getSBMSData() - START", fwTxn);
		Map<Object, Object> pageCollection = fwTxn.getPageCollection();
		APP_RQST_Collection appRqstCollection = new APP_RQST_Collection();
		try {
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			APP_SBMS_Collection appSbmsCollection = appsbms.findAllByAppNum(Integer.parseInt(appNumber));
			APP_RQST_Cargo[] appRqstArr = appRqstRepo.findByAppNum(Integer.parseInt(appNumber));
			pageCollection.put("APP_SBMS_Collection", appSbmsCollection);
			if(null != appRqstArr && appRqstArr.length > 0) {
				for(APP_RQST_Cargo rqstCargo : appRqstArr) {
					appRqstCollection.add(rqstCargo);	
				}
			}
			pageCollection.put("APP_RQST_Collection", appRqstCollection);
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ReportMyChangeBO.getSBMSData()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getSBMSData",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ReportMyChangeBO.getSBMSData() - END", fwTxn);

	}
}
