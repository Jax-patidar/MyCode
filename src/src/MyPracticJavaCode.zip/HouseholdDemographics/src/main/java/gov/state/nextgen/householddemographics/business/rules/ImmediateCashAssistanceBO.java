package gov.state.nextgen.householddemographics.business.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IMMED_CASH_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IMMED_CASH_Collection;
import gov.state.nextgen.householddemographics.data.db2.CP_APP_IMMED_CASH_Repository;

@Service("ImmediateCashAssistanceBO")
public class ImmediateCashAssistanceBO extends AbstractBO {
	
	@Autowired
	CP_APP_IMMED_CASH_Repository immedCashRepo;

	public void storeImmediateCashAssistance(CP_APP_IMMED_CASH_Collection immedCashColl) {
	        final long startTime = System.currentTimeMillis();
	        FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ImmediateCashAssistanceBO.storeImmediateCashAssistance() - START");
	        try {
	            CP_APP_IMMED_CASH_Cargo cp_app_immd_cash;
	            CP_APP_IMMED_CASH_Cargo[] immedCashCargo  = immedCashRepo.getAllData();
	           
	            if (null!=immedCashColl && !immedCashColl.isEmpty()) {
            			int immedCashId= 0;
	            		cp_app_immd_cash = immedCashColl.getCargo(0);
						if (cp_app_immd_cash.getImmed_cash_id() != null)
	            		{
							cp_app_immd_cash.setImmed_cash_id(immedCashColl.getCargo(0).getImmed_cash_id());
	            		}
						else
						{
							immedCashId =immedCashCargo.length + 1;
		            		cp_app_immd_cash.setImmed_cash_id(String.valueOf(immedCashId));
						}
	            		
	            		immedCashRepo.save(cp_app_immd_cash);
	            }
	        } catch (final Exception e) {
	        	FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	            throw e;
	        }
	        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ImmediateCashAssistanceBO.storeImmediateCashAssistance() - END , Time Taken :" + (System.currentTimeMillis() - startTime) );
		
	}

	public CP_APP_IMMED_CASH_Collection loadImmediateCashAssistance(String appnum, Integer indv_seq_num) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ImmediateCashAssistanceBO.loadImmediateCashAssistance() - START");
        try {
        	CP_APP_IMMED_CASH_Collection immedCashColl = new CP_APP_IMMED_CASH_Collection();
        	if(appnum != null  && indv_seq_num != null) {
        		CP_APP_IMMED_CASH_Cargo[] immedCash  = immedCashRepo.getByAppNum(Integer.parseInt(appnum));
        			immedCashColl.setResults(immedCash);
        	}
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ImmediateCashAssistanceBO.loadImmediateCashAssistance() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return immedCashColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	
	
	public CP_APP_IMMED_CASH_Collection loadImmediateCashByAppNum(String appnum) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ImmediateCashAssistanceBO.loadImmediateCashAssistance() - START");
        try {
        	CP_APP_IMMED_CASH_Collection immedCashColl = new CP_APP_IMMED_CASH_Collection();
        	if(appnum != null) {
        		CP_APP_IMMED_CASH_Cargo[] immedCashCargo  = immedCashRepo.getByAppNum(Integer.parseInt(appnum));
        		if (immedCashCargo.length > 0) {
        			immedCashColl.setResults(immedCashCargo);
        		}
        	}
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ImmediateCashAssistanceBO.loadImmediateCashAssistance() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return immedCashColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}

	public CP_APP_IMMED_CASH_Collection getByAppNum(String appNum) {
		CP_APP_IMMED_CASH_Cargo[] immColl = immedCashRepo.getByAppNum(Integer.parseInt(appNum));
		CP_APP_IMMED_CASH_Collection coll = new CP_APP_IMMED_CASH_Collection();
		coll.setResults(immColl);
		return coll;
	}

}
