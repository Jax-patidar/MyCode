package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Driver Page Response Model class.
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppSummaryPageResponse extends DriverPageResponse implements Serializable{

	private static final long serialVersionUID = 1669762600294501560L;
	private byte[] byteArr;

	
	public byte[] getByteArr() {
		return byteArr;
	}
	public void setByteArr(byte[] byteArr) {
		this.byteArr = byteArr;
	}	
	
}
