package gov.state.nextgen.householddemographics.business.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.householddemographics.business.entities.CP_HSHL_DETAILS_DISASTER_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_HSHL_DETAILS_DISASTER_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpHshlDetailsDisasterRepository;

/**
 * author: swabehera
 */
@Service("DisasterBO")
public class DisasterBO extends AbstractBO {
	
	@Autowired
	private CpHshlDetailsDisasterRepository cpHshlDtlsDisasterRepository;
	
	/**
	 * store HouseholdDetails
	 * @param cpHhDtlsDisasterCargo 
	 */
	public void storeHouseholdInformation(CP_HSHL_DETAILS_DISASTER_Cargo cpHshlDtlsDisasterCargo) {
		
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"DisasterBO.storeHouseholdInformation- START");
		try {
	            if(cpHshlDtlsDisasterCargo != null){
	            	cpHshlDtlsDisasterRepository.save(cpHshlDtlsDisasterCargo);
	            }
	   } catch (final Exception fe) {
		   FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		} 
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DisasterBO.storeHouseholdInformation - END , Time Taken : " + (System.currentTimeMillis() - startTime) + " milliseconds");	
	}

	public CP_HSHL_DETAILS_DISASTER_Collection loadHouseholdDetailsDCF(String appNumber) {
		
		FwLogger.log(this.getClass(), Level.INFO,
				"DisasterBO.loadHouseholdDetailsDCF() - START");
		
		CP_HSHL_DETAILS_DISASTER_Collection cpHshlDtlsDisasterColl = new CP_HSHL_DETAILS_DISASTER_Collection();
		
		try {
			cpHshlDtlsDisasterColl = cpHshlDtlsDisasterRepository.getHshlDtlsDisasterByAppNum(Integer.parseInt(appNumber));
		
		}catch (Exception ex) {
				 throw ex;
		 }
		
		FwLogger.log(this.getClass(), Level.INFO, "DisasterBO.loadHouseholdDetailsDCF() - END");
		
		return cpHshlDtlsDisasterColl;
	}

}
