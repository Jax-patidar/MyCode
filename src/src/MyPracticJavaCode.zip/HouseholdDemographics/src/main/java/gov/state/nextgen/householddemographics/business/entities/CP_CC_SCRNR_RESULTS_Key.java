package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

public class CP_CC_SCRNR_RESULTS_Key implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2638864299197674595L;
	private String app_num;
	
	
	
	
	protected CP_CC_SCRNR_RESULTS_Key(String app_num) {
		super();
		this.app_num = app_num;
	}
	protected CP_CC_SCRNR_RESULTS_Key() {
	
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		return result;
	}
	
	
	
}
