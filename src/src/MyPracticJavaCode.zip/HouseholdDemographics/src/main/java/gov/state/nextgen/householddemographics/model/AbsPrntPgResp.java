package gov.state.nextgen.householddemographics.model;

public class AbsPrntPgResp extends DriverPageResponse {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3981022820475968648L;

	private Individual individual;
	private ComponentFlags componentFlag;

	public Individual getIndividual() {
		return individual;
	}

	public void setIndividual(Individual individual) {
		this.individual = individual;
	}

	public ComponentFlags getComponentFlag() {
		return componentFlag;
	}

	public void setComponentFlag(ComponentFlags componentFlag) {
		this.componentFlag = componentFlag;
	}
}
