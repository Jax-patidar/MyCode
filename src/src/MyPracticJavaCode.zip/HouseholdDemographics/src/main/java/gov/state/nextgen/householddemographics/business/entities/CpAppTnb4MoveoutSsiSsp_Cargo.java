package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author ransahu
 *
 */
@Entity
@Table(name = "CP_APP_TNB4_MOVEOUT_SSISSP")
@IdClass(CpAppTnb4MoveoutSsiSspPrimaryKey.class)
public class CpAppTnb4MoveoutSsiSsp_Cargo extends AbstractCargo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -256458268045498175L;

	@Transient
	private String appNum;

	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	@Column(name = "INDV_SEQ_NUM")
	private Double indvSeqNum;

	@Id
	@Column(name = "INDV_TYPE")
	private String indvType;

	@Column(name = "SRC_APP_IND")
	private String srcAppInd;

	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name = "APP_NUM", insertable = false, updatable = false)
	private CpAppTnb4Redet_Cargo cpAppTnb4RedetCargo;

	/**
	 * @return the appNum
	 */
	public String getAppNum() {
		return String.valueOf(app_number);
	}

	/**
	 * @param appNum the appNum to set
	 */
	public void setAppNum(String appNum) {
		this.app_number = Integer.parseInt(appNum);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.appNum = String.valueOf(app_number);
	}

	/**
	 * @return the indvSeqNum
	 */
	public Double getIndvSeqNum() {
		return indvSeqNum;
	}

	/**
	 * @param indvSeqNum the indvSeqNum to set
	 */
	public void setIndvSeqNum(Double indvSeqNum) {
		this.indvSeqNum = indvSeqNum;
	}

	/**
	 * @return the indvType
	 */
	public String getIndvType() {
		return indvType;
	}

	/**
	 * @param indvType the indvType to set
	 */
	public void setIndvType(String indvType) {
		this.indvType = indvType;
	}

	/**
	 * @return the srcAppInd
	 */
	public String getSrcAppInd() {
		return srcAppInd;
	}

	/**
	 * @param srcAppInd the srcAppInd to set
	 */
	public void setSrcAppInd(String srcAppInd) {
		this.srcAppInd = srcAppInd;
	}

	/**
	 * @return the cpAppTnb4RedetCargo
	 */
	public CpAppTnb4Redet_Cargo getCpAppTnb4RedetCargo() {
		return cpAppTnb4RedetCargo;
	}

	/**
	 * @param cpAppTnb4RedetCargo the cpAppTnb4RedetCargo to set
	 */
	public void setCpAppTnb4RedetCargo(CpAppTnb4Redet_Cargo cpAppTnb4RedetCargo) {
		this.cpAppTnb4RedetCargo = cpAppTnb4RedetCargo;
	}

}
