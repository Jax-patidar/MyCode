package gov.state.nextgen.householddemographics.handlers;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.amazonaws.serverless.exceptions.ContainerInitializationException;
import com.amazonaws.serverless.proxy.internal.LambdaContainerHandler;
import com.amazonaws.serverless.proxy.internal.testutils.Timer;
import com.amazonaws.serverless.proxy.model.AwsProxyRequest;
import com.amazonaws.serverless.proxy.model.AwsProxyResponse;
import com.amazonaws.serverless.proxy.model.Headers;
import com.amazonaws.serverless.proxy.spring.SpringLambdaContainerHandler;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.householddemographics.HouseholdDemographicsApplication;

/**
 * Stream data handler proxy for AWS Lambda. This is responsible for the below actions
 * 1. Intercepting the requests from API gateway to AWS Lambda
 * 2. Intializing Lambda container and stream handler
 * 3. Handling proxy requests and sending it to REST endpoints.
 */
public class HouseholdDemographicsLambdaHandler implements RequestHandler<AwsProxyRequest,AwsProxyResponse>{

    private static SpringLambdaContainerHandler<AwsProxyRequest, AwsProxyResponse> handler;
    private static final String XAUTHID = "x-auth-id";
    private static final String USERID = "userId";
    private static final String TRANSACTIONID = "transactionIdentifier";
    private static final String APPNUMBER = "appNum";
    private static Logger log = LoggerFactory.getLogger(HouseholdDemographicsLambdaHandler.class);

    static {
        try {
        	FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO, "HouseholdDemographicsLambdaHandler::static block STARTED");
            log.info("HouseholdDemographicsLambdaHandler::static block STARTED");
            handler = SpringLambdaContainerHandler.getAwsProxyHandler(HouseholdDemographicsApplication.class);
        	FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO, "HouseholdDemographicsLambdaHandler::static block ENDED");
            log.info("HouseholdDemographicsLambdaHandler::static block ENDED");
        } catch (ContainerInitializationException e) {
            // if we fail here. We re-throw the exception to force another cold start
            throw new FwException("Could not initialize Spring Boot application", e);
        }
    }

    public HouseholdDemographicsLambdaHandler() {
        // we enable the timer for debugging. This SHOULD NOT be enabled in production.
    	LambdaContainerHandler.getContainerConfig().setDefaultContentCharset("UTF-8");
        Timer.enable();
    }


	@Override
	public AwsProxyResponse handleRequest(AwsProxyRequest event, Context context) {
    	FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler - Got event start "+event.getClass());
    	Headers headers = event.getMultiValueHeaders();
    	headers.add("X-Custom-TransactionIdentifier", context.getAwsRequestId());
    	MDC.put(TRANSACTIONID, context.getAwsRequestId());
    	event.setMultiValueHeaders(headers);
    	setUserIdInToLogs(event);
    	MDC.put(APPNUMBER,getAppNumberFromPayLoad(event.getBody()));
	    AwsProxyResponse response = handler.proxy(event, context);
	    FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler - Response status code ->>>"+response.getStatusCode());
	    MDC.clear();
	    return response;
	}
	 /**
     * @author maheshr
     * @param request
     * @apiNote extract authid from headers for loggedin users and add it to the logs
     */
    private void setUserIdInToLogs(AwsProxyRequest request)
    {
    	FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: setUserIdInToLogs - START");
    	if(!Objects.nonNull(request))
    	{
    		FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: setUserIdInToLogs - AwsProxyRequest is null");
    		FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: setUserIdInToLogs - END");
    		return;
    	}
	    Headers requestHeaders = request.getMultiValueHeaders();
	    if(Objects.nonNull(requestHeaders) && requestHeaders.containsKey(XAUTHID))
           {
	    		   List<String> xAuthIdList = requestHeaders.get(XAUTHID);
	               if(Objects.nonNull(xAuthIdList) && !xAuthIdList.isEmpty())
	               {
	                	FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: setUserIdInToLogs Request Headers contains "+XAUTHID);
	                    String xAuthId = xAuthIdList.get(0);
	                    FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: setUserIdInToLogs "+XAUTHID+" -->" +xAuthId);
	                    MDC.put(USERID,xAuthId);
	                    FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: setUserIdInToLogs  "+XAUTHID+" added to logs-->" +xAuthId);
	                }
	                else
	    	    	{
	    	    		FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: setUserIdInToLogs - xAuthIdList is empty or null "+xAuthIdList);
	    	    	}
           }
	    else
	    	{
	    		FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: setUserIdInToLogs - Headers does not have "+XAUTHID);
	    	}
    	FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: setUserIdInToLogs - END");
    }
    
    
    /**
     * @author maheshr
     * @param payLoad {@link String}
     * @apiNote This Function only uses {@link FwTransaction} as a reference since lambda has a unique payload structure for all API requests
     * @return applicationNumber
     */
    private String getAppNumberFromPayLoad(String payLoad)
    {
    	String applicationNumber = "";
    	FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: extractAppNumber - Start");
    	if(!Objects.nonNull(payLoad) || payLoad.trim().isEmpty())
    	{
    		FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: extractAppNumber - payLoad is null or empty payload :"+payLoad);
    		return applicationNumber;
    	}
	    try
	    {
	    	ObjectMapper jsonMapper = new ObjectMapper();
	    	FwTransaction fwTransaction = jsonMapper.readValue(payLoad,FwTransaction.class);
	    	if(Objects.nonNull(fwTransaction) && Objects.nonNull(fwTransaction.getUserDetails()))
	    	  {
	    		applicationNumber = fwTransaction.getUserDetails().getAppNumber();
	    	  }
	    		
		}
	    catch (JsonProcessingException e) {
				FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.ERROR,  "HouseholdDemographicsLambdaHandler:: extractAppNumber - "+e);
    	}
    	FwLogger.log(HouseholdDemographicsLambdaHandler.class, Level.INFO,  "HouseholdDemographicsLambdaHandler:: extractAppNumber - End");
    	return applicationNumber;
    }
}
