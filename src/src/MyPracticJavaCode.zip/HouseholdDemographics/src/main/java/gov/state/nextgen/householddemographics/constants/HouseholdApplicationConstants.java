package gov.state.nextgen.householddemographics.constants;

import java.util.HashMap;
import java.util.Map;

public class HouseholdApplicationConstants {

	public static final String ONEINDICATOR = "1";

	public static final String MCPROGRAMCODE = "MC";

	public static final String CWPROGRAMCODE = "CW";

	public static final String FSPROGRAMCODE = "FS";

	public static final String APPLICATIONPROCESSED = "TR";
	public static final String APPLICATIONDELETED = "DL";

	public static final String DASHBOARDURL = "dashboardServiceUrl";

	public static final String GUID = "gUID";

	public static final String DASHBOARDGETAPPLICATIONENDPOINT = "dashboard/getApplicationsForUser";
	
	public static final String FS_RQST_IND = "fs_rqst_ind";
	
	public static final String FMA_RQST_IND = "fma_rqst_ind";
			
	public static final String TANF_RQST_IND = "tanf_rqst_ind";
	public static final int ONE = 1;

	private HouseholdApplicationConstants() {

	}

}
