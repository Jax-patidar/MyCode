package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("RCCRT")
@Scope("prototype")
public class HouseholdIndividualConfirmationInfoView implements LogicResponseInterface {

	private static final String PAGE_ID = "RCCRT";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();
		List<APP_RQST_Cargo> appRqstList = new ArrayList<>();

		Map pageCollection = fwTxn.getPageCollection();

		UserDetails userDetails = fwTxn.getUserDetails();

		APP_RQST_Collection appRqstCol = (APP_RQST_Collection) pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_RQST_COLL);

		if (appRqstCol != null && !appRqstCol.isEmpty()) {
			appRqstList = Arrays.stream(appRqstCol.getResults()).collect(Collectors.toList());
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, appRqstList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

		return driverPageResponse;
	}

}
