package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("MCINR")
@Scope("prototype")
public class MCINRResponseWrapper implements LogicResponseInterface{

	private static final String PAGE_ID = "MCINR";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		
		List<APP_INDV_Cargo> appIndvCargoList = new ArrayList<>();

		Map<Object, Object> pageCollection = fwTxn.getPageCollection();
		
		APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection");

		APP_INDV_Cargo appIndvCargo;

		if (appIndvColl != null) {

			for (int i = 0; i < appIndvColl.size(); i++) {

				appIndvCargo = (APP_INDV_Cargo) appIndvColl.get(i);

				appIndvCargoList.add(appIndvCargo);

			}

		}


		driverPageResponse.getPageCollection().put("APP_INDV_Collection", appIndvCargoList);

		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));

		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

		return driverPageResponse;
	}

}
