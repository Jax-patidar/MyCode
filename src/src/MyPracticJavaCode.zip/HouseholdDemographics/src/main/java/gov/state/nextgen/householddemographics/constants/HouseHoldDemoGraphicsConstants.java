package gov.state.nextgen.householddemographics.constants;

import java.sql.Date;
import java.time.LocalDateTime;

import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Collection;

/**
 * This class contains constants being used throughout the HouseHoldDemographics
 * Service
 *
 * Created by @DeloitteUSI team Creation Date Wed Sep 29 11:34:07 IST 2020
 * 
 * @authors: @prabhasingh
 */

public class HouseHoldDemoGraphicsConstants {


	public static final String IS_SELECTED = "isSelected";
	
	public static final String COMMA = ",";

	public static final Integer PROGRAM_NOT_SELECTED = 0;

	public static final String SUFFIX_NAME = "suffixName";

	public static final String MOVED_OUT = "MovedOut";

	public static final String APP_IN_PRFL_COLLECTION = "APP_IN_PRFL_Collection";

	public static final String APP_INDV_COLLECTION = "APP_INDV_Collection";

	public static final String STORED_APP_INDV_COLLECTION = "STORED_APP_INDV_Collection";

	public static final String INDIVIDUAL_CUSTOM_COLLECTION = "INDIVIDUAL_Custom_Collection";

	// CSMP-2809 Leaving CA Service
	public static final String APP_PGM_RQST_COLL = "APP_PGM_RQST_Collection";
	
	public static final String CP_APP_PGM_INDV_COLL ="CP_APP_PGM_INDV_Collection";

	public static final String HOUSE_HOLD_QUESTION = "HHQ";

	public static final String NO_ONE_QUESTION = "NQ";

	public static final String IN_PROGRESS = "IP";

	public static final String OTHER_HOUSE_HOLD_QUESTION = "OHHQ";

	public static final String QUESTION_TYPE = "questionType";

	public static final String SELECTED = "selected";

	public static final String QUESTION_KEY = "questionKey";

	public static final String INDV_SEQ_NUMBER = "indvSeqNumber";

	public static final String CURRENT_PAGE_ID = "CURRENT_PAGE_ID";

	public static final String APP_NUMBER = "APP_NUMBER";

	public static final String COLON = ":";

	public static final String CALFRESH_ABBREV = "CF";

	public static final String BUSINESS_METHOD_STORE_MOVED_OUT = "storeMovedOut";

	public static final String BUSINESS_METHOD_STORE_REG_INFO = "storeRegistrationInformation";

	public static final String BUSINESS_METHOD_STORE_HOUSE_INFO = "storeHouseHoldInfoContactDetails";

	public static final String BUSINESS_METHOD_STORE_ADDRESS_INFO_AFB = "storeMailingAddressDetail";

	public static final String BUSINESS_METHOD_STORE_ADDRESS_INFO_RMB = "storeAddressValidationDetails";

	public static final String BUSINESS_METHOD_STORE_CONTACT_INFO_AFB = "storeContactInformationAFB";

	public static final String BUSINESS_METHOD_STORE_CONTACT_INFO_RMB = "storeContactInformationRMB";

	public static final String BUSINESS_METHOD_LOAD_CONTACT_INFO_AFB = "getContactInformation";

	public static final String BUSINESS_METHOD_LOAD_REG_INFO = "getRegistrationInformation";

	public static final String COMPLETE_APP_STORE_METHOD = "storeHelpWithApplications";

	public static final String COMPLETE_APP_LOAD_METHOD = "getHelpWithApplications";

	public static final String BUSINESS_METHOD_LOAD_DISABILITY_DETAILS = "getDisabilityDetails";

	public static final String BUSINESS_METHOD_STORE_DISABILITY_DETAILS = "storeLangNameAndDisabilityDetails";

	public static final String BUSINESS_METHOD_LOAD_ABSENT_PARENT_DETAILS = "getAbsentParentDetails";

	public static final String BUSINESS_METHOD_NEXT_ABSENT_PARENT_DETAILS = "storeAbsentParentDetails";

	public static final String PROGRAM_INFO_LOAD_METHOD = "getProgramInformation";

	public static final String PROGRAM_INFO_STORE_METHOD = "storeProgramInformation";

	public static final String AUTHORIZED_REPRESENTATIVE_LOAD_METHOD = "getAuthorizedRepresentativeDetails";

	public static final String AUTHORIZED_REPRESENTATIVE_STORE_METHOD = "storeAuthorizedRepresentativeDetails";

	public static final String BUSINESS_METHOD_LOAD_PERSONAL_INFO1 = "getHouseHoldMembersDetail";

	public static final String BUSINESS_METHOD_NEXT_PERSONAL_INFO1 = "storeHouseHoldMembersDetail";

	public static final String BUSINESS_METHOD_LOAD_PERSONAL_INFO2 = "getImmigrationDetails";

	public static final String BUSINESS_METHOD_NEXT_PERSONAL_INFO2 = "storeImmigrationDetail";

	public static final String BUSINESS_METHOD_GET_PEOPLE_HANDLER_INFO = "getPeopleHandlerInformation";

	public static final String BUSINESS_METHOD_GET_INDV_CUSTOM_COLLECTION = "getIndividualCustomCollection";

	public static final String BUSINESS_METHOD_AFB_GET_FOSTER_CARE_DETAILS = "getFosterCareDetails";

	public static final String BUSINESS_METHOD_AFB_STORE_FOSTER_CARE_DETAILS = "storeFosterCareDetails";
	public static final String BUSINESS_METHOD_AFB_DELETE_FOSTER_CARE_DETAILS = "deleteFosterCareDetails";

	// CSPM 2161 Additional County Programs
	public static final String BUSINESS_METHOD_STORE_ADDITIONAL_COUNTY_PROGRAMS = "storeAdditionalCountyProgramDetails";

	public static final String BUSINESS_METHOD_LOAD_ADDITIONAL_COUNTY_PROGRAMS = "loadAdditionalCountyProgramDetails";

	// CSPM-2809 LeavingCA Service
	public static final String BUSINESS_METHOD_AFB_GET_LEAVING_CA_DETAILS = "getLeavingCADetails";
	public static final String BUSINESS_METHOD_AFB_STORE_LEAVING_CA_DETAILS = "storeLeavingCADetails";

	// Start:Added as part of CSPM-2627
	public static final String INDV_FOOD_SERVICES_PROGRAM_LOAD_METHOD = "getAllIndvFoodProgramDetails";
	public static final String INDV_FOOD_SERVICES_PROGRAM_NEXT_METHOD = "storeIndvFoodProgramDetails";
	public static final String DELETE_FOOD_PROGRAM_DETAILS = "deleteFoodProgramDetails";
	// End:Added as part of CSPM-2627

	// Start: CSPM-1945
	public static final String SAVE_MISSING_INFO = "saveMissingInfo";
	// End: CSPM-1945

	// Added as part of CSPM-2783
	public static final String BUSINESS_METHOD_STORE_FOSTERCHILD_DATA = "storeFosterChildData";
	public static final String BUSINESS_METHOD_GET_FOSTERCHILD_DATA = "getFosterChildData";
	public static final String DELETE_FOSTER_CHILD_DATA = "deleteFosterChildData";

	public static final String BUSINESS_METHOD_GET_EXP_ASSISTANCE_INFO = "getHouseHoldExpeditedAssistanceDetails";

	public static final String BUSINESS_METHOD_STORE_EXP_ASSISTANCE_INFO = "storeHouseHoldExpeditedAssistanceDetails";

	public static final String BUSINESS_METHOD_GET_ADDR_VALIDATION_INFORMATION = "getAddressValidationInformation";

	// Added for Email Receipt Service - CSPM-2083
	public static final String BUSINESS_METHOD_LOAD_EMAIL_RECEIPT_INFO = "getEmailReceiptDetails";

	public static final String STORE_AUTH_REP_DET = "storeAuthRepDetails";

	// Method name constants for RMCHouseholdDemographicsService

	public static final String LOAD_HH_INFO_DET = "loadHouseHoldInfoDisabilityDetails";

	public static final String storeHouseHoldInfoDisabilityDetails = "storeHouseHoldInfoDisabilityDetails";

	public static final String LOADFACILITYINFORMATION = "loadFacilityInformation";

	public static final String STORE_FACILITY_INFO = "storeFacilityInformation";

	public static final String CP_APP_IN_SHLTC_COLL = "CP_APP_IN_SHLTC_Collection";

	public static final String ABFIN = "ABFIN";

	public static final String STORED_APP_IN_SHLTC_COLL = "STORED_APP_IN_SHLTC_Collection";

	public static final String BUSINESS_METHOD_AFB_GET_PARENT_SITUATION_PERSONALINFORMATION_DETAILS = "getParentSituationDetails";

	public static final String BUSINESS_METHOD_AFB_STORE_PARENT_SITUATION_DETAILS = "storeParentSituationDetails";
	public static final String FETCH_CASE_APPLICATIONS_DETAILS = "fetchCaseApplicationsDetails";

	// delete method for people summary
	public static final String DEL_PEOPLE_SUMM = "deletePeopleSummary";

	// Methods name constants for ImmediateCashAssistant
	public static final String STORE_IMMED_CASH_ASSIT = "storeImmediateCashAssistance";
	public static final String LOAD_IMMED_CASH_ASSIT = "loadImmediateCashAssistance";

	// method for updateApplicationSubmissionDivider
	public static final String UPDATE_APPLN_SUB_DIVIDER = "updateApplicationSubmissionDivider";
	public static final String APP_RQST_COLL = "APP_RQST_Collection";
	public static final String APP_STATUS_CODE = "SU";
	
	// method for getSBMSData
	public static final String GET_SBMS_DATA = "getSBMSData";

	/** Validation Message Constants. */

	public static final String MSG_90923 = "90923";

	public static final String MSG_90497 = "90497";

	public static final String MSG_50008 = "50008";

	public static final String MSG_09014 = "09014";

	public static final String MSG_09016 = "09016";

	public static final String MSG_50082 = "50082";

	public static final String MSG_00017 = "00017";

	public static final String MSG_000000000 = "000000000";

	public static final String MSG_99062 = "99062";

	public static final String MSG_00019 = "00019";

	public static final String MSG_00000 = "00000";

	public static final String MSG_10231 = "10231";

	public static final String MSG_10238 = "10238";

	public static final char MSG_0 = '0';

	public static final String MSG_09015 = "09015";

	public static final String MSG_10503 = "10503";

	public static final String MSG_79000 = "79000";

	public static final String MSG_79001 = "79001";

	public static final String MSG_79002 = "79002";

	public static final String MSG_79003 = "79003";

	public static final String MSG_00008 = "00008";

	public static final String MSG_10240 = "10240";

	public static final String MSG_00031 = "00031";

	public static final String MSG_00029 = "00029";

	public static final String MSG_10251 = "10251";

	public static final String MSG_000 = "000";

	public static final String MSG_00611 = "00611";

	public static final String MSG_99287 = "99287";

	public static final String MSG_10402 = "10402";

	public static final String MSG_99476 = "99476";

	public static final String MSG_99488 = "99488";

	public static final String MSG_00027 = "00027";

	public static final String MSG_99276 = "99276";

	public static final String MSG_00028 = "00028";

	public static final String MSG_90489 = "90489";

	public static final String MSG_99467 = "99467";

	public static final String MSG_99465 = "99465";

	public static final String MSG_99466 = "99466";

	public static final String MSG_00032 = "00032";

	public static final String MSG_00033 = "00033";

	public static final String MSG_3017360 = "3017360";

	public static final String MSG_99477 = "99477";

	public static final String MSG_98005 = "98005";

	public static final String MSG_10448 = "10448";

	public static final String MSG_10506 = "10506";

	public static final String MSG_10259 = "10259";

	public static final String MSG_3117361 = "3117361";

	public static final String MSG_820100996 = "820100996";

	public static final String MSG_99423 = "99423";

	public static final String MSG_3018189 = "3018189";

	public static final String MSG_3018190 = "3018190";

	public static final String MSG_800100266 = "800100266";

	public static final String MSG_10465 = "10465";

	public static final String MSG_98006 = "98006";

	public static final String MSG_00022 = "00022";

	public static final String MSG_00034 = "00034";

	public static final String MSG_00038 = "00038";

	public static final String MSG_00035 = "00035";

	public static final String MSG_00039 = "00039";

	public static final String MSG_00036 = "00036";

	public static final String MSG_00040 = "00040";

	public static final String MSG_00044 = "00044";

	public static final String MSG_00045 = "00045";

	public static final String MSG_00043 = "00043";

	public static final String MSG_99407 = "99407";

	public static final String MSG_HML = "HML";

	public static final String MSG_004 = "004";

	public static final String MSG_001 = "001";

	public static final int ONE = 1;

	public static final String ONE_STRING = "1";

	public static final Date HIGH_DATE = new Date(12 / 31 / 999);

	public static final String MSG_00076 = "00076";

	public static final String DBLTY_TYPE_OTH_MSG_CD = "00079";

	public static final String DBLTY_TYPE_OTH_CD = "OT";

	public static final String DISABILITY_TYPE_DEFAULT_CD = "000";

	public static final String DISABILITY_TYPE_MSG_CD = "00077";

	public static final String EMPTY = "";

	public static final String TILDE = "~";

	public static final String PAGE_MODE = "PAGE_MODE";

	public static final String MSG_00327 = "00327";

	public static final String MSG_10332 = "10332";

	public static final String MSG_99365 = "99365";

	public static final String MSG_99366 = "99366";

	public static final String MSG_99367 = "99367";

	public static final String MSG_99368 = "99368";

	public static final String MSG_30075 = "30075";

	public static final String MSG_00147 = "00147";

	public static final int ZERO = 0;

	public static final Integer PROGRAM_SELECTED = 1;

	public static final String MSG_10235 = "10235";

	public static final String MSG_00061 = "00061";

	public static final String MSG_90947 = "90947";

	public static final String MSG_00710 = "00710";

	public static final String MSG_00711 = "00711";

	public static final String MSG_00020 = "00020";

	public static final String MSG_00018 = "00018";

	public static final String MSG_70019 = "70019";

	public static final Object NEXT_PAGE_ID = null;

	public static final Object NEXT_PAGE_ACTION = null;

	public static final String MSG_99001 = "99001";

	public static final String MSG_10294 = "10294";

	public static final Date HIGH_DATE_OBJ = Date.valueOf("9999-12-31");

	public static final String STORERMBLANDINGPAGE = "storeRMBLandingPage";

	public static final String LOADRMBLANDING = "loadRMBLanding";

	/** The Constant X3. */
	public static final String X3 = "X";

	/** The Constant X2. */
	public static final String X2 = "x";

	/** The Constant XXXXX. */
	public static final String XXXXX = "XXXXX";

	public static final String N = "N";

	public static final String Y = "Y";

	public static final java.time.LocalDateTime HIGH_DATE_VALUE = LocalDateTime.of(9999, 12, 31, 0, 0, 0);

	/**
	 * HouseholdDemographicsIndividualRelationshipServiceImpl
	 */

	public static final String BUSINESS_METHOD_STORE_HOUSEHOLD_MOVED_OUT_DETAILS = "storeHouseHoldInfoMovedOutDetails";
	public static final String BUSINESS_METHOD_STORE_CITIZENSHIP_DECLARATION = "storeCitizenshipDeclaration";

	public static final String BUSINESS_METHOD_LOAD_HOUSEHOLD_MOVED_OUT_DETAILS = "loadHouseHoldInfoMovedOutDetails";
	public static final String BUSINESS_METHOD_LOAD_MOVE_OUT = "loadMovedOut";
	public static final String BUSINESS_METHOD_LOAD_CITIZENSHIP_DECLARATION = "loadCitizenshipDeclaration";
	public static final String BUSINESS_METHOD_LOAD_HOUSEHOLD_RELATIONSHIP_INFO = "loadHouseHoldInfoRelationshipDetails";
	public static final String BUSINESS_METHOD_STORE_HOUSEHOLD_RELATIONSHIP_INFO = "storeHouseHoldInfoRelationshipDetails";
	public static final String BUSINESS_METHOD_AFB_GET_CITIZENSHIP = "getCitizenship";
	public static final String BUSINESS_METHOD_STORE_AFB_STORE_CITIZENSHIP = "storeCitizenship";
	public static final String BUSINESS_METHOD_AFB_STORE_HOUSEHOLD_RELATIONS = "storeHouseHoldRelationshipDetails";
	public static final String BUSINESS_METHOD_AFB_GET_HOUSEHOLD_RELATIONS = "getHouseHoldRelationshipDetails";
	public static final String BUSINESS_METHOD_LOAD_FIX_MEALS_PERSON_SELECTION = "getFixMealsPersonSelection";
	public static final String BUSINESS_METHOD_STORE_FIX_MEALS_PERSON_SELECTION = "storeFixMealsPersonSelection";
	public static final String BUSINESS_METHOD_AFB_STORE_RELATIONSHIP_AND_BUYPREPAREFOOD_DETAILS = "storeRelationshipandBuyPrepareFoodDetails";
	public static final String BUSINESS_METHOD_AFB_GET_RELATIONSHIP_AND_BUYPREPAREFOOD_DETAILS = "getRelationshipandBuyPrepareFoodDetails";
	public static final String BUSINESS_METHOD_AFB_GET_PARENT_SITUATION_ABSENT_DETAILS = "getParentSituationAbsentDetails";
	public static final String BUSINESS_METHOD_AFB_STORE_PARENT_SITUATION_ABSENT_DETAILS = "storeParentSituationAbsentDetails";
	public static final String BUSINESS_METHOD_AFB_GET_PEOPLE_SUMMARY_DETAILS = "getPeopleSummaryDetails";
	public static final String BUSINESS_METHOD_AFB_STORE_CARETAKER_PERSON_SELECTION_DETAILS = "storeCaretakerPersonSelectionDetails";
	public static final String BUSINESS_METHOD_AFB_STORE_OTHERREVIEW_APPLICATION_SUMMARY = "storeOtherReviewAppSummary";
	public static final String BUSINESS_METHOD_AFB_LOAD_OTHERREVIEW_APPLICATION_SUMMARY = "loadOtherReviewAppSummary";
	public static final String BUSINESS_METHOD_MOVED_IN_DATE="saveMovedInDate";
	public static final String RMC_IN_PRFL_COLLECTION = "RMC_IN_PRFL_Collection";

	// CSPM-1881 Support Services
	public static final String LOAD_SUPP_SER_DET = "loadSupportServicesDetails";
	public static final String STORE_SUPP_SER_DET = "storeSupportServicesDetails";
	public static final String CP_APP_SUPPORT_SERVICES_COLL = "CP_APP_SUPPORT_SERVICES_Collection";

	public static final String NO_ONE_COLLECTION = "NO_ONE_Collection";
	public static final String CARGOS = ".cargos.";
	public static final String COLLECTIONS = ".collections.";

	public static final String PEOPLE_MAP_ID_ARMOV = "PEOPLE_20055";
	public static final String RESPONSE_PEOPLE_MAP_ID_ARMOV = "RESP_MAP_20055";
	public static final String NO_ONE_CHECKED_MAP = "NO_ONE_CHECKED_MAP";
	public static final String NO_ONE_MOVED_OUT = "NoOne_MovedOut";
	public static final String NO_ONE_CHECKED_20055 = "NO_ONE_CHECKED_20055";
	/**
	 * IRMCProfileManager Constants TODO: Will be moved once profile manager's are
	 * implemented.
	 */
	public static final short MOVED_OUT_OF_HOME_RESP = 156;
	public static final String MOVED_OUT_OF_HOME_RESP_VALUE = "R";
	public static final String IS_LOAD = "isLoad";
	public static final String APP_HSHL_RLT_COLLECTION_KEY = "APP_HSHL_RLT_Collection";
	public static final String APP_IN_PREG_COLLECTION = "APP_IN_PREG_Collection";
	public static final String INDV_SRC_CUST_COLLECTION = "INDV_SRC_CUST_Collection";
	public static final String CASE_PROGRAMS_COLLECTION = "CASE_PROGRAMS_Collection";
	public static final short ROOM_BOARD = 158;
	public static final short ROOM_AND_BOARD = 47;

	/**
	 * IApplicationManager Constants TODO: Will be moved once profile manager's are
	 * implemented.
	 */
	public static char STATUS_REQUIRED = 'R';
	public static char STATUS_NOT_REQUIRED = 'N';
	public static char STATUS_COMPLETE = 'C';
	public static char STATUS_ADD_NEW = 'A';
	public static char STATUS_VISIT_AGAIN = 'V';
	public static char STATUS_ABSOLUTE_NOT_REQUIRED = 'X';
	public static char RESPONSE_YES = 'Y';
	public static char RESPONSE_NO = 'N';

	/**
	 * RMCResponseProfileManager constants TODO: Will be moved once profile
	 * manager's are implemented.
	 */
	public static final short ACCIDENT = 0; // ACDT_RESP
	public static final short ADOPTION_ASSISTANCE = 1;// ADPT_ASST_RESP
	public static final short ALIMONY_RECEIVED = 2;// ALMY_RCV_RESP
	public static final short BENEFIT_ANNUITIES = 3;// BNFT_ANTY_RESP
	public static final short BENEFIT_CHARITY = 4;// BNFT_CHRT_RESP
	public static final short BENEFIT_DISABLE = 5;// BNFT_DABL_RESP
	public static final short BENEFIT_DIVIDEND = 6;// BNFT_DIVND_RESP
	public static final short BENEFIT_TRUST = 7;// BNFT_EST_TRST_RESP
	public static final short BENEFIT_RAILROAD_RETIREMENT = 8;// BNFT_RR_RESP
	public static final short BENEFIT_UNEMPLOYMENT = 9;// BNFT_UEMPL_RESP
	public static final short BENEFIT_VETERAN = 10;// BNFT_VET_RESP
	public static final short CHILD_SUPPORT_PAYMENT = 11;// CHLD_SPRT_PAY_RESP
	public static final short DISABLE = 12;// DABL_RESP
	public static final short DEPENDENT_CARE = 13;// DPND_CARE_RESP
	public static final short DRUG_FELON = 14;// DRUG_FELN_RESP
	public static final short FSET_SANCTION = 15;// FSET_SCTN_RESP
	public static final short FOSTER_CARE = 16;// FSTR_CARE_RESP
	public static final short GENERAL_RELIEF = 17;// GEN_RLF_RESP
	public static final short HEALTHCARE_COVERAGE = 18;// HC_CVRG_RESP
	public static final short INCOME_INTEREST = 19;// INCM_INT_RESP
	public static final short INDIVIDUAL_FAMILY_MEDICAID = 20;// INDV_FMA_RQST_IND
	public static final short INDIVIDUAL_FPW = 21;// INDV_FPW_RQST_IND
	public static final short INDIVIDUAL_FOODSHARE = 22;// INDV_FS_RQST_IND
	public static final short IREW = 23; // IREW_RESP
	public static final short KINSHIP_CARE = 24;// KINSHIP_CARE_RESP
	public static final short MEDICAL_EXPENSE = 25;// MED_EXP_RESP
	public static final short MILITARY_ALLOTMENT = 26;// MIL_ALLOT_RESP
	public static final short MONEY_FROM_ANOTHER_PERSON = 27;// MONY_OTHR_RESP
	public static final short REFUGE = 28;// NATL_RFGE_RESP
	public static final short NEEDY_INDIAN = 29;// NEED_IND_RESP
	public static final short ON_STRIKE = 30;// ON_STRK_SW
	public static final short OTHER_PENSION = 31;// OP_AODA_TMT_RCV_SW
	public static final short OTHER_INCOME = 32;// OTHR_INCM_RESP
	public static final short OTHER_SOURCE = 33;// OTHR_SRC_RESP
	public static final short OWNER_ASSET = 34; // OWN_ASET_RESP
	public static final short PAY_HOUSING_BILL = 35; // PAY_HOUS_BILL_RESP
	public static final short PREGNANCY = 36;// PREG_RESP
	public static final short JOB_IN_KIND = 37;// JOB_IKND_RESP
	public static final short PAY_ROOM_AND_BOARD = 38;// PAY_RMR_BRD_RESP
	public static final short PENSION_RETIREMENT = 39;// PNSN_RETR_RESP
	public static final short PROPERTY_SOLD = 40;// PROP_SOLD_RESP
	public static final short RECEIVE_FS_IN_OTHER_STATE = 41;// RCV_FS_OTH_ST_RESP
	public static final short RECEIVE_HOUSING_ASSET = 42;// RCV_HOUS_ASST_RESP
	public static final short RECEIVE_MEDICARE = 43;// RCV_MEDCR_RESP
	public static final short RECEIVE_SOCIAL_SECURITY = 44;// RCV_SS_RESP
	public static final short RECEIVE_SSI_LETTER = 45;// RCV_SSI_LTR_RESP
	public static final short RECEIVE_SSI = 46;// RCV_SSI_SW
	public static final short SELF_EMPLOYMENT = 48;// SELF_EMPL_RESP
	public static final short RECEIVE_SSI_DCOND = 49;// SSI_DCOND_RESP
	public static final short RECEIVE_SSI_1619B = 50;// SSI_1619B_RCV_SW
	public static final short SHELTER_COST_ASSESSMENT = 51;// SU_CST_ASES_RESP
	public static final short SHELTER_COST_COAL = 52;// SU_CST_COAL_RESP
	public static final short SHELTER_COST_ELECTRICTY = 53;// SU_CST_ELEC_RESP
	public static final short SHELTER_COST_FUEL = 54;// SU_CST_FUEL_RESP
	public static final short SHELTER_COST_GAS = 55;// SU_CST_GAS_RESP
	public static final short SHELTER_COST_HOME = 56;// SU_CST_HOME_RESP
	public static final short SHELTER_COST_INSTALL = 57;// SU_CST_ISTL_RESP
	public static final short SHELTER_COST_LPGAS = 58;// SU_CST_LPGAS_RESP
	public static final short SHELTER_COST_MOBILE_HOME = 59;// SU_CST_MBL_RESP
	public static final short SHELTER_COST_MORTGAGE = 60;// SU_CST_MTGE_RESP
	public static final short SHELTER_COST_OTHER = 61;// SU_CST_OTHR_RESP
	public static final short SHELTER_COST_PHONE = 62;// SU_CST_PHN_RESP
	public static final short SHELTER_COST_RENT = 63;// SU_CST_RENT_RESP
	public static final short SHELTER_COST_SEWER = 64;// SU_CST_SWR_RESP
	public static final short SHELTER_COST_TAX = 65;// SU_CST_TAX_RESP
	public static final short SHELTER_COST_TRASH = 66;// SU_CST_TRSH_RESP
	public static final short SHELTER_COST_WOOD = 67;// SU_CST_WOOD_RESP
	public static final short SHELTER_COST_WATER = 68;// SU_CST_WTR_RESP
	public static final short SHELTER_COST_WASTE = 69;// SU_CST_WWT_RESP
	public static final short TRIBAL_TANF = 70;// TRB_TANF_RESP
	public static final short UTILITY_EXPENSE = 71;// UTIL_EXP_RESP
	public static final short WORKER_COMP = 72;// WORK_COMP_RESP
	public static final short TRIBAL_CAPITA = 73;// TRB_CPTA_RESP
	public static final short EDUCATIONAL_AID = 74;// educ_aid_resp;---
	public static final short WHEAP = 75;// educ_aid_resp;---
	public static final short REGULAR_EMPL = 76;// Empl_resp
	public static final short BNFT_CHL_SPRT_RESP = 77;// BNFT_CHL_SPRT_RESP
	public static final short PUB_ASST_RESP = 78;// PUB_ASST_RESP
	public static final short YEHOC_RESP = 79; // YEHOC_RESP
	// PCR 35980 Added - past_hc_cvrg_resp
	public static final short PAST_HEALTHCARE_COVERAGE = 80; // PAST_HC_CVRG_RESP
	// PCR# 40362 - New responses added for RMB/SMRF - starts



	public static final short MAPP_BENEFITS_RESP = 81; // BNFT_MAPP_RESP
	public static final short BUR_AST_CASKET = 82; // BURY_ASET_C_RESP
	public static final short BUR_AST_IRREVOCABLE = 83;// BURY_ASET_IBT_RESP
	public static final short BUR_AST_INSURANCE = 84; // BURY_ASET_INS_RESP
	public static final short BUR_AST_MAUSOLEUM = 85; // BURY_ASET_MAS_RESP
	public static final short BUR_AST_OTHER = 86; // BURY_ASET_OTH_RESP
	public static final short BUR_AST_PLOT = 87; // BURY_ASET_PLT_RESP
	public static final short BUR_AST_REVOCABLE = 88; // BURY_ASET_RBT_RESP
	public static final short BUR_AST_VAULT = 89; // BURY_ASET_V_RESP
	public static final short LIF_AST_GROUP_LIFE = 90; // LI_ASET_G_L_RESP
	public static final short LIF_AST_GROUP_TERM = 91; // LI_ASET_G_T_RESP
	public static final short LIF_AST_TERM = 92; // LI_ASET_TRM_RESP
	public static final short LIF_AST_UNIVERSAL = 93; // LI_ASET_UNV_RESP
	public static final short LIF_AST_WHOLE_LIFE = 94; // LI_ASET_W_L_RESP
	// short LIQ_ASET_CHECKING_ACCOUNT = 95; // LQD_ASET_C_A_RESP
	public static final short LIQ_ASET_CASH = 96; // LQD_ASET_CASH_RESP
	public static final short LIQ_ASET_EBD = 97; // LQD_ASET_EB_A_RESP
	public static final short LIQ_ASET_HOME_SALE = 98; // LQD_ASET_H_S_RESP
	public static final short LIQ_ASET_IRA = 99; // LQD_ASET_IRA_RESP
	// short LIQ_ASET_KEOUGH_PLAN = 100; // LQD_ASET_K_P_RESP
	public static final short LIQ_ASET_MONEY_OWNED = 101; // LQD_ASET_M_O_RESP
	public static final short LIQ_ASET_MONEY_MARKET_ACCOUNT = 102; // LQD_ASET_MM_A_RESP
	public static final short LIQ_ASET_MONEY_OTHER_TYPE = 103; // LQD_ASET_O_T_RESP
	public static final short LIQ_ASET_OTHER = 104; // LQD_ASET_OTHR_RESP
	public static final short LIQ_ASET_SAVINGS_ACCOUNT = 105; // LQD_ASET_S_A_RESP
	public static final short LIQ_ASET_SAVINGS_CERTIFICATE = 106; // LQD_ASET_S_C_RESP
	public static final short LIQ_ASET_STOCKS_BONDS = 107; // LQD_ASET_ST_B_RESP
	public static final short LIQ_ASET_TRUST_FUNDS = 108; // LQD_ASET_TR_F_RESP
	public static final short LIQ_ASET_US_BOND = 109; // LQD_ASET_US_B_RESP
	public static final short OTHR_ASET_BURIAL = 110; // OTHR_ASET_BUR_RESP
	public static final short OTHR_ASET_LIFE_INSURANCE = 111; // OTHR_ASET_L_I_RESP
	public static final short OTHR_ASET_PERSONAL_PROPERTY = 112; // OTHR_ASET_P_P_RESP
	public static final short OTHR_ASET_REAL_PROPERTY = 113; // OTHR_ASET_R_P_RESP
	public static final short OTHR_ASET_VEHICLE = 114; // OTHR_ASET_VEH_RESP
	public static final short OTHR_ASET_TRANSFER = 115; // OTHR_ASET_XFR_RESP
	public static final short REAL_ASET_COMMERCIAL = 138;// REAL_ASET_COM_RESP
	public static final short REAL_ASET_CONDO = 123; // REAL_ASET_CON_RESP
	public static final short REAL_ASET_DUPLEX = 124; // REAL_ASET_DUP_RESP
	public static final short REAL_ASET_HOUSE = 116; // real_asset_house_resp
	public static final short REAL_ASET_LAND = 117; // real_asset_land_resp
	public static final short REAL_ASET_MOBILE_HOME = 118; // real_asset_mobile_home_resp
	public static final short REAL_ASET_OTHER = 119; // real_asset_other_resp
	public static final short VEH_ASET_ANIMAL_DRAWN = 125; // VEH_ASET_ANML_RESP
	public static final short VEH_ASET_AIRPLANE = 126; // VEH_ASET_ARPL_RESP
	public static final short VEH_ASET_AUTOMOBILE = 127; // VEH_ASET_AUTO_RESP
	public static final short VEH_ASET_BOAT = 128; // VEH_ASET_BOAT_RESP
	public static final short VEH_ASET_BUS = 129; // VEH_ASET_BUS_RESP
	public static final short VEH_ASET_CAMPER = 130; // VEH_ASET_CAMP_RESP
	public static final short VEH_ASET_FARM_IMPLEMENT = 131; // VEH_ASET_FIMP_RESP
	public static final short VEH_ASET_FARM_EQUIP = 132; // VEH_ASET_FMEQ_RESP
	public static final short VEH_ASET_FARM_TRACTOR = 133; // VEH_ASET_FTRC_RESP
	public static final short VEH_ASET_FARM_TRAILER = 134; // VEH_ASET_FTRL_RESP
	public static final short VEH_ASET_LOG_SKIDDER = 135; // VEH_ASET_LSKD_RESP
	public static final short VEH_ASET_MOTORCYCLE = 136; // VEH_ASET_MCYC_RESP
	public static final short VEH_ASET_MOPED = 137; // VEH_ASET_MPED_RESP
	public static final short VEH_ASET_NONMOTORIZED_BOAT = 235; // VEH_ASET_NM_B_RESP
	public static final short VEH_ASET_OTHER = 139; // VEH_ASET_OTHR_RESP
	public static final short VEH_ASET_RECREATIONAL_VEHICLE = 140; // VEH_ASET_RV_RESP
	public static final short VEH_ASET_SNOWMOBILE = 145; // VEH_ASET_S_MB_RESP //not used
	public static final short VEH_ASET_TRUCK = 237; // VEH_ASET_TRK_RESP
	public static final short VEH_ASET_TRAVEL_TRAILER = 236; // VEH_ASET_TRLR_RESP
	public static final short VEH_ASET_VAN = 144; // VEH_ASET_VAN_RESP
	public static final short LIQUID_ASSET_XFER = 203;
	public static final short INDV_TANF_RQST_IND = 218;// added last sequence num 217 previous number was 204 replaced
														// to use in persit for IRMCResponseProfileManager.persistStatus
														// index sequence
	public static final short INDV_WIC_RQST_IND = 219;
	public static final short OTHR_INCM_CONTRIB_RESP = 220;
	public static final short CHILD_CARE_RESP = 221;
	public static final short CHILD_OBLIGATION_RESP = 222;
	public static final short MEDICAL_BILLS_RESP = 223;
	public static final short MEDTYP_DENTAL = 224;
	public static final short MEDTYP_ATTENDANT_CARE = 225;
	public static final short MEDTYP_DOCTOR = 226;
	public static final short MEDTYP_MED_EQUIP = 227;
	public static final short MEDTYP_HOSP_BILLS = 228;
	public static final short MEDTYP_INSUR_PREMIUM = 229;
	public static final short MEDTYP_RX_COST = 230;
	public static final short MEDTYP_TRANS_MED = 231;
	public static final short MEDTYP_OTHER = 232;
	public static final short HOUS_PICE = 233;
	public static final short OUTSTATE_BNFTS = 234;
	public static final short LIQUID_ASET_BANK = 95;
	public static final short REAL_ASET_HOME = 120; // REAL_ASET_HOME_RESP
	public static final short REAL_ASET_LIFE_ESTATE = 121; // real_asset_life_estate_resp
	public static final short REAL_ASET_UNOCCUPY_HOME = 122; // REAL_ASET_UNOCCUPY_HOME_RESP
	public static final short VEH_ASET_TRACTOR = 141;
	public static final short VEH_ASET_GOLFCART = 142;
	public static final short VEH_ASET_NONMOTORIZED_CAMPER = 143;

	public static int INDV_PRG_RQST = 1000;
	public static final short HOSPITAL_STAY_RESP = 204;// HOSPITAL_STAY_RESP
	public static final short VEH_ASET_UNLIC = 238;// VEH_ASET_UNLIC_RESP
	public static final short UNPAID_MEDBILL = 239;
	public static final short SPECIAL_NEED = 240;
	public static final short FOSTER_CARE_RESP = 241;
	public static final short FORMER_FOSTER_RESP = 242;
	public static final short CHILD_PROTECTIVE_RESP = 243;
	public static final short LIVING_PROG_RESP = 244;
	public static final short GRAND_PARENT_RESP = 245;
	public static final short DRUG_FELONIES_RESP = 246;
	public static final short SNAP_TANF_DISC_RESP = 247;
	public static final short TANF_DISC_RESP = 329;
	public static final short AVOID_PROSC_RESP = 248;
	public static final short VIOLATING_PAROLE_RESP = 249;
	public static final short CONVIC_FALSE_INFO_RESP = 250;
	public static final short VOLUNTARILY_QUIT_JOB_RESP = 251;
	public static final short TRADING_SNAP_RESP = 252;
	public static final short BUY_SELL_SNAP_RESP = 253;
	public static final short TRADE_SNAP_GUN_RESP = 254;
	public static final short PREV_SSI_RESP = 255;
	public static final short HOME_COMMUNITY_RESP = 256;
	public static final short TRIBAL_HEALTH_RESP = 257;
	public static final short TRIBAL_ELIGIBILITY_RESP = 258;
	public static final short DOMESTIC_VIOLENCE_RESP = 259;
	public static final short TANF_EPPIC_RESP = 260;
	public static final short EMERGENCY_MEDICAL_RESP = 261;
	public static final short MEDTYP_HSA_CONTRIB = 262;
	public static final short UEI_ADOPTION_ASSIST = 263;
	public static final short UEI_ADOPTION_PYMT = 264;
	public static final short UEI_AGENT_ORNG_PYMT = 265;
	public static final short UEI_ALIMONY = 266;
	public static final short UEI_CAPITAL_GAINS = 267;
	public static final short UEI_DEATH_BNFT = 268;
	public static final short UEI_DABL_INCM = 269;
	public static final short UEI_DR_RELIEF = 270;
	public static final short UEI_EDU_ASSIST = 271;
	public static final short UEI_ENERGY_ASSIST = 272;
	public static final short UEI_FRM_ALOT = 273;
	public static final short UEI_FOSTER_CARE_PYMT = 274;
	public static final short UEI_GEN_ASSIST = 275;
	public static final short UEI_INT_DIV_PYMT = 276;
	public static final short UEI_IRA_DIST = 277;
	public static final short UEI_LOTTERY_WIN = 278;
	public static final short UEI_LUMP_SUM = 279;
	public static final short UEI_MIL_ALOT = 280;
	public static final short UEI_MON_FRO_OTH = 281;
	public static final short UEI_NET_RENT_ROYALTY = 282;
	public static final short UEI_OTH = 283;
	public static final short UEI_ANNY_PYMT = 284;
	public static final short UEI_PYMT_BO = 285;
	public static final short UEI_PENSION = 286;
	public static final short UEI_RR_RETIRE = 287;
	public static final short UEI_REFUGEE_CASH = 288;
	public static final short UEI_REL_CARE = 289;
	public static final short UEI_RENTAL_INCM = 290;
	public static final short UEI_TANF_PYMT = 291;
	public static final short UEI_UNEMPL = 292;
	public static final short UEI_WORKER_STUDY = 293;
	public static final short UEI_WORKER_COMP = 294;
	public static final short REAL_ASET_RENTAL = 295;// real_asset_rental_resp
	public static final short REAL_ASET_VAC = 296;// real_aset_vac_resp
	public static final short REAL_ASET_APARTMENT = 297; // REAL_ASET_APT_RESP
	public static final short REAL_ASET_FARM = 298; // REAL_ASET_FRM_RESP
	public static final short PERS_PROP_BUS_EQPT = 299;
	public static final short PERS_PROP_CEMETARY_LOT = 300;
	public static final short PERS_PROP_LIVESTOCK = 301;
	public static final short PERS_PROP_SAF_DEPST_BOX = 302;
	public static final short PERS_PROP_OTH_VAL = 303;
	public static final short ABLE_TO_CONCEIVE_RESP = 304;
	public static final short UNDERWEIGHT_BIRTH_RESP = 305;
	public static final short PREG_ADD_STAT_SW = 306;
	public static final short PREG_CHG_STAT_SW = 307;
	public static final short PRSN_INFO_STAT_SW = 308;
	public static final short RLT_CHG_STAT_SW = 309;
	public static final short SU_CST_INS_RESP = 310;
	public static final short OTHER_HOUSING_BILL_RESP = 311;
	public static final short DISASTER_REPAIR_RESP = 312;
	public static final short PREVENT_EVICTION_RESP = 313;
	public static final short CARE_TAKER_RESP = 314;
	public static final short OTHR_INCM_TRBL_RESP = 315;
	public static final short LOST_HEALTH_INS_IND = 316;
	public static final short TAX_CLAIM_DEPENDENT = 317;
	public static final short BEFORE_TAX_DEDUCTION = 318;
	public static final short BTD_MED_INS = 319;
	public static final short BTD_DENT_INS = 320;
	public static final short BTD_VIS_CARE_INS = 321;
	public static final short BTD_FLEX_ACC = 322;
	public static final short BTD_DEF_COMP = 323;
	public static final short BTD_PRE_TAX_INS = 324;
	public static final short BTD_OTHER = 325;
	public static final short TAX_DEDUCT_RESP = 326;
	public static final short HLTH_INS_RESP = 327;
	public static final short OTHR_HLTH_INS_RESP = 328;
	public static final short ROOM_BRD_CHG_IND = 330;
	public static final short DABL_STAT_IND = 331;
	public static final short PREG_ADD_STAT_IND = 332;
	public static final short PREG_CHG_IND = 333;
	public static final short IRWE_CHG_IND = 334;
	public static final short EI_CHG_IND = 335;
	public static final short SELF_EMPL_CHG_IND = 336;
	public static final short OTHR_INCM_CHG_IND = 337;
	public static final short EMPL_CHG_IND = 338;
	public static final short VEH_ASET_ADD_IND = 339;
	public static final short VEH_ASET_CHG_IND = 340;
	public static final short REAL_ASET_ADD_IND = 341;
	public static final short REAL_ASET_CHG_IND = 342;
	public static final short BURY_ASET_ADD_IND = 343;
	public static final short BURY_ASET_CHG_IND = 344;
	public static final short LIQUID_ASSET_ADD_IND = 345;
	public static final short LIQUID_ASSET_BANK_ACC_CHG_IND = 346;
	public static final short LIQUID_ASSET_CASH_CHG_IND = 347;
	public static final short LIQUID_ASSET_CHG_IND = 348;
	public static final short LIQUID_ASSET_OTHER_CHG_IND = 349;
	public static final short LIFE_INS_ASET_ADD_IND = 350;
	public static final short LIFE_INS_ASET_CHG_IND = 351;
	public static final short ASET_XFER_CHG_IND = 352;
	public static final short DPND_CARE_CHG_IND = 353;
	public static final short HEALTH_INSURANCE_CHG_IND = 354;
	public static final short CHILD_SUPPORT_PAYMENT_CHG_IND = 355;
	public static final short SNAP_SHELTER_STANDARD_EXP_IND = 356;
	public static final short HOUS_BILL_CHG_IND = 357;
	public static final short ADD_CHG_IND = 358;
	public static final short PERSON_MOVED_IN_STAT_IND = 359;
	public static final short PERSON_MOVED_OUT_STAT_IND = 360;
	public static final short HOSPICE_CHG_IND = 361;
	public static final short MEDICARE_CHG_IND = 362;
	public static final short NCP_CHG_IND = 363;
	public static final short THIRD_PARTY_CHG_IND = 364;
	public static final short HOSPITAL_ABD_CHG_IND = 365;
	public static final short PUBLIC_LAW_ABD_CHG_IND = 366;
	public static final short LIVING_ARGMT_CHG_IND = 367;
	public static final short OTHER_PROGRAM_CHG_IND = 368;
	public static final short MAGI_EXPENSE_CHG_IND = 369;
	public static final short TAX_INFO_IND = 370;
	public static final short TAX_DEPENDENT_IND = 371;
	public static final short MEDICARE_PART_A = 372;
	public static final short MEDICARE_PART_B = 373;
	public static final short MEDICARE_PART_C = 374;
	public static final short MEDICARE_PART_D = 375;
	public static final short CCSP_PROVIDER_PAYMENT = 376;
	public static final short ANIMALS_TO_ASSIST_DISABLED = 377;
	public static final short FUNERAL_DEATH_EXPENSE = 378;
	public static final short BLIND_WORK_EXPENSE = 379;
	public static final short IMPAIRMENT_WORK_EXPENSE = 380;
	public static final short OTH_IND_GAMBL_PMNTS = 381;
	public static final short BONDS = 382;
	public static final short DIVIDEND = 383;
	public static final short HEALTH_REIMBURSEMENT_ACCOUNT = 384;
	public static final short INDIVIDUAL_DEVELOPMENT_ACCOUNT = 385;
	public static final short UNIFORM_GIFTS_TO_MINORS = 386;
	public static final short INCOME_FROM_RESOURCE = 387;
	public static final short INDIAN_GAMBLING_PAYMENTS = 388;
	public static final short INHERITANCE_INCOME = 389;
	public static final short INSUANCE_BENEFITS = 390;
	public static final short LOAN_RECEIVED = 391;
	public static final short LOAN_REPAYMENT_INCOME = 392;
	public static final short MANAGED_INCOME = 393;
	public static final short MATCH_GRANT = 394;
	public static final short MONTGOMERY_GI_BILL = 395;
	public static final short OUT_OF_STATE_PUBLIC = 396;
	public static final short REFUNDS_FROM_DCH = 397;
	public static final short RESTITUTIONS_SETTLEMENTS = 398;
	public static final short SENIOR_COMPANION = 399;
	public static final short SEVERANCE_PAY = 400;
	public static final short STRIKE_BENEFITS = 401;
	public static final short TRADE_READJUSTMENT = 402;
	public static final short UNIFORM_RELOCATION = 403;
	public static final short UNION_FUNDS = 404;
	public static final short VENDOR_EXCLUDED = 405;
	public static final short VICTIM_RESTITUTION = 406;
	public static final short VOLUNTEER_PAYMENT = 407;
	public static final short VOLUNTEER_PAYMENT_TITLEI = 408;
	public static final short WIA_TRAINING_AND_ALLOWANCE = 409;
	public static final short INCLUDED_UNEARNED_INCOME = 410;
	public static final short TANF_MAX_AU_ALLOTMENT = 411;
	public static final short TANF_MAX_GRG_ALLOTMENT = 412;
	public static final short CHARITABLE_DONATION = 413;
	public static final short CHILD_NUTRITION_PAYMENTS = 414;
	public static final short BLACK_LUNG_BENEFITS = 415;
	public static final short CHILD_SUPPORT_COURT = 416;
	public static final short CHILD_SUPPORT_GAP_PAYMENT = 417;
	public static final short CIVIL_SERVICE = 418;
	public static final short DEFERRED_COMPENSATION_PLANS = 419;
	public static final short DISABILITY_INSURANCE = 420;
	public static final short EXCLUDED_UNEARNED_INCOME = 421;
	public static final short FEMA_PAYMENT_DISASTER = 422;
	public static final short FEMA_PAYMENT_NON_DISASTER = 423;
	public static final short HEALTH_SAVINGS_ACCOUNT = 424;
	public static final short IN_KIND_SUPPORT = 425;
	public static final short FOSTER_GRANDPARENT_PROGRAM = 426;
	public static final short DISASTER_UNEMPLOYMENT = 427;
	public static final short DIVIDENDS = 428;
	public static final short CHARITABLE_DONATION_FEDERAL = 429;
	public static final short PERSONAL_INFO = 430;
	public static final short PATIENT_FUND = 431;
	public static final short DISASTER_ASSISTANCE = 432;
	public static final short NON_BUSINESS_EQUIPMENT = 433;
	public static final short HOUSEHOLD_GOODS = 434;
	public static final short OTHER_NON_COUNTABLE = 435;
	public static final short OUT_ST_BNFT_CHG_IND = 436;
	public static final short SCHL_ENRL_CHG_IND = 437;
	public static final short MRTL_STAT_CHG_IND = 438;
	public static final short LIQ_ASET_CHECKING_ACCOUNT = 439; // LQD_ASET_C_A_RESP
	public static final short LIQ_ASET_KEOUGH_PLAN = 440; // LQD_ASET_K_P_RESP
	public static final short NUR_HME_CHG_IND = 441;
	public static final short BFR_TAX_CHG_IND = 442;
	public static final short INC_TAX_CHG_IND = 443;
	public static final short THRD_PRTY_CHG_IND = 444;
	public static final short DEATH_BENEFIT_STATE_FEDERAL = 445;
	public static final short SOCIAL_SECURITY_SURVIVOR = 446;
	public static final short VENDOR_PAYMENTS = 447;
	public static final short CITIZENSHIP_INFO = 448;
	public static final short INDV_PRGM_CHG_IND = 449;
	public static final short EMPL_HLTH_INS_RESP = 450;
	public static final short AVD_PRSCTN_FSTF = 451;
	public static final short BNFT_CNVCTN = 1000;
	public static final short HEAT_COOL_SRC = 452;
	public static final short KATIE_BECKETT = 453;
	public static final short LIQUID_ASSET_ANNUITY = 97;// liquid_aset_disable_blind_resp
	public static final short LIQUID_ASSET_IRA = 99;// liquid_asset_ira_resp
	public static final short LIQUID_ASSET_IRS_RET = 100; // liquid_asset_irs_retirmnt_resp
	public static final short LIQUID_ASSET_SAVINGS_ACC = 105;// liquid_asset_savings_acc_resp
	public static final short LIQUID_ASSET_PENSION_PLAN = 101;// liquid_asset_pension_plan_resp
	public static final short LIQUID_ASSET_PROMISSORY = 102;// liquid_asset_promissory_resp
	public static final short LIQUID_ASSET_RETIREMENT = 103;// liquid_asset_retirement_resp
	public static final short LIQUID_ASSET_STOCK_BONDS = 104;// liquid_asset_stocks_bonds_resp
	public static final short LIQUID_ASSET_TRUST_FUND = 106;// liquid_asset_trust_fund_resp
	public static final short LIQUID_ASSET_OTHER = 107;// liquid_asset_other_response
	public static final short LIQUID_ASSET_OTHER_TYPE = 108;// liquid_asset_other_type_resp

	public static final short APRV_ACTV_RESP = 145; // APRV_ACTV_RESP
	public static final short BNFT_CRT_O_KC_RESP = 146; // BNFT_CRT_O_KC_RESP
	public static final short BNFT_FC_RESP = 147; // BNFT_FC_RESP
	public static final short BNFT_KC_RESP = 148; // BNFT_KC_RESP
	public static final short BNFT_SG_RESP = 149; // BNFT_SG_RESP
	public static final short INDV_CC_RQST_IND = 150; // INDV_CC_RQST_IND

	public static final short SCHL_ENRL_RESP = 151; // SCHL_ENRL_RESP
	public static final short TRB_CMDY_RESP = 152; // TRB_CMDY_RESP
	public static final short CP_WLST_RESP = 153; // CP_WLST_RESP
	public static final short INDIVIDUAL_CLA = 154; // INDV_CLA_IND

	public static final short NO_RESPONSE = 199; // no response.

	public static final short INDV_DEMO_CHANGE = 200; // no response.
	public static final short PREGNANCY_END = 201; // no response.
	public static final short LIQ_ASET_CHRISTMAS_CLUB = 202;
	public static final short LIQ_ASET_CHILD_SUP_DD = 217;// added last sequence num 217 previous number was 204
															// replaced to use in persit for
															// IRMCResponseProfileManager.persistStatus index sequence
	public static final short LIQ_ASET_EXCESS_OVER_LIFE_GRANT_REFU = 205;
	public static final short LIQ_ASET_SPECIAL_RESOURCE_ACCOUNT = 206;
	public static final short LIQ_ASET_TAX_SHELTER_ACCOUNT = 207;
	public static final short LIQ_ASET_TAX_REFUND = 208;
	public static final short BUR_AST_BURIAL_FUND = 209;
	public static final short BUR_AST_BURIAL_INTEREST = 210;
	public static final short BUR_AST_BURIAL_SPACE = 211;
	public static final short BUR_AST_COUNTABLE_BURIAL_TRUST = 212;
	public static final short LIF_AST_ANNUITY = 213;
	public static final short REAL_ASET_TRADE_WORK = 214;
	public static final short REAL_ASET_MOBILE_HOME_LAND = 215;
	public static final short LIQ_ASET_MONTHLY_EXCESS_OVER_GRANT_REFU = 216;

	public static final short HEAD_OF_HOUSE = 159; // head_of_household_resp

	public static final short SHELTER_COST_DETAILS = 0;
	public static final short UTILITY_COST_DETAILS = 1;
	public static final short OTHER_INCOME_DETAILS = 2;
	public static final short EMPLOYMENT_DETAILS = 3;
	public static final short LIQUID_ASSET_DETAILS = 4;
	public static final short VEHICLE_ASSET_DETAILS = 5;
	public static final short REAL_PROPERTY_ASSET_DETAILS = 6;
	public static final short BURIAL_ASSET_DETAILS = 7;
	public static final short LIFE_INSURANCE_ASSET_DETAILS = 8;
	public static final short OTHER_RESOURCE_ASET_DETAILS = 9;
	public static final short OTHER_BILLS_MEDI_DETAILS = 10;

	public static final short MOVED_INTO_HOME_RESPONSE = 155; // MOVED_INTO_HOME_RESPONSE
	public static final short PAROLE_VIOLATION = 157;// PAROLE_VIOLATION_RESP

	public static final short CURRENT_PAST_PENDING = 162;
	public static final short MEDICAL_SERVICE = 160;
	public static final short EMERGENCY_MEDICAL = 161;
	public static final short STUDENT_FINANCIAL_AID = 163; // Student_financial_aid_resp
	public static final short BLACK_LUNG_BENEFIT = 164;
	public static final short CASH_GIFTS_CONT = 165;
	public static final short FOOD_CLOTHING_UTIL_RENT = 166;
	public static final short INHERITANCE = 167;
	public static final short INSURANCE_SETTLEMENT = 168;
	public static final short LOAN = 169;
	public static final short LOTTERY_PRIZE_WINNING = 170;

	public static final short STRIKE_BENEFITS_RESP = 173;

	public static final short TRAINING_ALLOWANCE = 171;
	public static final short OTHR_SOCIAL_SECURITY_BENEFITS = 172;
	public static final short RESETTL_INC_RESP = 174;
	public static final short OTHR_INCM_RENTL_RESP = 175;
	public static final short LAND_CONT_RESP = 176;

	public static final short HOUSING_BILLS_OTHERS = 177;
	public static final short UTILITY_BILLS_OIL = 178;

	public static final String CP_APP_ESGIN_COLLECTION_VALUE = "CP_APP_ESGIN_Collection";
	public static final String APP_INDV_COLLECTION_VALUE = "APP_INDV_Collection";

	public static final String PAGE_ID_ABHMS = "ABHMS";
	public static final String RELATIONSHIPCOLLECTION = "RelationCollection";

	public static final int MAX_CHILD_AGE = 18;

	public static final String UI_APP_NUM = "appNum";

	public static final String NO_ONE = "No One";

	public static final String APP_IND_AFB = "AB";

	public static final String ABCCE = "ABCCE";

	public static final String ABMIS = "ABMIS";
	public static final String MCINR = "MCINR";
	public static final String MCINS = "MCINS";

	public static String APP_HSHL_RLT_CareTaker_Collection = "APP_HSHL_RLT_CareTaker_Collection";

	public static final String STORE_CONTACT_DETAILS_AFB = "storeContactDetailsAFB";

	public static final String STORE_PENALTY_FRAUD_INFO = "storePenaltyFraudInformation";

	public static final Object CP_APP_HSHL_RLT_COLLECTION = "CP_APP_HSHL_RLT_Collection";
	
	public static final Object CpRmbLtcDtlsCollection = "CpRmbLtcDtls_Collection";
	
	public static final String CP_RMBLTCDTLSCOLL = "CpRmbLtcDtls_Collection";
	
	public static final Object APP_ABS_PRNT_COLLECTION = "APP_ABS_PRNT_Collection";

	public static final String SERVICE_SAVE_ENDPOINT_MARITAL_STATUS = "ABMRS";
	public static final String CP_APP_IN_CARE_PROV_COLL = "CP_APP_IN_CARE_PROV_Collection";
	public static final String APP_IN_DABL_COLL = "APP_IN_DABL_Collection";

	public static final String GET_DISABILITY_SUMMARY = "getDisabilitySummary";

	public static final String STORE_DISABILITY_SUMMARY = "storeDisabilitySummary";

	public static final String CP_APP_RGST_COLLECTION = "CP_APP_RGST_Collection";

	public static final String GET_PRFL_DATA = "getPrflData";

	public static final Object APP_ABS_PRNT_COLL = "APP_ABS_PRNT_Collection";

	public static final String REMOVE_LEAVE_CA_DET = "removeLeavingCADetails";

	public static final String REMOVE_DIS_SUM = "removeDisabilitySummary";

	public static final String GET_AFB_INDV_DET = "getAFBIndividualDetails";

	public static final String STORE_CHILD_CAREDET = "storeChildCareDetails";

	// Start: CSPM-6364
	public static final String BUSINESS_METHOD_AFB_LOAD_MILITARY_INFO_SUMMARY = "loadMilitaryInfoSummary";
	public static final String BUSINESS_METHOD_AFB_SAVE_MILITARY_INFO = "saveMilitaryInfo";
	public static final String BUSINESS_METHOD_AFB_REMOVE_MILITARY_INFO = "removeMilitaryInfo";
	// End: CSPM-6364

	public static final Object CP_APP_PGM_INDV_Collection = "CP_APP_PGM_INDV_Collection";
	public static final String CP_APP_INDV_ADD_INFO_COLLECTION = "CP_APP_INDV_ADD_INFO_Collection";
	public static final String SAVE_ESIGN_INFO = "saveEsignInfo";

	public static final String STORE_SIGN_YOUR_APPL = "storeSigningYourApplication";

	public static final String STORE_DUPLICATE_PROG_PER_SEL_DET = "storeDuplicateProgramPersonSelectionDetails";

	public static final String STORE_TRADE_FOR_GUN_SEL_DET = "storeTradedForGunsPersonSelectionDetails";

	public static final String STORE_SIGN_APPL_1 = "storeSigningYourApplication1";

	public static final String APP_IN_OUT_ST_BNFT_COLL = "APP_IN_OUT_ST_BNFT_Collection";

	public static final String GET_OUT_OF_STATE = "getOutOfState";

	public static final String STORE_OUT_OF_STATE = "storeOutOfState";

	public static final String DEL_GOV_AID = "deleteGovernmentAid";

	public static final String STORE_HH_PREG_DET = "storeHouseHoldPregnancyDetails";

	public static final String GET_HH_PREG_DET = "getHouseHoldPregnancyDetails";

	public static final String DELETEPREGNANTDETAILS = "deletePregnantDetails";

	public static final String LOADBREASTFEEDINGSUMMARYDETAILS = "loadBreastFeedingSummaryDetails";

	public static final String DELETEBREASTFEEDINGDETAILS = "deleteBreastFeedingDetails";

	public static final String STORETAXINFORMATION = "storeTaxInformation";

	public static final String LOADTAXSUMMARYINFORMATION = "LoadTaxSummaryInformation";
	
	public static final String LOADTAXRETURNSUMMARY = "loadTaxReturnSummary"; 

	public static final String DELETETAXINFORMATION = "deleteTaxInformation";

	public static final String LOADTAXDEPENDENTSINFORMATION = "loadTaxDependentsInformation";

	public static final String CP_APP_IN_PREG_COLLECTION = "CP_APP_IN_PREG_Collection";
	public static final String APP_IN_SCHLE_COLLECTION = "APP_IN_SCHLE_Collection";
	public static final String STORED_APP_IN_SCHLE_COLLECTION = "STORED_APP_IN_SCHLE_Collection";

	public static final String CP_APP_IN_TAX_RETURN_COLLECTION = "CP_APP_IN_TAX_RETURN_Collection";
	public static final String APP_IN_TAX_RETURNS_COLLECTION = "APP_IN_TAX_RETURNS_Collection";
	public static final String CP_APP_IN_TAX_DEPENDENTS_COLLECTION = "CP_APP_IN_TAX_DEPENDENTS_Collection";

	public static final String STORESCHOOLENROLLMENT = "storeSchoolEnrollment";
	public static final String GETTEENPARENTDETAILS = "getTeenParentDetails";
	public static final String DELETESCHOOLENROLLMENT = "deleteSchoolEnrollment";
    public static final String DELETEGOVERNMENTAID = "deleteGovernmentAid";
	public static final String STOREHOUSEHOLDPREGNANCYDETAILS = "storeHouseHoldPregnancyDetails";
	public static final String GETHOUSEHOLDPREGNANCYDETAILS = "getHouseHoldPregnancyDetails";
	public static final String DELETEPREGNANTDETAIL = "deletePregnantDetails";
	
	public static final String ABCLI = "ABCLI";
	public static final String ABTSS = "ABTSS";
	public static final String ABCSU = "ABCSU";

	public static final String RCCLD = "RCCLD";
	
    /** The Constants for MSGs. */


	/** The Constants for MSGs. */
	public static final String MSG_00210 = "00210";
	public static final String MSG_00208 = "00208";
	public static final String MSG_80670 = "80670";
	public static final String MSG_00211 = "00211";

	public static final String NE = "NE";
	public static final String PE = "PE";
	public static final String EM = "EM";
	public static final String MS = "MS";
	public static final String HS = "HS";
	public static final String SPACES = "";
	public static final String ZERO_5 = "00000";
	public static final String ZERO_9 = "000000000";

	public static final String PERSIST_INTERVIEW_PREF = "persistInterviewPref";

	public static final String GETOFFICESELECTION = "getOfficeSelection";

	public static final String STOREOFFICESELECTION = "storeOfficeSelection";





	public static final String LOAD_SUMMARY_TEMPLATE = "loadSummaryTemplate";

	// Start: CSPM-8449
	public static final String LOAD_TNB4_SPECIFIC_DATES_AND_CASENUM = "loadTNB4SpecificDatesAndCaseNum";
	public static final String GENERATE_APPLICATION_DATA_FOR_TNB4 = "generateApplicationDataForTNB4";
	public static final String SAVE_TNB4_RENEWAL_FORM_DATA = "saveTNB4RenewalFormData";
	public static final String TNBWB = "TNBWB";
	public static final String TNCIC = "TNCIC";
	public static final String CP_APP_TNB4_REDET_COLLECTION = "CpAppTnb4Redet_Collection";
	public static final String TNB4_TN = "TN";
	public static final String AFB_AB = "AB";
	public static final String MOVE_OUT = "MO";
	public static final String SSI_SSP = "SI";
	public static final String APP_NUM = "APP_NUM";
	public static final String ZERO_STRING = "0";
	public static final String RMB_RQST_COLLECTION = "RMB_RQST_Collection";
	public static final String CP_RMB_REQUEST_DETAILS_COLLECTION = "CpRmbRequestDetails_Collection";
	public static final String CASE_INDIVIDUALS = "CaseIndividuals";
	public static final String TRUE = "true";
	public static final String CASE_NUM = "case_num";
	public static final String CASE_NAME = "caseName";
	public static final String COUNTY_CODE = "countyCode";
	public static final String TNB_DUE_DATE = "tnb_due_date";
	public static final String TNB_LAST_CERTIFICATION_DATE = "tnb_last_certification_date";
	public static final String ONE_SPACE = " ";
	public static final String TNB4_FORM_DATA = "TNB4FormData";
	public static final String FORM = "form";
	public static final String FORM_REPORT_TYPE = "formReportType";
	public static final String MAILING_ADDRESS = "MailingAddress";
	public static final String MAILBACK_ADDRESS_OFFICE = "MailbackAddressOffice";
	// End: CSPM-8449

	public static final String HOUSEHOLD_INDIVIDUAL_INFO = "getHouseholdIndividualInfo";
	public static final String HOUSEHOLD_CONFIRMATION_INFO = "getConfirmationInfo";
	public static final String DISABILITY_TYPE_DOCUMENTS_REQUIRED = "DI";
	public static final String IDENTITY_TYPE_DOCUMENTS_REQUIRED = "BC";
	public static final String SCHOOL_VERIFICATION_DOCUMENTS_REQUIRED = "SV";
	public static final String SSN_DOCUMENTS_REQUIRED = "SC";
	public static final String HOUSEHOLD_MODULE = "HOUSEHOLD_MODULE";
	public static final String IMMUNIZATIONINFORMATION = "IM";
	public static final int IMMUNIZATIONAGELIMIT = 6;
	public static final int CHILDCAREAGELIMIT = 18;
	// Start CSPM-8470
	public static final String LINE_SEPARATOR = "\n";
	public static final String TEXT = "Text";
	public static final String EMAIL = "Email";
	public static final String TN_EMAIL_BODY = "This is a receipt that confirms your TNB4 Redetermination:";
	public static final String TN_EMAIL_SUBJECT = "BenefitsCal: Receipt of TNB4 Redetermination";
	public static final String TN_TEXT_BODY = "Receipt of TNB4 Redetermination:";
	public static final String ABTMR = "ABTMR";
	public static final String ABEMR = "ABEMR";
	// End CSPM-8470

	public static final String SAWS2PLUS = "SAWS2PLUS";
	public static final String APPTRANSFER = "APPTRANSFER";
	public static final String REPORTACHANGE="REPORTACHANGE";
	public static final String ONGOING_APPLICATION = "OngoingApplications";
	public static final String CHANGE_RENEWAL_APPLICATIONS = "ChangeRenewalApplications";
	public static final String SEND_EMAIL_TEXT_TO_API = "sendEmailTextToAPI";
	public static final String STORE_PROGRAM_SELECTION_MEMBER = "storeProgramSelectionMember";
	public static final String IN_HOME = "IH";
//	BCUAT-838
	public static final String ANAID_PAGE = "storeANAIDPage";



	
	public static final String LOAD_REDET_CALWORKS_DATA = "loadRedetCalWorksSpecificData";
	public static final String REDET_CW_DATA = "REDET_CW_DATA";
	public static final String CW_REDET_MODE = "CWF";
	public static final String CALWORKS_REDET = "CW";
	public static final String MILLISECONDS = " milliseconds";
	
	public static final String LOAD_SIGNING_INFO = "loadSigningYourApplication";

	public static final String CW_EMAIL_BODY = "This is a receipt that confirms your CalWORKs Redetermination:";
	public static final String CW_EMAIL_SUBJECT = "BenefitsCal: Receipt of CalWORKs Redetermination";
	public static final String CW_TEXT_BODY = "Receipt of CalWORKs Redetermination:"; 
	
	public static final String RMC_RQST_COLLECTION = "RMC_RQST_COLLECTION";
	public static final String GENERATE_APPLICATION_DATA_FOR_RMC = "generateApplicationDataForRMC";
	public static final String RMC = "RMC";
	
	//CSPM-11321
	public static final String CREATE_QUEUE_TO_PUSH_MESSAGE_RDCW = "pushMessageForRedetCWToInvokeSAWS2PLUS";
	
	public static final String RMC_SRC_APP_IND = "RC";
	public static final String FETCH_MOVEDOUT_INDV_DETAILS= "fetchMovedOutIndvDetails";
	public static final String STORE_MOVEDOUT_INDV_DETAILS= "storeMovedOutIndvDetails";
	public static final String REMOVE_MOVEDOUT_INDV_DETAILS= "removeMovedOutIndvDetails";
	//Start CSPM-11474
	public static final String RMC_SAVE_PASSED_AWAY_INFO = "rmcSavePassedAwayInfo";
	public static final String RMC_LOAD_PASSED_AWAY_INFO = "rmcLoadPassedAwayInfo";
	public static final String RMC_REMOVE_PASSED_AWAY_INFO = "rmcRemovePassedAwayInfo";
	//End CSPM-11474
	
	//Start CSPM-11444
	public static final String FETCH_BABY_INFO_DETAILS= "loadNewBornIndvDetails";
	public static final String STORE_BABY_INFO_DETAILS= "storeBabyInfoDetails";
	public static final String REMOVE_BABY_INFO_DETAILS= "removeBabyInfoDetails";
	//End CSPM-11444
		
	public static final String MODE = "mode";
	public static final String PERIODIC_REPORTING = "S7";
	public static final String CP_RMB_REQUEST_ID = "cp_rmb_request_id";
	public static final String PROGRAM_LIST = "programList";
	public static final String CALWORKS_PR = "CW";
	public static final String CALFRESH_PR = "CF";
	public static final String CALFRESH_F37 = "CF";

	public static final String STORESTOPBENEFITSPROGRAMINFO = "storeStopBenefitsProgramInfo";

	//CSPM-12779
		public static final String GET_APP_HISTORY = "getAppHistory";
//Start CSPM-11548
public static final String RCHAB = "RCHAB";
public static final String RCHAS = "RCHAS";
public static final String RCMAB = "RCMAB";
public static final String RCMAS = "RCMAS";
public static final String RCHAM = "RCHAM";
public static final String RMC_SAVE_HOME_OR_MAILING_ADDR_INFO = "rmcSaveHomeOrMailingAddrInfo";
public static final String RMC_CLEAR_HOME_OR_MAILING_ADDR_INFO = "rmcClearHomeOrMailingAddrInfo";
public static final String RMC_LOAD_HOME_OR_MAILING_ADDR_INFO =  "rmcLoadMailingOrHomeAddrInfo";
//End CSPM-11548		

	
	//CSPM-11601
	public static final String REMOVE_CONTACT_INFO = "removeContactInfoSummary";
	public static final String GET_CONTACT_INFO = "getContactInformationActiveIndv";
	public static final String SRC_APP_IND = "SRC_APP_IND";

	public static final String RMC_MRTL_DELETE = "deleteMrtlDetails";
	public static final String RMC_MRTL_LOAD = "getMaritalStatusDetail";
	
	public static final String SERVICE_SAVE_RC_ENDPOINT_MARITAL_STATUS = "RCMSD";
	
	//STRAT-CSPM-12263
	public static final String HOUSEHOLD_DETAILS_DCF = "storeHouseholdDetails";
	public static final String LOAD_HOUSEHOLD_DETAILS_DCF ="loadDCFHouseholdDetails";
	public static final String GET_DISASTER_SUMMARY ="getDisasterSummary";
	//END-CSPM-12263
	
	//Start CSPM-11578
	public static final String RMC_SAVE_PERSONAL_INFO = "rmcSavePersonalChangeInfo";
	public static final String RMC_CLEAR_PERSONAL_INFO = "rmcRemovePersonalChangeInfo";
	public static final String RMC_LOAD_PERSONAL_INFO =  "rmcLoadPersonalChangeInfo";
	//EndCSPM-11578
	
	//CSPM-14042
	public static final String STORE_OTHER_SITUATIONS = "storeOtherSituations";
	//CSPM-12418
	public static final String CP_HSHL_DETAILS_DISASTER_COLLECTION = "CP_HSHL_DETAILS_DISASTER_Collection";
	public static final String CP_APP_AUTH_REP_COLLECTION = "CP_APP_AUTH_REP_Collection";
	public static final String CP_APP_PGM_RQST_COLLECTION = "CP_APP_PGM_RQST_Collection";
	public static final String APP_SBMS_COLLECTION = "APP_SBMS_Collection";
	public static final String UPDATE_CF37MAILING_ADDRESS = "updateCF37MailingAddress";
	public static final String UPDATE_CF37_CONTACT_INFO = "updateContactInformationCF37";
	
	//CSPM-14645
	public static final String LOAD_MC_SPECIFIC_DATES_AND_CASENUM ="loadMCSpecificDatesAndCaseNum";
	public static final String GENERATE_APPLICATION_DATA_FOR_MC ="generateApplicationDataForMC";
	public static final String MC_MODE = "MR";
	public static final String REDETMC_MC = "MR";
	public static final String AFB_MODE = "AFB";
	public static final String DCF_MODE = "DCF";
	
	//CSPM-14418
	public static final String STORE_INDV_MEDICAL_INFO_DETAILS = "storeIndvMedicalInfoDetails";
	public static final String APP_IN_NEWB_COLLECTION="APP_IN_NEWB_Collection";
	public static final String GETCF37HOUSEHOLDDETAILS="getCF37HouseHoldDetails";
	public static final String OTHER_HOUSEHOLD_DETAILS_COLLECTION ="OTHER_HOUSEHOLD_DETAILS_Collection";
	public static final String CP_APP_HSHL_RLT_COLLECTIONS = "CP_APP_HSHL_RLT_Collection";
	public static final String CFHHS = "CFHHS";	
	//PR PEOPLE SUMMARY SERVICE
		public static final String GETPRPEOPLESUMMARYDETAILS="getPRPeopleSummaryDetails";
	//CSPM-12418
	public static final String DISASTERAPPTRANSFER = "DISASTERAPPTRANSFER";
	public static final String FORM_TYPE = "formType";

	//Start CSPM-11654
	public static final String RMC_SAVE_HOMELESS_INFO = "rmcSaveHomelessAddrInfo";
	public static final String RMC_CLEAR_HOMELESS_INFO = "rmcClearHomelessAddrInfo";
	public static final String RMC_LOAD_HOMELESS_INFO =  "rmcLoadHomelessAddrInfo";
	public static final String CF37FORMTYPE = "CF";
	//EndCSPM-11654
	public static final String PRHHS = "PRHHS";	
	public static final String GETPRHOUSEHOLDDETAILS="getPRHouseHoldDetails";
	public static final String PRFORMTYPE = "S7";
	
	//Start CSPM-12026
	public static final String RMC_SAVE_OTHER_PERSONAL_INFO = "rmcSaveOtherPersonalInfo";
	public static final String RMC_CLEAR_OTHER_PERSONAL_INFO = "rmcClearOtherPersonalInfo";
	public static final String RMC_LOAD_OTHER_PERSONAL_INFO =  "rmcLoadOtherPersonalInfo";
	//End CSPM-12026
	public static final String OTHER_PERSONAL_CHANGE_COLL = "OTHER_PERSONAL_CHANGE_COLL";
	
	public static final String APP_INCARCERATED_COLL = "APP_INCARCERATED_Collection";
	
	public static final String LOAD_INCARCERATED_INFO = "loadIncarceratedInfo";
	public static final String SAVE_INCARCERATED_INTO = "saveIncarceratedInfo";
	public static final String DELETE_INCARCERATED_INFO = "removeIncarceratedInfo";
	
	public static final String SAVE_DECEASED_INFO = "saveDeceasedInfo";
	
	public static final String STORE_IMMIGRATION_INFO = "storeImmigrationInfo";
	public static final String LOAD_IMMIGRATION_INFO = "loadImmigrationInfo";
	public static final String REMOVE_IMMIGRATION_INFO = "removeImmigrationInfo";
	
	/*
	 * changes as per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
	 */
	public static final String RELATIONSHIP = "relationship";
	public static final String CP_APP_HSHL_RLT_COLL = "CP_APP_HSHL_RLT_Collection";
	public static final String GENERATE_FORM_STATUS_REQ = "generateFormStatusReq";
	public static final String LOAD_LTC_DETAILS_REQ = "loadLTCDetails";
	public static final String SAVE_LTC_DETAILS_REQ = "saveLTCDetails";
	public static final String REMOVE_LTC_DETAILS_REQ = "removeLTCDetails";
	
	public static final String MARITAL_COLLECTION = "Marital_Collection";
	public static final String MOVED_OUT_COLLECTION = "moved_Out_Collection";
	public static final String HOMELESS_COLLECTION = "HOMELESS_Collection";
	public static final String GETSUMMARYDATA = "getSummaryData";
	public static final String APP_INDV_NEW_BORN_COLLECTION = "APP_INDV_NEW_BORN_Collection";
	public static final String CP_APP_OTHER_SITUATIONS_COLLECTION = "CP_APP_OTHER_SITUATIONS_Collection";
	public static final String UPDATE_HHINDV_AND_RELATION_DETAILS = "updateHHIndvAndRelationDetails";
	public static final String ADD_NEW_INDV= "addNewIndvAndRelationDetails";
	public static final String FORM_DUE_DT = "form_due_dt";
	public static final String FORM_TYPE_RAC = "RAC";
	public static final String STORE_FULL_TIME_STUDENT = "storeFullTimeStudent";
	public static final String TAX_SINGLE_IND = "SN";
	public static final String NON_TAX_FILER_IND = "NT";
	public static final String TAX_MARRIED_FILING_SEPERATELY_IND = "MS";
	public static final String TAX_MARRIED_FILING_JOINTLY_IND = "MJ";
	public static final String TAX_HEAD_OF_HOUSEHOLD_IND = "HH";
	public static final String CLAIMED_AS_OF_DEPENDENT_IND = "CD";

	public static final String DATE_OF_RELEASE = "dateOfRelease";
	public static final String MCEMS = "MCEMS";
	public static final String MCOSS = "MCOSS";
	public static final String MCDCI = "MCDCI";
	public static final String GET_MEDICAL_OR_MEDICARE_INFO = "getMedicalOrMeicareInfo";
	public static final String REMOVE_MEDICAL_OR_MEDICARE_INFO = "removeMedicalOrMeicareInfo"; 
	public static final String STORE_MEDICAL_OR_MEDICARE_INFO = "storeMedicalOrMeicareInfo"; 
	public static final String PERSIST_ADDRESS_CHANGED =  "persistAddressChangedInd";
	public static final String CASE_INDIVIDUALS_LIST = "CaseIndividuals";
	public static final String PAGEID_MCIFS = "MCIFS";
	public static final String PAGEID_MCIFI = "MCIFI";
	public static final String CALFRESH_PR_CF37 = "FS";
	public static final String MEDICAL_PR = "MA";

	public static final String STORE_ORGAN_TRANSPLANT_INDICATOR = "storeOrganTransplantIndicator";
    public static final String STORE_KIDNEY_DIALYSIS_INDICATOR = "storeKidneyDialysisIndicator";
    public static final String STORE_IN_KIND_SUPPORT_INDICATOR = "storeInKindSupportIndicator";
    public static final String STORE_INCOME_FLUCTUATION_INDICATOR =  "storeIncomeFluctuationInd";

	public static final String PREFERCONTACTLIST = "preferContactList";
	public static final String FINANCIAL_LAMBDA_FUNCTION = "FINANCIAL_FUNC";
	public static final String LAMBDAINVOKE_URL_PATTERN = "/%s/%s/%s";
	public static final String FINANCIAL_LAMDA_URL_PREFIX = "financialinfo";
	public static final String RMCFS = "RMCFS";
	public static final String RMCFSLOAD = "RMCFSLoad";
	public static final String RCRAS = "RCRAS";
	public static final String RCRASLOAD = "RCRASLoad";
	public static final String APPSUMMARY_LAMBDA_FUNCTION = "APPSUMMARY_LAMBDA_FUNCTION";
	public static final String APPSUMMARY_LAMDA_URL_PREFIX = "appsummary";
	public static final String CFFORMTYPE = "CF37";
	public static final String SAR7FORMTYPE = "SAR7";
	public static final String APPSUMMARY_LAMDA_URL_PROCESS_UPLOAD = "processupload";
	public static final String LAMBDAINVOKE_APPSUM_URL_PATTERN = "/%s/%s";
	public static final String MCLTC = "MCLTC";
	public static final String MCOQH = "MCOQH";
    public static final String RMCEM = "RMCEM";
    public static final String UPDATE_MEDICAL_OR_MEDICARE_INFO = "updateMedicalOrMeicareInfo";
    public static final String LOADINCARCERATEDDETAILS = "loadIncarceratedDetails";
    public static final String UPDATE_DT_FOR_APP = "updateUpdateDateForApp";
    public static final String RMC_SAVE_MARITAL_STATUS = "rmcSaveMaritalStatus";
// CSPM-30573
    public static final String APDEL_PAGE = "deleteAPDELPage";
    
    public static final String OFFICE_NUM = "OfficeNumber";
    public static final String TELE_TYPE_NUM = "teleTypeNumber";
    
    public static final String GET_APP_SUMMARY = "getApplicationSummaryData";
    public static final String PERSONDETAILS_PAGE_ID = "ABPSD";
    public static final String HOUSEHOLD_SUMMARY_PAGE_ID = "ABRGS";
	
	public static final String DELETE_WHEN_HOMELESS = "deleteWhenHomeless";
	public static final String STORETAXPRIMARY = "storeTaxprimary";
	
	public static final String AS_CASE_ID ="caseId";
	public static final String AS_CASE_NAME ="caseName";
	public static final String AS_GUID = "guid";
	public static final String AS_COUNTY_CODE = "case_county_cd";

	public static final String OTHER_TYPE_DOCUMENTS_REQUIRED = "OT";

	public static final String APPDETAILS_APPNUM = "getAppStatusByAppNum";
	public static final String RCCCS = "RCCCS";
	
	public static final String SMS_NOTIFICATION_DATA="SMSNotificationData";
	public static final String RECV_FLOW_TEXT="RECV_FLOW_TEXT";
	public static final String TEXT_FLOW_TYPE="TEXT_FLOW_TYPE";
	public static final String RECV_FLOW_COM_TEXT="RECV_FLOW_COM_TEXT";
	public static final String TEXT_PHONE_NUM="TEXT_PHONE_NUM";
	public static final String TEXT_HOURS="TEXT_HOURS";
	public static final String TEXT_HOURS_VALUE="TEXT_HOURS_VALUE";
	public static final String TEXT_DATE="TEXT_DATE";
	public static final String SEND_NEXT_DAY="SEND_NEXT_DAY";
	public static final String OPEN_STATUS="OP";
	public static final String APPLICATION_NUM="APPLICATION_NUM";
	
	public static final String GET_SURVEYS = "getSurveys";
	public static final String STORE_SURVEYS = "storeSurveys";
	public static final String CP_USER_SURVEYS_COLLECTION = "CpUserSurveys_Collection";
	public static final String ABSNC = "ABSNC";

}
