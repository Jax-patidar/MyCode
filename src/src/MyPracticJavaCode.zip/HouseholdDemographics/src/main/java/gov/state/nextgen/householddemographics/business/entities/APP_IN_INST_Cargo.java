package gov.state.nextgen.householddemographics.business.entities;


import java.io.Serializable;

import java.sql.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;



public class APP_IN_INST_Cargo extends AbstractCargo implements Serializable{

	private static final long serialVersionUID = -2215149369001801657L;
	
	@Id
	private String app_num;
	
	@Id
	private Integer indv_seq_num;
	
	@Id
	private String src_app_ind;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date cur_inst_dt;
	
	private Integer inst_cnty_cd;
	private String inst_nam;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date orig_inst_dt;
	
	private String rec_cplt_ind;
	// EDSP Starts - Getting Started New Fields
	private String before_moving_spcl_arrgment_cd;
	private String institution_county_city_name;
	private String placed_by_gov_agency_ind;
	
	
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public Date getCur_inst_dt() {
		return cur_inst_dt;
	}
	public void setCur_inst_dt(Date cur_inst_dt) {
		this.cur_inst_dt = cur_inst_dt;
	}
	public Integer getInst_cnty_cd() {
		return inst_cnty_cd;
	}
	public void setInst_cnty_cd(Integer inst_cnty_cd) {
		this.inst_cnty_cd = inst_cnty_cd;
	}
	public String getInst_nam() {
		return inst_nam;
	}
	public void setInst_nam(String inst_nam) {
		this.inst_nam = inst_nam;
	}
	public Date getOrig_inst_dt() {
		return orig_inst_dt;
	}
	public void setOrig_inst_dt(Date orig_inst_dt) {
		this.orig_inst_dt = orig_inst_dt;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getBefore_moving_spcl_arrgment_cd() {
		return before_moving_spcl_arrgment_cd;
	}
	public void setBefore_moving_spcl_arrgment_cd(String before_moving_spcl_arrgment_cd) {
		this.before_moving_spcl_arrgment_cd = before_moving_spcl_arrgment_cd;
	}
	public String getInstitution_county_city_name() {
		return institution_county_city_name;
	}
	public void setInstitution_county_city_name(String institution_county_city_name) {
		this.institution_county_city_name = institution_county_city_name;
	}
	public String getPlaced_by_gov_agency_ind() {
		return placed_by_gov_agency_ind;
	}
	public void setPlaced_by_gov_agency_ind(String placed_by_gov_agency_ind) {
		this.placed_by_gov_agency_ind = placed_by_gov_agency_ind;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	
	
	@Override
	public String toString() {
		return "APP_IN_INST_Cargo [app_num=" + app_num + ", indv_seq_num=" + indv_seq_num + ", cur_inst_dt="
				+ cur_inst_dt + ", inst_cnty_cd=" + inst_cnty_cd + ", inst_nam=" + inst_nam + ", orig_inst_dt="
				+ orig_inst_dt + ", rec_cplt_ind=" + rec_cplt_ind + ", before_moving_spcl_arrgment_cd="
				+ before_moving_spcl_arrgment_cd + ", institution_county_city_name=" + institution_county_city_name
				+ ", placed_by_gov_agency_ind=" + placed_by_gov_agency_ind + ", src_app_ind=" + src_app_ind + "]";
	}
	
	
	

	
}
