package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABASD")
@Scope("prototype")
public class ApplicationSubmissionDividerView implements LogicResponseInterface{

	private static final String PAGE_ID = "ABASD";
	
	private static final String APP_RQST_COLL = "APP_RQST_Collection";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTrxn.getPageCollection();

		
		List<APP_RQST_Cargo> reqtCargo = new ArrayList<APP_RQST_Cargo>();
		APP_RQST_Cargo cpAppInCargo;
		
		APP_RQST_Collection cpAppRqstColl = pageCollection.get(APP_RQST_COLL) != null ? (APP_RQST_Collection) pageCollection.get(APP_RQST_COLL) : null;
		
		if(cpAppRqstColl != null && !cpAppRqstColl.isEmpty() && cpAppRqstColl.size() >0) {			
			for (int i = 0; i < cpAppRqstColl.size(); i++) {
				cpAppInCargo = (APP_RQST_Cargo) cpAppRqstColl.getCargo(i);
				reqtCargo.add(cpAppInCargo);
			}
		}
		byte[] byteArr = (byte[]) pageCollection.get("byteArr");
		if(null != byteArr && byteArr.length > 0) {
			List<Object> bytelist = new ArrayList<>();
			bytelist.add(byteArr);
		driverPageResponse.getPageCollection().put("appSummaryByteArray", bytelist);
		}
		driverPageResponse.getPageCollection().put(APP_RQST_COLL, reqtCargo);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		return driverPageResponse;

	}
}
