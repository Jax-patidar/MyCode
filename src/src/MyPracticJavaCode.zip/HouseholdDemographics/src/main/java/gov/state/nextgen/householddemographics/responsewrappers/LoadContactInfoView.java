package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

/**
 * View Wrapper for passing the response object.
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @author prabhasingh
 */


@Component("ABCOP")
@Scope("prototype")
public class LoadContactInfoView implements LogicResponseInterface{
	
	private static final String PAGE_ID = "ABCOP";
	
	private static final String CP_APP_RGST_COLL = "CP_APP_RGST_Collection";
	
	private static final String APP_INDV_COLL = "APP_INDV_Collection";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();

		Map pageCollection = fwTrxn.getPageCollection();
		List<CP_APP_RGST_Cargo> contactList = new ArrayList<CP_APP_RGST_Cargo>();
		CP_APP_RGST_Cargo contactCargo = new CP_APP_RGST_Cargo();
		
		List<APP_INDV_Cargo> indvList = new ArrayList<APP_INDV_Cargo>();
		APP_INDV_Cargo indvCargo = new APP_INDV_Cargo();
		
		CP_APP_RGST_Collection contactCollection = pageCollection.get(CP_APP_RGST_COLL) != null ? (CP_APP_RGST_Collection)pageCollection.get(CP_APP_RGST_COLL) : null;
		APP_INDV_Collection indvCollection = pageCollection.get(APP_INDV_COLL) != null ? (APP_INDV_Collection)pageCollection.get(APP_INDV_COLL) : null;

		if(contactCollection != null) {
			contactCargo = (CP_APP_RGST_Cargo) contactCollection.get(0);
		}
		contactList.add(contactCargo);
		driverPageResponse.getPageCollection().put(CP_APP_RGST_COLL, contactList);
		
		if(indvCollection != null) {
			indvCargo = (APP_INDV_Cargo) indvCollection.get(0);
		}
		indvList.add(indvCargo);
		driverPageResponse.getPageCollection().put(APP_INDV_COLL, indvList);

		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

		return driverPageResponse;
	}

}
