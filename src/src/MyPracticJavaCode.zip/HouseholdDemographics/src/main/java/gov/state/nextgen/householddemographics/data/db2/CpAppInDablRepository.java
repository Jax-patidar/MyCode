/**
 * 
 */
package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Key;

/**
 * @author shtony
 *
 */
@Repository
public interface CpAppInDablRepository extends CrudRepository<APP_IN_DABL_Cargo, APP_IN_DABL_Key> {
	
	@Query("select c from APP_IN_DABL_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2 and c.seq_num = ?3")
	public APP_IN_DABL_Collection getDisabilityDtl(Integer appnum, Integer indvseqnum, Integer seqnum);

	@Query("select max(c.seq_num) from APP_IN_DABL_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public Integer getMxDisabilitySeqNumber(Integer appNumber, Integer indvSeqNumber);

	
	@Query("select c from APP_IN_DABL_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	APP_IN_DABL_Collection loadDisabilityDtls(Integer appNum, Integer indvSeqNum);
	
	@Query("select c from APP_IN_DABL_Cargo c where c.app_number = ?1 and c.indv_seq_num IN ?2")
	public APP_IN_DABL_Cargo[] getAllDetails(Integer appNum, List<Integer> indvIds);
	
	@Query("select c from APP_IN_DABL_Cargo c where c.app_number = ?1 and c.indv_seq_num IN ?2")
	public APP_IN_DABL_Cargo[] loadDisability(Integer appNum, List<Integer> indvIds);
	
	@Query("select c from APP_IN_DABL_Cargo c where c.app_number = ?1")
	public APP_IN_DABL_Collection loadDisabilityDetailsByAppNum(Integer appNum);
	
}
