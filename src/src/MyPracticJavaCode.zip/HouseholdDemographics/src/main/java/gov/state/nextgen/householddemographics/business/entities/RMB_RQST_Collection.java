package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class RMB_RQST_Collection extends AbstractCollection{


	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.RMB_RQST";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final RMB_RQST_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final RMB_RQST_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final RMB_RQST_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public RMB_RQST_Cargo[] getResults() {
		final RMB_RQST_Cargo[] cbArray = new RMB_RQST_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public RMB_RQST_Cargo getCargo(final int idx) {
		return (RMB_RQST_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public RMB_RQST_Cargo[] cloneResults() {
		final RMB_RQST_Cargo[] rescargo = new RMB_RQST_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final RMB_RQST_Cargo cargo = getCargo(i);
			rescargo[i] = new RMB_RQST_Cargo();
			rescargo[i].setCp_rmb_request_id(cargo.getCp_rmb_request_id());
			rescargo[i].setSsp_app_num(cargo.getSsp_app_num());
			rescargo[i].setAdr_chg_stat_ind(cargo.getAdr_chg_stat_ind());
			rescargo[i].setApp_typ(cargo.getApp_typ());
			rescargo[i].setAset_xfer_stat_ind(cargo.getAset_xfer_stat_ind());
			rescargo[i].setBury_aset_add_ind(cargo.getBury_aset_add_ind());
			rescargo[i].setBury_aset_stat_ind(cargo.getBury_aset_stat_ind());
			rescargo[i].setCase_num(cargo.getCase_num());
			rescargo[i].setDpnd_care_stat_ind(cargo.getDpnd_care_stat_ind());
			rescargo[i].setDabl_stat_ind(cargo.getDabl_stat_ind());
			rescargo[i].setDrug_feln_stat_ind(cargo.getDrug_feln_stat_ind());
			rescargo[i].setDue_dt(cargo.getDue_dt());
			rescargo[i].setEcf_stat_cd(cargo.getEcf_stat_cd());
			rescargo[i].setEmpl_stat_ind(cargo.getEmpl_stat_ind());
			rescargo[i].setHelp_othr_stat_ind(cargo.getHelp_othr_stat_ind());
			rescargo[i].setHshl_chg_stat_ind(cargo.getHshl_chg_stat_ind());
			rescargo[i].setHous_bill_stat_ind(cargo.getHous_bill_stat_ind());
			rescargo[i].setIrwe_stat_ind(cargo.getIrwe_stat_ind());
			rescargo[i].setIknd_incm_stat_ind(cargo.getIknd_incm_stat_ind());
			rescargo[i].setLi_aset_add_ind(cargo.getLi_aset_add_ind());
			rescargo[i].setLi_aset_stat_ind(cargo.getLi_aset_stat_ind());
			rescargo[i].setLqd_aset_add_ind(cargo.getLqd_aset_add_ind());
			rescargo[i].setLqd_aset_stat_ind(cargo.getLqd_aset_stat_ind());
			rescargo[i].setMapp_stat_ind(cargo.getMapp_stat_ind());
			rescargo[i].setMed_bills_stat_ind(cargo.getMed_bills_stat_ind());
			rescargo[i].setMed_cvrg_stat_ind(cargo.getMed_cvrg_stat_ind());
			rescargo[i].setOthr_incm_stat_ind(cargo.getOthr_incm_stat_ind());
			rescargo[i].setPdf_lang_cd(cargo.getPdf_lang_cd());
			rescargo[i].setPrsn_add_stat_ind(cargo.getPrsn_add_stat_ind());
			rescargo[i].setPrsn_move_stat_ind(cargo.getPrsn_move_stat_ind());
			rescargo[i].setPrsn_prop_stat_ind(cargo.getPrsn_prop_stat_ind());
			rescargo[i].setPreg_chg_stat_ind(cargo.getPreg_chg_stat_ind());
			rescargo[i].setReal_aset_add_ind(cargo.getReal_aset_add_ind());
			rescargo[i].setReal_aset_stat_ind(cargo.getReal_aset_stat_ind());
			rescargo[i].setRcnt_acdt_stat_ind(cargo.getRcnt_acdt_stat_ind());
			rescargo[i].setRoom_brd_stat_ind(cargo.getRoom_brd_stat_ind());
			rescargo[i].setSchl_enrl_stat_ind(cargo.getSchl_enrl_stat_ind());
			rescargo[i].setSelf_empl_stat_ind(cargo.getSelf_empl_stat_ind());
			rescargo[i].setStat_cd(cargo.getStat_cd());
			rescargo[i].setSbmt_tms(cargo.getSbmt_tms());
			rescargo[i].setSprt_oblg_stat_ind(cargo.getSprt_oblg_stat_ind());
			// NextGen  NG-6481 Phase 3 updates to ACA Streamline changes - start (H)
			rescargo[i].setTax_deduct_stat_ind(cargo.getTax_deduct_stat_ind());
			// NextGen  NG-6481 Phase 3 updates to ACA Streamline changes – end (H)
			rescargo[i].setTrb_cmdy_stat_ind(cargo.getTrb_cmdy_stat_ind());
			rescargo[i].setUpdt_dt(cargo.getUpdt_dt());
			rescargo[i].setUtil_bill_stat_ind(cargo.getUtil_bill_stat_ind());
			rescargo[i].setVeh_aset_add_ind(cargo.getVeh_aset_add_ind());
			rescargo[i].setVeh_aset_stat_ind(cargo.getVeh_aset_stat_ind());
			rescargo[i].setPast_cvrg_stat_ind(cargo.getPast_cvrg_stat_ind());
			rescargo[i].setFee_rqr_ind(cargo.getFee_rqr_ind());
			rescargo[i].setCla_due_dt(cargo.getCla_due_dt());
			// EDSP Starts
			rescargo[i].setParole_violation_stat_ind(cargo.getParole_violation_stat_ind());
			rescargo[i].setHead_of_household_stat_ind(cargo.getHead_of_household_stat_ind());
			rescargo[i].setCurrent_past_pndg_stat_ind(cargo.getCurrent_past_pndg_stat_ind());
			rescargo[i].setChild_care_stat_ind(cargo.getChild_care_stat_ind());
			rescargo[i].setChild_obligation_stat_ind(cargo.getChild_obligation_stat_ind());
			rescargo[i].setMed_bill_stat_ind(cargo.getMed_bill_stat_ind());
			rescargo[i].setTax_claim_dependant_ind(cargo.getTax_claim_dependant_ind());

			// EDSP Ends
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
			// ARXGQ
			rescargo[i].setMedicare_assist_req_stat_ind(cargo.getMedicare_assist_req_stat_ind());
			// ARXGQ
			//NextGen  NG-6481 Phase 3 updates to ACA Streamline changes : Start
			rescargo[i].setBefore_tax_deduction_ind(cargo.getBefore_tax_deduction_ind());
			//NextGen  NG-6481 Phase 3 updates to ACA Streamline changes : End
			//id proofing
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof RMB_RQST_Cargo[]) {
			final RMB_RQST_Cargo[] cbArray = (RMB_RQST_Cargo[]) obj;
			setResults(cbArray);
		}
	}


}
