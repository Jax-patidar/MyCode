package gov.state.nextgen.householddemographics.business.entities;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonProperty;

import gov.state.nextgen.access.business.entities.AbstractCargo;

import java.io.Serializable;
import java.util.Date;

@Entity
@IdClass(CP_APP_HSHL_RLT_Cargo.CP_APP_HSHL_RLT_Key.class)
@Table (name="CP_APP_HSHL_RLT")
public class CP_APP_HSHL_RLT_Cargo extends AbstractCargo implements Serializable{

    private static final long serialVersionUID = 1L;
    
    @Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num") 
	private int app_number;

    @Id
    @Column (name="ref_indv_seq_num" )
    @JsonProperty("ref_indv_seq_num") 
    private Integer refIndvSeqNum;

    @Id
    @Column (name="src_indv_seq_num" )
    @JsonProperty("src_indv_seq_num") 
    private Integer srcIndvSeqNum;

    
    @Column(name="src_app_ind")
    private String srcAppIndiv;

    @Column (name="rlt_cd")
    @JsonProperty("Rlt_cd")     
    private String rltCd;

    @Column (name="change_dt"   )
    private Date change_dt;

    private String care_resp;

    private Integer rec_cplt_ind;
    
    private String phy_boe_sep_sw;
    
    @Transient
    private Date change_eff_dt;
    
    private String pnp_tghr_sw;
    
    private String is_tax_dependent_of;
    
    @Column(name="rlt_calsaws_object")
    private String rltCalsawsObject;

    @Embeddable
    public static class CP_APP_HSHL_RLT_Key implements Serializable {

        /**
		 * 
		 */
		private static final long serialVersionUID = -2705463483291884263L;
		private Integer app_number;
        private Integer refIndvSeqNum;
        private Integer srcIndvSeqNum;

        public CP_APP_HSHL_RLT_Key(Integer app_number, Integer refIndvSeqNum, Integer srcIndvSeqNum, String srcAppIndiv) {
            this.app_number = app_number;
            this.refIndvSeqNum = refIndvSeqNum;
            this.srcIndvSeqNum = srcIndvSeqNum;
        }
        public CP_APP_HSHL_RLT_Key() {
        }
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
			result = prime * result + ((refIndvSeqNum == null) ? 0 : refIndvSeqNum.hashCode());
			result = prime * result + ((srcIndvSeqNum == null) ? 0 : srcIndvSeqNum.hashCode());
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CP_APP_HSHL_RLT_Key other = (CP_APP_HSHL_RLT_Key) obj;
			if (app_number == null) {
				if (other.app_number != null)
					return false;
			} else if (!app_number.equals(other.app_number))
				return false;
			if (refIndvSeqNum == null) {
				if (other.refIndvSeqNum != null)
					return false;
			} else if (!refIndvSeqNum.equals(other.refIndvSeqNum))
				return false;
			validateData(other);
			return true;
		}
		private boolean validateData(CP_APP_HSHL_RLT_Key other) {
			if (srcIndvSeqNum == null) {
				if (other.srcIndvSeqNum != null)
					return false;
			} else if (!srcIndvSeqNum.equals(other.srcIndvSeqNum))
				return false;
			return true;
		}
        
        
    }


    public CP_APP_HSHL_RLT_Cargo() {
    }


    public String getCare_resp() {
        return care_resp;
    }

    public void setCare_resp(String care_resp) {
        this.care_resp = care_resp;
    }

    public Integer getRec_cplt_ind() {
        return rec_cplt_ind;
    }

    public void setRec_cplt_ind(Integer rec_cplt_ind) {
        this.rec_cplt_ind = rec_cplt_ind;
    }

    
    

	public String getApp_num() {
		return String.valueOf(app_number);
	}


	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}


	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	
    public Integer getSrcIndvSeqNum() {
        return srcIndvSeqNum;
    }

    public void setSrcIndvSeqNum(Integer srcIndvSeqNum) {
        this.srcIndvSeqNum = srcIndvSeqNum;
    }

    public Date getChange_dt() {
        return change_dt;
    }

    public void setChange_dt(Date change_dt) {
        this.change_dt = change_dt;
    }

    public String getRltCd() {
        return rltCd;
    }

    public void setRltCd(String rltCd) {
        this.rltCd = rltCd;
    }

    public String getSrcAppIndiv() {
        return srcAppIndiv;
    }

    public void setSrcAppIndiv(String srcAppIndiv) {
        this.srcAppIndiv = srcAppIndiv;
    }

    public Integer getRefIndvSeqNum() {
        return refIndvSeqNum;
    }

    public void setRefIndvSeqNum(Integer refIndvSeqNum) {
        this.refIndvSeqNum = refIndvSeqNum;
    }


	public String getPhy_boe_sep_sw() {
		return phy_boe_sep_sw;
	}


	public void setPhy_boe_sep_sw(String phy_boe_sep_sw) {
		this.phy_boe_sep_sw = phy_boe_sep_sw;
	}


	public Date getChg_eff_dt() {
		return change_eff_dt;
	}


	public void setChg_eff_dt(Date chg_eff_dt) {
		this.change_eff_dt = chg_eff_dt;
	}


	public Date getChange_eff_dt() {
		return change_eff_dt;
	}


	public void setChange_eff_dt(Date change_eff_dt) {
		this.change_eff_dt = change_eff_dt;
	}


	public String getPnp_tghr_sw() {
		return pnp_tghr_sw;
	}


	public void setPnp_tghr_sw(String pnp_tghr_sw) {
		this.pnp_tghr_sw = pnp_tghr_sw;
	}


	public String getIs_tax_dependent_of() {
		return is_tax_dependent_of;
	}


	public void setIs_tax_dependent_of(String is_tax_dependent_of) {
		this.is_tax_dependent_of = is_tax_dependent_of;
	}

	public String getRltCalsawsObject() {
		return rltCalsawsObject;
	}


	public void setRltCalsawsObject(String rltCalsawsObject) {
		this.rltCalsawsObject = rltCalsawsObject;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((care_resp == null) ? 0 : care_resp.hashCode());
		result = prime * result + ((change_dt == null) ? 0 : change_dt.hashCode());
		result = prime * result + ((change_eff_dt == null) ? 0 : change_eff_dt.hashCode());
		result = prime * result + ((is_tax_dependent_of == null) ? 0 : is_tax_dependent_of.hashCode());
		result = prime * result + ((phy_boe_sep_sw == null) ? 0 : phy_boe_sep_sw.hashCode());
		result = prime * result + ((pnp_tghr_sw == null) ? 0 : pnp_tghr_sw.hashCode());
		result = prime * result + ((rec_cplt_ind == null) ? 0 : rec_cplt_ind.hashCode());
		result = prime * result + ((refIndvSeqNum == null) ? 0 : refIndvSeqNum.hashCode());
		result = prime * result + ((rltCd == null) ? 0 : rltCd.hashCode());
		result = prime * result + ((srcAppIndiv == null) ? 0 : srcAppIndiv.hashCode());
		result = prime * result + ((srcIndvSeqNum == null) ? 0 : srcIndvSeqNum.hashCode());
		return result;
	}


	
	
}
