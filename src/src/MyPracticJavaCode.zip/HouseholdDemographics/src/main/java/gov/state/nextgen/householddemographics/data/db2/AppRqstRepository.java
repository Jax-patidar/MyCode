package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;


@Repository
public interface AppRqstRepository extends CrudRepository<APP_RQST_Cargo, Long>{
	
	@Query("Select T from  APP_RQST_Cargo T where T.app_number=:app_num")
	public APP_RQST_Cargo[] findByAppNum(@Param("app_num") Integer app_num);
}
