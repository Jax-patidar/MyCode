package gov.state.nextgen.householddemographics.business.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.business.rules.AFBSchoolEnrollmentBO;
import gov.state.nextgen.householddemographics.business.rules.ContactInformationBO;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;

@SuppressWarnings("squid:S2229")
@Service("BenefitsService")
public class BenefitsServImpl implements HouseholdDemographicsService {

	@Autowired
	private AFBSchoolEnrollmentBO schoolEnrollBo;

	@Autowired
	private CpAppIndvRepository cpAppIndvRepository;

	@Autowired
	private ExceptionUtil exceptionUtil;
	

	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {
		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.STORESCHOOLENROLLMENT:
			this.storeSchoolEnrollment(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.DELETESCHOOLENROLLMENT:
			this.deleteSchoolEnrollment(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.GETTEENPARENTDETAILS:
			this.getTeenParentDetails(fwTxn);
			break;

		default:
			break;

		}

	}

	/**
	 * store the data for school enrollment
	 * 
	 * TODO:CP_APP_IN_PRFL service chaining needs to be implemented
	 */
	@Transactional
	@SuppressWarnings("squid:S3776")
	public void storeSchoolEnrollment(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "BenefitsService.storeSchoolEnrollment() - START", fwTxn);
		try {
			Map request = fwTxn.getRequest();
			Map pageCollection = fwTxn.getPageCollection();
			String schoolType;
			String noOfUnits;
			if (HouseHoldDemoGraphicsConstants.ABCLI.equals(fwTxn.getCurrentActionDetails().getPageId())
					|| HouseHoldDemoGraphicsConstants.RCCLD.equals(fwTxn.getCurrentActionDetails().getPageId())) {
				schoolType = "CL";
			} else {
				schoolType = "TN";
			}

			String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seq_num = null;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			APP_IN_SCHLE_Collection appInSchColl = (APP_IN_SCHLE_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION);
			APP_IN_SCHLE_Cargo appInSchCargo;

			if (appInSchColl != null && !appInSchColl.isEmpty() && appInSchColl.size() > 0) {

				appInSchCargo = appInSchColl.getCargo(0);
				noOfUnits = appInSchCargo.getNo_of_units();
				if (noOfUnits != null && noOfUnits.equalsIgnoreCase("SEL")) {
					appInSchCargo.setNo_of_units(null);
				}
				FwMessageList validateInfo = null;
				if (Objects.nonNull(fwTxn) && Objects.nonNull(fwTxn.getCurrentActionDetails())
						&& Objects.nonNull(fwTxn.getCurrentActionDetails().getPageId())
						&& (!fwTxn.getCurrentActionDetails().getPageId().equals(HouseHoldDemoGraphicsConstants.ABCLI)
								&& !fwTxn.getCurrentActionDetails().getPageId()
										.equals(HouseHoldDemoGraphicsConstants.ABTSS)
								&& !fwTxn.getCurrentActionDetails().getPageId()
										.equals(HouseHoldDemoGraphicsConstants.RCCLD))) {
					validateInfo = schoolEnrollBo.validateSchoolEnrollmentDetails(appInSchCargo);
				}

				if (Objects.nonNull(validateInfo) && validateInfo.hasMessages()) {
					request.put(FwConstants.MESSAGE_LIST, validateInfo);
					return;
				}

				appInSchCargo.setApp_num(appNum);
				appInSchCargo.setIndv_seq_num(indv_seq_num);
				appInSchCargo.setSchool_type_cd(schoolType);
				APP_IN_SCHLE_Collection clgEnrollDtls = schoolEnrollBo.loadEnrollmentDtls(appNum, indv_seq_num);
				if (Objects.isNull(seq_num)) {
					seq_num = 1;
					if (!clgEnrollDtls.isEmpty()) {
						int index = clgEnrollDtls.size() - 1;
						APP_IN_SCHLE_Cargo lastCargo = (APP_IN_SCHLE_Cargo) clgEnrollDtls.get(index);
						seq_num = lastCargo.getSeq_num() + 1;
					}
				}
				if (seq_num != null) {
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.setCategorySequence(seq_num.toString());
					appInSchCargo.setSeq_num(seq_num);
				}
				appInSchCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
				appInSchCargo.setRec_cplt_ind(HouseHoldDemoGraphicsConstants.ONE);
				if (Objects.isNull(appInSchCargo.getEnrl_stat_cd())) {
					appInSchCargo.setEnrl_stat_cd(HouseHoldDemoGraphicsConstants.SPACES);
				}

				appInSchCargo.setChg_dt(appInSchCargo.getInfoChangeDt());

			}

			schoolEnrollBo.storeSchoolEnrollmentDetails(appInSchColl);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"BenefitsService.storeSchoolEnrollment() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + " milliseconds", fwTxn);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in BenefitsService.storeSchoolEnrollment()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeSchoolEnrollment",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "BenefitsService.storeSchoolEnrollment() - END", fwTxn);
	}

	/*
	 * Load method for College and Teen Parent Summary Screen TODO:CP_APP_IN_PRFL
	 * service chaining needs to be implemented
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	public void getTeenParentDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "BenefitsService.getTeenParentDetails() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			PageActionDetails currentActionDetails = fwTxn.getCurrentActionDetails();
			String appNum = fwTxn.getUserDetails().getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("indvIds");
			List<Integer> indvIdList = new ArrayList<Integer>();
			if (null != indvIds && !indvIds.isEmpty()) {
				indvIdList = getIndvList(indvIdList, indvIds);
			} else {
				indvIds = new ArrayList<String>();
				APP_INDV_Cargo[] appIndvCargoArray = cpAppIndvRepository.getByAppNum(Integer.parseInt(appNum));
				if (null != appIndvCargoArray && appIndvCargoArray.length > 0) {
					for (APP_INDV_Cargo cargo : appIndvCargoArray) {
						if((cargo.getMove_out_ind()==null || cargo.getMove_out_ind() != "Y") && (cargo.getDeceased_ind()==null || cargo.getDeceased_ind() != "Y")) {
						indvIds.add(cargo.getIndv_seq_num().toString());
						}
					}
					}
					pageCollection.put("indvIds", indvIds);
					fwTxn.setPageCollection(pageCollection);
					indvIdList = getIndvList(indvIdList, indvIds);
			}
			String schoolType;
			if (HouseHoldDemoGraphicsConstants.ABCSU.equals(currentActionDetails.getPageId())
					|| "RCRAS".equals(fwTxn.getCurrentActionDetails().getPageId())) {
				schoolType = "CL";
			} else {
				schoolType = "TN";
			}
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			APP_IN_SCHLE_Collection appIndvCargos = schoolEnrollBo.loadCollegeEnrollment(appNumber, schoolType,
					indvIdList);
			pageCollection.put("APP_IN_SCHLE_Collection", appIndvCargos);
			pageCollection.put(HouseHoldDemoGraphicsConstants.STORED_APP_IN_SCHLE_COLLECTION, appIndvCargos);
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ARTransactionManagedServImpl.getTeenParentDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getTeenParentDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "BenefitsService.getTeenParentDetails() - END", fwTxn);

	}

	public List<Integer> getIndvList(List<Integer> indvIdList, ArrayList<String> indvIds) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "BenefitsServImpl.getIndvList() - START");
		try {
			for (String indvId : indvIds) {
				Integer indvSeqNum = (null != indvId && indvId.chars().allMatch(x -> Character.isDigit(x)))
						? Integer.parseInt(indvId)
						: 0;
				if (indvSeqNum > 0) {
					indvIdList.add(indvSeqNum);
				}
			}
		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), Level.ERROR, "getIndvList", fe);
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "BenefitsServImpl.getIndvList() - END");
		return indvIdList;
	}

	/**
	 * deleteSchoolEnrollment is to delete the college and teen parent information
	 * from DB .
	 *
	 * @param fwTxn the txn object
	 */
	@Transactional
	public void deleteSchoolEnrollment(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO, "BenefitsService.deleteSchoolEnrollment() - START", fwTxn);
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();
			String schoolType;
			if (HouseHoldDemoGraphicsConstants.ABCSU.equals(fwTxn.getCurrentActionDetails().getPageId())) {
				schoolType = "CL";
			} else {
				schoolType = "TN";
			}
			Integer indvSeqNumber = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			schoolEnrollBo.deleteSchoolDetails(appNum, indvSeqNumber, seq_num, schoolType);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ARTransactionManagedServImpl.deleteSchoolEnrollment()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteSchoolEnrollment",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "BenefitsService.deleteSchoolEnrollment() - END", fwTxn);
	}

}
