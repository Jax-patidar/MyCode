package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(APP_IN_SCHLE_Key.class)
@Table(name="CP_APP_IN_SCHOOL",schema = "ie_ssp_owner_hh")
public class APP_IN_SCHLE_Cargo extends AbstractCargo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
    @Id
    private Integer indv_seq_num;
    @Id
    private Integer seq_num;
    
    private String src_app_ind;
    @Id
    private String school_type_cd;
    @Transient
    private Integer chld_care_ind;
    @Transient
    private String educ_cd;
    private String enrl_stat_cd;
    @JsonFormat(pattern="MM/dd/yyyy")
    @Transient
    private Date hs_grad_dt;
    @Transient
    private String hs_grad_stat_cd;
    @Transient
    private Integer isfc_dy_care_ind;
    private Integer rec_cplt_ind;
    @Transient
    private Integer schl_plcm_ind;
    @Column(name="work_study_ind")
    private String work_stdy_ind;
    private String school_name;
    @Column(name="immunization_rcvd_ind")
    private String immunization_received_ind;
    @Transient
    private String adapt_record_id;
    @Transient
    private String fed_fund_wrk_study_prg_ind;
    @Transient
    private String school_city_adr;
    @Transient
    private String school_sta_adr;
    @Transient
    private String fed_sta_fund_wrk_study_prg_ind;
    @Transient
    private String school_l1_adr;
    @Transient
    private String school_sta_adr_cd;
    @Transient
    private String school_l2_adr;
    @Transient
    private String school_zip_adr;
    @JsonFormat(pattern="MM/dd/yyyy")
    private Date end_dt;
    @Transient
    private Integer ecp_id;
    @Transient
    private String addr_zip4;
    @Column(name="change_dt")
    @JsonFormat(pattern="MM/dd/yyyy")
    private Date chg_dt;
    private String no_of_units;
    private String avg_weekly_work_hrs;
    @Transient
    private String first_name;
    @Transient
    private String last_name;
    @Transient
    private Integer age;
    private String nt_enrl_stat_desc;
    @Transient
    @JsonFormat(pattern="yyyy-MM-dd")
    private Date infoChangeDt;
	/**
	 * @return the nt_enrl_stat_desc
	 */
	public String getNt_enrl_stat_desc() {
		return nt_enrl_stat_desc;
	}
	/**
	 * @param nt_enrl_stat_desc the nt_enrl_stat_desc to set
	 */
	public void setNt_enrl_stat_desc(String nt_enrl_stat_desc) {
		this.nt_enrl_stat_desc = nt_enrl_stat_desc;
	}
	/**
	 * @return the seq_num
	 */
	public Integer getSeq_num() {
		return seq_num;
	}
	/**
	 * @param seq_num the seq_num to set
	 */
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	/**
	 * @return the first_name
	 */
	public String getFirst_name() {
		return first_name;
	}
	/**
	 * @param first_name the first_name to set
	 */
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	/**
	 * @return the last_name
	 */
	public String getLast_name() {
		return last_name;
	}

	/**
	 * @param last_name the last_name to set
	 */
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	/**
	 * @return the age
	 */
	public Integer getAge() {
		return age;
	}

	/**
	 * @param i the age to set
	 */
	public void setAge(Integer i) {
		this.age = i;
	}
	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	
	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * @return the chld_care_ind
	 */
	public Integer getChld_care_ind() {
		return chld_care_ind;
	}

	/**
	 * @param chld_care_ind the chld_care_ind to set
	 */
	public void setChld_care_ind(Integer chld_care_ind) {
		this.chld_care_ind = chld_care_ind;
	}

	/**
	 * @return the educ_cd
	 */
	public String getEduc_cd() {
		return educ_cd;
	}

	/**
	 * @param educ_cd the educ_cd to set
	 */
	public void setEduc_cd(String educ_cd) {
		this.educ_cd = educ_cd;
	}

	/**
	 * @return the enrl_stat_cd
	 */
	public String getEnrl_stat_cd() {
		return enrl_stat_cd;
	}

	/**
	 * @param enrl_stat_cd the enrl_stat_cd to set
	 */
	public void setEnrl_stat_cd(String enrl_stat_cd) {
		this.enrl_stat_cd = enrl_stat_cd;
	}

	/**
	 * @return the hs_grad_dt
	 */
	public Date getHs_grad_dt() {
		if(hs_grad_dt != null) {
			return (Date) hs_grad_dt.clone();
		}else {
			return null;
		}
	}

	/**
	 * @param hs_grad_dt the hs_grad_dt to set
	 */
	public void setHs_grad_dt(Date hs_grad_dt) {
		if(hs_grad_dt != null) {
			this.hs_grad_dt = (Date) hs_grad_dt.clone();
		}else {
			this.hs_grad_dt = null;
		}
	}

	/**
	 * @return the hs_grad_stat_cd
	 */
	public String getHs_grad_stat_cd() {
		return hs_grad_stat_cd;
	}

	/**
	 * @param hs_grad_stat_cd the hs_grad_stat_cd to set
	 */
	public void setHs_grad_stat_cd(String hs_grad_stat_cd) {
		this.hs_grad_stat_cd = hs_grad_stat_cd;
	}

	/**
	 * @return the isfc_dy_care_ind
	 */
	public Integer getIsfc_dy_care_ind() {
		return isfc_dy_care_ind;
	}

	/**
	 * @param isfc_dy_care_ind the isfc_dy_care_ind to set
	 */
	public void setIsfc_dy_care_ind(Integer isfc_dy_care_ind) {
		this.isfc_dy_care_ind = isfc_dy_care_ind;
	}

	/**
	 * @return the rec_cplt_ind
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * @param rec_cplt_ind the rec_cplt_ind to set
	 */
	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * @return the schl_plcm_ind
	 */
	public Integer getSchl_plcm_ind() {
		return schl_plcm_ind;
	}

	/**
	 * @param schl_plcm_ind the schl_plcm_ind to set
	 */
	public void setSchl_plcm_ind(Integer schl_plcm_ind) {
		this.schl_plcm_ind = schl_plcm_ind;
	}

	/**
	 * @return the work_stdy_ind
	 */
	public String getWork_stdy_ind() {
		return work_stdy_ind;
	}

	/**
	 * @param work_stdy_ind the work_stdy_ind to set
	 */
	public void setWork_stdy_ind(String work_stdy_ind) {
		this.work_stdy_ind = work_stdy_ind;
	}
	/**
	 * @return the school_name
	 */
	public String getSchool_name() {
		return school_name;
	}
	/**
	 * @param school_name the school_name to set
	 */
	public void setSchool_name(String school_name) {
		this.school_name = school_name;
	}
	/**
	 * @return the immunization_received_ind
	 */
	public String getImmunization_received_ind() {
		return immunization_received_ind;
	}
	/**
	 * @param immunization_received_ind the immunization_received_ind to set
	 */
	public void setImmunization_received_ind(String immunization_received_ind) {
		this.immunization_received_ind = immunization_received_ind;
	}
	/**
	 * @return the adapt_record_id
	 */
	public String getAdapt_record_id() {
		return adapt_record_id;
	}
	/**
	 * @param adapt_record_id the adapt_record_id to set
	 */
	public void setAdapt_record_id(String adapt_record_id) {
		this.adapt_record_id = adapt_record_id;
	}
	/**
	 * @return the fed_fund_wrk_study_prg_ind
	 */
	public String getFed_fund_wrk_study_prg_ind() {
		return fed_fund_wrk_study_prg_ind;
	}
	/**
	 * @param fed_fund_wrk_study_prg_ind the fed_fund_wrk_study_prg_ind to set
	 */
	public void setFed_fund_wrk_study_prg_ind(String fed_fund_wrk_study_prg_ind) {
		this.fed_fund_wrk_study_prg_ind = fed_fund_wrk_study_prg_ind;
	}
	/**
	 * @return the school_type_cd
	 */
	public String getSchool_type_cd() {
		return school_type_cd;
	}
	/**
	 * @param school_type_cd the school_type_cd to set
	 */
	public void setSchool_type_cd(String school_type_cd) {
		this.school_type_cd = school_type_cd;
	}
	/**
	 * @return the school_city_adr
	 */
	public String getSchool_city_adr() {
		return school_city_adr;
	}
	/**
	 * @param school_city_adr the school_city_adr to set
	 */
	public void setSchool_city_adr(String school_city_adr) {
		this.school_city_adr = school_city_adr;
	}
	/**
	 * @return the school_sta_adr
	 */
	public String getSchool_sta_adr() {
		return school_sta_adr;
	}
	/**
	 * @param school_sta_adr the school_sta_adr to set
	 */
	public void setSchool_sta_adr(String school_sta_adr) {
		this.school_sta_adr = school_sta_adr;
	}
	/**
	 * @return the fed_sta_fund_wrk_study_prg_ind
	 */
	public String getFed_sta_fund_wrk_study_prg_ind() {
		return fed_sta_fund_wrk_study_prg_ind;
	}
	/**
	 * @param fed_sta_fund_wrk_study_prg_ind the fed_sta_fund_wrk_study_prg_ind to set
	 */
	public void setFed_sta_fund_wrk_study_prg_ind(String fed_sta_fund_wrk_study_prg_ind) {
		this.fed_sta_fund_wrk_study_prg_ind = fed_sta_fund_wrk_study_prg_ind;
	}
	/**
	 * @return the school_l1_adr
	 */
	public String getSchool_l1_adr() {
		return school_l1_adr;
	}
	/**
	 * @param school_l1_adr the school_l1_adr to set
	 */
	public void setSchool_l1_adr(String school_l1_adr) {
		this.school_l1_adr = school_l1_adr;
	}
	/**
	 * @return the school_sta_adr_cd
	 */
	public String getSchool_sta_adr_cd() {
		return school_sta_adr_cd;
	}
	/**
	 * @param school_sta_adr_cd the school_sta_adr_cd to set
	 */
	public void setSchool_sta_adr_cd(String school_sta_adr_cd) {
		this.school_sta_adr_cd = school_sta_adr_cd;
	}
	/**
	 * @return the school_l2_adr
	 */
	public String getSchool_l2_adr() {
		return school_l2_adr;
	}
	/**
	 * @param school_l2_adr the school_l2_adr to set
	 */
	public void setSchool_l2_adr(String school_l2_adr) {
		this.school_l2_adr = school_l2_adr;
	}
	/**
	 * @return the school_zip_adr
	 */
	public String getSchool_zip_adr() {
		return school_zip_adr;
	}
	/**
	 * @param school_zip_adr the school_zip_adr to set
	 */
	public void setSchool_zip_adr(String school_zip_adr) {
		this.school_zip_adr = school_zip_adr;
	}
	/**
	 * @return the end_dt
	 */
	public Date getEnd_dt() {
		if(end_dt != null) {
			return (Date) end_dt.clone();
		}else {
			return null;
		}
	}
	/**
	 * @param end_dt the end_dt to set
	 */
	public void setEnd_dt(Date end_dt) {
		if(end_dt != null) {
			this.end_dt = (Date) end_dt.clone();
		}else {
			this.end_dt = null;
		}
	}
	/**
	 * @return the ecp_id
	 */
	public Integer getEcp_id() {
		return ecp_id;
	}
	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(Integer ecp_id) {
		this.ecp_id = ecp_id;
	}
	/**
	 * @return the addr_zip4
	 */
	public String getAddr_zip4() {
		return addr_zip4;
	}
	/**
	 * @param addr_zip4 the addr_zip4 to set
	 */
	public void setAddr_zip4(String addr_zip4) {
		this.addr_zip4 = addr_zip4;
	}
	/**
	 * @return the chg_dt
	 */
	public Date getChg_dt() {
		if(chg_dt != null) {
			return (Date) chg_dt.clone();
		}else {
			return null;
		}
	}
	/**
	 * @param chg_dt the chg_dt to set
	 */
	public void setChg_dt(Date chg_dt) {
		if(chg_dt != null) {
			this.chg_dt = (Date) chg_dt.clone();
		}else {
			this.chg_dt = null;
		}
	}

	
	public Date getInfoChangeDt() {
		return infoChangeDt;
	}
	public void setInfoChangeDt(Date infoChangeDt) {
		this.infoChangeDt = infoChangeDt;
	}
	
	/**
	 * @return the no_of_units
	 */
	public String getNo_of_units() {
		return no_of_units;
	}
	/**
	 * @param no_of_units the no_of_units to set
	 */
	public void setNo_of_units(String no_of_units) {
		this.no_of_units = no_of_units;
	}
	/**
	 * @return the avg_weekly_work_hrs
	 */
	public String getAvg_weekly_work_hrs() {
		return avg_weekly_work_hrs;
	}
	/**
	 * @param avg_weekly_work_hrs the avg_weekly_work_hrs to set
	 */
	public void setAvg_weekly_work_hrs(String avg_weekly_work_hrs) {
		this.avg_weekly_work_hrs = avg_weekly_work_hrs;
	}
	
}
