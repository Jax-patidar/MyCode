package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name="CP_APP_PGM_REQUEST")
@IdClass(APP_PGM_RQST_Key.class)
public class APP_PGM_RQST_Cargo extends AbstractCargo implements Serializable{

	private static final long serialVersionUID = 269715134768762710L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Column(name="MA_REQUEST_IND")
	private Integer fma_rqst_ind;
	@Transient
	private Integer fpw_rqst_ind;
	@Column(name="FS_REQUEST_IND")
	private Integer fs_rqst_ind;
	@Transient
	private Integer ebd_rqst_ind;
	@Transient
	private Integer hc_rqst_ind;
	@Transient
	private Integer ser_rqst_ind;
	@Transient
	private String edi_acceptable_sw;
	@Transient
	private Integer cc_rqst_ind;
	@Transient
	private Integer cooling_assistance_rqst_ind;
	@Transient
	private Integer crisis_assistance_rqst_ind;
	@Transient
	private Integer fuel_assistance_rqst_ind;
	@Column(name="TANF_REQUEST_IND")
	private Integer tanf_rqst_ind;
	@Transient
	private Integer no_snap_rqst_ind;
	@Transient
	private Integer rmb_tanf_rqst_ind;
	@Transient
	private Integer rmb_snap_rqst_ind;
	@Transient
	private Integer rmb_fma_rqst_ind;
	@Transient
	private Integer rmb_other_program_ind;
	@Transient
	private Integer wic_rqst_ind;
	@Transient
	private Integer liheap_rqst_ind;
	@Transient
	private Integer peach_rqst_ind;
	@Transient
	private Integer magi_rqst_ind;
	
	//Added as part of the updated DB ie_ssp_owner.hh
	private Integer capi_request_ind;
	private Integer ggr_ind;
	private Integer county_med_ind;
	private Integer dcalfresh_request_ind;
	
	// Added as a part of PR Stop Benefits question
		private String stop_fs_rqst_ind;
		private String stop_tanf_rqst_ind;
		private String stop_fma_rqst_ind;
		
		private String prog_sel_sw;
		
		@CreationTimestamp
		@Column(name = "create_dt", updatable = false)
		private Timestamp create_dt;
		
		@UpdateTimestamp
		private Timestamp update_dt;
		
		
		
		
		public String getStop_fs_rqst_ind() {
			return stop_fs_rqst_ind;
		}
		public void setStop_fs_rqst_ind(String stop_fs_rqst_ind) {
			this.stop_fs_rqst_ind = stop_fs_rqst_ind;
		}
		public String getStop_tanf_rqst_ind() {
			return stop_tanf_rqst_ind;
		}
		public void setStop_tanf_rqst_ind(String stop_tanf_rqst_ind) {
			this.stop_tanf_rqst_ind = stop_tanf_rqst_ind;
		}
		public String getStop_fma_rqst_ind() {
			return stop_fma_rqst_ind;
		}
		public void setStop_fma_rqst_ind(String stop_fma_rqst_ind) {
			this.stop_fma_rqst_ind = stop_fma_rqst_ind;
		}
	
		public String getProg_sel_sw() {
			return prog_sel_sw;
		}
		public void setProg_sel_sw(String prog_sel_sw) {
			this.prog_sel_sw = prog_sel_sw;
		}
		
		public String getApp_num() {
			return String.valueOf(app_number);
		}
		public void setApp_num(String app_num) {
			this.app_number = Integer.parseInt(app_num);
			this.app_num = app_num;
		}
		public int getApp_number() {
			return app_number;
		}
		public void setApp_number(int app_number) {
			this.app_number = app_number;
			this.app_num = String.valueOf(app_number);
		}
	public Integer getFma_rqst_ind() {
		return fma_rqst_ind;
	}
	public void setFma_rqst_ind(Integer fma_rqst_ind) {
		this.fma_rqst_ind = fma_rqst_ind;
	}
	public Integer getFpw_rqst_ind() {
		return fpw_rqst_ind;
	}
	public void setFpw_rqst_ind(Integer fpw_rqst_ind) {
		this.fpw_rqst_ind = fpw_rqst_ind;
	}
	public Integer getFs_rqst_ind() {
		return fs_rqst_ind;
	}
	public void setFs_rqst_ind(Integer fs_rqst_ind) {
		this.fs_rqst_ind = fs_rqst_ind;
	}
	public Integer getEbd_rqst_ind() {
		return ebd_rqst_ind;
	}
	public void setEbd_rqst_ind(Integer ebd_rqst_ind) {
		this.ebd_rqst_ind = ebd_rqst_ind;
	}
	public Integer getHc_rqst_ind() {
		return hc_rqst_ind;
	}
	public void setHc_rqst_ind(Integer hc_rqst_ind) {
		this.hc_rqst_ind = hc_rqst_ind;
	}
	public Integer getSer_rqst_ind() {
		return ser_rqst_ind;
	}
	public void setSer_rqst_ind(Integer ser_rqst_ind) {
		this.ser_rqst_ind = ser_rqst_ind;
	}
	public String getEdi_acceptable_sw() {
		return edi_acceptable_sw;
	}
	public void setEdi_acceptable_sw(String edi_acceptable_sw) {
		this.edi_acceptable_sw = edi_acceptable_sw;
	}
	public Integer getCc_rqst_ind() {
		return cc_rqst_ind;
	}
	public void setCc_rqst_ind(Integer cc_rqst_ind) {
		this.cc_rqst_ind = cc_rqst_ind;
	}
	public Integer getCooling_assistance_rqst_ind() {
		return cooling_assistance_rqst_ind;
	}
	public void setCooling_assistance_rqst_ind(Integer cooling_assistance_rqst_ind) {
		this.cooling_assistance_rqst_ind = cooling_assistance_rqst_ind;
	}
	public Integer getCrisis_assistance_rqst_ind() {
		return crisis_assistance_rqst_ind;
	}
	public void setCrisis_assistance_rqst_ind(Integer crisis_assistance_rqst_ind) {
		this.crisis_assistance_rqst_ind = crisis_assistance_rqst_ind;
	}
	public Integer getFuel_assistance_rqst_ind() {
		return fuel_assistance_rqst_ind;
	}
	public void setFuel_assistance_rqst_ind(Integer fuel_assistance_rqst_ind) {
		this.fuel_assistance_rqst_ind = fuel_assistance_rqst_ind;
	}
	public Integer getTanf_rqst_ind() {
		return tanf_rqst_ind;
	}
	public void setTanf_rqst_ind(Integer tanf_rqst_ind) {
		this.tanf_rqst_ind = tanf_rqst_ind;
	}
	public Integer getNo_snap_rqst_ind() {
		return no_snap_rqst_ind;
	}
	public void setNo_snap_rqst_ind(Integer no_snap_rqst_ind) {
		this.no_snap_rqst_ind = no_snap_rqst_ind;
	}
	public Integer getRmb_tanf_rqst_ind() {
		return rmb_tanf_rqst_ind;
	}
	public void setRmb_tanf_rqst_ind(Integer rmb_tanf_rqst_ind) {
		this.rmb_tanf_rqst_ind = rmb_tanf_rqst_ind;
	}
	public Integer getRmb_snap_rqst_ind() {
		return rmb_snap_rqst_ind;
	}
	public void setRmb_snap_rqst_ind(Integer rmb_snap_rqst_ind) {
		this.rmb_snap_rqst_ind = rmb_snap_rqst_ind;
	}
	public Integer getRmb_fma_rqst_ind() {
		return rmb_fma_rqst_ind;
	}
	public void setRmb_fma_rqst_ind(Integer rmb_fma_rqst_ind) {
		this.rmb_fma_rqst_ind = rmb_fma_rqst_ind;
	}
	public Integer getRmb_other_program_ind() {
		return rmb_other_program_ind;
	}
	public void setRmb_other_program_ind(Integer rmb_other_program_ind) {
		this.rmb_other_program_ind = rmb_other_program_ind;
	}
	public Integer getWic_rqst_ind() {
		return wic_rqst_ind;
	}
	public void setWic_rqst_ind(Integer wic_rqst_ind) {
		this.wic_rqst_ind = wic_rqst_ind;
	}
	public Integer getLiheap_rqst_ind() {
		return liheap_rqst_ind;
	}
	public void setLiheap_rqst_ind(Integer liheap_rqst_ind) {
		this.liheap_rqst_ind = liheap_rqst_ind;
	}
	public Integer getPeach_rqst_ind() {
		return peach_rqst_ind;
	}
	public void setPeach_rqst_ind(Integer peach_rqst_ind) {
		this.peach_rqst_ind = peach_rqst_ind;
	}
	public Integer getMagi_rqst_ind() {
		return magi_rqst_ind;
	}
	public void setMagi_rqst_ind(Integer magi_rqst_ind) {
		this.magi_rqst_ind = magi_rqst_ind;
	}
	public Integer getCapi_request_ind() {
		return capi_request_ind;
	}
	public void setCapi_request_ind(Integer capi_request_ind) {
		this.capi_request_ind = capi_request_ind;
	}
	public Integer getGgr_ind() {
		return ggr_ind;
	}
	public void setGgr_ind(Integer ggr_ind) {
		this.ggr_ind = ggr_ind;
	}
	public Integer getCounty_med_ind() {
		return county_med_ind;
	}
	public void setCounty_med_ind(Integer county_med_ind) {
		this.county_med_ind = county_med_ind;
	}
	public Integer getDcalfresh_request_ind() {
		return dcalfresh_request_ind;
	}
	public void setDcalfresh_request_ind(Integer dcalfresh_request_ind) {
		this.dcalfresh_request_ind = dcalfresh_request_ind;
	}
	public Timestamp getCreate_dt() {
		return create_dt;
	}
	public void setCreate_dt(Timestamp create_dt) {
		this.create_dt = create_dt;
	}
	public Timestamp getUpdate_dt() {
		return update_dt;
	}
	public void setUpdate_dt(Timestamp update_dt) {
		this.update_dt = update_dt;
	}
	
		

}
