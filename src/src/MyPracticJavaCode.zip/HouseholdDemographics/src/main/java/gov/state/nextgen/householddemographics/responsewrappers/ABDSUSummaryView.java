package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_CARE_PROV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_CARE_PROV_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;




@Component("ABDSU")
@Scope("prototype")
public class ABDSUSummaryView implements LogicResponseInterface {
	
	private static final String PAGE_ID = "ABDSU";
	
	private static final String APP_IN_DABL_COLL = "APP_IN_DABL_Collection";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTxn.getPageCollection();
		List<APP_IN_DABL_Cargo> dablList = new ArrayList<APP_IN_DABL_Cargo>();
		
		
		APP_IN_DABL_Cargo cpAppdablCargo;
		APP_IN_DABL_Collection cpAppDablCollection = pageCollection.get(APP_IN_DABL_COLL) != null ? (APP_IN_DABL_Collection) pageCollection.get(APP_IN_DABL_COLL) : null;
	
		
		if(cpAppDablCollection != null && !cpAppDablCollection.isEmpty() && cpAppDablCollection.size() >0) {			
			for (int i = 0; i < cpAppDablCollection.size(); i++) {
				cpAppdablCargo = (APP_IN_DABL_Cargo) cpAppDablCollection.get(i);
				dablList.add(cpAppdablCargo);
			}
		}
		
		driverPageResponse.getPageCollection().put(APP_IN_DABL_COLL, dablList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		
		return driverPageResponse;
		
		
	}
	
}
