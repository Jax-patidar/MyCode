package gov.state.nextgen.householddemographics.business.entities;

public class RMC_CHG_SEL_PRFL_Cargo {

    private String app_num;

    private String indv_seq_num;

    private String chg_sel_cat_cd;

    private String cat_seq_num;

    private String cat_typ;

    private String stat_ind;

    private String user_end_sel_ind;

    public String getApp_num() {
        return app_num;
    }

    public void setApp_num(String app_num) {
        this.app_num = app_num;
    }

    public String getIndv_seq_num() {
        return indv_seq_num;
    }

    public void setIndv_seq_num(String indv_seq_num) {
        this.indv_seq_num = indv_seq_num;
    }

    public String getChg_sel_cat_cd() {
        return chg_sel_cat_cd;
    }

    public void setChg_sel_cat_cd(String chg_sel_cat_cd) {
        this.chg_sel_cat_cd = chg_sel_cat_cd;
    }

    public String getCat_seq_num() {
        return cat_seq_num;
    }

    public void setCat_seq_num(String cat_seq_num) {
        this.cat_seq_num = cat_seq_num;
    }

    public String getCat_typ() {
        return cat_typ;
    }

    public void setCat_typ(String cat_typ) {
        this.cat_typ = cat_typ;
    }

    public String getStat_ind() {
        return stat_ind;
    }

    public void setStat_ind(String stat_ind) {
        this.stat_ind = stat_ind;
    }

    public String getUser_end_sel_ind() {
        return user_end_sel_ind;
    }

    public void setUser_end_sel_ind(String user_end_sel_ind) {
        this.user_end_sel_ind = user_end_sel_ind;
    }
}
