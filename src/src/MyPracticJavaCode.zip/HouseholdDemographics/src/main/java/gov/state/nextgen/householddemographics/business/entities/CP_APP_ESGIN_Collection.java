package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class CP_APP_ESGIN_Collection extends AbstractCollection {

    private static final String PACKAGE = "gov.state.nextgen.access.business.entities.CP_APP_ESGIN";


    /**
     * returns the PACKAGE name.
     */
    @Override
    public String getPACKAGE() {
        return PACKAGE;
    }

    /**
     * Adds the given cargo to the collection.
     */
    public void addCargo(final CP_APP_ESGIN_Cargo aNewCargo) {
        add(aNewCargo);
    }

    /**
     * Sets cargo array into collection.
     */
    public void setResults(final CP_APP_ESGIN_Cargo[] cbArray) {
        clear();
        for (int i = 0; i < cbArray.length; i++) {
            add(cbArray[i]);
        }
    }

    public CP_APP_ESGIN_Cargo getResult(final int idx) {
        return (CP_APP_ESGIN_Cargo) get(idx);
    }

    /**
     * Sets cargo into collection at the given index.
     */
    public void setCargo(final int idx, final CP_APP_ESGIN_Cargo aCargo) {
        set(idx, aCargo);
    }

    /**
     * returns all the values in the Collection as Cargo Array.
     */
    public CP_APP_ESGIN_Cargo[] getResults() {
        final CP_APP_ESGIN_Cargo[] cbArray = new CP_APP_ESGIN_Cargo[size()];
        toArray(cbArray);
        return cbArray;
    }

    /**
     * returns a cargo from the Collection for the given index.
     */
    public CP_APP_ESGIN_Cargo getCargo(final int idx) {
        return (CP_APP_ESGIN_Cargo) get(idx);
    }

    /**
     * Set the cargo array object to the collection.
     */
    @Override
    public void setGenericResults(final Object obj) {
        if (obj instanceof CP_APP_ESGIN_Cargo[]) {
            final CP_APP_ESGIN_Cargo[] cbArray = (CP_APP_ESGIN_Cargo[]) obj;
            setResults(cbArray);
        }
    }

}
