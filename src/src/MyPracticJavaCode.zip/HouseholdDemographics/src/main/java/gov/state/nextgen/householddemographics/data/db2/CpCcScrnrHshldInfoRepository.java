package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_HSHLD_INFO_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_HSHLD_INFO_Key;

@NoRepositoryBean
public interface CpCcScrnrHshldInfoRepository extends CrudRepository<CP_CC_SCRNR_HSHLD_INFO_Cargo,CP_CC_SCRNR_HSHLD_INFO_Key>{
	
	@Query("select MAX(c.scrnr_seq) from CP_CC_SCRNR_HSHLD_INFO_Cargo c where c.app_num = ?1")
	public List getByAppNumMax(String appNum); 
	
	@Query("select c from CP_CC_SCRNR_HSHLD_INFO_Cargo c where c.app_num = ?1 and c.scrnr_seq = ?2")
	public CP_CC_SCRNR_HSHLD_INFO_Cargo[]  getByAppNumScrnrSeq(String appNum,String scrnrSeq);

}
