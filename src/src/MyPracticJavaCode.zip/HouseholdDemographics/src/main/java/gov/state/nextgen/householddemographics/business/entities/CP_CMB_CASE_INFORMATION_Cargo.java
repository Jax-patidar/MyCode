/*
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class CP_CMB_CASE_INFORMATION_Cargo extends AbstractCargo {

	/**
	 *
	 */
	boolean isDirty = false;
	private String case_num;
	private String program_type_cd;
	private String approved_dt;
	@JsonFormat(pattern = "dd-MM-yy HH:mm:ss")
	private java.time.LocalDateTime renewal_dt;
	private String verification_type_cd;
	private String negative_Status_RSN_Code;
	private String current_Mnt_Benefit_Status_Cd;
	private String case_status;
	private boolean enable;
	private String review_pending_cd;
	private String is_renewal_submitted;
	
	


	public String getReview_pending_cd() {
		return review_pending_cd;
	}

	public void setReview_pending_cd(String review_pending_cd) {
		this.review_pending_cd = review_pending_cd;
	}

	public String getIs_renewal_submitted() {
		return is_renewal_submitted;
	}

	public void setIs_renewal_submitted(String is_renewal_submitted) {
		this.is_renewal_submitted = is_renewal_submitted;
	}

	/**
	 * @return the case_status
	 */
	public String getCase_status() {
		return case_status;
	}

	/**
	 * @param case_status the case_status to set
	 */
	public void setCase_status(final String case_status) {
		this.case_status = case_status;
	}

	/**
	 * @return the case_num
	 */
	public String getCase_num() {
		return case_num;
	}

	public String getNegative_Status_RSN_Code() {
		return negative_Status_RSN_Code;
	}

	public void setNegative_Status_RSN_Code(final String negative_Status_RSN_Code) {
		this.negative_Status_RSN_Code = negative_Status_RSN_Code;
	}

	public String getCurrent_Mnt_Benefit_Status_Cd() {
		return current_Mnt_Benefit_Status_Cd;
	}

	public void setCurrent_Mnt_Benefit_Status_Cd(final String current_Mnt_Benefit_Status_Cd) {
		this.current_Mnt_Benefit_Status_Cd = current_Mnt_Benefit_Status_Cd;
	}

	/**
	 * @param case_num
	 *            the case_num to set
	 */
	public void setCase_num(final String case_num) {
		this.case_num = case_num;
	}

	/**
	 * @return the program_type_cd
	 */
	public String getProgram_type_cd() {
		return program_type_cd;
	}

	/**
	 * @param program_type_cd
	 *            the program_type_cd to set
	 */
	public void setProgram_type_cd(final String program_type_cd) {
		this.program_type_cd = program_type_cd;
	}

	/**
	 * @return the approved_dt
	 */
	public String getApproved_dt() {
		return approved_dt;
	}

	/**
	 * @param approved_dt
	 *            the approved_dt to set
	 */
	public void setApproved_dt(final String approved_dt) {
		this.approved_dt = approved_dt;
	}

	/**
	 * @return the renewal_dt
	 */
	public java.time.LocalDateTime getRenewal_dt() {
		return renewal_dt;
	}

	/**
	 * @param renewal_dt
	 *            the renewal_dt to set
	 */
	public void setRenewal_dt(final java.time.LocalDateTime renewal_dt) {
		this.renewal_dt = renewal_dt;
	}

	/**
	 * @return the verification_type_cd
	 */
	public String getVerification_type_cd() {
		return verification_type_cd;
	}

	/**
	 * @param verification_type_cd
	 *            the verification_type_cd to set
	 */
	public void setVerification_type_cd(final String verification_type_cd) {
		this.verification_type_cd = verification_type_cd;
	}

	/**
	 * @return the enable
	 */
	public boolean isEnable() {
		return enable;
	}

	/**
	 * @param enable the enable to set
	 */
	public void setEnable(final boolean enable) {
		this.enable = enable;
	}


	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((approved_dt == null) ? 0 : approved_dt.trim().hashCode());
		result = (prime * result) + ((case_num == null) ? 0 : case_num.trim().hashCode());
		result = (prime * result) + ((program_type_cd == null) ? 0 : program_type_cd.trim().hashCode());
		result = (prime * result) + ((verification_type_cd == null) ? 0 : verification_type_cd.trim().hashCode());
		result = (prime * result) + ((review_pending_cd == null) ? 0 : review_pending_cd.trim().hashCode());
		result = (prime * result) + ((is_renewal_submitted == null) ? 0 : is_renewal_submitted.trim().hashCode());
		return result;
	}

	
}
