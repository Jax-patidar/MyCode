package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class IndividualDetailsResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String firstName;
	private String lastName;
	private String middleInitial;
	private String suffixName;
	private String last4ssn;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date dateOfBirth;
	private String genderCode;
	private String primaryPersonSw;
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleInitial() {
		return middleInitial;
	}
	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}
	public String getSuffixName() {
		return suffixName;
	}
	public void setSuffixName(String suffixName) {
		this.suffixName = suffixName;
	}
	public String getLast4ssn() {
		return last4ssn;
	}
	public void setLast4ssn(String last4ssn) {
		this.last4ssn = last4ssn;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getGenderCode() {
		return genderCode;
	}
	public void setGenderCode(String genderCode) {
		this.genderCode = genderCode;
	}
	public String getPrimaryPersonSw() {
		return primaryPersonSw;
	}
	public void setPrimaryPersonSw(String primaryPersonSw) {
		this.primaryPersonSw = primaryPersonSw;
	}
	
	

	
}
