package gov.state.nextgen.householddemographics.business.services;

import org.springframework.stereotype.Service;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.amazonaws.services.sqs.model.SendMessageResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.householddemographics.configuration.AWSProperties;
import gov.state.nextgen.householddemographics.model.SQSResponse;

/**
 * AWS SQS Service bean for Sending/Receiving queue messages.
 * 
 * @author spoloju
 */
@Service
public class AWSSQSService {


	private AmazonSQS sqsService = null;//AmazonSQSClientBuilder.defaultClient();// remove comment in production
	
	private String awsQueue;
	AWSSQSService(AWSProperties awsConfig)
	{
		this.awsQueue = awsConfig.getTnb4RedetQueueName();
	}

	


	/**
	 * Send message to AWS SQS service
	 *
	 * @param errorResponse
	 * @return
	 */
	public SQSResponse sendMessage(FwTransaction requestBody, String queueName) {
		FwLogger.log(this.getClass(), Level.INFO, "AWSSQSService.sendMessage() - START");
		try {
			String queueUrl = sqsService.getQueueUrl(queueName).getQueueUrl();
			SendMessageRequest sendMsgRequest = new SendMessageRequest().withQueueUrl(queueUrl)
					.withMessageBody(getResponseBody(requestBody));
			FwLogger.log(this.getClass(), Level.INFO, "AWSSQSService.sendMessage() - END");
			return getSQSResponseDetails(sqsService.sendMessage(sendMsgRequest));
		}catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in AWSSQSService.sendMessage()");
		}
		return null;
		
		
	}
	
	/**
	 * Send message to AWS SQS service
	 *
	 * @param errorResponse
	 * @return
	 */
	public SQSResponse sendMessage(String requestBody, String queueName) {
		FwLogger.log(this.getClass(), Level.INFO, "AWSSQSService.sendMessage() - START");
		try {
			String queueUrl = sqsService.getQueueUrl(queueName).getQueueUrl();
			SendMessageRequest sendMsgRequest = new SendMessageRequest().withQueueUrl(queueUrl)
					.withMessageBody(requestBody);
			return getSQSResponseDetails(sqsService.sendMessage(sendMsgRequest));
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in AWSSQSService.sendMessage() " + e.getMessage(), e);
		}
		FwLogger.log(this.getClass(), Level.INFO, "AWSSQSService.sendMessage() - END");
		return null;}

	/**
	 * Prepares SQS Response object back to the UI.
	 * 
	 * @param messageResult
	 * @return
	 */
	private SQSResponse getSQSResponseDetails(SendMessageResult messageResult) {
		SQSResponse response = new SQSResponse();
		response.setMessageQueueId(messageResult.getMessageId());
		response.setStatusCode(String.valueOf(messageResult.getSdkHttpMetadata().getHttpStatusCode()));
		return response;
	}

	/**
	 * Mapping from ErrorResponse model to JSON data. This JSON Data will then be
	 * saved to SQS Queue
	 * 
	 * @param errorResponse
	 * @return
	 * @throws JsonProcessingException
	 */
	public String getResponseBody(Object object) throws JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		return objectMapper.writeValueAsString(object);
	}



}
