package gov.state.nextgen.householddemographics.business.services;


import gov.state.nextgen.access.business.entities.FwTransaction;

/**
 * Interface to Service layer of HouseholdDemographics
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

public interface HouseholdDemographicsService {

	public void callBusinessLogic(String methodName, FwTransaction txnBean);
   
}
