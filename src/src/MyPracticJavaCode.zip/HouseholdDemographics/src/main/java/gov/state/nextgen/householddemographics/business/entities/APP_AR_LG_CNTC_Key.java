package gov.state.nextgen.householddemographics.business.entities;


import java.io.Serializable;

/**
 * Primary Id Key class of CP_APP_AR_LG_CNTC
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

public class APP_AR_LG_CNTC_Key implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5599336805176741448L;
	private String app_num;
	private Integer auth_rep_seq_num;
	private String src_app_ind;
	
	public APP_AR_LG_CNTC_Key() {

	}

	public APP_AR_LG_CNTC_Key(String app_num, Integer auth_rep_seq_num, String src_app_ind) {
		super();
		this.app_num = app_num;
		
		this.auth_rep_seq_num = auth_rep_seq_num;
		this.src_app_ind = src_app_ind;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((auth_rep_seq_num == null) ? 0 : auth_rep_seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}


	

}
