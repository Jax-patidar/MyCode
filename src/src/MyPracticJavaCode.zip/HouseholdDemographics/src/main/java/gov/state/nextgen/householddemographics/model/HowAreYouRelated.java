package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.util.List;

public class HowAreYouRelated implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 5631002842311318410L;

    private List<RelationshipDtls> relationshipDtlsList;
    private String relation;
    private String iDontknow;
    private String chgDt;

    private String dispText;
    private String chgDate;

    private String[] sub;
    private String[] sub1;
    private boolean originalSelectedYesNo;
    private String suffix;

    public String getSuffix() {
        return suffix;
    }
    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }
    public List<RelationshipDtls> getRelationshipDtlsList() {
        return relationshipDtlsList;
    }
    public void setRelationshipDtlsList(List<RelationshipDtls> relationshipDtlsList) {
        this.relationshipDtlsList = relationshipDtlsList;
    }
    public boolean isOriginalSelectedYesNo() {
        return originalSelectedYesNo;
    }
    public void setOriginalSelectedYesNo(boolean originalSelectedYesNo) {
        this.originalSelectedYesNo = originalSelectedYesNo;
    }
    public String[] getSub() {
        return sub;
    }
    public void setSub(String[] sub) {
        this.sub = sub;
    }
    public String[] getSub1() {
        return sub1;
    }
    public void setSub1(String[] sub1) {
        this.sub1 = sub1;
    }
    public String getChgDate() {
        return chgDate;
    }
    public void setChgDate(String chgDate) {
        this.chgDate = chgDate;
    }
    public String getDispText() {
        return dispText;
    }
    public void setDispText(String dispText) {
        this.dispText = dispText;
    }
    public String getRelation() {
        return relation;
    }
    public void setRelation(String relation) {
        this.relation = relation;
    }
    public String getiDontknow() {
        return iDontknow;
    }
    public void setiDontknow(String iDontknow) {
        this.iDontknow = iDontknow;
    }
    public String getChgDt() {
        return chgDt;
    }
    public void setChgDt(String chgDt) {
        this.chgDt = chgDt;
    }

}
