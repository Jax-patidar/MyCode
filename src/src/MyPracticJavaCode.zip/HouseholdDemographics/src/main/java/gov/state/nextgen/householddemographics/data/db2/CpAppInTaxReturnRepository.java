package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Key;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Collection;

@Repository
public interface CpAppInTaxReturnRepository extends CrudRepository<CP_APP_IN_TAX_RETURN_Cargo, CP_APP_IN_TAX_RETURN_Key>{
	
	@Query("select c from CP_APP_IN_TAX_RETURN_Cargo c where c.app_number =?1 and c.src_app_ind = ?2 and c.indv_seq_num IN ?3")
	public CP_APP_IN_TAX_RETURN_Collection loadTaxInfo(Integer appNumber, String src_ind, List<Integer> indvIds);

	@Query("select c from CP_APP_IN_TAX_RETURN_Cargo c where c.app_number =?1 and c.src_app_ind = ?2 and c.indv_seq_num = ?3")
	public CP_APP_IN_TAX_RETURN_Collection loadTaxRetInfo(Integer appNum, String src_ind, Integer indv_seq_num);

	@Transactional
	@Modifying
	@Query("DELETE from CP_APP_IN_TAX_RETURN_Cargo where app_number =?1 and indv_seq_num = ?2 and src_app_ind = ?3")
	public void deleteTaxRetData(Integer appNum, Integer indv_seq_num, String src_ind);
	
	@Query("select c from CP_APP_IN_TAX_RETURN_Cargo c where app_number = ?1 and c.indv_seq_num IN ?2")
	public CP_APP_IN_TAX_RETURN_Cargo[] loadTaxFilerSummary(Integer appnum, List<Integer> indvIds);
	//added for CSPM-14999
	@Query("select c from CP_APP_IN_TAX_RETURN_Cargo c where c.app_number = ?1")
	public CP_APP_IN_TAX_RETURN_Collection loadTaxtReturninfo(Integer appNumber);
	
	@Transactional
	@Modifying
	@Query("update CP_APP_IN_TAX_RETURN_Cargo c set c.primary_filer_sw = 'N' where c.app_number = ?1 and c.src_app_ind = ?2 and c.indv_seq_num <> ?3")
	public void updateOthersPrimSw(Integer appNumber, String srcInd, Integer indvSeqNum);

}
