package gov.state.nextgen.householddemographics.business.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import java.io.Serializable;
import java.sql.Timestamp;


public class CP_RMC_IN_PRFL_Cargo implements Serializable{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="app_num" )
    private String appNum;
    
	@Id
    @Column(name="indv_seq_num")
    private String indvSeqNum;
	
	@Column (name="almy_rcv_resp"   )
    private String almy_rcv_resp;
	@Column (name="dabl_resp"   )
    private String dabl_resp;
	@Column (name="med_exp_resp"   )
    private String med_exp_resp;
	@Column (name="preg_resp"   )
    private String preg_resp;
	@Column (name="update_dt"   )
    private Timestamp updt_dt;
	@Column (name="work_comp_resp"   )
    private String work_comp_resp;
	@Column (name="other_resp"   )
    private String other_resp;
	@Column (name="none_resp"   )
    private String none_resp;
	@Column (name="current_past_job_resp"   )
    private String current_past_job_resp;
	@Column (name="food_clothing_util_rent_resp"   )
    private String food_clothing_util_rent_resp;
	@Column (name="insurance_settlement_resp"   )
    private String insurance_settlement_resp;
	@Column (name="liquid_asset_bank_acc_resp"   )
    private String liquid_asset_bank_acc_resp;
	@Column (name="liquid_asset_pension_plan_resp"   )
    private String liquid_asset_pension_plan_resp;
    @Column (name="liquid_asset_promissory_resp"   )
    private String liquid_asset_promissory_resp;
    @Column (name="liquid_asset_retirement_resp"   )
    private String liquid_asset_retirement_resp;
    @Column (name="moved_into_home_response"   )
    private String moved_into_home_response;
    @Column(name="moved_out_of_home_resp")
    private String movedOutOfHomeResp;
    @Column (name="new_job_resp"   )
    private String new_job_resp;
    @Column (name="other_asset_veh_resp"   )
    private String other_asset_vehicle_resp;
    @Column (name="PAROLE_VIOLATION_RESP"   )
    private String parole_violation_resp;
    @Column (name="lottery_prize_winning_resp"   )
    private String lottery_prize_winning_resp;
    @Column (name="real_asset_home_resp"   )
    private String real_asset_home_resp;
    @Column (name="room_board_resp"   )
    private String room_board_resp;
    @Column (name="school_enrollment_resp"   )
    private String school_enrollment_resp;
    @Column (name="benefits_on_strike_resp"   )
    private String benefits_on_strike_resp;
    @Column (name="cntct_info")
    private String cntct_info;
    @Column (name="child_care_resp"   )
    private String child_care_resp;
    @Column (name="pers_prop_oth_val"   )
    private String pers_prop_oth_val;
    @Column (name="voluntarily_quit_job_resp"   )
    private String voluntarily_quit_job_resp;
    @Column (name="tax_deduct_resp"   )
    private String tax_deduct_resp;
    @Column (name="dabl_stat_ind"   )
    private String dabl_stat_ind;
    @Column (name="asset_xfer_change_ind"   )
    private String aset_xfer_chg_ind;
    @Column (name="add_change_ind"   )
    private String add_chg_ind;
    @Column (name="child_support_payment_change_ind"   )
    private String child_support_payment_chg_ind;
    @Column (name="hous_bill_change_ind"   )
    private String hous_bill_chg_ind;
    @Column (name="other_income_change_ind"   )
    private String othr_incm_chg_ind;
    @Column (name="personal_info"   )
    private String personal_info;
    @Column (name="loan_repayment_income"   )
    private String loan_repayment_income;
    @Column (name="STRIKE_BENEFITS"   )
    private String strike_benefits;
    @Column (name="INCLUDED_UNEARNED_INCOME"   )
    private String included_unearned_income;
    @Column (name="CHILD_SUPPORT_COURT"   )
    private String child_support_court;
    @Column (name="IN_KIND_SUPPORT"   )
    private String in_kind_support;
    @Column (name="MRTL_STAT_CHANGE_IND"   )
    private String mrtl_stat_chg_ind;
    private String deceased_ind;
    private String child_spousal_support_ind;
    private String giftmoney_loans_resp;
    private String rental_royalties_resp;
    private String insurance_legal_settlmnt_resp;
    private String farmng_fshng_resp;
    private String dividend_intrst_income_resp;
    private String housing_bill_hless_shlt_resp;
    private String out_of_pockt_dep_care_cost_ind;
    private String rent_mortgage_ind;
    private String property_taxes_insurance_ind;
    private String medcl_costs_ind;
    private String duplicate_food_assistance_ind;
    private String selling_sharing_ebt_card_ind;
    private String trading_foodassistance_drug_ind;
    private String trading_foodassistance_guns_amunitions_explosive_ind;
    private String avoid_jail_for_felony_ind;
    private String con_info_change_ind;
    private String work_ind;
    private String imm_ind;
    private String insurance_ind;
    private String cust_ind;
    private String schl_atd_ind;
    private String ihss_ind;
    private String someone_paid_ind;
    @Column (name="healthy_baby_change_ind"   )
    private String hlthy_baby_chg_ind;
    private String hless_stat_sw;
    @Column (name="VEH_ASSET_CHANGE_IND"   )
    private String veh_aset_chg_ind;
    @Transient
    private String uei_net_rent_royalty;
    @Column (name="UEI_LOTTERY_WIN_RESP"   )
    private String uei_lottery_win;
    @Column (name="UEI_PENSION_RESP"   )
    private String uei_pension;
    @Transient
    private String bnft_dabl_resp;
    private String fishing_resp;
    @Transient
    private String uei_int_div_pymt;
	public String getAppNum() {
		return appNum;
	}
	public String getIndvSeqNum() {
		return indvSeqNum;
	}
	public String getAlmy_rcv_resp() {
		return almy_rcv_resp;
	}
	public String getDabl_resp() {
		return dabl_resp;
	}
	public String getMed_exp_resp() {
		return med_exp_resp;
	}
	public String getPreg_resp() {
		return preg_resp;
	}
	public Timestamp getUpdt_dt() {
		return updt_dt;
	}
	public String getWork_comp_resp() {
		return work_comp_resp;
	}
	public String getOther_resp() {
		return other_resp;
	}
	public String getNone_resp() {
		return none_resp;
	}
	public String getCurrent_past_job_resp() {
		return current_past_job_resp;
	}
	public String getFood_clothing_util_rent_resp() {
		return food_clothing_util_rent_resp;
	}
	public String getInsurance_settlement_resp() {
		return insurance_settlement_resp;
	}
	public String getLiquid_asset_bank_acc_resp() {
		return liquid_asset_bank_acc_resp;
	}
	public String getLiquid_asset_pension_plan_resp() {
		return liquid_asset_pension_plan_resp;
	}
	public String getLiquid_asset_promissory_resp() {
		return liquid_asset_promissory_resp;
	}
	public String getLiquid_asset_retirement_resp() {
		return liquid_asset_retirement_resp;
	}
	public String getMoved_into_home_response() {
		return moved_into_home_response;
	}
	public String getMovedOutOfHomeResp() {
		return movedOutOfHomeResp;
	}
	public String getNew_job_resp() {
		return new_job_resp;
	}
	public String getOther_asset_vehicle_resp() {
		return other_asset_vehicle_resp;
	}
	public String getParole_violation_resp() {
		return parole_violation_resp;
	}
	public String getLottery_prize_winning_resp() {
		return lottery_prize_winning_resp;
	}
	public String getReal_asset_home_resp() {
		return real_asset_home_resp;
	}
	public String getRoom_board_resp() {
		return room_board_resp;
	}
	public String getSchool_enrollment_resp() {
		return school_enrollment_resp;
	}
	public String getBenefits_on_strike_resp() {
		return benefits_on_strike_resp;
	}
	public String getCntct_info() {
		return cntct_info;
	}
	public String getChild_care_resp() {
		return child_care_resp;
	}
	public String getPers_prop_oth_val() {
		return pers_prop_oth_val;
	}
	public String getVoluntarily_quit_job_resp() {
		return voluntarily_quit_job_resp;
	}
	public String getTax_deduct_resp() {
		return tax_deduct_resp;
	}
	public String getDabl_stat_ind() {
		return dabl_stat_ind;
	}
	public String getAset_xfer_chg_ind() {
		return aset_xfer_chg_ind;
	}
	public String getAdd_chg_ind() {
		return add_chg_ind;
	}
	public String getChild_support_payment_chg_ind() {
		return child_support_payment_chg_ind;
	}
	public String getHous_bill_chg_ind() {
		return hous_bill_chg_ind;
	}
	public String getOthr_incm_chg_ind() {
		return othr_incm_chg_ind;
	}
	public String getPersonal_info() {
		return personal_info;
	}
	public String getLoan_repayment_income() {
		return loan_repayment_income;
	}
	public String getStrike_benefits() {
		return strike_benefits;
	}
	public String getIncluded_unearned_income() {
		return included_unearned_income;
	}
	public String getChild_support_court() {
		return child_support_court;
	}
	public String getIn_kind_support() {
		return in_kind_support;
	}
	public String getMrtl_stat_chg_ind() {
		return mrtl_stat_chg_ind;
	}
	public String getDeceased_ind() {
		return deceased_ind;
	}
	public String getChild_spousal_support_ind() {
		return child_spousal_support_ind;
	}
	public String getGiftmoney_loans_resp() {
		return giftmoney_loans_resp;
	}
	public String getRental_royalties_resp() {
		return rental_royalties_resp;
	}
	public String getInsurance_legal_settlmnt_resp() {
		return insurance_legal_settlmnt_resp;
	}
	public String getFarmng_fshng_resp() {
		return farmng_fshng_resp;
	}
	public String getDividend_intrst_income_resp() {
		return dividend_intrst_income_resp;
	}
	public String getHousing_bill_hless_shlt_resp() {
		return housing_bill_hless_shlt_resp;
	}
	public String getOut_of_pockt_dep_care_cost_ind() {
		return out_of_pockt_dep_care_cost_ind;
	}
	public String getRent_mortgage_ind() {
		return rent_mortgage_ind;
	}
	public String getProperty_taxes_insurance_ind() {
		return property_taxes_insurance_ind;
	}
	public String getMedcl_costs_ind() {
		return medcl_costs_ind;
	}
	public String getDuplicate_food_assistance_ind() {
		return duplicate_food_assistance_ind;
	}
	public String getSelling_sharing_ebt_card_ind() {
		return selling_sharing_ebt_card_ind;
	}
	public String getTrading_foodassistance_drug_ind() {
		return trading_foodassistance_drug_ind;
	}
	public String getTrading_foodassistance_guns_amunitions_explosive_ind() {
		return trading_foodassistance_guns_amunitions_explosive_ind;
	}
	public String getAvoid_jail_for_felony_ind() {
		return avoid_jail_for_felony_ind;
	}
	public String getCon_info_change_ind() {
		return con_info_change_ind;
	}
	public String getWork_ind() {
		return work_ind;
	}
	public String getImm_ind() {
		return imm_ind;
	}
	public String getInsurance_ind() {
		return insurance_ind;
	}
	public String getCust_ind() {
		return cust_ind;
	}
	public String getSchl_atd_ind() {
		return schl_atd_ind;
	}
	public String getIhss_ind() {
		return ihss_ind;
	}
	public String getSomeone_paid_ind() {
		return someone_paid_ind;
	}
	public String getHlthy_baby_chg_ind() {
		return hlthy_baby_chg_ind;
	}
	public String getHless_stat_sw() {
		return hless_stat_sw;
	}
	public String getVeh_aset_chg_ind() {
		return veh_aset_chg_ind;
	}
	public String getUei_net_rent_royalty() {
		return uei_net_rent_royalty;
	}
	public String getUei_lottery_win() {
		return uei_lottery_win;
	}
	public String getUei_pension() {
		return uei_pension;
	}
	public String getBnft_dabl_resp() {
		return bnft_dabl_resp;
	}
	public String getFishing_resp() {
		return fishing_resp;
	}
	public String getUei_int_div_pymt() {
		return uei_int_div_pymt;
	}
	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}
	public void setIndvSeqNum(String indvSeqNum) {
		this.indvSeqNum = indvSeqNum;
	}
	public void setAlmy_rcv_resp(String almy_rcv_resp) {
		this.almy_rcv_resp = almy_rcv_resp;
	}
	public void setDabl_resp(String dabl_resp) {
		this.dabl_resp = dabl_resp;
	}
	public void setMed_exp_resp(String med_exp_resp) {
		this.med_exp_resp = med_exp_resp;
	}
	public void setPreg_resp(String preg_resp) {
		this.preg_resp = preg_resp;
	}
	public void setUpdt_dt(Timestamp updt_dt) {
		this.updt_dt = updt_dt;
	}
	public void setWork_comp_resp(String work_comp_resp) {
		this.work_comp_resp = work_comp_resp;
	}
	public void setOther_resp(String other_resp) {
		this.other_resp = other_resp;
	}
	public void setNone_resp(String none_resp) {
		this.none_resp = none_resp;
	}
	public void setCurrent_past_job_resp(String current_past_job_resp) {
		this.current_past_job_resp = current_past_job_resp;
	}
	public void setFood_clothing_util_rent_resp(String food_clothing_util_rent_resp) {
		this.food_clothing_util_rent_resp = food_clothing_util_rent_resp;
	}
	public void setInsurance_settlement_resp(String insurance_settlement_resp) {
		this.insurance_settlement_resp = insurance_settlement_resp;
	}
	public void setLiquid_asset_bank_acc_resp(String liquid_asset_bank_acc_resp) {
		this.liquid_asset_bank_acc_resp = liquid_asset_bank_acc_resp;
	}
	public void setLiquid_asset_pension_plan_resp(String liquid_asset_pension_plan_resp) {
		this.liquid_asset_pension_plan_resp = liquid_asset_pension_plan_resp;
	}
	public void setLiquid_asset_promissory_resp(String liquid_asset_promissory_resp) {
		this.liquid_asset_promissory_resp = liquid_asset_promissory_resp;
	}
	public void setLiquid_asset_retirement_resp(String liquid_asset_retirement_resp) {
		this.liquid_asset_retirement_resp = liquid_asset_retirement_resp;
	}
	public void setMoved_into_home_response(String moved_into_home_response) {
		this.moved_into_home_response = moved_into_home_response;
	}
	public void setMovedOutOfHomeResp(String movedOutOfHomeResp) {
		this.movedOutOfHomeResp = movedOutOfHomeResp;
	}
	public void setNew_job_resp(String new_job_resp) {
		this.new_job_resp = new_job_resp;
	}
	public void setOther_asset_vehicle_resp(String other_asset_vehicle_resp) {
		this.other_asset_vehicle_resp = other_asset_vehicle_resp;
	}
	public void setParole_violation_resp(String parole_violation_resp) {
		this.parole_violation_resp = parole_violation_resp;
	}
	public void setLottery_prize_winning_resp(String lottery_prize_winning_resp) {
		this.lottery_prize_winning_resp = lottery_prize_winning_resp;
	}
	public void setReal_asset_home_resp(String real_asset_home_resp) {
		this.real_asset_home_resp = real_asset_home_resp;
	}
	public void setRoom_board_resp(String room_board_resp) {
		this.room_board_resp = room_board_resp;
	}
	public void setSchool_enrollment_resp(String school_enrollment_resp) {
		this.school_enrollment_resp = school_enrollment_resp;
	}
	public void setBenefits_on_strike_resp(String benefits_on_strike_resp) {
		this.benefits_on_strike_resp = benefits_on_strike_resp;
	}
	public void setCntct_info(String cntct_info) {
		this.cntct_info = cntct_info;
	}
	public void setChild_care_resp(String child_care_resp) {
		this.child_care_resp = child_care_resp;
	}
	public void setPers_prop_oth_val(String pers_prop_oth_val) {
		this.pers_prop_oth_val = pers_prop_oth_val;
	}
	public void setVoluntarily_quit_job_resp(String voluntarily_quit_job_resp) {
		this.voluntarily_quit_job_resp = voluntarily_quit_job_resp;
	}
	public void setTax_deduct_resp(String tax_deduct_resp) {
		this.tax_deduct_resp = tax_deduct_resp;
	}
	public void setDabl_stat_ind(String dabl_stat_ind) {
		this.dabl_stat_ind = dabl_stat_ind;
	}
	public void setAset_xfer_chg_ind(String aset_xfer_chg_ind) {
		this.aset_xfer_chg_ind = aset_xfer_chg_ind;
	}
	public void setAdd_chg_ind(String add_chg_ind) {
		this.add_chg_ind = add_chg_ind;
	}
	public void setChild_support_payment_chg_ind(String child_support_payment_chg_ind) {
		this.child_support_payment_chg_ind = child_support_payment_chg_ind;
	}
	public void setHous_bill_chg_ind(String hous_bill_chg_ind) {
		this.hous_bill_chg_ind = hous_bill_chg_ind;
	}
	public void setOthr_incm_chg_ind(String othr_incm_chg_ind) {
		this.othr_incm_chg_ind = othr_incm_chg_ind;
	}
	public void setPersonal_info(String personal_info) {
		this.personal_info = personal_info;
	}
	public void setLoan_repayment_income(String loan_repayment_income) {
		this.loan_repayment_income = loan_repayment_income;
	}
	public void setStrike_benefits(String strike_benefits) {
		this.strike_benefits = strike_benefits;
	}
	public void setIncluded_unearned_income(String included_unearned_income) {
		this.included_unearned_income = included_unearned_income;
	}
	public void setChild_support_court(String child_support_court) {
		this.child_support_court = child_support_court;
	}
	public void setIn_kind_support(String in_kind_support) {
		this.in_kind_support = in_kind_support;
	}
	public void setMrtl_stat_chg_ind(String mrtl_stat_chg_ind) {
		this.mrtl_stat_chg_ind = mrtl_stat_chg_ind;
	}
	public void setDeceased_ind(String deceased_ind) {
		this.deceased_ind = deceased_ind;
	}
	public void setChild_spousal_support_ind(String child_spousal_support_ind) {
		this.child_spousal_support_ind = child_spousal_support_ind;
	}
	public void setGiftmoney_loans_resp(String giftmoney_loans_resp) {
		this.giftmoney_loans_resp = giftmoney_loans_resp;
	}
	public void setRental_royalties_resp(String rental_royalties_resp) {
		this.rental_royalties_resp = rental_royalties_resp;
	}
	public void setInsurance_legal_settlmnt_resp(String insurance_legal_settlmnt_resp) {
		this.insurance_legal_settlmnt_resp = insurance_legal_settlmnt_resp;
	}
	public void setFarmng_fshng_resp(String farmng_fshng_resp) {
		this.farmng_fshng_resp = farmng_fshng_resp;
	}
	public void setDividend_intrst_income_resp(String dividend_intrst_income_resp) {
		this.dividend_intrst_income_resp = dividend_intrst_income_resp;
	}
	public void setHousing_bill_hless_shlt_resp(String housing_bill_hless_shlt_resp) {
		this.housing_bill_hless_shlt_resp = housing_bill_hless_shlt_resp;
	}
	public void setOut_of_pockt_dep_care_cost_ind(String out_of_pockt_dep_care_cost_ind) {
		this.out_of_pockt_dep_care_cost_ind = out_of_pockt_dep_care_cost_ind;
	}
	public void setRent_mortgage_ind(String rent_mortgage_ind) {
		this.rent_mortgage_ind = rent_mortgage_ind;
	}
	public void setProperty_taxes_insurance_ind(String property_taxes_insurance_ind) {
		this.property_taxes_insurance_ind = property_taxes_insurance_ind;
	}
	public void setMedcl_costs_ind(String medcl_costs_ind) {
		this.medcl_costs_ind = medcl_costs_ind;
	}
	public void setDuplicate_food_assistance_ind(String duplicate_food_assistance_ind) {
		this.duplicate_food_assistance_ind = duplicate_food_assistance_ind;
	}
	public void setSelling_sharing_ebt_card_ind(String selling_sharing_ebt_card_ind) {
		this.selling_sharing_ebt_card_ind = selling_sharing_ebt_card_ind;
	}
	public void setTrading_foodassistance_drug_ind(String trading_foodassistance_drug_ind) {
		this.trading_foodassistance_drug_ind = trading_foodassistance_drug_ind;
	}
	public void setTrading_foodassistance_guns_amunitions_explosive_ind(
			String trading_foodassistance_guns_amunitions_explosive_ind) {
		this.trading_foodassistance_guns_amunitions_explosive_ind = trading_foodassistance_guns_amunitions_explosive_ind;
	}
	public void setAvoid_jail_for_felony_ind(String avoid_jail_for_felony_ind) {
		this.avoid_jail_for_felony_ind = avoid_jail_for_felony_ind;
	}
	public void setCon_info_change_ind(String con_info_change_ind) {
		this.con_info_change_ind = con_info_change_ind;
	}
	public void setWork_ind(String work_ind) {
		this.work_ind = work_ind;
	}
	public void setImm_ind(String imm_ind) {
		this.imm_ind = imm_ind;
	}
	public void setInsurance_ind(String insurance_ind) {
		this.insurance_ind = insurance_ind;
	}
	public void setCust_ind(String cust_ind) {
		this.cust_ind = cust_ind;
	}
	public void setSchl_atd_ind(String schl_atd_ind) {
		this.schl_atd_ind = schl_atd_ind;
	}
	public void setIhss_ind(String ihss_ind) {
		this.ihss_ind = ihss_ind;
	}
	public void setSomeone_paid_ind(String someone_paid_ind) {
		this.someone_paid_ind = someone_paid_ind;
	}
	public void setHlthy_baby_chg_ind(String hlthy_baby_chg_ind) {
		this.hlthy_baby_chg_ind = hlthy_baby_chg_ind;
	}
	public void setHless_stat_sw(String hless_stat_sw) {
		this.hless_stat_sw = hless_stat_sw;
	}
	public void setVeh_aset_chg_ind(String veh_aset_chg_ind) {
		this.veh_aset_chg_ind = veh_aset_chg_ind;
	}
	public void setUei_net_rent_royalty(String uei_net_rent_royalty) {
		this.uei_net_rent_royalty = uei_net_rent_royalty;
	}
	public void setUei_lottery_win(String uei_lottery_win) {
		this.uei_lottery_win = uei_lottery_win;
	}
	public void setUei_pension(String uei_pension) {
		this.uei_pension = uei_pension;
	}
	public void setBnft_dabl_resp(String bnft_dabl_resp) {
		this.bnft_dabl_resp = bnft_dabl_resp;
	}
	public void setFishing_resp(String fishing_resp) {
		this.fishing_resp = fishing_resp;
	}
	public void setUei_int_div_pymt(String uei_int_div_pymt) {
		this.uei_int_div_pymt = uei_int_div_pymt;
	}
    
    
    
    
}