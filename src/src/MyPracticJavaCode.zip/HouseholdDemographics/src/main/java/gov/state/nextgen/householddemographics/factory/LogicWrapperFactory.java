package gov.state.nextgen.householddemographics.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.exceptions.BusinessWrappedNotInstantiatedException;

/**
 * Class for View wrapper configuration.
 * 
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */
@Component
@Scope("singleton")
public class LogicWrapperFactory {

	private static final Logger log = LoggerFactory.getLogger(LogicWrapperFactory.class);

	private static final String UNDERSCORE = "_";



	/**
	 * This method returns the instance of ResponseBean bean associated for the
	 * pageId passed.
	 * 
	 * @param pageId
	 * @return
	 */
	public static LogicResponseInterface createPageResponse(String pageId)
			throws BusinessWrappedNotInstantiatedException {

		try (AnnotationConfigApplicationContext springContext = new AnnotationConfigApplicationContext(
				LogicWrapperConfig.class);) {

			LogicResponseInterface responseBean = (LogicResponseInterface) springContext.getBean(pageId);

			return responseBean;

		} catch (BeansException be) {

			StringBuilder message = new StringBuilder();

			message.append("Response Bean associated to Page Id: ");
			message.append(pageId);
			message.append("could not be created");
			log.error(message.toString(), be);
			throw new BusinessWrappedNotInstantiatedException(message.toString());
		}
	}
	
	
}
