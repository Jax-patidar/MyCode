package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name="cp_app_automated_sms",schema = "IE_SSP_OWNER_HH")
public class CP_AUTOMATED_SMS_Cargo extends AbstractCargo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Long sms_id;
	private String from_number;
    private String to_number;
    private String text_message;
    private Date text_sent_date;
    private String flow_name;
    private String app_case_num;
    private String notification_status;
    private String start_hour;
    
	
	public Long getSms_id() {
		return sms_id;
	}
	public void setSms_id(Long sms_id) {
		this.sms_id = sms_id;
	}
	public String getFrom_number() {
		return from_number;
	}
	public void setFrom_number(String from_number) {
		this.from_number = from_number;
	}
	public String getTo_number() {
		return to_number;
	}
	public void setTo_number(String to_number) {
		this.to_number = to_number;
	}
	public String getText_message() {
		return text_message;
	}
	public void setText_message(String text_message) {
		this.text_message = text_message;
	}
	public Date getText_sent_date() {
		return text_sent_date;
	}
	public void setText_sent_date(Date text_sent_date) {
		this.text_sent_date = text_sent_date;
	}
	public String getFlow_name() {
		return flow_name;
	}
	public void setFlow_name(String flow_name) {
		this.flow_name = flow_name;
	}
	public String getApp_case_num() {
		return app_case_num;
	}
	public void setApp_case_num(String app_case_num) {
		this.app_case_num = app_case_num;
	}
	public String getNotification_status() {
		return notification_status;
	}
	public void setNotification_status(String notification_status) {
		this.notification_status = notification_status;
	}
	public String getStart_hour() {
		return start_hour;
	}
	public void setStart_hour(String start_hour) {
		this.start_hour = start_hour;
	}
    
}
