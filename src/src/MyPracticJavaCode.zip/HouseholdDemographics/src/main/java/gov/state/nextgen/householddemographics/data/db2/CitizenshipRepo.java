package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_ESGIN_Cargo;

@NoRepositoryBean
public interface CitizenshipRepo extends CrudRepository<CP_APP_ESGIN_Cargo,String> {
     CP_APP_ESGIN_Cargo findByAppNumAndSeqNum(String appNum, Integer seqNum);
}
