package gov.state.nextgen.householddemographics.business.rules;

import gov.state.nextgen.access.management.constants.FwConstants;

import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_ESGIN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_ESGIN_Collection;
import gov.state.nextgen.householddemographics.data.db2.CitizenshipRepo;
import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

@Component
public class ARHouseHoldMemberBO {

    private CitizenshipRepo citizenshipRepo;

    /**
     * Load citizenship declaration details using appNumber
     * @param appNumber
     * @return
     */
    public CP_APP_ESGIN_Collection loadCitizenshipDeclarationDetails(String appNumber) {
        CP_APP_ESGIN_Collection citizenColl = new CP_APP_ESGIN_Collection();
        List<CP_APP_ESGIN_Cargo> cpAppEsginCargos = Arrays.asList(citizenshipRepo.findByAppNumAndSeqNum(appNumber,  Integer.valueOf(FwConstants.ONE)));
        if(!CollectionUtils.isEmpty(cpAppEsginCargos)){
            citizenColl.setResults(cpAppEsginCargos.toArray(new CP_APP_ESGIN_Cargo[cpAppEsginCargos.size()]));
        }
        return citizenColl;
    }

    public FwMessageList validateCitizenDetails(CP_APP_ESGIN_Collection esignColl) {
        return null;
    }

    /**
     * Save the Citizenship Application cargo
     * @param esignColl
     */
    public void storeCitizenshipDeclaration(CP_APP_ESGIN_Collection esignColl) {
     try {	
        if(!ArrayUtils.isEmpty(esignColl.getResults())){
            CP_APP_ESGIN_Cargo cpAppEsginCargo = esignColl.getCargo(0);
            citizenshipRepo.save(cpAppEsginCargo);
        }
     }catch(Exception e) {
    	 throw e;
     }
    }
}
