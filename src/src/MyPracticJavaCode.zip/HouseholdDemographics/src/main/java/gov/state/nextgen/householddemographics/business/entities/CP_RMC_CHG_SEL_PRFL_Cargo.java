package gov.state.nextgen.householddemographics.business.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;

public class CP_RMC_CHG_SEL_PRFL_Cargo {

    @Id
    @Column(name="app_num" )
    private String appNum;

    @Column (name="indv_seq_num" )
    private String indvSeqNum;

    @Column (name="chg_sel_cat_cd" )
    private String chg_sel_cat_cd;

    @Column (name="cat_seq_num" )
    private BigDecimal cat_seq_num;

    @Column (name="cat_typ" )
    private String cat_typ;

    @Column (name="STAT_IND"   )
    private String stat_ind;

    @Column (name="USER_END_SEL_IND"   )
    private BigDecimal user_end_sel_ind;

    public String getAppNum() {
        return appNum;
    }

    public void setAppNum(String appNum) {
        this.appNum = appNum;
    }

    public String getIndvSeqNum() {
        return indvSeqNum;
    }

    public void setIndvSeqNum(String indvSeqNum) {
        this.indvSeqNum = indvSeqNum;
    }

    public String getChg_sel_cat_cd() {
        return chg_sel_cat_cd;
    }

    public void setChg_sel_cat_cd(String chg_sel_cat_cd) {
        this.chg_sel_cat_cd = chg_sel_cat_cd;
    }

    public BigDecimal getCat_seq_num() {
        return cat_seq_num;
    }

    public void setCat_seq_num(BigDecimal cat_seq_num) {
        this.cat_seq_num = cat_seq_num;
    }

    public String getCat_typ() {
        return cat_typ;
    }

    public void setCat_typ(String cat_typ) {
        this.cat_typ = cat_typ;
    }

    public String getStat_ind() {
        return stat_ind;
    }

    public void setStat_ind(String stat_ind) {
        this.stat_ind = stat_ind;
    }

    public BigDecimal getUser_end_sel_ind() {
        return user_end_sel_ind;
    }

    public void setUser_end_sel_ind(BigDecimal user_end_sel_ind) {
        this.user_end_sel_ind = user_end_sel_ind;
    }
}
