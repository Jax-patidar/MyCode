package gov.state.nextgen.householddemographics.business.entities;

import java.rmi.RemoteException;

import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * @author ransahu
 *
 */
public class CpAppTnb4MoveoutSsiSsp_Collection extends AbstractCollection {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6808839318866932606L;
	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.CpAppTnb4MoveoutSsiSsp";

	/**
	 * Gets the class Package.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CpAppTnb4MoveoutSsiSsp_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CpAppTnb4MoveoutSsiSsp_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CpAppTnb4MoveoutSsiSsp_Cargo[] getResults() {
		final CpAppTnb4MoveoutSsiSsp_Cargo[] cbArray = new CpAppTnb4MoveoutSsiSsp_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CpAppTnb4MoveoutSsiSsp_Cargo getCargo(final int idx) {
		return (CpAppTnb4MoveoutSsiSsp_Cargo) get(idx);
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CpAppTnb4MoveoutSsiSsp_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(Object obj) throws RemoteException {
		if (obj instanceof CpAppTnb4MoveoutSsiSsp_Cargo[]) {
			final CpAppTnb4MoveoutSsiSsp_Cargo[] cbArray = (CpAppTnb4MoveoutSsiSsp_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
