package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_TAX_RETURNS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_TAX_RETURNS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABTXS")
@Scope("prototype")
public class AFBTaxSummaryView implements LogicResponseInterface {

	private static final String PAGE_ID = "ABTXS";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();

		Map pageCollection = fwTxn.getPageCollection();
		List<CP_APP_IN_TAX_RETURN_Cargo> taxafbList = new ArrayList<CP_APP_IN_TAX_RETURN_Cargo>();
		CP_APP_IN_TAX_RETURN_Cargo taxCargo;
		
		CP_APP_IN_TAX_RETURN_Collection taxCollection = pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_RETURN_COLLECTION) != null ? (CP_APP_IN_TAX_RETURN_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_RETURN_COLLECTION) : null;
		
		if(taxCollection != null && !taxCollection.isEmpty() && taxCollection.size() > 0) {
			for(int i=0; i<taxCollection.size();i++) {
				taxCargo = taxCollection.getCargo(i);
				taxafbList.add(taxCargo);
			}	
		}
		
		List<APP_IN_TAX_RETURNS_Cargo> taxReturnsCargoList = new ArrayList<APP_IN_TAX_RETURNS_Cargo>();
		APP_IN_TAX_RETURNS_Collection taxRetursCollection = (APP_IN_TAX_RETURNS_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_IN_TAX_RETURNS_COLLECTION);
		
		if(taxRetursCollection != null && !taxRetursCollection.isEmpty() && taxRetursCollection.size() > 0) {
			taxReturnsCargoList = Arrays.asList(taxRetursCollection.getResults());
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_RETURN_COLLECTION, taxafbList);
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_IN_TAX_RETURNS_COLLECTION, taxReturnsCargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getRequest().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		return driverPageResponse;
	}

	

}
