package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABLCS")
@Scope("prototype")
public class LeavingCAResponseWrapper implements LogicResponseInterface{
	private static final String PAGE_ID = "ABLCS";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTxn.getPageCollection();
		List<APP_INDV_Cargo> appIndvList = new ArrayList<APP_INDV_Cargo>();
		APP_INDV_Cargo cpAppIndvCargo;
		APP_INDV_Collection cpAppIndvCollection = pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) != null ? (APP_INDV_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) : null;
	
		if(cpAppIndvCollection != null && !cpAppIndvCollection.isEmpty() && cpAppIndvCollection.size() >0) {			
			for (int i = 0; i < cpAppIndvCollection.size(); i++) {
				cpAppIndvCargo = (APP_INDV_Cargo) cpAppIndvCollection.get(i);
				appIndvList.add(cpAppIndvCargo);
			}
		}
		
		APP_PGM_RQST_Collection cpAppPgmRqstCollection = pageCollection.get(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL) != null ? (APP_PGM_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL) : null;
		List<APP_PGM_RQST_Cargo> appPgmRqstList = new ArrayList<APP_PGM_RQST_Cargo>();
		APP_PGM_RQST_Cargo appPgmRqstCargo;
		if(cpAppPgmRqstCollection != null && !cpAppPgmRqstCollection.isEmpty() && cpAppPgmRqstCollection.size() >0) {
		appPgmRqstCargo = (APP_PGM_RQST_Cargo)cpAppPgmRqstCollection.get(0);
		appPgmRqstList.add(appPgmRqstCargo);
		}
		
		driverPageResponse.getPageCollection().put("APP_INDV_LeavingCA_Collection", appIndvList);
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL, appPgmRqstList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		
		return driverPageResponse;
	}
}
