package gov.state.nextgen.householddemographics.business.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.serv.CaseData;
import gov.state.nextgen.householddemographics.serv.CaseDetailsResponse;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;

@Service
public class RMBRequestServiceBO {	
	
	@Autowired
    private LambdaInvokerServiceImpl service;
	
	@Autowired
    private ExceptionUtil exceptionUtil;
	
	public String prepareAWSRequest(String path, FwTransaction fwTransaction) throws Exception {
        long epoch = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss z");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
        ObjectMapper obj = new ObjectMapper();
        StringBuffer sb = new StringBuffer();
        sb.append("{   \"resource\": \"");
        sb.append("/dataexchange/{proxy+}");
        sb.append("\",   \"path\": \"");
        sb.append("/dataexchange/case-details");
        sb.append("\",   \"httpMethod\": \"");
        sb.append("GET");
        sb.append("\",   \"headers\": {     \"CORELATION_ID\":\"");
        sb.append("corelationID12345");
        sb.append("\", \"X-Amzn-Trace-Id\": \"");
        sb.append(fwTransaction.getAmznTraceId());
        sb.append("\", \"x-auth-id\": \"");
        sb.append(fwTransaction.getAuthId());
        sb.append("\", \"x-auth-token\": \"");
        sb.append(fwTransaction.getAuthToken());
        sb.append("\"},");
        sb.append("\"multiValueHeaders\": {     \"X-Amzn-Trace-Id\":");
        sb.append("[\"");
        sb.append(fwTransaction.getAmznTraceId());
        sb.append("\"],");
        sb.append("\"x-auth-id\":");
        sb.append("[\"");
        sb.append(fwTransaction.getAuthId());
        sb.append("\"],");        
        sb.append("\"x-auth-token\":");
        sb.append("[\"");
        sb.append(fwTransaction.getAuthToken());
        sb.append("\"],");        
        sb.append("\"CORELATION_ID\":");
        sb.append("[\"");
        sb.append(fwTransaction.getCoRelationID());
        sb.append("\"]},");
        sb.append("\"queryStringParameters\": { \"guID\": \"");
        sb.append(fwTransaction.getAuthId());
        sb.append("\"},");
        sb.append("\"multiValueQueryStringParameters\": {  \"guID\": [\"");
        sb.append(fwTransaction.getAuthId());
        sb.append("\"]},");       
        //sb.append("\", \"X-Amzn-Trace-Id\": \"Root=1-617c19cd-534cfb3c6ebd79d23b2b55fe\", \"x-auth-id\": \"7c50c37b-12fb-44a5-bbdf-016ccec8526d\", \"x-auth-token\": \"Bearer Wepo8UNus8iMuYBP-I1v-Pbrtyo\"},");
        //sb.append(   "\"multiValueHeaders\": {     \"X-Amzn-Trace-Id\": [ \"Root=1-617c19cd-534cfb3c6ebd79d23b2b55fe\" ],\"x-auth-id\": [   \"7c50c37b-12fb-44a5-bbdf-016ccec8526d\" ],\"x-auth-token\": [\"Bearer Wepo8UNus8iMuYBP-I1v-Pbrtyo\"  ],\"CORELATION_ID\": [ \"Bearer Wepo8UNus8iMuYBP-I1v-Pbrtyo\" ]},");
        //sb.append("\"queryStringParameters\": { \"guID\": \"7c50c37b-12fb-44a5-bbdf-016ccec8526d\" },");
        //sb.append("\"multiValueQueryStringParameters\": {  \"guID\": [\"7c50c37b-12fb-44a5-bbdf-016ccec8526d\"]},");
        sb.append("\"pathParameters\": {  \"proxy\": \"case-details\"  },");
        sb.append("\"stageVariables\": null,");
        
        sb.append("\"requestContext\": {\r\n" + 
        		"        \"resourcePath\": \"/dataexchange/{proxy+}\",\r\n" + 
        		"        \"httpMethod\": \"GET\",\r\n" + 
        		"        \"requestTime\": \"");
        sb.append(sdf.format(new Date(epoch)));
        sb.append("\",");
        sb.append("\"path\": \"");
        sb.append(path);
        sb.append("\",");
        sb.append("\"accountId\": null,\r\n" + 
        		"        \"protocol\": \"HTTP/1.1\",\r\n" + 
        		"        \"requestTimeEpoch\":\"");      
       // sb.append("\"requestContext\": {\r\n" + 
        //		"        \"resourcePath\": \"/dataexchange/{proxy+}\",\r\n" + 
        	//	"        \"httpMethod\": \"GET\",\r\n" + 
        		//"        \"requestTime\": \"sdf.format(new Date(epoch))\",\r\n" + 
        		//"        \"path\": \"/DEV-1/dataexchange/case-details\",\r\n" + 
        		//"        \"accountId\": null,\r\n" + 
        		//"        \"protocol\": \"HTTP/1.1\",\r\n" + 
        		//"        \"requestTimeEpoch\":\"");        
        sb.append(epoch);
        sb.append("\", \"requestId\": \"UniqueId\",");
        sb.append("\"identity\": {\r\n" + 
        		"            \"cognitoIdentityPoolId\": null,\r\n" + 
        		"            \"accountId\": null,\r\n" + 
        		"            \"cognitoIdentityId\": null,\r\n" + 
        		"            \"caller\": null,\r\n" + 
        		"            \"sourceIp\": null,\r\n" + 
        		"            \"principalOrgId\": null,\r\n" + 
        		"            \"accessKey\": null,\r\n" + 
        		"            \"cognitoAuthenticationType\": null,\r\n" + 
        		"            \"cognitoAuthenticationProvider\": null,\r\n" + 
        		"            \"userArn\": null,\r\n" + 
        		"            \"userAgent\":\"");
        sb.append(fwTransaction.getUserAgent());
        sb.append("\", \"user\": null\r\n" + 
        		"        },\r\n" + 
        		"        \"domainName\": \"\",\r\n" + 
        		"        \"apiId\": \"\"\r\n" + 
        		"    },");
       sb.append("\"body\": null,\r\n" + 
       		"    \"isBase64Encoded\": false }");
       FwLogger.log(this.getClass(), Level.INFO,
				"HouseholdDemographicsController DataExchange_Lambda_Function failed mapping::::finalString:::" +sb);
        return sb.toString();
    }
	
	public boolean checkCaseNumAndCountyCdAssociatedCorrect(FwTransaction fwTransaction, Map pageCollection) {
		RMB_RQST_Collection cpRmbRequestCollection = (RMB_RQST_Collection) pageCollection
				.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION);
		boolean isCaseNumAndCountyCdCorrect = true;
		if (null == cpRmbRequestCollection) {
			FwLogger.log(this.getClass(), Level.INFO,
					"HouseholdDemographicsController DataExchange_Lambda_Function failed mapping::::");
			return false;
		} else {
			try {
				RMB_RQST_Cargo cpRmbRequestCargo = (RMB_RQST_Cargo) cpRmbRequestCollection.get(0);
				String caseNumFromReq = cpRmbRequestCargo.getCase_num();
				String countyCodeFromReq = cpRmbRequestCargo.getCounty_cd();
				String caseNumFromDataExg = null;
				String countyCodeFromDataExg = null;
				FwLogger.log(this.getClass(), Level.INFO, "DataExchange_Lambda_Function mapping::::before calling");
				String responseBody = fetchCaseNumCountyFromDataExchange(fwTransaction);
				FwLogger.log(this.getClass(), Level.INFO,
						"DataExchange_Lambda_Function mapping::::after calling " + responseBody);

				String responseBodyAfterRemoveQuotes = null;
				if (null != responseBody) {
					// body is coming as string, it should be converted to object by below statement
					responseBodyAfterRemoveQuotes = responseBody.replace("\"{", "{").replace("}\"", "}").replace("\\", "");	
					FwLogger.log(this.getClass(), Level.INFO,
							"DataExchange_Lambda_Function mapping::::after calling response after remove quotes " + responseBodyAfterRemoveQuotes);
				}
				ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
						false);
				CaseDetailsResponse details = objMapper.readValue(responseBodyAfterRemoveQuotes,
						CaseDetailsResponse.class);
				FwLogger.log(this.getClass(), Level.INFO,
						"DataExchange_Lambda_Function mapping::::after calling response mapping details " + details);
				if (null != details && null != details.getBody() && null != details.getBody().getCaseData()) {
					FwLogger.log(this.getClass(), Level.INFO,
							"DataExchange_Lambda_Function mapping::::after calling response mapping caseData"
									+ details.getBody().getCaseData());
					List<CaseData> caseDt = details.getBody().getCaseData();
					if (!caseDt.isEmpty()) {
						for (CaseData caseDataFromDataExg:caseDt) {
							caseNumFromDataExg = caseDataFromDataExg.getCaseNumber();
							countyCodeFromDataExg = caseDataFromDataExg.getCountyCode();
							FwLogger.log(this.getClass(), Level.INFO,
									"DataExchange_Lambda_Function mapping::::after calling response mapping caseNum and countycd"
											+ caseNumFromDataExg + " " + countyCodeFromDataExg);
							if (caseNumFromReq.equals(caseNumFromDataExg)
									&& countyCodeFromReq.equals(countyCodeFromDataExg)) {
								FwLogger.log(this.getClass(), Level.INFO,
										"HouseholdDemographicsController DataExchange_Lambda_Function failed mapping::::");
								FwLogger.log(this.getClass(), Level.INFO,
										"case and county from request:::" +caseNumFromReq +"and "+countyCodeFromReq);
								FwLogger.log(this.getClass(), Level.INFO,
										"case and county from dataexchange:::" +caseNumFromDataExg +"and "+countyCodeFromDataExg);
								return true;
							}
							isCaseNumAndCountyCdCorrect = false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} catch (Exception e) {
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RMBRequestServiceBO.checkCaseNumAndCountyCdAssociatedCorrect() - ***checkCaseNumAndCountyCdAssociatedCorrect error***");
				FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
				return false;
			}
		}
		return isCaseNumAndCountyCdCorrect;
	}

	private String fetchCaseNumCountyFromDataExchange(FwTransaction fwTransaction) throws Exception {
		String responseBody = null;
		try {
			String url = System.getenv("DATAEXCHANGE_LAMBDA_FUNCTION");
			FwLogger.log(this.getClass(), Level.INFO,
				"HouseholdDemographicsController DataExchange_Lambda_Function URL::::" + url);
        
			FwTransaction newFxTxn = new FwTransaction();
			HttpEntity<FwTransaction> httpentity = new HttpEntity<>(newFxTxn);
			responseBody = service.invokeDataExchangeLambda(url, httpentity, fwTransaction);
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RMBRequestServiceBO.fetchCaseNumCountyFromDataExchange() - ***fetchCaseNumCountyFromDataExchange error***");
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
        return responseBody;
	}

	public ResponseEntity<Object> throwAuthorizedException(FwTransaction fwTransaction) {
		Map<String, FwMessageList> request = new HashMap<String,FwMessageList>();    	
    	FwMessageList validateInfo = exceptionUtil.unauthorizedMessageForURLEntity();
    	request.put(FwConstants.MESSAGE_LIST, validateInfo);
    	fwTransaction.setRequest(request);
		return new ResponseEntity<Object>(fwTransaction, HttpStatus.UNAUTHORIZED);
	}

	
}
