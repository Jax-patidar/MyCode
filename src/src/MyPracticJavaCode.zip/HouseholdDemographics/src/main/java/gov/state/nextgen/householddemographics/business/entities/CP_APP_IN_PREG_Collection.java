package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;


public class CP_APP_IN_PREG_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.CP_APP_IN_PREG_Cargo";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CP_APP_IN_PREG_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CP_APP_IN_PREG_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CP_APP_IN_PREG_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CP_APP_IN_PREG_Cargo[] getResults() {
		final CP_APP_IN_PREG_Cargo[] cbArray = new CP_APP_IN_PREG_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CP_APP_IN_PREG_Cargo getCargo(final int idx) {
		return (CP_APP_IN_PREG_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public CP_APP_IN_PREG_Cargo[] cloneResults() {
		final CP_APP_IN_PREG_Cargo[] rescargo = new CP_APP_IN_PREG_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_APP_IN_PREG_Cargo cargo = getCargo(i);
			rescargo[i] = new CP_APP_IN_PREG_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setEcp_id(cargo.getEcp_id());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setChg_eff_dt(cargo.getChg_eff_dt());
			rescargo[i].setFetus_ct(cargo.getFetus_ct());
			rescargo[i].setPreg_due_dt(cargo.getPreg_due_dt());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setBaby_ct(cargo.getBaby_ct());
			rescargo[i].setBaby_ct(cargo.getBaby_ct());
			rescargo[i].setBaby_reside_hshld_ind(cargo.getBaby_reside_hshld_ind());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
			
			rescargo[i].setCur_preg(cargo.getCur_preg());
			rescargo[i].setCur_in_post_partum(cargo.getCur_in_post_partum());
			rescargo[i].setPreg_term_dt(cargo.getPreg_term_dt());
			rescargo[i].setPp_babies_ct(cargo.getPp_babies_ct());
			rescargo[i].setBf_infant(cargo.getBf_infant());
			rescargo[i].setPreg_dlvry_dt(cargo.getPreg_dlvry_dt());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_APP_IN_PREG_Cargo[]) {
			final CP_APP_IN_PREG_Cargo[] cbArray = (CP_APP_IN_PREG_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
