package gov.state.nextgen.householddemographics.data.db2;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo.CP_APP_HSHL_RLT_Key;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface HouseholdRelationshipRepo extends CrudRepository<CP_APP_HSHL_RLT_Cargo,CP_APP_HSHL_RLT_Key> {
	@Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1")
    List<CP_APP_HSHL_RLT_Cargo> findByAppNum(Integer app_number);
    @Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1 and c.srcIndvSeqNum =?2")
    List<CP_APP_HSHL_RLT_Cargo> findByAppNumAndSrcIndvSeqNum(Integer app_number,String srcIndvSeqNum);
    @Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1 and c.srcAppIndiv =?2 and c.rltCd =?3")
    List<CP_APP_HSHL_RLT_Cargo> findByAppNumAndSrcAppIndivAndRltCdIn(Integer app_number,String srcAppIndiv,List<String> rltCds);
    @Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1 and c.rltCd =?2")
    List<CP_APP_HSHL_RLT_Cargo> findByAppNumAndRltCdIn(Integer app_number,List<String> rltCds);
    @Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1 and c.srcIndvSeqNum =?2")
    List<CP_APP_HSHL_RLT_Cargo> findByAppNumAndRefIndvSeqNum(Integer app_number, String srcIndvSeqNum);
    @Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1 and c.srcIndvSeqNum =?2 and c.refIndvSeqNum =?3")
    List<CP_APP_HSHL_RLT_Cargo> findByAppNumAndSrcIndvSeqNumAndRefIndvSeqNum(Integer app_number, String srcIndvSeqNum, String refIndvSeqNum);
    
    @Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1")
	public CP_APP_HSHL_RLT_Collection getByAppNum(Integer appNum);

    
    @Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1 and c.srcIndvSeqNum = ?2 and c.refIndvSeqNum =?3" )  
	CP_APP_HSHL_RLT_Collection loadRelationshipDetails(Integer app_num, Integer src_indv_seq_num,Integer ref_indv_seq_num);

	@Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1")
	CP_APP_HSHL_RLT_Collection loadCpAppHshlRltDetails(Integer appNum);

	@Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1 and c.refIndvSeqNum = ?2")
	public CP_APP_HSHL_RLT_Collection loadCaretakerExisitingDetails(Integer appNumber, Integer refIndvSeqNum);
	 	
	@Transactional
	@Modifying
	@Query("delete from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1 and c.srcIndvSeqNum = ?2")
	public void deleteHHRelations(Integer appNumber, Integer indvSeqNum);
	
	@Query("select A from CP_APP_HSHL_RLT_Cargo A where app_number= ?1 and ref_indv_seq_num = ?2")
	public List<CP_APP_HSHL_RLT_Cargo> findByAppNumRefIndvSeqNum(Integer appNum, Integer refIndvSeqNum);


	@Query("select A from CP_APP_HSHL_RLT_Cargo A where app_number = ?1 and src_indv_seq_num = ?2")
	public List<CP_APP_HSHL_RLT_Cargo> findByAppNumSrcIndvSeqNum(Integer appNum, Integer srcIndvSeqNum);
	
	@Query("select c from CP_APP_HSHL_RLT_Cargo c where c.app_number = ?1 and c.srcIndvSeqNum = ?2 and c.refIndvSeqNum =?3" )  
	List<CP_APP_HSHL_RLT_Cargo> findByAppNumSrcRefIndvSeqNum(Integer appNum, Integer srcIndvSeqNum,Integer refIndvSeqNum);
	
}
