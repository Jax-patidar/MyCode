package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;


public class CP_APP_IN_SHLTC_Cargo extends AbstractCargo implements Serializable {
	
	private static final long serialVersionUID = 269715134768762710L;
	
	
	private String app_num;
	
	private Integer indv_seq_num;
	
	private Integer seq_num;
	
	private String src_app_ind;
	
	
	private Date chg_eff_dt;
	private Integer rec_cplt_ind;
	private Double shlt_oblg_amt;
	private Integer shlt_oblg_ind;
	private String shlt_typ;
	private String pay_freq;
	private Double othr_housing_paymt_amt;
	private String othr_housing_paymts;
	private String intend_to_return_ind;
	
	private String not_living_reason_cd;
	
	private String someone_else_living_ind;
	
	private String someone_else_rent_pay_ind;
	private String housing_bill_ind;
	
	private String adapt_record_id;
	private String shelt_name;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date release_dt;
	
	    
	private String firstname;    
	    
	private String lastname;    
	    
	private Integer age;

	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public Integer getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public Date getChg_eff_dt() {
		return chg_eff_dt;
	}
	public void setChg_eff_dt(Date chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public Double getShlt_oblg_amt() {
		return shlt_oblg_amt;
	}
	public void setShlt_oblg_amt(Double shlt_oblg_amt) {
		this.shlt_oblg_amt = shlt_oblg_amt;
	}
	public Integer getShlt_oblg_ind() {
		return shlt_oblg_ind;
	}
	public void setShlt_oblg_ind(Integer shlt_oblg_ind) {
		this.shlt_oblg_ind = shlt_oblg_ind;
	}
	public String getShlt_typ() {
		return shlt_typ;
	}
	public void setShlt_typ(String shlt_typ) {
		this.shlt_typ = shlt_typ;
	}
	public String getPay_freq() {
		return pay_freq;
	}
	public void setPay_freq(String pay_freq) {
		this.pay_freq = pay_freq;
	}
	public Double getOthr_housing_paymt_amt() {
		return othr_housing_paymt_amt;
	}
	public void setOthr_housing_paymt_amt(Double othr_housing_paymt_amt) {
		this.othr_housing_paymt_amt = othr_housing_paymt_amt;
	}
	public String getOthr_housing_paymts() {
		return othr_housing_paymts;
	}
	public void setOthr_housing_paymts(String othr_housing_paymts) {
		this.othr_housing_paymts = othr_housing_paymts;
	}
	public String getIntend_to_return_ind() {
		return intend_to_return_ind;
	}
	public void setIntend_to_return_ind(String intend_to_return_ind) {
		this.intend_to_return_ind = intend_to_return_ind;
	}
	public String getNot_living_reason_cd() {
		return not_living_reason_cd;
	}
	public void setNot_living_reason_cd(String not_living_reason_cd) {
		this.not_living_reason_cd = not_living_reason_cd;
	}
	public String getSomeone_else_living_ind() {
		return someone_else_living_ind;
	}
	public void setSomeone_else_living_ind(String someone_else_living_ind) {
		this.someone_else_living_ind = someone_else_living_ind;
	}
	public String getSomeone_else_rent_pay_ind() {
		return someone_else_rent_pay_ind;
	}
	public void setSomeone_else_rent_pay_ind(String someone_else_rent_pay_ind) {
		this.someone_else_rent_pay_ind = someone_else_rent_pay_ind;
	}
	public String getHousing_bill_ind() {
		return housing_bill_ind;
	}
	public void setHousing_bill_ind(String housing_bill_ind) {
		this.housing_bill_ind = housing_bill_ind;
	}
	public String getAdapt_record_id() {
		return adapt_record_id;
	}
	public void setAdapt_record_id(String adapt_record_id) {
		this.adapt_record_id = adapt_record_id;
	}
	public String getShelt_name() {
		return shelt_name;
	}
	public void setShelt_name(String shelt_name) {
		this.shelt_name = shelt_name;
	}
	public Date getRelease_dt() {
		return release_dt;
	}
	public void setRelease_dt(Date release_dt) {
		this.release_dt = release_dt;
	}

}
