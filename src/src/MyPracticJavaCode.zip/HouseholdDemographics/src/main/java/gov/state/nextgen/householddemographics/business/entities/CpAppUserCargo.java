/**
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * @author rudeshmukh
 *
 */
@Entity
@Table(name = "CP_APP_USER", schema = "IE_SSP_OWNER_HH")
public class CpAppUserCargo extends AbstractCargo implements Serializable {

	

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CpAppUserCargoKey id;

	@Column(name="sbmt_acs_id")
	private String sbmtAcsId;

	public CpAppUserCargo() {
		//This is a default constructor
	}

	public CpAppUserCargoKey getId() {
		return this.id;
	}

	public void setId(CpAppUserCargoKey id) {
		this.id = id;
	}

	public String getSbmtAcsId() {
		return this.sbmtAcsId;
	}

	public void setSbmtAcsId(String sbmtAcsId) {
		this.sbmtAcsId = sbmtAcsId;
	}


}
