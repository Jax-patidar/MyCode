package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.util.List;

public class RelationshipDtls implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 7767053750915324020L;

    private String originalSelected;
    private String originalSrcIndvFirstName;
    private String originalRefIndvFirstName;

    private String suffix;
    private String selectedRel;
    private String originalTogetherDesc;
    private String physicallyBuy;
    private String[] sub;
    private int[] filterColumnId;
    private String[] filterValue;
    private String relationship;
    private List<String> applicableRelationShipCodes;

    private IndividualDtls sourceIndividual;
    private IndividualDtls referenceIndividual;

    public IndividualDtls getSourceIndividual() {
        return sourceIndividual;
    }
    public void setSourceIndividual(IndividualDtls sourceIndividual) {
        this.sourceIndividual = sourceIndividual;
    }
    public IndividualDtls getReferenceIndividual() {
        return referenceIndividual;
    }
    public void setReferenceIndividual(IndividualDtls referenceIndividual) {
        this.referenceIndividual = referenceIndividual;
    }
    public String getRelationship() {
        return relationship;
    }
    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }
    public int[] getFilterColumnId() {
        return filterColumnId;
    }
    public void setFilterColumnId(int[] filterColumnId) {
        this.filterColumnId = filterColumnId;
    }
    public String[] getFilterValue() {
        return filterValue;
    }
    public void setFilterValue(String[] filterValue) {
        this.filterValue = filterValue;
    }
    public String[] getSub() {
        return sub;
    }
    public void setSub(String[] sub) {
        this.sub = sub;
    }
    public String getSelectedRel() {
        return selectedRel;
    }
    public void setSelectedRel(String selectedRel) {
        this.selectedRel = selectedRel;
    }
    public String getOriginalTogetherDesc() {
        return originalTogetherDesc;
    }
    public void setOriginalTogetherDesc(String originalTogetherDesc) {
        this.originalTogetherDesc = originalTogetherDesc;
    }
    public String getPhysicallyBuy() {
        return physicallyBuy;
    }
    public void setPhysicallyBuy(String physicallyBuy) {
        this.physicallyBuy = physicallyBuy;
    }
    public String getSuffix() {
        return suffix;
    }
    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }
    public String getOriginalSelected() {
        return originalSelected;
    }
    public void setOriginalSelected(String originalSelected) {
        this.originalSelected = originalSelected;
    }
    public String getOriginalSrcIndvFirstName() {
        return originalSrcIndvFirstName;
    }
    public void setOriginalSrcIndvFirstName(String originalSrcIndvFirstName) {
        this.originalSrcIndvFirstName = originalSrcIndvFirstName;
    }
    public String getOriginalRefIndvFirstName() {
        return originalRefIndvFirstName;
    }
    public void setOriginalRefIndvFirstName(String originalRefIndvFirstName) {
        this.originalRefIndvFirstName = originalRefIndvFirstName;
    }
    public List<String> getApplicableRelationShipCodes() {
        return applicableRelationShipCodes;
    }
    public void setApplicableRelationShipCodes(List<String> applicableRelationShipCodes) {
        this.applicableRelationShipCodes = applicableRelationShipCodes;
    }


}
