package gov.state.nextgen.householddemographics.business.entities;

import javax.persistence.*;

import gov.state.nextgen.access.business.entities.AbstractCargo;

import java.io.Serializable;

@Entity
@IdClass(APP_IN_NEWB_Cargo.APP_IN_NEWB_CargoKey.class)
@Table(name="CP_APP_NEWBORN_INFO")
public class APP_IN_NEWB_Cargo extends AbstractCargo {

	private static final long serialVersionUID = -5023269728498861729L;
	
	@Transient
	private String appNum;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
    
    @Id
    @Column (name= "newborn_info_id")
    private String newBornInfoId;
    
    @Id
    @Column (name="INDV_SEQ_NUM" )
    private Integer indvSeqNum;
    
    @Column (name="par_one_indv_seq_num" )
    private Integer parentOneIndvSeqNum;
    
    @Column (name="par_two_indv_seq_num" )
    private Integer parentTwoIndvSeqNum;
    
    @Column (name="someone_else_par_first_name" )
    private String someoneElseParFrstName;
    
    @Column (name="someone_else_par_last_name" )
    private String someoneElseParLstName;
    
    @Column (name="someone_else_par_two_first_name" )
    private String someoneElseParTwoFrstName;
    
    @Column (name="someone_else_par_two_last_name" )
    private String someoneElseParTwoLstName;
    
    
    
	public Integer getParentOneIndvSeqNum() {
		return parentOneIndvSeqNum;
	}

	public void setParentOneIndvSeqNum(Integer parentOneIndvSeqNum) {
		this.parentOneIndvSeqNum = parentOneIndvSeqNum;
	}

	public Integer getParentTwoIndvSeqNum() {
		return parentTwoIndvSeqNum;
	}

	public void setParentTwoIndvSeqNum(Integer parentTwoIndvSeqNum) {
		this.parentTwoIndvSeqNum = parentTwoIndvSeqNum;
	}

	public String getSomeoneElseParFrstName() {
		return someoneElseParFrstName;
	}

	public void setSomeoneElseParFrstName(String someoneElseParFrstName) {
		this.someoneElseParFrstName = someoneElseParFrstName;
	}

	public String getSomeoneElseParLstName() {
		return someoneElseParLstName;
	}

	public void setSomeoneElseParLstName(String someoneElseParLstName) {
		this.someoneElseParLstName = someoneElseParLstName;
	}

	public String getSomeoneElseParTwoFrstName() {
		return someoneElseParTwoFrstName;
	}

	public void setSomeoneElseParTwoFrstName(String someoneElseParTwoFrstName) {
		this.someoneElseParTwoFrstName = someoneElseParTwoFrstName;
	}

	public String getSomeoneElseParTwoLstName() {
		return someoneElseParTwoLstName;
	}

	public void setSomeoneElseParTwoLstName(String someoneElseParTwoLstName) {
		this.someoneElseParTwoLstName = someoneElseParTwoLstName;
	}

	public static class APP_IN_NEWB_CargoKey implements Serializable {
        /**
		 * 
		 */
		private static final long serialVersionUID = -7240249758633137093L;
		private Integer app_number;
        private Integer indvSeqNum;

        public APP_IN_NEWB_CargoKey(Integer app_number, Integer indvSeqNum) {
            this.app_number = app_number;
            this.indvSeqNum = indvSeqNum;
        }

        public APP_IN_NEWB_CargoKey() {
        }

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
			result = prime * result + ((indvSeqNum == null) ? 0 : indvSeqNum.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			APP_IN_NEWB_CargoKey other = (APP_IN_NEWB_CargoKey) obj;
			if (app_number == null) {
				if (other.app_number != null)
					return false;
			} else if (!app_number.equals(other.app_number))
				return false;
			if (indvSeqNum == null) {
				if (other.indvSeqNum != null)
					return false;
			} else if (!indvSeqNum.equals(other.indvSeqNum))
				return false;
			return true;
		}
        
        
    }
	@Transient
    private String live_with_mom_resp;
	@Transient
    private String rec_cplt_ind;
    
    public String getAppNum() {
		return String.valueOf(app_number);
	}
	public void setAppNum(String appNum) {
		this.app_number = Integer.parseInt(appNum);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.appNum = String.valueOf(app_number);
	}
	
    public String getLive_with_mom_resp() {
        return live_with_mom_resp;
    }

    public void setLive_with_mom_resp(String live_with_mom_resp) {
        this.live_with_mom_resp = live_with_mom_resp;
    }

    public String getRec_cplt_ind() {
        return rec_cplt_ind;
    }

    public void setRec_cplt_ind(String rec_cplt_ind) {
        this.rec_cplt_ind = rec_cplt_ind;
    }
    
    public Integer getIndvSeqNum() {
		return indvSeqNum;
	}

	public void setIndvSeqNum(Integer indvSeqNum) {
		this.indvSeqNum = indvSeqNum;
	}
	
	public String getNewBornInfoId() {
		return newBornInfoId;
	}

	public void setNewBornInfoId(String newBornInfoId) {
		this.newBornInfoId = newBornInfoId;
	}
	
	
}
