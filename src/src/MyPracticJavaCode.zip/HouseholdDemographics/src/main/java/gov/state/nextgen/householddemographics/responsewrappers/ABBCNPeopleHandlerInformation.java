package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABBCN")
@Scope("prototype")
public class ABBCNPeopleHandlerInformation implements LogicResponseInterface{
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();

		Map pageCollection = fwTrxn.getPageCollection();
		List<APP_INDV_Cargo> appIndvList = new ArrayList<>();
		APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
		APP_INDV_Collection appIndvColl = pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) != null ? (APP_INDV_Collection)pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) : null;
		if(appIndvColl != null) {
			appIndvCargo = (APP_INDV_Cargo) appIndvColl.get(0);
		}
		appIndvList.add(appIndvCargo);
		
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvList);
		
		//Below elements are not required for populating in other services at this point of time, will be added later if required
		/*
		 * driverPageResponse.setCurrentPageID(PAGE_ID);
		 * driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(
		 * FwConstants.NEXT_PAGE_ACTION)));
		 * driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(
		 * FwConstants.NEXT_PAGE_ID)));
		 * driverPageResponse.setAppNum(String.valueOf(fwTrxn.getSession().get(
		 * FwConstants.APP_NUMBER)));
		 * driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(
		 * FwConstants.PREVIOUS_PAGE_ID)));
		 */

		return driverPageResponse;
	}
	
}
