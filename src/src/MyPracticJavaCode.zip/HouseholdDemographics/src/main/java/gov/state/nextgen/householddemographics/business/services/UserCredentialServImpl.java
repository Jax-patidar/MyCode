package gov.state.nextgen.householddemographics.business.services;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.householddemographics.data.db2.AppUserRepository;
import redis.clients.jedis.Jedis;

@Service
public class UserCredentialServImpl {

	@Autowired
	AppUserRepository appUserRep;

	
	/**Method for loading userid appnum in Redis on startup of Household
	 * If data exist in redis then no data is added
	 * @throws JsonProcessingException
	 */
	@SuppressWarnings("squid:S2095")
	public void loadCredentialsFromTable() throws JsonProcessingException {
		FwLogger.log(this.getClass(), Level.INFO, "loadCredentialsFromTable START");
		String redisUrl = System.getenv("REDIS_HOST");
		String redisPort = System.getenv("REDIS_PORT");

		
		

//		Jedis jedis = new Jedis(redisUrl, Integer.parseInt(redisPort));
//		Set<String> keys = jedis.keys(FwConstants.DBPREFIXUSERAPPNUM + "*");
//		try {
//		if (keys.isEmpty()) {
//
//			if (keys != null && !keys.isEmpty()) {
//				jedis.del(keys.toArray(new String[keys.size()]));
//			}
//			APP_USER_Cargo[] allUserData = appUserRep.findAllUserData();
//			if(allUserData.length > 0) {
//			String tempUserId = allUserData[0].getAcs_id();
//			Map tempApp = new HashMap();
//
//			for (APP_USER_Cargo data : allUserData) {
//
//				if (tempUserId.equalsIgnoreCase(data.getAcs_id())) {
//					tempApp.put(data.getApp_num(), null);
//				} else {
//					Map responseData = new HashMap();
//					responseData.put(tempUserId, tempApp);
//					ObjectMapper mapper = new ObjectMapper();
//					String jsonResult = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(responseData);
//					jedis.set(FwConstants.DBPREFIXUSERAPPNUM + tempUserId, jsonResult);
//
//					tempUserId = data.getAcs_id();
//					tempApp = new HashMap();
//					tempApp.put(data.getApp_num(), null);
//				}
//			}
//			Map responseData1 = new HashMap();
//			responseData1.put(tempUserId, tempApp);
//			ObjectMapper mapper = new ObjectMapper();
//			String jsonResult = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(responseData1);
//			jedis.set(FwConstants.DBPREFIXUSERAPPNUM + tempUserId, jsonResult);
//			}
//
//		}
//		jedis.close();
//
//		FwLogger.log(this.getClass(), Level.INFO, "loadCredentialsFromTable End");
//		}finally {
//			jedis.close();
//		}




		
		
	}

	
	/**Method to add appnum to userid when new application is requested
	 * @param appNum
	 * @param userId
	 * @throws JsonMappingException
	 * @throws JsonProcessingException
	 */
	@SuppressWarnings("squid:S2095")
	public void addNewApplicationToUser(String appNum, String userId)
			throws JsonMappingException, JsonProcessingException {
		FwLogger.log(this.getClass(), Level.INFO,
				"addNewApplicationToUser method called for AppNum :" + appNum + " UserId :" + userId + "-START");
		if (userId != null) {
			String redisUrl = System.getenv("REDIS_HOST");
			String redisPort = System.getenv("REDIS_PORT");
			if((Objects.nonNull(redisUrl) && !redisUrl.trim().isEmpty()) && (Objects.nonNull(redisPort) && !redisPort.trim().isEmpty())) {
		
			Jedis jedis = new Jedis(redisUrl, Integer.parseInt(redisPort));
			String previousData1 = jedis.get(FwConstants.DBPREFIXUSERAPPNUM + userId);
			ObjectMapper objectMapper = new ObjectMapper();
			try {
			if (previousData1 == null || previousData1.isEmpty()) {
				Map response = new HashMap();
				Map tempAppNum = new HashMap();
				tempAppNum.put(appNum, null);
				response.put(userId, tempAppNum);
				ObjectMapper mapper = new ObjectMapper();
				String jsonResult = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(response);
				jedis.set(FwConstants.DBPREFIXUSERAPPNUM + userId, jsonResult);

			} else {
				Map previousData = objectMapper.readValue(previousData1, HashMap.class);
				jedis.del(FwConstants.DBPREFIXUSERAPPNUM + userId);
				Map response = new HashMap();
				Map tempAppNum = new HashMap();
				tempAppNum = (HashMap) previousData.get(userId);
				tempAppNum.put(appNum, null);
				response.put(userId, tempAppNum);
				ObjectMapper mapper = new ObjectMapper();
				String jsonResult = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(response);
				jedis.set(FwConstants.DBPREFIXUSERAPPNUM + userId, jsonResult);

			}

			FwLogger.log(this.getClass(), Level.INFO, "AppNum :" + appNum + " added in Redis for UserId :" + userId + "-END");
			jedis.close();
			}finally {
				jedis.close();
			}
			}
		}

		FwLogger.log(this.getClass(), Level.INFO, "addNewApplicationToUser method END");
	}
}