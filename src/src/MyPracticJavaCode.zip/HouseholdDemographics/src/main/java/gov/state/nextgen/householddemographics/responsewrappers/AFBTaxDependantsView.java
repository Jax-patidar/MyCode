package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_DEPENDENTS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_DEPENDENTS_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;


@Component("ABTDP")
@Scope("prototype")
public class AFBTaxDependantsView implements LogicResponseInterface {

	private static final String PAGE_ID = "ABTDP";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTrxn.getPageCollection();
		List<CP_APP_IN_TAX_DEPENDENTS_Cargo> taxDepCargoList = new ArrayList<CP_APP_IN_TAX_DEPENDENTS_Cargo>();
		
		CP_APP_IN_TAX_DEPENDENTS_Collection taxDepCollection = (CP_APP_IN_TAX_DEPENDENTS_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_DEPENDENTS_COLLECTION);
		
		if(taxDepCollection != null && !taxDepCollection.isEmpty() && taxDepCollection.size() > 0) {
			taxDepCargoList = Arrays.asList(taxDepCollection.getResults());
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_DEPENDENTS_COLLECTION, taxDepCargoList);
		
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

		return driverPageResponse;
	}

}
