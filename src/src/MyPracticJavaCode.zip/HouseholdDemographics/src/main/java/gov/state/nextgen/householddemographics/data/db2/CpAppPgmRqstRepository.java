package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Key;

public interface CpAppPgmRqstRepository extends CrudRepository<APP_PGM_RQST_Cargo, APP_PGM_RQST_Key>{
	
	@Query("select c from APP_PGM_RQST_Cargo c where c.app_number = ?1")
	public APP_PGM_RQST_Cargo[] getByAppNum(Integer appNum); 
	
	@Query("select c from APP_PGM_RQST_Cargo c where c.app_number = ?1")
	public APP_PGM_RQST_Collection getDetails(Integer appNum);
	
	@Query("select c from APP_PGM_RQST_Cargo c where c.app_number = ?1")
	public APP_PGM_RQST_Cargo getCargoByAppNum(Integer appNum); 
	
	//ADDED AS PART OF CSPM-2161 to fetch data from DB
	@Query("select c from APP_PGM_RQST_Cargo c where c.app_number = ?1")
	public APP_PGM_RQST_Collection loadProgramRqstColl(Integer appNumber); 
	
	@Query("select c from APP_PGM_RQST_Cargo c where c.app_number = ?1")
	public APP_PGM_RQST_Collection loadProgrammeSelection(Integer appnum);


}
