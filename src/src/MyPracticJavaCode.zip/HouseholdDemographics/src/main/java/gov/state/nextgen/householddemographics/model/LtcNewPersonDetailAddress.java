package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * CSPM-22068 Changes as Per Loading Your Info
 * 
 * @author upriyadarshi
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class LtcNewPersonDetailAddress implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7601220252872840727L;
	
	private String addressLine;
	
	private String city;
	
	private String state;
	
	private String zipcode;
	
	private String apt;

	public String getAddressLine() {
		return addressLine;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public String getApt() {
		return apt;
	}

	public void setApt(String apt) {
		this.apt = apt;
	}

}
