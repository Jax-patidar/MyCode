/**
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.List;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * @author rudeshmukh
 *
 */
public class ApplicationRequest_Cargo extends AbstractCargo implements Serializable {
	private static final long serialVersionUID = 1l;

	private String gUID;
	private List<String> caseList;

	public String getgUID() {
		return gUID;
	}

	public void setgUID(String gUID) {
		this.gUID = gUID;
	}

	public List<String> getCaseList() {
		return caseList;
	}

	public void setCaseList(List<String> caseList) {
		this.caseList = caseList;
	}

}
