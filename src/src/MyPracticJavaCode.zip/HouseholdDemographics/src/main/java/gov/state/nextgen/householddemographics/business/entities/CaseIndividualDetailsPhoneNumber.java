package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author ransahu
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseIndividualDetailsPhoneNumber implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4857355993577490740L;

	@JsonProperty("Number")
	private String number;

	@JsonProperty("Extension")
	private String extension;

	private String type;

	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return the extension
	 */
	public String getExtension() {
		return extension;
	}

	/**
	 * @param extension the extension to set
	 */
	public void setExtension(String extension) {
		this.extension = extension;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

}
