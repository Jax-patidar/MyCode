package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;


/**
 * Primary Id Key class of CP_APP_FILE_HELP
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

public class APP_FILE_HELP_Key implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2535964183693692659L;
	private String app_num;
	
		
	public APP_FILE_HELP_Key() {
	}

	public APP_FILE_HELP_Key(String app_num) {
		super();
		this.app_num = app_num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		return result;
	}

	

}
