package gov.state.nextgen.householddemographics.model;

import java.util.List;

public class Relationship {

    private List<String> applicableRelationShipCodes;
    private Individual referenceIndividual;
    private Individual sourceIndividual;
    // The existing relationships.
    private String currentRelationshipCode;
    private String eatingMealsTogether;
    // Relationship key for legacy fw
    private String relationshipKey;
    // Eat together key for legacy fw
    private String eatTogetherKey;



    public String getEatTogetherKey() {
        return eatTogetherKey;
    }

    public void setEatTogetherKey(String eatTogetherKey) {
        this.eatTogetherKey = eatTogetherKey;
    }

    public String getRelationshipKey() {
        return relationshipKey;
    }

    public void setRelationshipKey(String relationshipKey) {
        this.relationshipKey = relationshipKey;
    }

    public List<String> getApplicableRelationShipCodes() {
        return applicableRelationShipCodes;
    }

    public void setApplicableRelationShipCodes(List<String> applicableRelationShipCodes) {
        this.applicableRelationShipCodes = applicableRelationShipCodes;
    }

    public Individual getReferenceIndividual() {
        return referenceIndividual;
    }

    public void setReferenceIndividual(Individual referenceIndividual) {
        this.referenceIndividual = referenceIndividual;
    }

    public Individual getSourceIndividual() {
        return sourceIndividual;
    }

    public void setSourceIndividual(Individual sourceIndividual) {
        this.sourceIndividual = sourceIndividual;
    }

    public String getCurrentRelationshipCode() {
        return currentRelationshipCode;
    }

    public void setCurrentRelationshipCode(String currentRelationshipCode) {
        this.currentRelationshipCode = currentRelationshipCode;
    }

    public String getEatingMealsTogether() {
        return eatingMealsTogether;
    }

    public void setEatingMealsTogether(String eatingMealsTogether) {
        this.eatingMealsTogether = eatingMealsTogether;
    }

}
