package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class RequiredDocumentModel extends AbstractCargo implements Serializable {
	
	private static final long serialVersionUID = -7149549134223107430L;	
	
	private String app_num;
	private String case_num;
	private String form_rpt_type;
	private List<Integer> active_individuals = new ArrayList<>();	
	private transient List<DocumentsRequired> documents_required = new ArrayList<>();
	private List<Integer> childCareIndivs  = new ArrayList<>();	
	private Map<Integer,String> active_benefitsCalIndividuals = new HashMap<>();
	private String mode;
	
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getCase_num() {
		return case_num;
	}
	public void setCase_num(String case_num) {
		this.case_num = case_num;
	}	
	public String getForm_rpt_type() {
		return form_rpt_type;
	}
	public void setForm_rpt_type(String form_rpt_type) {
		this.form_rpt_type = form_rpt_type;
	}	
	public List<Integer> getActive_individuals() {
		return active_individuals;
	}
	public void setActive_individuals(List<Integer> active_individuals) {
		this.active_individuals = active_individuals;
	}
	public List<DocumentsRequired> getDocuments_required() {
		return documents_required;
	}
	public void setDocuments_required(List<DocumentsRequired> documents_required) {
		this.documents_required = documents_required;
	}
	public List<Integer> getChildCareIndivs() {
		return childCareIndivs;
	}
	public void setChildCareIndivs(List<Integer> childCareIndivs) {
		this.childCareIndivs = childCareIndivs;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public Map<Integer,String> getActive_benefitsCalIndividuals() {
		return active_benefitsCalIndividuals;
	}
	public void setActive_benefitsCalIndividuals(Map<Integer,String> active_benefitsCalIndividuals) {
		this.active_benefitsCalIndividuals = active_benefitsCalIndividuals;
	}	
}
