package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "CP_APP_IN_TAX_RETURN")
@IdClass(CP_APP_IN_TAX_RETURN_Key.class)
public class CP_APP_IN_TAX_RETURN_Cargo extends AbstractCargo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Transient
	private boolean isDirty = false;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private Integer indv_seq_num;
	
	private String src_app_ind;
	private String jointly_file_sw;
	private Integer spouse_indv_id;
	@Column(name="dependents_outside_hshl_sw")
	private String dpndts_outside_household_sw;
	@Transient
	private Integer ecp_id;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date end_dt;
	
	@Column(name="change_dt")
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date chg_dt;
	
	@Transient
	private String fst_name;
	
	@Transient
	private String last_name;
	
	@Transient
	private Integer age;
	
	@Transient
	private String spouse_name;
	
	private String spouse_first_name;
	
	private String spouse_mid_name;
	
	private String spouse_last_name;
	
	private String tax_auto_enrl_ind;
	
	private String years;
	
	private String primary_filer_sw;
	
	@Column(name="status_cd")
	private String statusCd;
	
	@Column(name = "tax_return_sw")
	private String taxReturnSw;
	
	@Column(name = "mc_tax_filer_id")
	private Integer mcTaxFilerId;
	
	@Column(name = "federal_tax_sw")
	private String federalTaxSw;
	
	@Column(name = "tax_calsaws_object")
	private String taxCalsawsObject;
	
	@Column(name = "tax_primary_flag")
	private String taxPrimaryFlag;
	
	public String getPrimary_filer_sw() {
		return primary_filer_sw;
	}

	public void setPrimary_filer_sw(String primary_filer_sw) {
		this.primary_filer_sw = primary_filer_sw;
	}

	@Transient
	private String tax_dependent_resp;
	
	private String mc_tax_filer_fst_name;
	private String mc_tax_filer_mid_nam;
	private String mc_tax_filer_lst_nam;


	public String getTax_dependent_resp() {
		return tax_dependent_resp;
	}

	public void setTax_dependent_resp(String tax_dependent_resp) {
		this.tax_dependent_resp = tax_dependent_resp;
	}

	public String getSpouse_first_name() {
		return spouse_first_name;
	}

	public void setSpouse_first_name(String spouse_first_name) {
		this.spouse_first_name = spouse_first_name;
	}

	public String getSpouse_mid_name() {
		return spouse_mid_name;
	}

	public void setSpouse_mid_name(String spouse_mid_name) {
		this.spouse_mid_name = spouse_mid_name;
	}

	public String getSpouse_last_name() {
		return spouse_last_name;
	}

	public void setSpouse_last_name(String spouse_last_name) {
		this.spouse_last_name = spouse_last_name;
	}

	public String getFst_name() {
		return fst_name;
	}

	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}

	public String getSpouse_name() {
		return spouse_name;
	}

	public void setSpouse_name(String spouse_name) {
		this.spouse_name = spouse_name;
	}
	
	public String getTax_auto_enrl_ind() {
		return tax_auto_enrl_ind;
	}

	public void setTax_auto_enrl_ind(String tax_auto_enrl_ind) {
		this.tax_auto_enrl_ind = tax_auto_enrl_ind;
	}

	public String getYears() {
		return years;
	}

	public void setYears(String years) {
		this.years = years;
	}
	
	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	/**
	 *returns the app_num value.
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	/**
	 *returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 *returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 *returns the jointly_file_sw value.
	 */
	public String getJointly_file_sw() {
		return jointly_file_sw;
	}

	/**
	 *returns the spouse_indv_id value.
	 */
	public Integer getSpouse_indv_id() {
		return spouse_indv_id;
	}

	/**
	 *returns the dpndts_outside_household_sw value.
	 */
	public String getDpndts_outside_household_sw() {
		return dpndts_outside_household_sw;
	}

	/**
	 *returns the ecp_id value.
	 */
	public Integer getEcp_id() {
		return ecp_id;
	}

	/**
	 *sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 *sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 *sets the jointly_file_sw value.
	 */
	public void setJointly_file_sw(final String jointly_file_sw) {
		this.jointly_file_sw = jointly_file_sw;
	}

	/**
	 *sets the spouse_indv_id value.
	 */
	public void setSpouse_indv_id(final Integer spouse_indv_id) {
		this.spouse_indv_id = spouse_indv_id;
	}

	/**
	 *sets the dpndts_outside_household_sw value.
	 */
	public void setDpndts_outside_household_sw(final String dpndts_outside_household_sw) {
		this.dpndts_outside_household_sw = dpndts_outside_household_sw;
	}
	
	public String getStatusCd() {
		return statusCd;
	}

	public void setStatusCd(String statusCd) {
		this.statusCd = statusCd;
	}
	
	public String getTaxReturnSw() {
		return taxReturnSw;
	}

	public void setTaxReturnSw(String taxReturnSw) {
		this.taxReturnSw = taxReturnSw;
	}

	public Integer getMcTaxFilerId() {
		return mcTaxFilerId;
	}

	public void setMcTaxFilerId(Integer mcTaxFilerId) {
		this.mcTaxFilerId = mcTaxFilerId;
	}
	
	public String getFederalTaxSw() {
		return federalTaxSw;
	}

	public void setFederalTaxSw(String federalTaxSw) {
		this.federalTaxSw = federalTaxSw;
	}

	/**
	 *sets the ecp_id value.
	 */
	public void setEcp_id(final Integer ecp_id) {
		this.ecp_id = ecp_id;
	}

	/**
	 * @return the end_dt
	 */
	public Date getEnd_dt() {
		if (end_dt == null) {
    		return null;
    	} else {
    		return (Date)end_dt.clone();
    	}
	}

	/**
	 * @param end_dt the end_dt to set
	 */
	public void setEnd_dt(final Date end_dt) {
		if (end_dt == null) {
    		this.end_dt = null;
    	} else {
    		this.end_dt = (Date)end_dt.clone();
    	}
	}

	public Date getChg_dt() {
    	if (chg_dt == null) {
    		return null;
    	} else {
    		return (Date)chg_dt.clone();
    	}
    }

    /**
     * @param chg_dt the chg_dt to set
     */
    public void setChg_dt(Date chg_dt) {
    	if (chg_dt == null) {
    		this.chg_dt = null;
    	} else {
    		this.chg_dt = (Date)chg_dt.clone();
    	}
    }
    
	public String getTaxCalsawsObject() {
		return taxCalsawsObject;
	}

	public void setTaxCalsawsObject(String taxCalsawsObject) {
		this.taxCalsawsObject = taxCalsawsObject;
	}
	

	public String getMc_tax_filer_fst_name() {
		return mc_tax_filer_fst_name;
	}

	public void setMc_tax_filer_fst_name(String mc_tax_filer_fst_name) {
		this.mc_tax_filer_fst_name = mc_tax_filer_fst_name;
	}

	public String getMc_tax_filer_mid_nam() {
		return mc_tax_filer_mid_nam;
	}

	public void setMc_tax_filer_mid_nam(String mc_tax_filer_mid_nam) {
		this.mc_tax_filer_mid_nam = mc_tax_filer_mid_nam;
	}

	public String getMc_tax_filer_lst_nam() {
		return mc_tax_filer_lst_nam;
	}

	public void setMc_tax_filer_lst_nam(String mc_tax_filer_lst_nam) {
		this.mc_tax_filer_lst_nam = mc_tax_filer_lst_nam;
	}

	public String getTaxPrimaryFlag() {
		return taxPrimaryFlag;
	}

	public void setTaxPrimaryFlag(String taxPrimaryFlag) {
		this.taxPrimaryFlag = taxPrimaryFlag;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((chg_dt == null) ? 0 : chg_dt.hashCode());
		result = prime * result + ((dpndts_outside_household_sw == null) ? 0 : dpndts_outside_household_sw.hashCode());
		result = prime * result + ((ecp_id == null) ? 0 : ecp_id.hashCode());
		result = prime * result + ((end_dt == null) ? 0 : end_dt.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + (isDirty ? 1231 : 1237);
		result = prime * result + ((jointly_file_sw == null) ? 0 : jointly_file_sw.hashCode());
		result = prime * result + ((spouse_indv_id == null) ? 0 : spouse_indv_id.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		result = prime * result + ((spouse_first_name == null) ? 0 : spouse_first_name.hashCode());
		result = prime * result + ((spouse_mid_name == null) ? 0 : spouse_mid_name.hashCode());
		result = prime * result + ((spouse_last_name == null) ? 0 : spouse_last_name.hashCode());
		result = prime * result + ((tax_auto_enrl_ind == null) ? 0 : tax_auto_enrl_ind.hashCode());
		result = prime * result + ((years == null) ? 0 : years.hashCode());
		return result;
	}

	

}
