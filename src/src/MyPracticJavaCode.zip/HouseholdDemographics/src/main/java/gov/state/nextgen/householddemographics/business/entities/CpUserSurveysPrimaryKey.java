package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;
/**
 * @author ransahu
 *
 */
@Embeddable
public class CpUserSurveysPrimaryKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6524715584895484362L;
	
	private int appNumber;
	
	private String pageId;

	public CpUserSurveysPrimaryKey(int appNumber, String pageId) {
		super();
		this.appNumber = appNumber;
		this.pageId = pageId;
	}

	public CpUserSurveysPrimaryKey() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getAppNumber() {
		return appNumber;
	}

	public void setAppNumber(int appNumber) {
		this.appNumber = appNumber;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + appNumber;
		result = prime * result + ((pageId == null) ? 0 : pageId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CpUserSurveysPrimaryKey other = (CpUserSurveysPrimaryKey) obj;
		if (appNumber != other.appNumber)
			return false;
		if (pageId == null) {
			if (other.pageId != null)
				return false;
		} else if (!pageId.equals(other.pageId))
			return false;
		return true;
	}
	
}
