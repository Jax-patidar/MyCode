package gov.state.nextgen.householddemographics.business.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;
@Entity
@Table(name = "OTHER_HOUSEHOLD_DETAILS")
@IdClass(OTHER_HOUSEHOLD_DETAILS_KEY.class)
public class OTHER_HOUSEHOLD_DETAILS_Cargo extends AbstractCargo {
	private static final long serialVersionUID = -4939527281586501899L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	@Id
	private Integer indv_seq_num;
	private String care_taker_resp;
	private String fix_meal_personselection_resp;
	private String dup_food_assisstance;
	private String sell_ebt_card;
	private String cnvct_of_tr_fs_drg_resp;
	private String cnvct_of_tr_fs_gun_resp;
	
	public String getCnvct_of_tr_fs_gun_resp() {
		return cnvct_of_tr_fs_gun_resp;
	}
	public void setCnvct_of_tr_fs_gun_resp(String cnvct_of_tr_fs_gun_resp) {
		this.cnvct_of_tr_fs_gun_resp = cnvct_of_tr_fs_gun_resp;
	}
	public String getSell_ebt_card() {
		return sell_ebt_card;
	}
	public void setSell_ebt_card(String sell_ebt_card) {
		this.sell_ebt_card = sell_ebt_card;
	}
	public String getCnvct_of_tr_fs_drg_resp() {
		return cnvct_of_tr_fs_drg_resp;
	}
	public void setCnvct_of_tr_fs_drg_resp(String cnvct_of_tr_fs_drg_resp) {
		this.cnvct_of_tr_fs_drg_resp = cnvct_of_tr_fs_drg_resp;
	}
	public String getDup_food_assisstance() {
		return dup_food_assisstance;
	}
	public void setDup_food_assisstance(String dup_food_assisstance) {
		this.dup_food_assisstance = dup_food_assisstance;
	}
	public String getFix_meal_personselection_resp() {
		return fix_meal_personselection_resp;
	}
	public void setFix_meal_personselection_resp(String fix_meal_personselection_resp) {
		this.fix_meal_personselection_resp = fix_meal_personselection_resp;
	}
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getCare_taker_resp() {
		return care_taker_resp;
	}
	public void setCare_taker_resp(String care_taker_resp) {
		this.care_taker_resp = care_taker_resp;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((care_taker_resp == null) ? 0 : care_taker_resp.hashCode());
		result = prime * result + ((fix_meal_personselection_resp == null) ? 0 : fix_meal_personselection_resp.hashCode());
		result = prime * result + ((sell_ebt_card == null) ? 0 : sell_ebt_card.hashCode());
		result = prime * result + ((cnvct_of_tr_fs_drg_resp == null) ? 0 : cnvct_of_tr_fs_drg_resp.hashCode());
		return result;
	}
	
	
}
