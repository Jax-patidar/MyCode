package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author ransahu
 *
 */
@Entity
@Table(name = "CP_APP_TNB4_REDET")
@IdClass(CpAppTnb4RedetPrimaryKey.class)
public class CpAppTnb4Redet_Cargo extends AbstractCargo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2126139840394341564L;

	@Transient
	private String appNum;

	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Column(name = "SRC_APP_IND")
	private String srcAppInd;

	@Column(name = "PERSON_MOVED_IN_STATUS_IND")
	private String personMovedInStatusInd;

	@Column(name = "INCOME_CHANGE_STATUS_IND")
	private String incomeChangeStatusInd;

	@Column(name = "TNB4_CERTIFICATION_DUE_DATE")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date tnb4CertificationDueDate;

	@Column(name = "TNB4_LAST_CERTIFICATION_DATE")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date tnb4LastCertificationDate;

	@Column(name = "CASE_NUMBER")
	private String caseNumber;

	@Column(name = "COUNTY_CODE")
	private String countyCode;

	@Column(name = "CASE_NAME")
	private String caseName;

	@Column(name = "FORM_TYPE")
	private String formType;

	@Transient
	private String[] moveOut;

	@Transient
	private String[] ssiSsp;

	@OneToMany(mappedBy = "cpAppTnb4RedetCargo", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<CpAppTnb4MoveoutSsiSsp_Cargo> tnb4MoveoutssiSspList;

	/**
	 * @return the appNum
	 */
	public String getAppNum() {
		return String.valueOf(app_number);
	}

	/**
	 * @param appNum the appNum to set
	 */
	public void setAppNum(String appNum) {
		this.app_number = Integer.parseInt(appNum);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.appNum = String.valueOf(app_number);
	}
	
	/**
	 * @return the srcAppInd
	 */
	public String getSrcAppInd() {
		return srcAppInd;
	}

	/**
	 * @param srcAppInd the srcAppInd to set
	 */
	public void setSrcAppInd(String srcAppInd) {
		this.srcAppInd = srcAppInd;
	}

	/**
	 * @return the personMovedInStatusInd
	 */
	public String getPersonMovedInStatusInd() {
		return personMovedInStatusInd;
	}

	/**
	 * @param personMovedInStatusInd the personMovedInStatusInd to set
	 */
	public void setPersonMovedInStatusInd(String personMovedInStatusInd) {
		this.personMovedInStatusInd = personMovedInStatusInd;
	}

	/**
	 * @return the incomeChangeStatusInd
	 */
	public String getIncomeChangeStatusInd() {
		return incomeChangeStatusInd;
	}

	/**
	 * @param incomeChangeStatusInd the incomeChangeStatusInd to set
	 */
	public void setIncomeChangeStatusInd(String incomeChangeStatusInd) {
		this.incomeChangeStatusInd = incomeChangeStatusInd;
	}

	/**
	 * @return the tnb4CertificationDueDate
	 */
	public Date getTnb4CertificationDueDate() {
		return tnb4CertificationDueDate;
	}

	/**
	 * @param tnb4CertificationDueDate the tnb4CertificationDueDate to set
	 */
	public void setTnb4CertificationDueDate(Date tnb4CertificationDueDate) {
		this.tnb4CertificationDueDate = tnb4CertificationDueDate;
	}

	/**
	 * @return the tnb4LastCertificationDate
	 */
	public Date getTnb4LastCertificationDate() {
		return tnb4LastCertificationDate;
	}

	/**
	 * @param tnb4LastCertificationDate the tnb4LastCertificationDate to set
	 */
	public void setTnb4LastCertificationDate(Date tnb4LastCertificationDate) {
		this.tnb4LastCertificationDate = tnb4LastCertificationDate;
	}

	/**
	 * @return the caseNumber
	 */
	public String getCaseNumber() {
		return caseNumber;
	}

	/**
	 * @param caseNumber the caseNumber to set
	 */
	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	/**
	 * @return the countyCode
	 */
	public String getCountyCode() {
		return countyCode;
	}

	/**
	 * @param countyCode the countyCode to set
	 */
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	/**
	 * @return the caseName
	 */
	public String getCaseName() {
		return caseName;
	}

	/**
	 * @param caseName the caseName to set
	 */
	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}

	/**
	 * @return the formType
	 */
	public String getFormType() {
		return formType;
	}

	/**
	 * @param formType the formType to set
	 */
	public void setFormType(String formType) {
		this.formType = formType;
	}

	/**
	 * @return the moveOut
	 */
	public String[] getMoveOut() {
		return moveOut;
	}

	/**
	 * @param moveOut the moveOut to set
	 */
	public void setMoveOut(String[] moveOut) {
		this.moveOut = moveOut;
	}

	/**
	 * @return the ssiSsp
	 */
	public String[] getSsiSsp() {
		return ssiSsp;
	}

	/**
	 * @param ssiSsp the ssiSsp to set
	 */
	public void setSsiSsp(String[] ssiSsp) {
		this.ssiSsp = ssiSsp;
	}

	/**
	 * @return the tnb4MoveoutssiSspList
	 */
	public List<CpAppTnb4MoveoutSsiSsp_Cargo> getTnb4MoveoutssiSspList() {
		return tnb4MoveoutssiSspList;
	}

	/**
	 * @param tnb4MoveoutssiSspList the tnb4MoveoutssiSspList to set
	 */
	public void setTnb4MoveoutssiSspList(List<CpAppTnb4MoveoutSsiSsp_Cargo> tnb4MoveoutssiSspList) {
		this.tnb4MoveoutssiSspList = tnb4MoveoutssiSspList;
	}

}
