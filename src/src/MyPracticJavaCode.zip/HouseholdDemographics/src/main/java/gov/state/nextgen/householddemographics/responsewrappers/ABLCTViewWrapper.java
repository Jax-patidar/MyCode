package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABLCT")
@Scope("prototype")
public class ABLCTViewWrapper implements LogicResponseInterface {

    private static final String PAGE_ID = "ABLCT";
    
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

    	DriverPageResponse driverPageResponse = new DriverPageResponse();
    	List<APP_INDV_Cargo> AuthRepList = new ArrayList<APP_INDV_Cargo>();
    	List<APP_PGM_RQST_Cargo> appPgmRqstCargoList = new ArrayList<APP_PGM_RQST_Cargo>();
    	APP_INDV_Cargo authRepCargo = new APP_INDV_Cargo();
    	APP_PGM_RQST_Cargo appPgmRqstCargo = new APP_PGM_RQST_Cargo();
        Map<Object,Object> pageCollection = fwTxn.getPageCollection();

        APP_INDV_Collection appAuthRep = (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection");
        APP_PGM_RQST_Collection appPgmReqstColl = (APP_PGM_RQST_Collection) pageCollection.get("APP_PGM_RQST_Collection");
        
        
    	if(appAuthRep != null) {
    		authRepCargo = (APP_INDV_Cargo) appAuthRep.get(0);
		}
    	AuthRepList.add(authRepCargo);
		driverPageResponse.getPageCollection().put("APP_INDV_Collection", AuthRepList);
		
		if(appPgmReqstColl != null) {
			appPgmRqstCargo = (APP_PGM_RQST_Cargo) appPgmReqstColl.get(0);
		}
		appPgmRqstCargoList.add(appPgmRqstCargo);
		driverPageResponse.getPageCollection().put("APP_PGM_RQST_Collection", appPgmRqstCargoList);	
		
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

        return driverPageResponse;

    }

}
