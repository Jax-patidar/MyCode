package gov.state.nextgen.householddemographics.business.entities;

import javax.persistence.*;
import java.io.Serializable;


public class APP_IN_NEWB {

    @Transient
	private String appNum;
	
	@Id
	@Column(name = "app_num")
	private int app_number;

    @Id
    @Column(name="indv_seq_num")
    private String indvSeqNum;

    public static class CP_APP_INDV_Key implements Serializable {

        private Integer app_number;
        private String indvSeqNum;

        public CP_APP_INDV_Key(Integer app_number, String indvSeqNum) {
            this.app_number = app_number;
            this.indvSeqNum = indvSeqNum;
        }

        public CP_APP_INDV_Key() {
        }
    }

    @Transient
    private String liveWithMomResp;

    @Transient
    private Long recCpltInd;
    
    public String getAppNum() {
		return String.valueOf(app_number);
	}
	public void setAppNum(String appNum) {
		this.app_number = Integer.parseInt(appNum);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.appNum = String.valueOf(app_number);
	}
	
    public String getIndvSeqNum() {
        return indvSeqNum;
    }

    public void setIndvSeqNum(String indvSeqNum) {
        this.indvSeqNum = indvSeqNum;
    }

    public String getLiveWithMomResp() {
        return liveWithMomResp;
    }

    public void setLiveWithMomResp(String liveWithMomResp) {
        this.liveWithMomResp = liveWithMomResp;
    }

    public Long getRecCpltInd() {
        return recCpltInd;
    }

    public void setRecCpltInd(Long recCpltInd) {
        this.recCpltInd = recCpltInd;
    }
}