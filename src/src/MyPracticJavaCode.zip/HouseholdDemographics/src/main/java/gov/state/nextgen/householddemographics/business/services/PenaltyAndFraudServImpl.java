/**
 * 
 */
package gov.state.nextgen.householddemographics.business.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Collection;
import gov.state.nextgen.householddemographics.business.rules.CaretakerSelectionBO;
import gov.state.nextgen.householddemographics.business.rules.HouseHoldSummaryBO;
import gov.state.nextgen.householddemographics.business.rules.OtherHouseholdDetailsBO;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;

/**
 * @author KumariK
 *
 */
@SuppressWarnings("squid:S2229")
@Service("PenaltyAndFraudService")
public class PenaltyAndFraudServImpl implements HouseholdDemographicsService{
	
	@Autowired
	private HouseHoldSummaryBO houseHoldSummaryBO;
	
	@Autowired
	private OtherHouseholdDetailsBO otherHHDetailsBO;
	
	@Autowired
	private CaretakerSelectionBO caretakerSelectionBO;

	@Autowired
    private ExceptionUtil exceptionUtil;



	
	/**
	 * To call specific business method of the same bean
	 */
	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {

		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.STORE_PENALTY_FRAUD_INFO:
			this.storePenaltyFraudInformation(fwTxn);
			break;
		default:
		}
	}

	@Transactional
	public void storePenaltyFraudInformation(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "PenaltyAndFraudServImpl.storePenaltyFraudInformation() - START", fwTxn);
		try {


			String appNumber = null;
			String pageId = null;
			Integer indvSeqNum = 0;
			int currentPageStatus = 0;
			Map beforeColl = null;

			ArrayList<Integer> indvCheckArray;
			appNumber = fwTxn.getUserDetails().getAppNumber();

			beforeColl = fwTxn.getPageCollection();
			OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection;
			OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo;
			if (beforeColl != null) {
				//to save and update data for Selling EBT screen
				if (beforeColl.containsKey("sellEbtCardArray")) {
					sellEbtCardArrayCondition(appNumber, beforeColl);
					}
				
				//to save and update data for Traded for Drugs screen
				if (beforeColl.containsKey("cnvctOfTrFsDrgRespArray")) {
					cnvctOfTrFsDrgRespArrayCondition(appNumber, beforeColl);
					}
			}
			
		}catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storePenaltyFraudInformation()", fwTxn); 
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storePenaltyFraudInformation", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "PenaltyAndFraudServImpl.storePenaltyFraudInformation() - END", fwTxn);	
	}
	@SuppressWarnings("squid:S3776")
	private void cnvctOfTrFsDrgRespArrayCondition(String appNumber, Map beforeColl) {
	 try {
		 Integer indvSeqNum;
	 
		ArrayList<Integer> indvCheckArray;
		OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection;
		OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo;
		indvCheckArray =  (ArrayList<Integer>) beforeColl.get("cnvctOfTrFsDrgRespArray");
		for (int i = 0; i < indvCheckArray.size(); i++) {
			otherHouseholdDetailsCargo=new OTHER_HOUSEHOLD_DETAILS_Cargo();

			String cast = String.valueOf(indvCheckArray.get(i));
			if(!"false".equals(cast)) {
			indvSeqNum = Integer.parseInt(cast);
				otherHouseholdDetailsCollection = (OTHER_HOUSEHOLD_DETAILS_Collection) otherHHDetailsBO.loadOtherHHDetail(appNumber,indvSeqNum);
				if (null!=otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty()) {
					otherHouseholdDetailsCargo = otherHouseholdDetailsCollection.getCargo(0);
					otherHouseholdDetailsCargo.setCnvct_of_tr_fs_drg_resp("Y");
				} else {
				otherHouseholdDetailsCargo.setCnvct_of_tr_fs_drg_resp("Y");
				otherHouseholdDetailsCargo.setIndv_seq_num(indvSeqNum);
				otherHouseholdDetailsCargo.setApp_num(appNumber);
				}
				if(null!=otherHouseholdDetailsCollection) {
					otherHouseholdDetailsCollection.addCargo(otherHouseholdDetailsCargo);
					}
				if (null!=otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty() && !ArrayUtils.isEmpty(otherHouseholdDetailsCollection.getResults())) {
					otherHHDetailsBO.saveOtherHHDetail(otherHouseholdDetailsCollection);
				}
			}
		  }
	 }catch(Exception e) {
		 throw e;
	 }
	}
	@SuppressWarnings("squid:S3776")
	private void sellEbtCardArrayCondition(String appNumber, Map beforeColl) {
		try {
		Integer indvSeqNum;
		ArrayList<Integer> indvCheckArray;
		OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection;
		OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo;
		indvCheckArray =  (ArrayList<Integer>) beforeColl.get("sellEbtCardArray");
		for (int i = 0; i < indvCheckArray.size(); i++) {
			otherHouseholdDetailsCargo=new OTHER_HOUSEHOLD_DETAILS_Cargo();

			String cast = String.valueOf(indvCheckArray.get(i));
			if(!"false".equals(cast)) {
			indvSeqNum = Integer.parseInt(cast);
				otherHouseholdDetailsCollection = otherHHDetailsBO.loadOtherHHDetail(appNumber,indvSeqNum);
				if (null!=otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty()) {
					otherHouseholdDetailsCargo = otherHouseholdDetailsCollection.getCargo(0);
					otherHouseholdDetailsCargo.setSell_ebt_card("Y");
				} else {
				otherHouseholdDetailsCargo.setSell_ebt_card("Y");
				otherHouseholdDetailsCargo.setIndv_seq_num(indvSeqNum);
				otherHouseholdDetailsCargo.setApp_num(appNumber);
				}
				if(null!=otherHouseholdDetailsCollection) {
				otherHouseholdDetailsCollection.addCargo(otherHouseholdDetailsCargo);
				}
				if (null!=otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty() && !ArrayUtils.isEmpty(otherHouseholdDetailsCollection.getResults())) {
					otherHHDetailsBO.saveOtherHHDetail(otherHouseholdDetailsCollection);
				}
			}
		  }
		}catch(Exception e) {
			throw e;
		}
	}

}
