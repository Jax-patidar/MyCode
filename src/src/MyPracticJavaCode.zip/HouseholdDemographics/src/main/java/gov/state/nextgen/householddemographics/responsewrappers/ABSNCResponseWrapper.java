package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpUserSurveys_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpUserSurveys_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.constants.HouseholdApplicationConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;


@Component(HouseHoldDemoGraphicsConstants.ABSNC)
@Scope("prototype")
public class ABSNCResponseWrapper implements LogicResponseInterface{
	
	private static final String PAGE_ID = HouseHoldDemoGraphicsConstants.ABSNC;
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTrxn.getPageCollection();

		List<CpUserSurveys_Cargo> cargoList = new ArrayList<>();
		CpUserSurveys_Cargo cargo = new CpUserSurveys_Cargo();
		
		CpUserSurveys_Collection collection = (pageCollection.get(HouseHoldDemoGraphicsConstants.CP_USER_SURVEYS_COLLECTION) != null) 
				? (CpUserSurveys_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.CP_USER_SURVEYS_COLLECTION) : null;
		
		if(Objects.nonNull(collection) && !collection.isEmpty()) {			
			cargoList.add(collection.getCargo(0));
		} 
		
		
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_USER_SURVEYS_COLLECTION, cargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getRequest().get(FwConstants.APP_NUM)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		return driverPageResponse;
	}
}

