package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Key;

@Repository
public interface CpAppRgstRepository extends CrudRepository<APP_RGST_Cargo, APP_RGST_Key>{

	@Query("select c from APP_RGST_Cargo c where c.app_number = ?1")
	public APP_RGST_Cargo[] getByAppNum(Integer appNum);
	
	@Query("select c from APP_RGST_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2")
	public APP_RGST_Cargo[] getByAppNumAndSrcApp(Integer appNum,String srcAppInd);
	
	//Added as part of CSPM 2161
	@Query("select c from APP_RGST_Cargo c where c.app_number = ?1 and c.indv_seq_num =?2")
	public APP_RGST_Collection loadCpAppRgstDetails(Integer appNumber,Integer indv_seq_num);
	
	@Query("select c from APP_RGST_Cargo c where c.app_number = ?1 and c.indv_seq_num =?2")
	public APP_RGST_Cargo getCpAppRgstDetails(Integer appNumber,Integer indv_seq_num);


}
