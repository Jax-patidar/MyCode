package gov.state.nextgen.householddemographics.model;

import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;

import java.io.Serializable;

/**
 *  Add Person Details Summary List View
 */
public class ARAddPersonDtlsSummaryListView implements Serializable {

    private static final long serialVersionUID = 5496602275905482424L;

    protected APP_INDV_Collection coll = null;

    protected APP_INDV_Cargo cargo = null;

    protected String listViewName = "ARAddPersonDtlsSummaryListView_ListView";

    protected String[] values = new String[1];

    protected String[] displayColHeader;

    protected int[] colWidth;

    protected String appType;

    protected String language;

    protected String name = "listView";

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public APP_INDV_Collection getColl() {
        return coll;
    }

    public void setColl(APP_INDV_Collection coll) {
        this.coll = coll;
    }

    public APP_INDV_Cargo getCargo() {
        return cargo;
    }

    public void setCargo(APP_INDV_Cargo cargo) {
        this.cargo = cargo;
    }

    public String getListViewName() {
        return listViewName;
    }

    public void setListViewName(String listViewName) {
        this.listViewName = listViewName;
    }

    public String[] getValues() {
        return values;
    }

    public void setValues(String[] values) {
        this.values = values;
    }

    public String[] getDisplayColHeader() {
        return displayColHeader;
    }

    public void setDisplayColHeader(String[] displayColHeader) {
        this.displayColHeader = displayColHeader;
    }

    public int[] getColWidth() {
        return colWidth;
    }

    public void setColWidth(int[] colWidth) {
        this.colWidth = colWidth;
    }

    public String getAppType() {
        return appType;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }
}
