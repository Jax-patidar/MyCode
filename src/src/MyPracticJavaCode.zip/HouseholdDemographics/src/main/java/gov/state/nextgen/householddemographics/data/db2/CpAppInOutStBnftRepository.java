package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Key;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Collection;


@Repository
public interface CpAppInOutStBnftRepository extends CrudRepository<APP_IN_OUT_ST_BNFT_Cargo, APP_IN_OUT_ST_BNFT_Key>{

	@Query("select c from APP_IN_OUT_ST_BNFT_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2 and c.seq_num = ?3")
	public APP_IN_OUT_ST_BNFT_Cargo[] getGovernmentAidData(Integer appnum, Integer indv_seq_num, Integer seq_num);
	
	@Query("select c from APP_IN_OUT_ST_BNFT_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2 and c.seq_num = ?3")
	public APP_IN_OUT_ST_BNFT_Collection getCurrentIndv(Integer appNum, Integer indv_seq_num,
			Integer seq_num);
	
	@Query("select c from APP_IN_OUT_ST_BNFT_Cargo c where c.app_number = ?1 and c.indv_seq_num IN ?2")
	public APP_IN_OUT_ST_BNFT_Collection getByAppNum(Integer appNum, List<Integer> indvIds);
	
	@Transactional
	@Modifying
	@Query("delete from APP_IN_OUT_ST_BNFT_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2 and c.seq_num = ?3")
	public void deleteGovernmentAid(Integer appNumber, Integer indvSeqNum, Integer seqNum);

	@Query("select c from APP_IN_OUT_ST_BNFT_Cargo c where app_number = ?1 and c.indv_seq_num IN ?2")
	public APP_IN_OUT_ST_BNFT_Cargo[] loadGovernmentAid(Integer appNum, List<Integer> indvIds);


}
