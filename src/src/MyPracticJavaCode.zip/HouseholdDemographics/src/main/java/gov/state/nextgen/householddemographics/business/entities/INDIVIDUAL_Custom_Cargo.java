package gov.state.nextgen.householddemographics.business.entities;


import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.management.util.IndividualAge;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;


public class INDIVIDUAL_Custom_Cargo extends AbstractCargo implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6782958199193334749L;
	private String indv_seq_num;
    private String indv_pin_num;
    private String mci_id;
    private String brth_dt;
    private String fst_nam;
    private String last_nam;
    private String mid_init;
    private String rlvn_ind;
    private String sex_ind;
    private String rlt_cd;
    private IndividualAge indv_age;
    private String live_arng_typ;
    private String dabl_resp;
    private String preg_resp;
    private String relation_resp;
    private String out_of_home_ind;
    private String chld_trb_mbr_resp;
    private String trb_mbr_resp;
    
	// EDSP Starts
	private java.lang.String suffix_name;
	private java.lang.String res_va_sw;
	private java.lang.String Src_app_ind;
	private java.lang.String absence_reason_cd;
	private java.lang.String left_home_dt;

	private java.lang.String res_ga_ind;
	private java.lang.String living_arrangement_cd;

	// adding ssn field to cargo
	private java.lang.String ssn_num;
	private java.lang.String rec_cplt_ind;

    public String getIndv_seq_num() {
        return indv_seq_num;
    }

    public void setIndv_seq_num(String indv_seq_num) {
        this.indv_seq_num = indv_seq_num;
    }

    public String getIndv_pin_num() {
        return indv_pin_num;
    }

    public void setIndv_pin_num(String indv_pin_num) {
        this.indv_pin_num = indv_pin_num;
    }

    public String getMci_id() {
        return mci_id;
    }

    public void setMci_id(String mci_id) {
        this.mci_id = mci_id;
    }

    public String getBrth_dt() {
        return brth_dt;
    }

    public void setBrth_dt(String brth_dt) {
        this.brth_dt = brth_dt;
    }

    public String getFst_nam() {
        return fst_nam;
    }

    public void setFst_nam(String fst_nam) {
        this.fst_nam = fst_nam;
    }

    public String getLast_nam() {
        return last_nam;
    }

    public void setLast_nam(String last_nam) {
        this.last_nam = last_nam;
    }

    public String getMid_init() {
        return mid_init;
    }

    public void setMid_init(String mid_init) {
        this.mid_init = mid_init;
    }

    public String getRlvn_ind() {
        return rlvn_ind;
    }

    public void setRlvn_ind(String rlvn_ind) {
        this.rlvn_ind = rlvn_ind;
    }

    public String getSex_ind() {
        return sex_ind;
    }

    public void setSex_ind(String sex_ind) {
        this.sex_ind = sex_ind;
    }

    public String getRlt_cd() {
        return rlt_cd;
    }

    public void setRlt_cd(String rlt_cd) {
        this.rlt_cd = rlt_cd;
    }

    public IndividualAge getIndv_age() {
        return indv_age;
    }

    public void setIndv_age(IndividualAge indv_age) {
        this.indv_age = indv_age;
    }

    public String getLive_arng_typ() {
        return live_arng_typ;
    }

    public void setLive_arng_typ(String live_arng_typ) {
        this.live_arng_typ = live_arng_typ;
    }

    public String getDabl_resp() {
        return dabl_resp;
    }

    public void setDabl_resp(String dabl_resp) {
        this.dabl_resp = dabl_resp;
    }

    public String getPreg_resp() {
        return preg_resp;
    }

    public void setPreg_resp(String preg_resp) {
        this.preg_resp = preg_resp;
    }

    public String getRelation_resp() {
        return relation_resp;
    }

    public void setRelation_resp(String relation_resp) {
        this.relation_resp = relation_resp;
    }

    public String getOut_of_home_ind() {
        return out_of_home_ind;
    }

    public void setOut_of_home_ind(String out_of_home_ind) {
        this.out_of_home_ind = out_of_home_ind;
    }

    public String getChld_trb_mbr_resp() {
        return chld_trb_mbr_resp;
    }

    public void setChld_trb_mbr_resp(String chld_trb_mbr_resp) {
        this.chld_trb_mbr_resp = chld_trb_mbr_resp;
    }

    public String getTrb_mbr_resp() {
        return trb_mbr_resp;
    }

    public void setTrb_mbr_resp(String trb_mbr_resp) {
        this.trb_mbr_resp = trb_mbr_resp;
    }

	public java.lang.String getSuffix_name() {
		return suffix_name;
	}

	public void setSuffix_name(java.lang.String suffix_name) {
		this.suffix_name = suffix_name;
	}

	public java.lang.String getRes_va_sw() {
		return res_va_sw;
	}

	public void setRes_va_sw(java.lang.String res_va_sw) {
		this.res_va_sw = res_va_sw;
	}

	public java.lang.String getSrc_app_ind() {
		return Src_app_ind;
	}

	public void setSrc_app_ind(java.lang.String src_app_ind) {
		Src_app_ind = src_app_ind;
	}

	public java.lang.String getAbsence_reason_cd() {
		return absence_reason_cd;
	}

	public void setAbsence_reason_cd(java.lang.String absence_reason_cd) {
		this.absence_reason_cd = absence_reason_cd;
	}

	public java.lang.String getLeft_home_dt() {
		return left_home_dt;
	}

	public void setLeft_home_dt(java.lang.String left_home_dt) {
		this.left_home_dt = left_home_dt;
	}

	public java.lang.String getRes_ga_ind() {
		return res_ga_ind;
	}

	public void setRes_ga_ind(java.lang.String res_ga_ind) {
		this.res_ga_ind = res_ga_ind;
	}

	public java.lang.String getLiving_arrangement_cd() {
		return living_arrangement_cd;
	}

	public void setLiving_arrangement_cd(java.lang.String living_arrangement_cd) {
		this.living_arrangement_cd = living_arrangement_cd;
	}

	public java.lang.String getSsn_num() {
		return ssn_num;
	}

	public void setSsn_num(java.lang.String ssn_num) {
		this.ssn_num = ssn_num;
	}

	public java.lang.String getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	public void setRec_cplt_ind(java.lang.String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
}
