package gov.state.nextgen.householddemographics.business.profilemanagers;

import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.references.IReferenceTableData;
import gov.state.nextgen.access.management.references.ReferenceTableManager;
import gov.state.nextgen.householddemographics.business.entities.CP_RMC_CHG_SEL_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMC_CHG_SEL_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMC_CHG_SEL_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.services.HouseholdDemographicsServiceImpl;
import gov.state.nextgen.householddemographics.data.db2.CategorySelectionProfileRepo;
import gov.state.nextgen.householddemographics.management.CategorySequenceDetail;
import gov.state.nextgen.householddemographics.management.applications.CategorySequenceDetailsComparator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CategorySelectionProfileManager {

    protected char STATUS_NOT_REQUIRED = 'N';
    protected char STATUS_REQUIRED = 'R';
    protected char STATUS_COMPLETE = 'C';
    protected char STATUS_VISIT_AGAIN = 'V';
    protected char STATUS_ADD_NEW = 'A';

    private CategorySelectionProfileRepo categorySelectionProfileRepo;

    @Autowired
    private ReferenceTableManager referenceTableManager;

    static final Map typesMap = new HashMap();

    private static Logger logger = LoggerFactory.getLogger(HouseholdDemographicsServiceImpl.class);

    /**
     * Load category change selection profile.
     * @param appNum
     * @return
     */
    public SortedSet<CategorySequenceDetail> loadCategoryChangeSelectionProfile(String appNum) {
        final long startTime = System.currentTimeMillis();
        logger.info("CategorySelectionProfileManager.loadCategoryChangeSelectionProfile() - START");

        SortedSet<CategorySequenceDetail> categorySeqProfileSet = new TreeSet<CategorySequenceDetail>((categorySequenceDetailv1, categorySequenceDetailv2) -> {
            Integer compareValue = compareObjects(categorySequenceDetailv1.getIndividualSequence(), categorySequenceDetailv2.getIndividualSequence());
            if (compareValue == Integer.parseInt(FwConstants.ZERO)) {
                compareValue = compareObjects(retrieveTypeSequence(categorySequenceDetailv1.getCategoryType()), retrieveTypeSequence(categorySequenceDetailv2.getCategoryType()));
                if (compareValue == Integer.parseInt(FwConstants.ZERO)) {
                     compareValue = compareObjects(categorySequenceDetailv1.getUserEndSelectionInd(), categorySequenceDetailv2.getUserEndSelectionInd());
                }
            }
            return compareValue;
        });

        RMC_CHG_SEL_PRFL_Collection rmcChgSelColl = null;
        Map criteriaMap = null;

        List<RMC_CHG_SEL_PRFL_Cargo> rmcChgSelCargoArray = getRMCChangeSelectionProfileCargos(categorySelectionProfileRepo.findByAppNum(appNum));

        for(RMC_CHG_SEL_PRFL_Cargo rmcResponseCustomCargo: rmcChgSelCargoArray){
            CategorySequenceDetail categorySequenceDetailBean = new CategorySequenceDetail();
            if(Objects.nonNull(rmcResponseCustomCargo.getIndv_seq_num())){ categorySequenceDetailBean.setIndividualSequence(Short.parseShort(rmcResponseCustomCargo.getIndv_seq_num())); }
            if(Objects.nonNull(rmcResponseCustomCargo.getCat_seq_num())) { categorySequenceDetailBean.setCategorySequence(Long.parseLong(rmcResponseCustomCargo.getCat_seq_num())); }
            categorySequenceDetailBean.setUserEndSelectionInd(Short.parseShort(rmcResponseCustomCargo.getUser_end_sel_ind()));
            categorySequenceDetailBean.setChangeSelectionCategoryCd(rmcResponseCustomCargo.getChg_sel_cat_cd().trim());
            categorySequenceDetailBean.setStatus(rmcResponseCustomCargo.getStat_ind().charAt(0));
            categorySequenceDetailBean.setCategoryType(rmcResponseCustomCargo.getCat_typ().trim());
            categorySequenceDetailBean.setRowAction(null);
            categorySeqProfileSet.add(categorySequenceDetailBean);
        }
        getNextSequenceDetail(categorySeqProfileSet);

        return categorySeqProfileSet;
    }

    /**
     * Load category selection profile.
     * @param appNum
     * @param rmcCatHoCompPrfl
     * @return
     */
    public SortedSet loadCategoryChangeSelectionProfile(String appNum, String rmcCatHoCompPrfl) {
        return null;
    }

    /**
     * Compares two object and returns the value 0 if this aValue1 is
     * equal to aValue2; a value less than 0 if this aValue1 is numerically less
     * than aValue2 and a value greater than 0 if this aValue1 is numerically
     * greater than aValue2
     */
    private Integer compareObjects(long aValue1, long aValue2) {
        String NEGATIVE_ONE = "-1";
        if ((aValue1 == 0) && (aValue2 != 0)) {
            return Integer.parseInt(FwConstants.ONE);
        }
        if ((aValue1 != 0) && (aValue2 == 0)) {
            return Integer.parseInt(NEGATIVE_ONE);
        }
        if ((aValue1 != 0) && (aValue2 != 0)) {
            if (aValue1 < aValue2) {
                return Integer.parseInt(NEGATIVE_ONE);
            } else if (aValue1 > aValue2) {
                return Integer.parseInt(FwConstants.ONE);
            }
        }
        return 0;
    }

    /*
     * Fetches Category Sequence
     */
    private Integer retrieveTypeSequence(final String categoryType) {
        String seqNum = null;
        // If the typesMap is empty populate from the reference table
        synchronized (typesMap) {
            if (typesMap.isEmpty()) {
                // Category Reference table
                final IReferenceTableData refData = referenceTableManager.getReferenceTableData("TRCC", FwConstants.ENGLISH);
                final String[] code = refData.getCodeValues();
                // Codes Length
                final int codeLen = code.length;
                // Loop through the reference table and populate the category in
                // the typesMap
                for (int i = 0; i < codeLen; i++) {
                    typesMap.put(code[i], String.valueOf(i + 1));
                }
            }
            seqNum = (String) typesMap.get(categoryType);
        }

        if (seqNum != null) {
            return Integer.parseInt(seqNum);
        }

        return Integer.parseInt(FwConstants.ZERO);
    }

    /**
     *
     * @param cp_rmc_chg_sel_prfl_cargos
     * @return
     */
    private List<RMC_CHG_SEL_PRFL_Cargo> getRMCChangeSelectionProfileCargos(List<CP_RMC_CHG_SEL_PRFL_Cargo> cp_rmc_chg_sel_prfl_cargos) {
        List<RMC_CHG_SEL_PRFL_Cargo> rmc_chg_sel_prfl_cargos = new ArrayList<>();
        for(CP_RMC_CHG_SEL_PRFL_Cargo cp_rmc_chg_sel_prfl_cargo : cp_rmc_chg_sel_prfl_cargos){
            RMC_CHG_SEL_PRFL_Cargo rmc_chg_sel_prfl_cargo = new RMC_CHG_SEL_PRFL_Cargo();
            rmc_chg_sel_prfl_cargo.setApp_num(cp_rmc_chg_sel_prfl_cargo.getAppNum());

            if(Objects.nonNull(cp_rmc_chg_sel_prfl_cargo.getCat_seq_num())){
                rmc_chg_sel_prfl_cargo.setCat_seq_num(String.valueOf(cp_rmc_chg_sel_prfl_cargo.getCat_seq_num()));
            }

            rmc_chg_sel_prfl_cargo.setCat_typ(cp_rmc_chg_sel_prfl_cargo.getCat_typ());
            rmc_chg_sel_prfl_cargo.setChg_sel_cat_cd(cp_rmc_chg_sel_prfl_cargo.getChg_sel_cat_cd());
            rmc_chg_sel_prfl_cargo.setIndv_seq_num(cp_rmc_chg_sel_prfl_cargo.getIndvSeqNum());
            rmc_chg_sel_prfl_cargo.setStat_ind(cp_rmc_chg_sel_prfl_cargo.getStat_ind());
            if(Objects.nonNull(cp_rmc_chg_sel_prfl_cargo.getUser_end_sel_ind())) {
                rmc_chg_sel_prfl_cargo.setUser_end_sel_ind(String.valueOf(cp_rmc_chg_sel_prfl_cargo.getUser_end_sel_ind()));
            }
            rmc_chg_sel_prfl_cargos.add(rmc_chg_sel_prfl_cargo);
        }
        return  rmc_chg_sel_prfl_cargos;
    }

    /**
     * Get currentSequence detail.
     * @param aSelectionProfile
     * @return
     */
    public CategorySequenceDetail getCurrentSequenceDetail(SortedSet aSelectionProfile) {
        long startTime = System.currentTimeMillis();
        logger.info("CategorySelectionProfileManager.getCurrentSequenceDetail() - START");
        CategorySequenceDetail categorySeqDtl = null;
        final Iterator iter = aSelectionProfile.iterator();
        while (iter.hasNext()) {
            categorySeqDtl = (CategorySequenceDetail) iter.next();
            if (categorySeqDtl.isCurrentRecord()) {
                logger.info("CategorySelectionProfileManager.getCurrentSequenceDetail() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + AppConstants.SPACE + AppConstants.MILLISECONDS);
                return categorySeqDtl;
            }
        }
        logger.info( "CategorySelectionProfileManager.getCurrentSequenceDetail() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + AppConstants.SPACE + AppConstants.MILLISECONDS);
        return null;
    }

    public void updateSequence(SortedSet leftTheHomeProfile, Object o, short individualSequence, long catSeqNum, String categoryType) {
    }

    public void makeSequenceDetailComplete(SortedSet categorySelectionProfile, String appNum, short individualSequence, long categorySequence, String categoryType) {
    }

    public boolean areAllSequencesComplete(SortedSet leftTheHomeProfile) {
        return true;
    }

    public CategorySequenceDetail getNextSequenceDetail(SortedSet leftTheHomeProfile) {
        return getNextSequenceDetail(leftTheHomeProfile, null);
    }

    /**
     * Get Next sequence detail.
     * @param aSelectionProfile
     * @param aCatTyp
     * @return
     */
    public CategorySequenceDetail getNextSequenceDetail(final SortedSet aSelectionProfile, final Map aCatTyp) {
        CategorySequenceDetail nextCategorySeqDtl = null;
        final Iterator iter = aSelectionProfile.iterator();
        CategorySequenceDetail categorySeqDtl = null;
        boolean currentRecordFound = false;
        while (iter.hasNext()) {
            categorySeqDtl = (CategorySequenceDetail) iter.next();
            if ((aCatTyp == null) && !currentRecordFound && ((categorySeqDtl.getStatus() == STATUS_REQUIRED) || (categorySeqDtl.getStatus() == STATUS_VISIT_AGAIN))) {
                categorySeqDtl.setCurrentRecord(true);
                nextCategorySeqDtl = categorySeqDtl;
                currentRecordFound = true;
            } else if ((aCatTyp != null) && (aCatTyp.get(categorySeqDtl.getCategoryType()) != null) && !currentRecordFound && ((categorySeqDtl.getStatus() == STATUS_REQUIRED) || (categorySeqDtl.getStatus() == STATUS_VISIT_AGAIN))) {
                categorySeqDtl.setCurrentRecord(true);
                nextCategorySeqDtl = categorySeqDtl;
                currentRecordFound = true;
            } else {
                categorySeqDtl.setCurrentRecord(false);
            }
        }
        return nextCategorySeqDtl;
    }

    public SortedSet createPageProfile(SortedSet categorySelectionProfile, String[] catType) {
        try {
            final int catTypeSize = catType.length;
            SortedSet catSelProfile = new TreeSet(new CategorySequenceDetailsComparator());
            if (categorySelectionProfile != null) {
                final Iterator iter = categorySelectionProfile.iterator();
                CategorySequenceDetail categorySeqDtl = null;
                while (iter.hasNext()) {
                    categorySeqDtl = (CategorySequenceDetail) iter.next();
                    for (int i = 0; i < catTypeSize; i++) {
                        if (categorySeqDtl.getCategoryType().equals(catType[i]) && categorySeqDtl.getUserEndSelectionInd() != AppConstants.RMB_NO_CHANGE_SEL_IND) {
                            catSelProfile.add(categorySeqDtl);
                            break;
                        }
                    }
                }
            }
            return catSelProfile;
        } catch (Exception exception) {
            throw exception;
        }

    }


    public void resetCurrentSeqeunceDetail(SortedSet selectionProfile) {
    }

}
