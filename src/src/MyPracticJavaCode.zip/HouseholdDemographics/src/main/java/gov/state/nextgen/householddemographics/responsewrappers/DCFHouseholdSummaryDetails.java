package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("DCHHS")
@Scope("prototype")
public class DCFHouseholdSummaryDetails implements LogicResponseInterface {

	private static final String PAGE_ID = "DCHHS";

	DriverPageResponse driverPageResponse = new DriverPageResponse();

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		
		HouseholdCommonResponse response = new HouseholdCommonResponse(String.valueOf(fwTxn.getRequest().get(FwConstants.APP_NUMBER)), 
				PAGE_ID, String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)), 
				String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)), 
				String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
			
		

		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Started creating Response wrapper for DCHHS");

			Map<String, Object> pageCollection = fwTxn.getPageCollection();
			response.generateIndividualDriverResponse(pageCollection);

			/*
			 * loadContactInformationforAppNum
			 */
			
			response.generateContactDriverResponse(pageCollection);
			
			/*
			 * Auth Rep Collection
			 * 
			 */
			
			response.generateAuthDriverResponse(pageCollection);
		

			/*
			 * Program Related Data
			 */
			response.generateProgramDriverResponse(pageCollection);
		
			/*
			 * CP_APP_HSHL_RLT_Collection
			 */

			response.generateRelationDriverResponse(pageCollection);
			
			/*
			 * Household Details Collection
			 */
			response.generateHHDetailsDriverResponse(pageCollection);
			

			response.generateSubmitDriverResponse(pageCollection);
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Completed creating Response wrapper for DCHHS");

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Inside exception block of DCFHouseholdSummaryDetails",
					e);
		} 
		
		return response.getDriverPageResponse();
		 
	}

	

}
