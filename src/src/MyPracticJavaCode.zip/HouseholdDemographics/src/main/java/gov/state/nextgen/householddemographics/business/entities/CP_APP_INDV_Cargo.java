package gov.state.nextgen.householddemographics.business.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


public class CP_APP_INDV_Cargo {

    @Transient
	private String appNum;
	
	@Id
	@Column(name = "app_num")
	private int app_number;

    @Id
    @Column(name="indv_seq_num")
    private String indvSeqNum;

    public static class CP_APP_INDV_Key implements Serializable {

        private Integer app_number;
        private String indvSeqNum;

        public CP_APP_INDV_Key(Integer appNum, String indvSeqNum) {
            this.app_number = appNum;
            this.indvSeqNum = indvSeqNum;
        }

        public CP_APP_INDV_Key() {
        }
    }

    @Column(name="first_name")
    private String fst_nam;

    @Column(name="last_name")
    private String last_nam;

    @Column(name="mid_init")
    private String mid_init;

    @Column(name="rlvn_ind")
    private Integer rlvnInd;

    @Column(name="birth_dt")
    private Date brth_dt;

    @Column(name="sex_ind")
    private Character sex_ind;

    @Column(name="prim_prsn_sw")
    private Character prim_prsn_sw;

    @Column(name="live_arng_type")
    private String live_arng_typ;

    @Column (name="CHLD_OUT_HOME_RESP")
    private String chld_out_home_resp;

    @Column (name="SUFFIX_NAME"   )
    private String suffix_name;

    @Column (name="SRC_APP_IND"   )
    private String src_app_ind;

    @Column (name="CITIZEN_VERIFY_IND"   )
    private String citizen_verify_ind;

    @Column (name="BLND_DABL_IND"   )
    private String blnd_dabl_ind;

    @Column (name="LEFT_HOME_DT"   )
    private Timestamp left_home_dt;

    @Column (name="LEFT_HOME_REASON_CD"   )
    private String leftHomeReasonCd;
    
    public String getAppNum() {
		return String.valueOf(app_number);
	}
	public void setAppNum(String appNum) {
		this.app_number = Integer.parseInt(appNum);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.appNum = String.valueOf(app_number);
	}
	
    public Integer getRlvnInd() {
        return rlvnInd;
    }

    public void setRlvnInd(Integer rlvnInd) {
        this.rlvnInd = rlvnInd;
    }

    public String getFst_nam() {
        return fst_nam;
    }

    public void setFst_nam(String fst_nam) {
        this.fst_nam = fst_nam;
    }

    public String getLast_nam() {
        return last_nam;
    }

    public void setLast_nam(String last_nam) {
        this.last_nam = last_nam;
    }

    public String getMid_init() {
        return mid_init;
    }

    public void setMid_init(String mid_init) {
        this.mid_init = mid_init;
    }

    public Date getBrth_dt() {
        return brth_dt;
    }

    public void setBrth_dt(Date brth_dt) {
        this.brth_dt = brth_dt;
    }

    public Character getSex_ind() {
        return sex_ind;
    }

    public void setSex_ind(Character sex_ind) {
        this.sex_ind = sex_ind;
    }

    public Character getPrim_prsn_sw() {
        return prim_prsn_sw;
    }

    public void setPrim_prsn_sw(Character prim_prsn_sw) {
        this.prim_prsn_sw = prim_prsn_sw;
    }

    public String getLive_arng_typ() {
        return live_arng_typ;
    }

    public void setLive_arng_typ(String live_arng_typ) {
        this.live_arng_typ = live_arng_typ;
    }

    public String getChld_out_home_resp() {
        return chld_out_home_resp;
    }

    public void setChld_out_home_resp(String chld_out_home_resp) {
        this.chld_out_home_resp = chld_out_home_resp;
    }

    public String getSuffix_name() {
        return suffix_name;
    }

    public void setSuffix_name(String suffix_name) {
        this.suffix_name = suffix_name;
    }

    public String getSrc_app_ind() {
        return src_app_ind;
    }

    public void setSrc_app_ind(String src_app_ind) {
        this.src_app_ind = src_app_ind;
    }

    public String getCitizen_verify_ind() {
        return citizen_verify_ind;
    }

    public void setCitizen_verify_ind(String citizen_verify_ind) {
        this.citizen_verify_ind = citizen_verify_ind;
    }

    public String getBlnd_dabl_ind() {
        return blnd_dabl_ind;
    }

    public void setBlnd_dabl_ind(String blnd_dabl_ind) {
        this.blnd_dabl_ind = blnd_dabl_ind;
    }

    public String getIndvSeqNum() {
        return indvSeqNum;
    }

    public void setIndvSeqNum(String indvSeqNum) {
        this.indvSeqNum = indvSeqNum;
    }

    public Timestamp getLeft_home_dt() {
        return left_home_dt;
    }

    public void setLeft_home_dt(Timestamp left_home_dt) {
        this.left_home_dt = left_home_dt;
    }

    public String getLeftHomeReasonCd() {
        return leftHomeReasonCd;
    }

    public void setLeftHomeReasonCd(String leftHomeReasonCd) {
        this.leftHomeReasonCd = leftHomeReasonCd;
    }

}
