package gov.state.nextgen.householddemographics.business.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;
import gov.state.nextgen.householddemographics.data.db2.OtherHouseholdDetailsRepo;

@Service("CaretakerSelectionBO")
public class CaretakerSelectionBO extends AbstractBO{
	
	 @Autowired
	 protected HouseholdRelationshipRepo householdRelationshipRepo;
	 
	 @Autowired(required = true)
	 protected OtherHouseholdDetailsRepo otherHouseholdDetailsRepo;
	 
	 @Autowired
	 protected CpAppIndvRepository cpAppIndvRepository;

	public CP_APP_HSHL_RLT_Collection loadCaretakerExisitingDetails(String appNumber, Integer refIndvSeqNum) {
		return householdRelationshipRepo.loadCaretakerExisitingDetails(Integer.parseInt(appNumber),refIndvSeqNum);
	}

	public void saveCaretakerPersonDetails(CP_APP_HSHL_RLT_Collection cpAppHshlRltColl) {

		try {
			CP_APP_HSHL_RLT_Cargo cargo = null;
			if (cpAppHshlRltColl != null && !cpAppHshlRltColl.isEmpty()) {
				cargo = cpAppHshlRltColl.getCargo(0);
				householdRelationshipRepo.save(cargo);
			}
		}catch (final Exception exception) {
            throw exception;
        }
		
		
		
	
		
	}
	
	public OTHER_HOUSEHOLD_DETAILS_Collection loadCaretakerExisitingDetail(String app_num, Integer indv_seq_num) {
		return otherHouseholdDetailsRepo.loadCaretakerExisitingDetail(Integer.parseInt(app_num),indv_seq_num);
	}
	
	public void updateFixMealsAsEmptyByAppNum(String app_num) {
		otherHouseholdDetailsRepo.updateFixMealsAsEmptyByAppNum(Integer.parseInt(app_num));
	}
	
	public void updateCareTakerAsEmptyByAppNum(String app_num) {
		otherHouseholdDetailsRepo.updateCareTakerAsEmptyByAppNum(Integer.parseInt(app_num));
	}

	public void saveCaretakerPersonDetail(OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection) {

		try {
			OTHER_HOUSEHOLD_DETAILS_Cargo cargo = null;
			if (otherHouseholdDetailsCollection != null && !otherHouseholdDetailsCollection.isEmpty()) {
				cargo =  otherHouseholdDetailsCollection.getCargo(0);
				otherHouseholdDetailsRepo.save(cargo);
			}
		}catch (final Exception exception) {
            throw exception;
        }
	} 
	
	public OTHER_HOUSEHOLD_DETAILS_Collection backUnselectIndvChangedToN(String appNumber, ArrayList<Integer> indvCheckArray) {
		OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsOldCollection;
		OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsSwitchToNCollection=new OTHER_HOUSEHOLD_DETAILS_Collection();
		OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo;
		APP_INDV_Collection coll = cpAppIndvRepository.loadAppIndvData(Integer.parseInt(appNumber));
		List<String> indvList = new ArrayList<String>();
		for (int i=0; i<coll.size();i++) {
			APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) coll.get(i);
			indvList.add(indvCargo.getIndv_seq_num().toString());
		}
		for (String indvId:indvList) {
			if (Objects.nonNull(indvCheckArray) && !indvCheckArray.contains(indvId)) {
				otherHouseholdDetailsOldCollection = (OTHER_HOUSEHOLD_DETAILS_Collection)loadCaretakerExisitingDetail(appNumber,Integer.parseInt(indvId));
				if (Objects.nonNull(otherHouseholdDetailsOldCollection) && !otherHouseholdDetailsOldCollection.isEmpty()) {
					otherHouseholdDetailsCargo = otherHouseholdDetailsOldCollection.getCargo(0);
					otherHouseholdDetailsSwitchToNCollection.addCargo(otherHouseholdDetailsCargo);
				}
			}
		}
		return otherHouseholdDetailsSwitchToNCollection;
	}
	 
	 

}
