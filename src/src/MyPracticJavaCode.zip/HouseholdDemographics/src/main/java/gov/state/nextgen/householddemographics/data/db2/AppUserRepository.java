package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.APP_USER_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_USER_Collection;
import gov.state.nextgen.householddemographics.business.entities.AppUserIdentity;


@Repository
public interface AppUserRepository extends CrudRepository<APP_USER_Cargo, AppUserIdentity> {
	@Query("select c.app_number from APP_USER_Cargo c where c.acs_id =?1")
	public List<Integer> getByGUID(String gUID);
	

	@Query("SELECT T FROM APP_USER_Cargo T where T.acs_id= :acs_id")
	public APP_USER_Collection findAllByAcsId(@Param("acs_id") String acsId);
	
	@Query("select c from APP_USER_Cargo c where c.app_number =?1")
	public APP_USER_Cargo getByAppNum(Integer appNum);
	
	@Query("select c from APP_USER_Cargo c order by c.acs_id")
	public APP_USER_Cargo[] findAllUserData();
	
	
}
