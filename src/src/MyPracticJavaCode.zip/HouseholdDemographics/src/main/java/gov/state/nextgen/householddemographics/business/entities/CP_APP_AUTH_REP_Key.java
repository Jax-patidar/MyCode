package gov.state.nextgen.householddemographics.business.entities;

public class CP_APP_AUTH_REP_Key implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	private Integer app_number;
	private String rep_code;
	private int seq_num;
	
	public CP_APP_AUTH_REP_Key() {	
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((rep_code == null) ? 0 : rep_code.hashCode());
		result = prime * result + seq_num;
		return result;
	}
	
	public CP_APP_AUTH_REP_Key(Integer app_num, String rep_code, int seq_num) {
		super();
		this.app_number = app_num;
		this.rep_code = rep_code;
		this.seq_num = seq_num;
	}
	
}
