package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.util.List;

public class SummarySection implements Serializable {

    private static final long serialVersionUID = 7224047407731049190L;

    private List rowList;

    private String showAddSection;

    private List<IndividualDropDownRow> indvDDList;

    private List<TypeDropDownRow> typeDDList;

    private String refTableName;

    private String refTableCoulmnId;

    public List getRowList() {
        return rowList;
    }

    public void setRowList(List rowList) {
        this.rowList = rowList;
    }

    public String getShowAddSection() {
        return showAddSection;
    }

    public void setShowAddSection(String showAddSection) {
        this.showAddSection = showAddSection;
    }

    public List<IndividualDropDownRow> getIndvDDList() {
        return indvDDList;
    }

    public void setIndvDDList(List<IndividualDropDownRow> indvDDList) {
        this.indvDDList = indvDDList;
    }

    public List<TypeDropDownRow> getTypeDDList() {
        return typeDDList;
    }

    public void setTypeDDList(List<TypeDropDownRow> typeDDList) {
        this.typeDDList = typeDDList;
    }

    public String getRefTableName() {
        return refTableName;
    }

    public void setRefTableName(String refTableName) {
        this.refTableName = refTableName;
    }

    public String getRefTableCoulmnId() {
        return refTableCoulmnId;
    }

    public void setRefTableCoulmnId(String refTableCoulmnId) {
        this.refTableCoulmnId = refTableCoulmnId;
    }
}
