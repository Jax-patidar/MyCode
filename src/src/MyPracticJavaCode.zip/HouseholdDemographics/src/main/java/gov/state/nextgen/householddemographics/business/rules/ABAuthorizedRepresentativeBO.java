package gov.state.nextgen.householddemographics.business.rules;

import java.util.HashMap;

import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CpAppAuthRepRepository;

@Service("ABAuthorizedRepresentativeBO")
public class ABAuthorizedRepresentativeBO extends AbstractBO {
	
	@PersistenceContext
	EntityManager entityManager ;
	private FwMessageList messageList = new FwMessageList();
	@Autowired
	private CpAppAuthRepRepository cpAppAuthRepRepository;
	/**
	 * Constructor
	 *
	 * @author Deloitte Consulting.
	 */
	public ABAuthorizedRepresentativeBO() {
	}

	public CP_APP_AUTH_REP_Collection loadAuthorizedRepresentativeInformation(
			final String appNumber, final String seqNumber, final String repCode) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABAuthorizedRepresentativeBO.loadAuthorizedRepresentativeInformation() - START, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");

		try {
			CP_APP_AUTH_REP_Collection appInColl = new CP_APP_AUTH_REP_Collection();
			final Map value = new HashMap();
		
			
			appInColl = cpAppAuthRepRepository.getByAppNum_SeqNum_RepCode(Integer.parseInt(appNumber), seqNumber, repCode);
			

		

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABAuthorizedRepresentativeBO.loadAuthorizedRepresentativeInformation() - END, Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");

			return appInColl;
		} catch (final FwException fe) {
			throw fe;
		 
			
		} catch (final Exception e) {
			throw e;
		}

	}
	/**
	 * @param appNumber
	 * @return
	 */
	public CP_APP_AUTH_REP_Collection loadAuthorizedRepresentativeInformation(
			final String appNumber, int seqNum, final String repCode) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABAuthorizedRepresentativeBO.loadAuthorizedRepresentativeInformation() - START, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");

		try {
			CP_APP_AUTH_REP_Collection appInColl = new CP_APP_AUTH_REP_Collection();
			final Map value = new HashMap();
	
			appInColl = cpAppAuthRepRepository.getCalfreshDetails(Integer.parseInt(appNumber), seqNum, repCode);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABAuthorizedRepresentativeBO.loadAuthorizedRepresentativeInformation() - END, Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");

			return appInColl;
		} catch (final FwException fe) {
			throw fe;
		 
			
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public void storeAuthorizedRepresentativeDetails(
			final CP_APP_AUTH_REP_Cargo authRepCargo) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABAuthorizedRepresentativeBO.storeAuthorizedRepresentativeInformation() - START, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		try {
			cpAppAuthRepRepository.save(authRepCargo);			
		} catch (final FwException fe) {
			throw fe;
		 
			
		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABAuthorizedRepresentativeBO.storeAuthorizedRepresentativeInformation() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
	}
	
	
	
	
	
	public void storeAuthorizedRepresentativeInformation(
			final CP_APP_AUTH_REP_Collection appRgstColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABAuthorizedRepresentativeBO.storeAuthorizedRepresentativeInformation() - START, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		try {

			if (appRgstColl != null && !appRgstColl.isEmpty()) {
				for (CP_APP_AUTH_REP_Cargo cargo : appRgstColl.getResults()) {
				cpAppAuthRepRepository.save(cargo);
				}
			}
		} catch (final FwException fe) {
			throw fe;
		 
			
		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABAuthorizedRepresentativeBO.storeAuthorizedRepresentativeInformation() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
	}
	
	public FwMessageList validateAuthorizedRepresentativeInformation(
			final CP_APP_AUTH_REP_Cargo cpAppAuthRepCargo,
			final String loopingQuestion, final Map request) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABAuthorizedRepresentativeBO.validateAuthorizedRepresentativeInformation() - START, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		try {

			final char[] citySpecialChars = { '\'', '-', '.', ' ' };
			final char[] specialCharsForAddress1 = { '-', ' '};

			boolean msg99476Added = false;
			boolean msg99488Added = false;

			final Object[] error = new Object[] {};

			if (!appMgr.isFieldEmpty(cpAppAuthRepCargo.getAuth_rep_nam())
					&& !appMgr.isSpecialAlphaNumeric(
							cpAppAuthRepCargo.getAuth_rep_nam(),
							citySpecialChars)) {

				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00710));

			}
			if (!appMgr.isFieldEmpty(cpAppAuthRepCargo.getAuth_rep_nam())
					&& cpAppAuthRepCargo.getAuth_rep_nam().charAt(0) == '0') {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00711));
			}
			// for CR 507224 defect 82061
			// for the address line one- validation 3
			if (!appMgr.isFieldEmpty(cpAppAuthRepCargo.getL1_adr())
					&& !appMgr.isSpecialAlphaNumeric(
							cpAppAuthRepCargo.getL1_adr(),
							specialCharsForAddress1)) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99476));
				msg99476Added = true;

			}

			if (!msg99476Added
					&& !appMgr.isFieldEmpty(cpAppAuthRepCargo
							.getL2_adr())) {
				if (!appMgr
						.isFieldEmpty(cpAppAuthRepCargo.getL2_adr())
						&& !appMgr.isSpecialAlphaNumeric(
								cpAppAuthRepCargo.getL2_adr(),
								specialCharsForAddress1)) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99476));
				}

			}
			
			
			// Added as part of defect 82203
			
			if (!appMgr.isFieldEmpty(cpAppAuthRepCargo.getL1_adr())) {
							
			                 if (appMgr.valSeriesofNums(cpAppAuthRepCargo.getL1_adr()) ){
			                	 msg99488Added=true;
			                	 messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99488));
			                 }
			}
			
			
			if (!msg99488Added && !appMgr.isFieldEmpty(cpAppAuthRepCargo.getL2_adr())) {
				
                 if (appMgr.valSeriesofNums(cpAppAuthRepCargo.getL2_adr()) ){
                	 messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99488));
                 }
            }

			// for the city - validation 4
			if (!appMgr.isFieldEmpty(cpAppAuthRepCargo.getCity_adr())
					&& !appMgr.isAlphaWithSpace(cpAppAuthRepCargo
							.getCity_adr())) {
				this.addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_00018, error);

			}

			// zipcode
			if (!appMgr.isFieldEmpty(cpAppAuthRepCargo.getZip_adr())) {
				if (!appMgr.isInteger(cpAppAuthRepCargo.getZip_adr())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00019));
				} else if (!(cpAppAuthRepCargo.getZip_adr().length() == 5)) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10503));
				} else if ("00000".equals(cpAppAuthRepCargo
						.getZip_adr())
						|| "000000000".equals(cpAppAuthRepCargo
								.getZip_adr())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00020));
				}

			}
			if (!messageList.containsMessage("00019")
					&& cpAppAuthRepCargo.getAddr_zip4() != null
					&& !"".equals(cpAppAuthRepCargo.getAddr_zip4().trim())
					&& !cpAppAuthRepCargo.getAddr_zip4().matches("\\d+")) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00019));
			}

			if (!appMgr.isFieldEmpty(cpAppAuthRepCargo.getPhn_num())) {
				if (!appMgr.isInteger(cpAppAuthRepCargo.getPhn_num())
						|| cpAppAuthRepCargo.getPhn_num().length() != 10) {

					this.addMessageWithFieldValues("90926", error);
				}
				if (cpAppAuthRepCargo.getPhn_num().startsWith("0")) {

					this.addMessageWithFieldValues("10238", error);
				}
				if (!appMgr.isInteger(cpAppAuthRepCargo.getPhn_num())) {

					this.addMessageWithFieldValues("40120", error);
				}
			}

			if (null != cpAppAuthRepCargo.getAuth_rep_id_num() && !appMgr.isInteger(cpAppAuthRepCargo.getAuth_rep_id_num())) {
				this.addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_70019, error);

			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABAuthorizedRepresentativeBO.validateAuthorizedRepresentativeInformation() - END, Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");

			return messageList;
		} catch (final FwException fe) {
			throw fe;
		 
			
		} catch (final Exception e) {
			throw e;
		}

	}

	public CP_APP_AUTH_REP_Collection loadDetails(String appNumber, int seqNum, String repCode) {
		return cpAppAuthRepRepository.getCalfreshDetails(Integer.parseInt(appNumber),seqNum,repCode);
	}
	
	public int getMaxAuthRepSeq(String appNum, String srcAppInd, String repCode) {
	 try {	
		int max = 0;
		Integer result = cpAppAuthRepRepository.getMaxSeqNum(Integer.parseInt(appNum), srcAppInd, repCode);
		if (result != null) {
			max = result;
		}
		return max;
	 }catch(Exception e) {
		 throw e;
	 }
	}
	
	public CP_APP_AUTH_REP_Collection getBeforeColl(String appNum, String srcAppInd, String repCode) {
		CP_APP_AUTH_REP_Collection coll ;
		coll = cpAppAuthRepRepository.getBeforeColl(Integer.parseInt(appNum), srcAppInd, repCode);
		return coll;
	}
	
	public CP_APP_AUTH_REP_Collection getByAppNum(String appNum) {
		CP_APP_AUTH_REP_Collection coll;
		coll = cpAppAuthRepRepository.getByAppNum(Integer.parseInt(appNum));
		return coll;
	}
}
	
	

