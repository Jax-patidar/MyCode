package gov.state.nextgen.householddemographics.data.db2;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.WIC_CLINIC_INFO_Cargo;
import gov.state.nextgen.householddemographics.business.entities.WIC_CLINIC_INFO_Key;

@NoRepositoryBean
public interface WicClinicInfoRepository extends CrudRepository<WIC_CLINIC_INFO_Cargo,WIC_CLINIC_INFO_Key>{

	@Query("select c from WIC_CLINIC_INFO_Cargo c where c.eff_end_dt = ?1")
	public List getByEffEndDt(Date effEndDt);
	
	@Query("select c.clinic_cd, c.clinic_county_cd, c.clinic_name, c.clinic_addr_line1, c.clinic_addr_line2, c.clinic_city, c.clinic_zip, "
			+ "c.clinic_state_cd, c.clinic_phone_num from WIC_CLINIC_INFO_Cargo c where c.eff_end_dt = null")
	public List loadWICClncInformation();
	
	@Query("select c from WIC_CLINIC_INFO_Cargo c where c.clinic_cd = ?1")
	public WIC_CLINIC_INFO_Cargo loadWICClncName(String wic_clnc_cd);
}
