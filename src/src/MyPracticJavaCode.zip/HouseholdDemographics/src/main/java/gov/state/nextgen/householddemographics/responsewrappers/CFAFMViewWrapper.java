
package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_CARE_PROV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_CARE_PROV_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;




@Component("CFAFM")
@Scope("prototype")
public class CFAFMViewWrapper implements LogicResponseInterface {
	
	private static final String PAGE_ID = "CFAFM";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
			
		
		driverPageResponse.setCurrentPageID(PAGE_ID);
	
		
		return driverPageResponse;
		
		
	}
	
}
