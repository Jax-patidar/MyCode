package gov.state.nextgen.householddemographics.business.rules;


import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Collection;
import org.springframework.stereotype.Component;

@Component
public class HouseHoldInfoBO extends HouseHoldBaseBO {
    public APP_HSHL_RLT_Collection getRelationDetails(APP_HSHL_RLT_Cargo relationCargo) {
        return null;
    }
}
