
package gov.state.nextgen.householddemographics.business.entities;

import java.rmi.RemoteException;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_IN_FosterCare_Collection extends AbstractCollection{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4857868473863055525L;
	
	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_FosterCare_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_FosterCare_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}


	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_FosterCare_Cargo[]) {
			final APP_IN_FosterCare_Cargo[] cbArray = (APP_IN_FosterCare_Cargo[]) obj;
			setResults(cbArray);
		}
	}

	


}

