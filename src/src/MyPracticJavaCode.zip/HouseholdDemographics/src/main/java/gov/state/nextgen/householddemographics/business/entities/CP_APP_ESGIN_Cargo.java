package gov.state.nextgen.householddemographics.business.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;

import org.hibernate.annotations.ColumnDefault;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.management.constants.FwConstants;


public class CP_APP_ESGIN_Cargo extends AbstractCargo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	private String appNum;

	@ColumnDefault(FwConstants.ONE)
	@Column(name = "seq_num", nullable = false)
	private Integer seqNum;

	private String srcAppInd;

	private String appl_esign_ind;
	private String appl_fst_nam;
	private String appl_last_nam;
	private String appl_mid_init;
	private String appl_suffix_name;
	private Date appl_esign_date;
	private String auth_rep_esign_ind;
	private String auth_rep_fst_nam;
	private String auth_rep_last_nam;
	private String auth_rep_mid_init;
	private String auth_rep_suffix_name;
	private Date auth_rep_esign_date;
	private String appl_hipaa_esign_ind;
	private String appl_hipaa_fst_nam;
	private String appl_hipaa_last_nam;
	private String appl_hipaa_mid_init;
	private String appl_hipaa_suffix_name;
	private Date appl_hipaa_esign_date;
	private String appl_citz_decl_esign_ind;
	private String appl_citz_decl_fst_nam;
	private String appl_citz_decl_last_nam;
	private String appl_citz_decl_mid_init;
	private String appl_citz_decl_suffix_name;
	private Date appl_citz_decl_esign_date;
	private String appl_voter_reg_resp;

	public String getAppNum() {
		return appNum;
	}

	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}

	public Integer getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}

	public String getSrcAppInd() {
		return srcAppInd;
	}

	public void setSrcAppInd(String srcAppInd) {
		this.srcAppInd = srcAppInd;
	}

	public String getAppl_esign_ind() {
		return appl_esign_ind;
	}

	public void setAppl_esign_ind(final String appl_esign_ind) {
		this.appl_esign_ind = appl_esign_ind;
	}

	public String getAppl_fst_nam() {
		return appl_fst_nam;
	}

	public void setAppl_fst_nam(final String appl_fst_nam) {
		this.appl_fst_nam = appl_fst_nam;
	}

	public String getAppl_last_nam() {
		return appl_last_nam;
	}

	public void setAppl_last_nam(final String appl_last_nam) {
		this.appl_last_nam = appl_last_nam;
	}

	public String getAppl_mid_init() {
		return appl_mid_init;
	}

	public void setAppl_mid_init(final String appl_mid_init) {
		this.appl_mid_init = appl_mid_init;
	}

	public String getAppl_suffix_name() {
		return appl_suffix_name;
	}

	public void setAppl_suffix_name(final String appl_suffix_name) {
		this.appl_suffix_name = appl_suffix_name;
	}

	public Date getAppl_esign_date() {
		return (Date) appl_esign_date.clone();
	}

	public void setAppl_esign_date(final Date appl_esign_date) {
		this.appl_esign_date = (Date) appl_esign_date.clone();
	}

	public String getAuth_rep_esign_ind() {
		return auth_rep_esign_ind;
	}

	public void setAuth_rep_esign_ind(final String auth_rep_esign_ind) {
		this.auth_rep_esign_ind = auth_rep_esign_ind;
	}

	public String getAuth_rep_fst_nam() {
		return auth_rep_fst_nam;
	}

	public void setAuth_rep_fst_nam(final String auth_rep_fst_nam) {
		this.auth_rep_fst_nam = auth_rep_fst_nam;
	}

	public String getAuth_rep_last_nam() {
		return auth_rep_last_nam;
	}

	public void setAuth_rep_last_nam(final String auth_rep_last_nam) {
		this.auth_rep_last_nam = auth_rep_last_nam;
	}

	public String getAuth_rep_mid_init() {
		return auth_rep_mid_init;
	}

	public void setAuth_rep_mid_init(final String auth_rep_mid_init) {
		this.auth_rep_mid_init = auth_rep_mid_init;
	}

	public String getAuth_rep_suffix_name() {
		return auth_rep_suffix_name;
	}

	public void setAuth_rep_suffix_name(final String auth_rep_suffix_name) {
		this.auth_rep_suffix_name = auth_rep_suffix_name;
	}

	public Date getAuth_rep_esign_date() {
		return (Date) auth_rep_esign_date.clone();
	}

	public void setAuth_rep_esign_date(final Date auth_rep_esign_date) {
		this.auth_rep_esign_date = (Date) auth_rep_esign_date.clone();
	}

	public String getAppl_hipaa_esign_ind() {
		return appl_hipaa_esign_ind;
	}

	public void setAppl_hipaa_esign_ind(final String appl_hipaa_esign_ind) {
		this.appl_hipaa_esign_ind = appl_hipaa_esign_ind;
	}

	public String getAppl_hipaa_fst_nam() {
		return appl_hipaa_fst_nam;
	}

	public void setAppl_hipaa_fst_nam(final String appl_hipaa_fst_nam) {
		this.appl_hipaa_fst_nam = appl_hipaa_fst_nam;
	}

	public String getAppl_hipaa_last_nam() {
		return appl_hipaa_last_nam;
	}

	public void setAppl_hipaa_last_nam(final String appl_hipaa_last_nam) {
		this.appl_hipaa_last_nam = appl_hipaa_last_nam;
	}

	public String getAppl_hipaa_mid_init() {
		return appl_hipaa_mid_init;
	}

	public void setAppl_hipaa_mid_init(final String appl_hipaa_mid_init) {
		this.appl_hipaa_mid_init = appl_hipaa_mid_init;
	}

	public String getAppl_hipaa_suffix_name() {
		return appl_hipaa_suffix_name;
	}

	public void setAppl_hipaa_suffix_name(final String appl_hipaa_suffix_name) {
		this.appl_hipaa_suffix_name = appl_hipaa_suffix_name;
	}

	public Date getAppl_hipaa_esign_date() {
		return (Date) appl_hipaa_esign_date.clone();
	}

	public void setAppl_hipaa_esign_date(final Date appl_hipaa_esign_date) {
		this.appl_hipaa_esign_date = (Date) appl_hipaa_esign_date.clone();
	}

	public String getAppl_citz_decl_esign_ind() {
		return appl_citz_decl_esign_ind;
	}

	public void setAppl_citz_decl_esign_ind(final String appl_citz_decl_esign_ind) {
		this.appl_citz_decl_esign_ind = appl_citz_decl_esign_ind;
	}

	public String getAppl_citz_decl_fst_nam() {
		return appl_citz_decl_fst_nam;
	}

	public void setAppl_citz_decl_fst_nam(final String appl_citz_decl_fst_nam) {
		this.appl_citz_decl_fst_nam = appl_citz_decl_fst_nam;
	}

	public String getAppl_citz_decl_last_nam() {
		return appl_citz_decl_last_nam;
	}

	public void setAppl_citz_decl_last_nam(final String appl_citz_decl_last_nam) {
		this.appl_citz_decl_last_nam = appl_citz_decl_last_nam;
	}

	public String getAppl_citz_decl_mid_init() {
		return appl_citz_decl_mid_init;
	}

	public void setAppl_citz_decl_mid_init(final String appl_citz_decl_mid_init) {
		this.appl_citz_decl_mid_init = appl_citz_decl_mid_init;
	}

	public String getAppl_citz_decl_suffix_name() {
		return appl_citz_decl_suffix_name;
	}

	public void setAppl_citz_decl_suffix_name(final String appl_citz_decl_suffix_name) {
		this.appl_citz_decl_suffix_name = appl_citz_decl_suffix_name;
	}

	public Date getAppl_citz_decl_esign_date() {
		return (Date) appl_citz_decl_esign_date.clone();
	}

	public String getAppl_voter_reg_resp() {
		return appl_voter_reg_resp;
	}

	public void setAppl_citz_decl_esign_date(final Date appl_citz_decl_esign_date) {
		this.appl_citz_decl_esign_date = (Date) appl_citz_decl_esign_date.clone();
	}

	public void setAppl_voter_reg_resp(final String appl_voter_reg_resp) {
		this.appl_voter_reg_resp = appl_voter_reg_resp;
	}

	@Override
	public String getUser() {
		return null;
	}

	@Override
	public void setUser(String newUser) {

	}

	@Override
	public boolean isDirty() {
		return false;
	}

	@Override
	public void setDirty(boolean dirty) {

	}

	@Override
	public String getRowAction() {
		return null;
	}
}
