package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseIndividualDetailsTaxReview  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3846938092763145947L;
	
	private String person;
	private String taxFilingStatus;
	private boolean primaryTaxFilerInd;
	private boolean plansToFileTaxReturn;
	private boolean expectedToFileTaxReturn;
	
	public String getPerson() {
		return person;
	}
	public void setPerson(String person) {
		this.person = person;
	}
	public String getTaxFilingStatus() {
		return taxFilingStatus;
	}
	public void setTaxFilingStatus(String taxFilingStatus) {
		this.taxFilingStatus = taxFilingStatus;
	}
	public boolean isPrimaryTaxFilerInd() {
		return primaryTaxFilerInd;
	}
	public void setPrimaryTaxFilerInd(boolean primaryTaxFilerInd) {
		this.primaryTaxFilerInd = primaryTaxFilerInd;
	}
	public boolean isPlansToFileTaxReturn() {
		return plansToFileTaxReturn;
	}
	public void setPlansToFileTaxReturn(boolean plansToFileTaxReturn) {
		this.plansToFileTaxReturn = plansToFileTaxReturn;
	}
	public boolean isExpectedToFileTaxReturn() {
		return expectedToFileTaxReturn;
	}
	public void setExpectedToFileTaxReturn(boolean expectedToFileTaxReturn) {
		this.expectedToFileTaxReturn = expectedToFileTaxReturn;
	}
}
