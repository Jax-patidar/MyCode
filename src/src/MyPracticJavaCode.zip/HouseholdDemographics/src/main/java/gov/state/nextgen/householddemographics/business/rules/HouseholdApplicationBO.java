/**
 * 
 */
package gov.state.nextgen.householddemographics.business.rules;

import static gov.state.nextgen.householddemographics.constants.HouseholdApplicationConstants.APPLICATIONPROCESSED;
import static gov.state.nextgen.householddemographics.constants.HouseholdApplicationConstants.CWPROGRAMCODE;
import static gov.state.nextgen.householddemographics.constants.HouseholdApplicationConstants.FSPROGRAMCODE;
import static gov.state.nextgen.householddemographics.constants.HouseholdApplicationConstants.MCPROGRAMCODE;
import static gov.state.nextgen.householddemographics.constants.HouseholdApplicationConstants.ONEINDICATOR;
import static gov.state.nextgen.householddemographics.utilities.DateUtility.getPSTDateFromDate;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.constants.HouseholdApplicationConstants;
import gov.state.nextgen.householddemographics.data.db2.AppUserRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppRgstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpRmbRequestDetailsRepository;
import gov.state.nextgen.householddemographics.data.db2.RMBRqstRepository;
import gov.state.nextgen.householddemographics.model.ChangeRenewalApplicationsRespone;
import gov.state.nextgen.householddemographics.model.IndividualResponse;
import gov.state.nextgen.householddemographics.model.OngoingApplicationsResponse;
import gov.state.nextgen.householddemographics.model.ProgramListResponse;;

/**
 * @author rudeshmukh
 *
 */
@Service("HouseholdApplicationBO")
@PropertySource("classpath:application.properties")
public class HouseholdApplicationBO extends AbstractBO {
	
	@Autowired
	private AppUserRepository appUserRepo;

	@Autowired
	private CpAppRqstRepository cpAppRequestRepository;

	@Autowired
	private RMBRqstRepository cpRmbRequestRepository;
	
	@Autowired
	private CpAppIndvRepository cpAppIndvRepository;
	
	@Autowired
	private CpAppPgmIndvRepository cpAppIndvPgmRepository;
	
	@Autowired
	private CpAppRgstRepository cpAppRgstRepository;
	
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	protected Environment env;
	
	@Autowired
	CpRmbRequestDetailsRepository cpRmbRequestDetailsRepository;
	
	private boolean is_app_num_link_loggedin = false;

	public APP_RQST_Collection getAllOngoingApplicationsRequestData(List<Integer> appNumList) {
		APP_RQST_Collection appRequestCollection = new APP_RQST_Collection();
		List<String> statList = new ArrayList<>();
		statList.add(APPLICATIONPROCESSED);
		statList.add(HouseholdApplicationConstants.APPLICATIONDELETED);
		try {
			APP_RQST_Cargo[] appRequestCargos = cpAppRequestRepository.findByAppNumInAndAppStatCdNot(appNumList,
					statList);
			
			if (Objects.nonNull(appRequestCargos) && appRequestCargos.length > 0) {
				
				appRequestCollection.setResults(appRequestCargos);
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR,
					"Error in HouseholdApplicationBO.getAllOngoingApplicationsRequestData: " + e.getMessage());
			throw createFwException(this.getClass().getName(), "getAllOngoingApplicationsRequestData", e);
		}
		return appRequestCollection;
	}

	@SuppressWarnings("squid:S3776")
	public List<ChangeRenewalApplicationsRespone> getChangeRenewalApplicationsResponeResponse(List<String> caseList,
			List<APP_RQST_Cargo> appRequestList) {
		List<ChangeRenewalApplicationsRespone> responseList = new ArrayList<>();
		try {
			List<RMB_RQST_Cargo> rmbRequestCargoList = new ArrayList<RMB_RQST_Cargo>();
			LocalDateTime localDateTime = LocalDateTime.now();
			List<String> caseNumList = new ArrayList<>();
			for (String caseValue : caseList) {
				if (StringUtils.isNotBlank(caseValue) && caseValue.length() > 1) {
					String[] caseNumAndCountyNum = caseValue.split("~");
					if (Objects.nonNull(caseNumAndCountyNum) && caseNumAndCountyNum.length > 1) {
						String caseNum = caseNumAndCountyNum[0];
						String countyCd = caseNumAndCountyNum[1];
						if (StringUtils.isNotBlank(countyCd)) {
							RMB_RQST_Cargo[] rmbRequestCargo = cpRmbRequestRepository
									.findByCaseNumCountyCdAndCurrentDate(caseNum, countyCd, localDateTime);
							if (Objects.nonNull(rmbRequestCargo) && rmbRequestCargo.length > 0) {
								rmbRequestCargoList.addAll(Arrays.asList(rmbRequestCargo));
							}
						} else {
							caseNumList.add(caseNum);
						}
					} else if (Objects.nonNull(caseNumAndCountyNum) && caseNumAndCountyNum.length == 1) {
						caseNumList.add(caseNumAndCountyNum[0]);
					}
				}
			}

			if (Objects.nonNull(caseNumList) && caseNumList.size() > 0) {
				RMB_RQST_Cargo[] rmbRequestCargo = cpRmbRequestRepository.findByCaseNumIn(caseNumList, localDateTime);
				if (Objects.nonNull(rmbRequestCargo) && rmbRequestCargo.length > 0) {
					rmbRequestCargoList.addAll(Arrays.asList(rmbRequestCargo));
				}
			}

			if (Objects.nonNull(rmbRequestCargoList) && rmbRequestCargoList.size() > 0) {

				for (RMB_RQST_Cargo currentCpRmbReqCargo : rmbRequestCargoList) {
					Optional<APP_RQST_Cargo> appRequestCargoOptional = getUnprocessedApplicationRelatedtoCase(
							String.valueOf(currentCpRmbReqCargo.getSsp_app_num()), appRequestList);

					if (is_app_num_link_loggedin) {
						ChangeRenewalApplicationsRespone response = new ChangeRenewalApplicationsRespone();
						response.setFormDueDate(currentCpRmbReqCargo.getForm_due_dt());
						response.setFormType(currentCpRmbReqCargo.getForm_rpt_type());
						response.setViewEndDate(currentCpRmbReqCargo.getApp_end_dt());
						response.setRmbRequestId(currentCpRmbReqCargo.getCp_rmb_request_id());
						response.setCaseNumber(currentCpRmbReqCargo.getCase_num());
						response.setProgramList(getProgramListFromFormStatusClob(currentCpRmbReqCargo.getCp_rmb_request_id()));
						
						if (appRequestCargoOptional.isPresent()) {
							populateOngoingResponseFromReqCargo(appRequestCargoOptional.get(), response);
						}

						responseList.add(response);
					}
				}
			}
			if (Objects.nonNull(appRequestList) && !appRequestList.isEmpty()) {
				for (APP_RQST_Cargo appRqstCargo : appRequestList) {
					if (appRqstCargo.getFormRptType().equals(HouseHoldDemoGraphicsConstants.FORM_TYPE_RAC)) {
						ChangeRenewalApplicationsRespone response = new ChangeRenewalApplicationsRespone();
						response.setFormType(appRqstCargo.getFormRptType());
						response.setCaseNumber(appRqstCargo.getCaseNum());
						populateOngoingResponseFromReqCargo(appRqstCargo, response);
						responseList.add(response);
					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR,
					"Error in HouseholdApplicationBO.getChangeRenewalApplicationsResponeResponse: " + e.getMessage());
			throw createFwException(this.getClass().getName(), "getChangeRenewalApplicationsResponeResponse", e);
		}
		return responseList;

	}

	private List<String> getProgramListFromFormStatusClob(Long rmbRequestId)
			throws JsonProcessingException, JsonMappingException {
		List<String> programList = Collections.<String>emptyList();
		CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = cpRmbRequestDetailsRepository
				.getCpRmbRequestId(rmbRequestId);
		if (Objects.nonNull(cpRmbRequestDetailsCollection) && !cpRmbRequestDetailsCollection.isEmpty()) {
			CpRmbRequestDetails_Cargo cpRmbRequestDetailsCargo = (CpRmbRequestDetails_Cargo) cpRmbRequestDetailsCollection
					.get(0);
			Map formStatusReqJson = (Map) new ObjectMapper()
					.readValue(cpRmbRequestDetailsCargo.getForm_status_req(), Object.class);
		    programList = Objects.nonNull(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.PROGRAM_LIST))
					? (List<String>) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.PROGRAM_LIST)
							: null;
		}
		return programList;
	}

	public List<OngoingApplicationsResponse> getAllOngoingApplicationsResponseList(
			List<APP_RQST_Cargo> caseNumNullAppList) {
		List<OngoingApplicationsResponse> responseList = new ArrayList<>();

		if (Objects.nonNull(caseNumNullAppList) && !caseNumNullAppList.isEmpty()) {

			for (APP_RQST_Cargo currentCpAppReqCargo : caseNumNullAppList) {

				OngoingApplicationsResponse response = new OngoingApplicationsResponse();
				populateOngoingResponseFromReqCargo(currentCpAppReqCargo, response);
				responseList.add(response);
			}
		}
		
		return responseList;

	}

	private String getCountyCountyCode(String appNum) {
		try {
			APP_RGST_Cargo[] cpAppRgstList = cpAppRgstRepository.getByAppNum(Integer.parseInt(appNum));
			APP_RGST_Collection cpAppRgstCollection = cpAppRgstRepository.loadCpAppRgstDetails(Integer.parseInt(appNum),1);
			if (Objects.nonNull(cpAppRgstCollection) && !cpAppRgstCollection.isEmpty()
					&& Objects.nonNull(cpAppRgstCollection.getCargo(0))) {
				return cpAppRgstCollection.getCargo(0).getCnty_num();
			}else if (Objects.nonNull(cpAppRgstList) && cpAppRgstList.length > 0) {
				return cpAppRgstList[0].getCnty_num();
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR,
					"Error in HouseholdApplicationBO.getCountyCountyCode: " + e.getMessage());
			throw createFwException(this.getClass().getName(), "getCountyCountyCode", e);
		}
		return "";
	}

	private List<IndividualResponse> getIndividualListForApplication(String appNum) {
		List<IndividualResponse> individualResponseList = new ArrayList<>();
		try {
			APP_INDV_Cargo[] appsIndvList = cpAppIndvRepository.getByAppNum(Integer.parseInt(appNum));

			if (Objects.nonNull(appsIndvList) && appsIndvList.length >0) {
				
				Stream.of(appsIndvList).forEach(indvCargo -> {
					IndividualResponse indvResponse = new IndividualResponse(indvCargo);
					individualResponseList.add(indvResponse);
				});
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR,
					"Error in HouseholdApplicationBO.getIndividualListForApplication: " + e.getMessage());
			throw createFwException(this.getClass().getName(), "getIndividualListForApplication", e);
		}
		return individualResponseList;
	}

	private List<ProgramListResponse> getProgramResponseListForApplication(String appNum) {

		List<ProgramListResponse> programList = new ArrayList<>();
		try {
			CP_APP_PGM_INDV_Collection appPgmCollection = cpAppIndvPgmRepository.getDetails(Integer.parseInt(appNum));
			CP_APP_PGM_INDV_Cargo[] appsPgmList = appPgmCollection.getResults();

			if (Objects.nonNull(appsPgmList) && appsPgmList.length >0) {
				Map<String, List<Integer>> programIndvSeqMap = populateProgramIndvForApplication(appsPgmList);
				programIndvSeqMap.forEach((key, value) -> {
					ProgramListResponse programResponse = new ProgramListResponse();
					programResponse.setProgramCode(key);
					programResponse.setProgramIndividualsSequenceNumber(value);
					programList.add(programResponse);
				});
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR,
					"Error in HouseholdApplicationBO.getProgramResponseListForApplication: " + e.getMessage());
			throw createFwException(this.getClass().getName(), "getProgramResponseListForApplication", e);
		}

		return programList;
	}

	private Map<String, List<Integer>> populateProgramIndvForApplication(CP_APP_PGM_INDV_Cargo[] appPgmIndvList) {
		Map<String, List<Integer>> programIndvSeqMap = new HashMap<>();
		for (int currentIndex = 0; currentIndex < appPgmIndvList.length; currentIndex++) {// TODO ADD DISASTER COLUMN IN DB
			CP_APP_PGM_INDV_Cargo appIndv = appPgmIndvList[currentIndex];
			if (Objects.isNull(appIndv.getIndv_seq_num()) || appIndv.getIndv_seq_num().intValue() == 0) {
				continue;
			}
			int seqNum = appIndv.getIndv_seq_num().intValue();
			if (Objects.nonNull(appIndv.getFs_rqst_ind()) && ONEINDICATOR.equalsIgnoreCase(appIndv.getFs_rqst_ind())) {
				programIndvSeqMap.computeIfAbsent(FSPROGRAMCODE, k -> new ArrayList<>()).add(seqNum);
			}
			if (Objects.nonNull(appIndv.getTanf_rqst_ind())
					&& ONEINDICATOR.equalsIgnoreCase(appIndv.getTanf_rqst_ind())) {
				programIndvSeqMap.computeIfAbsent(CWPROGRAMCODE, k -> new ArrayList<>()).add(seqNum);
			}
			if (Objects.nonNull(appIndv.getFma_rqst_ind())
					&& ONEINDICATOR.equalsIgnoreCase(appIndv.getFma_rqst_ind())) {
				programIndvSeqMap.computeIfAbsent(MCPROGRAMCODE, k -> new ArrayList<>()).add(seqNum);
			}

		}

		return programIndvSeqMap;
	}

	private Optional<APP_RQST_Cargo> getUnprocessedApplicationRelatedtoCase(String sspAppNum,
			List<APP_RQST_Cargo> appRequestList) {
		
		is_app_num_link_loggedin = true;
		if (Objects.nonNull(sspAppNum) && !sspAppNum.trim().isEmpty() && !"null".equalsIgnoreCase(sspAppNum) ) {
			
			Optional<APP_RQST_Cargo> app_rqst_cargo = appRequestList.stream().filter(appRqst -> sspAppNum.equalsIgnoreCase(appRqst.getApp_num()))
					.findFirst();
			
			if(app_rqst_cargo.isPresent())
			{
				return app_rqst_cargo;
			}else
			{
				APP_RQST_Collection app_rqst_collection = cpAppRequestRepository.getByAppNum(Integer.parseInt(sspAppNum));
				if(!app_rqst_collection.isEmpty())
				{
					APP_RQST_Cargo ssp_app_rqst_cargo = app_rqst_collection.getCargo(0);
					if("IP".equalsIgnoreCase(ssp_app_rqst_cargo.getApp_stat_cd()) || "DL".equalsIgnoreCase(ssp_app_rqst_cargo.getApp_stat_cd()))
					{
						return Optional.ofNullable(null);
					}else
					{
						is_app_num_link_loggedin = false;
						return Optional.ofNullable(null);
					}
				}
			}
		}
		
		return Optional.ofNullable(null);
	}

	private <T extends OngoingApplicationsResponse> void populateOngoingResponseFromReqCargo(
			APP_RQST_Cargo currentCpAppReqCargo, T responseObject) {
		String appNum = currentCpAppReqCargo.getApp_num();
		responseObject.setApplicationNumber(appNum); 
		responseObject.setLastUpdatedDate(getPSTDateFromDate(currentCpAppReqCargo.getUpdt_dt()));
		responseObject.setSubmittedDate(getPSTDateFromDate(currentCpAppReqCargo.getAppSbmtTms()));
		responseObject.setProgramResponseList(getProgramResponseListForApplication(appNum));
		responseObject.setApplicationStatus(currentCpAppReqCargo.getApp_stat_cd());
		responseObject.setApplicationIndividuals(getIndividualListForApplication(appNum));
		responseObject.setCountyCode(getCountyCountyCode(appNum));
		responseObject.setFormType(currentCpAppReqCargo.getFormRptType());
	}
	
	public List<Integer> getAllApplicationForUserFromDashboardService(String gUID) {

		FwLogger.log(this.getClass(), Level.INFO,
				"HouseholdApplicationService.getAllApplicationForUserFromDashboardService: called");
		try {
			List<Integer> appNumber;
			appNumber = appUserRepo.getByGUID(gUID);
			return appNumber;

		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, "getAllApplicationForUserFromDashboardService", e);
			throw e;
		}
	
	}

}
