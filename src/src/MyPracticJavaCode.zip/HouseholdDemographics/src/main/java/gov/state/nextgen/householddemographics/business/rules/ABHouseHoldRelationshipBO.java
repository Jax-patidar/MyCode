package gov.state.nextgen.householddemographics.business.rules;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.util.IndividualAge;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PREG_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;
import gov.state.nextgen.householddemographics.data.db2.NewBornChildInformationRepo;
import gov.state.nextgen.householddemographics.data.db2.PregnancyInformationRepo;


@Service("ABHouseHoldRelationshipBO")
public class ABHouseHoldRelationshipBO extends AbstractBO {

	private static final Logger logger = LoggerFactory.getLogger(ABHouseHoldRelationshipBO.class);
	
	@Autowired
	private HouseholdRelationshipRepo householdRelationshipRepo;

	@Autowired
	protected PregnancyInformationRepo pregnancyInformationRepo;

	@Autowired
	protected NewBornChildInformationRepo newBornChildInformationRepo;


	public void storeHousholdRelationshipDetails(CP_APP_HSHL_RLT_Collection appHshlRltColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldRelationshipBO.storeHousholdRelationshipDetails() - START");

		try {

			if (appHshlRltColl != null && !appHshlRltColl.isEmpty()) {
				CP_APP_HSHL_RLT_Cargo appRelationCargo = appHshlRltColl.getCargo(0);
				householdRelationshipRepo.save(appRelationCargo);
			}
			
		} catch (final Exception fe) {
			throw fe;
		} 

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldRelationshipBO.storeHousholdRelationshipDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
	}

	public APP_IN_PRFL_Cargo createAppIndividualProfile(APP_IN_PRFL_Cargo appInPrflCargo) {
	try {	
	appInPrflCargo.setAcdt_resp(HouseHoldDemoGraphicsConstants.Y);
	appInPrflCargo.setAdpt_asst_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setAlmy_rcv_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_anty_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_chl_sprt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_chrt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_dabl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_divnd_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_est_trst_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_rr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_uempl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_vet_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setChld_sprt_pay_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDabl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDpnd_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDrug_feln_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setEmpl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setFset_sctn_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setFstr_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setGen_rlf_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIncm_dcon_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIncm_int_resp(HouseHoldDemoGraphicsConstants.N);
	
	if(null == appInPrflCargo.getIndv_fma_rqst_ind()) {
		appInPrflCargo.setIndv_fma_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	}
	
	if(null == appInPrflCargo.getIndv_fs_rqst_ind()) {
		appInPrflCargo.setIndv_fs_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	}
	
	appInPrflCargo.setIndv_fpw_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	appInPrflCargo.setJob_iknd_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setKinship_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLoss_empl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMed_exp_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMed_ins_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedcr_ettl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMil_allot_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMony_othr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setNatl_rfge_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setNeed_ind_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOn_strk_sw(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOp_aoda_tmt_rcv_sw(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_incm_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_src_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPay_rmr_brd_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPnsn_retr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPreg_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setProp_sold_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRcv_fs_oth_st_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRcv_ss_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRcv_ssi_ever_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRcv_ssi_ltr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRcv_ssi_sw(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRmr_brd_inc_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSchl_enrl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSelf_empl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSep_fs_rqst_sw(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setShlt_cst_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSsi_1619b_rcv_sw(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_ases_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_coal_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_elec_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_fuel_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_gas_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_home_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_istl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_lpgas_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_mbl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_mtge_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_othr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_phn_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_rent_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_swr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_tax_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_trsh_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_wood_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_wtr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSu_cst_wwt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTrb_tanf_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTurn_down_job_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUtil_exp_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setWork_comp_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTrb_cpta_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBury_aset_c_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBury_aset_ibt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBury_aset_ins_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBury_aset_mas_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBury_aset_oth_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBury_aset_plt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBury_aset_rbt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBury_aset_v_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setEduc_aid_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIndv_ebd_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	appInPrflCargo.setIndv_hc_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	appInPrflCargo.setLi_aset_g_l_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLi_aset_g_t_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLi_aset_trm_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLi_aset_unv_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLi_aset_w_l_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_c_a_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_cash_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_eb_a_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_h_s_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_ira_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_k_p_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_m_o_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_mm_a_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_o_t_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_othr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_s_a_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_s_c_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_st_b_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_tr_f_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_tx_s_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_us_b_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_aset_xmas_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_aset_bur_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_aset_l_i_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_aset_p_p_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_aset_r_p_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_aset_veh_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_aset_xfr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_apt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_con_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_dup_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_frm_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_hse_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_lnd_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_m_h_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_oth_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_arpl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_auto_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_boat_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_camp_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_mcyc_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_mped_rsp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_nm_b_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_othr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_rv_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_s_mb_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_trk_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_trlr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_van_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_fmeq_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setEmer_ma_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTb_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setChld_trb_mbr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTrb_mbr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setYeohc_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRefusal_to_work_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPresc_drug_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setResettlement_incm_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLand_contract_mortgage_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setNursing_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDiabets_edu_prg_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPrsnl_care_provided_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setChild_care_provider_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setAttdt_hsekpr_srvc_animal_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPostage_mail_presc_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHlth_hosp_insurance_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_incm_unemp_bnfts_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_incm_trbl_ga_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_incm_rentl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMed_equip_supplies_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOther_housing_bill_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setAssociation_fee_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOut_patient_treatment_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMed_dent_vision_services_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUnocc_home_paymt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCool_exp_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTrbl_ser_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSer_rqst_ind(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSer_eb_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSer_ed_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSer_hd_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSer_he_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSer_fr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setGarnishment_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBasic_allow_housing_mil_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCloth_maint_allow_mil_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOther_deduction_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDeduction_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIndv_cc_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	appInPrflCargo.setBnft_bl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCash_gifts_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setChild_support_income_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCurrent_new_job_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_va_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setEmergency_medical_service_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setFood_clothing_util_rent_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHead_of_household_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHlth_insurance_cur_cvrg_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHlth_insurance_past_cvrg_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHousing_bill_home_ins_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHousing_bill_others_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIncome_change_resp(HouseHoldDemoGraphicsConstants.N);
	
	if(null == appInPrflCargo.getIndv_tanf_rqst_ind()) {
		appInPrflCargo.setIndv_tanf_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	}
	
	appInPrflCargo.setInheritance_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setInsurance_settlement_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLegal_child_support_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_aset_bank_acc_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_deed_trust_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_money_lgl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_pension_plan_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_promissory_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_retirement_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLoan_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedicare_part_a_b_d_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setParole_violation_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPast_job_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPending_social_assistance_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPrize_winning_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPublic_assistance_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setProp_tax_mobile_home_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_asset_home_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_asset_life_estate_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_estate_tax_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRent_exp_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setStudent_financial_aid_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTraining_allowance_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setWork_related_expense_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUtility_bills_kerosene_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_asset_irs_collge_plan_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLqd_asset_irs_retirement_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVehicle_asset_animal_drwn_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVehicle_asset_tractor_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVehicle_asset_golf_cart_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVehicle_asset_nmot_camper_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_asset_unoccupy_home_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLifeinsurance_asset_other_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setShelter_expense_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setService_provider_co_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setService_provider_fu_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setService_provider_cr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setAuth_rep_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIndv_ca_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	appInPrflCargo.setIndv_cr_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	appInPrflCargo.setIndv_fu_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	appInPrflCargo.setBenefits_on_strike_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_social_security_bnft_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIncome_room_boarder_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_none_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_rental_incm_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_annuity_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setElg_rcv_energy_assist_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_none_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCnvct_of_tr_fs_drg_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_incm_dcss_sup_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLi_aset_none_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMig_farm_wrkr_job_end_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setComm_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCurr_rcv_tanf_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_vac_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOth_bill_unpaid_med_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_lottery_win_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_gen_assist_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_none_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHousing_bill_rent_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_dr_relief_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOth_bill_chld_sup_oblig_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCnvct_of_tr_fs_gun_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHshl_primary_care_taker_ind(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVeh_aset_unlic_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCur_rcv_energy_assist_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setAvoid_pros_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_tanf_pymt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPers_prop_oth_val(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_none_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_ira_dist_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_irs_col_plan_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_irs_retirmnt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_lest_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_edu_assist_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHospital_stay_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_worker_comp_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_death_bnft_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_energy_assist_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOth_bill_b_tax_ded_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHouse_assist_rcv_ind(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPers_prop_livestock(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOth_bill_incm_tax_ded_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHousing_bill_mortgage_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHouse_hc_src_type_cd(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_trust_fund_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMig_farm_wrkr_job_rate_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_incm_vets_bnft_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setFs_disqualify_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_net_rent_royalty_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPers_prop_cemetary_lot(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLost_ins_spl_care_need_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_int_div_pymt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHousing_bill_prop_tax_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMig_farm_wrkr_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_incm_ssi_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHousing_bill_none_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_adoption_pymt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLost_ins_new_born_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLi_aset_oth_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCnvct_of_false_info_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setGrp_care_grc_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_capital_gains_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_ira_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_alimony_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHouse_liheap_rcv_ind(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_incm_contrib_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setKatie_beckett_medicaid_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLost_ins_empl_stop_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSpecial_needs_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_stocks_bonds_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_pymt_bo_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRcv_hospice_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLost_ins_divorce_parent_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCnvct_of_buy_sell_fs_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_oth_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_rel_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOth_bill_med_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_foster_care_pymt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPers_prop_saf_depst_box(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPub_hsa_rcv_pay_own_bill_ind(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_lump_sum_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUtility_bill_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOth_bill_chld_adult_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLost_ins_dis_fmcov_5pct_inc(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHouse_rent_assist_type(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRcv_bnft_oth_st_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setChld_prot_srvs_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setFormer_fstr_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_agent_orng_pymt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_worker_study_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_refugee_cash_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLost_ins_fmcov_5pct_inc(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_anny_pymt_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_frm_alot_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_mil_alot_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBnft_ssi_ended_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPers_prop_bus_eqpt(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setReal_aset_rental_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_dabl_incm_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_adoption_assist_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLost_ins_chg_empl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTrbl_ser_elg_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_pension_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_unempl_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOthr_incm_ss_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPers_prop_none(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_rr_retire_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHousing_bill_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_checking_acc_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedtyp_other(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedtyp_attendant_care(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedtyp_rx_cost(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedtyp_insur_premium(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedtyp_doctor(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedtyp_hsa_contrib(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedtyp_trans_med(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setAble_to_conceive_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedtyp_med_equip(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUei_mon_fro_oth_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedtyp_dental(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedtyp_hosp_bills(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUnderweight_birth_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTrbl_hlth_serv_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLost_health_insurance_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setEr_med_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setNursing_home_care_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVictim_dv_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIndp_living_prg_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHealth_insurance_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIndv_wic_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	appInPrflCargo.setTanf_fund_misuse_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDisaster_repair_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPrevent_eviction_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOther_housing_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedicare_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTax_claim_dependant_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTribal_ind_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBtd_pre_tax_ins(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBtd_vis_care_ins(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBtd_dent_ins(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIncome_tax_deduction(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBtd_flex_acc(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBtd_def_comp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBtd_med_ins(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBefore_tax_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBtd_other(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTanf_disqualify_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setFile_tax_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTax_dependents_outside_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOth_ind_gambl_pmnts(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedicare_part_a(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedicare_part_b(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIndv_magi_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
	appInPrflCargo.setMedicare_part_c(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedicare_part_d(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCcsp_provider_payment(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setAnimals_to_assist_disabled(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setFuneral_death_expense(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBlind_work_expense(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setImpairment_work_expense(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBonds(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCash(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCheckin_account(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDividend(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHlth_reimbur_acct(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIndv_dvlp_acct(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSavings_account(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUniform_gifts(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIncome_from_resource(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIndian_gambling_payments(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setInheritance(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setInsuance_benefits(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLoan_received(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLoan_repayment_income(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setManaged_income(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMatch_grant(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMontgomery_gi_bill(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOut_of_state_public(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRefunds_from_dch(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setRestitutions_settlements(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSenior_companion(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSeverance_pay(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setStrike_benefits(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTrade_readjustment(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUniform_relocation(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setUnion_funds(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVendor_excluded(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVictim_restitution(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVolunteer_payment(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVolunteer_payment_titlei(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setWia_training_and_allowance(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIncluded_unearned_income(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTanf_max_au_allotment(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTanf_max_grg_allotment(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCharitable_donation(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setChild_nutrition_payments(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setBlack_lung_benefits(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setChild_support_court(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setChild_support_gap_payment(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCivil_service(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDeferred_compensation_plans(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDisability_insurance(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setExcluded_unearned_income(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setFema_payment_disaster(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setFema_payment_non_disaster(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHealth_savings_account(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIn_kind_support(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setFoster_grandparent_program(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDisaster_unemployment(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDividends(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCharitable_donation_federal(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setTrust_fund(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPatient_fund(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDisaster_assistance(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setNon_business_equipment(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHousehold_goods(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setOther_non_countable(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setIndv_peach_rqst_ind(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_ida_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setLiquid_asset_hra_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDeath_benefit_state_federal(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setSocial_security_survivor(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setVendor_payments(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setAvd_prsctn_fstf(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setCntrl_subs_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setHeat_cool_src(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setDisq_snap_resp(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setPlan_helthy_baby_res(HouseHoldDemoGraphicsConstants.N);
	appInPrflCargo.setMedical_service_resp(HouseHoldDemoGraphicsConstants.N);
	
	return appInPrflCargo;
	}catch(Exception e) {
		throw e;
	}
	}

	/**
	 *
	 * @param appInPrflSessionColl
	 * @param indvSrcCustColl
	 * @return
	 */
	public boolean runPregChk(APP_IN_PRFL_Collection appInPrflSessionColl, INDIVIDUAL_Custom_Collection indvSrcCustColl) {
		final long startTime = System.currentTimeMillis();
		logger.info("ABHouseHoldRelationshipBO.runPregChk() - START");
		boolean foundFlag = false;
		try {
			// now we are checking for the preg
			if (AppConstants.SEX_IND_FEMALE.equals(indvSrcCustColl.getResult(0).getSex_ind())) {
				// now we are checking app_in_prfl manager
				foundFlag = true;
			}
		} catch (final Exception exception) {
			throw exception;
		}
		logger.info("ABHouseHoldRelationshipBO.runPregChk() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + " milliseconds");
		return foundFlag;
	}

	/**
	 *
	 * @param indvSrcCustColl
	 * @param peopleHandler
	 * @param appNumber
	 * @return
	 */
	public APP_HSHL_RLT_Collection runCareTakerCheck(INDIVIDUAL_Custom_Collection indvSrcCustColl, String appNumber) {

		IndividualAge indvAge = null;
		APP_HSHL_RLT_Collection hshlRltColl = null;

		final long startTime = System.currentTimeMillis();
		logger.info("ABHouseHoldRelationshipBO.runCareTakerCheck() - START");

		try {
			INDIVIDUAL_Custom_Cargo indvCustCargo = indvSrcCustColl.getResult(0);
			indvAge = indvCustCargo.getIndv_age();

			if (indvAge.getYears() < 18) {
				List<CP_APP_HSHL_RLT_Cargo> cp_app_hshl_rlt_cargos = householdRelationshipRepo.findByAppNumAndRefIndvSeqNum(Integer.parseInt(appNumber),indvCustCargo.getIndv_seq_num());

				final int resSize = cp_app_hshl_rlt_cargos.size();
				if (resSize > 0) {
					APP_HSHL_RLT_Cargo hshlRltCargo = new APP_HSHL_RLT_Cargo();
					INDIVIDUAL_Custom_Cargo custCargo = null;
					IndividualAge indvCareAge = null;
					for (int i = 0; i < resSize; i++) {
						CP_APP_HSHL_RLT_Cargo cpAppHshlRltCargo = cp_app_hshl_rlt_cargos.get(i);

						
						hshlRltCargo = validateAppHsHlRltCargo(cpAppHshlRltCargo);
						hshlRltColl = valdiateHshHlRltColl(hshlRltColl, hshlRltCargo, cpAppHshlRltCargo);

						if ("FTR".equals(hshlRltCargo.getRlt_cd()) || "MTR".equals(hshlRltCargo.getRlt_cd())) {
							hshlRltColl = null;
							return hshlRltColl;
						}
					}
				}
			}
		} catch (final Exception exception) {
			throw exception;
		}
		logger.info("ABHouseHoldRelationshipBO.runCareTakerCheck() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + " milliseconds");
		return hshlRltColl;
	}

	private APP_HSHL_RLT_Collection valdiateHshHlRltColl(APP_HSHL_RLT_Collection hshlRltColl,
			APP_HSHL_RLT_Cargo hshlRltCargo, CP_APP_HSHL_RLT_Cargo cpAppHshlRltCargo) {
		if(Objects.nonNull(cpAppHshlRltCargo.getChange_dt())){hshlRltCargo.setChg_eff_dt(String.valueOf(cpAppHshlRltCargo.getChange_dt()));}
		hshlRltCargo.setSrc_app_ind(cpAppHshlRltCargo.getSrcAppIndiv());
		if (hshlRltColl == null) {
			hshlRltColl = new APP_HSHL_RLT_Collection();
		}
		hshlRltColl.addCargo(hshlRltCargo);
		return hshlRltColl;
	}

	private APP_HSHL_RLT_Cargo validateAppHsHlRltCargo(CP_APP_HSHL_RLT_Cargo cpAppHshlRltCargo) {
		APP_HSHL_RLT_Cargo hshlRltCargo;
		hshlRltCargo = new APP_HSHL_RLT_Cargo();
		hshlRltCargo.setApp_num(cpAppHshlRltCargo.getApp_num());
		hshlRltCargo.setRef_indv_seq_num(cpAppHshlRltCargo.getRefIndvSeqNum());
		hshlRltCargo.setSrc_indv_seq_num(cpAppHshlRltCargo.getSrcIndvSeqNum());
		hshlRltCargo.setCare_resp(cpAppHshlRltCargo.getCare_resp());
		hshlRltCargo.setRec_cplt_ind(String.valueOf(cpAppHshlRltCargo.getRec_cplt_ind()));
		hshlRltCargo.setRlt_cd(cpAppHshlRltCargo.getRltCd());
		return hshlRltCargo;
	}

	/**
	 * Load Household relationship details.
	 * @param appNumber
	 * @param indvSeqNumber
	 * @return
	 */
	public Map<Object,Object> loadHousholdRelationshipDetails(String appNumber, Integer indvSeqNumber) {

		Map<Object,Object> pageCollection = new HashMap<Object,Object>();
		long startTime = System.currentTimeMillis();

		logger.info("ABHouseHoldRelationshipBO.loadHousholdRelationshipDetails() - START");
		try {
			APP_HSHL_RLT_Collection appHshlRltColl = new APP_HSHL_RLT_Collection();

			List<APP_HSHL_RLT_Cargo> appHshlRltCargos = getAppHouseholdRelationCargos(householdRelationshipRepo.findByAppNumAndSrcIndvSeqNum(Integer.parseInt(appNumber),String.valueOf(indvSeqNumber)));

			if (!CollectionUtils.isEmpty(appHshlRltCargos)) {
				appHshlRltColl.setResults(appHshlRltCargos.toArray(new APP_HSHL_RLT_Cargo[appHshlRltCargos.size()]));
				pageCollection.put("APP_HSHL_RLT_Collection", appHshlRltColl);

				List<String> relationList = new ArrayList<String>();
				for(APP_HSHL_RLT_Cargo appHshlRltCargo:appHshlRltColl.getResults()) {
					relationList.add(appHshlRltCargo.getRlt_cd());
				}
				pageCollection.put("RelationList", relationList);
			}

			APP_IN_PREG_Collection appPregColl = new APP_IN_PREG_Collection();

			List<APP_IN_PREG_Cargo> appPregnancyCargos = getAppPregnancyCargos(pregnancyInformationRepo.findAllByAppNumAndIndvSeqNum(Integer.parseInt(appNumber),Double.valueOf(indvSeqNumber)));
			if (!CollectionUtils.isEmpty(appPregnancyCargos)) {
				appPregColl.setResults(appPregnancyCargos.toArray(new APP_IN_PREG_Cargo[appPregnancyCargos.size()]));
				pageCollection.put("APP_IN_PREG_Collection", appPregColl);
			}

			APP_IN_NEWB_Collection appNewBornColl = new APP_IN_NEWB_Collection();
			List<APP_IN_NEWB_Cargo> appNewBornCargoArray = newBornChildInformationRepo.findAllByAppNumAndIndvSeqNum(Integer.parseInt(appNumber),Double.valueOf(indvSeqNumber));

			if (!CollectionUtils.isEmpty(appNewBornCargoArray)) {
				appNewBornColl.setResults(appNewBornCargoArray.toArray(new APP_IN_NEWB_Cargo[appNewBornCargoArray.size()]));
				pageCollection.put("APP_IN_NEWB_Collection", appNewBornColl);
			}
			logger.info("ABHouseHoldRelationshipBO.loadHousholdRelationshipDetails() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + " milliseconds");
			return pageCollection;
		}  catch (final Exception exception) {
			throw exception;
		}
	}

	/**
	 * Get App Household cargos.
	 * @param householdRelationShip
	 * @return
	 */
	protected List<APP_HSHL_RLT_Cargo> getAppHouseholdRelationCargos(List<CP_APP_HSHL_RLT_Cargo> householdRelationShip) {
		List<APP_HSHL_RLT_Cargo> app_hshl_rlt_cargos = new ArrayList<>();
		householdRelationShip.forEach(cp_app_hshl_rlt_cargo -> {
			APP_HSHL_RLT_Cargo cargo = new APP_HSHL_RLT_Cargo();
			cargo.setApp_num(cp_app_hshl_rlt_cargo.getApp_num());
			if(Objects.nonNull(cp_app_hshl_rlt_cargo.getChange_dt())){
				cargo.setChg_dt(cp_app_hshl_rlt_cargo.getChange_dt().toString());
			}
			cargo.setRef_indv_seq_num(cp_app_hshl_rlt_cargo.getRefIndvSeqNum());
			cargo.setRlt_cd(cp_app_hshl_rlt_cargo.getRltCd());
			cargo.setSrc_indv_seq_num(cp_app_hshl_rlt_cargo.getSrcIndvSeqNum());
			app_hshl_rlt_cargos.add(cargo);

		});

		return app_hshl_rlt_cargos;
	}

	/**
	 *
	 * @param cpAppInPregCargos
	 * @return
	 */
	protected List<APP_IN_PREG_Cargo> getAppPregnancyCargos(List<CP_APP_IN_PREG_Cargo> cpAppInPregCargos) {
		List<APP_IN_PREG_Cargo> appInPregCargos = new ArrayList<>();
		for(CP_APP_IN_PREG_Cargo cpAppInPregCargo:cpAppInPregCargos){
			APP_IN_PREG_Cargo appInPregCargo = getAppInPregCargo(cpAppInPregCargo);
			appInPregCargos.add(appInPregCargo);
		}
		return appInPregCargos;
	}

	protected APP_IN_PREG_Cargo getAppInPregCargo(CP_APP_IN_PREG_Cargo cpAppInPregCargo) {
		APP_IN_PREG_Cargo appInPregCargo = new APP_IN_PREG_Cargo();
		appInPregCargo.setApp_num(cpAppInPregCargo.getApp_num());
		if(Objects.nonNull(cpAppInPregCargo.getBaby_ct())) { appInPregCargo.setBaby_ct(cpAppInPregCargo.getBaby_ct().toString()); }
		appInPregCargo.setBaby_reside_hshld_ind(cpAppInPregCargo.getBaby_reside_hshld_ind());
		appInPregCargo.setBf_infant(cpAppInPregCargo.getBf_infant());
		if(Objects.nonNull(cpAppInPregCargo.getBaby_ct())){appInPregCargo.setBaby_ct(cpAppInPregCargo.getBaby_ct().toString());}
		if(Objects.nonNull(cpAppInPregCargo.getChg_eff_dt())){appInPregCargo.setChg_eff_dt(cpAppInPregCargo.getChg_eff_dt().toString());}
		if(Objects.nonNull(cpAppInPregCargo.getConception_dt())){appInPregCargo.setConception_dt(cpAppInPregCargo.getConception_dt().toString());}
		appInPregCargo.setCur_in_post_partum(cpAppInPregCargo.getCur_in_post_partum());
		appInPregCargo.setCur_preg(cpAppInPregCargo.getCur_preg());
		appInPregCargo.setEcp_id(cpAppInPregCargo.getEcp_id());
		if(Objects.nonNull(cpAppInPregCargo.getPp_babies_ct())){appInPregCargo.setPp_babies_ct(cpAppInPregCargo.getPp_babies_ct().toString());}
		if(Objects.nonNull(cpAppInPregCargo.getPreg_due_dt())){appInPregCargo.setPreg_due_dt(cpAppInPregCargo.getPreg_due_dt().toString());}
		appInPregCargo.setSrc_app_ind(cpAppInPregCargo.getSrc_app_ind());
		if(Objects.nonNull(cpAppInPregCargo.getFetus_ct())){appInPregCargo.setFetus_ct(cpAppInPregCargo.getFetus_ct().toString());}
		return appInPregCargo;
	}

	/**
	 *
	 * @param results
	 * @return
	 */
	protected List<CP_APP_IN_PREG_Cargo> getCpAppPregCargos(APP_IN_PREG_Cargo[] results) {
		List<CP_APP_IN_PREG_Cargo> cpAppInPregCargos = new ArrayList<>();
		for(APP_IN_PREG_Cargo appInPregCargo:results){
			CP_APP_IN_PREG_Cargo cpAppInPregCargo = getCpAppInPregCargo(appInPregCargo);
			cpAppInPregCargos.add(cpAppInPregCargo);
		}
		return cpAppInPregCargos;
	}

	protected CP_APP_IN_PREG_Cargo getCpAppInPregCargo(APP_IN_PREG_Cargo appInPregCargo) {
		CP_APP_IN_PREG_Cargo cpAppInPregCargo = new CP_APP_IN_PREG_Cargo();

		cpAppInPregCargo.setApp_num(appInPregCargo.getApp_num());

		if(Objects.nonNull(appInPregCargo.getBaby_ct())) {
			cpAppInPregCargo.setBaby_ct(Integer.parseInt(appInPregCargo.getBaby_ct()));
		}
		cpAppInPregCargo.setEcp_id(appInPregCargo.getEcp_id());
		if(null != appInPregCargo.getChg_eff_dt()) {
			cpAppInPregCargo.setChg_eff_dt(Timestamp.valueOf(appInPregCargo.getChg_eff_dt()));
		}else {
			cpAppInPregCargo.setChg_eff_dt(Timestamp.valueOf(AppConstants.HIGH_TIMESTAMP));
		}

		if(Objects.nonNull(appInPregCargo.getFetus_ct())) {
			cpAppInPregCargo.setFetus_ct(Integer.parseInt(appInPregCargo.getFetus_ct()));
		}

		if(Objects.nonNull(appInPregCargo.getPreg_due_dt()) && appInPregCargo.getPreg_due_dt().isEmpty()) {
			cpAppInPregCargo.setPreg_due_dt(Timestamp.valueOf(appInPregCargo.getPreg_due_dt()));
		}
		if(Objects.nonNull(appInPregCargo.getRec_cplt_ind())) {
			cpAppInPregCargo.setRec_cplt_ind(Integer.parseInt(appInPregCargo.getRec_cplt_ind()));
		}
		cpAppInPregCargo.setBaby_reside_hshld_ind(appInPregCargo.getBaby_reside_hshld_ind());
		cpAppInPregCargo.setCur_preg(appInPregCargo.getCur_preg());
		cpAppInPregCargo.setCur_in_post_partum(appInPregCargo.getCur_in_post_partum());
		if(Objects.nonNull(appInPregCargo.getPreg_term_dt()) && appInPregCargo.getPreg_term_dt().isEmpty()) {
			cpAppInPregCargo.setPreg_term_dt(Timestamp.valueOf(appInPregCargo.getPreg_term_dt()));
		}
		if(Objects.nonNull(appInPregCargo.getPp_babies_ct())) {
			cpAppInPregCargo.setPp_babies_ct(Integer.parseInt(appInPregCargo.getPp_babies_ct()));
		}
		cpAppInPregCargo.setBf_infant(appInPregCargo.getBf_infant());
		if(Objects.nonNull(appInPregCargo.getPreg_dlvry_dt()) && appInPregCargo.getPreg_dlvry_dt().isEmpty()) {
			cpAppInPregCargo.setPreg_dlvry_dt(Timestamp.valueOf(appInPregCargo.getPreg_dlvry_dt()));
		}
		if(Objects.nonNull(appInPregCargo.getConception_dt())) {
			cpAppInPregCargo.setConception_dt(null);
		}
		cpAppInPregCargo.setIndv_seq_num(Integer.parseInt(appInPregCargo.getIndv_seq_num()));
		cpAppInPregCargo.setSrc_app_ind(appInPregCargo.getSrc_app_ind());
		return cpAppInPregCargo;
	}

	public void storeHousholdRelationshipDetails(APP_HSHL_RLT_Collection appHshlRltColl, APP_IN_PREG_Collection appPregColl, APP_IN_NEWB_Collection appNewBornColl, String persistAction) {

		/**
		 * Updates Relationship collections, Pregnancy collections and NewBorn Child collections.
		 */
	 try {	
		if(StringUtils.isNotBlank(persistAction)) {
			if(persistAction.equals(FwConstants.ROWACTION_INSERT) || persistAction.equals(FwConstants.ROWACTION_UPDATE)) {
				if(Objects.nonNull(appHshlRltColl) && !ArrayUtils.isEmpty(appHshlRltColl.getResults())) {
					householdRelationshipRepo.saveAll(getCpAppIndvCargos(appHshlRltColl.getResults()));
				}
				if(Objects.nonNull(appPregColl) && !ArrayUtils.isEmpty(appPregColl.getResults())) {
					pregnancyInformationRepo.saveAll(getCpAppPregCargos(appPregColl.getResults()));
				}
				if(Objects.nonNull(appNewBornColl) && !ArrayUtils.isEmpty(appNewBornColl.getResults())) {
					newBornChildInformationRepo.saveAll(Arrays.asList(appNewBornColl.getResults()));
				}
			}else if(persistAction.equals(FwConstants.ROWACTION_DELETE)) {
				if(Objects.nonNull(appHshlRltColl) && !ArrayUtils.isEmpty(appHshlRltColl.getResults())) {
					for(APP_HSHL_RLT_Cargo appHshlRltCargo:appHshlRltColl.getResults()) {
						householdRelationshipRepo.delete(getCpAppHshlRltCargo(appHshlRltCargo));
					}
				}
				if(Objects.nonNull(appPregColl) && !ArrayUtils.isEmpty(appPregColl.getResults())) {
					for(APP_IN_PREG_Cargo appInPregCargo:appPregColl.getResults()){
						pregnancyInformationRepo.delete(getCpAppInPregCargo(appInPregCargo));
					}
				}
				if(Objects.nonNull(appNewBornColl) && !ArrayUtils.isEmpty(appNewBornColl.getResults())) {
					for(APP_IN_NEWB_Cargo appInNewbCargo:appNewBornColl.getResults()){
						newBornChildInformationRepo.delete(appInNewbCargo);
					}
				}
			}
		}
	 }catch(Exception e) {
		 throw e;
	 }
	}

	/**
	 *
	 * @param results
	 * @return
	 */
	protected  List<CP_APP_HSHL_RLT_Cargo> getCpAppIndvCargos(APP_HSHL_RLT_Cargo[] results) {
		List<CP_APP_HSHL_RLT_Cargo> cp_app_indv_cargos = new ArrayList<CP_APP_HSHL_RLT_Cargo>();
		for(APP_HSHL_RLT_Cargo app_hshl_rlt_cargo : results){
			CP_APP_HSHL_RLT_Cargo cpAppHshlRltCargo = getCpAppHshlRltCargo(app_hshl_rlt_cargo);
			cp_app_indv_cargos.add(cpAppHshlRltCargo);
		}
		return cp_app_indv_cargos;
	}

	protected CP_APP_HSHL_RLT_Cargo getCpAppHshlRltCargo(APP_HSHL_RLT_Cargo app_hshl_rlt_cargo) {
		CP_APP_HSHL_RLT_Cargo cpAppHshlRltCargo = new CP_APP_HSHL_RLT_Cargo();
		cpAppHshlRltCargo.setApp_num(app_hshl_rlt_cargo.getApp_num());
		cpAppHshlRltCargo.setCare_resp(app_hshl_rlt_cargo.getCare_resp());
		if(Objects.nonNull(app_hshl_rlt_cargo.getChg_eff_dt())) { cpAppHshlRltCargo.setChange_dt(null); }
		cpAppHshlRltCargo.setRec_cplt_ind(Integer.parseInt(app_hshl_rlt_cargo.getRec_cplt_ind()));
		cpAppHshlRltCargo.setSrcIndvSeqNum(app_hshl_rlt_cargo.getSrc_indv_seq_num());
		cpAppHshlRltCargo.setRefIndvSeqNum(app_hshl_rlt_cargo.getRef_indv_seq_num());
		cpAppHshlRltCargo.setSrcAppIndiv(app_hshl_rlt_cargo.getSrc_app_ind());
		cpAppHshlRltCargo.setRltCd(app_hshl_rlt_cargo.getRlt_cd());
		return cpAppHshlRltCargo;
	}

	/**
	 * checkExitingRelations
	 * @param appNumber
	 * @return
	 */
	public APP_HSHL_RLT_Collection checkExistingRelations(String appNumber) {
		APP_HSHL_RLT_Collection appHouseholdRelationCollection = new APP_HSHL_RLT_Collection();
		List<APP_HSHL_RLT_Cargo> appHouseHoldRelationCargos = getAppHouseholdRelationCargos(householdRelationshipRepo.findByAppNumAndRltCdIn(Integer.parseInt(appNumber),Arrays.asList(new String[]{"HUS","WIF","FTR","MTR"})));
		if (!CollectionUtils.isEmpty(appHouseHoldRelationCargos)) {
			appHouseholdRelationCollection.setResults(appHouseHoldRelationCargos.toArray(new APP_HSHL_RLT_Cargo[appHouseHoldRelationCargos.size()]));
		}
		return appHouseholdRelationCollection;
	}

	/**
	 *
	 * @param programKey
	 */
	public void setProgramKey(final short[] programKey) {
	 try {	
		short[] programKeyArray = new short[3];
		programKeyArray = programKey;
	 }catch(Exception e) {
		 throw e;
	 }
	}

	public APP_HSHL_RLT_Cargo[] findRelationsByIndvSeqNum(APP_HSHL_RLT_Collection appHSHLRLTCollection) {
		return null;
	}

	public APP_IN_PREG_Cargo[] findByKey(APP_IN_PREG_Collection coll, String srcAppInd) {
		return null;
	}

	
	 

	

	public void saveRelationshipandBuyPrepareNewDetails(CP_APP_HSHL_RLT_Collection COLL) {
		try {
			CP_APP_HSHL_RLT_Cargo cargo = null;
			if (COLL != null && !COLL.isEmpty()) {
				cargo = COLL.getCargo(0);
				householdRelationshipRepo.save(cargo);
			}
		}catch (final FwException fe) {
            final FwWrappedException fwWrappedException = new FwWrappedException(fe);
            fwWrappedException.setCallingClassID(getClass().getName());
            fwWrappedException.setCallingMethodID("saveRelationshipandBuyPrepareNewDetails");
            fwWrappedException.setFwException(fe);
            throw fwWrappedException;
        } catch (final Exception exception) {
            throw exception;
        }
		
		
		
	}

	public CP_APP_HSHL_RLT_Collection loadRelationshipDetails(String app_num) {
		return householdRelationshipRepo.loadCpAppHshlRltDetails(Integer.parseInt(app_num));
			
	}

}
