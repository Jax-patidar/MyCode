package gov.state.nextgen.householddemographics.business.rules;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppInOutStBnftRepository;

@Service("OutOfStateBenefitsBO")
public class OutOfStateBenefitsBO extends AbstractBO {

	@Autowired
	private CpAppInOutStBnftRepository outOfStateRepo;
	
	/**
	 * store out of state details
	 * 
	 * @param newColl
	 */
	public void storeStateBenefits(APP_IN_OUT_ST_BNFT_Cargo cargo) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OutOfStateBenefitsBO.storeStateBenefits() - START");
        try {
        	outOfStateRepo.save(cargo);
        	
        }catch (final Exception e) {
        	FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OutOfStateBenefitsBO.storeStateBenefits() - END , Time Taken : "
                + (System.currentTimeMillis() - startTime)
                + " milliseconds");
		
	}
	
	public APP_IN_OUT_ST_BNFT_Collection loadOutOfStateDetailsCurrent(String appNum, Integer indv_seq_num, Integer seq_num) {
		return outOfStateRepo.getCurrentIndv(Integer.parseInt(appNum), indv_seq_num,seq_num);
	}
	
	public APP_IN_OUT_ST_BNFT_Collection loadIndividualOutOfStateDetails(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OutOfStateBenefitsBO.loadIndividualOutOfStateDetails() - START");
		try {
			APP_IN_OUT_ST_BNFT_Collection appInColl = new APP_IN_OUT_ST_BNFT_Collection();
			if(appNum != null) {
				appInColl = outOfStateRepo.getByAppNum(Integer.parseInt(appNum), indvIds);
			}
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OutOfStateBenefitsBO.loadIndividualOutOfStateDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    + " milliseconds");
            return appInColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(getClass().getName(),
                    "loadIndividualOutOfStateDetails", e);
        }
	}
	
	public void deleteGovernmentAid(String appNum, Integer indivSeqNumInt, Integer seqNumInt) {
		outOfStateRepo.deleteGovernmentAid(Integer.parseInt(appNum), indivSeqNumInt, seqNumInt);
	}
}
