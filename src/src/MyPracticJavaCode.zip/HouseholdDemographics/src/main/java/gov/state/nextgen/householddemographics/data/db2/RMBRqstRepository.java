package gov.state.nextgen.householddemographics.data.db2;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;

@Repository
public interface RMBRqstRepository extends CrudRepository<RMB_RQST_Cargo,Long>{
	
	@Query("select c from RMB_RQST_Cargo c where c.case_num in ?1 and ( c.app_start_dt is null or c.app_start_dt <= ?2) and ( c.app_end_dt is null or c.app_end_dt >= ?2)")
	public RMB_RQST_Cargo[] findByCaseNumIn(List<String> caseList, LocalDateTime LocalDateTime);
	
	@Query("select c from RMB_RQST_Cargo c where c.case_num = ?1 and c.county_cd = ?2 and ( c.app_start_dt is null or c.app_start_dt <= ?3) and ( c.app_end_dt is null or c.app_end_dt >= ?3)")
	public RMB_RQST_Cargo[] findByCaseNumCountyCdAndCurrentDate(String caseNum, String countyCd, LocalDateTime LocalDateTime);
	
	@Query("select c from RMB_RQST_Cargo c where c.cp_rmb_request_id = ?1")
	RMB_RQST_Collection findByCpRmbRequestId(Long cp_rmb_request_id);
	
	@Transactional
	@Modifying
	@Query("update RMB_RQST_Cargo c set c.ssp_app_num = ?1, update_dt = ?3 where c.cp_rmb_request_id = ?2")
	public void updateSspAppNum(Integer app_num, Long cp_rmb_request_id, Timestamp update_dt);
	
    @Query("select c from RMB_RQST_Cargo c where c.ssp_app_num = ?1")
    RMB_RQST_Collection findByAppNum(Integer appNum);
	
}
