package gov.state.nextgen.householddemographics.model;

import java.io.IOException;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.AbstractCollection;
import gov.state.nextgen.access.business.entities.ICargo;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;

/**
 * Driver Page Response Model class.
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 */
@SuppressWarnings("squid:S1452")
public class DriverPageResponse extends PageResponse implements Serializable{
	private static final long serialVersionUID = 1669762600294501560L;
	private String appNum;
	private Map<String, List<? extends BaseDomainObject>> pageMap = new HashMap<>();
	private transient Map<String, List<? >> pageCollection = new HashMap<>();

	
	public String getAppNum() {
		return appNum;
	}
	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}
	public Map<String, List<? extends BaseDomainObject>> getPageMap() {
		return pageMap;
	}
	public void setPageMap(Map<String, List<? extends BaseDomainObject>> pageMap) {
		this.pageMap = pageMap;
	}
	public Map<String, List<? >> getPageCollection() {
		return pageCollection;
	}
	
	
	/*This method is used to get the cargo list based on collection for service chaining*/
	public Object getCollectionData(Map<String, Object> map, String collectionName) throws InstantiationException, IllegalAccessException, ClassNotFoundException, JsonProcessingException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		AbstractCollection collectionObj= null;
		for (String key : map.keySet()) {
		    if(key.equalsIgnoreCase(collectionName)) {
		    	Iterable itrerable = (Iterable) map.get(key);
				Iterator itr = itrerable.iterator();
				collectionObj= (AbstractCollection) Class.forName("gov.state.nextgen.householddemographics.business.entities."+collectionName).getDeclaredConstructor().newInstance();
				while (itr.hasNext()) {
					Map cargoMap = (Map) itr.next();
			  
				ObjectMapper Obj =  new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				Obj.registerModule(new JavaTimeModule());
				String jsonStr = Obj.writeValueAsString(cargoMap);
				ICargo cargo = (ICargo) Obj.readValue(jsonStr, Class.forName("gov.state.nextgen.householddemographics.business.entities."+collectionName.replaceAll("_Collection", "_Cargo")));
				collectionObj.add(cargo);
		    }	
		    }
			
		}
		return collectionObj;
		
		
	}

	
	public void setPageCollection(Map<String, List<? >> pageCollection) {
		this.pageCollection = pageCollection;
	}
	
	
}
