package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.ChangeRenewalApplicationsRespone;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.OngoingApplicationsResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABGAD")
@Scope("prototype")
public class ABGADViewWrapper implements LogicResponseInterface {

	private static final String PAGE_ID = "ABGAD";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), Level.INFO, "ABGADViewWrapper.constructPageResponse: called :");
		DriverPageResponse driverPageResponse = new DriverPageResponse();

		Map<Object, Object> pageCollection = fwTxn.getPageCollection();
		List<OngoingApplicationsResponse> ongoingApplicationResponsesList = (List<OngoingApplicationsResponse>) pageCollection
				.get(HouseHoldDemoGraphicsConstants.ONGOING_APPLICATION);
		List<ChangeRenewalApplicationsRespone> changeRenewableApplicationsList = (List<ChangeRenewalApplicationsRespone>) pageCollection
				.get(HouseHoldDemoGraphicsConstants.CHANGE_RENEWAL_APPLICATIONS);
		FwLogger.log(this.getClass(), Level.DEBUG,
				"ABGADViewWrapper.constructPageResponse: ongoingApplicationResponsesList response receiceved from pagecollection :"
						+ ongoingApplicationResponsesList);

		FwLogger.log(this.getClass(), Level.DEBUG,
				"ABGADViewWrapper.constructPageResponse: changeRenewableApplicationsList response receiceved from pagecollection :"
						+ changeRenewableApplicationsList);

		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.ONGOING_APPLICATION,
				ongoingApplicationResponsesList);
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CHANGE_RENEWAL_APPLICATIONS,
				changeRenewableApplicationsList);

		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

		return driverPageResponse;

	}

}
