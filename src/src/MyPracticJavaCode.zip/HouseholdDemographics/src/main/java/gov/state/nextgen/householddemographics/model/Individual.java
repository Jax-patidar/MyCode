package gov.state.nextgen.householddemographics.model;

import gov.state.nextgen.access.business.entities.AbstractCargo;

import java.io.Serializable;

public class Individual extends AbstractCargo implements Serializable {

    private static final long serialVersionUID = 355782720204794811L;

    private String firstName;
    private Integer age;
    // Male - M Female -F
    private String gender;
    // Seq. Number of the Individual
    private String indvSeqNumber;
    private String ageSuffix;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getIndvSeqNumber() {
        return indvSeqNumber;
    }

    public void setIndvSeqNumber(String indvSeqNumber) {
        this.indvSeqNumber = indvSeqNumber;
    }

    public String getAgeSuffix() {
        return ageSuffix;
    }

    public void setAgeSuffix(String ageSuffix) {
        this.ageSuffix = ageSuffix;
    }

}
