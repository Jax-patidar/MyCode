package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

public class Citizenship implements Serializable {

    private static final long serialVersionUID = -4112924804679488416L;
    public String citizeneSignature;
    public String citizenFirstname;
    public String citizenLastName;
    public String citizenMiddleName;
    public String citizenSuffixName;

    public String getCitizeneSignature() {
        return citizeneSignature;
    }

    public void setCitizeneSignature(String citizeneSignature) {
        this.citizeneSignature = citizeneSignature;
    }

    public String getCitizenFirstname() {
        return citizenFirstname;
    }

    public void setCitizenFirstname(String citizenFirstname) {
        this.citizenFirstname = citizenFirstname;
    }

    public String getCitizenLastName() {
        return citizenLastName;
    }

    public void setCitizenLastName(String citizenLastName) {
        this.citizenLastName = citizenLastName;
    }

    public String getCitizenMiddleName() {
        return citizenMiddleName;
    }

    public void setCitizenMiddleName(String citizenMiddleName) {
        this.citizenMiddleName = citizenMiddleName;
    }

    public String getCitizenSuffixName() {
        return citizenSuffixName;
    }

    public void setCitizenSuffixName(String citizenSuffixName) {
        this.citizenSuffixName = citizenSuffixName;
    }

}