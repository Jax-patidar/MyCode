/**
 * 
 */
package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

/**
 * View Wrapper for passing the response object.
 * Created by @DeloitteUSI team
 * @author khuskumari
 */

@Component("CFMAR")
@Scope("prototype")
public class CFMARMailingAddressReviewViewWrapper implements LogicResponseInterface{
	
	private static final String PAGE_ID = "CFMAR";
	
	private static final String CP_APP_RGST_COLL = "CP_APP_RGST_Collection";
		
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();

		Map pageCollection = fwTrxn.getPageCollection();
		List<CP_APP_RGST_Cargo> contactList = new ArrayList<CP_APP_RGST_Cargo>();
		CP_APP_RGST_Cargo contactCargo = new CP_APP_RGST_Cargo();
		
		
		CP_APP_RGST_Collection contactCollection = pageCollection.get(CP_APP_RGST_COLL) != null ? (CP_APP_RGST_Collection)pageCollection.get(CP_APP_RGST_COLL) : null;

		if(contactCollection != null) {
			contactCargo = (CP_APP_RGST_Cargo) contactCollection.get(0);
		}
		
		contactList.add(contactCargo);
		driverPageResponse.getPageCollection().put(CP_APP_RGST_COLL, contactList);
		
		driverPageResponse.setCurrentPageID(PAGE_ID);

		return driverPageResponse;
	}

}
