package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class CP_APP_PGM_INDV_Collection extends AbstractCollection  {

    /**
     *
     */
    private static final long serialVersionUID = -8653237098010167069L;

    
    /**
     * Set the cargo array object to the collection.
     */
    @Override
    public void setGenericResults(final Object obj) {
        if (obj instanceof CP_APP_RGST_Cargo[]) {
            final CP_APP_PGM_INDV_Cargo[] cbArray = (CP_APP_PGM_INDV_Cargo[]) obj;
            setResults(cbArray);
        }
    }

    /**
     * Sets cargo array into collection.
     */
    public void setResults(final CP_APP_PGM_INDV_Cargo[] cbArray) {
        clear();
        for (int i = 0; i < cbArray.length; i++) {
            add(cbArray[i]);
        }
    }

    @Override
    public String getPACKAGE() {
        return null;
    }

    /**
     * returns all the values in the Collection as Cargo Array.
     */
    public CP_APP_PGM_INDV_Cargo[] getResults() {
        final CP_APP_PGM_INDV_Cargo[] cbArray = new CP_APP_PGM_INDV_Cargo[size()];
        toArray(cbArray);
        return cbArray;
    }

    /**
     * returns a cargo from the Collection for the given index.
     */
    public CP_APP_PGM_INDV_Cargo getCargo(final int idx) {
        return (CP_APP_PGM_INDV_Cargo) get(idx);
    }
}
