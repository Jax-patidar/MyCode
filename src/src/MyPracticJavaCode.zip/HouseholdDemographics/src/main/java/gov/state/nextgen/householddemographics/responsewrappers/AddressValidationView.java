package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.business.entities.Address_Validate_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.Address_Validate_Custom_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABAVD")
@Scope("prototype")
public class AddressValidationView implements LogicResponseInterface{

	private static final String PAGE_ID = "ABAVD";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTxn.getPageCollection();
		
		Address_Validate_Custom_Cargo cargo = new Address_Validate_Custom_Cargo();
		List<Address_Validate_Custom_Cargo> addrValidtnCargoList = new ArrayList<Address_Validate_Custom_Cargo>();
		Address_Validate_Custom_Collection addrValidColl = (Address_Validate_Custom_Collection) pageCollection.get("Address_Validate_Custom_Collection");

		if(addrValidColl != null) {
			cargo = (Address_Validate_Custom_Cargo) addrValidColl.get(0);
		}
		addrValidtnCargoList.add(cargo);
		driverPageResponse.getPageCollection().put("Address_Validate_Custom_Collection", addrValidtnCargoList);
		

		driverPageResponse.setCurrentPageID(PAGE_ID);
		
		return driverPageResponse;
	}

}
