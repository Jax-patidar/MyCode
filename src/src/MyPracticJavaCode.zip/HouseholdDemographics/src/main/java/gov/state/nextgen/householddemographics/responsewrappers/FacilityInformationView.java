package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_SHLTC_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_SHLTC_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component(HouseHoldDemoGraphicsConstants.ABFIN)
@Scope("prototype")
public class FacilityInformationView implements LogicResponseInterface{

	private static final String PAGE_ID = "ABFIN";
	
	private static final String CP_APP_IN_SHLTC_COLL = "CP_APP_IN_SHLTC_Collection";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTxn.getPageCollection();
		List<CP_APP_IN_SHLTC_Cargo> facilityList = new ArrayList<CP_APP_IN_SHLTC_Cargo>();
		CP_APP_IN_SHLTC_Cargo cpAppInShltcCargo;
		CP_APP_IN_SHLTC_Collection cpAppInShltcCollection = pageCollection.get(CP_APP_IN_SHLTC_COLL) != null ? (CP_APP_IN_SHLTC_Collection) pageCollection.get(CP_APP_IN_SHLTC_COLL) : null;
	
		if(cpAppInShltcCollection != null && !cpAppInShltcCollection.isEmpty() && cpAppInShltcCollection.size() >0) {			
			for (int i = 0; i < cpAppInShltcCollection.size(); i++) {
				cpAppInShltcCargo = (CP_APP_IN_SHLTC_Cargo) cpAppInShltcCollection.get(i);
				facilityList.add(cpAppInShltcCargo);
			}
		}
		
		driverPageResponse.getPageCollection().put(CP_APP_IN_SHLTC_COLL, facilityList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		
		return driverPageResponse;
}
}
