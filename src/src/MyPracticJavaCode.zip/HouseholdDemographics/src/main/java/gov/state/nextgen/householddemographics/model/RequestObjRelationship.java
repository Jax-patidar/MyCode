package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
 * @author upriyadarshi
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestObjRelationship implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String indv1;

	private String indv2;

	private String relationCode;

	public String getIndv1() {
		return indv1;
	}

	public void setIndv1(String indv1) {
		this.indv1 = indv1;
	}

	public String getIndv2() {
		return indv2;
	}

	public void setIndv2(String indv2) {
		this.indv2 = indv2;
	}

	public String getRelationCode() {
		return relationCode;
	}

	public void setRelationCode(String relationCode) {
		this.relationCode = relationCode;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
