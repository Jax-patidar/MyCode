package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("MCDCS")
@Scope("prototype")
public class MCDCSViewWrapper implements LogicResponseInterface {
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		final String PAGE_ID = "MCDCS";
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTrxn.getPageCollection();
		APP_INDV_Collection appIndvCollection = (APP_INDV_Collection) pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
		if (!appIndvCollection.isEmpty()) {
			driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION,
					Arrays.asList(appIndvCollection.getResults()));
		} else {
			driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION,
					new ArrayList<>());
		}
		driverPageResponse.setCurrentPageID(PAGE_ID);
		return driverPageResponse;
	}

}
