package gov.state.nextgen.householddemographics.business.entities;

import com.fasterxml.jackson.annotation.JsonFormat;
import gov.state.nextgen.access.business.entities.AbstractCargo;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


public class CP_APP_IN_CARE_PROV_Cargo extends AbstractCargo implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    
    
    

    @Id
    private String app_num;
    @Id
    private Integer indv_seq_num;
    @Id
    private Integer seq_num;
    @Id
    private String src_app_ind;
    private String care_prov_org_nam;
    @JsonFormat(pattern = "MM/dd/yyyy")
    private Date end_dt;
    @JsonFormat(pattern = "MM/dd/yyyy")
    private Date chg_dt;
    private String care_type_cd;
    private Integer rec_cplt_ind;
    
    private String care_prov_org_nam_nursing;
    private String care_prov_org_nam_hospice;
    private String care_prov_org_nam_hosp_stay;
    private Integer ecp_id;
    private String nur_prvd_id;
    private String nur_loc_met;
    private String nur_admitted_from;
    @JsonFormat(pattern = "MM/dd/yyyy")
    private Date nur_adm_dt;
    @JsonFormat(pattern = "MM/dd/yyyy")
    private Date nur_hosp_adm_dt;
    private String nur_rcv_hspc_nurh;
    private String nur_hspc_prvd_nm;
    private String nur_end_rsn;
    private String nur_dchg_dest;
    private String nur_dchg_oth;
    private String need_care_other_hhm_desc;
    private String dabl_caring_desc;
    
    
    

    public String getDabl_caring_desc() {
		return dabl_caring_desc;
	}

	public void setDabl_caring_desc(String dabl_caring_desc) {
		this.dabl_caring_desc = dabl_caring_desc;
	}

	public String getNeed_care_other_hhm_desc() {
		return need_care_other_hhm_desc;
	}

	public void setNeed_care_other_hhm_desc(String need_care_other_hhm_desc) {
		this.need_care_other_hhm_desc = need_care_other_hhm_desc;
	}

	public String getCare_prov_org_nam() {
        return care_prov_org_nam;
    }

    public void setCare_prov_org_nam(String care_prov_org_nam) {
        this.care_prov_org_nam = care_prov_org_nam;
    }

    public Date getEnd_dt() {
    	if(end_dt != null) {
        return (Date) end_dt.clone();
        }else {
        	return null;
        }	
    }

    public void setEnd_dt(Date end_dt) {
    	if(end_dt != null)
         this.end_dt = (Date) end_dt.clone();
    	else
    		this.end_dt = null;
    }

    public Date getChg_dt() {
    	if(chg_dt != null)
    		return (Date) chg_dt.clone();
    	else
    		return null;
    }

    public void setChg_dt(Date chg_dt) {
    	if(chg_dt != null)
    		this.chg_dt = (Date) chg_dt.clone();
    	else
    		this.chg_dt = null;
    }

    public String getCare_type_cd() {
        return care_type_cd;
    }

    public void setCare_type_cd(String care_type_cd) {
        this.care_type_cd = care_type_cd;
    }

    public String getApp_num() {
        return app_num;
    }

    public void setApp_num(String app_num) {
        this.app_num = app_num;
    }

    public Integer getIndv_seq_num() {
        return indv_seq_num;
    }

    public void setIndv_seq_num(Integer indv_seq_num) {
        this.indv_seq_num = indv_seq_num;
    }

    public Integer getSeq_num() {
        return seq_num;
    }

    public void setSeq_num(Integer seq_num) {
        this.seq_num = seq_num;
    }

    public String getSrc_app_ind() {
        return src_app_ind;
    }

    public void setSrc_app_ind(String src_app_ind) {
        this.src_app_ind = src_app_ind;
    }

    public Integer getRec_cplt_ind() {
        return rec_cplt_ind;
    }

    public void setRec_cplt_ind(Integer rec_cplt_ind) {
        this.rec_cplt_ind = rec_cplt_ind;
    }
    
    

    /**
	 * @return the care_prov_org_nam_nursing
	 */
	public String getCare_prov_org_nam_nursing() {
		return care_prov_org_nam_nursing;
	}

	/**
	 * @param care_prov_org_nam_nursing the care_prov_org_nam_nursing to set
	 */
	public void setCare_prov_org_nam_nursing(String care_prov_org_nam_nursing) {
		this.care_prov_org_nam_nursing = care_prov_org_nam_nursing;
	}

	/**
	 * @return the care_prov_org_nam_hospice
	 */
	public String getCare_prov_org_nam_hospice() {
		return care_prov_org_nam_hospice;
	}

	/**
	 * @param care_prov_org_nam_hospice the care_prov_org_nam_hospice to set
	 */
	public void setCare_prov_org_nam_hospice(String care_prov_org_nam_hospice) {
		this.care_prov_org_nam_hospice = care_prov_org_nam_hospice;
	}

	/**
	 * @return the care_prov_org_nam_hosp_stay
	 */
	public String getCare_prov_org_nam_hosp_stay() {
		return care_prov_org_nam_hosp_stay;
	}

	/**
	 * @param care_prov_org_nam_hosp_stay the care_prov_org_nam_hosp_stay to set
	 */
	public void setCare_prov_org_nam_hosp_stay(String care_prov_org_nam_hosp_stay) {
		this.care_prov_org_nam_hosp_stay = care_prov_org_nam_hosp_stay;
	}

	/**
	 * @return the ecp_id
	 */
	public Integer getEcp_id() {
		return ecp_id;
	}

	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(Integer ecp_id) {
		this.ecp_id = ecp_id;
	}

	/**
	 * @return the nur_prvd_id
	 */
	public String getNur_prvd_id() {
		return nur_prvd_id;
	}

	/**
	 * @param nur_prvd_id the nur_prvd_id to set
	 */
	public void setNur_prvd_id(String nur_prvd_id) {
		this.nur_prvd_id = nur_prvd_id;
	}

	/**
	 * @return the nur_loc_met
	 */
	public String getNur_loc_met() {
		return nur_loc_met;
	}

	/**
	 * @param nur_loc_met the nur_loc_met to set
	 */
	public void setNur_loc_met(String nur_loc_met) {
		this.nur_loc_met = nur_loc_met;
	}

	/**
	 * @return the nur_admitted_from
	 */
	public String getNur_admitted_from() {
		return nur_admitted_from;
	}

	/**
	 * @param nur_admitted_from the nur_admitted_from to set
	 */
	public void setNur_admitted_from(String nur_admitted_from) {
		this.nur_admitted_from = nur_admitted_from;
	}

	/**
	 * @return the nur_adm_dt
	 */
	public Date getNur_adm_dt() {
		if(nur_adm_dt != null) {
			return (Date) nur_adm_dt.clone();
		}else {
			return null;
		}
	}

	/**
	 * @param nur_adm_dt the nur_adm_dt to set
	 */
	public void setNur_adm_dt(Date nur_adm_dt) {
		if(nur_adm_dt != null) {
			this.nur_adm_dt = (Date) nur_adm_dt.clone();
		}else {
			this.nur_adm_dt = null;
		}
	}

	/**
	 * @return the nur_hosp_adm_dt
	 */
	public Date getNur_hosp_adm_dt() {
		if(nur_hosp_adm_dt != null) {
			return (Date) nur_hosp_adm_dt.clone();
		}else {
			return null;
		}
	}

	/**
	 * @param nur_hosp_adm_dt the nur_hosp_adm_dt to set
	 */
	public void setNur_hosp_adm_dt(Date nur_hosp_adm_dt) {
		if(nur_hosp_adm_dt != null) {
			this.nur_hosp_adm_dt = (Date) nur_hosp_adm_dt.clone();
		}else {
			this.nur_hosp_adm_dt = null;
		}
	}

	/**
	 * @return the nur_rcv_hspc_nurh
	 */
	public String getNur_rcv_hspc_nurh() {
		return nur_rcv_hspc_nurh;
	}

	/**
	 * @param nur_rcv_hspc_nurh the nur_rcv_hspc_nurh to set
	 */
	public void setNur_rcv_hspc_nurh(String nur_rcv_hspc_nurh) {
		this.nur_rcv_hspc_nurh = nur_rcv_hspc_nurh;
	}

	/**
	 * @return the nur_hspc_prvd_nm
	 */
	public String getNur_hspc_prvd_nm() {
		return nur_hspc_prvd_nm;
	}

	/**
	 * @param nur_hspc_prvd_nm the nur_hspc_prvd_nm to set
	 */
	public void setNur_hspc_prvd_nm(String nur_hspc_prvd_nm) {
		this.nur_hspc_prvd_nm = nur_hspc_prvd_nm;
	}

	/**
	 * @return the nur_end_rsn
	 */
	public String getNur_end_rsn() {
		return nur_end_rsn;
	}

	/**
	 * @param nur_end_rsn the nur_end_rsn to set
	 */
	public void setNur_end_rsn(String nur_end_rsn) {
		this.nur_end_rsn = nur_end_rsn;
	}

	/**
	 * @return the nur_dchg_dest
	 */
	public String getNur_dchg_dest() {
		return nur_dchg_dest;
	}

	/**
	 * @param nur_dchg_dest the nur_dchg_dest to set
	 */
	public void setNur_dchg_dest(String nur_dchg_dest) {
		this.nur_dchg_dest = nur_dchg_dest;
	}

	/**
	 * @return the nur_dchg_oth
	 */
	public String getNur_dchg_oth() {
		return nur_dchg_oth;
	}

	/**
	 * @param nur_dchg_oth the nur_dchg_oth to set
	 */
	public void setNur_dchg_oth(String nur_dchg_oth) {
		this.nur_dchg_oth = nur_dchg_oth;
	}

	
	
    
}
