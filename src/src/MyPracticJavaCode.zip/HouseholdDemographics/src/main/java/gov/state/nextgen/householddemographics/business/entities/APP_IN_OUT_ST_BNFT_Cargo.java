package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(APP_IN_OUT_ST_BNFT_Key.class)
@Table(name = "CP_APP_IN_OUT_ST_BENEFIT")
public class APP_IN_OUT_ST_BNFT_Cargo extends AbstractCargo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	
	private String src_app_ind;
	
	@Column(name = "out_of_st_benefit_cd")
	private String out_of_st_bnft_cd;
	
	@Column(name = "out_of_st_benefit_sta_cd")
	private String out_of_st_bnft_sta_cd;
	
	@Column(name = "curr_rcv_out_of_st_benefit_ind")
	private String curr_rcv_out_of_st_bnft_ind;
	
	@Column(name = "rcv_out_of_st_benefit_dt")
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date rcv_out_of_st_bnft_date;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date end_dt;
	
	@Column(name = "change_dt")
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date chg_dt;
	
	@Transient
	private String fst_name;
	
	@Transient
    private String first_name;
    @Transient
    private String last_name;
    @Transient
    private Integer age;
	
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getFst_name() {
		return fst_name;
	}
	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	/**
	 * @return the seq_num
	 */
	public Integer getSeq_num() {
		return seq_num;
	}
	/**
	 * @param seq_num the seq_num to set
	 */
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	/**
	 * @return the out_of_st_bnft_cd
	 */
	public String getOut_of_st_bnft_cd() {
		return out_of_st_bnft_cd;
	}
	/**
	 * @param out_of_st_bnft_cd the out_of_st_bnft_cd to set
	 */
	public void setOut_of_st_bnft_cd(String out_of_st_bnft_cd) {
		this.out_of_st_bnft_cd = out_of_st_bnft_cd;
	}
	/**
	 * @return the out_of_st_bnft_sta_cd
	 */
	public String getOut_of_st_bnft_sta_cd() {
		return out_of_st_bnft_sta_cd;
	}
	/**
	 * @param out_of_st_bnft_sta_cd the out_of_st_bnft_sta_cd to set
	 */
	public void setOut_of_st_bnft_sta_cd(String out_of_st_bnft_sta_cd) {
		this.out_of_st_bnft_sta_cd = out_of_st_bnft_sta_cd;
	}
	/**
	 * @return the curr_rcv_out_of_st_bnft_ind
	 */
	public String getCurr_rcv_out_of_st_bnft_ind() {
		return curr_rcv_out_of_st_bnft_ind;
	}
	/**
	 * @param curr_rcv_out_of_st_bnft_ind the curr_rcv_out_of_st_bnft_ind to set
	 */
	public void setCurr_rcv_out_of_st_bnft_ind(String curr_rcv_out_of_st_bnft_ind) {
		this.curr_rcv_out_of_st_bnft_ind = curr_rcv_out_of_st_bnft_ind;
	}
	/**
	 * @return the rcv_out_of_st_bnft_date
	 */
	public Date getRcv_out_of_st_bnft_date() {
		if(rcv_out_of_st_bnft_date != null) {
			return (Date) rcv_out_of_st_bnft_date.clone();
		}else {
			return null;
		}
	}
	/**
	 * @param rcv_out_of_st_bnft_date the rcv_out_of_st_bnft_date to set
	 */
	public void setRcv_out_of_st_bnft_date(Date rcv_out_of_st_bnft_date) {
		if(rcv_out_of_st_bnft_date !=null) {
			this.rcv_out_of_st_bnft_date = (Date) rcv_out_of_st_bnft_date.clone();
		}else {
			this.rcv_out_of_st_bnft_date = null;
		}
	}
	/**
	 * @return the end_dt
	 */
	public Date getEnd_dt() {
		if(end_dt != null) {
			return (Date) end_dt.clone();
		}else {
			return null;
		}
	}
	/**
	 * @param end_dt the end_dt to set
	 */
	public void setEnd_dt(Date end_dt) {
		if(end_dt != null) {
			this.end_dt = (Date) end_dt.clone();
		}else {
			this.end_dt = null;
		}
	}
	/**
	 * @return the chg_dt
	 */
	public Date getChg_dt() {
		if(chg_dt != null) {
			return (Date) chg_dt.clone();
		}else {
			return null;
		}
	}
	/**
	 * @param chg_dt the chg_dt to set
	 */
	public void setChg_dt(Date chg_dt) {
		if(chg_dt != null) {
			this.chg_dt = (Date) chg_dt.clone();
		}else {
			this.chg_dt = null;
		}
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((chg_dt == null) ? 0 : chg_dt.hashCode());
		result = prime * result + ((curr_rcv_out_of_st_bnft_ind == null) ? 0 : curr_rcv_out_of_st_bnft_ind.hashCode());
		result = prime * result + ((end_dt == null) ? 0 : end_dt.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((out_of_st_bnft_cd == null) ? 0 : out_of_st_bnft_cd.hashCode());
		result = prime * result + ((out_of_st_bnft_sta_cd == null) ? 0 : out_of_st_bnft_sta_cd.hashCode());
		result = prime * result + ((rcv_out_of_st_bnft_date == null) ? 0 : rcv_out_of_st_bnft_date.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}
	

}
