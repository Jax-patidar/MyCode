/*
 * 
 */
package gov.state.nextgen.householddemographics.business.rules;

import gov.state.nextgen.access.business.rules.AbstractBO;

/**
 * This contains any methods that are common to all HouseHoldBOs
 *
 * Creation Date :Wed Jan 31 09:02:54 CST 2007 Modified By: Modified on:
 */
public abstract class AbstractHouseHoldBO extends AbstractBO {

}
