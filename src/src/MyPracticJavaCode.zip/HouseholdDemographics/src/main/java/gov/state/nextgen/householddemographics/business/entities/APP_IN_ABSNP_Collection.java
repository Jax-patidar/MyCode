package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_IN_ABSNP_Collection extends AbstractCollection   {

	private static final long serialVersionUID = -5445030682623278489L;

	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.APP_IN_ABSNP";

	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_ABSNP_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_ABSNP_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_ABSNP_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_ABSNP_Cargo[] getResults() {
		final APP_IN_ABSNP_Cargo[] cbArray = new APP_IN_ABSNP_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_ABSNP_Cargo getCargo(final int idx) {
		return (APP_IN_ABSNP_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_ABSNP_Cargo[] cloneResults() {
		final APP_IN_ABSNP_Cargo[] rescargo = new APP_IN_ABSNP_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_ABSNP_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_ABSNP_Cargo();
			rescargo[i].setAppNum(cargo.getAppNum());
			rescargo[i].setApSeqNum(cargo.getApSeqNum());
			rescargo[i].setIndvSeqNum(cargo.getIndvSeqNum());
			rescargo[i].setPaterEstbSw(cargo.getPaterEstbSw());
			rescargo[i].setRecCpltInd(cargo.getRecCpltInd());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_AR_LG_CNTC_Cargo[]) {
			final APP_IN_ABSNP_Cargo[] cbArray = (APP_IN_ABSNP_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
