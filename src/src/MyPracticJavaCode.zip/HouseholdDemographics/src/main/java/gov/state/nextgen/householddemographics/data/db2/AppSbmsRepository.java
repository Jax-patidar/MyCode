package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;

@Repository
public interface AppSbmsRepository extends CrudRepository<APP_SBMS_Cargo, Long>{

	@Query("SELECT T FROM APP_SBMS_Cargo T where T.app_number= :app_num")
	public APP_SBMS_Cargo[] findByAppNum(@Param("app_num") Integer app_num);
	
	@Query("SELECT T FROM APP_SBMS_Cargo T where T.app_number= :app_num")
	public APP_SBMS_Collection findAllByAppNum(@Param("app_num") Integer app_num);
	
}
