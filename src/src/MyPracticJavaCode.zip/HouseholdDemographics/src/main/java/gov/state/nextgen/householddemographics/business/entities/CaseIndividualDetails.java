package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import gov.state.nextgen.householddemographics.model.CaseIndividualDetailsIncarceratedDetail;
import gov.state.nextgen.householddemographics.model.CaseIndividualDetailsLtcNewPersonDetail;
import gov.state.nextgen.householddemographics.model.CaseIndividualDetailsPassedAwayDetail;
import gov.state.nextgen.householddemographics.model.CaseIndividualDetailsTaxReview;
import gov.state.nextgen.householddemographics.model.CaseIndividualDetailsTaxStatus;

/**
 * @author ransahu
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseIndividualDetails implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3765098563427687082L;

	private String firstName;

	@JsonProperty("lastname")
	private String lastName;

	private String middleName;

	private String suffix;

	private String cin;

	@JsonProperty("DOB")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date dob;
	
	@JsonProperty("dob")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date dateOfBirth;

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	private String genderCode;

	private String emailAddress;

	@JsonProperty("Age")
	private String age;

	private String primaryApplicant;

	CaseIndividualDetailsAddress homeAddress;

	CaseIndividualDetailsAddress mailingAddressIfDifferent;

	CaseIndividualDetailsPhoneNumber homePhoneNumber;

	CaseIndividualDetailsPhoneNumber cellPhoneNumber;
	
	CaseIndividualDetailsPhoneNumber workPhoneNumber;
	
	@JsonProperty("LtcNewPersonDetail")
	CaseIndividualDetailsLtcNewPersonDetail ltcNewPersonDetail;
	
	CaseIndividualDetailsIncarceratedDetail incarceratedDetail;
	
	CaseIndividualDetailsPassedAwayDetail passedAwayDetail;
	
	@JsonProperty("taxStatus")
	CaseIndividualDetailsTaxStatus taxStatus;
	
	@JsonProperty("taxReview")
	CaseIndividualDetailsTaxReview taxReview;
	
	private String cashAid;
	private String calfresh;
	private String healthCoverage;
	
	@JsonProperty("PersonalId")
	private BigDecimal personalId;
	
	private String writtenLanguage;
	
	private String spokenLanguage;
	
	private Boolean homeless;
	
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * @return the suffix
	 */
	public String getSuffix() {
		return suffix;
	}

	/**
	 * @param suffix the suffix to set
	 */
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	/**
	 * @return the cin
	 */
	public String getCin() {
		return cin;
	}

	/**
	 * @param cin the cin to set
	 */
	public void setCin(String cin) {
		this.cin = cin;
	}

	/**
	 * @return the dob
	 */
	public Date getDob() {
		return dob;
	}

	/**
	 * @param dob the dob to set
	 */
	public void setDob(Date dob) {
		this.dob = dob;
	}

	/**
	 * @return the genderCode
	 */
	public String getGenderCode() {
		return genderCode;
	}

	/**
	 * @param genderCode the genderCode to set
	 */
	public void setGenderCode(String genderCode) {
		this.genderCode = genderCode;
	}

	/**
	 * @return the homeAddress
	 */
	public CaseIndividualDetailsAddress getHomeAddress() {
		return homeAddress;
	}

	/**
	 * @param homeAddress the homeAddress to set
	 */
	public void setHomeAddress(CaseIndividualDetailsAddress homeAddress) {
		this.homeAddress = homeAddress;
	}

	/**
	 * @return the mailingAddressIfDifferent
	 */
	public CaseIndividualDetailsAddress getMailingAddressIfDifferent() {
		return mailingAddressIfDifferent;
	}

	/**
	 * @param mailingAddressIfDifferent the mailingAddressIfDifferent to set
	 */
	public void setMailingAddressIfDifferent(CaseIndividualDetailsAddress mailingAddressIfDifferent) {
		this.mailingAddressIfDifferent = mailingAddressIfDifferent;
	}

	/**
	 * @return the homePhoneNumber
	 */
	public CaseIndividualDetailsPhoneNumber getHomePhoneNumber() {
		return homePhoneNumber;
	}

	/**
	 * @param homePhoneNumber the homePhoneNumber to set
	 */
	public void setHomePhoneNumber(CaseIndividualDetailsPhoneNumber homePhoneNumber) {
		this.homePhoneNumber = homePhoneNumber;
	}

	/**
	 * @return the cellPhoneNumber
	 */
	public CaseIndividualDetailsPhoneNumber getCellPhoneNumber() {
		return cellPhoneNumber;
	}

	/**
	 * @param cellPhoneNumber the cellPhoneNumber to set
	 */
	public void setCellPhoneNumber(CaseIndividualDetailsPhoneNumber cellPhoneNumber) {
		this.cellPhoneNumber = cellPhoneNumber;
	}

	/**
	 * @return the emailAddress
	 */
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @param emailAddress the emailAddress to set
	 */
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * @return the age
	 */
	public String getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(String age) {
		this.age = age;
	}

	public String getPrimaryApplicant() {
		return primaryApplicant;
	}

	public void setPrimaryApplicant(String primaryApplicant) {
		this.primaryApplicant = primaryApplicant;
	}

	public String getCashAid() {
		return cashAid;
	}

	public void setCashAid(String cashAid) {
		this.cashAid = cashAid;
	}

	public String getCalfresh() {
		return calfresh;
	}

	public void setCalfresh(String calfresh) {
		this.calfresh = calfresh;
	}

	public String getHealthCoverage() {
		return healthCoverage;
	}

	public void setHealthCoverage(String healthCoverage) {
		this.healthCoverage = healthCoverage;
	}

	public BigDecimal getPersonalId() {
		return personalId;
	}

	public void setPersonalId(BigDecimal personalId) {
		this.personalId = personalId;
	}

	public CaseIndividualDetailsLtcNewPersonDetail getLtcNewPersonDetail() {
		return ltcNewPersonDetail;
	}

	public void setLtcNewPersonDetail(CaseIndividualDetailsLtcNewPersonDetail ltcNewPersonDetail) {
		this.ltcNewPersonDetail = ltcNewPersonDetail;
	}

	public CaseIndividualDetailsIncarceratedDetail getIncarceratedDetail() {
		return incarceratedDetail;
	}

	public void setIncarceratedDetail(CaseIndividualDetailsIncarceratedDetail incarceratedDetail) {
		this.incarceratedDetail = incarceratedDetail;
	}

	public CaseIndividualDetailsPassedAwayDetail getPassedAwayDetail() {
		return passedAwayDetail;
	}

	public void setPassedAwayDetail(CaseIndividualDetailsPassedAwayDetail passedAwayDetail) {
		this.passedAwayDetail = passedAwayDetail;
	}

	public CaseIndividualDetailsTaxStatus getTaxStatus() {
		return taxStatus;
	}

	public void setTaxStatus(CaseIndividualDetailsTaxStatus taxStatus) {
		this.taxStatus = taxStatus;
	}

	public CaseIndividualDetailsTaxReview getTaxReview() {
		return taxReview;
	}

	public void setTaxReview(CaseIndividualDetailsTaxReview taxReview) {
		this.taxReview = taxReview;
	}

	public String getWrittenLanguage() {
		return writtenLanguage;
	}

	public void setWrittenLanguage(String writtenLanguage) {
		this.writtenLanguage = writtenLanguage;
	}

	public String getSpokenLanguage() {
		return spokenLanguage;
	}

	public void setSpokenLanguage(String spokenLanguage) {
		this.spokenLanguage = spokenLanguage;
	}

	public CaseIndividualDetailsPhoneNumber getWorkPhoneNumber() {
		return workPhoneNumber;
	}

	public void setWorkPhoneNumber(CaseIndividualDetailsPhoneNumber workPhoneNumber) {
		this.workPhoneNumber = workPhoneNumber;
	}
	public Boolean getHomeless() {
		return homeless;
	}

	public void setHomeless(Boolean homeless) {
		this.homeless = homeless;
	}
}
