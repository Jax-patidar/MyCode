package gov.state.nextgen.householddemographics.data.db2;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_IMG_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Key;

public interface CpAppIndvRepository extends CrudRepository<APP_INDV_Cargo, APP_INDV_Key>{

	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1")
	public APP_INDV_Cargo[] getByAppNum(Integer appNum); 

	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.rlvn_ind <> ?2")
	public APP_INDV_Cargo[] getNonDelIndv(Integer appNum,int rlvn ); 

	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.rlvn_ind <> ?2")
	List<APP_INDV_Cargo> findByAppNumAndRlvnIndNot(Integer appnum,Integer rlvnind);

	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public List<APP_INDV_Cargo> findByAppNumIndvSeqNum(Integer appNum, Integer indvSeqNum);

	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public APP_INDV_Cargo[] findByAppNumIndvSeqNumArray(Integer appNum, Integer indvSeqNum);

	@Query("select max(c.indv_seq_num) from APP_INDV_Cargo c where c.app_number = ?1")
	public int getByAppNumMax(Integer appNum);

	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1")
	public APP_INDV_Cargo getCargoByAppNum(Integer appNum); 

	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public APP_INDV_Collection getCollByAppNumIndvSeq(Integer appNum, Integer indvSeqNum);

	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1")
	public APP_INDV_Collection loadAppIndvData(Integer appNum);

	@Query("select c.brth_dt from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public Date getByAppNum(Integer appNumber, Integer indvSeqNumber);

	@Query("select c.ssn_num from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public String getSSNByAppNumIndv(Integer appNumber, Integer indvSeqNumber);

	@Query("select max(c.indv_seq_num) from APP_INDV_Cargo c")
	public Integer getMaxIndvSeqNum();

	//Start: Added as a part of CSPM-2627
	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.is_food_program != null and c.indv_seq_num IN ?2")
	public List <APP_INDV_Cargo> getAllIndvFoodProgramDetails(Integer appNum, List<Integer> indvIds); 

	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public APP_INDV_Cargo getAppIndvCargoByAppNumIndvSeq(Integer appNum, Integer indvSeqNum);
	//END: Added as a part of CSPM-2627 	

	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1")
	public APP_INDV_Collection loadCpAppIndvDetails(Integer appNum);
	
	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num IN ?2")
	public APP_INDV_Cargo[] loadIndvData(Integer appNum, List<Integer> indvIds);
	
	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.prim_prsn_sw = 'Y'")
	public APP_INDV_Cargo getPrimaryApplicantIndvDetails(Integer appNumber);
	
	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1")
	public APP_INDV_Collection getByAppNum1(Integer appNum);

	@Transactional
	@Modifying
	@Query("delete from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2 and (c.prim_prsn_sw is null or c.prim_prsn_sw = 'N') ")
	public void deleteNonPrimApplicat(Integer appNumber, Integer indvSeqNum);
	
	@Transactional
	@Modifying
	@Query("update from APP_INDV_Cargo c set c.other_food_program_name = null, c.is_food_program = null where c.app_number = ?1 and c.indv_seq_num = ?2")
	public void deleteFoodProgramDetail(Integer appNum, Integer indvSeqNumber);
	
	@Transactional
	@Modifying
	@Query("update from APP_INDV_Cargo c set  c.foster_court_ord_dep_ind=null , c.foster_incl_calfresh_ind=null where c.app_number = ?1 and c.indv_seq_num = ?2")
	public void deleteFosterChildData(Integer appNum, Integer indvSeqNumber);
	
	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num IN ?2")
	public List <APP_INDV_Cargo> getAllFosterChildDetails(Integer appNum, List<Integer> indvIds);
	
	@Transactional
	@Modifying
	@Query("update from APP_INDV_Cargo c set c.oth_hhm_care_desc = ?4, c.is_child_needs_care =?5 where c.app_number = ?1 and c.indv_seq_num = ?2 and c.src_app_ind= ?3")
	public void updateChildCareValue(Integer appNum, Integer indvSeqNumber,String src_app_ind, String other_hhm_care_desc, String isChildCare);
	
	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num IN ?2")
	public APP_INDV_Cargo[] loadIndvDataByIndvIds(Integer appNum, List<Integer> indvIds);
	
	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.move_out_ind = 'Y'")
	public APP_INDV_Cargo[] loadIndvsLeftHome(Integer appNum);
	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public APP_INDV_Cargo getAppIndvCargoByAppNumIndvSeqSrcAppInd(Integer appNum, Integer indvSeqNum);
	
	@Query("select c from APP_INDV_Cargo c where c.app_number = ?1 and (c.move_out_ind is Null or c.move_out_ind != 'Y') and (c.deceased_ind is Null or c.deceased_ind != 'Y')")
	public APP_INDV_Collection getAppActiveIndvCargoByAppNum(Integer appNum);
	
	@Query("select c from APP_INDV_IMG_Cargo c where c.app_number = ?1 and c.alien_status_cd = ?2")
	public APP_INDV_IMG_Collection loadImmigrationInfo(Integer appNum,String statusCd);

	@Transactional
	@Modifying
	@Query("update APP_INDV_Cargo c set c.help_comm_based_services_ind = ?1, c.update_dt = ?2 where c.app_number = ?3 and c.indv_seq_num IN ?4")
	public void updateCommutingBasedServices(String helpCommBasedServicesInd, Timestamp currentTimeStamp,Integer appNum, List<Integer> indvIds);

	@Transactional
	@Modifying
	@Query("update APP_INDV_Cargo c set c.help_comm_based_services_ind = null, c.update_dt = ?2 where c.app_number = ?1")
	public void clearCommutingBasedServicesValue(Integer appNum, Timestamp currentTimeStamp);

	@Transactional
	@Modifying
	@Query("update APP_INDV_Cargo c set c.dialysis_ind = ?1, c.update_dt = ?2 where c.app_number = ?3 and c.indv_seq_num IN ?4")
	public void updateIndvDataKidneyInd(String dialysisInd, Timestamp currentTimeStamp, Integer appNum,  List<Integer> indvIdList);
	
	@Transactional
	@Modifying
	@Query("update APP_INDV_Cargo c set c.dialysis_ind = null, c.update_dt = ?2 where c.app_number = ?1")
	public void clearKidneyInd(Integer appNum, Timestamp currentTimeStamp);

	@Transactional
	@Modifying
	@Query("update APP_INDV_Cargo c set c.organ_transplant_ind = null, c.update_dt = ?2 where c.app_number = ?1")
	public void clearOrganTransplantInd(Integer appNum, Timestamp currentTimeStamp);

	@Transactional
	@Modifying
	@Query("update APP_INDV_Cargo c set c.organ_transplant_ind = ?1, c.update_dt = ?2 where c.app_number = ?3 and c.indv_seq_num IN ?4")
	public void updateOrganTransplantInd(String organTransplantInd, Timestamp currentTimeStamp,Integer appNum, List<Integer> indvIdList);
	
	@Transactional
	@Modifying
	@Query("update APP_INDV_Cargo c set c.inKindSupport = ?1, c.update_dt = ?2 where c.app_number = ?3 and c.indv_seq_num IN ?4")
	public void updateInKindSupportInd(String inKindSupport, Timestamp currentTimeStamp, Integer appNum,  List<Integer> indvIdList);
	
	@Transactional
	@Modifying
	@Query("update APP_INDV_Cargo c set c.incomeFluctuationInd = ?1, c.update_dt = ?2 where c.app_number = ?3 and c.indv_seq_num IN ?4")
	public void updateIncomeFluctuationInd(String incomeFluctuationInd, Timestamp currentTimeStamp, Integer appNum,  List<Integer> indvIdList);
	
	@Transactional
	@Modifying
	@Query("update APP_INDV_Cargo c set c.incomeFluctuationInd = null, c.anticipatedAmt = null, c.update_dt = ?2 where c.app_number = ?1")
	public void clearIncomeFluctuationInd(Integer appNum, Timestamp currentTimeStamp);
	
	@Transactional
	@Modifying
	@Query("update from APP_INDV_Cargo c set  c.ltcInd = 'Y' where c.app_number = ?1 and c.indv_seq_num = ?2")
	public void updateIndvDataLtcInd(Integer appNum, Integer indvSeqNumber);
	
	@Transactional
	@Modifying
	@Query("update from APP_INDV_Cargo c set  c.ltcInd = 'N' where c.app_number = ?1 and c.indv_seq_num = ?2")
	public void clearIndvDataLtcInd(Integer appNum, Integer indvSeqNum);
	
	@Transactional
	@Query("select c from APP_INDV_Cargo c where ((c.calsawsObject IS NULL AND c.move_out_ind != 'Y' AND c.deceased_ind != 'Y') or (c.calsawsObject IS NOT NULL)) and c.app_number = ?1")
	public APP_INDV_Cargo[] getByAppNumSubMC(Integer appNum);
}
