package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Key;

@Repository
public interface CpAbsPrntRepository extends CrudRepository<APP_ABS_PRNT_Cargo, APP_ABS_PRNT_Key>{
	@Query("select c from APP_ABS_PRNT_Cargo c where c.app_number = :appNum and c.apSexInd = :apSexInd")
	public List<APP_ABS_PRNT_Cargo> findByAppNumAndApSexInd(Integer appNum, String apSexInd);

	@Query("select c from APP_ABS_PRNT_Cargo c where c.app_number = :appNum and c.apSeqNum = :apSeqNum and c.srcAppInd = :srcAppInd")
	public List<APP_ABS_PRNT_Cargo> findByAppNumAndApSeqNumAndSrcAppInd(Integer appNum, double apSeqNum,
			String srcAppInd);

	@Query("select c from APP_ABS_PRNT_Cargo c where c.app_number = :appNum and c.apFstNam = :apFstNam and c.apLastNam = :apLastNam and c.apSexInd = :apSexInd and c.srcAppInd = :srcAppInd")
	public APP_ABS_PRNT_Cargo findByAppFstLstNmSexSrcInd(Integer appNum, String apFstNam, String apLastNam,
			String apSexInd, String srcAppInd);

	@Query("select c from APP_ABS_PRNT_Cargo c where c.app_number = :appNum and c.srcAppInd = :srcAppInd")
	public List<APP_ABS_PRNT_Cargo> findByAppNumSrcInd(Integer appNum, String srcAppInd);

	@Query("SELECT c FROM APP_ABS_PRNT_Cargo c WHERE app_number = :appNum")
	public List<APP_ABS_PRNT_Cargo> findByAppNum(Integer appNum);

	
	@Query("select c from APP_ABS_PRNT_Cargo c where c.app_number = ?1")
	public APP_ABS_PRNT_Collection loadParentSituationAbsentDetails(Integer appnum);
	
	@Transactional
	@Modifying
	@Query("delete from APP_ABS_PRNT_Cargo c where c.app_number = ?1 and c.apSeqNum = ?2")
	public void deletePrntDetails(Integer appNumber, Double indvSeqNum);
	
	/* Start : CSPM-7108 */
	@Transactional
    @Modifying
    @Query("delete from APP_ABS_PRNT_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
    public void deleteAbsPrntDetails(Integer appNumber, Integer indvSeqNum);
	/* End : CSPM-7108 */
}
