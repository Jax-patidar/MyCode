package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

public class OTHER_HOUSEHOLD_DETAILS_KEY implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 669724569378226962L;
	
	private Integer app_number;
	private Integer indv_seq_num;
	
	public OTHER_HOUSEHOLD_DETAILS_KEY() {}
	
	public OTHER_HOUSEHOLD_DETAILS_KEY(Integer app_number, Integer indv_seq_num) {
		super();
		this.app_number = app_number;
		this.indv_seq_num = indv_seq_num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		return result;
	}

	

}
