package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Embeddable;

@Embeddable
public class CpRmbRequestDetailsPrimaryKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5431800713666426601L;
	private Long cpRmbRequestDetailId;

	public CpRmbRequestDetailsPrimaryKey() {
	}

	/**
	 * @return the cpRmbRequestDetailId
	 */
	public Long getCpRmbRequestDetailId() {
		return cpRmbRequestDetailId;
	}

	/**
	 * @param cpRmbRequestDetailId the cpRmbRequestDetailId to set
	 */
	public void setCpRmbRequestDetailId(Long cpRmbRequestDetailId) {
		this.cpRmbRequestDetailId = cpRmbRequestDetailId;
	}

	public CpRmbRequestDetailsPrimaryKey(Long cpRmbRequestDetailId) {
		super();
		this.cpRmbRequestDetailId = cpRmbRequestDetailId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cpRmbRequestDetailId == null) ? 0 : cpRmbRequestDetailId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CpRmbRequestDetailsPrimaryKey other = (CpRmbRequestDetailsPrimaryKey) obj;
		if (cpRmbRequestDetailId == null) {
			if (other.cpRmbRequestDetailId != null)
				return false;
		} else if (!cpRmbRequestDetailId.equals(other.cpRmbRequestDetailId))
			return false;
		return true;
	}
	
	
	
	

}
