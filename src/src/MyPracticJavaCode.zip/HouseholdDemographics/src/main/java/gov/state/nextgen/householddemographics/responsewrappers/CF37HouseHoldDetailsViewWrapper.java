package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Collection;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component(HouseHoldDemoGraphicsConstants.CFHHS)
@Scope("prototype")
public class CF37HouseHoldDetailsViewWrapper implements LogicResponseInterface {
	private static final String PAGE_ID = HouseHoldDemoGraphicsConstants.CFHHS;
	DriverPageResponse driverPageResponse = new DriverPageResponse();
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {	
		Map<String,Object> pageCollection = fwTrxn.getPageCollection();	
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) != null) {
			getAppIndvCollection(pageCollection);
		}
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION) != null) {
			getCpAppRGSTCollection(pageCollection);
		}
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_AUTH_REP_COLLECTION) != null) {
			getCpAppAuthRepCollection(pageCollection);
		}
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_PGM_RQST_COLLECTION) != null) {
			getCpAppPgmRqstCollection(pageCollection);
		}
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.APP_IN_NEWB_COLLECTION) != null) {
			getAppIndvNewBornCollection(pageCollection);
		}
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION) != null) {
			getAppInSchleCollection(pageCollection);
		}
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION) != null) {
			getCpAppHshlRltCollection(pageCollection);
		}
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.APP_SBMS_COLLECTION) != null) {
			getAppSbmsCollection(pageCollection);
		}
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.OTHER_HOUSEHOLD_DETAILS_COLLECTION) != null) {
			getOtherHouseholdDetailsCollection(pageCollection);
		}	
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION) != null) {
		    generateRmbRqstResponse(pageCollection);	
		}
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION) != null) {
		    generateRmbRqstDetailResponse(pageCollection);
		}
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getRequest().get(FwConstants.APP_NUMBER)));
		return driverPageResponse;
	}
	
    private void getAppIndvCollection(Map<String, Object> pageCollection) {		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_INDV_Collection Started");
		List<APP_INDV_Cargo> indvList = new ArrayList<>();
		APP_INDV_Cargo cargo = null;
		APP_INDV_Collection appCollection = pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) != null
						? (APP_INDV_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION)
						: null;
		if (appCollection != null && !appCollection.isEmpty()) {
			for (int i = 0; i < appCollection.size(); i++) {
				cargo = appCollection.getCargo(i);
				indvList.add(cargo);
			}
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, indvList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_INDV_Collection completed");
	}

	private void getCpAppRGSTCollection(Map<String, Object> pageCollection) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_RGST_Collection started");
		List<CP_APP_RGST_Cargo> rgstList = new ArrayList<>();
		CP_APP_RGST_Collection rgstColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION) != null
						? (CP_APP_RGST_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION)
						: null;
		if (rgstColl != null && !rgstColl.isEmpty()) {
			for (int i = 0; i < rgstColl.size(); i++) {
				CP_APP_RGST_Cargo rgstCargo = rgstColl.getCargo(i);
				rgstList.add(rgstCargo);
			}
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION, rgstList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_RGST_Collection completed");
	}

	private void getCpAppAuthRepCollection(Map<String, Object> pageCollection) {		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_AUTH_REP_Collection started");		
		List<CP_APP_AUTH_REP_Cargo> repList = new ArrayList<>();
		CP_APP_AUTH_REP_Collection repColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_APP_AUTH_REP_COLLECTION) != null
						? (CP_APP_AUTH_REP_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_APP_AUTH_REP_COLLECTION)
						: null;
		if (repColl != null && !repColl.isEmpty()) {
			for (int i = 0; i < repColl.size(); i++) {
				CP_APP_AUTH_REP_Cargo repCargo = repColl.getCargo(i);
				repList.add(repCargo);
			}

		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_AUTH_REP_COLLECTION, repList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_AUTH_REP_Collection completed");
	}

	private void getCpAppPgmRqstCollection(Map<String, Object> pageCollection) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_PGM_RQST_Collection started");	
		List<APP_PGM_RQST_Cargo> progList = new ArrayList<>();
		APP_PGM_RQST_Collection programColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_APP_PGM_RQST_COLLECTION) != null
						? (APP_PGM_RQST_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_APP_PGM_RQST_COLLECTION)
						: null;
		if (programColl != null && !programColl.isEmpty()) {
			for (Iterator<?> iterator = programColl.iterator(); iterator.hasNext();) {
				APP_PGM_RQST_Cargo pgmCargo = (APP_PGM_RQST_Cargo) iterator.next();
				progList.add(pgmCargo);
			}
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_PGM_RQST_COLLECTION, progList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_PGM_RQST_Collection completed");
	}
	
	private void getAppIndvNewBornCollection(Map<String, Object> pageCollection) {		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_IN_NEWB_Collection started");		
		List<APP_IN_NEWB_Cargo> newBornList = new ArrayList<>();
		APP_IN_NEWB_Collection appInNewCollection = pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_IN_NEWB_COLLECTION) != null
						? (APP_IN_NEWB_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.APP_IN_NEWB_COLLECTION)
						: null;

		if (appInNewCollection != null && !appInNewCollection.isEmpty()) {
			for (Iterator<?> iterator = appInNewCollection.iterator(); iterator.hasNext();) {
				APP_IN_NEWB_Cargo newBornCargo = (APP_IN_NEWB_Cargo) iterator.next();
				newBornList.add(newBornCargo);
			}
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_IN_NEWB_COLLECTION, newBornList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_IN_NEWB_Collection completed");		
	}
	
	
	private void getAppInSchleCollection(Map<String, Object> pageCollection) {	
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_IN_SCHLE_Collection started");		
		List<APP_IN_SCHLE_Cargo> appinschleList = new ArrayList<>();
		APP_IN_SCHLE_Collection appInSchleCollection = pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION) != null
						? (APP_IN_SCHLE_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION)
						: null;
		if (appInSchleCollection != null && !appInSchleCollection.isEmpty()) {
			for (Iterator<?> iterator = appInSchleCollection.iterator(); iterator.hasNext();) {
				APP_IN_SCHLE_Cargo appinschleCargo = (APP_IN_SCHLE_Cargo) iterator.next();
				appinschleList.add(appinschleCargo);
			}
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION, appinschleList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_IN_SCHLE_Collection completed");			
	}
	

	private void getCpAppHshlRltCollection(Map<String, Object> pageCollection) {		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_HSHL_RLT_Collection started");
		List<CP_APP_HSHL_RLT_Cargo> rltList = new ArrayList<>();
		CP_APP_HSHL_RLT_Collection rltColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION) != null
						? (CP_APP_HSHL_RLT_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION)
						: null;
		if (rltColl != null && !rltColl.isEmpty()) {
			for (Iterator<?> iterator = rltColl.iterator(); iterator.hasNext();) {
				CP_APP_HSHL_RLT_Cargo rltCargo = (CP_APP_HSHL_RLT_Cargo) iterator.next();
				rltList.add(rltCargo);
			}

		}
		driverPageResponse.getPageCollection().put((String) HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION,
				rltList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_HSHL_RLT_Collection completed");  
	}

	private void getAppSbmsCollection(Map<String, Object> pageCollection) {		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_SBMS_Collection started");
		List<APP_SBMS_Cargo> sbmsDtlsList = new ArrayList<>();
		APP_SBMS_Collection sbmsDtlsColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_SBMS_COLLECTION) != null
						? (APP_SBMS_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_SBMS_COLLECTION)
						: null;
		if (sbmsDtlsColl != null && !sbmsDtlsColl.isEmpty()) {
			for (Iterator<?> iterator = sbmsDtlsColl.iterator(); iterator.hasNext();) {
				APP_SBMS_Cargo sbmsDtlsCargo = (APP_SBMS_Cargo) iterator.next();
				sbmsDtlsList.add(sbmsDtlsCargo);
			}

		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_SBMS_COLLECTION, sbmsDtlsList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_SBMS_Collection completed");
	}
	
    private void getOtherHouseholdDetailsCollection(Map<String, Object> pageCollection) {	
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OTHER_HOUSEHOLD_DETAILS_Collection started");		
		List<OTHER_HOUSEHOLD_DETAILS_Cargo> otherHouseholdDetailsCargoList = new ArrayList<>();
		OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection = pageCollection.get(HouseHoldDemoGraphicsConstants.OTHER_HOUSEHOLD_DETAILS_COLLECTION) != null
						? (OTHER_HOUSEHOLD_DETAILS_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.OTHER_HOUSEHOLD_DETAILS_COLLECTION)
						: null;
		if (otherHouseholdDetailsCollection != null && !otherHouseholdDetailsCollection.isEmpty()) {
			for (Iterator<?> iterator = otherHouseholdDetailsCollection.iterator(); iterator.hasNext();) {
				OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo = (OTHER_HOUSEHOLD_DETAILS_Cargo) iterator.next();
				otherHouseholdDetailsCargoList.add(otherHouseholdDetailsCargo);
			}

		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.OTHER_HOUSEHOLD_DETAILS_COLLECTION, otherHouseholdDetailsCargoList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OTHER_HOUSEHOLD_DETAILS_Collection completed");
}
    
	private void generateRmbRqstResponse(Map<String, Object> pageCollection) {

		List<RMB_RQST_Cargo> rmbRqstList = new ArrayList<>();
		RMB_RQST_Collection rmbRqstColl = pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION) != null
				? (RMB_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION)
				: null;
		if (Objects.nonNull(rmbRqstColl) && !rmbRqstColl.isEmpty()) {
			rmbRqstList = Arrays.asList(rmbRqstColl.getResults());
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION, rmbRqstList);
	}
	
	private void generateRmbRqstDetailResponse(Map<String, Object> pageCollection) {

		List<CpRmbRequestDetails_Cargo> rmbRqstDetailList = new ArrayList<>();
		CpRmbRequestDetails_Collection rmbRqstDetailColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION) != null
						? (CpRmbRequestDetails_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION)
						: null;
		if (Objects.nonNull(rmbRqstDetailColl) && !rmbRqstDetailColl.isEmpty()) {
			rmbRqstDetailList = Arrays.asList(rmbRqstDetailColl.getResults());
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION,
				rmbRqstDetailList);
	}
    
}
