package gov.state.nextgen.householddemographics.business.entities;

/**
 * This class contains the collection of entities of CP_APP_AR_LG_CNTC
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class Address_Validate_Custom_Collection extends AbstractCollection  {

	private static final long serialVersionUID = 4537413576559576787L;

	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.Address_Validate_Custom_Cargo";
	
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final Address_Validate_Custom_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final Address_Validate_Custom_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final Address_Validate_Custom_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public Address_Validate_Custom_Cargo[] getResults() {
		final Address_Validate_Custom_Cargo[] cbArray = new Address_Validate_Custom_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public Address_Validate_Custom_Cargo getCargo(final int idx) {
		return (Address_Validate_Custom_Cargo) get(idx);
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof Address_Validate_Custom_Cargo[]) {
			final Address_Validate_Custom_Cargo[] cbArray = (Address_Validate_Custom_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
	
