package gov.state.nextgen.householddemographics.business.rules;

import java.util.List;
import java.util.Objects;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.data.db2.IndividualInformationRepo;

@Component
public class ARHouseholdMembersSummaryBO extends HouseHoldBaseBO {

    protected IndividualInformationRepo individualInformationRepo;

    /**
     * Load houseHold members
     * @param appNumber
     * @return
     */
    public APP_INDV_Collection loadHouseholdMembers(String appNumber) {
     try {	
        APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
        List<APP_INDV_Cargo> app_indv_cargoList = getAppIndvCargos(individualInformationRepo.findByAppNum(Integer.parseInt(appNumber)));
        if(!CollectionUtils.isEmpty(app_indv_cargoList)) {
            appIndvCollection.setResults(app_indv_cargoList.toArray(new APP_INDV_Cargo[app_indv_cargoList.size()]));
        }
        return appIndvCollection;
     }catch(Exception e) {
    	 throw e;
     }
    }

    /**
     * Update citizenship verify flag with Y.
     * @param appIndvCollection
     */
    public void updateChildCitizenShipStatus(APP_INDV_Collection appIndvCollection) {
        APP_INDV_Cargo cargo = (APP_INDV_Cargo) appIndvCollection.get(0);

        String appNum = cargo.getApp_num();
        String indvSeqNum = cargo.getIndv_seq_num().toString();

        CP_APP_INDV_Cargo dbCargo = individualInformationRepo.findByAppNumAndIndvSeqNum(Integer.parseInt(appNum),indvSeqNum);
        if (dbCargo != null && FwConstants.YES.equalsIgnoreCase(cargo.getUs_ctzn_sw())) {
            dbCargo.setCitizen_verify_ind(FwConstants.YES);
            individualInformationRepo.save(dbCargo);
        }
    }

    /**
     * Update citizenship flag with usCtznSw
     * @param cargo
     * @param usCtznSw
     */
    public void updateCitizenShipWithExistingFlag(APP_INDV_Cargo cargo, String usCtznSw) {
     try {
        String appNum = cargo.getApp_num();
        String indvSeqNum = cargo.getIndv_seq_num().toString();
        CP_APP_INDV_Cargo dbCargo = individualInformationRepo.findByAppNumAndIndvSeqNum(Integer.parseInt(appNum),indvSeqNum);

        if(Objects.nonNull(dbCargo)){
            dbCargo.setCitizen_verify_ind(usCtznSw);
            individualInformationRepo.save(dbCargo);
        }
     }catch(Exception e) {
        	throw e;
        }
        
    }
}
