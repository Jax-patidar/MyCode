package gov.state.nextgen.householddemographics.business.profilemanagers;

import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.CP_RMC_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMC_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMC_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.RMCProfileRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RMCResponseProfileManager {

    private static Logger logger = LoggerFactory.getLogger(RMCResponseProfileManager.class);

    protected RMCProfileRepo rmcProfileRepo;

    public RMC_IN_PRFL_Collection loadProfile(String appNum) {
        try {
            final Map criteria = new HashMap();
            RMC_IN_PRFL_Collection appInPrflCollection = new RMC_IN_PRFL_Collection();
           List appInPrflCargoList = rmcProfileRepo.findAllByAppNum(appNum);
            if (appInPrflCargoList.size() > 0) {
                appInPrflCollection.setResults(getAppInPrflCargoArray(appInPrflCargoList));
            }
            return appInPrflCollection;
        } catch (final Exception exception) {
            throw exception;
        }
    }

    private RMC_IN_PRFL_Cargo[] getAppInPrflCargoArray(List<CP_RMC_IN_PRFL_Cargo> appInPrflCargoList) {
        List<RMC_IN_PRFL_Cargo> rmc_in_prfl_cargos = new ArrayList<>();
        for(CP_RMC_IN_PRFL_Cargo cp_rmc_in_prfl_cargo:appInPrflCargoList){
            RMC_IN_PRFL_Cargo cargo = new RMC_IN_PRFL_Cargo();
            cargo.setAppNum(cp_rmc_in_prfl_cargo.getAppNum());
            if(Objects.nonNull(cp_rmc_in_prfl_cargo.getIndvSeqNum())) { cargo.setIndv_seq_num(cp_rmc_in_prfl_cargo.getIndvSeqNum().toString()); }
            cargo.setMoved_out_of_home_resp(cp_rmc_in_prfl_cargo.getMovedOutOfHomeResp());
            rmc_in_prfl_cargos.add(cargo);
        }
        return rmc_in_prfl_cargos.toArray(new RMC_IN_PRFL_Cargo[rmc_in_prfl_cargos.size()]);
    }

    public RMC_IN_PRFL_Cargo getProfile(final RMC_IN_PRFL_Collection aRmcInProfileCollection, final String aIndvSeqNum) {

        try {
            final int aAppInProfileCollectionSize = aRmcInProfileCollection.size();
            RMC_IN_PRFL_Cargo rmcInPrflCargo = null;
            for (int i = 0; i < aAppInProfileCollectionSize; i++) {
                rmcInPrflCargo = (RMC_IN_PRFL_Cargo) aRmcInProfileCollection.get(i);
                if (rmcInPrflCargo.getIndv_seq_num().equals(aIndvSeqNum)) {
                    return rmcInPrflCargo;
                }
            }
            return null;
        } catch (final Exception exception) {
            throw exception;
        }
    }

    public String getProfileResponse(RMC_IN_PRFL_Cargo aRmcInPrflCargo, short aFieldId) {

        switch (aFieldId) {
            case HouseHoldDemoGraphicsConstants.ACCIDENT:
                return aRmcInPrflCargo.getAcdt_resp();
            case HouseHoldDemoGraphicsConstants.ADOPTION_ASSISTANCE:
                return aRmcInPrflCargo.getAdpt_asst_resp();
            case HouseHoldDemoGraphicsConstants.ALIMONY_RECEIVED:
                return aRmcInPrflCargo.getAlmy_rcv_resp();
            case HouseHoldDemoGraphicsConstants.BENEFIT_ANNUITIES:
                return aRmcInPrflCargo.getBnft_anty_resp();
            case HouseHoldDemoGraphicsConstants.BENEFIT_CHARITY:
                return aRmcInPrflCargo.getBnft_chrt_resp();
            case HouseHoldDemoGraphicsConstants.BENEFIT_DISABLE:
                return aRmcInPrflCargo.getBnft_dabl_resp();
            case HouseHoldDemoGraphicsConstants.BENEFIT_DIVIDEND:
                return aRmcInPrflCargo.getBnft_divnd_resp();
            case HouseHoldDemoGraphicsConstants.BENEFIT_TRUST:
                return aRmcInPrflCargo.getBnft_est_trst_resp();
            case HouseHoldDemoGraphicsConstants.BENEFIT_RAILROAD_RETIREMENT:
                return aRmcInPrflCargo.getBnft_rr_resp();
            case HouseHoldDemoGraphicsConstants.BENEFIT_UNEMPLOYMENT:
                return aRmcInPrflCargo.getBnft_uempl_resp();
            case HouseHoldDemoGraphicsConstants.BENEFIT_VETERAN:
                return aRmcInPrflCargo.getBnft_vet_resp();
            case HouseHoldDemoGraphicsConstants.CHILD_SUPPORT_PAYMENT:
                return aRmcInPrflCargo.getChld_sprt_pay_resp();
            case HouseHoldDemoGraphicsConstants.DISABLE:
                return aRmcInPrflCargo.getDabl_resp();
            case HouseHoldDemoGraphicsConstants.DEPENDENT_CARE:
                return aRmcInPrflCargo.getDpnd_care_resp();
            case HouseHoldDemoGraphicsConstants.DRUG_FELON:
                return aRmcInPrflCargo.getDrug_feln_resp();
            case HouseHoldDemoGraphicsConstants.FSET_SANCTION:
                return aRmcInPrflCargo.getFset_sctn_resp();
            case HouseHoldDemoGraphicsConstants.FOSTER_CARE:
                return aRmcInPrflCargo.getFstr_care_resp();
            case HouseHoldDemoGraphicsConstants.GENERAL_RELIEF:
                return aRmcInPrflCargo.getGen_rlf_resp();
            case HouseHoldDemoGraphicsConstants.HEALTHCARE_COVERAGE:
                return aRmcInPrflCargo.getHc_cvrg_resp();
            case HouseHoldDemoGraphicsConstants.INCOME_INTEREST:
                return aRmcInPrflCargo.getIncm_int_resp();
            case HouseHoldDemoGraphicsConstants.INDIVIDUAL_FAMILY_MEDICAID:
                return aRmcInPrflCargo.getIndv_fma_rqst_ind();
            case HouseHoldDemoGraphicsConstants.INDIVIDUAL_FPW:
                return aRmcInPrflCargo.getIndv_fpw_rqst_ind();
            case HouseHoldDemoGraphicsConstants.INDIVIDUAL_FOODSHARE:
                return aRmcInPrflCargo.getIndv_fs_rqst_ind();
            case HouseHoldDemoGraphicsConstants.IREW:
                return aRmcInPrflCargo.getIrwe_resp();
            case HouseHoldDemoGraphicsConstants.KINSHIP_CARE:
                return aRmcInPrflCargo.getKinship_care_resp();
            case HouseHoldDemoGraphicsConstants.MEDICAL_EXPENSE:
                return aRmcInPrflCargo.getMed_exp_resp();
            case HouseHoldDemoGraphicsConstants.MILITARY_ALLOTMENT:
                return aRmcInPrflCargo.getMil_allot_resp();
            case HouseHoldDemoGraphicsConstants.MONEY_FROM_ANOTHER_PERSON:
                return aRmcInPrflCargo.getMony_othr_resp();
            case HouseHoldDemoGraphicsConstants.REFUGE:
                return aRmcInPrflCargo.getNatl_rfge_resp();
            case HouseHoldDemoGraphicsConstants.NEEDY_INDIAN:
                return aRmcInPrflCargo.getNeed_ind_resp();
            case HouseHoldDemoGraphicsConstants.ON_STRIKE:
                return aRmcInPrflCargo.getOn_strk_sw();
            case HouseHoldDemoGraphicsConstants.OTHER_PENSION:
                return aRmcInPrflCargo.getOp_aoda_tmt_rcv_sw();
            case HouseHoldDemoGraphicsConstants.OTHER_INCOME:
                return aRmcInPrflCargo.getOthr_incm_resp();
            case HouseHoldDemoGraphicsConstants.OTHER_SOURCE:
                return aRmcInPrflCargo.getOthr_src_resp();
            case HouseHoldDemoGraphicsConstants.OWNER_ASSET:
                return aRmcInPrflCargo.getOwn_aset_resp();
            case HouseHoldDemoGraphicsConstants.PAY_HOUSING_BILL:
                return aRmcInPrflCargo.getPay_hous_bill_resp();
            case HouseHoldDemoGraphicsConstants.PREGNANCY:
                return aRmcInPrflCargo.getPreg_resp();
            case HouseHoldDemoGraphicsConstants.JOB_IN_KIND:
                return aRmcInPrflCargo.getJob_iknd_resp();
            case HouseHoldDemoGraphicsConstants.PAY_ROOM_AND_BOARD:
                return aRmcInPrflCargo.getPay_rmr_brd_resp();
            case HouseHoldDemoGraphicsConstants.PENSION_RETIREMENT:
                return aRmcInPrflCargo.getPnsn_retr_resp();
            case HouseHoldDemoGraphicsConstants.PROPERTY_SOLD:
                return aRmcInPrflCargo.getProp_sold_resp();
            case HouseHoldDemoGraphicsConstants.RECEIVE_FS_IN_OTHER_STATE:
                return aRmcInPrflCargo.getRcv_fs_oth_st_resp();
            case HouseHoldDemoGraphicsConstants.RECEIVE_HOUSING_ASSET:
                return aRmcInPrflCargo.getRcv_hous_asst_resp();
            case HouseHoldDemoGraphicsConstants.RECEIVE_MEDICARE:
                return aRmcInPrflCargo.getRcv_medcr_resp();
            case HouseHoldDemoGraphicsConstants.RECEIVE_SOCIAL_SECURITY:
                return aRmcInPrflCargo.getRcv_ss_resp();
            case HouseHoldDemoGraphicsConstants.RECEIVE_SSI_LETTER:
                return aRmcInPrflCargo.getRcv_ssi_ltr_resp();
            case HouseHoldDemoGraphicsConstants.RECEIVE_SSI:
                return aRmcInPrflCargo.getRcv_ssi_sw();
            case HouseHoldDemoGraphicsConstants.ROOM_AND_BOARD:
                return aRmcInPrflCargo.getRmr_brd_incm_resp();
            case HouseHoldDemoGraphicsConstants.SELF_EMPLOYMENT:
                return aRmcInPrflCargo.getSelf_empl_resp();
            case HouseHoldDemoGraphicsConstants.RECEIVE_SSI_DCOND:
                return aRmcInPrflCargo.getSsi_dcond_resp();
            case HouseHoldDemoGraphicsConstants.RECEIVE_SSI_1619B:
                return aRmcInPrflCargo.getSsi_1619b_rcv_sw();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_ASSESSMENT:
                return aRmcInPrflCargo.getSu_ases_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_COAL:
                return aRmcInPrflCargo.getSu_cst_coal_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_ELECTRICTY:
                return aRmcInPrflCargo.getSu_cst_elec_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_FUEL:
                return aRmcInPrflCargo.getSu_cst_fuel_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_GAS:
                return aRmcInPrflCargo.getSu_cst_gas_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_HOME:
                return aRmcInPrflCargo.getSu_cst_home_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_INSTALL:
                return aRmcInPrflCargo.getSu_cst_istl_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_LPGAS:
                return aRmcInPrflCargo.getSu_cst_lpgas_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_MOBILE_HOME:
                return aRmcInPrflCargo.getSu_cst_mbl_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_MORTGAGE:
                return aRmcInPrflCargo.getSu_cst_mtge_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_OTHER:
                return aRmcInPrflCargo.getSu_cst_othr_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_PHONE:
                return aRmcInPrflCargo.getSu_cst_phn_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_RENT:
                return aRmcInPrflCargo.getSu_cst_rent_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_SEWER:
                return aRmcInPrflCargo.getSu_cst_swr_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_TAX:
                return aRmcInPrflCargo.getSu_cst_tax_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_TRASH:
                return aRmcInPrflCargo.getSu_cst_trsh_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_WOOD:
                return aRmcInPrflCargo.getSu_cst_wood_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_WATER:
                return aRmcInPrflCargo.getSu_cst_wtr_resp();
            case HouseHoldDemoGraphicsConstants.SHELTER_COST_WASTE:
                return aRmcInPrflCargo.getSu_cst_wwt_resp();
            case HouseHoldDemoGraphicsConstants.TRIBAL_TANF:
                return aRmcInPrflCargo.getTrb_tanf_resp();
            case HouseHoldDemoGraphicsConstants.UTILITY_EXPENSE:
                return aRmcInPrflCargo.getUtil_exp_resp();
            case HouseHoldDemoGraphicsConstants.WORKER_COMP:
                return aRmcInPrflCargo.getWork_comp_resp();
            case HouseHoldDemoGraphicsConstants.TRIBAL_CAPITA:
                return aRmcInPrflCargo.getTrb_cpta_resp();
            case HouseHoldDemoGraphicsConstants.EDUCATIONAL_AID:
                return aRmcInPrflCargo.getEduc_aid_resp();
            case HouseHoldDemoGraphicsConstants.WHEAP:
                return aRmcInPrflCargo.getWheap_resp();
            case HouseHoldDemoGraphicsConstants.REGULAR_EMPL:
                return aRmcInPrflCargo.getEmpl_resp();
            case HouseHoldDemoGraphicsConstants.BNFT_CHL_SPRT_RESP:
                return aRmcInPrflCargo.getBnft_chl_sprt_resp();
            case HouseHoldDemoGraphicsConstants.PUB_ASST_RESP:
                return aRmcInPrflCargo.getPub_asst_resp();
            case HouseHoldDemoGraphicsConstants.YEHOC_RESP:
                return aRmcInPrflCargo.getYehoc_resp();
            // PCR 35980
            case HouseHoldDemoGraphicsConstants.PAST_HEALTHCARE_COVERAGE:
                return aRmcInPrflCargo.getPast_hc_cvrg_resp();

            // PCR# 40362 - ADDED NEW RESPONSES FOR RMB AND SMRF CHANGES -
            // starts
            case HouseHoldDemoGraphicsConstants.MAPP_BENEFITS_RESP:
                return aRmcInPrflCargo.getBnft_mapp_resp();

            case HouseHoldDemoGraphicsConstants.BUR_AST_CASKET:
                return aRmcInPrflCargo.getBury_aset_oth_resp();

            case HouseHoldDemoGraphicsConstants.BUR_AST_IRREVOCABLE:
                return aRmcInPrflCargo.getBury_aset_rbt_resp();

            case HouseHoldDemoGraphicsConstants.BUR_AST_INSURANCE:
                return aRmcInPrflCargo.getBury_aset_ins_resp();

            case HouseHoldDemoGraphicsConstants.BUR_AST_MAUSOLEUM:
                return aRmcInPrflCargo.getBury_aset_mas_resp();

            case HouseHoldDemoGraphicsConstants.BUR_AST_OTHER:
                return aRmcInPrflCargo.getBury_aset_oth_resp();

            case HouseHoldDemoGraphicsConstants.BUR_AST_PLOT:
                return aRmcInPrflCargo.getBury_aset_plt_resp();

            case HouseHoldDemoGraphicsConstants.BUR_AST_REVOCABLE:
                return aRmcInPrflCargo.getBury_aset_rbt_resp();

            case HouseHoldDemoGraphicsConstants.BUR_AST_VAULT:
                return aRmcInPrflCargo.getBury_aset_v_resp();

            case HouseHoldDemoGraphicsConstants.LIF_AST_GROUP_LIFE:
                return aRmcInPrflCargo.getLi_aset_g_l_resp();

            case HouseHoldDemoGraphicsConstants.LIF_AST_GROUP_TERM:
                return aRmcInPrflCargo.getLi_aset_g_t_resp();

            case HouseHoldDemoGraphicsConstants.LIF_AST_TERM:
                return aRmcInPrflCargo.getLi_aset_trm_resp();

            case HouseHoldDemoGraphicsConstants.LIF_AST_UNIVERSAL:
                return aRmcInPrflCargo.getLi_aset_unv_resp();

            case HouseHoldDemoGraphicsConstants.LIF_AST_WHOLE_LIFE:
                return aRmcInPrflCargo.getLi_aset_w_l_resp();

            case HouseHoldDemoGraphicsConstants.LIQ_ASET_CASH:
                return aRmcInPrflCargo.getLiquid_asset_cash_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_XFER:
                return aRmcInPrflCargo.getLqd_aset_tr_f_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_ANNUITY:
                return aRmcInPrflCargo.getLiquid_aset_disable_blind_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_IRA:
                return aRmcInPrflCargo.getLiquid_asset_ira_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_IRS_RET:
                return aRmcInPrflCargo.getLiquid_asset_irs_retirmnt_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_SAVINGS_ACC:
                return aRmcInPrflCargo.getLiquid_asset_savings_acc_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_PENSION_PLAN:
                return aRmcInPrflCargo.getLiquid_asset_pension_plan_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_PROMISSORY:
                return aRmcInPrflCargo.getLiquid_asset_promissory_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_RETIREMENT:
                return aRmcInPrflCargo.getLiquid_asset_retirement_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_STOCK_BONDS:
                return aRmcInPrflCargo.getLiquid_asset_stocks_bonds_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_TRUST_FUND:
                return aRmcInPrflCargo.getLiquid_asset_trust_fund_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_OTHER:
                return aRmcInPrflCargo.getLiquid_asset_other_response();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_OTHER_TYPE:
                return aRmcInPrflCargo.getLiquid_asset_other_type_resp();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASET_BANK:
                return aRmcInPrflCargo.getLiquid_asset_bank_acc_resp();

            case HouseHoldDemoGraphicsConstants.LIQ_ASET_HOME_SALE:
                return aRmcInPrflCargo.getLqd_aset_h_s_resp();

            case HouseHoldDemoGraphicsConstants.LIQ_ASET_US_BOND:
                return aRmcInPrflCargo.getLqd_aset_us_b_resp();

            case HouseHoldDemoGraphicsConstants.OTHR_ASET_BURIAL:
                return aRmcInPrflCargo.getOther_asset_burial_resp();

            case HouseHoldDemoGraphicsConstants.OTHR_ASET_LIFE_INSURANCE:
                return aRmcInPrflCargo.getOther_aset_life_insurance_resp();

            case HouseHoldDemoGraphicsConstants.OTHR_ASET_PERSONAL_PROPERTY:
                return aRmcInPrflCargo.getOther_asset_personal_prop_resp();

            case HouseHoldDemoGraphicsConstants.OTHR_ASET_REAL_PROPERTY:
                return aRmcInPrflCargo.getOther_asset_real_property_resp();

            case HouseHoldDemoGraphicsConstants.OTHR_ASET_VEHICLE:
                return aRmcInPrflCargo.getOther_asset_vehicle_resp();

            case HouseHoldDemoGraphicsConstants.OTHR_ASET_TRANSFER:
                return aRmcInPrflCargo.getOther_asset_transfer_resp();

            case HouseHoldDemoGraphicsConstants.REAL_ASET_APARTMENT:
                return aRmcInPrflCargo.getReal_aset_apt_resp();

            case HouseHoldDemoGraphicsConstants.REAL_ASET_COMMERCIAL:
                return aRmcInPrflCargo.getReal_aset_com_resp();

            case HouseHoldDemoGraphicsConstants.REAL_ASET_CONDO:
                return aRmcInPrflCargo.getReal_aset_con_resp();

            case HouseHoldDemoGraphicsConstants.REAL_ASET_RENTAL:
                return aRmcInPrflCargo.getReal_asset_rental_resp();

            case HouseHoldDemoGraphicsConstants.REAL_ASET_DUPLEX:
                return aRmcInPrflCargo.getReal_aset_dup_resp();

            case HouseHoldDemoGraphicsConstants.REAL_ASET_FARM:
                return aRmcInPrflCargo.getReal_aset_frm_resp();

            case HouseHoldDemoGraphicsConstants.REAL_ASET_HOUSE:
                return aRmcInPrflCargo.getReal_asset_house_resp();

            case HouseHoldDemoGraphicsConstants.REAL_ASET_LAND:
                return aRmcInPrflCargo.getReal_asset_land_resp();

            case HouseHoldDemoGraphicsConstants.REAL_ASET_MOBILE_HOME:
                return aRmcInPrflCargo.getReal_asset_mobile_home_resp();

            case HouseHoldDemoGraphicsConstants.REAL_ASET_OTHER:
                return aRmcInPrflCargo.getReal_asset_other_resp();
            case HouseHoldDemoGraphicsConstants.REAL_ASET_HOME:
                return aRmcInPrflCargo.getReal_asset_home_resp();
            case HouseHoldDemoGraphicsConstants.REAL_ASET_LIFE_ESTATE:
                return aRmcInPrflCargo.getReal_asset_life_estate_resp();
            case HouseHoldDemoGraphicsConstants.REAL_ASET_UNOCCUPY_HOME:
                return aRmcInPrflCargo.getReal_asset_unoccupy_home_resp();
            case HouseHoldDemoGraphicsConstants.REAL_ASET_VAC:
                return aRmcInPrflCargo.getReal_aset_vac_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_ANIMAL_DRAWN:
                return aRmcInPrflCargo.getVehicle_asset_animal_drwn_resp();
            case HouseHoldDemoGraphicsConstants.VEH_ASET_NONMOTORIZED_CAMPER:
                return aRmcInPrflCargo.getVehicle_asset_nmot_camper_resp();
            case HouseHoldDemoGraphicsConstants.VEH_ASET_GOLFCART:
                return aRmcInPrflCargo.getVehicle_asset_golf_cart_resp();
            case HouseHoldDemoGraphicsConstants.VEH_ASET_TRACTOR:
                return aRmcInPrflCargo.getVehicle_asset_tractor_resp();
            case HouseHoldDemoGraphicsConstants.VEH_ASET_AIRPLANE:
                return aRmcInPrflCargo.getVeh_aset_arpl_resp();
            case HouseHoldDemoGraphicsConstants.VEH_ASET_UNLIC:
                return aRmcInPrflCargo.getVeh_aset_unlic_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_AUTOMOBILE:
                return aRmcInPrflCargo.getVehicle_asset_auto_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_BOAT:
                return aRmcInPrflCargo.getVehicle_asset_boat_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_BUS:
                return aRmcInPrflCargo.getVeh_aset_bus_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_CAMPER:
                return aRmcInPrflCargo.getVehicle_asset_camper_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_FARM_IMPLEMENT:
                return aRmcInPrflCargo.getVeh_aset_fimp_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_FARM_EQUIP:
                return aRmcInPrflCargo.getVeh_aset_fmeq_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_FARM_TRACTOR:
                return aRmcInPrflCargo.getVeh_aset_ftrc_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_FARM_TRAILER:
                return aRmcInPrflCargo.getVeh_aset_ftrl_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_LOG_SKIDDER:
                return aRmcInPrflCargo.getVeh_aset_lskd_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_MOTORCYCLE:
                return aRmcInPrflCargo.getVehicle_asset_motorcycle_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_NONMOTORIZED_BOAT:
                return aRmcInPrflCargo.getVeh_aset_nm_b_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_OTHER:
                return aRmcInPrflCargo.getVeh_aset_othr_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_RECREATIONAL_VEHICLE:
                return aRmcInPrflCargo.getVehicle_asset_recreation_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_SNOWMOBILE:
                return aRmcInPrflCargo.getVeh_aset_s_mb_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_TRUCK:
                return aRmcInPrflCargo.getVeh_aset_trk_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_TRAVEL_TRAILER:
                return aRmcInPrflCargo.getVeh_aset_trlr_resp();

            case HouseHoldDemoGraphicsConstants.VEH_ASET_VAN:
                return aRmcInPrflCargo.getVeh_aset_van_resp();

            case HouseHoldDemoGraphicsConstants.INDV_CC_RQST_IND:
                return aRmcInPrflCargo.getIndv_cc_rqst_ind();

            case HouseHoldDemoGraphicsConstants.INDV_TANF_RQST_IND:
                return aRmcInPrflCargo.getIndv_tanf_rqst_ind();

            case HouseHoldDemoGraphicsConstants.INDV_WIC_RQST_IND:
                return aRmcInPrflCargo.getIndv_wic_rqst_ind();

            case HouseHoldDemoGraphicsConstants.SCHL_ENRL_RESP:
                return aRmcInPrflCargo.getSchool_enrollment_resp();
            case HouseHoldDemoGraphicsConstants.TRB_CMDY_RESP:
                return aRmcInPrflCargo.getTrb_cmdy_resp();
            case HouseHoldDemoGraphicsConstants.CP_WLST_RESP:
                return aRmcInPrflCargo.getCp_wlst_resp();
            case HouseHoldDemoGraphicsConstants.INDIVIDUAL_CLA:
                return aRmcInPrflCargo.getIndv_cla_ind();
            case HouseHoldDemoGraphicsConstants.HEAD_OF_HOUSE:
                return aRmcInPrflCargo.getHead_of_household_resp();
            case HouseHoldDemoGraphicsConstants.STUDENT_FINANCIAL_AID:
                return aRmcInPrflCargo.getStudent_financial_aid_resp();
            case HouseHoldDemoGraphicsConstants.BLACK_LUNG_BENEFIT:
                return aRmcInPrflCargo.getBenefit_black_lung_resp();
            case HouseHoldDemoGraphicsConstants.CASH_GIFTS_CONT:
                return aRmcInPrflCargo.getCash_gifts_resp();
            case HouseHoldDemoGraphicsConstants.FOOD_CLOTHING_UTIL_RENT:
                return aRmcInPrflCargo.getFood_clothing_util_rent_resp();
            case HouseHoldDemoGraphicsConstants.INHERITANCE:
                return aRmcInPrflCargo.getInheritance_resp();
            case HouseHoldDemoGraphicsConstants.INSURANCE_SETTLEMENT:
                return aRmcInPrflCargo.getInsurance_settlement_resp();
            case HouseHoldDemoGraphicsConstants.LOAN:
                return aRmcInPrflCargo.getLoan_resp();
            case HouseHoldDemoGraphicsConstants.LOTTERY_PRIZE_WINNING:
                return aRmcInPrflCargo.getLottery_prize_winning_resp();
            case HouseHoldDemoGraphicsConstants.STRIKE_BENEFITS_RESP:
                return aRmcInPrflCargo.getBenefits_on_strike_resp();
            case HouseHoldDemoGraphicsConstants.TRAINING_ALLOWANCE:
                return aRmcInPrflCargo.getTraining_allowance_resp();
            case HouseHoldDemoGraphicsConstants.OTHR_SOCIAL_SECURITY_BENEFITS:
                return aRmcInPrflCargo.getOthr_social_security_bnft_resp();
            case HouseHoldDemoGraphicsConstants.RESETTL_INC_RESP:
                return aRmcInPrflCargo.getResettl_inc_resp();
            case HouseHoldDemoGraphicsConstants.OTHR_INCM_RENTL_RESP:
                return aRmcInPrflCargo.getOthr_incm_rentl_resp();
            case HouseHoldDemoGraphicsConstants.LAND_CONT_RESP:
                return aRmcInPrflCargo.getLand_cont_resp();
            case HouseHoldDemoGraphicsConstants.HOUSING_BILLS_OTHERS:
                return aRmcInPrflCargo.getHousing_bill_others_resp();
            case HouseHoldDemoGraphicsConstants.UTILITY_BILLS_OIL:
                return aRmcInPrflCargo.getUtility_bills_oil_resp();

                //TODO: Removed few case blocks here, Currently using only which are required for the flow.

            case HouseHoldDemoGraphicsConstants.OTHR_INCM_CONTRIB_RESP:
                return aRmcInPrflCargo.getOther_incm_contrib_resp();
            case HouseHoldDemoGraphicsConstants.OTHR_INCM_TRBL_RESP:
                return aRmcInPrflCargo.getOthr_incm_trbl_resp();
            case HouseHoldDemoGraphicsConstants.HOSPITAL_STAY_RESP:
                return aRmcInPrflCargo.getHospital_stay_resp();
            case HouseHoldDemoGraphicsConstants.CHILD_CARE_RESP:
                return aRmcInPrflCargo.getChild_care_resp();
            case HouseHoldDemoGraphicsConstants.CHILD_OBLIGATION_RESP:
                return aRmcInPrflCargo.getChild_obligation_resp();
            case HouseHoldDemoGraphicsConstants.MEDICAL_BILLS_RESP:
                return aRmcInPrflCargo.getMedical_bills_resp();
            case HouseHoldDemoGraphicsConstants.MEDTYP_DENTAL:
                return aRmcInPrflCargo.getMedtyp_dental();
            case HouseHoldDemoGraphicsConstants.MEDTYP_ATTENDANT_CARE:
                return aRmcInPrflCargo.getMedtyp_attendant_care();
            case HouseHoldDemoGraphicsConstants.MEDTYP_DOCTOR:
                return aRmcInPrflCargo.getMedtyp_doctor();
            case HouseHoldDemoGraphicsConstants.MEDTYP_MED_EQUIP:
                return aRmcInPrflCargo.getMedtyp_med_equip();
            case HouseHoldDemoGraphicsConstants.MEDTYP_HOSP_BILLS:
                return aRmcInPrflCargo.getMedtyp_hosp_bills();
            case HouseHoldDemoGraphicsConstants.MEDTYP_INSUR_PREMIUM:
                return aRmcInPrflCargo.getMedtyp_insur_premium();
            case HouseHoldDemoGraphicsConstants.MEDTYP_RX_COST:
                return aRmcInPrflCargo.getMedtyp_rx_cost();
            case HouseHoldDemoGraphicsConstants.MEDTYP_TRANS_MED:
                return aRmcInPrflCargo.getMedtyp_trans_med();
            case HouseHoldDemoGraphicsConstants.MEDTYP_OTHER:
                return aRmcInPrflCargo.getMedtyp_other();
            case HouseHoldDemoGraphicsConstants.UNPAID_MEDBILL:
                return aRmcInPrflCargo.getUnpaid_medbill();
            case HouseHoldDemoGraphicsConstants.MEDTYP_HSA_CONTRIB:
                return aRmcInPrflCargo.getMedtyp_hsa_contrib();
            case HouseHoldDemoGraphicsConstants.UEI_ADOPTION_ASSIST:
                return aRmcInPrflCargo.getAdoptAssistance();
            case HouseHoldDemoGraphicsConstants.UEI_ADOPTION_PYMT:
                return aRmcInPrflCargo.getAdoptionPayments();
            case HouseHoldDemoGraphicsConstants.UEI_AGENT_ORNG_PYMT:
                return aRmcInPrflCargo.getAgentOrangePayments();
            case HouseHoldDemoGraphicsConstants.UEI_ALIMONY:
                return aRmcInPrflCargo.getAlimony();
            case HouseHoldDemoGraphicsConstants.UEI_CAPITAL_GAINS:
                return aRmcInPrflCargo.getCapitalGains();
            case HouseHoldDemoGraphicsConstants.UEI_DEATH_BNFT:
                return aRmcInPrflCargo.getDeathBenefits();
            case HouseHoldDemoGraphicsConstants.UEI_DABL_INCM:
                return aRmcInPrflCargo.getDisabilityIncome();
            case HouseHoldDemoGraphicsConstants.UEI_DR_RELIEF:
                return aRmcInPrflCargo.getDisasterRelief();
            case HouseHoldDemoGraphicsConstants.UEI_EDU_ASSIST:
                return aRmcInPrflCargo.getEducationalAssistance();
            case HouseHoldDemoGraphicsConstants.UEI_ENERGY_ASSIST:
                return aRmcInPrflCargo.getEnergyAssistance();
            case HouseHoldDemoGraphicsConstants.UEI_FRM_ALOT:
                return aRmcInPrflCargo.getFarmAllotment();
            case HouseHoldDemoGraphicsConstants.UEI_FOSTER_CARE_PYMT:
                return aRmcInPrflCargo.getFosterCarePayments();
            case HouseHoldDemoGraphicsConstants.UEI_GEN_ASSIST:
                return aRmcInPrflCargo.getGeneralAssistance();
            case HouseHoldDemoGraphicsConstants.UEI_INT_DIV_PYMT:
                return aRmcInPrflCargo.getInterestDividendPayments();
            case HouseHoldDemoGraphicsConstants.UEI_IRA_DIST:
                return aRmcInPrflCargo.getiRADistribution();
            case HouseHoldDemoGraphicsConstants.UEI_LOTTERY_WIN:
                return aRmcInPrflCargo.getLotteryWinnings();
            case HouseHoldDemoGraphicsConstants.UEI_LUMP_SUM:
                return aRmcInPrflCargo.getLumpSum();
            case HouseHoldDemoGraphicsConstants.UEI_MIL_ALOT:
                return aRmcInPrflCargo.getMilitaryAllotment();
            case HouseHoldDemoGraphicsConstants.UEI_MON_FRO_OTH:
                return aRmcInPrflCargo.getMoneyFromAnotherPerson();
            case HouseHoldDemoGraphicsConstants.UEI_NET_RENT_ROYALTY:
                return aRmcInPrflCargo.getNetRentalRoyalty();
            case HouseHoldDemoGraphicsConstants.UEI_OTH:
                return aRmcInPrflCargo.getOtherIncome();
            case HouseHoldDemoGraphicsConstants.UEI_ANNY_PYMT:
                return aRmcInPrflCargo.getPaymentsFromAnnuity();
            case HouseHoldDemoGraphicsConstants.UEI_PYMT_BO:
                return aRmcInPrflCargo.getPaymentsMadeOnYourBehalf();
            case HouseHoldDemoGraphicsConstants.UEI_PENSION:
                return aRmcInPrflCargo.getPensionOrRetirement();
            case HouseHoldDemoGraphicsConstants.UEI_RR_RETIRE:
                return aRmcInPrflCargo.getRailroadRetirement();
            case HouseHoldDemoGraphicsConstants.UEI_REFUGEE_CASH:
                return aRmcInPrflCargo.getRefugeeCash();
            case HouseHoldDemoGraphicsConstants.UEI_REL_CARE:
                return aRmcInPrflCargo.getRelativeCareSubsidy();
            case HouseHoldDemoGraphicsConstants.UEI_RENTAL_INCM:
                return aRmcInPrflCargo.getRentalIncome();
            case HouseHoldDemoGraphicsConstants.UEI_TANF_PYMT:
                return aRmcInPrflCargo.gettANFPayments();
            case HouseHoldDemoGraphicsConstants.UEI_UNEMPL:
                return aRmcInPrflCargo.getUnemploymentCompensation();
            case HouseHoldDemoGraphicsConstants.UEI_WORKER_STUDY:
                return aRmcInPrflCargo.getWorkStudyStateFederal();
            case HouseHoldDemoGraphicsConstants.UEI_WORKER_COMP:
                return aRmcInPrflCargo.getWorkersCompensation();
            case HouseHoldDemoGraphicsConstants.SPECIAL_NEED:
                return aRmcInPrflCargo.getSpecial_need_resp();
            case HouseHoldDemoGraphicsConstants.FOSTER_CARE_RESP:
                return aRmcInPrflCargo.getFoster_care_resp();
            case HouseHoldDemoGraphicsConstants.FORMER_FOSTER_RESP:
                return aRmcInPrflCargo.getFormer_foster_resp();
            case HouseHoldDemoGraphicsConstants.CHILD_PROTECTIVE_RESP:
                return aRmcInPrflCargo.getChild_protective_resp();
            case HouseHoldDemoGraphicsConstants.LIVING_PROG_RESP:
                return aRmcInPrflCargo.getLiving_prog_resp();
            case HouseHoldDemoGraphicsConstants.GRAND_PARENT_RESP:
                return aRmcInPrflCargo.getGrand_parent_resp();
            case HouseHoldDemoGraphicsConstants.DRUG_FELONIES_RESP:
                return aRmcInPrflCargo.getDrug_felonies_resp();
            case HouseHoldDemoGraphicsConstants.SNAP_TANF_DISC_RESP:
                return aRmcInPrflCargo.getSnap_tanf_disc_resp();
            case HouseHoldDemoGraphicsConstants.TANF_DISC_RESP:
                return aRmcInPrflCargo.getTanfDiscResp();
            case HouseHoldDemoGraphicsConstants.AVOID_PROSC_RESP:
                return aRmcInPrflCargo.getAvoid_prosc_resp();
            case HouseHoldDemoGraphicsConstants.AVD_PRSCTN_FSTF:
                return aRmcInPrflCargo.getAvd_prsctn_fstf();
            case HouseHoldDemoGraphicsConstants.VIOLATING_PAROLE_RESP:
                return aRmcInPrflCargo.getViolating_parole_resp();
            case HouseHoldDemoGraphicsConstants.CONVIC_FALSE_INFO_RESP:
                return aRmcInPrflCargo.getConvic_false_info_resp();
            case HouseHoldDemoGraphicsConstants.VOLUNTARILY_QUIT_JOB_RESP:
                return aRmcInPrflCargo.getVoluntarily_quit_job_resp();
            case HouseHoldDemoGraphicsConstants.TRADING_SNAP_RESP:
                return aRmcInPrflCargo.getTrading_snap_resp();
            case HouseHoldDemoGraphicsConstants.BUY_SELL_SNAP_RESP:
                return aRmcInPrflCargo.getBuy_sell_snap_resp();
            case HouseHoldDemoGraphicsConstants.TRADE_SNAP_GUN_RESP:
                return aRmcInPrflCargo.getTrade_snap_gun_resp();
            case HouseHoldDemoGraphicsConstants.PREV_SSI_RESP:
                return aRmcInPrflCargo.getPrev_ssi_resp();
            case HouseHoldDemoGraphicsConstants.HOME_COMMUNITY_RESP:
                return aRmcInPrflCargo.getHome_community_resp();
            case HouseHoldDemoGraphicsConstants.TRIBAL_HEALTH_RESP:
                return aRmcInPrflCargo.getTribal_health_resp();
            case HouseHoldDemoGraphicsConstants.TRIBAL_ELIGIBILITY_RESP:
                return aRmcInPrflCargo.getTribal_eligibility_resp();
            case HouseHoldDemoGraphicsConstants.DOMESTIC_VIOLENCE_RESP:
                return aRmcInPrflCargo.getDomestic_violence_resp();
            case HouseHoldDemoGraphicsConstants.TANF_EPPIC_RESP:
                return aRmcInPrflCargo.getTanf_eppic_resp();
            case HouseHoldDemoGraphicsConstants.EMERGENCY_MEDICAL_RESP:
                return aRmcInPrflCargo.getEmergency_medical_resp();

            case HouseHoldDemoGraphicsConstants.PERS_PROP_BUS_EQPT:
                return aRmcInPrflCargo.getPers_prop_bus_eqpt();
            case HouseHoldDemoGraphicsConstants.PERS_PROP_CEMETARY_LOT:
                return aRmcInPrflCargo.getPers_prop_cemetary_lot();
            case HouseHoldDemoGraphicsConstants.PERS_PROP_LIVESTOCK:
                return aRmcInPrflCargo.getPers_prop_livestock();
            case HouseHoldDemoGraphicsConstants.PERS_PROP_SAF_DEPST_BOX:
                return aRmcInPrflCargo.getPers_prop_saf_depst_box();
            case HouseHoldDemoGraphicsConstants.PERS_PROP_OTH_VAL:
                return aRmcInPrflCargo.getPers_prop_oth_val();
            case HouseHoldDemoGraphicsConstants.MOVED_OUT_OF_HOME_RESP:
                return aRmcInPrflCargo.getMoved_out_of_home_resp();
            case HouseHoldDemoGraphicsConstants.PRSN_INFO_STAT_SW:
                return aRmcInPrflCargo.getPersonal_info();
            case HouseHoldDemoGraphicsConstants.CITIZENSHIP_INFO:
                return aRmcInPrflCargo.getCitizenship_info();
            case HouseHoldDemoGraphicsConstants.RLT_CHG_STAT_SW:
                return aRmcInPrflCargo.getRlt_chg_stat_sw();
            case HouseHoldDemoGraphicsConstants.OUTSTATE_BNFTS:
                return aRmcInPrflCargo.getOutstate_bnft_resp();
            case HouseHoldDemoGraphicsConstants.HOUS_PICE:
                return aRmcInPrflCargo.getHospice_resp();

            case HouseHoldDemoGraphicsConstants.ABLE_TO_CONCEIVE_RESP:
                return aRmcInPrflCargo.getAble_to_conceive_resp();
            case HouseHoldDemoGraphicsConstants.UNDERWEIGHT_BIRTH_RESP:
                return aRmcInPrflCargo.getUnderweight_birth_resp();
            case HouseHoldDemoGraphicsConstants.PREG_ADD_STAT_SW:
                return aRmcInPrflCargo.getPreg_add_stat_sw();
            case HouseHoldDemoGraphicsConstants.PREG_CHG_STAT_SW:
                return aRmcInPrflCargo.getPreg_chg_stat_sw();

            case HouseHoldDemoGraphicsConstants.SU_CST_INS_RESP:
                return aRmcInPrflCargo.getSu_cst_ins_resp();
            case HouseHoldDemoGraphicsConstants.OTHER_HOUSING_BILL_RESP:
                return aRmcInPrflCargo.getOther_housing_bill_resp();
            case HouseHoldDemoGraphicsConstants.DISASTER_REPAIR_RESP:
                return aRmcInPrflCargo.getDisaster_repair_resp();
            case HouseHoldDemoGraphicsConstants.PREVENT_EVICTION_RESP:
                return aRmcInPrflCargo.getPrevent_eviction_resp();
            case HouseHoldDemoGraphicsConstants.CARE_TAKER_RESP:
                return aRmcInPrflCargo.getCareTaker_resp();
            case HouseHoldDemoGraphicsConstants.LOST_HEALTH_INS_IND:
                return aRmcInPrflCargo.getLost_health_ins_ind();
            case HouseHoldDemoGraphicsConstants.TAX_CLAIM_DEPENDENT:
                return aRmcInPrflCargo.getTax_claim_dependant_resp();

            case HouseHoldDemoGraphicsConstants.BEFORE_TAX_DEDUCTION:
                return aRmcInPrflCargo.getBefore_tax_deduction_resp();

            case HouseHoldDemoGraphicsConstants.BTD_MED_INS:
                return aRmcInPrflCargo.getBtd_med_ins();

            case HouseHoldDemoGraphicsConstants.BTD_DENT_INS:
                return aRmcInPrflCargo.getBtd_dent_ins();

            case HouseHoldDemoGraphicsConstants.BTD_VIS_CARE_INS:
                return aRmcInPrflCargo.getBtd_vis_care_ins();

            case HouseHoldDemoGraphicsConstants.BTD_FLEX_ACC:
                return aRmcInPrflCargo.getBtd_flex_acc();

            case HouseHoldDemoGraphicsConstants.BTD_DEF_COMP:
                return aRmcInPrflCargo.getBtd_def_comp();

            case HouseHoldDemoGraphicsConstants.BTD_PRE_TAX_INS:
                return aRmcInPrflCargo.getBtd_pre_tax_ins();

            case HouseHoldDemoGraphicsConstants.BTD_OTHER:
                return aRmcInPrflCargo.getBtd_other();

            case HouseHoldDemoGraphicsConstants.TAX_DEDUCT_RESP:
                return aRmcInPrflCargo.getTax_deduct_resp();
            case HouseHoldDemoGraphicsConstants.HLTH_INS_RESP:
                return aRmcInPrflCargo.getHlth_ins_resp();
            case HouseHoldDemoGraphicsConstants.OTHR_HLTH_INS_RESP:
                return aRmcInPrflCargo.getOthr_hlth_ins_resp();

            //add and change indicator

            case HouseHoldDemoGraphicsConstants.ROOM_BRD_CHG_IND:
                return aRmcInPrflCargo.getRoom_brd_chg_ind();
            case HouseHoldDemoGraphicsConstants.DABL_STAT_IND:
                return aRmcInPrflCargo.getDabl_stat_ind();
            case HouseHoldDemoGraphicsConstants.PREG_ADD_STAT_IND:
                return aRmcInPrflCargo.getPreg_add_stat_ind();
            case HouseHoldDemoGraphicsConstants.PREG_CHG_IND:
                return aRmcInPrflCargo.getPreg_chg_ind();
            case HouseHoldDemoGraphicsConstants.IRWE_CHG_IND:
                return aRmcInPrflCargo.getIrwe_chg_ind();
            case HouseHoldDemoGraphicsConstants.EI_CHG_IND:
                return aRmcInPrflCargo.getEi_chg_ind();
            case HouseHoldDemoGraphicsConstants.SELF_EMPL_CHG_IND:
                return aRmcInPrflCargo.getSelf_empl_chg_ind();
            case HouseHoldDemoGraphicsConstants.OTHR_INCM_CHG_IND:
                return aRmcInPrflCargo.getOthr_incm_chg_ind();
            case HouseHoldDemoGraphicsConstants.EMPL_CHG_IND:
                return aRmcInPrflCargo.getEmpl_chg_ind();
            case HouseHoldDemoGraphicsConstants.VEH_ASET_ADD_IND:
                return aRmcInPrflCargo.getVeh_aset_add_ind();
            case HouseHoldDemoGraphicsConstants.VEH_ASET_CHG_IND:
                return aRmcInPrflCargo.getVeh_aset_chg_ind();
            case HouseHoldDemoGraphicsConstants.REAL_ASET_ADD_IND:
                return aRmcInPrflCargo.getReal_aset_add_ind();
            case HouseHoldDemoGraphicsConstants.REAL_ASET_CHG_IND:
                return aRmcInPrflCargo.getReal_aset_chg_ind();
            case HouseHoldDemoGraphicsConstants.BURY_ASET_ADD_IND:
                return aRmcInPrflCargo.getBury_aset_add_ind();
            case HouseHoldDemoGraphicsConstants.BURY_ASET_CHG_IND:
                return aRmcInPrflCargo.getBury_aset_chg_ind();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_ADD_IND:
                return aRmcInPrflCargo.getLiquid_asset_add_ind();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_BANK_ACC_CHG_IND:
                return aRmcInPrflCargo.getLiquid_asset_bank_acc_chg_ind();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_CASH_CHG_IND:
                return aRmcInPrflCargo.getLiquid_asset_cash_chg_ind();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_CHG_IND:
                return aRmcInPrflCargo.getLiquid_asset_chg_ind();
            case HouseHoldDemoGraphicsConstants.LIQUID_ASSET_OTHER_CHG_IND:
                return aRmcInPrflCargo.getLiquid_asset_other_chg_ind();
            case HouseHoldDemoGraphicsConstants.LIFE_INS_ASET_ADD_IND:
                return aRmcInPrflCargo.getLife_ins_aset_add_ind();
            case HouseHoldDemoGraphicsConstants.LIFE_INS_ASET_CHG_IND:
                return aRmcInPrflCargo.getLife_ins_aset_chg_ind();
            case HouseHoldDemoGraphicsConstants.ASET_XFER_CHG_IND:
                return aRmcInPrflCargo.getAset_xfer_chg_ind();
            case HouseHoldDemoGraphicsConstants.DPND_CARE_CHG_IND:
                return aRmcInPrflCargo.getDpnd_care_chg_ind();
            case HouseHoldDemoGraphicsConstants.HEALTH_INSURANCE_CHG_IND:
                return aRmcInPrflCargo.getHealth_insurance_chg_ind();
            case HouseHoldDemoGraphicsConstants.OUT_ST_BNFT_CHG_IND:
                return aRmcInPrflCargo.getOut_st_bnft_chg_ind();
            case HouseHoldDemoGraphicsConstants.SCHL_ENRL_CHG_IND:
                return aRmcInPrflCargo.getSchl_enrl_chg_ind();
            case HouseHoldDemoGraphicsConstants.MRTL_STAT_CHG_IND:
                return aRmcInPrflCargo.getMrtl_stat_chg_ind();
            case HouseHoldDemoGraphicsConstants.NUR_HME_CHG_IND:
                return aRmcInPrflCargo.getNur_hme_chg_ind();
            case HouseHoldDemoGraphicsConstants.BFR_TAX_CHG_IND:
                return aRmcInPrflCargo.getBfr_tax_chg_ind();
            case HouseHoldDemoGraphicsConstants.INC_TAX_CHG_IND:
                return aRmcInPrflCargo.getInc_tax_chg_ind();
            case HouseHoldDemoGraphicsConstants.THRD_PRTY_CHG_IND:
                return aRmcInPrflCargo.getThrd_prty_chg_ind();
            case HouseHoldDemoGraphicsConstants.CHILD_SUPPORT_PAYMENT_CHG_IND:
                return aRmcInPrflCargo.getChild_support_payment_chg_ind();
            case HouseHoldDemoGraphicsConstants.SNAP_SHELTER_STANDARD_EXP_IND:
                return aRmcInPrflCargo.getSnap_shelter_standard_exp_ind();
            case HouseHoldDemoGraphicsConstants.HOUS_BILL_CHG_IND:
                return aRmcInPrflCargo.getHous_bill_chg_ind();
            case HouseHoldDemoGraphicsConstants.ADD_CHG_IND:
                return aRmcInPrflCargo.getAdd_chg_ind();
            case HouseHoldDemoGraphicsConstants.PERSON_MOVED_IN_STAT_IND:
                return aRmcInPrflCargo.getPerson_moved_in_stat_ind();
            case HouseHoldDemoGraphicsConstants.PERSON_MOVED_OUT_STAT_IND:
                return aRmcInPrflCargo.getPerson_moved_out_stat_ind();
            case HouseHoldDemoGraphicsConstants.HOSPICE_CHG_IND:
                return aRmcInPrflCargo.getHospice_chg_ind();
            case HouseHoldDemoGraphicsConstants.MEDICARE_CHG_IND:
                return aRmcInPrflCargo.getMedicare_chg_ind();
            case HouseHoldDemoGraphicsConstants.NCP_CHG_IND:
                return aRmcInPrflCargo.getNcp_chg_ind();
            case HouseHoldDemoGraphicsConstants.THIRD_PARTY_CHG_IND:
                return aRmcInPrflCargo.getThird_party_chg_ind();
            case HouseHoldDemoGraphicsConstants.HOSPITAL_ABD_CHG_IND:
                return aRmcInPrflCargo.getHospital_abd_chg_ind();
            case HouseHoldDemoGraphicsConstants.PUBLIC_LAW_ABD_CHG_IND:
                return aRmcInPrflCargo.getPublic_law_abd_chg_ind();
            case HouseHoldDemoGraphicsConstants.LIVING_ARGMT_CHG_IND:
                return aRmcInPrflCargo.getLiving_argmt_chg_ind();
            case HouseHoldDemoGraphicsConstants.OTHER_PROGRAM_CHG_IND:
                return aRmcInPrflCargo.getOther_program_chg_ind();
            case HouseHoldDemoGraphicsConstants.MAGI_EXPENSE_CHG_IND:
                return aRmcInPrflCargo.getMagi_expense_chg_ind();
            case HouseHoldDemoGraphicsConstants.TAX_INFO_IND:
                return aRmcInPrflCargo.getTax_info_ind();
            case HouseHoldDemoGraphicsConstants.TAX_DEPENDENT_IND:
                return aRmcInPrflCargo.getTax_dep_outside_resp();

            case HouseHoldDemoGraphicsConstants.MEDICARE_PART_A:
                return aRmcInPrflCargo.getMedicare_part_a();
            case HouseHoldDemoGraphicsConstants.MEDICARE_PART_B:
                return aRmcInPrflCargo.getMedicare_part_b();
            case HouseHoldDemoGraphicsConstants.MEDICARE_PART_C:
                return aRmcInPrflCargo.getMedicare_part_c();
            case HouseHoldDemoGraphicsConstants.MEDICARE_PART_D:
                return aRmcInPrflCargo.getMedicare_part_d();
            case HouseHoldDemoGraphicsConstants.CCSP_PROVIDER_PAYMENT:
                return aRmcInPrflCargo.getCssp_provider_payment();
            case HouseHoldDemoGraphicsConstants.ANIMALS_TO_ASSIST_DISABLED:
                return aRmcInPrflCargo.getAnimals_to_assist_disabled();
            case HouseHoldDemoGraphicsConstants.FUNERAL_DEATH_EXPENSE:
                return aRmcInPrflCargo.getFuneral_death_expense();
            case HouseHoldDemoGraphicsConstants.BLIND_WORK_EXPENSE:
                return aRmcInPrflCargo.getBlind_work_expense();
            case HouseHoldDemoGraphicsConstants.IMPAIRMENT_WORK_EXPENSE:
                return aRmcInPrflCargo.getImpairment_work_expense();
            case HouseHoldDemoGraphicsConstants.OTH_IND_GAMBL_PMNTS:
                return aRmcInPrflCargo.getOth_ind_gambl_pmnts();
            case HouseHoldDemoGraphicsConstants.BONDS:
                return aRmcInPrflCargo.getBonds();
            case HouseHoldDemoGraphicsConstants.DIVIDEND:
                return aRmcInPrflCargo.getDividend();
            case HouseHoldDemoGraphicsConstants.HEALTH_REIMBURSEMENT_ACCOUNT:
                return aRmcInPrflCargo.getHealth_reimbursement_account();
            case HouseHoldDemoGraphicsConstants.INDIVIDUAL_DEVELOPMENT_ACCOUNT:
                return aRmcInPrflCargo.getIndividual_development_account();
            case HouseHoldDemoGraphicsConstants.UNIFORM_GIFTS_TO_MINORS:
                return aRmcInPrflCargo.getUniform_gifts_to_minors();

            case HouseHoldDemoGraphicsConstants.INCOME_FROM_RESOURCE:
                return aRmcInPrflCargo.getIncome_from_resource();
            case HouseHoldDemoGraphicsConstants.INDIAN_GAMBLING_PAYMENTS:
                return aRmcInPrflCargo.getIndian_gambling_payments();
            case HouseHoldDemoGraphicsConstants.INHERITANCE_INCOME:
                return aRmcInPrflCargo.getInheritance_income();
            case HouseHoldDemoGraphicsConstants.INSUANCE_BENEFITS:
                return aRmcInPrflCargo.getInsuance_benefits();
            case HouseHoldDemoGraphicsConstants.LOAN_RECEIVED:
                return aRmcInPrflCargo.getLoan_received();
            case HouseHoldDemoGraphicsConstants.LOAN_REPAYMENT_INCOME:
                return aRmcInPrflCargo.getLoan_repayment_income();
            case HouseHoldDemoGraphicsConstants.MANAGED_INCOME:
                return aRmcInPrflCargo.getManaged_income();
            case HouseHoldDemoGraphicsConstants.MATCH_GRANT:
                return aRmcInPrflCargo.getMatch_grant();
            case HouseHoldDemoGraphicsConstants.MONTGOMERY_GI_BILL:
                return aRmcInPrflCargo.getMontgomery_gi_bill();
            case HouseHoldDemoGraphicsConstants.OUT_OF_STATE_PUBLIC:
                return aRmcInPrflCargo.getOut_of_state_public();

            case HouseHoldDemoGraphicsConstants.REFUNDS_FROM_DCH:
                return aRmcInPrflCargo.getRefunds_from_dch();
            case HouseHoldDemoGraphicsConstants.RESTITUTIONS_SETTLEMENTS:
                return aRmcInPrflCargo.getRestitutions_settlements();
            case HouseHoldDemoGraphicsConstants.SENIOR_COMPANION:
                return aRmcInPrflCargo.getSenior_companion();
            case HouseHoldDemoGraphicsConstants.SEVERANCE_PAY:
                return aRmcInPrflCargo.getSeverance_pay();
            case HouseHoldDemoGraphicsConstants.STRIKE_BENEFITS:
                return aRmcInPrflCargo.getStrike_benefits();
            case HouseHoldDemoGraphicsConstants.TRADE_READJUSTMENT:
                return aRmcInPrflCargo.getTrade_readjustment();
            case HouseHoldDemoGraphicsConstants.UNIFORM_RELOCATION:
                return aRmcInPrflCargo.getUniform_relocation();
            case HouseHoldDemoGraphicsConstants.UNION_FUNDS:
                return aRmcInPrflCargo.getUnion_funds();
            case HouseHoldDemoGraphicsConstants.VENDOR_EXCLUDED:
                return aRmcInPrflCargo.getVendor_excluded();
            case HouseHoldDemoGraphicsConstants.VICTIM_RESTITUTION:
                return aRmcInPrflCargo.getVictim_restitution();

            case HouseHoldDemoGraphicsConstants.VOLUNTEER_PAYMENT:
                return aRmcInPrflCargo.getVolunteer_payment();
            case HouseHoldDemoGraphicsConstants.VOLUNTEER_PAYMENT_TITLEI:
                return aRmcInPrflCargo.getVolunteer_payment_titlei();
            case HouseHoldDemoGraphicsConstants.WIA_TRAINING_AND_ALLOWANCE:
                return aRmcInPrflCargo.getWia_training_and_allowance();
            case HouseHoldDemoGraphicsConstants.INCLUDED_UNEARNED_INCOME:
                return aRmcInPrflCargo.getIncluded_unearned_income();
            case HouseHoldDemoGraphicsConstants.TANF_MAX_AU_ALLOTMENT:
                return aRmcInPrflCargo.getTanf_max_au_allotment();
            case HouseHoldDemoGraphicsConstants.TANF_MAX_GRG_ALLOTMENT:
                return aRmcInPrflCargo.getTanf_max_grg_allotment();
            case HouseHoldDemoGraphicsConstants.CHARITABLE_DONATION:
                return aRmcInPrflCargo.getCharitable_donation();
            case HouseHoldDemoGraphicsConstants.CHILD_NUTRITION_PAYMENTS:
                return aRmcInPrflCargo.getChild_nutrition_payments();
            case HouseHoldDemoGraphicsConstants.BLACK_LUNG_BENEFITS:
                return aRmcInPrflCargo.getBlack_lung_benefits();
            case HouseHoldDemoGraphicsConstants.CHILD_SUPPORT_COURT:
                return aRmcInPrflCargo.getChild_support_court();

            case HouseHoldDemoGraphicsConstants.CHILD_SUPPORT_GAP_PAYMENT:
                return aRmcInPrflCargo.getChild_support_gap_payment();
            case HouseHoldDemoGraphicsConstants.CIVIL_SERVICE:
                return aRmcInPrflCargo.getCivil_service();
            case HouseHoldDemoGraphicsConstants.DEFERRED_COMPENSATION_PLANS:
                return aRmcInPrflCargo.getDeferred_compensation_plans();
            case HouseHoldDemoGraphicsConstants.DISABILITY_INSURANCE:
                return aRmcInPrflCargo.getDisability_insurance();
            case HouseHoldDemoGraphicsConstants.EXCLUDED_UNEARNED_INCOME:
                return aRmcInPrflCargo.getExcluded_unearned_income();
            case HouseHoldDemoGraphicsConstants.FEMA_PAYMENT_DISASTER:
                return aRmcInPrflCargo.getFema_payment_disaster();
            case HouseHoldDemoGraphicsConstants.FEMA_PAYMENT_NON_DISASTER:
                return aRmcInPrflCargo.getFema_payment_non_disaster();
            case HouseHoldDemoGraphicsConstants.HEALTH_SAVINGS_ACCOUNT:
                return aRmcInPrflCargo.getHealth_savings_account();
            case HouseHoldDemoGraphicsConstants.IN_KIND_SUPPORT:
                return aRmcInPrflCargo.getIn_kind_support();
            case HouseHoldDemoGraphicsConstants.FOSTER_GRANDPARENT_PROGRAM:
                return aRmcInPrflCargo.getFoster_grandparent_program();

            case HouseHoldDemoGraphicsConstants.DISASTER_UNEMPLOYMENT:
                return aRmcInPrflCargo.getDisaster_unemployment();
            case HouseHoldDemoGraphicsConstants.DIVIDENDS:
                return aRmcInPrflCargo.getDividends();
            case HouseHoldDemoGraphicsConstants.CHARITABLE_DONATION_FEDERAL:
                return aRmcInPrflCargo.getCharitable_donation_federal();
            case HouseHoldDemoGraphicsConstants.PERSONAL_INFO:
                return aRmcInPrflCargo.getPersonal_info();
            case HouseHoldDemoGraphicsConstants.PATIENT_FUND:
                return aRmcInPrflCargo.getPatient_fund();

            case HouseHoldDemoGraphicsConstants.DISASTER_ASSISTANCE:
                return aRmcInPrflCargo.getDisaster_assistance();
            case HouseHoldDemoGraphicsConstants.NON_BUSINESS_EQUIPMENT:
                return aRmcInPrflCargo.getNon_business_equipment();
            case HouseHoldDemoGraphicsConstants.HOUSEHOLD_GOODS:
                return aRmcInPrflCargo.getHousehold_goods();
            case HouseHoldDemoGraphicsConstants.OTHER_NON_COUNTABLE:
                return aRmcInPrflCargo.getOther_non_countable();

            case HouseHoldDemoGraphicsConstants.LIQ_ASET_CHECKING_ACCOUNT:
                return aRmcInPrflCargo.getLqd_aset_c_a_resp();
            case HouseHoldDemoGraphicsConstants.LIQ_ASET_KEOUGH_PLAN:
                return aRmcInPrflCargo.getLqd_aset_k_p_resp();
            case HouseHoldDemoGraphicsConstants.DEATH_BENEFIT_STATE_FEDERAL:
                return aRmcInPrflCargo.getDeath_benefit_state_federal();
            case HouseHoldDemoGraphicsConstants.SOCIAL_SECURITY_SURVIVOR:
                return aRmcInPrflCargo.getSocial_security_survivor();
            case HouseHoldDemoGraphicsConstants.VENDOR_PAYMENTS:
                return aRmcInPrflCargo.getVendor_payments();
            case HouseHoldDemoGraphicsConstants.INDV_PRGM_CHG_IND:
                return aRmcInPrflCargo.getIndv_prgm_chg_ind();
            case HouseHoldDemoGraphicsConstants.EMPL_HLTH_INS_RESP:
                return aRmcInPrflCargo.getEmpl_hlth_ins_resp();
            case HouseHoldDemoGraphicsConstants.KATIE_BECKETT:
                return aRmcInPrflCargo.getMed_type_katie_beckett();

            default:
                logger.info("RMCResponseProfileManager.getProfileResponse() - Raising FwException manually on a condition");
                final FwException fe = new FwException("Incorrect field id : " + aFieldId + " passed.");
                fe.setClassID(this.getClass().getName());
                fe.setMethodID("getProfileResponse");
                fe.setExceptionType(FwConstants.EXP_TYP_APPLICATION);
                fe.setExceptionText("Incorrect field id : " + aFieldId + " passed.");
                throw fe;
        }
    }

    public void translateProfileResponses(final String responseFromPage, final String responseFromSession, final int currentPageStatus,
                                          final short responseId, final RMC_IN_PRFL_Cargo sessionAppInPrflCargo) {
        translateProfileResponsesForType(responseFromPage, responseFromSession, currentPageStatus, responseId, sessionAppInPrflCargo,
                HouseHoldDemoGraphicsConstants.NO_RESPONSE);
    }

    public void translateProfileResponsesForType(String responseFromPage, final String responseFromSession, final int currentPageStatus,final short responseId, final RMC_IN_PRFL_Cargo sessionAppInPrflCargo, final short parentPageResponseId) {
        try {
            if ((responseFromPage == null)
                    || "null".equals(responseFromPage)) {
                responseFromPage = "N";
            }

            if (null != responseFromPage
                    && responseFromPage.charAt(0) == HouseHoldDemoGraphicsConstants.RESPONSE_YES) {
                // if response from the session is complete
                if (null != responseFromSession
                        && responseFromSession.charAt(0) == HouseHoldDemoGraphicsConstants.STATUS_COMPLETE) {
                    // if currernt page status is visit again
                    if (!(currentPageStatus == FwConstants.DRIVER_VISIT_AGAIN)) {
                    	return;
                    } 
                } else {


                    // if this method is calling type page
                    // basically i am checking for the null.
                    if (parentPageResponseId != HouseHoldDemoGraphicsConstants.NO_RESPONSE) {
                        ////TODO: CalSAWS – Service Migration: Commenting out profiler code for <Household-storeMovedOut> Driver service
                    }
                }
            } else if (null != responseFromPage
                    &&	responseFromPage.charAt(0) == HouseHoldDemoGraphicsConstants.RESPONSE_NO) {
                if (null != responseFromSession
                        && responseFromSession.charAt(0) == HouseHoldDemoGraphicsConstants.STATUS_REQUIRED) {
                    ////TODO: CalSAWS – Service Migration: Commenting out profiler code for <Household-storeMovedOut> Driver service
                } else {
                    return;
                }
            } else {
                logger.info("RMCResponseProfileManager.translateProfileResponsesForType() - Raising FwException manually on a condition");
                final FwException fe = new FwException("Incorrect Response From The Page : " + responseFromPage + " passed.");
                fe.setClassID(this.getClass().getName());
                fe.setMethodID("translateProfileResponsesForType");
                fe.setExceptionType(FwConstants.EXP_TYP_APPLICATION);
                fe.setExceptionText("Incorrect Response From The Page : " + responseFromPage + " passed.");
                throw fe;
            }
        } catch (Exception exception){
            throw exception;
        }
    }

    /**
     * Persist Moved Out details of  {@link RMC_IN_PRFL_Cargo} into {@link CP_RMC_IN_PRFL_Cargo}
     * @param tAppNum
     * @param indv_seq_num
     * @param questionsArrayForIndv
     * @param strings
     */
    public void persistMovedOutDetails(String appNum, String indv_seq_num, String questionsArrayForIndv, String[] strings) {
        logger.debug("Persisting moved out details : currentThread  " + Thread.currentThread() + " appNum:" + appNum + " indv_seq_num: " + indv_seq_num );
        Optional<CP_RMC_IN_PRFL_Cargo> dbCargoResponse = rmcProfileRepo.findByAppNumAndIndvSeqNum(appNum,indv_seq_num);
        if(dbCargoResponse.isPresent()){
            logger.info("RMCResponseProfileManager::persistMovedOutDetails - dbCargoResponse"+dbCargoResponse);
            CP_RMC_IN_PRFL_Cargo rmc_in_prfl_cargo = dbCargoResponse.get();
            rmc_in_prfl_cargo.setMovedOutOfHomeResp(questionsArrayForIndv);
            rmcProfileRepo.save(rmc_in_prfl_cargo);
        }
    }

    public void makeComplete(short movedOutOfHomeResp, RMC_IN_PRFL_Cargo rmcResCargo, boolean b) {
    }
}
