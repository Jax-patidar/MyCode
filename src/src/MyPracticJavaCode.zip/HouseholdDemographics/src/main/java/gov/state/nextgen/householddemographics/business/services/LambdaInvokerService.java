package gov.state.nextgen.householddemographics.business.services;

import org.springframework.http.HttpEntity;

import com.fasterxml.jackson.core.JsonProcessingException;

import gov.state.nextgen.access.business.entities.FwTransaction;

public interface LambdaInvokerService {

	public String invokeLambda(String url, HttpEntity<FwTransaction> httpentity, String path) throws Exception;
	public String invokeDataExchangeLambda(String url, HttpEntity<FwTransaction> httpentity, FwTransaction fwTransaction) throws Exception;
}
