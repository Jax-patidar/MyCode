package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

public class IndvMovedOutSummarySectionRow extends SummarySectionRow implements Serializable {

    private static final long serialVersionUID = -6418194215200480505L;

    private String left_home_reason_cd;
    private String left_home_dt;

    private String indvSeqNo;
    private String SeqNum;

    public String getLeft_home_reason_cd() {
        return left_home_reason_cd;
    }
    public void setLeft_home_reason_cd(String left_home_reason_cd) {
        this.left_home_reason_cd = left_home_reason_cd;
    }
    public String getLeft_home_dt() {
        return left_home_dt;
    }
    public void setLeft_home_dt(String left_home_dt) {
        this.left_home_dt = left_home_dt;
    }


    public String getIndvSeqNo() {
        return indvSeqNo;
    }
    public void setIndvSeqNo(String indvSeqNo) {
        this.indvSeqNo = indvSeqNo;
    }
    public String getSeqNum() {
        return SeqNum;
    }
    public void setSeqNum(String seqNum) {
        SeqNum = seqNum;
    }
}
