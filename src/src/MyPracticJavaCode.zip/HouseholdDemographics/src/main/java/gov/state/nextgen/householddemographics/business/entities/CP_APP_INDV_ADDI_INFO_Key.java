package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;


/**
 * Primary Id Key class of CP_APP_INDV_ADDI_INFO
 *
 * Created by @DeloitteUSI team
 * Creation Date Mon Jan 29 11:34:07 IST 2021
 */

public class CP_APP_INDV_ADDI_INFO_Key implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -735961343693692659L;
	private Integer app_number;
	
		
	public CP_APP_INDV_ADDI_INFO_Key() {
	}

	public CP_APP_INDV_ADDI_INFO_Key(Integer app_number) {
		super();
		this.app_number = app_number;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		return result;
	}

	
	

}
