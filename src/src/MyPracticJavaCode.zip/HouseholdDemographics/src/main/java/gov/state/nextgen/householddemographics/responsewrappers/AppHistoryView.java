package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.AppDetail;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;
import gov.state.nextgen.householddemographics.utilities.DateUtility;

@Component("APHIS")
@Scope("prototype")
public class AppHistoryView implements LogicResponseInterface {
	private static final String PAGE_ID = "APHIS";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();

		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Started creating Response wrapper for APHIS"); 

			Map<String, Object> pageCollection = fwTxn.getPageCollection();

			// load Apprequest details.
			List<AppDetail> rgstList = new ArrayList<>();
			APP_RQST_Collection rgstColl = pageCollection.get("GET_APP_HISTORY") != null
					? (APP_RQST_Collection) pageCollection.get("GET_APP_HISTORY")
					: null;
			if (rgstColl != null && !rgstColl.isEmpty()) {
				for (int i = 0; i < rgstColl.size(); i++) {
					rgstList.add(mapper(rgstColl.getCargo(i)));
				}

			} 

			driverPageResponse.getPageCollection().put("CP_APP_RQST_Collection", rgstList);
			driverPageResponse.setCurrentPageID(PAGE_ID);

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Inside exception block of AppHistoryView", e); 
		}

		return driverPageResponse;
	}

	private AppDetail mapper(APP_RQST_Cargo appreq) {
		AppDetail details = new AppDetail();
		details.setAppNum(appreq.getApp_num());
		details.setCasenum(appreq.getCaseNum());
		details.setStatus(appreq.getApp_stat_cd());
//		System.out.println(" appreq.getAppSbmtTms()    "+appreq.getAppSbmtTms());
		details.setApplicationDate(DateUtility.getPSTDefaultDateFromDate(appreq.getAppSbmtTms()));
		details.setSubmissionDate(DateUtility.getPSTDefaultDateFromDate(appreq.getAppSbmtTms()));
		details.setFormType(appreq.getFormRptType());
		details.setChangedDetails(appreq.getChanges_reported()!=null?appreq.getChanges_reported():"");
		return details;
	}
	
}
