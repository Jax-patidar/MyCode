package gov.state.nextgen.householddemographics.business.rules;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SHLTC_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SHLTC_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4MoveoutSsiSsp_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4MoveoutSsiSsp_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4Redet_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4Redet_Collection;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Collection;
import gov.state.nextgen.householddemographics.data.db2.AppMoveoutSsiSspRepository;
import gov.state.nextgen.householddemographics.data.db2.AppSbmsRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInDablRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInOutStBnftRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInPregRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInPrflRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInSchleRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInShltcRepo;
import gov.state.nextgen.householddemographics.data.db2.CpAppInTaxReturnRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.OtherHouseholdDetailsRepo;
import gov.state.nextgen.householddemographics.data.db2.Tnb4RedetRepository;

@Service("HouseHoldSummaryBO")
public class HouseHoldSummaryBO extends AbstractBO{
	
	private CpAppInPrflRepository cpAppInPrflRepository;
	
	@Autowired
	private CpAppInPregRepository cpAppInPregRepo;
	
	@Autowired
	private CpAppInOutStBnftRepository cpAppInOutStBnftRepository;
	
	@Autowired
	private CpAppInDablRepository cpAppInDablRepository;
	
	@Autowired
	private CpAppIndvRepository cpAppIndvRepository;
	
	@Autowired
	private CpAppInSchleRepository cpAppInSchleRepository;
	
	private CpAppInShltcRepo cpAppInShltcRepository;
	
	@Autowired
	private CpAppInTaxReturnRepository cpAppInTaxReturnRepository;
	
	@Autowired
	private OtherHouseholdDetailsRepo otherHouseholdDetailsRepo;
	
	@Autowired
	private AppSbmsRepository appSbmsRepository;
	
	@Autowired
	private Tnb4RedetRepository tnb4RedetRepository;
	
	@Autowired
	private AppMoveoutSsiSspRepository appMoveoutSsiSspRepository;

	public APP_IN_PRFL_Collection getPrflData(String appNum) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.getPrflData() - START");
        try {
        	APP_IN_PRFL_Collection appInPrflColl = new APP_IN_PRFL_Collection();
        	if(appNum != null) {
        		APP_IN_PRFL_Cargo[] appInPrflCargoArray  = cpAppInPrflRepository.getPrflData(appNum);
        		if (appInPrflCargoArray.length > 0) {
        			appInPrflColl.setResults(appInPrflCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.getPrflData() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInPrflColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(getClass().getName(),
                    "getPrflData", e);
        }
	}


	public APP_IN_DABL_Collection loadDisability(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadDisability() - START");
        try {
        	APP_IN_DABL_Collection appInDablColl = new APP_IN_DABL_Collection();
        	if(appNum != null) {
        		APP_IN_DABL_Cargo[] appInDablCargoArray  = cpAppInDablRepository.loadDisability(Integer.parseInt(appNum), indvIds);
        		if (appInDablCargoArray.length > 0) {
        			appInDablColl.setResults(appInDablCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadDisability() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInDablColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(getClass().getName(),
                    "loadDisability", e);
        }
	}

	public APP_IN_OUT_ST_BNFT_Collection loadGovernmentAid(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadGovernmentAid() - START");
		try {
			APP_IN_OUT_ST_BNFT_Collection appInbnftColl = new APP_IN_OUT_ST_BNFT_Collection();
			if (appNum != null) {
				APP_IN_OUT_ST_BNFT_Cargo[] appInbnftCargoArray = cpAppInOutStBnftRepository.loadGovernmentAid(Integer.parseInt(appNum), indvIds);
				if (appInbnftCargoArray.length > 0) {
					appInbnftColl.setResults(appInbnftCargoArray);
				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseHoldSummaryBO.loadGovernmentAid() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) );

			return appInbnftColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw createFwException(getClass().getName(), "loadGovernmentAid", e);
		}
	}


	public CP_APP_IN_PREG_Collection loadPregnancy(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadPregnancy() - START");
		try {
			CP_APP_IN_PREG_Collection appInPregColl = new CP_APP_IN_PREG_Collection();
			if (appNum != null) {
				String isPregnant = "Y";
				appInPregColl = cpAppInPregRepo.getAllDetails(Integer.parseInt(appNum), AppConstants.SRC_APP_IND_AFB, indvIds,
						isPregnant);
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseHoldSummaryBO.loadPregnancy() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) );

			return appInPregColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw createFwException(getClass().getName(), "loadPregnancy", e);
		}
	}

		
	public APP_INDV_Collection loadAppIndvCollection(String appNum, List<Integer> indvIds) {

		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadAppIndvCollection() - START");
        try {
        	APP_INDV_Collection appIndvColl = new APP_INDV_Collection();
        	if(appNum != null) {
        		APP_INDV_Cargo[] appIndvCargoArray  = cpAppIndvRepository.loadIndvData(Integer.parseInt(appNum), indvIds);
        		if (appIndvCargoArray.length > 0) {
        			appIndvColl.setResults(appIndvCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadAppIndvCollection() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appIndvColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	
		
	}


	public APP_IN_SCHLE_Collection loadCollegeTradeSchool(String appnum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadCollegeTradeSchool() - START");
		try {
			APP_IN_SCHLE_Collection appInSchleColl = new APP_IN_SCHLE_Collection();
			if (appnum != null) {
				APP_IN_SCHLE_Cargo[] appInSchleCargoArray = cpAppInSchleRepository.loadCollegeTradeSchool(Integer.parseInt(appnum),
						indvIds);
				if (appInSchleCargoArray.length > 0) {
					appInSchleColl.setResults(appInSchleCargoArray);
				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseHoldSummaryBO.loadCollegeTradeSchool() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) );

			return appInSchleColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw createFwException(getClass().getName(), "loadCollegeTradeSchool", e);
		}
	}

	
	public APP_IN_SHLTC_Collection loadFacilityShelter(String appNum) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadFacilityShelter() - START");
        try {
        	APP_IN_SHLTC_Collection shltcColl = new APP_IN_SHLTC_Collection();
        	if(appNum != null) {
        		APP_IN_SHLTC_Cargo[] shltcCargoArray  = cpAppInShltcRepository.loadFacilityShelterDtls(appNum);
        		if (shltcCargoArray.length > 0) {
        			shltcColl.setResults(shltcCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadFacilityShelter() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return shltcColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(getClass().getName(),
                    "loadFacilityShelter", e);
        }
	}

	public CP_APP_IN_TAX_RETURN_Collection loadTaxFilerSummary(String appnum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadTaxFilerSummary() - START");
		try {
			CP_APP_IN_TAX_RETURN_Collection appInTaxColl = new CP_APP_IN_TAX_RETURN_Collection();
			if (appnum != null) {
				CP_APP_IN_TAX_RETURN_Cargo[] appInTaxCargoArray = cpAppInTaxReturnRepository.loadTaxFilerSummary(Integer.parseInt(appnum),
						indvIds);
				if (appInTaxCargoArray.length > 0) {
					appInTaxColl.setResults(appInTaxCargoArray);
				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseHoldSummaryBO.loadTaxFilerSummary() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) );

			return appInTaxColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw createFwException(getClass().getName(), "loadTaxFilerSummary", e);
		}
	}

	public CP_APP_IN_PREG_Collection loadBreastFeedingDetails(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadBreastFeedingDetails() - START");
		try {
			CP_APP_IN_PREG_Collection appInPregColl = new CP_APP_IN_PREG_Collection();
			if (appNum != null) {
				String isBreastFeeding = "Y";
				appInPregColl = cpAppInPregRepo.getBreastFeedingDetails(Integer.parseInt(appNum), AppConstants.SRC_APP_IND_AFB, indvIds, isBreastFeeding);
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseHoldSummaryBO.loadBreastFeedingDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) );
			return appInPregColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw createFwException(getClass().getName(), "loadBreastFeedingDetails", e);
		}
	}

	public APP_IN_SCHLE_Collection loadTeenParentDetails(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadTeenParentDetails() - START");
        try {
        	APP_IN_SCHLE_Collection teenColl = new APP_IN_SCHLE_Collection();
        	if(appNum != null) {
        		APP_IN_SCHLE_Cargo[] teenCargoArray  = cpAppInSchleRepository.loadTeenParentDetails(Integer.parseInt(appNum), indvIds);
        		if (teenCargoArray.length > 0) {
        			teenColl.setResults(teenCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadTeenParentDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return teenColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(getClass().getName(),
                    "loadTeenParentDetails", e);
        }
	}
	@SuppressWarnings("unchecked")
	public void savePrflData(APP_IN_PRFL_Collection svePrflColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.savePrflData) - START");
		try {
			if(svePrflColl != null && !svePrflColl.isEmpty()) {
				cpAppInPrflRepository.saveAll(svePrflColl);
			}
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw createFwException(this.getClass().getName(),
	                  "savePrflData", e);
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.savePrflData - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) );
		
	}
	
	public OTHER_HOUSEHOLD_DETAILS_Collection getOtherHouseHoldDetails(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.getOtherHouseHoldDetails() - START");
        try {
        	OTHER_HOUSEHOLD_DETAILS_Collection otherHHCollection = new OTHER_HOUSEHOLD_DETAILS_Collection();
        	if(appNum != null) {
        		otherHHCollection  = otherHouseholdDetailsRepo.getDetailsByAppNumAndIndvIds(Integer.parseInt(appNum), indvIds);
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.getOtherHouseHoldDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return otherHHCollection;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(getClass().getName(),
                    "getOtherHouseHoldDetails", e);
        }
	}
	

	  public APP_SBMS_Collection loadSummaryTemplate(String appnum) {
			final long startTime = System.currentTimeMillis();
	        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadSummaryTemplate() - START");
	        try {
	        	APP_SBMS_Collection appInSumTem = new APP_SBMS_Collection();
	        	if(appnum != null) {
	        		APP_SBMS_Cargo[] appInSumTemCargoArray  = appSbmsRepository.findByAppNum(Integer.parseInt(appnum));
	        		if (null != appInSumTemCargoArray && appInSumTemCargoArray.length > 0) {
	        			appInSumTem.setResults(appInSumTemCargoArray);
	        		}
	        	}
	        	
	        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadSummaryTemplate() - END , Time Taken : "
	                    + (System.currentTimeMillis() - startTime)
	                    );
	        	
	    		return appInSumTem;
	        }catch (final Exception e) {
	            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	            throw e;
	        }
		}
	  public CpAppTnb4Redet_Collection loadtnb4redet(String appnum) {
			final long startTime = System.currentTimeMillis();
	        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadtnb4redet() - START");
	        try {
	        	CpAppTnb4Redet_Collection appInSumTem = new CpAppTnb4Redet_Collection();
	        	if(appnum != null) {
	        		CpAppTnb4Redet_Cargo[] appInSumTemCargoArray  = tnb4RedetRepository.findByAppNum(Integer.parseInt(appnum));
	        		if (null != appInSumTemCargoArray && appInSumTemCargoArray.length > 0) {
	        			
	        			appInSumTem.setResults(appInSumTemCargoArray);
	        			
	        		}
	        	}
	        	
	        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadtnb4redet() - END , Time Taken : "
	                    + (System.currentTimeMillis() - startTime)
	                    );
	        	
	    		return appInSumTem;
	        }catch (final Exception e) {
	            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	            throw createFwException(getClass().getName(),
	                    "loadtnb4redet", e);
	        }
		}
	  
	  public CpAppTnb4MoveoutSsiSsp_Collection loadMoveOutSsiSsp(String appnum) {
			final long startTime = System.currentTimeMillis();
	        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadMoveOutSsiSsp() - START");
	        try {
	        	CpAppTnb4MoveoutSsiSsp_Collection appInMoveOutSsiSsp = new CpAppTnb4MoveoutSsiSsp_Collection();
	        	if(appnum != null) {
	        		CpAppTnb4MoveoutSsiSsp_Cargo[] appInMoveOutSsiSspCargoArray  = appMoveoutSsiSspRepository.findByAppNum(Integer.parseInt(appnum));
	        		if (null != appInMoveOutSsiSspCargoArray && appInMoveOutSsiSspCargoArray.length > 0) {
	        			appInMoveOutSsiSsp.setResults(appInMoveOutSsiSspCargoArray);
	        		}
	        	}
	        	
	        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryBO.loadMoveOutSsiSsp() - END , Time Taken : "
	                    + (System.currentTimeMillis() - startTime)
	                    );
	        	
	    		return appInMoveOutSsiSsp;
	        }catch (final Exception e) {
	            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	            throw createFwException(getClass().getName(),
	                    "loadMoveOutSsiSsp", e);
	        }
		}

}
