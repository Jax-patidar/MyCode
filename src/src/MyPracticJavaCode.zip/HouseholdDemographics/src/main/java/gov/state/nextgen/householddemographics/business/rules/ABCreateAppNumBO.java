package gov.state.nextgen.householddemographics.business.rules;

import java.util.Arrays;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_USER_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_USER_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.data.db2.AppUserRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.RMBRqstRepository;

@Service
public class ABCreateAppNumBO extends AbstractBO {

	@Autowired
	AppUserRepository appUserRepo;
	@Autowired
	CpAppRqstRepository cpAppRqstRepositor;
	@Autowired
	RMBRqstRepository rmbRqstRepository;
	
	private static final String MILLISECONDS = "milliseconds";
	
	public void storeAcsIdAndAppNum(final String acsId, final String appNum) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(),Level.INFO, "ABCreateAppNumBO.storeAcsIdAndAppNum() - START");
		try {
			
			appUserRepo.save(new APP_USER_Cargo(acsId, Integer.parseInt(appNum),null));
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			/*
			 * final FwException fe = createFwException(this.getClass().getName(),
			 * "storeAcsIdAndAppNum", e);
			 */
			throw e;
		}

		FwLogger.log(this.getClass(),Level.INFO,
				"ABCreateAppNumBO.storeAcsIdAndAppNum() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ MILLISECONDS);
	}

	
	public APP_USER_Collection getByAppNum(String appNum) {
		APP_USER_Collection coll = new APP_USER_Collection();
		APP_USER_Cargo cargo = appUserRepo.getByAppNum(Integer.parseInt(appNum));
		if(cargo != null) {
			coll.add(cargo);
		}
		return coll;
	}
		public APP_USER_Cargo[] findAllByAcsId(String gUID) {
       try {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(),Level.INFO, "ABCreateAppNumBO.findAllByAcsId() - START");
		APP_USER_Cargo[] list = appUserRepo.findAllByAcsId(gUID).getResults();
		FwLogger.log(this.getClass(),Level.INFO,
				"ABCreateAppNumBO.findAllByAcsId() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ MILLISECONDS);
		return list;
       }catch(Exception e) {
    	   throw e;
       }
	}
	
	public APP_RQST_Collection getAllDetails(Set<Integer> appnums) {
		try{
			final long startTime = System.currentTimeMillis();
		
		FwLogger.log(this.getClass(),Level.INFO, "ABCreateAppNumBO.getAllDetails() - START");
		APP_RQST_Collection collection = cpAppRqstRepositor.getAllDetails(appnums);
		FwLogger.log(this.getClass(),Level.INFO,
				"ABCreateAppNumBO.getAllDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ MILLISECONDS);
		return collection;
		}catch(Exception e) {
			throw e;
		}
	}
	
	public APP_RQST_Collection deleteAppDetails(String appnum) {
		try{
			final long startTime = System.currentTimeMillis();
		
		FwLogger.log(this.getClass(),Level.INFO, "ABCreateAppNumBO.deleteAppDetails() - START");
		APP_RQST_Collection collection = cpAppRqstRepositor.getAllDetails(Integer.parseInt(appnum));
		for(APP_RQST_Cargo cargo : collection.getResults()) {
			
			if("IP".equals(cargo.getApp_stat_cd())) {
				cargo.setApp_stat_cd("DL");
			}
		
		}
		cpAppRqstRepositor.saveAll(Arrays.asList(collection.getResults()));
		FwLogger.log(this.getClass(),Level.INFO,
				"ABCreateAppNumBO.deleteAppDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		return collection;
		}catch(Exception e) {
			throw e;
		}
	}
	
	public void setSspAppNumAsNull(String appnum) {
		try{
			final long startTime = System.currentTimeMillis();
		
		FwLogger.log(this.getClass(),Level.INFO, "ABCreateAppNumBO.setSspAppNumAsNull() - START");
		
		RMB_RQST_Collection rmbRequestColl = rmbRqstRepository.findByAppNum(Integer.parseInt(appnum));
		for(RMB_RQST_Cargo cargo : rmbRequestColl.getResults()) {
				cargo.setSsp_app_num(null);
		}
		rmbRqstRepository.saveAll(Arrays.asList(rmbRequestColl.getResults()));
		
		FwLogger.log(this.getClass(),Level.INFO,
				"ABCreateAppNumBO.setSspAppNumAsNull() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		}catch(Exception e) {
			throw e;
		}
	}
}
