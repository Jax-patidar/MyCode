package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.APP_AR_LG_CNTC_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_AR_LG_CNTC_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_AR_LG_CNTC_Key;

/**
 * Crud Interface and/or Repository for APP_AR_LG_CNTC_Cargo.
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */
@NoRepositoryBean
public interface CpAppArLgCntcRepository extends CrudRepository<APP_AR_LG_CNTC_Cargo, APP_AR_LG_CNTC_Key>{
	
	@Query("select c from APP_AR_LG_CNTC_Cargo c where c.app_num = ?1 and c.auth_rep_seq_num = ?2 and c.src_app_ind =?3")
	public APP_AR_LG_CNTC_Collection getByAppNum(String appNum); 

}
