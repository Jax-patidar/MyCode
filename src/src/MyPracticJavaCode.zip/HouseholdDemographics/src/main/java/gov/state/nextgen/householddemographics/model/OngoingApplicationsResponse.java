	/**
 * 
 */
package gov.state.nextgen.householddemographics.model;


import static gov.state.nextgen.householddemographics.utilities.DateUtility.getPSTDateFromTimestamp;


import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * @author rudeshmukh
 *
 */
@Component
@Scope("prototype")
public class OngoingApplicationsResponse extends AbstractCargo implements Serializable {

	private static final long serialVersionUID = 1L;

	private String applicationNumber;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate lastUpdatedDate;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate submittedDate;
	private List<ProgramListResponse> programResponseList;
	private String applicationStatus;
	private List<IndividualResponse> applicationIndividuals;
	private String countyCode;
	private String formType;

	public String getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public LocalDate getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(LocalDate lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	
	public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
		if(Objects.nonNull(lastUpdatedDate)) {
			this.lastUpdatedDate = getPSTDateFromTimestamp(lastUpdatedDate);
		}
	}

	public LocalDate getSubmittedDate() {
		return submittedDate;
	}

	public void setSubmittedDate(LocalDate submittedDate) {
		this.submittedDate = submittedDate;
	}
	
	public void setSubmittedDate(Timestamp submittedDate) {
		if(Objects.nonNull(submittedDate)) {
			this.submittedDate = getPSTDateFromTimestamp(submittedDate);
		}
	}

	public List<ProgramListResponse> getProgramResponseList() {
		return programResponseList;
	}

	public void setProgramResponseList(List<ProgramListResponse> programResponseList) {
		this.programResponseList = programResponseList;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public List<IndividualResponse> getApplicationIndividuals() {
		return applicationIndividuals;
	}

	public void setApplicationIndividuals(List<IndividualResponse> applicationIndividuals) {
		this.applicationIndividuals = applicationIndividuals;
	}

	public String getCountyCode() {
		return countyCode;
	}

	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	public String getFormType() {
		return formType;
	}

	public void setFormType(String formType) {
		this.formType = formType;
	}

}
