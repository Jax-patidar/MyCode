package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_AR_LG_CNTC_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_AR_LG_CNTC_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_INST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_INST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SPS_IMPOV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SPS_IMPOV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABRGI")
@Scope("prototype")
public class InfoAboutYouView implements LogicResponseInterface{
	
	private static final String PAGE_ID = "ABRGI";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();

		Map pageCollection = fwTrxn.getPageCollection();
		
		List<APP_IN_INST_Cargo> appInInstList = new ArrayList<APP_IN_INST_Cargo>();
		APP_IN_INST_Cargo appInInstCargo = new APP_IN_INST_Cargo();
		
		List<APP_IN_SPS_IMPOV_Cargo> appInSpsImpovList = new ArrayList<APP_IN_SPS_IMPOV_Cargo>();
		APP_IN_SPS_IMPOV_Cargo appInSpsImpovCargo = new APP_IN_SPS_IMPOV_Cargo();
		
		List<APP_INDV_Cargo> appIndvList = new ArrayList<APP_INDV_Cargo>();
		APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
		
		List<APP_PGM_RQST_Cargo> appPgmRqstList = new ArrayList<APP_PGM_RQST_Cargo>();
		APP_PGM_RQST_Cargo appPgmRqstCargo = new APP_PGM_RQST_Cargo();
		
		List<APP_RGST_Cargo> appRqstList = new ArrayList<APP_RGST_Cargo>();
		APP_RGST_Cargo appRqstCargo = new APP_RGST_Cargo();
		
		APP_IN_INST_Collection appInInstColl = pageCollection.get("APP_IN_INST_Collection") != null ? (APP_IN_INST_Collection)pageCollection.get("APP_IN_INST_Collection") : null;

		APP_IN_SPS_IMPOV_Collection appInSpsImpovColl = pageCollection.get("APP_IN_SPS_IMPOV_Collection") != null ? (APP_IN_SPS_IMPOV_Collection)pageCollection.get("APP_IN_SPS_IMPOV_Collection") : null;

		APP_PGM_RQST_Collection appPgmRqstColl = pageCollection.get("APP_PGM_RQST_Collection") != null ? (APP_PGM_RQST_Collection)pageCollection.get("APP_PGM_RQST_Collection") : null;

		APP_INDV_Collection appIndvColl = pageCollection.get("APP_INDV_Collection") != null ? (APP_INDV_Collection)pageCollection.get("APP_INDV_Collection") : null;

		APP_RGST_Collection appRqstColl = pageCollection.get("APP_RGST_Collection") != null ? (APP_RGST_Collection)pageCollection.get("APP_RGST_Collection") : null;

		
		if(appInInstColl != null) {
			appInInstCargo = (APP_IN_INST_Cargo) appInInstColl.get(0);
		}
		appInInstList.add(appInInstCargo);
		
		if(appInSpsImpovColl != null) {
			appInSpsImpovCargo = (APP_IN_SPS_IMPOV_Cargo) appInSpsImpovColl.get(0);
		}
		appInSpsImpovList.add(appInSpsImpovCargo);
		
		if(appPgmRqstColl != null) {
			appPgmRqstCargo = (APP_PGM_RQST_Cargo) appPgmRqstColl.get(0);
		}
		appPgmRqstList.add(appPgmRqstCargo);
		
		if(appIndvColl != null) {
			appIndvCargo = (APP_INDV_Cargo) appIndvColl.get(0);
		}
		appIndvList.add(appIndvCargo);
		
		if(appRqstColl != null) {
			appRqstCargo = (APP_RGST_Cargo) appRqstColl.get(0);
		}
		appRqstList.add(appRqstCargo);
		
		driverPageResponse.getPageCollection().put("APP_IN_INST_Collection", appInInstList);
		driverPageResponse.getPageCollection().put("APP_IN_SPS_IMPOV_Collection", appInSpsImpovList);
		driverPageResponse.getPageCollection().put("APP_PGM_RQST_Collection", appPgmRqstList);
		driverPageResponse.getPageCollection().put("APP_INDV_Collection", appIndvList);
		driverPageResponse.getPageCollection().put("APP_RGST_Collection", appRqstList);

		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

		return driverPageResponse;
	}

}
