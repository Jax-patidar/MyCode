package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.math.BigInteger;

import javax.persistence.Embeddable;

@Embeddable
public class CpRmbRequestPrimaryKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6172981299491411648L;
	private BigInteger cpRmbRequestId;

	public CpRmbRequestPrimaryKey() {
	}

	public CpRmbRequestPrimaryKey(BigInteger cpRmbRequestId) {
		super();
		this.cpRmbRequestId = cpRmbRequestId;
	}

	/**
	 * @return the cpRmbRequestId
	 */
	public BigInteger getCpRmbRequestId() {
		return cpRmbRequestId;
	}

	/**
	 * @param cpRmbRequestId the cpRmbRequestId to set
	 */
	public void setCpRmbRequestId(BigInteger cpRmbRequestId) {
		this.cpRmbRequestId = cpRmbRequestId;
	}

}
