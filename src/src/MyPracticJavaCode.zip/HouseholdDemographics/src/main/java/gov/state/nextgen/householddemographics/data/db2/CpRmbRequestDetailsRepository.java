package gov.state.nextgen.householddemographics.data.db2;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Collection;

@Repository
public interface CpRmbRequestDetailsRepository extends CrudRepository<CpRmbRequestDetails_Cargo, Long>{
	
	@Query("select c from CpRmbRequestDetails_Cargo c where c.cpRmbRequestId = ?1")
	public CpRmbRequestDetails_Collection getCpRmbRequestId(Long cpRmbRequestId); 
	
}
