package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.Arrays;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABAD")
@Scope("prototype")
public class ABADViewWrapper implements LogicResponseInterface{

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		APP_RQST_Collection applicationRequestCollection = (APP_RQST_Collection) fwTxn.getPageCollection().get(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION);
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION, Arrays.asList(applicationRequestCollection.getResults()));
		return driverPageResponse;
	}

}
