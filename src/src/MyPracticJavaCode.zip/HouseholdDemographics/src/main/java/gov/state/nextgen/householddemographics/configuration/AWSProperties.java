package gov.state.nextgen.householddemographics.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class AWSProperties {

	@Autowired
    private Environment env;
	AWSProperties(Environment environment)
	{
		this.env = environment;
	}
	private String region;	
	private String tnb4RedetQueueName;
	private String appTransferQueueName;
	private String saws2PlusQueueName;
	private String cf37QueueName;
	private String reportAChangeQueueName;
	private String periodicReportQueueName;
	private String medicalQueueName;
	private String appSummaryInvocationQueue;
	
	public String getPeriodicReportQueueName() {
		return env.getProperty("AWS_PR_QUEUE");
	}
	public void setPeriodicReportQueueName(String periodicReportQueueName) {
		this.periodicReportQueueName = periodicReportQueueName;
	}
	public String getCf37QueueName() {
		return env.getProperty("AWS_CF37_QUEUE");
	}
	public void setMedicalQueueName(String medicalQueueName) {
		this.medicalQueueName = medicalQueueName;
	}
	public String getMedicalQueueName() {
		return env.getProperty("AWS_MC_QUEUE");
	}
	public void setCf37QueueName(String cf37QueueName) {
		this.cf37QueueName = cf37QueueName;
	}
	public String getRegion() {
		return env.getProperty("AWS_REGION_TNB4REDET");
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public Environment getEnv() {
		return env;
	}
	public void setEnv(Environment env) {
		this.env = env;
	}
	public String getTnb4RedetQueueName() {
		return env.getProperty("AWS_TNB4REDET_QUEUE");
	}
	public void setTnb4RedetQueueName(String tnb4RedetQueueName) {
		this.tnb4RedetQueueName = tnb4RedetQueueName;
	}
	public String getAppTransferQueueName() {
		return env.getProperty("AWS_APPTRANSFER_QUEUE");
	}
	public void setAppTransferQueueName(String appTransferQueueName) {
		this.appTransferQueueName = appTransferQueueName;
	}
	public String getSaws2PlusQueueName() {
		return env.getProperty("AWS_SAWS2PLUS_QUEUE");
	}
	public void setSaws2PlusQueueName(String saws2PlusQueueName) {
		this.saws2PlusQueueName = saws2PlusQueueName;
	}
	
	public String getReportAChangeQueueName() {
		return env.getProperty("AWS_REPORTACHANGE_QUEUE");
	}
	public void setReportAChangeQueueName(String reportAChangeQueueName) {
		this.reportAChangeQueueName = reportAChangeQueueName;
	}
	public String getAppSummaryInvocationQueue() {
		return env.getProperty("AWS_APPSUMMARY_QUEUE");
	}
	public void setAppSummaryInvocationQueue(String appSummaryInvocationQueue) {
		this.appSummaryInvocationQueue = appSummaryInvocationQueue;
	}
	
	
	
}
