package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import gov.state.nextgen.access.business.entities.FwTransaction;

import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpUserSurveys_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpUserSurveys_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABCRT")
@Scope("prototype")
public class ABCRTView implements LogicResponseInterface{
	
	private static final String PAGE_ID = "ABOST";
	private static final String APP_SBMS_COLLECTION= "APP_SBMS_Collection";
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
DriverPageResponse driverPageResponse = new DriverPageResponse();
		
		Map pageCollection = fwTxn.getPageCollection();

		List<APP_SBMS_Cargo> sbmsList = new ArrayList<APP_SBMS_Cargo>();
		APP_SBMS_Cargo cpAppIndvCargo;
		
		APP_SBMS_Collection apSbmsCollection = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLLECTION);
		if(apSbmsCollection != null && !apSbmsCollection.isEmpty() && apSbmsCollection.size() >0) {			
			for (int i = 0; i < apSbmsCollection.size(); i++) {
				cpAppIndvCargo = (APP_SBMS_Cargo) apSbmsCollection.get(i);
				sbmsList.add(cpAppIndvCargo);
			}
		}
		
		List<CpUserSurveys_Cargo> surveyCargoList = new ArrayList<>();
		
		CpUserSurveys_Collection collection = (pageCollection.get(HouseHoldDemoGraphicsConstants.CP_USER_SURVEYS_COLLECTION) != null) 
				? (CpUserSurveys_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.CP_USER_SURVEYS_COLLECTION) : null;
		
		if(Objects.nonNull(collection) && !collection.isEmpty()) {			
			surveyCargoList.add(collection.getCargo(0));
		}
		
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_USER_SURVEYS_COLLECTION, surveyCargoList);
		driverPageResponse.getPageCollection().put(APP_SBMS_COLLECTION, sbmsList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		return driverPageResponse;
	}
}
