package gov.state.nextgen.householddemographics.business.validation;

import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;

public class MovedOutValidator {
    public void validateARHMO(APP_INDV_Cargo appIndvCargo, String catType, String firstName, String birDate) {
    }
}
