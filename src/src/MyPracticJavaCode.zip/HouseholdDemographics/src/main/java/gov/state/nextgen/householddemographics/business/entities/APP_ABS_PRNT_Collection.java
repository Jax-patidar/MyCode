package gov.state.nextgen.householddemographics.business.entities;

import java.rmi.RemoteException;
import java.sql.Date;
import java.util.Objects;

import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_ABS_PRNT_Collection extends AbstractCollection{

	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT";
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7015103454373898505L;

	@Override
	public String getPACKAGE() {
		// TODO Auto-generated method stub
		return PACKAGE;
	}
	
	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_ABS_PRNT_Cargo aNewCargo) {
		add(aNewCargo);
	}
	
	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_ABS_PRNT_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}
	
	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_ABS_PRNT_Cargo[] getResults() {
		final APP_ABS_PRNT_Cargo[] cbArray = new APP_ABS_PRNT_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}
	
	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_ABS_PRNT_Cargo getCargo(final int idx) {
		return (APP_ABS_PRNT_Cargo) get(idx);
	}
	
	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_ABS_PRNT_Cargo aCargo) {
		set(idx, aCargo);
	}
	
	
	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(Object obj) throws RemoteException {
		// TODO Auto-generated method stub
		if (obj instanceof APP_ABS_PRNT_Cargo[]) {
			final APP_ABS_PRNT_Cargo[] cbArray = (APP_ABS_PRNT_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
