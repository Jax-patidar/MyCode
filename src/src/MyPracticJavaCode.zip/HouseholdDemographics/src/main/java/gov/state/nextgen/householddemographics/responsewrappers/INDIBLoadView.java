package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("INDIB")
@Scope("prototype")
public class INDIBLoadView implements LogicResponseInterface {
	private static final String PAGE_ID = "INDIB";
	
	private static final String APP_INDV_COLL = "APP_INDV_Collection";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
	
		Map pageCollection = fwTrxn.getPageCollection();
		
		//Indv Cargo and Coll
		List<APP_INDV_Cargo> appIndvCargoList = new ArrayList<APP_INDV_Cargo>();
		
		APP_INDV_Collection appIndvCollection = pageCollection.get(APP_INDV_COLL) != null ? (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL) : null;
		if(appIndvCollection != null && !appIndvCollection.isEmpty() && appIndvCollection.size() > 0) {
			for (int i = 0; i < appIndvCollection.size(); i++) {
				APP_INDV_Cargo appIndvCargo1 = (APP_INDV_Cargo) appIndvCollection.get(i);
				appIndvCargoList.add(appIndvCargo1);
			}	
			
		}
		
		

		driverPageResponse.getPageCollection().put(APP_INDV_COLL, appIndvCargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getRequest().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		return driverPageResponse;
	}

}
