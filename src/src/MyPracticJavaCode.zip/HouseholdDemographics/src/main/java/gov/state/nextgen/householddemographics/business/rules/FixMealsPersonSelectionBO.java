package gov.state.nextgen.householddemographics.business.rules;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;

/*
 * FixMealsPersonSelectionBO - An BO class for fixMealsPersonSelection Service
 * 
 * Created by @DeloitteUSI team
 * @author @arunkuj
 */
@Service("FixMealsPersonSelectionBO")
public class FixMealsPersonSelectionBO extends AbstractBO{
	
	@Autowired
	private CpAppIndvRepository cpAppIndvRepository;
	
	private static Logger logger = LoggerFactory.getLogger(FixMealsPersonSelectionBO.class);
	
	public List<APP_INDV_Cargo> getAllAPPIndividuals(String appNum) {
		logger.info("FixMealsPersonSelectionBO.getAllAPPIndividuals() - START");
		try {

			List<APP_INDV_Cargo> cpAppIndvCargos;
        APP_INDV_Cargo[] appIndvCargoArray =  cpAppIndvRepository.getByAppNum(Integer.parseInt(appNum));
        cpAppIndvCargos = Arrays.asList(appIndvCargoArray);
        logger.info("FixMealsPersonSelectionBO.getAllAPPIndividuals() - END");
		return cpAppIndvCargos;
		} catch (final FwException fe) {
			final FwWrappedException fwWrappedException = new FwWrappedException(fe);
			fwWrappedException.setCallingClassID(getClass().getName());
			fwWrappedException.setCallingMethodID("getAllAPPIndividuals");
			fwWrappedException.setFwException(fe);
			throw fwWrappedException;
		} catch (final Exception exception) {
			throw exception;
		}
		
	}
	
	public APP_INDV_Collection getAppIndvByAppNumIndvSeqNum(String appNum, Integer indvSeqNum) {
		try {
		logger.info("FixMealsPersonSelectionBO.getAppIndvByAppNumIndvSeqNum() - START");
		APP_INDV_Collection appIndvCollection =  cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNum), indvSeqNum);
        logger.info("FixMealsPersonSelectionBO.getAppIndvByAppNumIndvSeqNum() - END");
		return appIndvCollection;
		} catch (final FwException fe) {
			final FwWrappedException fwWrappedException = new FwWrappedException(fe);
			fwWrappedException.setCallingClassID(getClass().getName());
			fwWrappedException.setCallingMethodID("getAppIndvByAppNumIndvSeqNum");
			fwWrappedException.setFwException(fe);
			throw fwWrappedException;
		} catch (final Exception exception) {
			throw exception;
		}
	}

	public void saveFixMealsPersonSelection(APP_INDV_Cargo appIndvCargo) {
		try {
		logger.info("FixMealsPersonSelectionBO.saveFixMealsPersonSelection() - START");
		cpAppIndvRepository.save(appIndvCargo);
		logger.info("FixMealsPersonSelectionBO.saveFixMealsPersonSelection() - END");
		} catch (final FwException fe) {
			final FwWrappedException fwWrappedException = new FwWrappedException(fe);
			fwWrappedException.setCallingClassID(getClass().getName());
			fwWrappedException.setCallingMethodID("saveFixMealsPersonSelection");
			fwWrappedException.setFwException(fe);
			throw fwWrappedException;
		} catch (final Exception exception) {
			throw exception;
		}
	}
}
