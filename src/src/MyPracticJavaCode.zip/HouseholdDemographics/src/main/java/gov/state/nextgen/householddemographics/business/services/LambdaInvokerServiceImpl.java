package gov.state.nextgen.householddemographics.business.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.business.entities.ServiceResponseCargo;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.util.ServiceChainUtil;
import gov.state.nextgen.householddemographics.configuration.AWSProperties;

@Service
public class LambdaInvokerServiceImpl implements LambdaInvokerService {

	@Autowired
    private AWSProperties awsProperties;
	
	@Autowired
    private RMBRequestServiceBO rmbRequestServiceBO;
	
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    public String invokeLambda(String url, HttpEntity<FwTransaction> httpentity, String path) throws Exception {
        try {
        	String responsePayload = null;
        	String payload = null;
        	String body = null;
            logger.info("Begin invokeLambda");
                // (1) Define the AWS Region in which the function is to be invoked
                Regions region = Regions.fromName(awsProperties.getRegion());
                // (2) Instantiate AWSLambdaClientBuilder to build the Lambda client
                AWSLambdaClientBuilder builder = AWSLambdaClientBuilder.standard().withRegion(region);
                // (3) Build the client, which will ultimately invoke the function
                AWSLambda client = builder.build();
                String httpMethod = "POST";
                payload = ServiceChainUtil.prepareAWSRequest(httpMethod,path,path,httpentity.getBody());
                logger.info("payload::{} ",payload);
                InvokeRequest req = new InvokeRequest().withFunctionName(url).withPayload(payload); // optional
                // (5) Invoke the function and capture response
                InvokeResult result = client.invoke(req);
                logger.info(" result: {}", result);
                if(result != null) {
                 logger.info(" result status code: {}", result.getStatusCode());
                 logger.info(" payload: {}", result.getPayload());
                 responsePayload = new String(result.getPayload().array());
                }
                logger.info("responsePayload::{} responsePayload",responsePayload);
                if(responsePayload != null) {
                	 ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                           FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Converting Json");
                           
                            ServiceResponseCargo responseObj = objMapper.readValue(responsePayload, ServiceResponseCargo.class);
                            logger.info("responseObj::{} ",responseObj);

                           body = responseObj.getBody();
                           logger.info("body::{} ",body);
                }
                logger.info("body::{} ",body);
                logger.info("End invokeLambda");
                return body;
        } catch (JsonProcessingException e) {
			FwLogger.log(this.getClass(), Level.ERROR, "In Exception; LambdaInvokerServiceImpl.invokeLambda; Exception Details: ", e);
			throw e;
        }
        
    }
    
    public String invokeDataExchangeLambda(String url, HttpEntity<FwTransaction> httpentity, FwTransaction fwTransaction) throws Exception {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"LambdaInvokerServiceImpl.invokeCommonServicesLambda - START");
		try {
			String responsePayload = null;
			String payload = null;
			String body = null;
			String httpMethod = "GET";
			String guid = fwTransaction.getAuthId();
			String path = "dataexchange/case-details?guID="+guid;
			logger.info("Begin invokeDataExcLambda");
			
			// (1) Define the AWS Region in which the function is to be invoked
			Regions region = Regions.fromName(awsProperties.getRegion());
			 FwLogger.log(this.getClass(), Level.INFO,
						"lambdaInvokerServiceImpl from hh DataExchange_Lambda_Function path::::" + region);
			// (2) Instantiate AWSLambdaClientBuilder to build the Lambda client
			AWSLambdaClientBuilder builder = AWSLambdaClientBuilder.standard().withRegion(region);
			// (3) Build the client, which will ultimately invoke the function
			AWSLambda client = builder.build();
						
			payload = rmbRequestServiceBO.prepareAWSRequest(path, fwTransaction);
			FwLogger.log(this.getClass(), Level.INFO,
					"lambdaInvokerServiceImpl from hh DataExchange_Lambda_Function payload::::" + payload);
			logger.info("payload::{} ", payload);
			InvokeRequest req = new InvokeRequest().withFunctionName(url).withPayload(payload); // optional
			FwLogger.log(this.getClass(), Level.INFO,
					"lambdaInvokerServiceImpl from hh DataExchange_Lambda_Function before invoking::::" + req);
			// (5) Invoke the function and capture response
			InvokeResult result = client.invoke(req);
			FwLogger.log(this.getClass(), Level.INFO,
					"lambdaInvokerServiceImpl from hh DataExchange_Lambda_Function after invoking::::" + result);
			logger.info(" result: {}", result);
			if (result != null) {
				logger.info(" result status code: {}", result.getStatusCode());
				logger.info(" payload: {}", result.getPayload());
				FwLogger.log(this.getClass(), Level.INFO,
						"lambdaInvokerServiceImpl from hh DataExchange_Lambda_Function before getting payload::::");
				responsePayload = new String(result.getPayload().array());
				FwLogger.log(this.getClass(), Level.INFO,
						"lambdaInvokerServiceImpl from hh DataExchange_Lambda_Function before getting payload::::" +responsePayload);
			}
			logger.info("responsePayload::{} responsePayload", responsePayload);
			/*if (responsePayload != null) {
				FwLogger.log(this.getClass(), Level.INFO,
						"lambdaInvokerServiceImpl from hh DataExchange_Lambda_Function objectmapper:::: start");
				ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
						false);
				
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Converting Json");

				ServiceResponseCargo responseObj = objMapper.readValue(responsePayload, ServiceResponseCargo.class);
				FwLogger.log(this.getClass(), Level.INFO,
						"lambdaInvokerServiceImpl from hh DataExchange_Lambda_Function objectmapper:::: end" +responseObj);
				logger.info("responseObj::{} ", responseObj);

				body = responseObj.getBody();
			}*/
			FwLogger.log(this.getClass(), Level.INFO,
					"lambdaInvokerServiceImpl from hh DataExchange_Lambda_Function objectmapper:::: getbody" +responsePayload);
			logger.info("body:::::{} ", responsePayload);
			logger.info("End invokeCommonServicesLambda");
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"LambdaInvokerServiceImpl.invokeCommonServicesLambda - END");
			return responsePayload;
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR,
					"In Exception; LambdaInvokerServiceImpl.invokeCommonServicesLambda; Exception Details: ", e);
			throw e;
		}
    }
}
