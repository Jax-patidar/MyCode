package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "CP_APP_IN_PREG",schema = "ie_ssp_owner_hh")
@IdClass(CP_APP_IN_PREG_CargoKey.class)
public class CP_APP_IN_PREG_Cargo extends AbstractCargo implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Transient
	private boolean isDirty = false;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private Integer indv_seq_num;

	private String src_app_ind;
	
	@Transient
	private String ecp_id;
	
	@Column(name = "change_eff_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_eff_dt;
	@Transient
	private Integer fetus_ct;
	
	//Changed date format as per frontend screen
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date preg_due_dt;
	private Integer rec_cplt_ind;
	
	@Transient
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date conception_dt;
	
	private Integer baby_ct;
	@Transient
	private String baby_reside_hshld_ind;
	@Transient
	private String cur_preg;
	@Transient
	private String cur_in_post_partum;
	
	@Transient
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date preg_term_dt;
	@Transient
	private Integer pp_babies_ct;
	@Transient
	private String bf_infant;
	@Transient
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date preg_dlvry_dt;
	
	private Date preg_end_dt;
	
	private String birth_in_twelv_mnths;
	
	private String presump_elig_card_ind;
	
	private String enrl_stat_cd;
	
	private String nt_enrl_stat_desc;
	
	private String is_breast_feeding;
	
	private String is_pregnant;
	
	@Transient
    private String first_name;
    @Transient
    private String last_name;
    @Transient
    private Integer age;
	
	public String getEnrl_stat_cd() {
		return enrl_stat_cd;
	}
	public void setEnrl_stat_cd(String enrl_stat_cd) {
		this.enrl_stat_cd = enrl_stat_cd;
	}
	public String getNt_enrl_stat_desc() {
		return nt_enrl_stat_desc;
	}
	public void setNt_enrl_stat_desc(String nt_enrl_stat_desc) {
		this.nt_enrl_stat_desc = nt_enrl_stat_desc;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}

	
	
	public Date getPreg_end_dt() {
		return preg_end_dt;
	}

	public void setPreg_end_dt(Date preg_end_dt) {
		this.preg_end_dt = preg_end_dt;
	}

	public String getBirth_in_twelv_mnths() {
		return birth_in_twelv_mnths;
	}

	public void setBirth_in_twelv_mnths(String birth_in_twelv_mnths) {
		this.birth_in_twelv_mnths = birth_in_twelv_mnths;
	}

	public String getPresump_elig_card_ind() {
		return presump_elig_card_ind;
	}

	public void setPresump_elig_card_ind(String presump_elig_card_ind) {
		this.presump_elig_card_ind = presump_elig_card_ind;
	}

	public Date getPreg_dlvry_dt() {
		if (preg_dlvry_dt == null) {
			return null;
		} else {
			return (Date) preg_dlvry_dt.clone();
		}
	}

	public void setPreg_dlvry_dt(Date preg_dlvry_dt) {
		if (preg_dlvry_dt == null) {
			this.preg_dlvry_dt = null;
		} else {
			this.preg_dlvry_dt = (Date) preg_dlvry_dt.clone();
		}
	}

	public String getCur_preg() {
		return cur_preg;
	}

	public void setCur_preg(String cur_preg) {
		this.cur_preg = cur_preg;
	}

	public String getCur_in_post_partum() {
		return cur_in_post_partum;
	}

	public void setCur_in_post_partum(String cur_in_post_partum) {
		this.cur_in_post_partum = cur_in_post_partum;
	}

	public Date getPreg_term_dt() {
		if (preg_term_dt == null) {
			return null;
		} else {
			return (Date) preg_term_dt.clone();
		}
	}

	public void setPreg_term_dt(Date preg_term_dt) {
		if (preg_term_dt == null) {
			this.preg_term_dt = null;
		} else {
			this.preg_term_dt = (Date) preg_term_dt.clone();
		}
	}

	public Integer getPp_babies_ct() {
		return pp_babies_ct;
	}

	public void setPp_babies_ct(Integer pp_babies_ct) {
		this.pp_babies_ct = pp_babies_ct;
	}

	public String getBf_infant() {
		return bf_infant;
	}

	public void setBf_infant(String bf_infant) {
		this.bf_infant = bf_infant;
	}

	/**
	 * @return the ecp_id
	 */
	public String getEcp_id() {
		return ecp_id;
	}

	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(final String ecp_id) {
		this.ecp_id = ecp_id;
	}

	/**
	 * @return the baby_reside_hshld_ind
	 */
	public String getBaby_reside_hshld_ind() {
		return baby_reside_hshld_ind;
	}

	/**
	 * @param baby_reside_hshld_ind the baby_reside_hshld_ind to set
	 */
	public void setBaby_reside_hshld_ind(final String baby_reside_hshld_ind) {
		this.baby_reside_hshld_ind = baby_reside_hshld_ind;
	}

	/**
	 * @return the baby_ct
	 */
	public Integer getBaby_ct() {
		return baby_ct;
	}

	/**
	 * @param baby_ct the baby_ct to set
	 */
	public void setBaby_ct(final Integer baby_ct) {
		this.baby_ct = baby_ct;
	}

	public Date getConception_dt() {
		if (conception_dt == null) {
			return null;
		} else {
			return (Date) conception_dt.clone();
		}
	}

	public void setConception_dt(final Date conception_dt) {
		if (conception_dt == null) {
			this.conception_dt = null;
		} else {
			this.conception_dt = (Date) conception_dt.clone();
		}
	}

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * returns the chg_eff_dt value.
	 */
	public Date getChg_eff_dt() {
		if (chg_eff_dt == null) {
			return null;
		} else {
			return (Date) chg_eff_dt.clone();
		}
	}

	/**
	 * sets the chg_eff_dt value.
	 */
	public void setChg_eff_dt(final Date chg_eff_dt) {
		if (chg_eff_dt == null) {
			this.chg_eff_dt = null;
		} else {
			this.chg_eff_dt = (Date) chg_eff_dt.clone();
		}
	}

	/**
	 * returns the fetus_ct value.
	 */
	public Integer getFetus_ct() {
		return fetus_ct;
	}

	/**
	 * sets the fetus_ct value.
	 */
	public void setFetus_ct(final Integer fetus_ct) {
		this.fetus_ct = fetus_ct;
	}

	/**
	 * returns the preg_due_dt value.
	 */
	public Date getPreg_due_dt() {
		if (preg_due_dt == null) {
			return null;
		} else {
			return (Date) preg_due_dt.clone();
		}
	}

	/**
	 * sets the preg_due_dt value.
	 */
	public void setPreg_due_dt(final Date preg_due_dt) {
		if (preg_due_dt == null) {
			this.preg_due_dt = null;
		} else {
			this.preg_due_dt = (Date) preg_due_dt.clone();
		}
	}

	/**
	 * returns the rec_cplt_ind value.
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * sets the rec_cplt_ind value.
	 */
	public void setRec_cplt_ind(final Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	public String getIs_breast_feeding() {
		return is_breast_feeding;
	}

	public void setIs_breast_feeding(String is_breast_feeding) {
		this.is_breast_feeding = is_breast_feeding;
	}

	public String getIs_pregnant() {
		return is_pregnant;
	}

	public void setIs_pregnant(String is_pregnant) {
		this.is_pregnant = is_pregnant;
	}

	
	
	

	

}
