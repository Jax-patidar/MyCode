package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_IMMED_CASH_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IMMED_CASH_KEY;

@Repository
public interface CP_APP_IMMED_CASH_Repository extends CrudRepository<CP_APP_IMMED_CASH_Cargo, CP_APP_IMMED_CASH_KEY>{
	
	@Query("select c from CP_APP_IMMED_CASH_Cargo c where c.app_number = ?1")
	public CP_APP_IMMED_CASH_Cargo[] getByAppNum(Integer appNum);
	
	@Query("select c from CP_APP_IMMED_CASH_Cargo c")
	public CP_APP_IMMED_CASH_Cargo[] getAllData();
	
}
