package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;


import gov.state.nextgen.access.business.entities.AbstractCargo;

public class ADD_VAL_Cargo extends AbstractCargo implements Serializable {
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -1361251433120466661L;
	
	String radioGroup_HOME;
	String radioGroup_MAIL;
	
	public String getRadioGroup_HOME() {
		return radioGroup_HOME;
	}
	public void setRadioGroup_HOME(String radioGroup_HOME) {
		this.radioGroup_HOME = radioGroup_HOME;
	}
	public String getRadioGroup_MAIL() {
		return radioGroup_MAIL;
	}
	public void setRadioGroup_MAIL(String radioGroup_MAIL) {
		this.radioGroup_MAIL = radioGroup_MAIL;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((radioGroup_HOME == null) ? 0 : radioGroup_HOME.hashCode());
		result = prime * result + ((radioGroup_MAIL == null) ? 0 : radioGroup_MAIL.hashCode());
		return result;
	}
	
	@Override
	public String toString() {
		return "ADD_VAL_Cargo [radioGroup_HOME=" + radioGroup_HOME + ", radioGroup_MAIL=" + radioGroup_MAIL
				+ "]";
	}
	
	
	
	

}
