/**
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * @author khuskumari
 *
 */
@Entity
@Table(name = "CP_APP_SUPPORT_SERVICES")
@IdClass(CP_APP_SUPPORT_SERVICES_Key.class)
public class CP_APP_SUPPORT_SERVICES_Cargo extends AbstractCargo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Transient
	private String src_app_ind;

	private Integer indv_seq_num;
	private String child_health_disability;
	private String family_planning;
	private String free_vaccines;
	private String wic_flag;
	private String personal_care_ind;

	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public String getPersonal_care_ind() {
		return personal_care_ind;
	}

	public void setPersonal_care_ind(String personal_care_ind) {
		this.personal_care_ind = personal_care_ind;
	}

	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	
	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * @return the child_health_disability
	 */
	public String getChild_health_disability() {
		return child_health_disability;
	}

	/**
	 * @param child_health_disability the child_health_disability to set
	 */
	public void setChild_health_disability(String child_health_disability) {
		this.child_health_disability = child_health_disability;
	}

	/**
	 * @return the family_planning
	 */
	public String getFamily_planning() {
		return family_planning;
	}

	/**
	 * @param family_planning the family_planning to set
	 */
	public void setFamily_planning(String family_planning) {
		this.family_planning = family_planning;
	}

	/**
	 * @return the free_vaccines
	 */
	public String getFree_vaccines() {
		return free_vaccines;
	}

	/**
	 * @param free_vaccines the free_vaccines to set
	 */
	public void setFree_vaccines(String free_vaccines) {
		this.free_vaccines = free_vaccines;
	}

	/**
	 * @return the wic_flag
	 */
	public String getWic_flag() {
		return wic_flag;
	}

	/**
	 * @param wic_flag the wic_flag to set
	 */
	public void setWic_flag(String wic_flag) {
		this.wic_flag = wic_flag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((child_health_disability == null) ? 0 : child_health_disability.hashCode());
		result = prime * result + ((family_planning == null) ? 0 : family_planning.hashCode());
		result = prime * result + ((free_vaccines == null) ? 0 : free_vaccines.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		result = prime * result + ((wic_flag == null) ? 0 : wic_flag.hashCode());
		return result;
	}

	

}
