package gov.state.nextgen.householddemographics.responsewrappers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;



@Component("ABAS")
public class ApplicationSummaryWrapper implements LogicResponseInterface {


	private PersonDetailsView personDetailsWrapper;
	
	private HouseHoldSummaryView houseHoldSummaryWrapper;
	
	
	 @Autowired
	 public ApplicationSummaryWrapper(ApplicationContext ctx) {
	        personDetailsWrapper = (PersonDetailsView) ctx.getBean(HouseHoldDemoGraphicsConstants.PERSONDETAILS_PAGE_ID);
	        houseHoldSummaryWrapper = (HouseHoldSummaryView) ctx.getBean(HouseHoldDemoGraphicsConstants.HOUSEHOLD_SUMMARY_PAGE_ID);
	    }
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		PageResponse personDetailsPageResponse = personDetailsWrapper.constructPageResponse(fwTxn);
		PageResponse summaryDetailsPageResponse = houseHoldSummaryWrapper.constructPageResponse(fwTxn);
		DriverPageResponse finalPageResponse = (DriverPageResponse)personDetailsPageResponse;
		DriverPageResponse summaryDetailsDriverResponse = (DriverPageResponse)summaryDetailsPageResponse;
		//merging pagecollection
		finalPageResponse.getPageCollection().putAll(summaryDetailsDriverResponse.getPageCollection());
		finalPageResponse.setAppNum(fwTxn.getUserDetails().getAppNumber());
		return finalPageResponse;
	}

}
