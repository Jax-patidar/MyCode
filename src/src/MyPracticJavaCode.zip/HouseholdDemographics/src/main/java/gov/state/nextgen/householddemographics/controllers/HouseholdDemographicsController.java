package gov.state.nextgen.householddemographics.controllers;


import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.entityurl.UrlPermission;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;

import gov.state.nextgen.householddemographics.business.services.RedeterminationServiceImpl;

import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;

import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;

import gov.state.nextgen.householddemographics.business.services.RedeterminationServiceImpl;

import gov.state.nextgen.householddemographics.factory.CommonLogicInterface;
import gov.state.nextgen.householddemographics.model.PageResponse;

/**
 * Household demographics controller.
 *
 * Created by @DeloitteUSI team Creation Date Wed Sep 29 11:34:07 IST 2020
 * 
 * @authors: @prabhasingh, @srprasannakumar
 */

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class HouseholdDemographicsController {

	@Autowired
	private CommonLogicInterface logicService;
	
	@Autowired
	private RedeterminationServiceImpl redeterminationServiceImpl;

	@Autowired
    private ExceptionUtil exceptionUtil;
	
	@Autowired
	private HttpServletRequest httpServletRequest;
	

	
	/**
	 * Endpoint for HouseholdDemographicsController
	 * 
	 * @param currentPageId
	 * @param pageAction
	 * @return ResponseEntity mapped to DriverPageResponse object
	 * @throws Exception
	 */
	@SuppressWarnings("javasecurity:S5131")
	@PostMapping("/hhdemographics/{currentPageId}/{pageAction}")
	public ResponseEntity<Object> apiRequest(@PathVariable("currentPageId") String currentPageId,
			@PathVariable("pageAction") String pageAction, @RequestBody FwTransaction fwTx,

			@RequestHeader(value = HttpHeaders.USER_AGENT) String userAgent,
			@RequestHeader("X-Custom-TransactionIdentifier") String transactionIdentifier, @RequestHeader("x-auth-id") String guid
			) throws Exception {
		fwTx.setTransactionIdentifier(transactionIdentifier);
		fetchingHeadersFromRequest(fwTx, guid, userAgent);
		
		FwLogger.log(this.getClass(), Level.INFO,"HouseholdDemographics service result of validateUserAndAppNUm:" + transactionIdentifier+" "+fwTx.getTransactionIdentifier());
//=======
//			@RequestHeader(value = HttpHeaders.USER_AGENT) String userAgent) throws Exception {
////		fwTx.setTransactionIdentifier(transactionIdentifier);
////		FwLogger.log(this.getClass(), Level.INFO,"HouseholdDemographics service result of validateUserAndAppNUm:" + transactionIdentifier+" "+fwTx.getTransactionIdentifier());
//>>>>>>> Stashed changes
		UrlPermission urlObj=new UrlPermission();
		boolean result=true;
//		if(!urlObj.overRideAuthentication(currentPageId,userAgent, fwTx, guid)) {
//			result=urlObj.validateUserAndAppNum(fwTx, guid);
//			FwLogger.log(this.getClass(), Level.INFO,
//					"HouseholdDemographics service result of validateUserAndAppNUm:" + result);
//		}
		if(result) {
			FwLogger.log(this.getClass(), Level.INFO,
					"HouseholdDemographicsController called with pageId:" + currentPageId + ", pageAction:" + pageAction);
			Object obj = invokeServices(pageAction, fwTx);
			return new ResponseEntity<Object>(obj, HttpStatus.OK);
		}else {
			Map<String, FwMessageList> request = new HashMap<String,FwMessageList>();    	
        	FwMessageList validateInfo = exceptionUtil.unauthorizedMessageForURLEntity();
        	request.put(FwConstants.MESSAGE_LIST, validateInfo);
        	fwTx.setRequest(request);
			return new ResponseEntity<Object>(fwTx, HttpStatus.UNAUTHORIZED);
		}
	}

	private void fetchingHeadersFromRequest(FwTransaction fwTx, String guid, String userAgent) {
		FwLogger.log(this.getClass(), Level.INFO,"HouseholdDemographics service inside:::: fetchingHeadersFromRequest");
		String amznTraceId = httpServletRequest.getHeader("X-Amzn-Trace-Id");
		String authToken = httpServletRequest.getHeader("x-auth-token");
		fwTx.setAuthId(guid);
		fwTx.setAmznTraceId(amznTraceId);
		fwTx.setAuthToken(authToken);
		fwTx.setUserAgent(userAgent);
		FwLogger.log(this.getClass(), Level.INFO,"HouseholdDemographics service result of guid:" +" "+fwTx.getAuthId());
		FwLogger.log(this.getClass(), Level.INFO,"HouseholdDemographics service result of amznTraceId:" +" "+fwTx.getAmznTraceId());
		FwLogger.log(this.getClass(), Level.INFO,"HouseholdDemographics service result of authToken:" +" "+fwTx.getAuthToken());
		FwLogger.log(this.getClass(), Level.INFO,"HouseholdDemographics service result of userAgent:" +" "+fwTx.getUserAgent());
	}

	/**
	 * Main point of input to services from the controller.
	 * 
	 * @param currentPageId
	 * @param pageAction
	 * @param payload/FwTransaction object
	 * @return PageResponse object
	 * @throws Exception
	 */
	private Object invokeServices(String pageAction, FwTransaction fwTx) throws Exception {

		PageResponse pageResponse = null;

		pageResponse = logicService.processLogic(fwTx);

		return pageResponse;
	}
}
