package gov.state.nextgen.householddemographics.business.rules;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.data.db2.IndividualInformationRepo;

@Component
public class LivingArrangementBO extends HouseHoldBaseBO {

    protected IndividualInformationRepo individualInformationRepo;

    /**
     *
     * @param indvUpdtColl
     */
    public void storeLivingArrangementDetails(APP_INDV_Collection indvUpdtColl) {
    }

    /**
     * Load Individual living arrangement details.
     * @param appNum
     * @param indvSeqNum
     * @return
     */
    public APP_INDV_Collection loadIndvLivingArrangementDetails(String appNum, String indvSeqNum) {
        APP_INDV_Collection indvLiveChgColl = new APP_INDV_Collection();
        APP_INDV_Cargo app_indv_cargo =  getAppIndvCargo(individualInformationRepo.findByAppNumAndIndvSeqNum(Integer.parseInt(appNum),indvSeqNum));
        indvLiveChgColl.addCargo(app_indv_cargo);
        return indvLiveChgColl;
    }

    /**
     * Load Move out collection.
     * @param appNum
     * @return
     */
    public APP_INDV_Collection loadMoveOutCollection(String appNum) {
        APP_INDV_Collection indvCollection = new APP_INDV_Collection();
        List<APP_INDV_Cargo> appIndvCargos = getAppIndvCargos(individualInformationRepo.findAllByAppNumAndLeftHomeReasonCdIn(Integer.parseInt(appNum), Arrays.asList(new String[]{"SEL"})));
        indvCollection.setResults(appIndvCargos.toArray(new APP_INDV_Cargo[appIndvCargos.size()]));
        return indvCollection;
    }
}
