/**
 * 
 */
package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.repository.CrudRepository;

import gov.state.nextgen.householddemographics.business.entities.CpAppUserCargo;



/**
 * @author rudeshmukh
 *
 */
public interface CpAppUserRepository extends CrudRepository<CpAppUserCargo, Long> {
	
	public CpAppUserCargo[] findByIdAcsId(String acsId);
}
