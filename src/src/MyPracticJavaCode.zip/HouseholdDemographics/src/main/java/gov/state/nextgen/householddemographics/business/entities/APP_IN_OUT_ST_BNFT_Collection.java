package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_IN_OUT_ST_BNFT_Collection extends AbstractCollection{
	
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.nonfinancialinformation.business.entities.APP_IN_OUT_ST_BNFT";


	public void addCargo(final APP_IN_OUT_ST_BNFT_Cargo newCargo) {
		add(newCargo);
	}

	/**
	 * Returns the package name.
	 *
	 * @return gov.state.nextgen.access.business.entities.APP_IN_DC_E_Collection
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}
	/**
	 * Returns cargo.
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @return java.lang.String
	 */
	public APP_IN_OUT_ST_BNFT_Cargo getCargo() {
		if (size() == 0) {
			add(new APP_IN_OUT_ST_BNFT_Cargo());
		}
		return (APP_IN_OUT_ST_BNFT_Cargo) get(0);
	}

	// EDSP CP starts
	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_OUT_ST_BNFT_Cargo getCargo(final int idx) {
		return (APP_IN_OUT_ST_BNFT_Cargo) get(idx);
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_OUT_ST_BNFT_Cargo aCargo) {
		set(idx, aCargo);
	}

	// EDSP CP Ends

	/**
	 * Sets cargo values.
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @param newCargo
	 *            The newCargo to set
	 */

	public void setCargo(final APP_IN_OUT_ST_BNFT_Cargo newCargo) {
		if (size() == 0) {
			add(newCargo);
		} else {
			set(0, newCargo);
		}
	}

	/**
	 * Returns an abstract cargo.
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @return gov.state.nextgen.access.business.entities.AbstractCargo
	 */
	public AbstractCargo getAbstractCargo() {
		return getCargo();
	}

	/**
	 * Sets abstract cargo.
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @param cargo
	 *            The Cargo to set
	 */

	public void setAbstractCargo(final AbstractCargo cargo) {
		setCargo((APP_IN_OUT_ST_BNFT_Cargo) cargo);
	}

	/**
	 * Sets cargo array into collection.
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @param cbArray
	 *            The cbArray to set
	 */

	public void setResults(final APP_IN_OUT_ST_BNFT_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets a cargo into particular index of the collection
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @param cb
	 *            The cbarray to set
	 * @param idx
	 *            The idx to set
	 */

	public void setResults(final int idx, final APP_IN_OUT_ST_BNFT_Cargo cb) {
		set(idx, cb);
	}

	/**
	 * Sets a cargo into particular index of the collection
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @param obj
	 *            The cbarray to set
	 */

	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_OUT_ST_BNFT_Cargo[]) {
			final APP_IN_OUT_ST_BNFT_Cargo[] cbArray = (APP_IN_OUT_ST_BNFT_Cargo[]) obj;
			for (int i = 0; i < cbArray.length; i++) {
				add(cbArray[i]);
			}
		}
	}

	/**
	 * Returns cargo array.
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @return
	 *         gov.state.nextgen.access.business.entities.APP_IN_DC_E_Collection[
	 *         ]
	 */
	public APP_IN_OUT_ST_BNFT_Cargo[] getResults() {
		final APP_IN_OUT_ST_BNFT_Cargo[] cbArray = new APP_IN_OUT_ST_BNFT_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * Returns a particular cargo.
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @return gov.state.nextgen.access.business.entities.APP_IN_DC_E_Collection
	 */
	public APP_IN_OUT_ST_BNFT_Cargo getResult(final int idx) {
		return (APP_IN_OUT_ST_BNFT_Cargo) get(idx);
	}

	/**
	 * Returns size of a collection.
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @return int
	 */
	public int getResultsSize() {
		return size();
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_OUT_ST_BNFT_Cargo[] cloneResults() {
		final APP_IN_OUT_ST_BNFT_Cargo[] rescargo = new APP_IN_OUT_ST_BNFT_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_OUT_ST_BNFT_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_OUT_ST_BNFT_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setCurr_rcv_out_of_st_bnft_ind(cargo.getCurr_rcv_out_of_st_bnft_ind());
			rescargo[i].setOut_of_st_bnft_sta_cd(cargo.getOut_of_st_bnft_sta_cd());
			rescargo[i].setRcv_out_of_st_bnft_date(cargo.getRcv_out_of_st_bnft_date());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setOut_of_st_bnft_cd(cargo.getOut_of_st_bnft_cd());
			rescargo[i].setChg_dt(cargo.getChg_dt());
			rescargo[i].setDirty(cargo.isDirty());
		}
		return rescargo;
	}



}
