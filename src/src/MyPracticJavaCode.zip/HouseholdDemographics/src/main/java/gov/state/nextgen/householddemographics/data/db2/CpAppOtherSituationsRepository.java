package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_OTHER_SITUATIONS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_OTHER_SITUATIONS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_OTHER_SITUATIONS_Key;
@Repository
public interface CpAppOtherSituationsRepository extends CrudRepository<CP_APP_OTHER_SITUATIONS_Cargo, CP_APP_OTHER_SITUATIONS_Key> {

	@Query("select c from CP_APP_OTHER_SITUATIONS_Cargo c where c.app_number = ?1")
	public CP_APP_OTHER_SITUATIONS_Collection getByAppNum(Integer appnum);
	
}
