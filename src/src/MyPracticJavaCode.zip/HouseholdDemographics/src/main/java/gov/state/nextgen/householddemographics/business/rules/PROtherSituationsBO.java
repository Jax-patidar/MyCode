package gov.state.nextgen.householddemographics.business.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_OTHER_SITUATIONS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_OTHER_SITUATIONS_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppOtherSituationsRepository;

@Service("PROtherSituationsBO")
public class PROtherSituationsBO extends AbstractBO{
	
	@Autowired
	private CpAppOtherSituationsRepository cpAppOtherSituationsRepository;

	public CP_APP_OTHER_SITUATIONS_Collection getByAppNum(String appnum) {
		return cpAppOtherSituationsRepository.getByAppNum(Integer.parseInt(appnum));
	}

	public void storeOtherSituations(CP_APP_OTHER_SITUATIONS_Collection otherSituationsSaveColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"PROtherSituationsBO.storeOtherSituations() - START, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		try {
			  if (otherSituationsSaveColl != null && !otherSituationsSaveColl.isEmpty()) {
					CP_APP_OTHER_SITUATIONS_Cargo cargo = new CP_APP_OTHER_SITUATIONS_Cargo();
	     			cargo = otherSituationsSaveColl.getCargo(0);
	     			cpAppOtherSituationsRepository.save(cargo);
			    }
            } catch (final FwException fe) {
            		throw fe;
            } catch (final Exception e) {
			        throw e;
            }
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"PROtherSituationsBO.storeOtherSituations() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
	
		
	}

}
