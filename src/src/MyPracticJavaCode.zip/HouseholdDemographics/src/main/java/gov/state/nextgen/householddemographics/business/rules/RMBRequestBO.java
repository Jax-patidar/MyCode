package gov.state.nextgen.householddemographics.business.rules;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.RMBRqstRepository;

@Service
public class RMBRequestBO extends AbstractBO {
	
	@Autowired
	RMBRqstRepository rmbRqstRepo;
	
	public RMB_RQST_Cargo createRMBRequest(final String appNumber, final String caseNumber) {
		try {
			final RMB_RQST_Cargo rmbRequestCargo = new RMB_RQST_Cargo();
			final RMB_RQST_Collection coll = new RMB_RQST_Collection();
			rmbRequestCargo.setSsp_app_num(Integer.parseInt(appNumber));
			rmbRequestCargo.setCase_num(caseNumber);
			rmbRequestCargo.setStat_cd(AppConstants.AFB_SUBMISSION_PENDING);
			rmbRequestCargo.setEcf_stat_cd(AppConstants.PDF_STORING_PENDING);
			rmbRequestCargo.setPdf_lang_cd(AppConstants.EMPTY_STRING);
			rmbRequestCargo.setApp_typ(AppConstants.RMB);
			rmbRequestCargo.setDue_dt(HouseHoldDemoGraphicsConstants.HIGH_DATE_VALUE);
			rmbRequestCargo.setAdr_chg_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setAset_xfer_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setBury_aset_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setDpnd_care_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setDabl_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setDrug_feln_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setEmpl_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setHelp_othr_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setHshl_chg_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setHous_bill_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setIrwe_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setIknd_incm_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setLi_aset_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setLqd_aset_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setMapp_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setMed_bills_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setMed_cvrg_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setOthr_incm_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setPrsn_add_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setPrsn_move_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setPrsn_prop_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setPreg_chg_stat_ind(FwConstants.HIDDEN);
			// NextGen NG-6481 Phase 3 updates to ACA Streamline changes â€“ start (H)
			rmbRequestCargo.setTax_deduct_stat_ind(FwConstants.HIDDEN);
			// NextGen NG-6481 Phase 3 updates to ACA Streamline changes â€“ end (H)
			rmbRequestCargo.setReal_aset_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setRcnt_acdt_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setRoom_brd_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setSchl_enrl_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setSelf_empl_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setSprt_oblg_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setTrb_cmdy_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setUtil_bill_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setVeh_aset_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setLqd_aset_add_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setLi_aset_add_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setBury_aset_add_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setReal_aset_add_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setVeh_aset_add_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setPast_cvrg_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setFee_rqr_ind(FwConstants.NO);
			rmbRequestCargo.setCla_due_dt(HouseHoldDemoGraphicsConstants.HIGH_DATE_VALUE);
			// EDSP CP adding default
			rmbRequestCargo.setHead_of_household_stat_ind(FwConstants.EMPTY_STRING);
			rmbRequestCargo.setParole_violation_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setHealth_insurance_chg_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setMedicare_assist_req_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setLiquid_asset_bank_acc_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setLiquid_asset_cash_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setLiquid_asset_other_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setAset_xfer_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setCurrent_past_pndg_stat_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setSnap_shelter_standard_exp_ind(FwConstants.HIDDEN);
			rmbRequestCargo.setApp_end_dt(HouseHoldDemoGraphicsConstants.HIGH_DATE_VALUE);
			Timestamp currentTimeStamp = new Timestamp(new Date().getTime());
			rmbRequestCargo.setCreate_dt(currentTimeStamp);

			rmbRequestCargo.setChild_care_stat_ind(FwConstants.HIDDEN);
			//NextGen NG-6481 Updates to ACA Streamline changes - NG-6540 Development of Bills - Before Tax Deductions pages - AFB/RMC/RMB : Start
			rmbRequestCargo.setBefore_tax_deduction_ind(FwConstants.HIDDEN);
			//NextGen NG-6481 Updates to ACA Streamline changes - NG-6540 Development of Bills - Before Tax Deductions pages - AFB/RMC/RMB : End
			// EDSP RMB
			rmbRequestCargo.setAuthorized_represent_stat_ind(FwConstants.HIDDEN);
			
			return rmbRequestCargo;
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(), "createRMBRequest", e);
		}
	}

	public RMB_RQST_Collection fetchRMBRqstInfoByAppNum(String appNum) {
		try {
			return rmbRqstRepo.findByAppNum(Integer.parseInt(appNum));
		}catch (final Exception e) {
			throw createFwException(this.getClass().getName(), "fetchRMBRqstInfoByAppNum", e);
		}
	}
}
