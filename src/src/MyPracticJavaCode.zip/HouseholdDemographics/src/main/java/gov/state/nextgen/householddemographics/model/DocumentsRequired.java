package gov.state.nextgen.householddemographics.model;

import java.util.List;

public class DocumentsRequired {
	
	
	private String document_type;
	
	private List<Integer> indv_seq_num;
	

	public String getDocument_type() {
		return document_type;
	}

	public void setDocument_type(String document_type) {
		this.document_type = document_type;
	}

	public List<Integer> getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(List<Integer> indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	
	
	
	

}
