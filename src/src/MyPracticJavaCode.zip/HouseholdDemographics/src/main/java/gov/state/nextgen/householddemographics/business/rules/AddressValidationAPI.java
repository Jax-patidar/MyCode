package gov.state.nextgen.householddemographics.business.rules;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.Address_Validate_Custom_Cargo;

@Service("AddressValidationAPI")
public class AddressValidationAPI extends AbstractBO {

	@Autowired
	private RestTemplate restTemplate;

	public Address_Validate_Custom_Cargo callPostAddressValidationRequest(
			Address_Validate_Custom_Cargo addrsValidateRequest) throws FwException {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"AddressValidationAPI.callPostAddressValidationRequest() - START");

		Address_Validate_Custom_Cargo addrsValidateResponse = null;
		try {

			String uri = "https://reqres.in/api/users";

			restTemplate = new RestTemplate();
			// create request body
			StringBuilder sb = new StringBuilder("{\"options\": {"
					+ "			        \"OutputCasing\": \"M\"\r\n"
					+ "			    },\r\n"
					+ "			    \"Input\": {\r\n"
					+ "			        \"Row\": [\r\n"
					+ "			            {");
			sb.append("\"AddressLine1\": \""+(addrsValidateRequest.getAddressLine1() != null ? addrsValidateRequest.getAddressLine1():"")+"\"");
			sb.append("\"AddressLine2\": \""+(addrsValidateRequest.getAddressLine2()!= null ? addrsValidateRequest.getAddressLine2():"")+"\"");
			sb.append("\"City\": \""+addrsValidateRequest.getCity()+"\"");
			sb.append("\"Country\": \""+addrsValidateRequest.getCountry()+"\"");
			sb.append("\"StateProvince\": \""+addrsValidateRequest.getStateProvince()+"\"");
			sb.append("\"PostalCode\": \""+addrsValidateRequest.getPostalCode()+"\"");
			sb.append("\"FirmName\": \""+addrsValidateRequest.getFirmName()+"\"}]}}");
			
			String requestJSON1 = "{\"name\": \"Pricely\", \"job\": \"API\"}";
			String requestJSON = sb.toString();
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Request JSON is ::" + requestJSON);

			// set headers
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> requestEntity = new HttpEntity<String>(requestJSON1, headers);

			// send request and parse result
			ResponseEntity<Map> responseEntity = restTemplate.postForEntity(uri, requestEntity, Map.class);
			addrsValidateResponse = new Address_Validate_Custom_Cargo();
			if (responseEntity.getStatusCode() == HttpStatus.OK
					|| responseEntity.getStatusCode().equals(HttpStatus.CREATED)) {
				addrsValidateResponse.setAddressLine1("1186 Roseville Pkwy");
				addrsValidateResponse.setAddressLine2("");
				addrsValidateResponse.setCity("Roseville");
				addrsValidateResponse.setStateProvince("CA");
				addrsValidateResponse.setCountry("United States of America");
				addrsValidateResponse.setPostalCode("95678");
			} else if (responseEntity.getStatusCode() == HttpStatus.UNAUTHORIZED
					|| responseEntity.getStatusCode() == HttpStatus.BAD_REQUEST
					|| responseEntity.getStatusCode() == HttpStatus.INTERNAL_SERVER_ERROR
					|| responseEntity.getStatusCode() == HttpStatus.NOT_IMPLEMENTED
					|| responseEntity.getStatusCode() == HttpStatus.SERVICE_UNAVAILABLE) {
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, responseEntity.getStatusCode().toString());
				addrsValidateResponse.setExceptionCode(responseEntity.getStatusCodeValue());
				addrsValidateResponse.setExceptionDescription("No Data Returned");
			}
		} catch (FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"AddressValidationAPI.callPostAddressValidationRequest() - END");

		return addrsValidateResponse;

	}
}
