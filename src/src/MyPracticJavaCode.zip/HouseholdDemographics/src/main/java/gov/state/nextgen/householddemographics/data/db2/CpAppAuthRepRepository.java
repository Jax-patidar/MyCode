package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Key;

@Repository
public interface CpAppAuthRepRepository extends CrudRepository<CP_APP_AUTH_REP_Cargo, CP_APP_AUTH_REP_Key> {
	@Query("select c from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1")
	public CP_APP_AUTH_REP_Collection getByAppNum(Integer appNum);

	@Query("select c from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1 and c.seq_num = ?2 and c.rep_code = ?3")
	public CP_APP_AUTH_REP_Collection getByAppNum_SeqNum_RepCode(Integer appNum, String seqNum, String repCode);

	@Query("select c from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1 and c.seq_num = ?2 and c.rep_code = ?3")
	public CP_APP_AUTH_REP_Collection getCalfreshDetails(Integer appNum, int seqNum, String repCode);

	@Query("select c from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1 and c.rep_code = ?2")
	public CP_APP_AUTH_REP_Collection getByAppNum_RepCode(Integer appNum, String repCode);

	@Query("select max(c.seq_num) from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.rep_code = ?3")
	public Integer getMaxSeqNum(Integer appNum, String srcAppInd, String repCode);

	@Query("select c from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.rep_code = ?3")
	public CP_APP_AUTH_REP_Collection getBeforeColl(Integer appNum, String srcAppInd, String repCode);

	@Query("select c from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.snap_auth_rep_ind = ?3 and (c.authRepMedInd = 'Y' or c.authRepMedInd = null)")
	public CP_APP_AUTH_REP_Collection getCalfreshAuthRep(Integer appNum, String srcAppInd, String snapAuthRepInd);

	@Query("select c from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.auth_rep_medical_assist_ind = ?3")
	public CP_APP_AUTH_REP_Collection getMediCalAuthRep(Integer appNum, String srcAppInd, String medicalAuthRepInd);

	@Query("select c from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.snap_auth_rep_ind = ?3 and c.auth_rep_medical_assist_ind = ?4")
	public CP_APP_AUTH_REP_Collection getCalFreshAndMediCalAuthRepColl(Integer appNum, String srcAppInd,
			String snapAuthRepInd, String medicalAuthRepInd);

	@Query("select c from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.snap_auth_rep_ind = ?3 and c.authRepMedInd = 'N' ")
	public CP_APP_AUTH_REP_Collection getBeneficiaryRep(Integer appNumber, String src_app_ind, String snapAuthRepInd);

	@Query("select c from CP_APP_AUTH_REP_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.snap_auth_rep_ind is null and c.authRepMedInd = 'N' ")
	public CP_APP_AUTH_REP_Collection getBeneficiaryRepSnapAuthNull(Integer appNumber, String src_app_ind);

	
}
