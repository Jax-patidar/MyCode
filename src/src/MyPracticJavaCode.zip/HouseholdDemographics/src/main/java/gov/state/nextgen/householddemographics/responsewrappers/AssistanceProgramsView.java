package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_INST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_INST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABPRI")
@Scope("prototype")
public class AssistanceProgramsView implements LogicResponseInterface {

	
	private static final String APP_RGST_COLLECTION = "APP_RGST_Collection";
	private static final String APP_RQST_COLLECTION = "APP_RQST_Collection";
	private static final String APP_PGM_RQST_COLLECTION = "APP_PGM_RQST_Collection";
	private static final String PAGE_ID = "ABPRI";

	@Override
	public PageResponse constructPageResponse(FwTransaction txBean) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = txBean.getPageCollection();
		
		List<APP_RQST_Cargo> appRqstCargoList = new ArrayList<APP_RQST_Cargo>();
		APP_RQST_Cargo appRqstCargo = new APP_RQST_Cargo();
		APP_RQST_Collection appRqstColl = pageCollection.get("APP_RQST_Collection") != null ? (APP_RQST_Collection)pageCollection.get("APP_RQST_Collection") : null;
		if(appRqstColl != null) {
			appRqstCargo = (APP_RQST_Cargo) appRqstColl.get(0);
		}
		appRqstCargoList.add(appRqstCargo);
		
		List<APP_PGM_RQST_Cargo> appPgmRqstCargoList = new ArrayList<APP_PGM_RQST_Cargo>();
		APP_PGM_RQST_Cargo appPgmRqstCargo = new APP_PGM_RQST_Cargo();
		APP_PGM_RQST_Collection appPgmRqstColl = pageCollection.get("APP_PGM_RQST_Collection") != null ? (APP_PGM_RQST_Collection)pageCollection.get("APP_PGM_RQST_Collection") : null;
		if(appPgmRqstColl != null) {
			appPgmRqstCargo = (APP_PGM_RQST_Cargo) appPgmRqstColl.get(0);
		}
		appPgmRqstCargoList.add(appPgmRqstCargo);
		
		APP_RGST_Cargo appRgstCargo = new APP_RGST_Cargo();
		List<APP_RGST_Cargo> appRgstCargoList = new ArrayList<APP_RGST_Cargo>();
		APP_RGST_Collection appRgstColl = (APP_RGST_Collection) pageCollection.get(APP_RGST_COLLECTION);
		if(appRgstColl != null) {
			appRgstCargo = (APP_RGST_Cargo) appRgstColl.get(0);
		}
		appRgstCargoList.add(appRgstCargo);
		driverPageResponse.getPageCollection().put(APP_RGST_COLLECTION, appRgstCargoList);
		driverPageResponse.getPageCollection().put(APP_RQST_COLLECTION, appRqstCargoList);
		driverPageResponse.getPageCollection().put(APP_PGM_RQST_COLLECTION, appPgmRqstCargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(txBean.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(txBean.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(txBean.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(txBean.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		
		return driverPageResponse;
	}

}
