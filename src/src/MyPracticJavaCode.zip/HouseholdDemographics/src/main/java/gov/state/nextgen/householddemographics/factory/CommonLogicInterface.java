package gov.state.nextgen.householddemographics.factory;

import gov.state.nextgen.householddemographics.model.PageResponse;
import gov.state.nextgen.access.business.entities.FwTransaction;

/**
 * Interface for Household demographics CommonLogicImpl.
 * 
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

public interface CommonLogicInterface {
	
	public PageResponse processLogic(FwTransaction fwTxn) throws Exception;
	
}
