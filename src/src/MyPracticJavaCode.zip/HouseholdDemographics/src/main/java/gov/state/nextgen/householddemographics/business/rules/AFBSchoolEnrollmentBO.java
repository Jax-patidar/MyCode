package gov.state.nextgen.householddemographics.business.rules;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CpAppInSchleRepository;

@Service
public class AFBSchoolEnrollmentBO extends AbstractBO{

	@Autowired
	private CpAppInSchleRepository schRepo;
	
	/**
	 * loads data from table for the given params for school enrollment
	 * 
	 * @param appNum
	 * @param indv_seq_num
	 * @param src_app_ind
	 * @param seq_num 
	 * @return APP_IN_SCHLE_Collection
	 */
	public APP_IN_SCHLE_Collection loadSchoolEnrollment(String appNum, Integer indv_seq_num, String src_app_ind, Integer seq_num) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AFBSchoolEnrollmentBO.loadSchoolEnrollment() - START");
        try {
        	APP_IN_SCHLE_Collection appInSchColl = new APP_IN_SCHLE_Collection();
        	if(appNum != null && indv_seq_num != null) {
        		APP_IN_SCHLE_Cargo[] appInSchCargoArray = schRepo.getAllDetails(Integer.parseInt(appNum), indv_seq_num, src_app_ind, seq_num);
        		if (appInSchCargoArray.length > 0) {
        			appInSchColl.setResults(appInSchCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AFBSchoolEnrollmentBO.loadSchoolEnrollment() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInSchColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(getClass().getName(),
                    "", e);
        }
	}
	
	public void storeSchoolDetails(APP_IN_SCHLE_Cargo appInSchCargo) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AFBSchoolEnrollmentBO.storeSchoolEnrollmentDetails() - START");
        try {  	
        	 schRepo.save(appInSchCargo);
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AFBSchoolEnrollmentBO.storeSchoolEnrollmentDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(getClass().getName(),
                    "storeSchoolEnrollmentDetails", e);
        }
	}
	
	public APP_IN_SCHLE_Collection getAllClgDetails(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.loadSchoolEnrollment() - START");
        try {
        	APP_IN_SCHLE_Collection appInSchColl = new APP_IN_SCHLE_Collection();
        	if(appNum != null) {
        		APP_IN_SCHLE_Cargo[] appInSchCargoArray = schRepo.getAllClgDetails(Integer.parseInt(appNum), indvIds);
        		if (appInSchCargoArray.length > 0) {
        			appInSchColl.setResults(appInSchCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.loadSchoolEnrollment() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInSchColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	public void deleteSchoolEnrollment(String appNum, Integer indvSeqNumber, Integer seq_num) {
		schRepo.deleteSchoolEnrollment(Integer.parseInt(appNum), indvSeqNumber,seq_num);
	}
	
	public void deleteSchoolDetails(String appNum, Integer indvSeqNumber, Integer seq_num, String schoolType) {
		schRepo.deleteSchoolDetails(Integer.parseInt(appNum), indvSeqNumber,seq_num,schoolType);
	}
	
	/**
	 * validate the data for school enrollment
	 * 
	 * @param appInSchCargo
	 * @return
	 */
	public FwMessageList validateSchoolEnrollmentDetails(APP_IN_SCHLE_Cargo appInSchCargo) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.loadSchoolEnrollment() - START");
        try {
        	FwMessageList messageList = new FwMessageList();
        	final char[] specialChars = { '(', '.', '-', '\'', ')' };
        	final char[] specialCharsForAddress = { '-', '\'', '.', '#', '/', ',' , '&', ' '};
        	
        	if(appMgr.isFieldEmpty(appInSchCargo.getEnrl_stat_cd())) {
        		messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_90923));
        	}
        	
        	if(!appMgr.isFieldEmpty(appInSchCargo.getEnrl_stat_cd()) && !((HouseHoldDemoGraphicsConstants.NE).equals(appInSchCargo.getEnrl_stat_cd()))) {
        		
        		validateGradStat(appInSchCargo, messageList);
        		
        		validateSchoolAddr(appInSchCargo, messageList, specialCharsForAddress);
    			validateSchoolZip(appInSchCargo, messageList, specialChars);
    			if (!messageList.containsMessage(HouseHoldDemoGraphicsConstants.MSG_00019)
    					&& appInSchCargo.getAddr_zip4() != null
    					&& !((HouseHoldDemoGraphicsConstants.SPACES).equals(appInSchCargo.getAddr_zip4().trim()))){
    				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00019));
    			}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.loadSchoolEnrollment() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return messageList;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}

	private void validateSchoolZip(APP_IN_SCHLE_Cargo appInSchCargo, FwMessageList messageList,
			final char[] specialChars) {
		if (!appMgr.isFieldEmpty(appInSchCargo.getSchool_name())
				&& !appMgr.isSpecialAlphaNumeric(
						appInSchCargo.getSchool_name(), specialChars)) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00211));
		}

		if (!appMgr.isInteger(appInSchCargo.getSchool_zip_adr())) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00019));
		} else if (!appMgr.isFieldEmpty(appInSchCargo.getSchool_zip_adr())
				&& !(appInSchCargo.getSchool_zip_adr().length() == 5)) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10503));
		} else if (HouseHoldDemoGraphicsConstants.ZERO_5.equals(appInSchCargo.getSchool_zip_adr())
				|| HouseHoldDemoGraphicsConstants.ZERO_9.equals(appInSchCargo.getSchool_zip_adr())) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00022));
		}
	}

	private void validateSchoolAddr(APP_IN_SCHLE_Cargo appInSchCargo, FwMessageList messageList,
			final char[] specialCharsForAddress) {
		if (!appMgr.isFieldEmpty(appInSchCargo.getSchool_l1_adr())
				&& !appMgr.isSpecialAlphaNumeric(appInSchCargo.getSchool_l1_adr(),specialCharsForAddress)) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00017));
		}
		
		if (!appMgr.isFieldEmpty(appInSchCargo.getSchool_l2_adr())
				&& !appMgr.isSpecialAlphaNumeric(appInSchCargo.getSchool_l2_adr(),specialCharsForAddress)) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00017));
		}

		if (!appMgr.isFieldEmpty(appInSchCargo.getSchool_city_adr())
				&& !appMgr.isAlphaWithSpace(appInSchCargo.getSchool_city_adr())) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00018));
		}
	}

	private void validateGradStat(APP_IN_SCHLE_Cargo appInSchCargo, FwMessageList messageList) {
		if (appInSchCargo.getHs_grad_stat_cd() == null
				|| FwConstants.DEFAULT_DROPDOWN_SEL
				.equals(appInSchCargo.getHs_grad_stat_cd())) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00208));
		}
		
		if(!(HouseHoldDemoGraphicsConstants.PE.equals(appInSchCargo.getHs_grad_stat_cd()))
				&& !(HouseHoldDemoGraphicsConstants.EM.equals(appInSchCargo.getHs_grad_stat_cd()))
				&& !(HouseHoldDemoGraphicsConstants.MS.equals(appInSchCargo.getHs_grad_stat_cd()))
				&& !(HouseHoldDemoGraphicsConstants.HS.equals(appInSchCargo.getHs_grad_stat_cd()))
				&& appMgr.isFieldEmpty(appInSchCargo.getWork_stdy_ind())) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00210));
		}
		
		if (appInSchCargo.getHs_grad_dt() != null) {
			if (!appMgr.validateDate(appInSchCargo.getHs_grad_dt())) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_90497));
			}
			if (appMgr.futureDate(appInSchCargo.getHs_grad_dt())) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_80670));
			}
		}
	}
	
	/**
	 * load the school enrollment details based on appNumber and individual sequence number
	 * 
	 * @param appNum
	 * @param indv_seq_num
	 * @return
	 */
	public APP_IN_SCHLE_Collection loadEnrollmentDtls(String appNum, Integer indv_seq_num) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.loadEnrollmentDtls() - START");
        try {
        	APP_IN_SCHLE_Collection appInSchColl = new APP_IN_SCHLE_Collection();
        	if(appNum != null && indv_seq_num != null) {
        		appInSchColl = schRepo.getAllDtls(Integer.parseInt(appNum), indv_seq_num);
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.loadEnrollmentDtls() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInSchColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	
	/**
	 * presist data into db
	 * 
	 * @param appInSchColl
	 */
	public void storeSchoolEnrollmentDetails(APP_IN_SCHLE_Collection appInSchColl) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.storeSchoolEnrollmentDetails() - START");
        try {  	
        	if ((appInSchColl != null) && (!appInSchColl.isEmpty()) && (appInSchColl.size() > 0)){
        		APP_IN_SCHLE_Cargo schlCargo = appInSchColl.getCargo(0);
                schRepo.save(schlCargo);
            }
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.storeSchoolEnrollmentDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	
	/**
	 * @param appNum
	 * @param indv_seq_num
	 * @return
	 */
	public APP_IN_SCHLE_Collection loadCollegeEnrollment(String appNum, String schoolTypeCd, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.loadCollegeEnrollment() - START");
        try {
        	APP_IN_SCHLE_Collection appInClgColl = new APP_IN_SCHLE_Collection();
        	if(appNum != null) {
        		APP_IN_SCHLE_Cargo[] appInClgCargoArray  = schRepo.getAllSchoolDetails(Integer.parseInt(appNum), schoolTypeCd, indvIds);
        		if (null != appInClgCargoArray && appInClgCargoArray.length > 0) {
        			for(APP_IN_SCHLE_Cargo cargo : appInClgCargoArray) {
        				cargo.setInfoChangeDt(cargo.getChg_dt());
        			}
        			appInClgColl.setResults(appInClgCargoArray);
        			
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.loadCollegeEnrollment() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInClgColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
		
	public APP_IN_SCHLE_Collection loadCollegeEnrollmentDetails(String appNum) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.loadCollegeEnrollmentDetails() - START");
        try {
        	APP_IN_SCHLE_Collection appInClgColl = new APP_IN_SCHLE_Collection();
        	if(appNum != null) {
        		APP_IN_SCHLE_Cargo[] appInClgCargoArray  = schRepo.loadCollegeTradeSchoolDetails(Integer.parseInt(appNum));
        		if (null != appInClgCargoArray && appInClgCargoArray.length > 0) {
        			for(APP_IN_SCHLE_Cargo cargo : appInClgCargoArray) {
        				cargo.setInfoChangeDt(cargo.getChg_dt());
        			}
        			appInClgColl.setResults(appInClgCargoArray);
        			
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSchoolEnrollmentBO.loadCollegeEnrollmentDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    + " milliseconds");
        	
    		return appInClgColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
}
