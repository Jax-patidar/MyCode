package gov.state.nextgen.householddemographics.responsewrappers;

import gov.state.nextgen.access.management.references.IReferenceConstants;
import gov.state.nextgen.access.management.references.IReferenceTableData;
import gov.state.nextgen.access.management.references.ReferenceTableManager;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Base view holding common data in between different viewWrappers.
 */
public abstract class BaseView implements LogicResponseInterface {

    private static final String CODE_COLUMN_ID = "-999";
    private static final String DEFAULT_DROPDOWN_SEL = "SEL";

    @Autowired
    private ReferenceTableManager referenceTableManager;

    /**
     * getRelaventRelationshipCodes
     * @param filterColumnId
     * @param filterValue
     * @param language
     * @return
     */
    protected List<String> getRelevantRelationshipCodes(int[] filterColumnId, String[] filterValue, String language) {
        IReferenceTableData refData = null;

        List<String> relaventRelationShipCodes = new ArrayList<>();

        if (filterColumnId != null) {
            if (filterColumnId.length == 1) {
                refData = referenceTableManager.filterDataOnSingleColumn("TREL", language, filterColumnId[0], IReferenceConstants.FILTER_EXCLUDE_MATCH_ONE, filterValue);

            } else {
                refData = referenceTableManager.filterDataOnMultipleColumns("TREL", language, filterColumnId,IReferenceConstants.FILTER_EXCLUDE_MATCH_ONE, filterValue);
            }

        } else {
            refData = referenceTableManager.getReferenceTableData("TREL", language);
        }

        List<Map<Integer, String>> referenceTableData = refData.getData();

        for (int i = 0; i < referenceTableData.size(); i++) {
            Map<Integer, String> referenceTableEntry = referenceTableData.get(i);
            for (Map.Entry<Integer, String> entry : referenceTableEntry.entrySet()) {
                StringBuilder key = new StringBuilder().append(entry.getKey()); //"Typecasting issue" in converting response data, Will later remove StringBuilder.
                String value = entry.getValue().toString();
                if (key.toString().equals(CODE_COLUMN_ID) ) {
                    if (!DEFAULT_DROPDOWN_SEL.equalsIgnoreCase(value)) {
                        relaventRelationShipCodes.add(value);
                    }
                }
            }
        }
        return relaventRelationShipCodes;
    }

}
