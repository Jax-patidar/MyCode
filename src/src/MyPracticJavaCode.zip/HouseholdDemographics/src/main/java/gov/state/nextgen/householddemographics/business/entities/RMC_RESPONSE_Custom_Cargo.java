package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

public class RMC_RESPONSE_Custom_Cargo implements Serializable {


    private static final long serialVersionUID = 2949390991213034226L;

    private String indvSeqNum;

    private String seqNum;

    private String response;

    private String categoryType;

    private String changeSelectionCategoryCd;

    private String userEndSelectionInd;

    public String getIndvSeqNum() {
        return indvSeqNum;
    }

    public void setIndvSeqNum(String indvSeqNum) {
        this.indvSeqNum = indvSeqNum;
    }

    public String getSeqNum() {
        return seqNum;
    }

    public void setSeqNum(String seqNum) {
        this.seqNum = seqNum;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getCategoryType() {
        return categoryType;
    }

    public void setCategoryType(String categoryType) {
        this.categoryType = categoryType;
    }

    public String getChangeSelectionCategoryCd() {
        return changeSelectionCategoryCd;
    }

    public void setChangeSelectionCategoryCd(String changeSelectionCategoryCd) {
        this.changeSelectionCategoryCd = changeSelectionCategoryCd;
    }

    public String getUserEndSelectionInd() {
        return userEndSelectionInd;
    }

    public void setUserEndSelectionInd(String userEndSelectionInd) {
        this.userEndSelectionInd = userEndSelectionInd;
    }
}
