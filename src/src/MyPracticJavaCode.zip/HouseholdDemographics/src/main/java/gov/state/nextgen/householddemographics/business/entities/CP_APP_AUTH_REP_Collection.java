/*
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class acts as a wrapper for one or many cargos of CP_APP_AUTH_REP
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Sept 20 13:57:20 CST 2011 Modified By: Modified on: PCR#
 */
public class CP_APP_AUTH_REP_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.CP_APP_AUTH_REP";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CP_APP_AUTH_REP_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CP_APP_AUTH_REP_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	public CP_APP_AUTH_REP_Cargo getResult(final int idx) {
		return (CP_APP_AUTH_REP_Cargo) get(idx);
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CP_APP_AUTH_REP_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CP_APP_AUTH_REP_Cargo[] getResults() {
		final CP_APP_AUTH_REP_Cargo[] cbArray = new CP_APP_AUTH_REP_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CP_APP_AUTH_REP_Cargo getCargo(final int idx) {
		return (CP_APP_AUTH_REP_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public CP_APP_AUTH_REP_Cargo[] cloneResults() {
		final CP_APP_AUTH_REP_Cargo[] rescargo = new CP_APP_AUTH_REP_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_APP_AUTH_REP_Cargo cargo = getCargo(i);
			rescargo[i] = new CP_APP_AUTH_REP_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setRep_code(cargo.getRep_code());
			rescargo[i].setSeq_num(cargo.getSeq_num());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setAuth_rep_nam(cargo.getAuth_rep_nam());
			rescargo[i].setAuth_rep_org_nam(cargo.getAuth_rep_org_nam());
			rescargo[i].setAuth_rep_id_num(cargo.getAuth_rep_id_num());
			rescargo[i].setL1_adr(cargo.getL1_adr());
			rescargo[i].setL2_adr(cargo.getL2_adr());
			rescargo[i].setCity_adr(cargo.getCity_adr());
			rescargo[i].setSta_adr(cargo.getSta_adr());
			rescargo[i].setZip_adr(cargo.getZip_adr());
			rescargo[i].setPhn_num(cargo.getPhn_num());
			rescargo[i].setAuth_rep_fst_nam(cargo.getAuth_rep_fst_nam());
			rescargo[i].setAuth_rep_mid_init(cargo.getAuth_rep_mid_init());
			rescargo[i].setAuth_rep_last_nam(cargo.getAuth_rep_last_nam());
			rescargo[i].setApp_start_dt(cargo.getApp_start_dt());
			rescargo[i].setAuth_rep_suffix_nam(cargo.getAuth_rep_suffix_nam());
			rescargo[i].setRel_to_auth_rep_typ_cd(cargo.getRel_to_auth_rep_typ_cd());
			rescargo[i].setAuth_rep_duty_afb_ind(cargo.getAuth_rep_duty_afb_ind());
			rescargo[i].setAuth_rep_duty_benefits_ind(cargo.getAuth_rep_duty_benefits_ind());
			rescargo[i].setAuth_rep_duty_receive_ind(cargo.getAuth_rep_duty_receive_ind());
			rescargo[i].setAuth_rep_duty_request_ind(cargo.getAuth_rep_duty_request_ind());
			rescargo[i].setAuth_rep_duty_other_ind(cargo.getAuth_rep_duty_other_ind());
			rescargo[i].setAuth_rep_info_share_ind(cargo.getAuth_rep_info_share_ind());
			rescargo[i].setAuth_rep_medical_assist_ind(cargo.getAuth_rep_medical_assist_ind());
			rescargo[i].setTanf_auth_rep_ind(cargo.getTanf_auth_rep_ind());
			rescargo[i].setSnap_auth_rep_ind(cargo.getSnap_auth_rep_ind());
			rescargo[i].setAdapt_record_id(cargo.getAdapt_record_id());
			rescargo[i].setAddr_zip4(cargo.getAddr_zip4());
			rescargo[i].setAppl_esign_ind(cargo.getAppl_esign_ind());
			rescargo[i].setAuth_rep_esign_ind(cargo.getAuth_rep_esign_ind());
			rescargo[i].setAppl_fst_nam(cargo.getAppl_fst_nam());
			rescargo[i].setAppl_last_nam(cargo.getAppl_last_nam());
			rescargo[i].setAppl_mid_init(cargo.getAppl_mid_init());
			rescargo[i].setBrg_crd_rcv_ind(cargo.getBrg_crd_rcv_ind());
			rescargo[i].setEmail_adr(cargo.getEmail_adr());
			rescargo[i].setFiling_rep_fst_nam(cargo.getFiling_rep_fst_nam());
			rescargo[i].setFiling_rep_last_nam(cargo.getFiling_rep_last_nam());
			rescargo[i].setFiling_rep_mid_nam(cargo.getFiling_rep_mid_nam());
			rescargo[i].setMa_fs_auth_rep_nam(cargo.getMa_fs_auth_rep_nam());
			rescargo[i].setPhn_extn_num(cargo.getPhn_extn_num());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setWitn_esign_ind(cargo.getWitn_esign_ind());
			rescargo[i].setWitn_fst_nam(cargo.getWitn_fst_nam());
			rescargo[i].setWitn_last_nam(cargo.getWitn_last_nam());
			rescargo[i].setWitn_mid_init(cargo.getWitn_mid_init());

			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
			rescargo[i].setAppl_esign_dt(cargo.getAppl_esign_dt());
			rescargo[i].setAuthRepMedInd(cargo.getAuthRepMedInd());
			rescargo[i].setAuth_rep_req_ind(cargo.getAuth_rep_req_ind());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_APP_AUTH_REP_Cargo[]) {
			final CP_APP_AUTH_REP_Cargo[] cbArray = (CP_APP_AUTH_REP_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}