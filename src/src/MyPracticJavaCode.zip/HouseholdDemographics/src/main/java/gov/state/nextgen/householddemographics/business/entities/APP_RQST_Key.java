package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;
@Embeddable
public class APP_RQST_Key implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer app_number;
	public APP_RQST_Key() {
		super();
		// TODO Auto-generated constructor stub
	}
	public APP_RQST_Key(Integer app_number) {
		super();
		this.app_number = app_number;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		return result;
	}
	
}
