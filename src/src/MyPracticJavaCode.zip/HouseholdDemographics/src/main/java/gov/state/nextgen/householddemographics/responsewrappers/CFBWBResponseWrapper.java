package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.Tnb4FormSpecificCargo;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("CFBWB")
@Scope("prototype")
public class CFBWBResponseWrapper implements LogicResponseInterface {

	private static final String PAGE_ID = "CFBWB";
	@SuppressWarnings("squid:S3776")
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();

		Map pageCollection = fwTxn.getPageCollection();

		/* Getting individuals */
		List<APP_INDV_Cargo> appIndvCargoList = new ArrayList<>();

		APP_INDV_Collection appIndvCollection = (APP_INDV_Collection) pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);

		if (Objects.nonNull(appIndvCollection) && !appIndvCollection.isEmpty()) {
			for (APP_INDV_Cargo indvCargo : appIndvCollection.getResults()) {
				appIndvCargoList.add(indvCargo);
			}
		}
		
		/* Getting Program Details */
		List<APP_PGM_RQST_Cargo> appPgmCargoList = new ArrayList<>();

		APP_PGM_RQST_Collection appPgmCollection = (APP_PGM_RQST_Collection) pageCollection
				.get("APP_PGM_RQST_Collection");

		if (Objects.nonNull(appPgmCollection) && !appPgmCollection.isEmpty()) {
			for (APP_PGM_RQST_Cargo pgmCargo : appPgmCollection.getResults()) {
				appPgmCargoList.add(pgmCargo);
			}
		}
		
		/* Getting RMB Request Details Details */
		List<RMB_RQST_Cargo> rmbRqstCargoList = new ArrayList<>();

		RMB_RQST_Collection rmbRqstCollection = (RMB_RQST_Collection) pageCollection
				.get("RMB_RQST_Collection");

		if (Objects.nonNull(rmbRqstCollection) && !rmbRqstCollection.isEmpty()) {
			for (RMB_RQST_Cargo pgmCargo : rmbRqstCollection.getResults()) {
				rmbRqstCargoList.add(pgmCargo);
			}
		}
		
		/* Getting App program indv Request Details Details */
		List<CP_APP_PGM_INDV_Cargo> cpAppPgmIndvCargoList = new ArrayList<>();

		CP_APP_PGM_INDV_Collection cpAppPgmCollection = (CP_APP_PGM_INDV_Collection) pageCollection
				.get("CP_APP_PGM_INDV_Collection");

		if (Objects.nonNull(cpAppPgmCollection) && !cpAppPgmCollection.isEmpty()) {
			for (CP_APP_PGM_INDV_Cargo pgmCargo : cpAppPgmCollection.getResults()) {
				cpAppPgmIndvCargoList.add(pgmCargo);
			}
		}
		
		/* Getting App program indv Request Details Details */
		List<CP_APP_RGST_Cargo> cpAppRgstCargoList = new ArrayList<>();

		CP_APP_RGST_Collection cpAppRgstCollection = (CP_APP_RGST_Collection) pageCollection
				.get("CP_APP_RGST_Collection");

		if (Objects.nonNull(cpAppRgstCollection) && !cpAppRgstCollection.isEmpty()) {
			for (CP_APP_RGST_Cargo pgmCargo : cpAppRgstCollection.getResults()) {
				cpAppRgstCargoList.add(pgmCargo);
			}
		}

		/* Getting App Number */
		String appNum = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.APP_NUM))
				? pageCollection.get(HouseHoldDemoGraphicsConstants.APP_NUM).toString()
				: null;

		/* Setting TNB4 Form Specific Data */		
		List<Tnb4FormSpecificCargo> tnb4FormData = new ArrayList<>();
		Tnb4FormSpecificCargo tnb4FormSpecificCargo = new Tnb4FormSpecificCargo();

		String caseNum = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.CASE_NUM))
				? pageCollection.get(HouseHoldDemoGraphicsConstants.CASE_NUM).toString()
				: null;
		tnb4FormSpecificCargo.setCaseNum(caseNum);

		Date tnbDueDate = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_DUE_DATE))
				&& !pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_DUE_DATE).equals("")
				? (Date)pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_DUE_DATE)
				: null;
		tnb4FormSpecificCargo.setTnbDueDate(tnbDueDate);
		
		java.time.LocalDate formDueDt = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.FORM_DUE_DT))
				&& !pageCollection.get(HouseHoldDemoGraphicsConstants.FORM_DUE_DT).equals("")
				? (java.time.LocalDate)pageCollection.get(HouseHoldDemoGraphicsConstants.FORM_DUE_DT)
				: null;
		tnb4FormSpecificCargo.setFormDueDate(formDueDt);

		Date tnbLastCertificationDate = Objects
				.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_LAST_CERTIFICATION_DATE))
				&& !pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_DUE_DATE).equals("")
						? (Date)pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_LAST_CERTIFICATION_DATE)
						: null;
		tnb4FormSpecificCargo.setTnbLastCertificationDate(tnbLastCertificationDate);

		String caseName = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.CASE_NAME))
				? pageCollection.get(HouseHoldDemoGraphicsConstants.CASE_NAME).toString()
				: null;
		tnb4FormSpecificCargo.setCaseName(caseName);

		String countyCode = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.COUNTY_CODE))
				? pageCollection.get(HouseHoldDemoGraphicsConstants.COUNTY_CODE).toString()
				: null;
		tnb4FormSpecificCargo.setCountyCode(countyCode);
		
		tnb4FormData.add(tnb4FormSpecificCargo);

		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION,
				appIndvCargoList);
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.TNB4_FORM_DATA, tnb4FormData);
		driverPageResponse.getPageCollection().put("APP_PGM_RQST_Collection",
				appPgmCargoList);
		
		driverPageResponse.getPageCollection().put("RMB_RQST_Collection",
				rmbRqstCargoList);
		driverPageResponse.getPageCollection().put("CP_APP_PGM_INDV_Collection",
				cpAppPgmIndvCargoList);
		driverPageResponse.getPageCollection().put("CP_APP_RGST_Collection",
				cpAppRgstCargoList);
		
		driverPageResponse.setAppNum(appNum);
		driverPageResponse.setCurrentPageID(PAGE_ID);

		return driverPageResponse;

	}

}
