package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.CP_AUTOMATED_SMS_Cargo;

@Repository
public interface AutomatedSMSRepository extends CrudRepository<CP_AUTOMATED_SMS_Cargo, Long>{

}
