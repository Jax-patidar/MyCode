package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABCSU")
@Scope("prototype")
public class CollegeSummaryView implements LogicResponseInterface{
	
	private static final String PAGE_ID = "ABCSU";
	
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTrxn.getPageCollection();
		List<APP_IN_SCHLE_Cargo> schoolafbList = new ArrayList<>();
		
		APP_IN_SCHLE_Collection appInSchlCollection = pageCollection.get(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION) != null ? (APP_IN_SCHLE_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION) : null;
		if (appInSchlCollection != null) {
			for (Object clgCargo : appInSchlCollection) {
				schoolafbList.add((APP_IN_SCHLE_Cargo) clgCargo);
			}
		}
		
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION, schoolafbList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getRequest().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		return driverPageResponse;
	}

}
