/**
 * 
 */
package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Key;

/**
 * @author khuskumari
 *
 */
@Repository
public interface CP_APP_RGST_Repository extends CrudRepository<CP_APP_RGST_Cargo, CP_APP_RGST_Key>{
	
	@Query("select c from CP_APP_RGST_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.indv_seq_num = ?3")
	CP_APP_RGST_Cargo loadContactInfoforAppnum(Integer appNum, String src_app_ind, Integer indv_seq_num);
	@Query("select c from CP_APP_RGST_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2")
	public  List<CP_APP_RGST_Cargo> loadContactForAppnum(Integer appNum, String src_app_ind);
	
	@Query("select c from CP_APP_RGST_Cargo c where c.app_number = ?1 and c.indv_seq_num =?2")
	public CP_APP_RGST_Cargo getCpAppRgstDetails(Integer appNumber,Integer indv_seq_num);
	
	@Query("select c from CP_APP_RGST_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2")
	CP_APP_RGST_Cargo loadDataInerPerfforAppNumAndSrcAppInd(Integer appNum, String src_app_ind);
	
	@Query("select c from CP_APP_RGST_Cargo c where c.app_number = ?1 and c.indv_seq_num in (?2)")
	public List<CP_APP_RGST_Cargo> getContactInfoActiveIndv(Integer appNumber,List<Integer> indvs);
	
	@Query("select c from CP_APP_RGST_Cargo c where c.app_number = ?1")
	public List<CP_APP_RGST_Cargo> getRgstListByAppNum(Integer appNum);
	@Query("select c from CP_APP_RGST_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2 and c.src_app_ind = ?3")
	CP_APP_RGST_Cargo loadDataInerPerfforAppNumAndSrcAppInd(Integer appNum, Integer indvSeqNum, String src_app_ind);

}
