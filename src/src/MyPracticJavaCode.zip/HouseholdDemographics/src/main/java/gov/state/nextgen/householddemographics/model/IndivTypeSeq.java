/**
 * 
 */
package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

/**
 * @author shtony
 *
 */
public class IndivTypeSeq implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer indivSeqNum;
	private String type;
	private Integer seqNum;
	private String userEndInd;
	/**
	 * @return the indivSeqNum
	 */
	public Integer getIndivSeqNum() {
		return indivSeqNum;
	}
	/**
	 * @param indivSeqNum the indivSeqNum to set
	 */
	public void setIndivSeqNum(Integer indivSeqNum) {
		this.indivSeqNum = indivSeqNum;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * @return the seqNum
	 */
	public Integer getSeqNum() {
		return seqNum;
	}
	/**
	 * @param seqNum the seqNum to set
	 */
	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}
	/**
	 * @return the userEndInd
	 */
	public String getUserEndInd() {
		return userEndInd;
	}
	/**
	 * @param userEndInd the userEndInd to set
	 */
	public void setUserEndInd(String userEndInd) {
		this.userEndInd = userEndInd;
	}


}
