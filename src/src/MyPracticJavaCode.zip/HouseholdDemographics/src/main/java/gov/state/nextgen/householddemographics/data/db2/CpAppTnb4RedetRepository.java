package gov.state.nextgen.householddemographics.data.db2;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4Redet_Cargo;

@Repository
public interface CpAppTnb4RedetRepository extends CrudRepository<CpAppTnb4Redet_Cargo, Integer>{

}
