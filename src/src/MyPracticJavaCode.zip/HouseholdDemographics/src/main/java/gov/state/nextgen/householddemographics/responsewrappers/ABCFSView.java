package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;


@Component("ABCFS")
@Scope("prototype")
public class ABCFSView implements LogicResponseInterface{
	
	private static final String PAGE_ID = "ABCFS";
	
	private static final String CP_APP_AUTH_REP_COLL = "CP_APP_AUTH_REP_Collection";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTrxn.getPageCollection();

		List<CP_APP_AUTH_REP_Cargo> authRepList = new ArrayList<CP_APP_AUTH_REP_Cargo>();
		CP_APP_AUTH_REP_Cargo cpAppInCargo = new CP_APP_AUTH_REP_Cargo();
		
		CP_APP_AUTH_REP_Collection cpAppAuthRepCollection = (pageCollection.get(CP_APP_AUTH_REP_COLL) != null) ? (CP_APP_AUTH_REP_Collection) pageCollection.get(CP_APP_AUTH_REP_COLL) : null;
		
		if(cpAppAuthRepCollection != null && !cpAppAuthRepCollection.isEmpty() && cpAppAuthRepCollection.size() >0) {			
			for (int i = 0; i < cpAppAuthRepCollection.size(); i++) {
				cpAppInCargo = (CP_APP_AUTH_REP_Cargo) cpAppAuthRepCollection.get(i);
				authRepList.add(cpAppInCargo);
			}
		} else {
			authRepList.add(cpAppInCargo);
		}
		
		
		driverPageResponse.getPageCollection().put(CP_APP_AUTH_REP_COLL, authRepList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getRequest().get(FwConstants.APP_NUM)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		return driverPageResponse;
	}
}

