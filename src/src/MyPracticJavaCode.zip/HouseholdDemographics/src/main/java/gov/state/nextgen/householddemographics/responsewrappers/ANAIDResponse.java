package gov.state.nextgen.householddemographics.responsewrappers;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ANAID")
@Scope("prototype")
public class ANAIDResponse implements LogicResponseInterface {

	private static final String PAGE_ID = "ANAID";

	/*
	 * Constructing pageResponse and returning driverPageResponse.
	 */
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();
		return driverPageResponse;
	}

}
