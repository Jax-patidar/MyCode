package gov.state.nextgen.householddemographics.business.entities;


import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_INDV_Collection extends AbstractCollection{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4857868473863055525L;
	
	private static final String PACKAGE = "gov.nextgen.services.householddemographics.dao.entities.APP_INDV";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_INDV_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_INDV_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_INDV_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_INDV_Cargo[] getResults() {
		final APP_INDV_Cargo[] cbArray = new APP_INDV_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_INDV_Cargo getCargo(final int idx) {
		return (APP_INDV_Cargo) get(idx);
	}


	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_INDV_Cargo[]) {
			final APP_INDV_Cargo[] cbArray = (APP_INDV_Cargo[]) obj;
			setResults(cbArray);
		}
	}

	public APP_INDV_Cargo getResult(final int idx) {
		return (APP_INDV_Cargo) get(idx);
	}
}
