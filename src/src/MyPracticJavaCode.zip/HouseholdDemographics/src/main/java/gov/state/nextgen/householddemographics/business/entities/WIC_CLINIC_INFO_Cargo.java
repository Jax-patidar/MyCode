package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class WIC_CLINIC_INFO_Cargo extends AbstractCargo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7541081525247920666L;

	@Id
	private String clinic_cd;
	
	private String clinic_county_cd;
	private String clinic_name;
	private String clinic_addr_line1;
	private String clinic_addr_line2;
	private String clinic_city;
	private String clinic_zip;
	private String clinic_state_cd;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date eff_begin_dt;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date eff_end_dt;
	
	private String clinic_phone_num;

	public String getClinic_cd() {
		return clinic_cd;
	}

	public void setClinic_cd(String clinic_cd) {
		this.clinic_cd = clinic_cd;
	}

	public String getClinic_county_cd() {
		return clinic_county_cd;
	}

	public void setClinic_county_cd(String clinic_county_cd) {
		this.clinic_county_cd = clinic_county_cd;
	}

	public String getClinic_name() {
		return clinic_name;
	}

	public void setClinic_name(String clinic_name) {
		this.clinic_name = clinic_name;
	}

	public String getClinic_addr_line1() {
		return clinic_addr_line1;
	}

	public void setClinic_addr_line1(String clinic_addr_line1) {
		this.clinic_addr_line1 = clinic_addr_line1;
	}

	public String getClinic_addr_line2() {
		return clinic_addr_line2;
	}

	public void setClinic_addr_line2(String clinic_addr_line2) {
		this.clinic_addr_line2 = clinic_addr_line2;
	}

	public String getClinic_city() {
		return clinic_city;
	}

	public void setClinic_city(String clinic_city) {
		this.clinic_city = clinic_city;
	}

	public String getClinic_zip() {
		return clinic_zip;
	}

	public void setClinic_zip(String clinic_zip) {
		this.clinic_zip = clinic_zip;
	}

	public String getClinic_state_cd() {
		return clinic_state_cd;
	}

	public void setClinic_state_cd(String clinic_state_cd) {
		this.clinic_state_cd = clinic_state_cd;
	}

	public Date getEff_begin_dt() {
		return eff_begin_dt;
	}

	public void setEff_begin_dt(Date eff_begin_dt) {
		this.eff_begin_dt = eff_begin_dt;
	}

	public Date getEff_end_dt() {
		return eff_end_dt;
	}

	public void setEff_end_dt(Date eff_end_dt) {
		this.eff_end_dt = eff_end_dt;
	}

	public String getClinic_phone_num() {
		return clinic_phone_num;
	}

	public void setClinic_phone_num(String clinic_phone_num) {
		this.clinic_phone_num = clinic_phone_num;
	}

	

}
