/**
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * @author rudeshmukh
 *
 */
public class CpAppUserCollection extends AbstractCollection implements Serializable {


	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.workerPortalIntergration.business.entities.CP_APP_USER";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CpAppUserCargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CpAppUserCargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CpAppUserCargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CpAppUserCargo[] getResults() {
		final CpAppUserCargo[] cbArray = new CpAppUserCargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CpAppUserCargo getCargo(final int idx) {
		return (CpAppUserCargo) get(idx);
	}

	

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CpAppUserCargo[]) {
			final CpAppUserCargo[] cbArray = (CpAppUserCargo[]) obj;
			setResults(cbArray);
		}
	}

}
