package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABBFS")
@Scope("prototype")
public class BreastFeedingSummaryView implements LogicResponseInterface {
	private static final String PAGE_ID = "ABBFS";
	
	private static final String CP_APP_IN_PREG_COLL = "CP_APP_IN_PREG_Collection";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTxn.getPageCollection();
		List<CP_APP_IN_PREG_Cargo> indvList = new ArrayList<CP_APP_IN_PREG_Cargo>();
		CP_APP_IN_PREG_Cargo pregCargo;
		CP_APP_IN_PREG_Collection pregCollection = pageCollection.get(CP_APP_IN_PREG_COLL) != null ? (CP_APP_IN_PREG_Collection) pageCollection.get(CP_APP_IN_PREG_COLL) : null;
		if(pregCollection != null && !pregCollection.isEmpty() && pregCollection.size() > 0) {
			for(int i=0; i< pregCollection.size();i++) {
				pregCargo = pregCollection.getCargo(i);
				indvList.add(pregCargo);
			}
		}
		driverPageResponse.getPageCollection().put(CP_APP_IN_PREG_COLL, indvList);
		driverPageResponse.setAppNum(fwTxn.getUserDetails().getAppNumber());
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getRequest().get(FwConstants.APP_NUMBER)));
		return driverPageResponse;
	}
}
