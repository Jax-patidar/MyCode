package gov.state.nextgen.householddemographics;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.redis.RedisRepositoriesAutoConfiguration;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.GetSecretValueRequest;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zaxxer.hikari.HikariDataSource;

import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.householddemographics.business.services.UserCredentialServImpl;

/**
 * HouseholdDemographics application class.
 * 
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * 
 * @author prabhasingh
 */


@SpringBootApplication(exclude = { RedisRepositoriesAutoConfiguration.class })
@ComponentScan(value = {"gov.state.nextgen.access", "gov.state.nextgen.householddemographics"},lazyInit = true)
public class HouseholdDemographicsApplication {
	
	@Autowired
	UserCredentialServImpl userCred;
	
	private static Logger log = LoggerFactory.getLogger(HouseholdDemographicsApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(HouseholdDemographicsApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder){
		return builder.build();
	}
	

//	@Bean
//	public DataSource dataSource() throws SQLException {
//		String jdbcURL = System.getenv("JDBC_URL");
//		String dbSchema = System.getenv("DB_SCHEMA");
//		String maxPoolSize = System.getenv("DB_POOLSIZE");
//		String minPoolSize = System.getenv("MIN_DB_POOLSIZE");
//		String idleTimeOut = System.getenv("DB_IDLE_TIMEOUT");
//		
//		String secretName = System.getenv("SECRET_NAME");
//		String region=System.getenv("REGION");
//		String secret="";
//		GetSecretValueRequest valueRequest = GetSecretValueRequest.builder().secretId(secretName).build();
//	    Region region1 = Region.of(region);
//	    SecretsManagerClient secretsClient = SecretsManagerClient.builder().region(region1).build();
//	    GetSecretValueResponse valueResponse = secretsClient.getSecretValue(valueRequest);
//        secret = valueResponse.secretString();
//	    
//	    ObjectMapper objectMapper=new ObjectMapper();
//	    Map secretObject=new HashMap<>();
//		
//			try {
//				secretObject=objectMapper.readValue(secret, HashMap.class);
//			} catch (Exception e) {
//				FwLogger.log(this.getClass(), FwLogger.Level.ERROR,"Error occured in HouseholdDemographicsApplication.dataSource()", e);
//			}
//		
//	    String username=(String)secretObject.get("username");
//	    String password=(String)secretObject.get("password");
//
//		HikariDataSource ds = new HikariDataSource();
//		ds.setMaximumPoolSize(Integer.valueOf(maxPoolSize));
//		ds.setMinimumIdle(Integer.valueOf(minPoolSize));
//		log.info("Registering driver");
//		ds.setDriverClassName("org.postgresql.Driver");
//		log.info("Driver complete");
//		ds.setJdbcUrl(jdbcURL);
//		ds.setUsername(username);
//		ds.setPassword(password);
//
//		if(idleTimeOut == null || idleTimeOut.isEmpty()) {
//			ds.setIdleTimeout(20000L);
//		}else {
//			ds.setIdleTimeout(Long.valueOf(idleTimeOut));
//		}
//		ds.setSchema(dbSchema);
//		return (DataSource)ds;
//	}
//
//	
//	@Bean
//	public void loadInRedis() throws Exception {
//		userCred.loadCredentialsFromTable();
//	}


//	/**
//	 * 
//	 * @param region
//	 * @param secretName
//	 * @return {@link GetSecretValueResult}
//	 */
//	private GetSecretValueResult getSecretValue(String region,String secretName)
//	{
//		  AWSSecretsManager secretsClient = AWSSecretsManagerClientBuilder.standard().withRegion(Regions.fromName(region)).build();
//		  GetSecretValueRequest valueRequest = new GetSecretValueRequest().withSecretId(secretName);
//		  return  secretsClient.getSecretValue(valueRequest); 
//	}
}
