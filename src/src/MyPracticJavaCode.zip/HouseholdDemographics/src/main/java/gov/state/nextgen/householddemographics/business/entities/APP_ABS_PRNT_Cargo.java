package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "cp_app_abs_prnt")
@IdClass(APP_ABS_PRNT_Key.class)
public class APP_ABS_PRNT_Cargo extends AbstractCargo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3425981979486131207L;
	
	
	@Transient
	private String appNum;
	
	@Id
	@Column(name = "app_num")
	@JsonProperty("app_num")
	private int app_number;
	
	@Id
	@Column(name = "ap_seq_num")
	@JsonProperty("ap_seq_num")
	private double apSeqNum;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date ap_absn_dt;
	private String ap_absn_rsn_cd;
	@Column(name = "ap_first_name")
	@JsonProperty("AP_FST_NAM")
	private String apFstNam;
	@Column(name = "ap_last_name")
	@JsonProperty("AP_LAST_NAM")
	private String apLastNam;
	private String ap_mid_init;
	@Column(name = "ap_sex_ind")
	@JsonProperty("ap_sex_ind")
	private String apSexInd;
	@Column(name = "case_gdcs_clm_sw")
	@JsonProperty("case_gdcs_clm_sw")
	private String caseGdcsClmSw;
	private double rec_cplt_ind;
	// fields added for EDSP-CP
	private String absent_parent_deceased_ind;
	private String suffix_name;
	@Column(name = "chld_sup_payee_name")
	private String chld_sup_payee_nam;	

	@Column(name = "src_app_ind")
	@JsonProperty("src_app_ind")
	private String srcAppInd;
	
	@Column(name = "court_order_pay_chld_sup_ind")
	@JsonProperty("court_order_pay_chld_sup_ind")
	private String courtOrderPayChldSupInd;
	
	/* Start : CSPM-7108 */
    @Id
    private Integer indv_seq_num;
    @Transient
    private String parentOneFirstName;
    @Transient
    private String parentOneLastName;
    @Transient
    private String parentTwoFirstName;
    @Transient
    private String parentTwoLastName;
    
    public Integer getIndv_seq_num() {
          return indv_seq_num;
    }

    public void setIndv_seq_num(Integer indv_seq_num) {
          this.indv_seq_num = indv_seq_num;
    }
    
    public String getParentOneFirstName() {
          return parentOneFirstName;
    }

    public void setParentOneFirstName(String parentOneFirstName) {
          this.parentOneFirstName = parentOneFirstName;
    }

    public String getParentOneLastName() {
          return parentOneLastName;
    }

    public void setParentOneLastName(String parentOneLastName) {
          this.parentOneLastName = parentOneLastName;
    }

    public String getParentTwoFirstName() {
          return parentTwoFirstName;
    }

    public void setParentTwoFirstName(String parentTwoFirstName) {
          this.parentTwoFirstName = parentTwoFirstName;
    }

    public String getParentTwoLastName() {
          return parentTwoLastName;
    }

    public void setParentTwoLastName(String parentTwoLastName) {
          this.parentTwoLastName = parentTwoLastName;
    }
    
    /* End : CSPM-7108 */
	
	public String getAppNum() {
		return String.valueOf(app_number);
	}
	public void setAppNum(String appNum) {
		this.app_number = Integer.parseInt(appNum);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.appNum = String.valueOf(app_number);
	}

	public double getApSeqNum() {
		return apSeqNum;
	}

	public void setApSeqNum(double apSeqNum) {
		this.apSeqNum = apSeqNum;
	}

	public Date getAp_absn_dt() {
		return ap_absn_dt;
	}

	public void setAp_absn_dt(Date ap_absn_dt) {
		this.ap_absn_dt = ap_absn_dt;
	}

	public String getAp_absn_rsn_cd() {
		return ap_absn_rsn_cd;
	}

	public void setAp_absn_rsn_cd(String ap_absn_rsn_cd) {
		this.ap_absn_rsn_cd = ap_absn_rsn_cd;
	}

	public String getApFstNam() {
		return apFstNam;
	}

	public void setApFstNam(String apFstNam) {
		this.apFstNam = apFstNam;
	}

	public String getApLastNam() {
		return apLastNam;
	}

	public void setApLastNam(String apLastNam) {
		this.apLastNam = apLastNam;
	}

	public String getAp_mid_init() {
		return ap_mid_init;
	}

	public void setAp_mid_init(String ap_mid_init) {
		this.ap_mid_init = ap_mid_init;
	}

	public String getApSexInd() {
		return apSexInd;
	}

	public void setApSexInd(String apSexInd) {
		this.apSexInd = apSexInd;
	}

	public String getCaseGdcsClmSw() {
		return caseGdcsClmSw;
	}

	public void setCaseGdcsClmSw(String caseGdcsClmSw) {
		this.caseGdcsClmSw = caseGdcsClmSw;
	}

	public double getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	public void setRec_cplt_ind(double rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	public String getAbsent_parent_deceased_ind() {
		return absent_parent_deceased_ind;
	}

	public void setAbsent_parent_deceased_ind(String absent_parent_deceased_ind) {
		this.absent_parent_deceased_ind = absent_parent_deceased_ind;
	}

	public String getSuffix_name() {
		return suffix_name;
	}

	public void setSuffix_name(String suffix_name) {
		this.suffix_name = suffix_name;
	}

	public String getChld_sup_payee_nam() {
		return chld_sup_payee_nam;
	}

	public void setChld_sup_payee_nam(String chld_sup_payee_nam) {
		this.chld_sup_payee_nam = chld_sup_payee_nam;
	}

	public String getSrcAppInd() {
		return srcAppInd;
	}

	public void setSrcAppInd(String srcAppInd) {
		this.srcAppInd = srcAppInd;
	}

	public String getCourtOrderPayChldSupInd() {
		return courtOrderPayChldSupInd;
	}

	public void setCourtOrderPayChldSupInd(String courtOrderPayChldSupInd) {
		this.courtOrderPayChldSupInd = courtOrderPayChldSupInd;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((absent_parent_deceased_ind == null) ? 0 : absent_parent_deceased_ind.hashCode());
		result = prime * result + ((apFstNam == null) ? 0 : apFstNam.hashCode());
		result = prime * result + ((apLastNam == null) ? 0 : apLastNam.hashCode());
		long temp;
		temp = Double.doubleToLongBits(apSeqNum);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((apSexInd == null) ? 0 : apSexInd.hashCode());
		result = prime * result + ((ap_absn_dt == null) ? 0 : ap_absn_dt.hashCode());
		result = prime * result + ((ap_absn_rsn_cd == null) ? 0 : ap_absn_rsn_cd.hashCode());
		result = prime * result + ((ap_mid_init == null) ? 0 : ap_mid_init.hashCode());
		result = prime * result + ((appNum == null) ? 0 : appNum.hashCode());
		result = prime * result + ((caseGdcsClmSw == null) ? 0 : caseGdcsClmSw.hashCode());
		result = prime * result + ((chld_sup_payee_nam == null) ? 0 : chld_sup_payee_nam.hashCode());
		result = prime * result + ((courtOrderPayChldSupInd == null) ? 0 : courtOrderPayChldSupInd.hashCode());
		temp = Double.doubleToLongBits(rec_cplt_ind);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((srcAppInd == null) ? 0 : srcAppInd.hashCode());
		result = prime * result + ((suffix_name == null) ? 0 : suffix_name.hashCode());
		return result;
	}

	
	
}
