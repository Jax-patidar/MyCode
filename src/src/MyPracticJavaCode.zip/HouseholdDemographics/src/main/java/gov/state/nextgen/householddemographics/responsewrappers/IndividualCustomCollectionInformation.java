package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABCHS")
@Scope("prototype")
public class IndividualCustomCollectionInformation implements LogicResponseInterface{
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();

		Map pageCollection = fwTrxn.getPageCollection();
		List<INDIVIDUAL_Custom_Cargo> appIndvList = new ArrayList<>();
		INDIVIDUAL_Custom_Cargo appIndvCargo = new INDIVIDUAL_Custom_Cargo();
		INDIVIDUAL_Custom_Collection appIndvColl = pageCollection.get(HouseHoldDemoGraphicsConstants.INDIVIDUAL_CUSTOM_COLLECTION) != null ? (INDIVIDUAL_Custom_Collection)pageCollection.get(HouseHoldDemoGraphicsConstants.INDIVIDUAL_CUSTOM_COLLECTION) : null;
		if(Objects.nonNull(appIndvColl)) {
			for(Object indvCustomCargo : appIndvColl) {
				appIndvCargo = (INDIVIDUAL_Custom_Cargo) indvCustomCargo;
				appIndvList.add(appIndvCargo);
			}
		}
		
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.INDIVIDUAL_CUSTOM_COLLECTION, appIndvList);

		return driverPageResponse;
	}
	
}
