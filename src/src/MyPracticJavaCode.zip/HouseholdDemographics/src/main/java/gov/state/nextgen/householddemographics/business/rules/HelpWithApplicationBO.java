package gov.state.nextgen.householddemographics.business.rules;

import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppFileHelpRepository;

/**
 * This class contains rules and/or validations related to ABCON.
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

@Service("HelpWithApplicationBO")
public class HelpWithApplicationBO extends AbstractBO{

	private CpAppFileHelpRepository cpAppFileHelpRepository;

	/**
	 * Method to load Help With Application Page
	 * 
	 * @param appNum
	 * @return APP_FILE_HELP_Cargo
	 */
	public APP_FILE_HELP_Cargo loadHelpWithApplication(final String applNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HelpWithApplicationBO.loadHelpWithApplication- START");
		try {
			APP_FILE_HELP_Cargo resultCargo = new APP_FILE_HELP_Cargo();
			APP_FILE_HELP_Collection helpColl ;

			helpColl = cpAppFileHelpRepository.getByAppNum(applNum);

			if ((helpColl != null) && !helpColl.isEmpty()) {
				resultCargo = helpColl.getCargo(0);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HelpWithApplicationBO.loadHelpWithApplication() - END , Time Taken : " + (System.currentTimeMillis() - startTime)
					+ " milliseconds");
			return resultCargo;
		} catch (final Exception fe) {
			throw fe;
		} 
	}
	
	
	/* Method to get the filing representative code- added by EDSP-CP team */
	public String getFilingRepresentativeCode(final Integer codeOption) {
		System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HelpWithApplicationBO.getFilingRepresentativeCode() - START");
		switch (codeOption) {
		case 1:
			return FwConstants.HELP_INDIVIDUAL_CD_SELF;
		case 2:
			return FwConstants.HELP_INDIVIDUAL_CD_FRIEND;
		case 3:
			return FwConstants.HELP_INDIVIDUAL_CD_FAMILYMEMBER;
		case 4:
			return FwConstants.HELP_INDIVIDUAL_CD_STAFFPERSON_OR_VOLUNTEERATANAGENCY;
		case 5:
			return FwConstants.HELP_INDIVIDUAL_CD_AUTHORIZEDREPRESENTATIVE;
		case 6:
			return FwConstants.HELP_INDIVIDUAL_CD_LEGALGUARDIAN;
		case 7:
			return FwConstants.HELP_INDIVIDUAL_CD_POWER_OF_ATTORNEY;
		case 8:
			return FwConstants.HELP_INDIVIDUAL_CD_LONG_TERM_CARE;
		default:
			return codeOption.toString();
		}

	}
	
    public void storeHelpWithApplication(final APP_FILE_HELP_Collection helpColl) {
        final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO,"HelpWithApplicationBO.storeHelpWithApplication() - START");
        try {
        	APP_FILE_HELP_Cargo resultCargo = new APP_FILE_HELP_Cargo();
			
            if (null!=helpColl && !helpColl.isEmpty()) {
                resultCargo = helpColl.getCargo(0);
                cpAppFileHelpRepository.save(resultCargo);
            }
        } catch (final Exception e) {
             FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(this.getClass().getName(), "storeHelpWithApplication", e);
        }
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HelpWithApplicationBO.storeHelpWithApplication() - END , Time Taken :" + (System.currentTimeMillis() - startTime) + " milliseconds");
    }


    public FwMessageList validateHelpWithApplication(final APP_FILE_HELP_Cargo helpCargo) {
		
		try {
			FwMessageList messageList = new FwMessageList();

			if ((helpCargo.getHelp_indv_ind()==null)) 
			{
				addMessageCode("10237");
				messageList.addMessageToList(addMessageCode("10237")); 

			}
			/*
			// Help with Application Validation for Agency Number
			String agencyNumberEntered = null;

			if (helpCargo.getAgcy_num() != null) {
				agencyNumberEntered = helpCargo.getAgcy_num().trim();
			}
			if (appMgr.isFieldEmpty(helpCargo.getHelp_indv_ind())) {
				addMessageCode("10237");
			}
			if (!appMgr.isFieldEmpty(agencyNumberEntered)) {
				if (!appMgr.isInteger(agencyNumberEntered)) {
					final Object[] error = new Object[] { new FwMessageTextLabel("32289") };
					this.addMessageWithFieldValues("20075", error);
				}
			}
			// verification against the database to check whether the entered
			// Agency Exists
			if (!appMgr.isFieldEmpty(agencyNumberEntered)) {
				if (appMgr.isInteger(agencyNumberEntered)) {
					final Map criteriaMap = new HashMap();
					final CMNY_ACS_PNT_ATCT_Collection cmnyAcsPntColl = new CMNY_ACS_PNT_ATCT_Collection();
					final FwDataCriteria[] criteria = new FwDataCriteria[1];
					criteria[0] = new FwDataCriteria();
					criteria[0].setColumn_name("AGCY_NUM");
					criteria[0].setColumn_value(agencyNumberEntered);
					criteria[0].setData_type(FwConstants.INT);
					criteriaMap.put(FwConstants.CRITERIA, criteria);
					final CMNY_ACS_PNT_ATCT_Cargo[] appRgstCargoArray = (CMNY_ACS_PNT_ATCT_Cargo[]) cmnyAcsPntColl.select(FwConstants.DAO,
							criteriaMap);
					cmnyAcsPntColl.setResults(appRgstCargoArray);
					if (cmnyAcsPntColl.isEmpty()) {
						final Object[] error = new Object[] { new FwMessageTextLabel("32289") };
						this.addMessageWithFieldValues("20081", error);
					}
				}
			}
*/
			return messageList;
			
		} catch (final Exception e) {
			final FwException fe = createFwException(this.getClass().getName(), "validateHelpWithApplication", e);
			throw fe;
		}
	}
	}




