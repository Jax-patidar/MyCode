package gov.state.nextgen.householddemographics.responsewrappers;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("CFESS")
@Scope("prototype")
public class CFESSViewWrapper implements LogicResponseInterface {

    private static final String PAGE_ID = "CFESS";
    
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

    	DriverPageResponse driverPageResponse = new DriverPageResponse();
    	
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

        return driverPageResponse;

    }

}