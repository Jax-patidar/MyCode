package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the cp_app_user database table.
 * 
 */
@Embeddable
public class CpAppUserCargoKey implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="acs_id")
	private String acsId;

	@Column(name="app_num")
	private Integer appNum;

	public CpAppUserCargoKey() {
		//This is a default constructor
	}
	public String getAcsId() {
		return this.acsId;
	}
	public void setAcsId(String acsId) {
		this.acsId = acsId;
	}

	public Integer getAppNum() {
		return appNum;
	}
	public void setAppNum(Integer appNum) {
		this.appNum = appNum;
	}
	@SuppressWarnings("squid:S2162")
	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CpAppUserCargoKey)) {
			return false;
		}
		CpAppUserCargoKey castOther = (CpAppUserCargoKey)other;
		return 
			this.acsId.equals(castOther.acsId)
			&& this.appNum.equals(castOther.appNum);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.acsId.hashCode();
		hash = hash * prime + this.appNum.hashCode();
		
		return hash;
	}
}