package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

public class CP_APP_OTHER_SITUATIONS_Key implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer app_number;
	
		//default constructor
		public CP_APP_OTHER_SITUATIONS_Key() {
			
		}

	public CP_APP_OTHER_SITUATIONS_Key(Integer app_num) {
		super();
		this.app_number = app_num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CP_APP_OTHER_SITUATIONS_Key other = (CP_APP_OTHER_SITUATIONS_Key) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		return true;
	} 
	
	
	
	
}
