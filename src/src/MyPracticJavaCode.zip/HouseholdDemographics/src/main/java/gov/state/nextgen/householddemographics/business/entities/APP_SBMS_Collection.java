package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_SBMS_Collection extends AbstractCollection{


	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.workerPortalIntergration.business.entities.APP_SBMS";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_SBMS_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_SBMS_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_SBMS_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_SBMS_Cargo[] getResults() {
		final APP_SBMS_Cargo[] cbArray = new APP_SBMS_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_SBMS_Cargo getCargo(final int idx) {
		return (APP_SBMS_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_SBMS_Cargo[] cloneResults() {
		final APP_SBMS_Cargo[] rescargo = new APP_SBMS_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_SBMS_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_SBMS_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setBus_hr_exmp_ind(cargo.getBus_hr_exmp_ind());
			rescargo[i].setCare_exmp_ind(cargo.getCare_exmp_ind());
			rescargo[i].setCc_exmp_ind(cargo.getCc_exmp_ind());
			rescargo[i].setE_sign_ind(cargo.getE_sign_ind());
			rescargo[i].setEdb_exmp_ind(cargo.getEdb_exmp_ind());
			rescargo[i].setFs_ivw_resp(cargo.getFs_ivw_resp());
			rescargo[i].setFst_nam(cargo.getFst_nam());
			rescargo[i].setIlns_exmp_ind(cargo.getIlns_exmp_ind());
			rescargo[i].setLast_nam(cargo.getLast_nam());
			rescargo[i].setMid_init(cargo.getMid_init());
			rescargo[i].setOthr_exmp_ind(cargo.getOthr_exmp_ind());
			rescargo[i].setSps_esign_ind(cargo.getSps_esign_ind());
			rescargo[i].setSps_fst_nam(cargo.getSps_fst_nam());
			rescargo[i].setSps_last_nam(cargo.getSps_last_nam());
			rescargo[i].setSps_mid_init(cargo.getSps_mid_init());
			rescargo[i].setTrnsp_exmp_ind(cargo.getTrnsp_exmp_ind());
			rescargo[i].setUcmft_exmp_ind(cargo.getUcmft_exmp_ind());
			rescargo[i].setWork_exmp_ind(cargo.getWork_exmp_ind());
			rescargo[i].setWthr_exmp_ind(cargo.getWthr_exmp_ind());
			rescargo[i].setOthr_rsn_txt(cargo.getOthr_rsn_txt());

			// EDSP CP Starts
			rescargo[i].setInfo_exchange_consent_ind(cargo.getInfo_exchange_consent_ind());
			rescargo[i].setElectronically_sign_ind(cargo.getElectronically_sign_ind());
			rescargo[i].setUnable_sign_ind(cargo.getUnable_sign_ind());
			rescargo[i].setSuffix_name(cargo.getSuffix_name());
			rescargo[i].setApplicant_first_name(cargo.getApplicant_first_name());
			rescargo[i].setApplicant_last_name(cargo.getApplicant_last_name());
			rescargo[i].setApplicant_mid_name(cargo.getApplicant_mid_name());
			rescargo[i].setApplicant_suffix_name(cargo.getApplicant_suffix_name());
			rescargo[i].setVoter_registration_sw(cargo.getVoter_registration_sw());
			rescargo[i].setExpedited_fap_sw(cargo.getExpedited_fap_sw());
			rescargo[i].setMedicaid_abd_sw(cargo.getMedicaid_abd_sw());
			rescargo[i].setPregnant_sw(cargo.getPregnant_sw());
			rescargo[i].setNew_born_sw(cargo.getNew_born_sw());
			rescargo[i].setCitizenship_sign(cargo.getCitizenship_sign());
			rescargo[i].setAuthrep_citizenship_sign(cargo.getAuthrep_citizenship_sign());
			// EDSP CP Ends
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
			rescargo[i].setReview_sps_first_name(cargo.getReview_sps_first_name());
			rescargo[i].setReview_sps_last_name(cargo.getReview_sps_last_name());
			rescargo[i].setReview_sps_sign_date(cargo.getReview_sps_sign_date());
			rescargo[i].setReview_esign_ind(cargo.getReview_esign_ind());
			rescargo[i].setApplicant_sign_dt(cargo.getApplicant_sign_dt());
			rescargo[i].setOrg_user_agency_name(cargo.getOrg_user_agency_name());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_SBMS_Cargo[]) {
			final APP_SBMS_Cargo[] cbArray = (APP_SBMS_Cargo[]) obj;
			setResults(cbArray);
		}
	}

}
