package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABAUR")
@Scope("prototype")
public class AuthorizedRepresentativeView implements LogicResponseInterface {
	private static final String PAGE_ID = "ABAUR";
	private static final String CP_APP_AUTH_REP_COLLECTION = "CP_APP_AUTH_REP_Collection";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction txBean) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = txBean.getPageCollection();
		
		List<CP_APP_AUTH_REP_Cargo> cpAppAuthRepCargoList = new ArrayList<CP_APP_AUTH_REP_Cargo>();
		CP_APP_AUTH_REP_Cargo cpAppAuthRepCargo = new CP_APP_AUTH_REP_Cargo();
		CP_APP_AUTH_REP_Collection cpAppAuthRepColl = pageCollection.get("CP_APP_AUTH_REP_Collection") != null ? (CP_APP_AUTH_REP_Collection)pageCollection.get("CP_APP_AUTH_REP_Collection") : null;
		if(cpAppAuthRepColl != null && cpAppAuthRepColl.size() > 0) {
			cpAppAuthRepCargo = (CP_APP_AUTH_REP_Cargo) cpAppAuthRepColl.get(0);
		}
		cpAppAuthRepCargoList.add(cpAppAuthRepCargo);
		driverPageResponse.getPageCollection().put(CP_APP_AUTH_REP_COLLECTION, cpAppAuthRepCargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(txBean.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(txBean.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(txBean.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(txBean.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		
		return driverPageResponse;
	}

	

}
