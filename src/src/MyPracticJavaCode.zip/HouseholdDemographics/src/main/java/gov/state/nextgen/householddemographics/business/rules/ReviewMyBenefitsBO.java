package gov.state.nextgen.householddemographics.business.rules;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_SMRF_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_SMRF_Custom_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CpAppRgstRepository;

@Service
public class ReviewMyBenefitsBO extends AbstractBO {
	
	@Autowired
	CpAppRgstRepository appRgstRepo;

	public FwMessageList validateRMBLandingPage(
			final APP_PGM_RQST_Collection appPgmColl, String language) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(),Level.INFO, "ReviewMyBenefitsBO.validateRMBLandingPage) - START");
		FwMessageList messageList = new FwMessageList();
		try {
			if (appPgmColl == null) {
				return messageList;
			} else {
				final APP_PGM_RQST_Cargo appPgmCargo = appPgmColl.getCargo(0);
	
				if (appPgmCargo.getCc_rqst_ind() == null
						&& appPgmCargo.getTanf_rqst_ind() == null
						&& appPgmCargo.getFma_rqst_ind() == null
						&& appPgmCargo.getFs_rqst_ind() == null
						&& appPgmCargo.getWic_rqst_ind() == null
						&& appPgmCargo.getPeach_rqst_ind() == null) {
					messageList.addMessageToList(addMessageCode("00742"));
				}
				
				//Below commented out code will be handled in UI since its comparison
				//of cargos. Warning message should also be displayed at UI level
				/*
				 * Map compareMap = appPgmCargo.compareAttributes(beforePgmCargo);
				 * if(!compareMap.isEmpty()){
				 * 
				 * StringBuilder sb = genValidationMsg(language, compareMap);
				 * 
				 * final Object[] error = new Object[] { sb.toString() };
				 * this.addMessageWithFieldValues("99457", error); }
				 */
				
			}
			FwLogger.log(this.getClass(),Level.INFO,
					"ReviewMyBenefitsBO.validateRMBLandingPage - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");
			return messageList;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(),
					"validateRMBLandingPage", e);
		}
	}
	
	public void updateAppType(final String appType, final String appNum) {
		APP_RGST_Cargo[] rqstCargos = appRgstRepo.getByAppNum(Integer.parseInt(appNum));
		
		if(rqstCargos.length > 0) {
		APP_RGST_Cargo rqstCargo = rqstCargos[0];
		rqstCargo.setApp_typ(appType);
		//Set Update Date
		Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
		rqstCargo.setUpdate_dt(currentTimeStamp);
		
		appRgstRepo.save(rqstCargo);
		}
		
	}
	
	public Date findEarliestDueDate(final Map detMap) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(),Level.INFO, "ReviewMyBenefitsBO.findEarliestDueDate() - START");
		try {
			Date dueDate = null;
			Date hcDueDate = HouseHoldDemoGraphicsConstants.HIGH_DATE_OBJ;
			Date fsDueDate = HouseHoldDemoGraphicsConstants.HIGH_DATE_OBJ;
			Date ccDueDate = HouseHoldDemoGraphicsConstants.HIGH_DATE_OBJ;
			if (detMap.containsKey("HC")) {
				final Map hcDetMap = (Map) detMap.get("HC");
				if (hcDetMap.get("HC_DUE_DATE") != null) {
					hcDueDate = (Date) hcDetMap.get("HC_DUE_DATE");
				}
			}

			if (detMap.containsKey("FS")) {
				final Map fsDetMap = (Map) detMap.get("FS");
				if (fsDetMap.get("FS_DUE_DATE") != null) {
					fsDueDate = (Date) fsDetMap.get("FS_DUE_DATE");
				}
			}

			if (detMap.containsKey("CC")) {
				final Map ccDetMap = (Map) detMap.get("CC");
				if (ccDetMap.get("CC_DUE_DATE") != null) {
					ccDueDate = (Date) ccDetMap.get("CC_DUE_DATE");
				}
			}

			if (hcDueDate.compareTo(fsDueDate) < 0) {
				if (hcDueDate.compareTo(ccDueDate) < 0) {
					dueDate = hcDueDate;
				} else {
					dueDate = ccDueDate;
				}
			} else {
				if (fsDueDate.compareTo(ccDueDate) < 0) {
					dueDate = fsDueDate;
				} else {
					dueDate = ccDueDate;
				}
			}

			FwLogger.log(this.getClass(),Level.INFO,
					"ReviewMyBenefitsBO.findEarliestDueDate() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");

			return dueDate;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(),
					"findEarliestDueDate", e);
		}
	}

	/**
	 * @param detMap
	 * @return
	 */
	public Date findBCLADueDate(final Map detMap) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(),Level.INFO, "ReviewMyBenefitsBO.findBCLADueDate() - START");
		try {
			Date dueDate = HouseHoldDemoGraphicsConstants.HIGH_DATE;

			if (detMap.containsKey("BCLA")) {
				final Map bclaDetMap = (Map) detMap.get("BCLA");
				if (bclaDetMap.get("BCLA_DUE_DATE") != null) {
					dueDate = (Date) bclaDetMap.get("BCLA_DUE_DATE");
				}
			}
			FwLogger.log(this.getClass(),Level.INFO,
					"ReviewMyBenefitsBO.findBCLADueDate() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");

			return dueDate;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(),
					"findBCLADueDate", e);
		}
	}
	
	public Map getReviewProgramDetailsMap(
			final RMB_SMRF_Custom_Collection aRmbSmrfColl,
			final String aReviewType) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(),Level.INFO,"ReviewMyBenefitsBO.getReviewProgramDetailsMap) - START");
		try {
			final Map returnMap = new HashMap();
			final Map hcPgmMap = new HashMap();
			final Map fsPgmMap = new HashMap();
			final Map ccPgmMap = new HashMap();
			final Map bclaMap = new HashMap();
			final Map taPgmMap = new HashMap();
			final Map snPgmMap = new HashMap();
			final Map mcPgmMap = new HashMap();
			final Map wcPgmMap = new HashMap();
			final Map pcPgmMap = new HashMap();
			RMB_SMRF_Custom_Cargo custCargo = null;
			final RMB_SMRF_Custom_Collection filteredCustColl = new RMB_SMRF_Custom_Collection();
			boolean hcFound = false;
			boolean fsFound = false;
			boolean ccFound = false;
			boolean bclaFound = false;
			boolean taFound = false;
			boolean snFound = false;
			boolean mcFound = false;
			boolean wcFound = false;
			boolean pcFound = false;
			// loop through aRmbSmrfColl and remove invalid AG's for review
			if ("RMB".equals(aReviewType)) {
				for (int i = 0; i < aRmbSmrfColl.size(); i++) {
					custCargo = aRmbSmrfColl.getCargo(i);
					if (custCargo.isValidAGForReview()) {
						filteredCustColl.addCargo(custCargo);
					}
				}
			} else {
				filteredCustColl.addAll(aRmbSmrfColl);
			}

			final int collSize = filteredCustColl.size();
			for (int i = 0; i < collSize; i++) {
				custCargo = filteredCustColl.getCargo(i);
				if ("RMB".equals(aReviewType)) {// if RMB
					if ("HC".equals(custCargo.getCat_type())) {
						hcFound = true;
						if (custCargo.isReviewDue()) {
							hcPgmMap.put("HC_REVIEW_PENDING", FwConstants.YES);
						} else {
							hcPgmMap.put("HC_REVIEW_PENDING", FwConstants.NO);
						}

						hcPgmMap.put("HC_REQUIRED", FwConstants.YES);
						hcPgmMap.put("HC_REVIEW_DATE", displayFormatter
								.getMMDDYYYYDate(String.valueOf(custCargo
										.getActual_review_date())));
						hcPgmMap.put("HC_DUE_DATE",
								custCargo.getActual_review_date());
						hcPgmMap.put("HC_PRGM_LIST",
								custCargo.getCate_type_list());
						returnMap.put("HC", hcPgmMap);
					} else if ("FS".equals(custCargo.getCat_type())) {
						fsFound = true;
						if (custCargo.isReviewDue()) {
							fsPgmMap.put("FS_REVIEW_PENDING", FwConstants.YES);
						} else {
							fsPgmMap.put("FS_REVIEW_PENDING", FwConstants.NO);
						}

						fsPgmMap.put("FS_REQUIRED", FwConstants.YES);
						fsPgmMap.put("FS_DUE_DATE",
								custCargo.getActual_review_date());
						fsPgmMap.put("FS_REVIEW_DATE", displayFormatter
								.getMMDDYYYYDate(String.valueOf(custCargo
										.getActual_review_date())));
						fsPgmMap.put("FS_PRGM_LIST",
								custCargo.getCate_type_list());
						fsPgmMap.put("FS_SUB_PRGM_LIST",
								custCargo.getSub_cat_type_list());
						returnMap.put("FS", fsPgmMap);
					} else if ("CD".equals(custCargo.getCat_type())) {
						ccFound = true;
						if (custCargo.isReviewDue()) {
							ccPgmMap.put("CC_REVIEW_PENDING", FwConstants.YES);
						} else {
							ccPgmMap.put("CC_REVIEW_PENDING", FwConstants.NO);
						}

						ccPgmMap.put("CC_REQUIRED", FwConstants.YES);
						ccPgmMap.put("CC_DUE_DATE",
								custCargo.getActual_review_date());
						ccPgmMap.put("CC_REVIEW_DATE", displayFormatter
								.getMMDDYYYYDate(String.valueOf(custCargo
										.getActual_review_date())));
						ccPgmMap.put("CC_PRGM_LIST",
								custCargo.getCate_type_list());
						returnMap.put("CC", ccPgmMap);
					} else if ("M50".equals(custCargo.getCat_type())) {
						bclaFound = true;
						if (custCargo.isCLAReviewDue()) {
							bclaMap.put("BCLA_REVIEW_PENDING", FwConstants.YES);
							bclaMap.put("BCLA_REQUIRED", FwConstants.YES);
							bclaMap.put("BCLA_DUE_DATE",
									custCargo.getActual_review_date());
							bclaMap.put("BCLA_REVIEW_DATE", displayFormatter
									.getMMDDYYYYDate(String.valueOf(custCargo
											.getActual_review_date())));
							returnMap.put("BCLA_INDV_PIN_LIST",
									custCargo.getCla_pin_num_list());
							returnMap.put("BCLA", bclaMap);
						} else {
							bclaMap.put("BCLA_REVIEW_PENDING", FwConstants.NO);
							bclaMap.put("BCLA_REQUIRED", FwConstants.NO);
							returnMap.put("BCLA", bclaMap);
						}
					} else if ("TA".equals(custCargo.getCat_type())) {
						taFound = true;
						if (custCargo.isReviewDue()) {
							taPgmMap.put("TA_REVIEW_PENDING", FwConstants.YES);
						} else {
							taPgmMap.put("TA_REVIEW_PENDING", FwConstants.NO);
						}

						taPgmMap.put("TA_REQUIRED", FwConstants.YES);
						taPgmMap.put("TA_DUE_DATE",
								custCargo.getActual_review_date());
						taPgmMap.put("TA_REVIEW_DATE", displayFormatter
								.getMMDDYYYYDate(String.valueOf(custCargo
										.getActual_review_date())));
						taPgmMap.put("TA_PRGM_LIST",
								custCargo.getCate_type_list());
						returnMap.put("TA", taPgmMap);
					} else if ("SN".equals(custCargo.getCat_type())) {
						snFound = true;
						if (custCargo.isReviewDue()) {
							snPgmMap.put("SN_REVIEW_PENDING", FwConstants.YES);
						} else {
							snPgmMap.put("SN_REVIEW_PENDING", FwConstants.NO);
						}

						snPgmMap.put("SN_REQUIRED", FwConstants.YES);
						snPgmMap.put("SN_DUE_DATE",
								custCargo.getActual_review_date());
						snPgmMap.put("SN_REVIEW_DATE", displayFormatter
								.getMMDDYYYYDate(String.valueOf(custCargo
										.getActual_review_date())));
						snPgmMap.put("SN_PRGM_LIST",
								custCargo.getCate_type_list());
						returnMap.put("SN", snPgmMap);
					} else if ("MC".equals(custCargo.getCat_type())) {
						mcFound = true;
						if (custCargo.isReviewDue()) {
							mcPgmMap.put("MC_REVIEW_PENDING", FwConstants.YES);
						} else {
							mcPgmMap.put("MC_REVIEW_PENDING", FwConstants.NO);
						}

						mcPgmMap.put("MC_REQUIRED", FwConstants.YES);
						mcPgmMap.put("MC_DUE_DATE",
								custCargo.getActual_review_date());
						mcPgmMap.put("MC_REVIEW_DATE", displayFormatter
								.getMMDDYYYYDate(String.valueOf(custCargo
										.getActual_review_date())));
						mcPgmMap.put("MC_PRGM_LIST",
								custCargo.getCate_type_list());
						returnMap.put("MC", mcPgmMap);
					} else if ("PC".equals(custCargo.getCat_type())) {
						pcFound = true;
						if (custCargo.isReviewDue()) {
							pcPgmMap.put("PC_REVIEW_PENDING", FwConstants.YES);
						} else {
							pcPgmMap.put("PC_REVIEW_PENDING", FwConstants.NO);
						}

						pcPgmMap.put("PC_REQUIRED", FwConstants.YES);
						pcPgmMap.put("PC_DUE_DATE",
								custCargo.getActual_review_date());
						pcPgmMap.put("PC_REVIEW_DATE", displayFormatter
								.getMMDDYYYYDate(String.valueOf(custCargo
										.getActual_review_date())));
						pcPgmMap.put("PC_PRGM_LIST",
								custCargo.getCate_type_list());
						returnMap.put("PC", pcPgmMap);
					} else if ("WC".equals(custCargo.getCat_type())) {
						wcFound = true;
						if (custCargo.isReviewDue()) {
							wcPgmMap.put("WC_REVIEW_PENDING", FwConstants.YES);
						} else {
							wcPgmMap.put("WC_REVIEW_PENDING", FwConstants.NO);
						}

						wcPgmMap.put("WC_REQUIRED", FwConstants.YES);
						wcPgmMap.put("WC_DUE_DATE",
								custCargo.getActual_review_date());
						wcPgmMap.put("WC_REVIEW_DATE", displayFormatter
								.getMMDDYYYYDate(String.valueOf(custCargo
										.getActual_review_date())));
						wcPgmMap.put("WC_PRGM_LIST",
								custCargo.getCate_type_list());
						returnMap.put("WC", wcPgmMap);
					}
				} else if ("SMRF".equals(aReviewType)) {// if SMRF
					if ("FS".equals(custCargo.getCat_type())) {
						fsFound = true;
						if (custCargo.isSMRFDue()) {
							fsPgmMap.put("FS_REVIEW_PENDING", FwConstants.YES);
						} else {
							fsPgmMap.put("FS_REVIEW_PENDING", FwConstants.NO);
						}
						fsPgmMap.put("FS_REQUIRED", FwConstants.YES);
						fsPgmMap.put("FS_DUE_DATE", dateRoutine
								.getEndOfMonth(custCargo.getActual_smrf_date()));
						fsPgmMap.put("FS_REVIEW_DATE", displayFormatter
								.getMMDDYYYYDate(String.valueOf(dateRoutine
										.getEndOfMonth(custCargo
												.getActual_smrf_date()))));
						fsPgmMap.put("FS_PRGM_LIST",
								custCargo.getCate_type_list());
						returnMap.put("FS", fsPgmMap);
					} else if ("CC".equals(custCargo.getCat_type())) {
						ccFound = true;
						if (custCargo.isSMRFDue()) {
							ccPgmMap.put("CC_REVIEW_PENDING", FwConstants.YES);
						} else {
							ccPgmMap.put("CC_REVIEW_PENDING", FwConstants.NO);
						}

						ccPgmMap.put("CC_REQUIRED", FwConstants.YES);
						ccPgmMap.put("CC_DUE_DATE", dateRoutine
								.getEndOfMonth(custCargo.getActual_smrf_date()));
						ccPgmMap.put("CC_REVIEW_DATE", displayFormatter
								.getMMDDYYYYDate(String.valueOf(dateRoutine
										.getEndOfMonth(custCargo
												.getActual_smrf_date()))));
						ccPgmMap.put("CC_PRGM_LIST",
								custCargo.getCate_type_list());
						returnMap.put("CC", ccPgmMap);
					}
				}
			}

			if (!hcFound && "RMB".equals(aReviewType)) {
				hcPgmMap.put("HC_REQUIRED", FwConstants.NO);
				returnMap.put("HC", hcPgmMap);
			}
			if (!fsFound) {
				fsPgmMap.put("FS_REQUIRED", FwConstants.NO);
				returnMap.put("FS", fsPgmMap);
			}
			if (!ccFound) {
				ccPgmMap.put("CC_REQUIRED", FwConstants.NO);
				returnMap.put("CC", ccPgmMap);
			}

			if (!bclaFound) {
				bclaMap.put("BCLA_REQUIRED", FwConstants.NO);
				returnMap.put("BCLA", bclaMap);
			}

			if (!taFound) {
				taPgmMap.put("TA_REQUIRED", FwConstants.NO);
				returnMap.put("TA", taPgmMap);
			}
			if (!snFound) {
				snPgmMap.put("SN_REQUIRED", FwConstants.NO);
				returnMap.put("SN", snPgmMap);
			}
			if (!mcFound) {
				mcPgmMap.put("MC_REQUIRED", FwConstants.NO);
				returnMap.put("MC", mcPgmMap);
			}
			if (!wcFound) {
				wcPgmMap.put("WC_REQUIRED", FwConstants.NO);
				returnMap.put("WC", wcPgmMap);
			}
			if (!pcFound) {
				pcPgmMap.put("PC_REQUIRED", FwConstants.NO);
				returnMap.put("PC", pcPgmMap);
			}

			FwLogger.log(this.getClass(),Level.INFO,
					"ReviewMyBenefitsBO.getReviewProgramDetailsMap - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");
			return returnMap;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(),
					"initializeDefaultValues", e);
		}
	}

}
