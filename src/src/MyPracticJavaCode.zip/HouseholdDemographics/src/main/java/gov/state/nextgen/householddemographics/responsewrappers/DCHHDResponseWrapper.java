/**
 * 
 */
package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.PageResponse;

/**
 * @author swabehera
 *
 */
@Component("DCHHD")
@Scope("prototype")
public class DCHHDResponseWrapper implements LogicResponseInterface {

	private static final String PAGE_ID = "DCHHD";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		
		HouseholdCommonResponse response = new HouseholdCommonResponse(String.valueOf(fwTxn.getRequest().get(FwConstants.APP_NUMBER)), 
				PAGE_ID, String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)), 
				String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)), 
				String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		
		try {
			Map<String,Object> pageCollection = fwTxn.getPageCollection();
			
			response.generateHHDetailsDriverResponse(pageCollection);
			
		}catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Inside exception block of DCHHDResponseWrapper",
					e);
		} 
		
		return response.getDriverPageResponse();
	
	}

}
