/*
 * 
 */
package gov.state.nextgen.householddemographics.business.rules;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;

import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;

/**
 * Enter the description of the class
 *
 * @author nathsu Creation Date Apr 21, 2006 Modified By: Modified on: PCR#
 */
@Service
public class GenerateNextCntlNumBO extends AbstractBO {
	
	@PersistenceUnit
	private EntityManagerFactory emf;

	// getting the Next Control number From the Controle Table
	public String getNextCntlNum() {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(),Level.INFO, "GenerateNextCntlNumBO.getNextCntlNum() - START");
		try {
			String dbSchema;
			dbSchema="IE_SSP_OWNER_HH";
		    String nextCntlNum = null;
		    Map sqlMap = new HashMap();
		    
            	EntityManager em = emf.createEntityManager();
            	 nextCntlNum = em
                        .createNativeQuery("select nextval('"+dbSchema+".CP_CNTL_NUM_1SQ')")
                        .getSingleResult().toString();
            	 em.close();
		    
            FwLogger.log(this.getClass(),Level.INFO, "GenerateNextCntlNumBO.getNextCntlNum() - END , Time Taken : " + (System.currentTimeMillis() - startTime)
                    + " milliseconds");
            return nextCntlNum;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(), "getNextCntlNum", e);
		}
	}
}
