/**
 * 
 */
package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABEXP")
@Scope("prototype")
public class ExpeditedFoodAssistanceView implements LogicResponseInterface {

	private static final String PAGE_ID = "ABEXP";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTxn.getPageCollection();

		CP_APP_INDV_ADDI_INFO_Cargo cargo = new CP_APP_INDV_ADDI_INFO_Cargo();
		List<CP_APP_INDV_ADDI_INFO_Cargo> appIndvAddInfoList = new ArrayList<CP_APP_INDV_ADDI_INFO_Cargo>();
		CP_APP_INDV_ADDI_INFO_Collection appIndvAdInfoColl = (CP_APP_INDV_ADDI_INFO_Collection) pageCollection
				.get("CP_APP_INDV_ADDI_INFO_Collection");

		if (appIndvAdInfoColl != null && !appIndvAdInfoColl.isEmpty()) {
			cargo = (CP_APP_INDV_ADDI_INFO_Cargo) appIndvAdInfoColl.get(0);
		}
		appIndvAddInfoList.add(cargo);

		driverPageResponse.getPageCollection().put("CP_APP_INDV_ADDI_INFO_Collection", appIndvAddInfoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);

		return driverPageResponse;
	}

}
