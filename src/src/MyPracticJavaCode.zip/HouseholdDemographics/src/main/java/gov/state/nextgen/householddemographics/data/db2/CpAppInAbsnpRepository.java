package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.APP_IN_ABSNP_Cargo;

@NoRepositoryBean
public interface CpAppInAbsnpRepository extends CrudRepository<APP_IN_ABSNP_Cargo, String>{

	@Query("select c from APP_IN_ABSNP_Cargo c where c.appNum = :appNum and c.indvSeqNum = :indvSeqNum")
	public  List<APP_IN_ABSNP_Cargo> findByAppNumIndvSeqNum(String appNum, double indvSeqNum);
	
	@Query("select c from APP_IN_ABSNP_Cargo c where c.appNum = :appNum")
	public  List<APP_IN_ABSNP_Cargo> findByAppNum(String appNum);
	
	@Query("select c from APP_IN_ABSNP_Cargo c where c.appNum = :appNum and c.indvSeqNum = :indvSeqNum and c.apSeqNum = :apSeqNum")
	public  List<APP_IN_ABSNP_Cargo> findByAppNumIndvSeqNumSeqNum(String appNum, double indvSeqNum, double apSeqNum);
}
