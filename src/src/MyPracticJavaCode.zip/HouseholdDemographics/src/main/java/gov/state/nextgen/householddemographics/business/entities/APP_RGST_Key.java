package gov.state.nextgen.householddemographics.business.entities;


import java.io.Serializable;

public class APP_RGST_Key implements Serializable{

	private static final long serialVersionUID = -7406706786506800734L;

	private Integer app_number;

	public APP_RGST_Key(Integer app_num) {
		super();
		this.app_number = app_num;
	}

	public APP_RGST_Key() {

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		return result;
	}

	
	
	
}
