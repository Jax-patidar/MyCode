package gov.state.nextgen.householddemographics.business.entities;

public class RMC_RQST_Cargo {

    private String app_num;
    private String case_num;
    private String ei_chg_sw;
    private String stat_cd;
    private String sbmt_tms;
    private String updt_dt;
    private String ecf_stat_cd;
    private String add_chg_stat_sw;
    private String dabl_stat_sw;
    private String dth_stat_sw;
    private String dvrc_stat_sw;
    private String hous_util_stat_sw;
    private String mrrg_stat_sw;
    private String othr_stat_sw;
    private String preg_add_stat_sw;
    private String preg_chg_stat_sw;
    private String prsn_add_stat_sw;
    private String prsn_move_stat_sw;
    private String app_start_dt;
    private String app_end_dt;
    private String able_to_conceive_resp;
    private String underweight_birth_resp;
    private String liquid_asset_changed;
    private String other_asset_changed;
    private String change_in_care;
    private String change_in_child_care;
    private String change_in_personal_info;

    private String veh_aset_add_ind;
    private String veh_aset_stat_ind;
    private String real_aset_add_ind;
    private String real_aset_stat_ind;
    private String prsn_prop_add_ind;
    private String prsn_prop_stat_ind;
    private String bury_aset_add_ind;
    private String bury_aset_stat_ind;
    private String life_aset_add_ind;
    private String life_aset_stat_ind;
    private String li_aset_add_ind;
    private String li_aset_stat_ind;
    private String tax_stat_sw;
    private String abs_prnt_stat_sw;
    private String rlt_stat_sw;
    private String additional_info_sw;
    private String hlthy_baby_chg_ind;
    private String bcc_diag_chg_ind;
    private String mailAddrAddInd;
    private String mailAddrChgInd;

    /**
     * @return the additional_info_sw
     */
    public String getAdditional_info_sw() {
        return additional_info_sw;
    }

    /**
     * @param additional_info_sw the additional_info_sw to set
     */
    public void setAdditional_info_sw(final String additional_info_sw) {
        this.additional_info_sw = additional_info_sw;
    }

    /**
     * @return the tax_stat_sw
     */
    public String getTax_stat_sw() {
        return tax_stat_sw;
    }

    /**
     * @param tax_stat_sw the tax_stat_sw to set
     */
    public void setTax_stat_sw(final String tax_stat_sw) {
        this.tax_stat_sw = tax_stat_sw;
    }

    /**
     * @return the abs_prnt_stat_sw
     */
    public String getAbs_prnt_stat_sw() {
        return abs_prnt_stat_sw;
    }

    /**
     * @param abs_prnt_stat_sw the abs_prnt_stat_sw to set
     */
    public void setAbs_prnt_stat_sw(final String abs_prnt_stat_sw) {
        this.abs_prnt_stat_sw = abs_prnt_stat_sw;
    }

    /**
     * @return the rlt_stat_sw
     */
    public String getRlt_stat_sw() {
        return rlt_stat_sw;
    }

    /**
     * @param rlt_stat_sw the rlt_stat_sw to set
     */
    public void setRlt_stat_sw(final String rlt_stat_sw) {
        this.rlt_stat_sw = rlt_stat_sw;
    }

    public String getLiquid_asset_changed() {
        return liquid_asset_changed;
    }

    public void setLiquid_asset_changed(final String liquid_asset_changed) {
        this.liquid_asset_changed = liquid_asset_changed;
    }

    public String getOther_asset_changed() {
        return other_asset_changed;
    }

    public void setOther_asset_changed(final String other_asset_changed) {
        this.other_asset_changed = other_asset_changed;
    }

    public String getChange_in_care() {
        return change_in_care;
    }

    public void setChange_in_care(final String change_in_care) {
        this.change_in_care = change_in_care;
    }

    public String getChange_in_child_care() {
        return change_in_child_care;
    }

    public void setChange_in_child_care(final String change_in_child_care) {
        this.change_in_child_care = change_in_child_care;
    }

    public String getChange_in_personal_info() {
        return change_in_personal_info;
    }

    public void setChange_in_personal_info(final String change_in_personal_info) {
        this.change_in_personal_info = change_in_personal_info;
    }

    public String getAble_to_conceive_resp() {
        return able_to_conceive_resp;
    }

    public void setAble_to_conceive_resp(final String able_to_conceive_resp) {
        this.able_to_conceive_resp = able_to_conceive_resp;
    }

    public String getUnderweight_birth_resp() {
        return underweight_birth_resp;
    }

    public void setUnderweight_birth_resp(final String underweight_birth_resp) {
        this.underweight_birth_resp = underweight_birth_resp;
    }

    public String getApp_start_dt() {
        return app_start_dt;
    }

    public void setApp_start_dt(final String app_start_dt) {
        this.app_start_dt = app_start_dt;
    }

    public String getApp_end_dt() {
        return app_end_dt;
    }

    public void setApp_end_dt(final String app_end_dt) {
        this.app_end_dt = app_end_dt;
    }

    /**
     * returns the app_num value.
     */
    public String getApp_num() {
        return app_num;
    }

    /**
     * sets the app_num value.
     */
    public void setApp_num(final String app_num) {
        this.app_num = app_num;
    }

    /**
     * returns the case_num value.
     */
    public String getCase_num() {
        return case_num;
    }

    /**
     * sets the case_num value.
     */
    public void setCase_num(final String case_num) {
        this.case_num = case_num;
    }

    /**
     * returns the ei_chg_sw value.
     */
    public String getEi_chg_sw() {
        return ei_chg_sw;
    }

    /**
     * sets the ei_chg_sw value.
     */
    public void setEi_chg_sw(final String ei_chg_sw) {
        this.ei_chg_sw = ei_chg_sw;
    }

    /**
     * returns the stat_cd value.
     */
    public String getStat_cd() {
        return stat_cd;
    }

    /**
     * sets the stat_cd value.
     */
    public void setStat_cd(final String stat_cd) {
        this.stat_cd = stat_cd;
    }

    /**
     * returns the sbmt_tms value.
     */
    public String getSbmt_tms() {
        return sbmt_tms;
    }

    /**
     * sets the sbmt_tms value.
     */
    public void setSbmt_tms(final String sbmt_tms) {
        this.sbmt_tms = sbmt_tms;
    }

    /**
     * returns the updt_dt value.
     */
    public String getUpdt_dt() {
        return updt_dt;
    }

    /**
     * sets the updt_dt value.
     */
    public void setUpdt_dt(final String updt_dt) {
        this.updt_dt = updt_dt;
    }

    /**
     * returns the ecf_stat_cd value.
     */
    public String getEcf_stat_cd() {
        return ecf_stat_cd;
    }

    /**
     * sets the ecf_stat_cd value.
     */
    public void setEcf_stat_cd(final String ecf_stat_cd) {
        this.ecf_stat_cd = ecf_stat_cd;
    }

    /**
     * returns the add_chg_stat_sw value.
     */
    public String getAdd_chg_stat_sw() {
        return add_chg_stat_sw;
    }

    /**
     * sets the add_chg_stat_sw value.
     */
    public void setAdd_chg_stat_sw(final String add_chg_stat_sw) {
        this.add_chg_stat_sw = add_chg_stat_sw;
    }

    /**
     * returns the dabl_stat_sw value.
     */
    public String getDabl_stat_sw() {
        return dabl_stat_sw;
    }

    /**
     * sets the dabl_stat_sw value.
     */
    public void setDabl_stat_sw(final String dabl_stat_sw) {
        this.dabl_stat_sw = dabl_stat_sw;
    }

    /**
     * returns the dth_stat_sw value.
     */
    public String getDth_stat_sw() {
        return dth_stat_sw;
    }

    /**
     * sets the dth_stat_sw value.
     */
    public void setDth_stat_sw(final String dth_stat_sw) {
        this.dth_stat_sw = dth_stat_sw;
    }

    /**
     * returns the dvrc_stat_sw value.
     */
    public String getDvrc_stat_sw() {
        return dvrc_stat_sw;
    }

    /**
     * sets the dvrc_stat_sw value.
     */
    public void setDvrc_stat_sw(final String dvrc_stat_sw) {
        this.dvrc_stat_sw = dvrc_stat_sw;
    }

    /**
     * returns the hous_util_stat_sw value.
     */
    public String getHous_util_stat_sw() {
        return hous_util_stat_sw;
    }

    /**
     * sets the hous_util_stat_sw value.
     */
    public void setHous_util_stat_sw(final String hous_util_stat_sw) {
        this.hous_util_stat_sw = hous_util_stat_sw;
    }

    /**
     * returns the mrrg_stat_sw value.
     */
    public String getMrrg_stat_sw() {
        return mrrg_stat_sw;
    }

    /**
     * sets the mrrg_stat_sw value.
     */
    public void setMrrg_stat_sw(final String mrrg_stat_sw) {
        this.mrrg_stat_sw = mrrg_stat_sw;
    }

    /**
     * returns the othr_stat_sw value.
     */
    public String getOthr_stat_sw() {
        return othr_stat_sw;
    }

    /**
     * sets the othr_stat_sw value.
     */
    public void setOthr_stat_sw(final String othr_stat_sw) {
        this.othr_stat_sw = othr_stat_sw;
    }

    /**
     * returns the preg_add_stat_sw value.
     */
    public String getPreg_add_stat_sw() {
        return preg_add_stat_sw;
    }

    /**
     * sets the preg_add_stat_sw value.
     */
    public void setPreg_add_stat_sw(final String preg_add_stat_sw) {
        this.preg_add_stat_sw = preg_add_stat_sw;
    }

    /**
     * returns the preg_chg_stat_sw value.
     */
    public String getPreg_chg_stat_sw() {
        return preg_chg_stat_sw;
    }

    /**
     * sets the preg_chg_stat_sw value.
     */
    public void setPreg_chg_stat_sw(final String preg_chg_stat_sw) {
        this.preg_chg_stat_sw = preg_chg_stat_sw;
    }

    /**
     * returns the prsn_add_stat_sw value.
     */
    public String getPrsn_add_stat_sw() {
        return prsn_add_stat_sw;
    }

    /**
     * sets the prsn_add_stat_sw value.
     */
    public void setPrsn_add_stat_sw(final String prsn_add_stat_sw) {
        this.prsn_add_stat_sw = prsn_add_stat_sw;
    }

    /**
     * returns the prsn_move_stat_sw value.
     */
    public String getPrsn_move_stat_sw() {
        return prsn_move_stat_sw;
    }

    /**
     * sets the prsn_move_stat_sw value.
     */
    public void setPrsn_move_stat_sw(final String prsn_move_stat_sw) {
        this.prsn_move_stat_sw = prsn_move_stat_sw;
    }

    public String getVeh_aset_add_ind() {
        return veh_aset_add_ind;
    }

    public void setVeh_aset_add_ind(final String veh_aset_add_ind) {
        this.veh_aset_add_ind = veh_aset_add_ind;
    }

    public String getVeh_aset_stat_ind() {
        return veh_aset_stat_ind;
    }

    public void setVeh_aset_stat_ind(final String veh_aset_stat_ind) {
        this.veh_aset_stat_ind = veh_aset_stat_ind;
    }

    public String getReal_aset_add_ind() {
        return real_aset_add_ind;
    }

    public void setReal_aset_add_ind(final String real_aset_add_ind) {
        this.real_aset_add_ind = real_aset_add_ind;
    }

    public String getReal_aset_stat_ind() {
        return real_aset_stat_ind;
    }

    public void setReal_aset_stat_ind(final String real_aset_stat_ind) {
        this.real_aset_stat_ind = real_aset_stat_ind;
    }

    public String getPrsn_prop_add_ind() {
        return prsn_prop_add_ind;
    }

    public void setPrsn_prop_add_ind(final String prsn_prop_add_ind) {
        this.prsn_prop_add_ind = prsn_prop_add_ind;
    }

    public String getPrsn_prop_stat_ind() {
        return prsn_prop_stat_ind;
    }

    public void setPrsn_prop_stat_ind(final String prsn_prop_stat_ind) {
        this.prsn_prop_stat_ind = prsn_prop_stat_ind;
    }

    public String getBury_aset_add_ind() {
        return bury_aset_add_ind;
    }

    public void setBury_aset_add_ind(final String bury_aset_add_ind) {
        this.bury_aset_add_ind = bury_aset_add_ind;
    }

    public String getBury_aset_stat_ind() {
        return bury_aset_stat_ind;
    }

    public void setBury_aset_stat_ind(final String bury_aset_stat_ind) {
        this.bury_aset_stat_ind = bury_aset_stat_ind;
    }

    public String getLife_aset_add_ind() {
        return life_aset_add_ind;
    }

    public void setLife_aset_add_ind(final String life_aset_add_ind) {
        this.life_aset_add_ind = life_aset_add_ind;
    }

    public String getLife_aset_stat_ind() {
        return life_aset_stat_ind;
    }

    public void setLife_aset_stat_ind(final String life_aset_stat_ind) {
        this.life_aset_stat_ind = life_aset_stat_ind;
    }

    public String getLi_aset_add_ind() {
        return li_aset_add_ind;
    }

    public void setLi_aset_add_ind(final String li_aset_add_ind) {
        this.li_aset_add_ind = li_aset_add_ind;
    }

    public String getLi_aset_stat_ind() {
        return li_aset_stat_ind;
    }

    public void setLi_aset_stat_ind(final String li_aset_stat_ind) {
        this.li_aset_stat_ind = li_aset_stat_ind;
    }

    /**
     * @return the mailAddrAddInd
     */
    public String getMailAddrAddInd() {
        return mailAddrAddInd;
    }

    /**
     * @param mailAddrAddInd the mailAddrAddInd to set
     */
    public void setMailAddrAddInd(String mailAddrAddInd) {
        this.mailAddrAddInd = mailAddrAddInd;
    }

    /**
     * @return the mailAddrChgInd
     */
    public String getMailAddrChgInd() {
        return mailAddrChgInd;
    }

    /**
     * @param mailAddrChgInd the mailAddrChgInd to set
     */
    public void setMailAddrChgInd(String mailAddrChgInd) {
        this.mailAddrChgInd = mailAddrChgInd;
    }


    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (prime * result) + ((able_to_conceive_resp == null) ? 0 : able_to_conceive_resp.trim().hashCode());
        result = (prime * result) + ((abs_prnt_stat_sw == null) ? 0 : abs_prnt_stat_sw.trim().hashCode());
        result = (prime * result) + ((add_chg_stat_sw == null) ? 0 : add_chg_stat_sw.trim().hashCode());
        result = (prime * result) + ((app_end_dt == null) ? 0 : app_end_dt.trim().hashCode());
        result = (prime * result) + ((app_num == null) ? 0 : app_num.trim().hashCode());
        result = (prime * result) + ((app_start_dt == null) ? 0 : app_start_dt.trim().hashCode());
        result = (prime * result) + ((bury_aset_add_ind == null) ? 0 : bury_aset_add_ind.trim().hashCode());
        result = (prime * result) + ((bury_aset_stat_ind == null) ? 0 : bury_aset_stat_ind.trim().hashCode());
        result = (prime * result) + ((case_num == null) ? 0 : case_num.trim().hashCode());
        result = (prime * result) + ((change_in_care == null) ? 0 : change_in_care.trim().hashCode());
        result = (prime * result) + ((change_in_child_care == null) ? 0 : change_in_child_care.trim().hashCode());
        result = (prime * result) + ((change_in_personal_info == null) ? 0 : change_in_personal_info.trim().hashCode());
        result = (prime * result) + ((dabl_stat_sw == null) ? 0 : dabl_stat_sw.trim().hashCode());
        result = (prime * result) + ((dth_stat_sw == null) ? 0 : dth_stat_sw.trim().hashCode());
        result = (prime * result) + ((dvrc_stat_sw == null) ? 0 : dvrc_stat_sw.trim().hashCode());
        result = (prime * result) + ((ecf_stat_cd == null) ? 0 : ecf_stat_cd.trim().hashCode());
        result = (prime * result) + ((ei_chg_sw == null) ? 0 : ei_chg_sw.trim().hashCode());
        result = (prime * result) + ((hous_util_stat_sw == null) ? 0 : hous_util_stat_sw.trim().hashCode());
        result = (prime * result) + ((li_aset_add_ind == null) ? 0 : li_aset_add_ind.trim().hashCode());
        result = (prime * result) + ((li_aset_stat_ind == null) ? 0 : li_aset_stat_ind.trim().hashCode());
        result = (prime * result) + ((life_aset_add_ind == null) ? 0 : life_aset_add_ind.trim().hashCode());
        result = (prime * result) + ((life_aset_stat_ind == null) ? 0 : life_aset_stat_ind.trim().hashCode());
        result = (prime * result) + ((liquid_asset_changed == null) ? 0 : liquid_asset_changed.trim().hashCode());
        result = (prime * result) + ((mrrg_stat_sw == null) ? 0 : mrrg_stat_sw.trim().hashCode());
        result = (prime * result) + ((other_asset_changed == null) ? 0 : other_asset_changed.trim().hashCode());
        result = (prime * result) + ((othr_stat_sw == null) ? 0 : othr_stat_sw.trim().hashCode());
        result = (prime * result) + ((preg_add_stat_sw == null) ? 0 : preg_add_stat_sw.trim().hashCode());
        result = (prime * result) + ((preg_chg_stat_sw == null) ? 0 : preg_chg_stat_sw.trim().hashCode());
        result = (prime * result) + ((prsn_add_stat_sw == null) ? 0 : prsn_add_stat_sw.trim().hashCode());
        result = (prime * result) + ((prsn_move_stat_sw == null) ? 0 : prsn_move_stat_sw.trim().hashCode());
        result = (prime * result) + ((prsn_prop_add_ind == null) ? 0 : prsn_prop_add_ind.trim().hashCode());
        result = (prime * result) + ((prsn_prop_stat_ind == null) ? 0 : prsn_prop_stat_ind.trim().hashCode());
        result = (prime * result) + ((real_aset_add_ind == null) ? 0 : real_aset_add_ind.trim().hashCode());
        result = (prime * result) + ((real_aset_stat_ind == null) ? 0 : real_aset_stat_ind.trim().hashCode());
        result = (prime * result) + ((rlt_stat_sw == null) ? 0 : rlt_stat_sw.trim().hashCode());
        result = (prime * result) + ((sbmt_tms == null) ? 0 : sbmt_tms.trim().hashCode());
        result = (prime * result) + ((stat_cd == null) ? 0 : stat_cd.trim().hashCode());
        result = (prime * result) + ((tax_stat_sw == null) ? 0 : tax_stat_sw.trim().hashCode());
        result = (prime * result) + ((underweight_birth_resp == null) ? 0 : underweight_birth_resp.trim().hashCode());
        result = (prime * result) + ((updt_dt == null) ? 0 : updt_dt.trim().hashCode());
        result = (prime * result) + ((veh_aset_add_ind == null) ? 0 : veh_aset_add_ind.trim().hashCode());
        result = (prime * result) + ((veh_aset_stat_ind == null) ? 0 : veh_aset_stat_ind.trim().hashCode());
        result = (prime * result) + ((additional_info_sw == null) ? 0 : additional_info_sw.trim().hashCode());
        result = (prime * result) + ((hlthy_baby_chg_ind == null) ? 0 : hlthy_baby_chg_ind.trim().hashCode());
        result = (prime * result) + ((bcc_diag_chg_ind == null) ? 0 : bcc_diag_chg_ind.trim().hashCode());
        return result;
    }



    /**
     * @return the hlthy_baby_chg_ind
     */
    public String getHlthy_baby_chg_ind() {
        return hlthy_baby_chg_ind;
    }

    /**
     * @param hlthy_baby_chg_ind the hlthy_baby_chg_ind to set
     */
    public void setHlthy_baby_chg_ind(final String hlthy_baby_chg_ind) {
        this.hlthy_baby_chg_ind = hlthy_baby_chg_ind;
    }

    /**
     * @return the bcc_diag_chg_ind
     */
    public String getBcc_diag_chg_ind() {
        return bcc_diag_chg_ind;
    }

    /**
     * @param bcc_diag_chg_ind the bcc_diag_chg_ind to set
     */
    public void setBcc_diag_chg_ind(final String bcc_diag_chg_ind) {
        this.bcc_diag_chg_ind = bcc_diag_chg_ind;
    }

}

