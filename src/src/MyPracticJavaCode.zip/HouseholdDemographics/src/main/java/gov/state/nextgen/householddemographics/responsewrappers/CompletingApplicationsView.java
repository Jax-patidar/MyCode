package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABHWA")
@Scope("prototype")
public class CompletingApplicationsView implements LogicResponseInterface {

	
	private static final String APP_FILE_HELP_COLLECTION = "APP_FILE_HELP_Collection";
	private static final String PAGE_ID = "ABHWA";

	@Override
	public PageResponse constructPageResponse(FwTransaction txBean) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = txBean.getPageCollection();
		
		APP_FILE_HELP_Cargo cargo = new APP_FILE_HELP_Cargo();
		List<APP_FILE_HELP_Cargo> appFileHelpCargoList = new ArrayList<APP_FILE_HELP_Cargo>();
		APP_FILE_HELP_Collection helpColl = (APP_FILE_HELP_Collection) pageCollection.get(APP_FILE_HELP_COLLECTION);

		if(helpColl != null) {
			cargo = (APP_FILE_HELP_Cargo) helpColl.get(0);
		}
		appFileHelpCargoList.add(cargo);
		driverPageResponse.getPageCollection().put(APP_FILE_HELP_COLLECTION, appFileHelpCargoList);
		

		driverPageResponse.setCurrentPageID(PAGE_ID);
		
		return driverPageResponse;
	}

}
