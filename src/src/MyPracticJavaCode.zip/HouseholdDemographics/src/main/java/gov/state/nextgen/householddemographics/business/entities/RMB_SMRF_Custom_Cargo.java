/*
 * Created on Sep 9, 2009
 *
 */
package gov.state.nextgen.householddemographics.business.entities;


import java.sql.Date;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Entity;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * @author deloitte
 *
 */
public class RMB_SMRF_Custom_Cargo extends AbstractCargo {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	String case_num;
	String cat_type;
	Date review_begin_date;
	Date review_end_date;
	Date review_due_date;
	LocalDateTime actual_review_date;
	Date smrf_begin_date;
	Date smrf_end_date;
	Date smrf_due_date;
	Date actual_smrf_date;
	List cate_type_list;
	List sub_cat_type_list;
	List cla_pin_num_list;
	boolean isReviewDue = true;
	boolean isSMRFDue = true;
	boolean isTCLADue = true;
	boolean isValidAGForReview = true;
	boolean isCLAReviewDue = true;

	


	/**
	 * @return Returns the case_num.
	 */
	public String getCase_num() {
		return case_num;
	}

	/**
	 * @param case_num
	 *            The case_num to set.
	 */
	public void setCase_num(final String case_num) {
		this.case_num = case_num;
	}

	/**
	 * @return Returns the cat_type.
	 */
	public String getCat_type() {
		return cat_type;
	}

	/**
	 * @param cat_type
	 *            The cat_type to set.
	 */
	public void setCat_type(final String cat_type) {
		this.cat_type = cat_type;
	}

	/**
	 * @return Returns the isReviewDue.
	 */
	public boolean isReviewDue() {
		return isReviewDue;
	}

	/**
	 * @param isReviewDue
	 *            The isReviewDue to set.
	 */
	public void setReviewDue(final boolean isReviewDue) {
		this.isReviewDue = isReviewDue;
	}

	/**
	 * @return Returns the isSMRFDue.
	 */
	public boolean isSMRFDue() {
		return isSMRFDue;
	}

	/**
	 * @param isSMRFDue
	 *            The isSMRFDue to set.
	 */
	public void setSMRFDue(final boolean isSMRFDue) {
		this.isSMRFDue = isSMRFDue;
	}

	/**
	 * @return Returns the review_begin_date.
	 */
	public Date getReview_begin_date() {
		return review_begin_date;
	}

	/**
	 * @param review_begin_date
	 *            The review_begin_date to set.
	 */
	public void setReview_begin_date(final Date review_begin_date) {
		this.review_begin_date = review_begin_date;
	}

	/**
	 * @return Returns the review_due_date.
	 */
	public Date getReview_due_date() {
		return review_due_date;
	}

	/**
	 * @param review_due_date
	 *            The review_due_date to set.
	 */
	public void setReview_due_date(final Date review_due_date) {
		this.review_due_date = review_due_date;
	}

	/**
	 * @return Returns the review_end_date.
	 */
	public Date getReview_end_date() {
		return review_end_date;
	}

	/**
	 * @param review_end_date
	 *            The review_end_date to set.
	 */
	public void setReview_end_date(final Date review_end_date) {
		this.review_end_date = review_end_date;
	}

	/**
	 * @return Returns the smrf_begin_date.
	 */
	public Date getSmrf_begin_date() {
		return smrf_begin_date;
	}

	/**
	 * @param smrf_begin_date
	 *            The smrf_begin_date to set.
	 */
	public void setSmrf_begin_date(final Date smrf_begin_date) {
		this.smrf_begin_date = smrf_begin_date;
	}

	/**
	 * @return Returns the smrf_due_date.
	 */
	public Date getSmrf_due_date() {
		return smrf_due_date;
	}

	/**
	 * @param smrf_due_date
	 *            The smrf_due_date to set.
	 */
	public void setSmrf_due_date(final Date smrf_due_date) {
		this.smrf_due_date = smrf_due_date;
	}

	/**
	 * @return Returns the smrf_end_date.
	 */
	public Date getSmrf_end_date() {
		return smrf_end_date;
	}

	/**
	 * @param smrf_end_date
	 *            The smrf_end_date to set.
	 */
	public void setSmrf_end_date(final Date smrf_end_date) {
		this.smrf_end_date = smrf_end_date;
	}

	/**
	 * @return Returns the cate_type_list.
	 */
	public List getCate_type_list() {
		return cate_type_list;
	}

	/**
	 * @param cate_type_list
	 *            The cate_type_list to set.
	 */
	public void setCate_type_list(final List cate_type_list) {
		this.cate_type_list = cate_type_list;
	}

	/**
	 * @return Returns the actual_review_date.
	 */
	public LocalDateTime getActual_review_date() {
		return actual_review_date;
	}

	/**
	 * @param actual_review_date
	 *            The actual_review_date to set.
	 */
	public void setActual_review_date(final LocalDateTime actual_review_date) {
		this.actual_review_date = actual_review_date;
	}

	/**
	 * @return Returns the actual_smrf_date.
	 */
	public Date getActual_smrf_date() {
		return actual_smrf_date;
	}

	/**
	 * @param actual_smrf_date
	 *            The actual_smrf_date to set.
	 */
	public void setActual_smrf_date(final Date actual_smrf_date) {
		this.actual_smrf_date = actual_smrf_date;
	}

	/**
	 * @return Returns the sub_cat_type_list.
	 */
	public List getSub_cat_type_list() {
		return sub_cat_type_list;
	}

	/**
	 * @param sub_cat_type_list
	 *            The sub_cat_type_list to set.
	 */
	public void setSub_cat_type_list(final List sub_cat_type_list) {
		this.sub_cat_type_list = sub_cat_type_list;
	}

	/**
	 * @return Returns the isTCLADue.
	 */
	public boolean isTCLADue() {
		return isTCLADue;
	}

	/**
	 * @param isTCLADue
	 *            The isTCLADue to set.
	 */
	public void setTCLADue(final boolean isTCLADue) {
		this.isTCLADue = isTCLADue;
	}

	/**
	 * @return Returns the isValidAGForReview.
	 */
	public boolean isValidAGForReview() {
		return isValidAGForReview;
	}

	/**
	 * @param isValidAGForReview
	 *            The isValidAGForReview to set.
	 */
	public void setValidAGForReview(final boolean isValidAGForReview) {
		this.isValidAGForReview = isValidAGForReview;
	}

	/**
	 * @return Returns the isCLAReviewDue.
	 */
	public boolean isCLAReviewDue() {
		return isCLAReviewDue;
	}

	/**
	 * @param isCLAReviewDue
	 *            The isCLAReviewDue to set.
	 */
	public void setCLAReviewDue(final boolean isCLAReviewDue) {
		this.isCLAReviewDue = isCLAReviewDue;
	}

	/**
	 * @return Returns the cla_pin_num_list.
	 */
	public List getCla_pin_num_list() {
		return cla_pin_num_list;
	}

	/**
	 * @param cla_pin_num_list
	 *            The cla_pin_num_list to set.
	 */
	public void setCla_pin_num_list(final List cla_pin_num_list) {
		this.cla_pin_num_list = cla_pin_num_list;
	}
}
