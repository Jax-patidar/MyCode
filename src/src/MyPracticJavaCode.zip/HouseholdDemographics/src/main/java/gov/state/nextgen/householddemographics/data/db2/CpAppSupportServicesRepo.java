package gov.state.nextgen.householddemographics.data.db2;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_SUPPORT_SERVICES_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_SUPPORT_SERVICES_Key;

@Repository
public interface CpAppSupportServicesRepo extends CrudRepository<CP_APP_SUPPORT_SERVICES_Cargo, CP_APP_SUPPORT_SERVICES_Key>{
	@Query("select c from CP_APP_SUPPORT_SERVICES_Cargo c where c.app_number = ?1")
	public CP_APP_SUPPORT_SERVICES_Cargo[] getByAppNum(Integer appNum);
	
}
