package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class NO_ONE_Cargo extends AbstractCargo {


    private String no_one_name;
    private String no_one_value;

    /**
     * Inspects Cargo values for debug.
     *
     * Creation Date Thu Jun 24 19:05:32 CDT 2004
     * @return String
     */

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = (prime * result) + ((no_one_name == null) ? 0 : no_one_name.trim().hashCode());
        result = (prime * result) + ((no_one_value == null) ? 0 : no_one_value.trim().hashCode());
        return result;
    }

    /**
     * Returns the no_one_name.
     *
     * Creation Date Thu Jun 24 19:05:32 CDT 2004
     * @return String
     */

    public String getNo_one_name() {
        return no_one_name;
    }

    /**
     * Sets the no_one_name.
     *
     * Creation Date Thu Jun 24 19:05:32 CDT 2004
     * @param no_one_name
     *            The no_one_name to set
     */

    public void setNo_one_name(final String no_one_name) {
        this.no_one_name = no_one_name;
    }

    /**
     * Returns the no_one_value.
     *
     * Creation Date Thu Jun 24 19:05:32 CDT 2004
     * @return char
     */

    public String getNo_one_value() {
        return no_one_value;
    }

    /**
     * Sets the no_one_value.
     *
     * Creation Date Thu Jun 24 19:05:32 CDT 2004
     * @param no_one_value
     *            The no_one_value to set
     */

    public void setNo_one_value(final String no_one_value) {
        this.no_one_value = no_one_value;
    }

   
}
