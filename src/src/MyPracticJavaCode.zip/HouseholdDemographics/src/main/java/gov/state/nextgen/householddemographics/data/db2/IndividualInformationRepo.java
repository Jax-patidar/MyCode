package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.query.Param;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_Cargo;

@NoRepositoryBean
public interface IndividualInformationRepo extends CrudRepository<CP_APP_INDV_Cargo, Integer> {

    List<CP_APP_INDV_Cargo> findByAppNumAndRlvnIndNot(Integer app_num,Integer rlvn_ind);

    CP_APP_INDV_Cargo findByAppNumAndIndvSeqNum(Integer appNum, String indvSeqNum);

    List<CP_APP_INDV_Cargo> findByAppNum(Integer appNum);

    List<CP_APP_INDV_Cargo> findAllByAppNumAndIndvSeqNumOrderByIndvSeqNum(Integer appNum, String indvSeqNum);

    List<CP_APP_INDV_Cargo> findAllByAppNumAndLeftHomeReasonCdIn(Integer appNum,List<String> leftHomeReasonCds);

    @Query("SELECT cargo FROM CP_APP_INDV_Cargo cargo WHERE app_number = :appNum AND src_app_ind  IN ('CW','RM') ORDER BY indvSeqNum, src_app_ind")
    List<CP_APP_INDV_Cargo> findByAppNumWithConditionalSrcAppInd(@Param("appNum") Integer appNum);
}
