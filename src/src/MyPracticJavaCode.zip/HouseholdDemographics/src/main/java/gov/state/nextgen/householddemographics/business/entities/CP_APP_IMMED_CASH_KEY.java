package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class CP_APP_IMMED_CASH_KEY implements Serializable{
	/**
    *
    */
   private static final long serialVersionUID = 1L;
	private Integer app_number;
	
	private String immed_cash_id;

	public CP_APP_IMMED_CASH_KEY() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CP_APP_IMMED_CASH_KEY(Integer app_number, String immed_cash_id) {
		super();
		this.app_number = app_number;
		this.immed_cash_id = immed_cash_id;
	}


	public Integer getApp_number() {
		return app_number;
	}

	public void setApp_number(Integer app_number) {
		this.app_number = app_number;
	}

	public String getImmed_cash_id() {
		return immed_cash_id;
	}

	public void setImmed_cash_id(String immed_cash_id) {
		this.immed_cash_id = immed_cash_id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((immed_cash_id == null) ? 0 : immed_cash_id.hashCode());
		return result;
	}

	

	
	
}
