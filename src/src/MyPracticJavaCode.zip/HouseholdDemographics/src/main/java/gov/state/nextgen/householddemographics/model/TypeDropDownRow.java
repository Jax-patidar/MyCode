package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

public class TypeDropDownRow implements Serializable {

    private static final long serialVersionUID = 1270148599274780099L;

    private String code;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
