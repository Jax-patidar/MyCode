package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(APP_SBMS_Key.class)
@Table(name="cp_app_sbms",schema = "IE_SSP_OWNER_HH")
public class APP_SBMS_Cargo extends AbstractCargo implements Serializable{

	public String getReview_sps_first_name() {
		return review_sps_first_name;
	}

	public void setReview_sps_first_name(String review_sps_first_name) {
		this.review_sps_first_name = review_sps_first_name;
	}

	public String getReview_sps_last_name() {
		return review_sps_last_name;
	}

	public void setReview_sps_last_name(String review_sps_last_name) {
		this.review_sps_last_name = review_sps_last_name;
	}

	public Date getReview_sps_sign_date() {
		return review_sps_sign_date;
	}

	public void setReview_sps_sign_date(Date review_sps_sign_date) {
		this.review_sps_sign_date = review_sps_sign_date;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Transient
	private String bus_hr_exmp_ind;
	@Transient
	private String care_exmp_ind;
	@Transient
	private String cc_exmp_ind;
	private String e_sign_ind;
	@Transient
	private String edb_exmp_ind;
	@Transient
	private String fs_ivw_resp;
	@Column(name="first_name")
	private String fst_nam;
	@Transient
	private String ilns_exmp_ind;
	@Column(name="last_name")
	private String last_nam;
	@Transient
	private String mid_init;
	@Transient
	private String othr_exmp_ind;
	private String sps_esign_ind;
	@JsonProperty("sps_first_name")
	@Column(name="sps_first_name")
	private String sps_fst_nam;
	@JsonProperty("sps_last_name")
	@Column(name="sps_last_name")
	private String sps_last_nam;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date sps_sign_dt;
	@Transient
	private String sps_mid_init;
	@Transient
	private String trnsp_exmp_ind;
	@Transient
	private String ucmft_exmp_ind;
	@Transient
	private String work_exmp_ind;
	@Transient
	private String wthr_exmp_ind;
	@Transient
	private String othr_rsn_txt;
	@Transient
	private String direct_pay_sw;

	// EDSP Starts
	@Transient
	private String info_exchange_consent_ind;
	@Transient
	private String electronically_sign_ind;
	@Transient
	private String unable_sign_ind;
	@Transient
	private String voter_registration_sw;
	public String getApplicant_home_ph() {
		return applicant_home_ph;
	}

	public void setApplicant_home_ph(String applicant_home_ph) {
		this.applicant_home_ph = applicant_home_ph;
	}

	public String getApplicant_mobile_ph() {
		return applicant_mobile_ph;
	}

	public void setApplicant_mobile_ph(String applicant_mobile_ph) {
		this.applicant_mobile_ph = applicant_mobile_ph;
	}

	public String getWitness_first_name() {
		return witness_first_name;
	}

	public void setWitness_first_name(String witness_first_name) {
		this.witness_first_name = witness_first_name;
	}

	public String getWitness_last_name() {
		return witness_last_name;
	}

	public void setWitness_last_name(String witness_last_name) {
		this.witness_last_name = witness_last_name;
	}

	public Date getWitness_sign_dt() {
		return witness_sign_dt;
	}

	public void setWitness_sign_dt(Date witness_sign_dt) {
		this.witness_sign_dt = witness_sign_dt;
	}

	@Transient
	private String suffix_name;
	private String applicant_first_name;
	private String applicant_last_name;
	private String applicant_mid_name;
	private String applicant_home_ph;
	private String applicant_mobile_ph;
	private String witness_first_name;
	private String witness_last_name;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date witness_sign_dt;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date sign_dt;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
	private Date sbms_dt;
	@Transient
	private String applicant_suffix_name;
	@Transient
	private String application_my_certi;
	@Transient
	private String application_other_certi;
	@Transient
	private String apply_medicaid;
	@Transient
	private String renewal_of_coverage;
	@Transient
	private String expedited_fap_sw;
	@Transient
	private String medicaid_abd_sw;
	@Transient
	private String pregnant_sw;
	@Transient
	private String new_born_sw;
	@Transient
	private String citizenship_sign;
	@Transient
	private String authrep_citizenship_sign;
	@Transient
	private String e_sign_ind1[];
	@Transient
	private String sps_esign_ind1[];
	@Transient
	private String eSign_time;
	@JsonProperty("review_sps_first_name")
	@Column(name="review_sps_first_name")
	private String review_sps_first_name;
	@JsonProperty("review_sps_last_name")
	@Column(name="review_sps_last_name")
	private String review_sps_last_name;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date review_sps_sign_date;
	private String review_esign_ind;
	@Transient
	private String[] review_esign_ind1;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date applicant_sign_dt;
	@Column(name="prog_types")
	private String prog_types;
	
	public Date getApplicant_sign_dt() {
		return applicant_sign_dt;
	}

	public void setApplicant_sign_dt(Date applicant_sign_dt) {
		this.applicant_sign_dt = applicant_sign_dt;
	}

	public String[] getReview_esign_ind1() {
		return review_esign_ind1;
	}

	public void setReview_esign_ind1(String[] review_esign_ind1) {
		this.review_esign_ind1 = review_esign_ind1;
	}

	public String getReview_esign_ind() {
		return review_esign_ind;
	}

	public void setReview_esign_ind(String review_esign_ind) {
		this.review_esign_ind = review_esign_ind;
	}

	public String[] getSps_esign_ind1() {
		return sps_esign_ind1;
	}

	public void setSps_esign_ind1(String[] sps_esign_ind1) {
		this.sps_esign_ind1 = sps_esign_ind1;
	}

	private String office_id;
	@Transient
	private ArrayList<String> esignArr;
    private String phone_num;
    private String address; 
    private String case_num;
    private String form_type;
    private String org_user_agency_name;
    
    @Transient
	private String case_county_cd;
	@Transient
	private String change_summary;
	
	
	public String getCase_county_cd() {
		return case_county_cd;
	}
	public void setCase_county_cd(String case_county_cd) {
		this.case_county_cd = case_county_cd;
	}
	public String getChange_summary() {
		return change_summary;
	}
	public void setChange_summary(String change_summary) {
		this.change_summary = change_summary;
	}
	
	/**
	 * @return the medicaid_abd_sw
	 */
	public String getMedicaid_abd_sw() {
		return medicaid_abd_sw;
	}

	public String[] getE_sign_ind1() {
		return e_sign_ind1;
	}

	public void setE_sign_ind1(String[] e_sign_ind1) {
		this.e_sign_ind1 = e_sign_ind1;
	}

	/**
	 * @param medicaid_abd_sw the medicaid_abd_sw to set
	 */
	public void setMedicaid_abd_sw(final String medicaid_abd_sw) {
		this.medicaid_abd_sw = medicaid_abd_sw;
	}

	/**
	 * @return the pregnant_sw
	 */
	public String getPregnant_sw() {
		return pregnant_sw;
	}

	/**
	 * @param pregnant_sw the pregnant_sw to set
	 */
	public void setPregnant_sw(final String pregnant_sw) {
		this.pregnant_sw = pregnant_sw;
	}

	/**
	 * @return the new_born_sw
	 */
	public String getNew_born_sw() {
		return new_born_sw;
	}

	/**
	 * @param new_born_sw the new_born_sw to set
	 */
	public void setNew_born_sw(final String new_born_sw) {
		this.new_born_sw = new_born_sw;
	}

	/**
	 * @return the expedited_fap_sw
	 */
	public String getExpedited_fap_sw() {
		return expedited_fap_sw;
	}

	/**
	 * @param expedited_fap_sw the expedited_fap_sw to set
	 */
	public void setExpedited_fap_sw(final String expedited_fap_sw) {
		this.expedited_fap_sw = expedited_fap_sw;
	}

	/**
	 * returns the citizenship certification value for applicant.
	 */

	public String getApplication_my_certi() {
		return application_my_certi;
	}

	/**
	 * citizenship certification value for applicant.
	 */

	public void setApplication_my_certi(final String application_my_certi) {
		this.application_my_certi = application_my_certi;
	}

	/**
	 * returns the citizenship certification value for applicant when certifying
	 * for someone else.
	 */

	public String getApplication_other_certi() {
		return application_other_certi;
	}

	/**
	 * citizenship certification value for applicant when certifying for someone
	 * else.
	 */

	public void setApplication_other_certi(final String application_other_certi) {
		this.application_other_certi = application_other_certi;
	}

	/**
	 * returns the applying for full medicaid.
	 */

	public String getApply_medicaid() {
		return apply_medicaid;
	}

	/**
	 * applying for full medicaid.
	 */

	public void setApply_medicaid(final String apply_medicaid) {
		this.apply_medicaid = apply_medicaid;
	}

	/**
	 * returns the applying for renewal.
	 */
	public String getCitizenship_sign() {
		return citizenship_sign;
	}

	public void setCitizenship_sign(final String citizenship_sign) {
		this.citizenship_sign = citizenship_sign;
	}

	public String getAuthrep_citizenship_sign() {
		return authrep_citizenship_sign;
	}

	public void setAuthrep_citizenship_sign(final String authrep_citizenship_sign) {
		this.authrep_citizenship_sign = authrep_citizenship_sign;
	}

	public String getRenewal_of_coverage() {
		return renewal_of_coverage;
	}

	/**
	 * applying for renewal.
	 */
	public void setRenewal_of_coverage(final String renewal_of_coverage) {
		this.renewal_of_coverage = renewal_of_coverage;
	}

	/**
	 * returns the info_exchange_consent_ind value.
	 */
	public String getInfo_exchange_consent_ind() {
		return info_exchange_consent_ind;
	}

	/**
	 *
	 * @param info_exchange_consent_ind
	 */
	public void setInfo_exchange_consent_ind(final String info_exchange_consent_ind) {
		this.info_exchange_consent_ind = info_exchange_consent_ind;
	}

	/**
	 * returns the electronically_sign_ind value.
	 */
	public String getElectronically_sign_ind() {
		return electronically_sign_ind;
	}

	/**
	 *
	 * @param electronically_sign_ind
	 */
	public void setElectronically_sign_ind(final String electronically_sign_ind) {
		this.electronically_sign_ind = electronically_sign_ind;
	}

	/**
	 * returns the unable_sign_ind value.
	 */
	public String getUnable_sign_ind() {
		return unable_sign_ind;
	}

	/**
	 *
	 * @param unable_sign_ind
	 */
	public void setUnable_sign_ind(final String unable_sign_ind) {
		this.unable_sign_ind = unable_sign_ind;
	}

	/**
	 * returns the suffix_name value.
	 */
	public String getSuffix_name() {
		return suffix_name;
	}

	/**
	 *
	 * @param suffix_name
	 */
	public void setSuffix_name(final String suffix_name) {
		this.suffix_name = suffix_name;
	}

	/**
	 * returns the applicant_first_name value.
	 */
	public String getApplicant_first_name() {
		return applicant_first_name;
	}

	/**
	 *
	 * @param applicant_first_name
	 */
	public void setApplicant_first_name(final String applicant_first_name) {
		this.applicant_first_name = applicant_first_name;
	}

	/**
	 * returns the applicant_last_name value.
	 */
	public String getApplicant_last_name() {
		return applicant_last_name;
	}

	/**
	 *
	 * @param applicant_last_name
	 */
	public void setApplicant_last_name(final String applicant_last_name) {
		this.applicant_last_name = applicant_last_name;
	}

	/**
	 * returns the applicant_mid_name value.
	 */
	public String getApplicant_mid_name() {
		return applicant_mid_name;
	}

	/**
	 *
	 * @param applicant_mid_name
	 */
	public void setApplicant_mid_name(final String applicant_mid_name) {
		this.applicant_mid_name = applicant_mid_name;
	}

	/**
	 * returns the applicant_suffix_name value.
	 */
	public String getApplicant_suffix_name() {
		return applicant_suffix_name;
	}

	/**
	 *
	 * @param applicant_suffix_name
	 */
	public void setApplicant_suffix_name(final String applicant_suffix_name) {
		this.applicant_suffix_name = applicant_suffix_name;
	}

	// EDPS Ends

	/**
	 *
	 * @return
	 */
	public String getVoter_registration_sw() {
		return voter_registration_sw;
	}

	/**
	 *
	 * @param voter_registration_sw
	 */
	public void setVoter_registration_sw(final String voter_registration_sw) {
		this.voter_registration_sw = voter_registration_sw;
	}

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	
	/**
	 * returns the bus_hr_exmp_ind value.
	 */
	public String getBus_hr_exmp_ind() {
		return bus_hr_exmp_ind;
	}

	/**
	 * sets the bus_hr_exmp_ind value.
	 */
	public void setBus_hr_exmp_ind(final String bus_hr_exmp_ind) {
		this.bus_hr_exmp_ind = bus_hr_exmp_ind;
	}

	/**
	 * returns the care_exmp_ind value.
	 */
	public String getCare_exmp_ind() {
		return care_exmp_ind;
	}

	/**
	 * sets the care_exmp_ind value.
	 */
	public void setCare_exmp_ind(final String care_exmp_ind) {
		this.care_exmp_ind = care_exmp_ind;
	}

	/**
	 * returns the cc_exmp_ind value.
	 */
	public String getCc_exmp_ind() {
		return cc_exmp_ind;
	}

	/**
	 * sets the cc_exmp_ind value.
	 */
	public void setCc_exmp_ind(final String cc_exmp_ind) {
		this.cc_exmp_ind = cc_exmp_ind;
	}

	/**
	 * returns the edb_exmp_ind value.
	 */
	public String getEdb_exmp_ind() {
		return edb_exmp_ind;
	}

	/**
	 * sets the edb_exmp_ind value.
	 */
	public void setEdb_exmp_ind(final String edb_exmp_ind) {
		this.edb_exmp_ind = edb_exmp_ind;
	}

	/**
	 * returns the fs_ivw_resp value.
	 */
	public String getFs_ivw_resp() {
		return fs_ivw_resp;
	}

	/**
	 * sets the fs_ivw_resp value.
	 */
	public void setFs_ivw_resp(final String fs_ivw_resp) {
		this.fs_ivw_resp = fs_ivw_resp;
	}

	/**
	 * returns the fst_nam value.
	 */
	public String getFst_nam() {
		return fst_nam;
	}

	/**
	 * sets the fst_nam value.
	 */
	public void setFst_nam(final String fst_nam) {
		this.fst_nam = fst_nam;
	}

	/**
	 * returns the ilns_exmp_ind value.
	 */
	public String getIlns_exmp_ind() {
		return ilns_exmp_ind;
	}

	/**
	 * sets the ilns_exmp_ind value.
	 */
	public void setIlns_exmp_ind(final String ilns_exmp_ind) {
		this.ilns_exmp_ind = ilns_exmp_ind;
	}

	/**
	 * returns the last_nam value.
	 */
	public String getLast_nam() {
		return last_nam;
	}

	/**
	 * sets the last_nam value.
	 */
	public void setLast_nam(final String last_nam) {
		this.last_nam = last_nam;
	}

	/**
	 * returns the mid_init value.
	 */
	public String getMid_init() {
		return mid_init;
	}

	/**
	 * sets the mid_init value.
	 */
	public void setMid_init(final String mid_init) {
		this.mid_init = mid_init;
	}

	/**
	 * returns the othr_exmp_ind value.
	 */
	public String getOthr_exmp_ind() {
		return othr_exmp_ind;
	}

	/**
	 * sets the othr_exmp_ind value.
	 */
	public void setOthr_exmp_ind(final String othr_exmp_ind) {
		this.othr_exmp_ind = othr_exmp_ind;
	}

	/**
	 * returns the sps_fst_nam value.
	 */
	public String getSps_fst_nam() {
		return sps_fst_nam;
	}

	/**
	 * sets the sps_fst_nam value.
	 */
	public void setSps_fst_nam(final String sps_fst_nam) {
		this.sps_fst_nam = sps_fst_nam;
	}

	/**
	 * returns the sps_last_nam value.
	 */
	public String getSps_last_nam() {
		return sps_last_nam;
	}

	/**
	 * sets the sps_last_nam value.
	 */
	public void setSps_last_nam(final String sps_last_nam) {
		this.sps_last_nam = sps_last_nam;
	}

	/**
	 * returns the sps_mid_init value.
	 */
	public String getSps_mid_init() {
		return sps_mid_init;
	}

	/**
	 * sets the sps_mid_init value.
	 */
	public void setSps_mid_init(final String sps_mid_init) {
		this.sps_mid_init = sps_mid_init;
	}

	/**
	 * returns the trnsp_exmp_ind value.
	 */
	public String getTrnsp_exmp_ind() {
		return trnsp_exmp_ind;
	}

	/**
	 * sets the trnsp_exmp_ind value.
	 */
	public void setTrnsp_exmp_ind(final String trnsp_exmp_ind) {
		this.trnsp_exmp_ind = trnsp_exmp_ind;
	}

	/**
	 * returns the ucmft_exmp_ind value.
	 */
	public String getUcmft_exmp_ind() {
		return ucmft_exmp_ind;
	}

	/**
	 * sets the ucmft_exmp_ind value.
	 */
	public void setUcmft_exmp_ind(final String ucmft_exmp_ind) {
		this.ucmft_exmp_ind = ucmft_exmp_ind;
	}

	/**
	 * returns the work_exmp_ind value.
	 */
	public String getWork_exmp_ind() {
		return work_exmp_ind;
	}

	/**
	 * sets the work_exmp_ind value.
	 */
	public void setWork_exmp_ind(final String work_exmp_ind) {
		this.work_exmp_ind = work_exmp_ind;
	}

	/**
	 * returns the wthr_exmp_ind value.
	 */
	public String getWthr_exmp_ind() {
		return wthr_exmp_ind;
	}

	/**
	 * sets the wthr_exmp_ind value.
	 */
	public void setWthr_exmp_ind(final String wthr_exmp_ind) {
		this.wthr_exmp_ind = wthr_exmp_ind;
	}

	/**
	 * returns the othr_rsn_txt value.
	 */
	public String getOthr_rsn_txt() {
		return othr_rsn_txt;
	}

	/**
	 * sets the othr_rsn_txt value.
	 */
	public void setOthr_rsn_txt(final String othr_rsn_txt) {
		this.othr_rsn_txt = othr_rsn_txt;
	}

	/**
	 * @return the direct_pay_sw
	 */
	public String getDirect_pay_sw() {
		return direct_pay_sw;
	}

	/**
	 * @param direct_pay_sw
	 *            the direct_pay_sw to set
	 */
	public void setDirect_pay_sw(final String direct_pay_sw) {
		this.direct_pay_sw = direct_pay_sw;
	}

	public Date getSps_sign_dt() {
		return sps_sign_dt;
	}

	public void setSps_sign_dt(Date sps_sign_dt) {
		this.sps_sign_dt = sps_sign_dt;
	}

	public Date getSign_dt() {
		return sign_dt;
	}

	public void setSign_dt(Date sign_dt) {
		this.sign_dt = sign_dt;
	}

	public String getE_sign_ind() {
		return e_sign_ind;
	}

	public void setE_sign_ind(String e_sign_ind) {
		this.e_sign_ind = e_sign_ind;
	}

	public String getSps_esign_ind() {
		return sps_esign_ind;
	}

	public void setSps_esign_ind(String sps_esign_ind) {
		this.sps_esign_ind = sps_esign_ind;
	}
	
	public void setSbms_dt(Date sbms_dt) {
		this.sbms_dt = sbms_dt;
	}

	public String getOffice_id() {
		return office_id;
	}

	public void setOffice_id(String office_id) {
		this.office_id = office_id;
	}
	public ArrayList<String> getEsignArr() {
		return esignArr;
	}

	public void setEsignArr(ArrayList<String> esignArr) {
		this.esignArr = esignArr;
	}

	public String getPhone_num() {
		return phone_num;
	}

	public void setPhone_num(String phone_num) {
		this.phone_num = phone_num;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCase_num() {
		return case_num;
	}

	public void setCase_num(String case_num) {
		this.case_num = case_num;
	}

	public String getForm_type() {
		return form_type;
	}

	public void setForm_type(String form_type) {
		this.form_type = form_type;
	}
	
	public String getOrg_user_agency_name() {
		return org_user_agency_name;
	}

	public void setOrg_user_agency_name(String org_user_agency_name) {
		this.org_user_agency_name = org_user_agency_name;
	}

	public String geteSign_time() {
		return eSign_time;
	}

	public void seteSign_time(String eSign_time) {
		this.eSign_time = eSign_time;
	}

	
	public String getProg_types() {
		return prog_types;
	}

	public void setProg_types(String prog_types) {
		this.prog_types = prog_types;
	}
	
	}
