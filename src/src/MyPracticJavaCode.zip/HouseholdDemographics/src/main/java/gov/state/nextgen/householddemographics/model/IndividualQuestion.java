package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

public class IndividualQuestion extends  Individual implements Serializable {

    private static final long serialVersionUID = 5014669535437073990L;

    private String questionType;
    private String questionKey;
    private Boolean readOnly = false;
    private String selected;
    private String otherSeqNumber;
    private String shareValue;
    private String shareKey;
    private String someoneFirstName;
    private String someoneLastName;

    public String getQuestionType() {
        return questionType;
    }

    public void setQuestionType(String questionType) {
        this.questionType = questionType;
    }

    public String getQuestionKey() {
        return questionKey;
    }

    public void setQuestionKey(String questionKey) {
        this.questionKey = questionKey;
    }

    public Boolean getReadOnly() {
        return readOnly;
    }

    public void setReadOnly(Boolean readOnly) {
        this.readOnly = readOnly;
    }

    public String getSelected() {
        return selected;
    }

    public void setSelected(String selected) {
        this.selected = selected;
    }

    public String getOtherSeqNumber() {
        return otherSeqNumber;
    }

    public void setOtherSeqNumber(String otherSeqNumber) {
        this.otherSeqNumber = otherSeqNumber;
    }

    public String getShareValue() {
        return shareValue;
    }

    public void setShareValue(String shareValue) {
        this.shareValue = shareValue;
    }

    public String getShareKey() {
        return shareKey;
    }

    public void setShareKey(String shareKey) {
        this.shareKey = shareKey;
    }

    public String getSomeoneFirstName() {
        return someoneFirstName;
    }

    public void setSomeoneFirstName(String someoneFirstName) {
        this.someoneFirstName = someoneFirstName;
    }

    public String getSomeoneLastName() {
        return someoneLastName;
    }

    public void setSomeoneLastName(String someoneLastName) {
        this.someoneLastName = someoneLastName;
    }
}
