package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

public class HouseHoldInfoMovedOut implements Serializable {

    private static final long serialVersionUID = -8077346330849983351L;

    private String movedOutResponse;

    private String date_movedOut;

    private String indvSeqNum;

    private String brth_Dt;

    private String page_Status;

    private String category_Type;

    private String[] first_Name;

    public String getMovedOutResponse() {
        return movedOutResponse;
    }

    public void setMovedOutResponse(String movedOutResponse) {
        this.movedOutResponse = movedOutResponse;
    }

    public String getDate_movedOut() {
        return date_movedOut;
    }

    public void setDate_movedOut(String date_movedOut) {
        this.date_movedOut = date_movedOut;
    }

    public String getIndvSeqNum() {
        return indvSeqNum;
    }

    public void setIndvSeqNum(String indvSeqNum) {
        this.indvSeqNum = indvSeqNum;
    }

    public String getBrth_Dt() {
        return brth_Dt;
    }

    public void setBrth_Dt(String brth_Dt) {
        this.brth_Dt = brth_Dt;
    }

    public String getPage_Status() {
        return page_Status;
    }

    public void setPage_Status(String page_Status) {
        this.page_Status = page_Status;
    }

    public String getCategory_Type() {
        return category_Type;
    }

    public void setCategory_Type(String category_Type) {
        this.category_Type = category_Type;
    }

    public String[] getFirst_Name() {
        return first_Name;
    }

    public void setFirst_Name(String[] first_Name) {
        this.first_Name = first_Name;
    }
}
