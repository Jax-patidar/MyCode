package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import java.sql.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class CP_CC_SCRNR_RESULTS_Cargo extends AbstractCargo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5732911624404409231L;
	
	@Id
	private String app_num;
	
	private String scrnr_seq;
	private String screener_result;
	private String ga_resident_result;
	private String has_chld_less13;
	private String has_chld_14to18;
	private String has_chld_spcl_needs;
	private String has_chld_court_order;
	private String income_test;
	private String does_caretaker_meet_criteria;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date create_dt;
	
	private String has_minor_parent;

	public String getApp_num() {
		return app_num;
	}

	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}

	public String getScrnr_seq() {
		return scrnr_seq;
	}

	public void setScrnr_seq(String scrnr_seq) {
		this.scrnr_seq = scrnr_seq;
	}

	public String getScreener_result() {
		return screener_result;
	}

	public void setScreener_result(String screener_result) {
		this.screener_result = screener_result;
	}

	public String getGa_resident_result() {
		return ga_resident_result;
	}

	public void setGa_resident_result(String ga_resident_result) {
		this.ga_resident_result = ga_resident_result;
	}

	public String getHas_chld_less13() {
		return has_chld_less13;
	}

	public void setHas_chld_less13(String has_chld_less13) {
		this.has_chld_less13 = has_chld_less13;
	}

	public String getHas_chld_14to18() {
		return has_chld_14to18;
	}

	public void setHas_chld_14to18(String has_chld_14to18) {
		this.has_chld_14to18 = has_chld_14to18;
	}

	public String getHas_chld_spcl_needs() {
		return has_chld_spcl_needs;
	}

	public void setHas_chld_spcl_needs(String has_chld_spcl_needs) {
		this.has_chld_spcl_needs = has_chld_spcl_needs;
	}

	public String getHas_chld_court_order() {
		return has_chld_court_order;
	}

	public void setHas_chld_court_order(String has_chld_court_order) {
		this.has_chld_court_order = has_chld_court_order;
	}

	public String getIncome_test() {
		return income_test;
	}

	public void setIncome_test(String income_test) {
		this.income_test = income_test;
	}

	public String getDoes_caretaker_meet_criteria() {
		return does_caretaker_meet_criteria;
	}

	public void setDoes_caretaker_meet_criteria(String does_caretaker_meet_criteria) {
		this.does_caretaker_meet_criteria = does_caretaker_meet_criteria;
	}

	public Date getCreate_dt() {
		return create_dt;
	}

	public void setCreate_dt(Date create_dt) {
		this.create_dt = create_dt;
	}

	public String getHas_minor_parent() {
		return has_minor_parent;
	}

	public void setHas_minor_parent(String has_minor_parent) {
		this.has_minor_parent = has_minor_parent;
	}


}
