package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.sun.xml.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABCPS")
@Scope("prototype")
public class CaretakerPersonSelectionView implements LogicResponseInterface{
	
	private static final String PAGE_ID = "ABCPS";
	
	private static final String CP_APP_HSHL_RLT_COLL = "CP_APP_HSHL_RLT_Collection";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTxn.getPageCollection();
		List<CP_APP_HSHL_RLT_Cargo> hshlRltList = new ArrayList<CP_APP_HSHL_RLT_Cargo>();
		CP_APP_HSHL_RLT_Cargo cpAppHshlCargo;
		CP_APP_HSHL_RLT_Collection cpAppHshlColl = pageCollection.get(CP_APP_HSHL_RLT_COLL) != null ? (CP_APP_HSHL_RLT_Collection) pageCollection.get(CP_APP_HSHL_RLT_COLL) : null;
	
		if(cpAppHshlColl != null && !cpAppHshlColl.isEmpty() && cpAppHshlColl.size() >0) {			
			for (int i = 0; i < cpAppHshlColl.size(); i++) {
				cpAppHshlCargo = (CP_APP_HSHL_RLT_Cargo) cpAppHshlColl.get(i);
				hshlRltList.add(cpAppHshlCargo);
			}
		}
		
		driverPageResponse.getPageCollection().put(CP_APP_HSHL_RLT_COLL, hshlRltList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		
		return driverPageResponse;
		
		
	}
	
	


	

}
