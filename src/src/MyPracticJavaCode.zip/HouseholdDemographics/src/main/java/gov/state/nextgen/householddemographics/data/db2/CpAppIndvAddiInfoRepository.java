package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Key;


@Repository
public interface CpAppIndvAddiInfoRepository extends CrudRepository<CP_APP_INDV_ADDI_INFO_Cargo,CP_APP_INDV_ADDI_INFO_Key>
{
    @Query("select c from CP_APP_INDV_ADDI_INFO_Cargo c where c.app_number = ?1")
    public CP_APP_INDV_ADDI_INFO_Collection getByAppNum(Integer appNum);
    
}
