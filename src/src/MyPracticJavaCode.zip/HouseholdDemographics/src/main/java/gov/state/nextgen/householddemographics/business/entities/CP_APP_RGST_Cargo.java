/**
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * @author khuskumari
 *
 */
@Entity
@Table(name="CP_APP_RGST")
@IdClass(CP_APP_RGST_Key.class)
public class CP_APP_RGST_Cargo extends AbstractCargo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	private String src_app_ind;
	@Id
	private Integer indv_seq_num;
	@Column(name="alt_city_address")
	private String alt_city_adr;
	@Column(name="alt_l2_address")
	private String alt_l2_adr;
	@Column(name="alt_st_address")
	private String alt_st_adr;
	@Column(name="alt_sta_address")
	private String alt_sta_adr;
	@Column(name="alt_zip_address")
	private String alt_zip_adr;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="change_eff_dt")
	private Date chg_eff_dt;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="contact_eff_dt")
	private Date contact_eff_dt;

	@Column(name="county_num")
	private String cnty_num;
	@Transient
	private String radioGroup_HOME;
	@Transient
	private String mail_adr_ind;
	@Transient
	private String homeless_a_ind;
	private String hless_sw;
	@Column(name="hshl_cell_phone_num")
	private String hshl_cell_phn_num;
	@Column(name="hshl_city_address")
	private String hshl_city_adr;
	@Column(name="hshl_email_address")
	private String hshl_email_adr;
	@Column(name="hshl_home_phone_num")
	private String hshl_home_phn_num;
	private Integer hshl_indv_ct;
	@Column(name="hshl_l1_address")
	private String hshl_l1_adr;
	@Column(name="hshl_l2_address")
	private String hshl_l2_adr;
	@Column(name="hshl_sta_address")
	private String hshl_sta_adr;
	@Column(name="hshl_work_phone_num")
	private String hshl_work_phn_num;
	@Column(name="hshl_zip_address")
	private String hshl_zip_adr;
	private String lang_cd;
	@Column(name="msg_phone_extn_num")
	private String msg_phn_extn_num;
	@Column(name="msg_phone_num")
	private String msg_phn_num;
	@Column(name="phone_num_type")
	private String phn_num_typ;
	private Integer pref_cntc_ind;
	private Integer rec_cplt_ind;
	@Column(name="work_phone_extn_num")
	private String work_phn_extn_num;
	private String ebt_card_resp;
	private String text_sent_ind;
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="home_address_change_begin_dt")
	private Date home_addr_chg_begin_dt;
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="mail_address_change_begin_dt")
	private Date mail_addr_chg_begin_dt;
	private String other_assistance_sw;
	private String hshl_apt_num;
	private String alt_apt_num;
	@Column(name="alt_l1_address")
	private String alt_l1_adr;
	private String living_plcd_govt_agency_ind;
	private String pref_cont_method_cd;
	private String pref_cont_method_case_cd;
	@Column(name="app_type")
	private String app_typ;
	@Column(name="alt_address_zip4")
	private String alt_addr_zip4;
	@Column(name="hshl_address_zip4")
	private String hshl_addr_zip4;
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="change_dt")
	private Date chg_dt;
	@Column(name="wic_clnc_county")
	private String wic_clnc_cnty;
	private String wic_clnc_cd;
	private String county_office_num;
	private String email_receipt;
	private String phonenum_receipt;
	private String temp_street_address;
	private String temp_l2_address;
	private String temp_city_address;
	private String temp_county_num;
	private String temp_state_address;
	private String temp_zip_address;
	private String work_street_address;
	private String work_l2_address;
	private String work_city_address;
	private String work_zip_address;
	private String work_phone_num;
	private String work_county_num;
	private String work_state_address;
	@Transient
	private String pref_cntc_tm_txt;
	@Transient
	private Integer days_at_address_num;
	@Transient
	private String chld_tanf_rcv_ind;
	@Transient
	private String living_arrangement_cd;
	@Transient
	private String assigned_cnty_num;
	@Transient
	private String hshl_home_phn_extn_num;
	@Transient
	private String hshl_past_addr_ind;
	@Transient
	private String past_county_cd;
	@Transient
	private String past_state_cd;
	@Transient
	private String pref_cont_time_cd;
	@Transient
	private String pref_deaf_cont_method_cd;
	@Transient
	private String pub_hsa_rcv_pay_own_bill_ind;
	@Transient
	private String house_rent_assist_type;
	@Transient
	private String house_liheap_rcv_ind;
	
	@Transient
	private String ecp_id;
	@Transient
	private String ecp_id_mail;
	private String wic_dsclsr;
	@Transient
	private String is_cc_renewal;
	@Transient
	private String caps_id;
	@Transient
	private String emailBody;
	@Transient
	private String emailSubject;
	@Transient
	private String textBody;
	@Transient
	private String indvNameAge;
	@Transient
	private List<Integer> indvSeqList;
	private String address_change_ind;
	
	@Transient
	private String hshl_email_adrA;
	
	@CreationTimestamp
	private Timestamp create_dt;
	
	private Timestamp update_dt;
	
	private String pref_cont_method_phone_cd;
	private String pref_consent_cd;
	
	public String getHshl_email_adrA() {
		return hshl_email_adrA;
	}
	public void setHshl_email_adrA(String hshl_email_adrA) {
		this.hshl_email_adrA = hshl_email_adrA;
	}
	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	/**
	 * @return the alt_city_adr
	 */
	public String getAlt_city_adr() {
		return alt_city_adr;
	}
	/**
	 * @param alt_city_adr the alt_city_adr to set
	 */
	public void setAlt_city_adr(String alt_city_adr) {
		this.alt_city_adr = alt_city_adr;
	}
	/**
	 * @return the alt_l2_adr
	 */
	public String getAlt_l2_adr() {
		return alt_l2_adr;
	}
	/**
	 * @param alt_l2_adr the alt_l2_adr to set
	 */
	public void setAlt_l2_adr(String alt_l2_adr) {
		this.alt_l2_adr = alt_l2_adr;
	}
	/**
	 * @return the alt_st_adr
	 */
	public String getAlt_st_adr() {
		return alt_st_adr;
	}
	/**
	 * @param alt_st_adr the alt_st_adr to set
	 */
	public void setAlt_st_adr(String alt_st_adr) {
		this.alt_st_adr = alt_st_adr;
	}
	/**
	 * @return the alt_sta_adr
	 */
	public String getAlt_sta_adr() {
		return alt_sta_adr;
	}
	/**
	 * @param alt_sta_adr the alt_sta_adr to set
	 */
	public void setAlt_sta_adr(String alt_sta_adr) {
		this.alt_sta_adr = alt_sta_adr;
	}
	/**
	 * @return the alt_zip_adr
	 */
	public String getAlt_zip_adr() {
		return alt_zip_adr;
	}
	/**
	 * @param alt_zip_adr the alt_zip_adr to set
	 */
	public void setAlt_zip_adr(String alt_zip_adr) {
		this.alt_zip_adr = alt_zip_adr;
	}
	/**
	 * @return the chg_eff_dt
	 */
	public Date getChg_eff_dt() {
		if(chg_eff_dt != null) {
			return (Date) chg_eff_dt.clone();
		}else {
			return null;
		}	
	}
	/**
	 * @param chg_eff_dt the chg_eff_dt to set
	 */
	public void setChg_eff_dt(Date chg_eff_dt) {
		if(chg_eff_dt != null) {
			this.chg_eff_dt = (Date) chg_eff_dt.clone();
		}else {
			this.chg_eff_dt = null;
		}
	}
	/**
	 * @return the cnty_num
	 */
	public String getCnty_num() {
		return cnty_num;
	}
	/**
	 * @param cnty_num the cnty_num to set
	 */
	public void setCnty_num(String cnty_num) {
		this.cnty_num = cnty_num;
	}
	/**
	 * @return the hless_sw
	 */
	public String getHless_sw() {
		return hless_sw;
	}
	/**
	 * @param hless_sw the hless_sw to set
	 */
	public void setHless_sw(String hless_sw) {
		this.hless_sw = hless_sw;
	}
	/**
	 * @return the hshl_cell_phn_num
	 */
	public String getHshl_cell_phn_num() {
		return hshl_cell_phn_num;
	}
	/**
	 * @param hshl_cell_phn_num the hshl_cell_phn_num to set
	 */
	public void setHshl_cell_phn_num(String hshl_cell_phn_num) {
		this.hshl_cell_phn_num = hshl_cell_phn_num;
	}
	/**
	 * @return the hshl_city_adr
	 */
	public String getHshl_city_adr() {
		return hshl_city_adr;
	}
	/**
	 * @param hshl_city_adr the hshl_city_adr to set
	 */
	public void setHshl_city_adr(String hshl_city_adr) {
		this.hshl_city_adr = hshl_city_adr;
	}
	/**
	 * @return the hshl_email_adr
	 */
	public String getHshl_email_adr() {
		return hshl_email_adr;
	}
	/**
	 * @param hshl_email_adr the hshl_email_adr to set
	 */
	public void setHshl_email_adr(String hshl_email_adr) {
		this.hshl_email_adr = hshl_email_adr;
	}
	/**
	 * @return the hshl_home_phn_num
	 */
	public String getHshl_home_phn_num() {
		return hshl_home_phn_num;
	}
	/**
	 * @param hshl_home_phn_num the hshl_home_phn_num to set
	 */
	public void setHshl_home_phn_num(String hshl_home_phn_num) {
		this.hshl_home_phn_num = hshl_home_phn_num;
	}
	/**
	 * @return the hshl_indv_ct
	 */
	public Integer getHshl_indv_ct() {
		return hshl_indv_ct;
	}
	/**
	 * @param hshl_indv_ct the hshl_indv_ct to set
	 */
	public void setHshl_indv_ct(Integer hshl_indv_ct) {
		this.hshl_indv_ct = hshl_indv_ct;
	}
	/**
	 * @return the hshl_l1_adr
	 */
	public String getHshl_l1_adr() {
		return hshl_l1_adr;
	}
	/**
	 * @param hshl_l1_adr the hshl_l1_adr to set
	 */
	public void setHshl_l1_adr(String hshl_l1_adr) {
		this.hshl_l1_adr = hshl_l1_adr;
	}
	/**
	 * @return the hshl_l2_adr
	 */
	public String getHshl_l2_adr() {
		return hshl_l2_adr;
	}
	/**
	 * @param hshl_l2_adr the hshl_l2_adr to set
	 */
	public void setHshl_l2_adr(String hshl_l2_adr) {
		this.hshl_l2_adr = hshl_l2_adr;
	}
	/**
	 * @return the hshl_sta_adr
	 */
	public String getHshl_sta_adr() {
		return hshl_sta_adr;
	}
	/**
	 * @param hshl_sta_adr the hshl_sta_adr to set
	 */
	public void setHshl_sta_adr(String hshl_sta_adr) {
		this.hshl_sta_adr = hshl_sta_adr;
	}
	/**
	 * @return the hshl_work_phn_num
	 */
	public String getHshl_work_phn_num() {
		return hshl_work_phn_num;
	}
	/**
	 * @param hshl_work_phn_num the hshl_work_phn_num to set
	 */
	public void setHshl_work_phn_num(String hshl_work_phn_num) {
		this.hshl_work_phn_num = hshl_work_phn_num;
	}
	/**
	 * @return the hshl_zip_adr
	 */
	public String getHshl_zip_adr() {
		return hshl_zip_adr;
	}
	/**
	 * @param hshl_zip_adr the hshl_zip_adr to set
	 */
	public void setHshl_zip_adr(String hshl_zip_adr) {
		this.hshl_zip_adr = hshl_zip_adr;
	}
	/**
	 * @return the lang_cd
	 */
	public String getLang_cd() {
		return lang_cd;
	}
	/**
	 * @param lang_cd the lang_cd to set
	 */
	public void setLang_cd(String lang_cd) {
		this.lang_cd = lang_cd;
	}
	/**
	 * @return the msg_phn_extn_num
	 */
	public String getMsg_phn_extn_num() {
		return msg_phn_extn_num;
	}
	/**
	 * @param msg_phn_extn_num the msg_phn_extn_num to set
	 */
	public void setMsg_phn_extn_num(String msg_phn_extn_num) {
		this.msg_phn_extn_num = msg_phn_extn_num;
	}
	/**
	 * @return the msg_phn_num
	 */
	public String getMsg_phn_num() {
		return msg_phn_num;
	}
	/**
	 * @param msg_phn_num the msg_phn_num to set
	 */
	public void setMsg_phn_num(String msg_phn_num) {
		this.msg_phn_num = msg_phn_num;
	}
	/**
	 * @return the phn_num_typ
	 */
	public String getPhn_num_typ() {
		return phn_num_typ;
	}
	/**
	 * @param phn_num_typ the phn_num_typ to set
	 */
	public void setPhn_num_typ(String phn_num_typ) {
		this.phn_num_typ = phn_num_typ;
	}
	/**
	 * @return the pref_cntc_ind
	 */
	public Integer getPref_cntc_ind() {
		return pref_cntc_ind;
	}
	/**
	 * @param pref_cntc_ind the pref_cntc_ind to set
	 */
	public void setPref_cntc_ind(Integer pref_cntc_ind) {
		this.pref_cntc_ind = pref_cntc_ind;
	}
	/**
	 * @return the pref_cntc_tm_txt
	 */
	public String getPref_cntc_tm_txt() {
		return pref_cntc_tm_txt;
	}
	/**
	 * @param pref_cntc_tm_txt the pref_cntc_tm_txt to set
	 */
	public void setPref_cntc_tm_txt(String pref_cntc_tm_txt) {
		this.pref_cntc_tm_txt = pref_cntc_tm_txt;
	}
	/**
	 * @return the rec_cplt_ind
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	/**
	 * @param rec_cplt_ind the rec_cplt_ind to set
	 */
	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	/**
	 * @return the work_phn_extn_num
	 */
	public String getWork_phn_extn_num() {
		return work_phn_extn_num;
	}
	/**
	 * @param work_phn_extn_num the work_phn_extn_num to set
	 */
	public void setWork_phn_extn_num(String work_phn_extn_num) {
		this.work_phn_extn_num = work_phn_extn_num;
	}
	/**
	 * @return the days_at_address_num
	 */
	public Integer getDays_at_address_num() {
		return days_at_address_num;
	}
	/**
	 * @param days_at_address_num the days_at_address_num to set
	 */
	public void setDays_at_address_num(Integer days_at_address_num) {
		this.days_at_address_num = days_at_address_num;
	}
	/**
	 * @return the ebt_card_resp
	 */
	public String getEbt_card_resp() {
		return ebt_card_resp;
	}
	/**
	 * @param ebt_card_resp the ebt_card_resp to set
	 */
	public void setEbt_card_resp(String ebt_card_resp) {
		this.ebt_card_resp = ebt_card_resp;
	}
	/**
	 * @return the home_addr_chg_begin_dt
	 */
	public Date getHome_addr_chg_begin_dt() {
		if(home_addr_chg_begin_dt != null) {
			return (Date) home_addr_chg_begin_dt.clone();
		}else {
			return null;
		}
	}
	/**
	 * @param home_addr_chg_begin_dt the home_addr_chg_begin_dt to set
	 */
	public void setHome_addr_chg_begin_dt(Date home_addr_chg_begin_dt) {
		if(home_addr_chg_begin_dt != null) {
			this.home_addr_chg_begin_dt = (Date) home_addr_chg_begin_dt.clone();
		}else {
			this.home_addr_chg_begin_dt = null;
		}
	}
	/**
	 * @return the mail_addr_chg_begin_dt
	 */
	public Date getMail_addr_chg_begin_dt() {
		if(mail_addr_chg_begin_dt != null) {
			return (Date) mail_addr_chg_begin_dt.clone();
		}else {
			return null;
		}
	}
	/**
	 * @param mail_addr_chg_begin_dt the mail_addr_chg_begin_dt to set
	 */
	public void setMail_addr_chg_begin_dt(Date mail_addr_chg_begin_dt) {
		if(mail_addr_chg_begin_dt != null) {
			this.mail_addr_chg_begin_dt = (Date) mail_addr_chg_begin_dt.clone();
		}else {
			this.mail_addr_chg_begin_dt = null;
		}
	}
	/**
	 * @return the other_assistance_sw
	 */
	public String getOther_assistance_sw() {
		return other_assistance_sw;
	}
	/**
	 * @param other_assistance_sw the other_assistance_sw to set
	 */
	public void setOther_assistance_sw(String other_assistance_sw) {
		this.other_assistance_sw = other_assistance_sw;
	}
	/**
	 * @return the hshl_apt_num
	 */
	public String getHshl_apt_num() {
		return hshl_apt_num;
	}
	/**
	 * @param hshl_apt_num the hshl_apt_num to set
	 */
	public void setHshl_apt_num(String hshl_apt_num) {
		this.hshl_apt_num = hshl_apt_num;
	}
	/**
	 * @return the alt_apt_num
	 */
	public String getAlt_apt_num() {
		return alt_apt_num;
	}
	/**
	 * @param alt_apt_num the alt_apt_num to set
	 */
	public void setAlt_apt_num(String alt_apt_num) {
		this.alt_apt_num = alt_apt_num;
	}
	/**
	 * @return the alt_l1_adr
	 */
	public String getAlt_l1_adr() {
		return alt_l1_adr;
	}
	/**
	 * @param alt_l1_adr the alt_l1_adr to set
	 */
	public void setAlt_l1_adr(String alt_l1_adr) {
		this.alt_l1_adr = alt_l1_adr;
	}
	/**
	 * @return the chld_tanf_rcv_ind
	 */
	public String getChld_tanf_rcv_ind() {
		return chld_tanf_rcv_ind;
	}
	/**
	 * @param chld_tanf_rcv_ind the chld_tanf_rcv_ind to set
	 */
	public void setChld_tanf_rcv_ind(String chld_tanf_rcv_ind) {
		this.chld_tanf_rcv_ind = chld_tanf_rcv_ind;
	}
	/**
	 * @return the living_arrangement_cd
	 */
	public String getLiving_arrangement_cd() {
		return living_arrangement_cd;
	}
	/**
	 * @param living_arrangement_cd the living_arrangement_cd to set
	 */
	public void setLiving_arrangement_cd(String living_arrangement_cd) {
		this.living_arrangement_cd = living_arrangement_cd;
	}
	/**
	 * @return the assigned_cnty_num
	 */
	public String getAssigned_cnty_num() {
		return assigned_cnty_num;
	}
	/**
	 * @param assigned_cnty_num the assigned_cnty_num to set
	 */
	public void setAssigned_cnty_num(String assigned_cnty_num) {
		this.assigned_cnty_num = assigned_cnty_num;
	}
	/**
	 * @return the hshl_home_phn_extn_num
	 */
	public String getHshl_home_phn_extn_num() {
		return hshl_home_phn_extn_num;
	}
	/**
	 * @param hshl_home_phn_extn_num the hshl_home_phn_extn_num to set
	 */
	public void setHshl_home_phn_extn_num(String hshl_home_phn_extn_num) {
		this.hshl_home_phn_extn_num = hshl_home_phn_extn_num;
	}
	/**
	 * @return the hshl_past_addr_ind
	 */
	public String getHshl_past_addr_ind() {
		return hshl_past_addr_ind;
	}
	/**
	 * @param hshl_past_addr_ind the hshl_past_addr_ind to set
	 */
	public void setHshl_past_addr_ind(String hshl_past_addr_ind) {
		this.hshl_past_addr_ind = hshl_past_addr_ind;
	}
	/**
	 * @return the living_plcd_govt_agency_ind
	 */
	public String getLiving_plcd_govt_agency_ind() {
		return living_plcd_govt_agency_ind;
	}
	/**
	 * @param living_plcd_govt_agency_ind the living_plcd_govt_agency_ind to set
	 */
	public void setLiving_plcd_govt_agency_ind(String living_plcd_govt_agency_ind) {
		this.living_plcd_govt_agency_ind = living_plcd_govt_agency_ind;
	}
	/**
	 * @return the past_county_cd
	 */
	public String getPast_county_cd() {
		return past_county_cd;
	}
	/**
	 * @param past_county_cd the past_county_cd to set
	 */
	public void setPast_county_cd(String past_county_cd) {
		this.past_county_cd = past_county_cd;
	}
	/**
	 * @return the past_state_cd
	 */
	public String getPast_state_cd() {
		return past_state_cd;
	}
	/**
	 * @param past_state_cd the past_state_cd to set
	 */
	public void setPast_state_cd(String past_state_cd) {
		this.past_state_cd = past_state_cd;
	}
	/**
	 * @return the pref_cont_method_cd
	 */
	public String getPref_cont_method_cd() {
		return pref_cont_method_cd;
	}
	
	/**
	 * @return the Pref_cont_method_case_cd
	 */
	public String getPref_cont_method_case_cd() {
		return pref_cont_method_case_cd;
	}
	/**
	 * @param pref_cont_method_cd the pref_cont_method_cd to set
	 */
	public void setPref_cont_method_cd(String pref_cont_method_cd) {
		this.pref_cont_method_cd = pref_cont_method_cd;
	}
	/**
	 * @param pref_cont_method_case_cd the pref_cont_method_case_cd to set
	 */
	public void setPref_cont_method_case_cd(String pref_cont_method_case_cd) {
		this.pref_cont_method_case_cd = pref_cont_method_case_cd;
	}
	/**
	 * @return the pref_cont_time_cd
	 */
	public String getPref_cont_time_cd() {
		return pref_cont_time_cd;
	}
	/**
	 * @param pref_cont_time_cd the pref_cont_time_cd to set
	 */
	public void setPref_cont_time_cd(String pref_cont_time_cd) {
		this.pref_cont_time_cd = pref_cont_time_cd;
	}
	/**
	 * @return the pref_deaf_cont_method_cd
	 */
	public String getPref_deaf_cont_method_cd() {
		return pref_deaf_cont_method_cd;
	}
	/**
	 * @param pref_deaf_cont_method_cd the pref_deaf_cont_method_cd to set
	 */
	public void setPref_deaf_cont_method_cd(String pref_deaf_cont_method_cd) {
		this.pref_deaf_cont_method_cd = pref_deaf_cont_method_cd;
	}
	/**
	 * @return the pub_hsa_rcv_pay_own_bill_ind
	 */
	public String getPub_hsa_rcv_pay_own_bill_ind() {
		return pub_hsa_rcv_pay_own_bill_ind;
	}
	/**
	 * @param pub_hsa_rcv_pay_own_bill_ind the pub_hsa_rcv_pay_own_bill_ind to set
	 */
	public void setPub_hsa_rcv_pay_own_bill_ind(String pub_hsa_rcv_pay_own_bill_ind) {
		this.pub_hsa_rcv_pay_own_bill_ind = pub_hsa_rcv_pay_own_bill_ind;
	}
	/**
	 * @return the house_rent_assist_type
	 */
	public String getHouse_rent_assist_type() {
		return house_rent_assist_type;
	}
	/**
	 * @param house_rent_assist_type the house_rent_assist_type to set
	 */
	public void setHouse_rent_assist_type(String house_rent_assist_type) {
		this.house_rent_assist_type = house_rent_assist_type;
	}
	/**
	 * @return the house_liheap_rcv_ind
	 */
	public String getHouse_liheap_rcv_ind() {
		return house_liheap_rcv_ind;
	}
	/**
	 * @param house_liheap_rcv_ind the house_liheap_rcv_ind to set
	 */
	public void setHouse_liheap_rcv_ind(String house_liheap_rcv_ind) {
		this.house_liheap_rcv_ind = house_liheap_rcv_ind;
	}
	/**
	 * @return the app_typ
	 */
	public String getApp_typ() {
		return app_typ;
	}
	/**
	 * @param app_typ the app_typ to set
	 */
	public void setApp_typ(String app_typ) {
		this.app_typ = app_typ;
	}
	/**
	 * @return the ecp_id
	 */
	public String getEcp_id() {
		return ecp_id;
	}
	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	/**
	 * @return the ecp_id_mail
	 */
	public String getEcp_id_mail() {
		return ecp_id_mail;
	}
	/**
	 * @param ecp_id_mail the ecp_id_mail to set
	 */
	public void setEcp_id_mail(String ecp_id_mail) {
		this.ecp_id_mail = ecp_id_mail;
	}
	/**
	 * @return the alt_addr_zip4
	 */
	public String getAlt_addr_zip4() {
		return alt_addr_zip4;
	}
	/**
	 * @param alt_addr_zip4 the alt_addr_zip4 to set
	 */
	public void setAlt_addr_zip4(String alt_addr_zip4) {
		this.alt_addr_zip4 = alt_addr_zip4;
	}
	/**
	 * @return the hshl_addr_zip4
	 */
	public String getHshl_addr_zip4() {
		return hshl_addr_zip4;
	}
	/**
	 * @param hshl_addr_zip4 the hshl_addr_zip4 to set
	 */
	public void setHshl_addr_zip4(String hshl_addr_zip4) {
		this.hshl_addr_zip4 = hshl_addr_zip4;
	}
	/**
	 * @return the chg_dt
	 */
	public Date getChg_dt() {
		if(chg_dt != null) {
			return (Date) chg_dt.clone();
		}else {
			return null;
		}
	}
	/**
	 * @param chg_dt the chg_dt to set
	 */
	public void setChg_dt(Date chg_dt) {
		if(chg_dt != null) {
			this.chg_dt = (Date) chg_dt.clone();
		}else {
			this.chg_dt = null;
		}
	}
	/**
	 * @return the wic_clnc_cnty
	 */
	public String getWic_clnc_cnty() {
		return wic_clnc_cnty;
	}
	/**
	 * @param wic_clnc_cnty the wic_clnc_cnty to set
	 */
	public void setWic_clnc_cnty(String wic_clnc_cnty) {
		this.wic_clnc_cnty = wic_clnc_cnty;
	}
	/**
	 * @return the wic_clnc_cd
	 */
	public String getWic_clnc_cd() {
		return wic_clnc_cd;
	}
	/**
	 * @param wic_clnc_cd the wic_clnc_cd to set
	 */
	public void setWic_clnc_cd(String wic_clnc_cd) {
		this.wic_clnc_cd = wic_clnc_cd;
	}
	/**
	 * @return the wic_dsclsr
	 */
	public String getWic_dsclsr() {
		return wic_dsclsr;
	}
	/**
	 * @param wic_dsclsr the wic_dsclsr to set
	 */
	public void setWic_dsclsr(String wic_dsclsr) {
		this.wic_dsclsr = wic_dsclsr;
	}
	/**
	 * @return the is_cc_renewal
	 */
	public String getIs_cc_renewal() {
		return is_cc_renewal;
	}
	/**
	 * @param is_cc_renewal the is_cc_renewal to set
	 */
	public void setIs_cc_renewal(String is_cc_renewal) {
		this.is_cc_renewal = is_cc_renewal;
	}
	/**
	 * @return the caps_id
	 */
	public String getCaps_id() {
		return caps_id;
	}
	/**
	 * @param caps_id the caps_id to set
	 */
	public void setCaps_id(String caps_id) {
		this.caps_id = caps_id;
	}
	
	/**
	 * @return the radioGroup_HOME
	 */
	public String getRadioGroup_HOME() {
		return radioGroup_HOME;
	}
	/**
	 * @param radioGroup_HOME the radioGroup_HOME to set
	 */
	public void setRadioGroup_HOME(String radioGroup_HOME) {
		this.radioGroup_HOME = radioGroup_HOME;
	}
	
	/**
	 * @return the mail_adr_ind
	 */
	public String getMail_adr_ind() {
		return mail_adr_ind;
	}
	/**
	 * @param mail_adr_ind the mail_adr_ind to set
	 */
	public void setMail_adr_ind(String mail_adr_ind) {
		this.mail_adr_ind = mail_adr_ind;
	}
	/**
	 * @return the homeless_a_ind
	 */
	public String getHomeless_a_ind() {
		return homeless_a_ind;
	}
	/**
	 * @param homeless_a_ind the homeless_a_ind to set
	 */
	public void setHomeless_a_ind(String homeless_a_ind) {
		this.homeless_a_ind = homeless_a_ind;
	}
	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	/**
	 * @return the county_office_num
	 */
	public String getCounty_office_num() {
		return county_office_num;
	}
	/**
	 * @param county_office_num the county_office_num to set
	 */
	public void setCounty_office_num(String county_office_num) {
		this.county_office_num = county_office_num;
	}
	/**
	 * @return the email_receipt
	 */
	public String getEmail_receipt() {
		return email_receipt;
	}
	/**
	 * @param email_receipt the email_receipt to set
	 */
	public void setEmail_receipt(String email_receipt) {
		this.email_receipt = email_receipt;
	}
	/**
	 * @return the phonenum_receipt
	 */
	public String getPhonenum_receipt() {
		return phonenum_receipt;
	}
	/**
	 * @param phonenum_receipt the phonenum_receipt to set
	 */
	public void setPhonenum_receipt(String phonenum_receipt) {
		this.phonenum_receipt = phonenum_receipt;
	}
	/**
	 * @return the temp_street_address
	 */
	public String getTemp_street_address() {
		return temp_street_address;
	}
	/**
	 * @param temp_street_address the temp_street_address to set
	 */
	public void setTemp_street_address(String temp_street_address) {
		this.temp_street_address = temp_street_address;
	}
	/**
	 * @return the temp_l2_address
	 */
	public String getTemp_l2_address() {
		return temp_l2_address;
	}
	/**
	 * @param temp_l2_address the temp_l2_address to set
	 */
	public void setTemp_l2_address(String temp_l2_address) {
		this.temp_l2_address = temp_l2_address;
	}
	/**
	 * @return the temp_city_address
	 */
	public String getTemp_city_address() {
		return temp_city_address;
	}
	/**
	 * @param temp_city_address the temp_city_address to set
	 */
	public void setTemp_city_address(String temp_city_address) {
		this.temp_city_address = temp_city_address;
	}
	/**
	 * @return the temp_county_num
	 */
	public String getTemp_county_num() {
		return temp_county_num;
	}
	/**
	 * @param temp_county_num the temp_county_num to set
	 */
	public void setTemp_county_num(String temp_county_num) {
		this.temp_county_num = temp_county_num;
	}
	/**
	 * @return the temp_state_address
	 */
	public String getTemp_state_address() {
		return temp_state_address;
	}
	/**
	 * @param temp_state_address the temp_state_address to set
	 */
	public void setTemp_state_address(String temp_state_address) {
		this.temp_state_address = temp_state_address;
	}
	/**
	 * @return the temp_zip_address
	 */
	public String getTemp_zip_address() {
		return temp_zip_address;
	}
	/**
	 * @param temp_zip_address the temp_zip_address to set
	 */
	public void setTemp_zip_address(String temp_zip_address) {
		this.temp_zip_address = temp_zip_address;
	}
	/**
	 * @return the work_street_address
	 */
	public String getWork_street_address() {
		return work_street_address;
	}
	/**
	 * @param work_street_address the work_street_address to set
	 */
	public void setWork_street_address(String work_street_address) {
		this.work_street_address = work_street_address;
	}
	/**
	 * @return the work_l2_address
	 */
	public String getWork_l2_address() {
		return work_l2_address;
	}
	/**
	 * @param work_l2_address the work_l2_address to set
	 */
	public void setWork_l2_address(String work_l2_address) {
		this.work_l2_address = work_l2_address;
	}
	/**
	 * @return the work_city_address
	 */
	public String getWork_city_address() {
		return work_city_address;
	}
	/**
	 * @param work_city_address the work_city_address to set
	 */
	public void setWork_city_address(String work_city_address) {
		this.work_city_address = work_city_address;
	}
	/**
	 * @return the work_zip_address
	 */
	public String getWork_zip_address() {
		return work_zip_address;
	}
	/**
	 * @param work_zip_address the work_zip_address to set
	 */
	public void setWork_zip_address(String work_zip_address) {
		this.work_zip_address = work_zip_address;
	}
	/**
	 * @return the work_phone_num
	 */
	public String getWork_phone_num() {
		return work_phone_num;
	}
	/**
	 * @param work_phone_num the work_phone_num to set
	 */
	public void setWork_phone_num(String work_phone_num) {
		this.work_phone_num = work_phone_num;
	}
	/**
	 * @return the work_county_num
	 */
	public String getWork_county_num() {
		return work_county_num;
	}
	/**
	 * @param work_county_num the work_county_num to set
	 */
	public void setWork_county_num(String work_county_num) {
		this.work_county_num = work_county_num;
	}
	/**
	 * @return the work_state_address
	 */
	public String getWork_state_address() {
		return work_state_address;
	}
	/**
	 * @param work_state_address the work_state_address to set
	 */
	public void setWork_state_address(String work_state_address) {
		this.work_state_address = work_state_address;
	}
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	public String getEmailBody() {
		return emailBody;
	}
	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}
	public String getEmailSubject() {
		return emailSubject;
	}
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	public String getTextBody() {
		return textBody;
	}
	public void setTextBody(String textBody) {
		this.textBody = textBody;
	}
	


	public String getIndvNameAge() {
		return indvNameAge;
	}
	public void setIndvNameAge(String indvNameAge) {
		this.indvNameAge = indvNameAge;
	}

	public Date getContact_eff_dt() {
		return contact_eff_dt;
	}
	public void setContact_eff_dt(Date contact_eff_dt) {
		this.contact_eff_dt = contact_eff_dt;

	}
	
	public List<Integer> getIndvSeqList() {
		return indvSeqList;
	}
	public void setIndvSeqList( List<Integer> indvSeqList) {
		this.indvSeqList = indvSeqList;
	}
		
	public String getText_sent_ind() {
		return text_sent_ind;
	}
	public void setText_sent_ind(String text_sent_ind) {
		this.text_sent_ind = text_sent_ind;
	}
	/**
	 * @return the address_change_ind
	 */
	public String getAddress_change_ind() {
		return address_change_ind;
	}
	/**
	 * @param address_change_ind the address_change_ind to set
	 */
	public void setAddress_change_ind(String address_change_ind) {
		this.address_change_ind = address_change_ind;
	}
	public Timestamp getCreate_dt() {
		return create_dt;
	}
	public void setCreate_dt(Timestamp create_dt) {
		this.create_dt = create_dt;
	}
	public Timestamp getUpdate_dt() {
		return update_dt;
	}
	public void setUpdate_dt(Timestamp update_dt) {
		this.update_dt = update_dt;
	}
	public String getPref_cont_method_phone_cd() {
		return pref_cont_method_phone_cd;
	}
	public void setPref_cont_method_phone_cd(String pref_cont_method_phone_cd) {
		this.pref_cont_method_phone_cd = pref_cont_method_phone_cd;
	}
	public String getPref_consent_cd() {
		return pref_consent_cd;
	}
	public void setPref_consent_cd(String pref_consent_cd) {
		this.pref_consent_cd = pref_consent_cd;
	}
	
	
}
