package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.framework.business.model.IndividualCategorySequenceDetails;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABHMD")
@Scope("prototype")
public class ABHMD_Wrapper implements LogicResponseInterface {
	private static final String PAGE_ID = "ABHMD";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
	
		Map pageCollection = fwTrxn.getPageCollection();
		
		//getting app_num, indv_seq_num and seq_num
		PageActionDetails currentPageActionDetails = fwTrxn.getCurrentActionDetails();
		IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails.getIndividualCategorySequenceDetails();
		final String appNum = fwTrxn.getUserDetails().getAppNumber();
		final Integer indv_seq_num = Integer.parseInt(fwTrxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
		
		
		
		//Indv Cargo and Coll
		List<APP_INDV_Cargo> appIndvCargoList = new ArrayList<APP_INDV_Cargo>();
		APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
		
		APP_INDV_Collection appIndvCollection = pageCollection.get("APP_INDV_Collection") != null ? (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection") : null;
		if(appIndvCollection != null && !appIndvCollection.isEmpty() && appIndvCollection.size() > 0) {
			appIndvCargo = appIndvCollection.getCargo(0);	
		}
		else
		{	
			//setting app_num, indv_seq_num
			appIndvCargo.setApp_num(appNum);
			appIndvCargo.setIndv_seq_num(indv_seq_num);
		}
		
		appIndvCargo.setShowLoopingQuestionSection("Y");
		appIndvCargoList.add(appIndvCargo);
		
		//Prfl Cargo and Coll
		List<APP_IN_PRFL_Cargo> appInPrflCargoList = new ArrayList<APP_IN_PRFL_Cargo>();
		APP_IN_PRFL_Cargo appInPrflCargo = new APP_IN_PRFL_Cargo();
		
		APP_IN_PRFL_Collection appInPrflCollection = pageCollection.get("APP_IN_PRFL_Collection") != null ? (APP_IN_PRFL_Collection) pageCollection.get("APP_IN_PRFL_Collection") : null;
		if(appInPrflCollection != null && !appInPrflCollection.isEmpty() && appInPrflCollection.size() > 0) {
			appInPrflCargo = appInPrflCollection.getCargo(0);
		}
		else {
			//setting app_num, indv_seq_num
			appInPrflCargo.setApp_num(appNum);
			appInPrflCargo.setIndv_seq_num(indv_seq_num);
		}
		appInPrflCargoList.add(appInPrflCargo);
				
		//Program Cargo and Coll
		List<APP_PGM_RQST_Cargo> appPgmRqstCargoList = new ArrayList<APP_PGM_RQST_Cargo>();
		APP_PGM_RQST_Cargo appPgmRqstCargo = new APP_PGM_RQST_Cargo();
		
		APP_PGM_RQST_Collection appPgmRqstColl = pageCollection.get("APP_PGM_RQST_Collection") != null ? (APP_PGM_RQST_Collection) pageCollection.get("APP_PGM_RQST_Collection") : null;
		if(appPgmRqstColl != null && !appPgmRqstColl.isEmpty() && appPgmRqstColl.size() > 0) {
			appPgmRqstCargo = appPgmRqstColl.getCargo(0);
		}
		
		appPgmRqstCargoList.add(appPgmRqstCargo);
		
		driverPageResponse.getPageCollection().put("APP_INDV_Collection", appIndvCargoList);
		driverPageResponse.getPageCollection().put("APP_IN_PRFL_Collection", appInPrflCargoList);
		driverPageResponse.getPageCollection().put("APP_PGM_RQST_Collection", appPgmRqstCargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getRequest().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		return driverPageResponse;
	}

}
