package gov.state.nextgen.householddemographics.model;

import java.util.ArrayList;
import java.util.List;

public class AppSummaryDtlsModel {
private String appNum;
private String formType;
private List<String> indvIds = new ArrayList<>();
private String caseNumber;
private String countyCode;
private String langCode;
private String caseId;
private String caseName;
private String guid;
public String getAppNum() {
	return appNum;
}
public void setAppNum(String appNum) {
	this.appNum = appNum;
}
public String getFormType() {
	return formType;
}
public void setFormType(String formType) {
	this.formType = formType;
}
public List<String> getIndvIds() {
	return indvIds;
}
public void setIndvIds(List<String> indvIds) {
	this.indvIds = indvIds;
}
public String getCaseNumber() {
	return caseNumber;
}
public void setCaseNumber(String caseNumber) {
	this.caseNumber = caseNumber;
}
public String getCountyCode() {
	return countyCode;
}
public void setCountyCode(String countyCode) {
	this.countyCode = countyCode;
}
public String getLangCode() {
	return langCode;
}
public void setLangCode(String langCode) {
	this.langCode = langCode;
}
public String getCaseId() {
	return caseId;
}
public void setCaseId(String caseId) {
	this.caseId = caseId;
}
public String getCaseName() {
	return caseName;
}
public void setCaseName(String caseName) {
	this.caseName = caseName;
}
public String getGuid() {
	return guid;
}
public void setGuid(String guid) {
	this.guid = guid;
}




}
