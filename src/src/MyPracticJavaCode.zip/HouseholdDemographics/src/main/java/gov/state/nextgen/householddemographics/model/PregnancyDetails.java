package gov.state.nextgen.householddemographics.model;

public class PregnancyDetails {

    private String firstName;
    private String isCurrentlyPregnant;
    private String dueDate;
    private String expectedBabyCount;
    // post partum
    private String isInPostPatrum;
    private String deliveryDate;
    private String terminationDate;
    private String postPartumBabiesCount;
    private String isBreastFeeding;
    private boolean showPregnancy;

    public boolean isShowPregnancy() {
        return showPregnancy;
    }

    public void setShowPregnancy(boolean showPregnancy) {
        this.showPregnancy = showPregnancy;
    }

    public String getIsCurrentlyPregnant() {
        return isCurrentlyPregnant;
    }

    public void setIsCurrentlyPregnant(String isCurrentlyPregnant) {
        this.isCurrentlyPregnant = isCurrentlyPregnant;
    }

    public String getIsInPostPatrum() {
        return isInPostPatrum;
    }

    public void setIsInPostPatrum(String isInPostPatrum) {
        this.isInPostPatrum = isInPostPatrum;
    }

    public String getIsBreastFeeding() {
        return isBreastFeeding;
    }

    public void setIsBreastFeeding(String isBreastFeeding) {
        this.isBreastFeeding = isBreastFeeding;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getExpectedBabyCount() {
        return expectedBabyCount;
    }

    public void setExpectedBabyCount(String expectedBabyCount) {
        this.expectedBabyCount = expectedBabyCount;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getTerminationDate() {
        return terminationDate;
    }

    public void setTerminationDate(String terminationDate) {
        this.terminationDate = terminationDate;
    }

    public String getPostPartumBabiesCount() {
        return postPartumBabiesCount;
    }

    public void setPostPartumBabiesCount(String postPartumBabiesCount) {
        this.postPartumBabiesCount = postPartumBabiesCount;
    }

}
