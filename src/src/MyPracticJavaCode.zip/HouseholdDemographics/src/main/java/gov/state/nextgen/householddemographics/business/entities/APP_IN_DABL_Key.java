package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;
@Embeddable
public class APP_IN_DABL_Key implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer app_number; 
	private Integer indv_seq_num;
	private Integer seq_num;
	
	//default constructor
	public APP_IN_DABL_Key() {
		
	}

	/**
	 * @param app_num
	 * @param indv_seq_num
	 * @param src_app_ind
	 * @param seq_num
	 */
	public APP_IN_DABL_Key(Integer app_number, Integer indv_seq_num, Integer seq_num) {
		super();
		this.app_number = app_number;
		this.indv_seq_num = indv_seq_num;
		this.seq_num = seq_num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		APP_IN_DABL_Key other = (APP_IN_DABL_Key) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		if (seq_num == null) {
			if (other.seq_num != null)
				return false;
		} else if (!seq_num.equals(other.seq_num))
			return false;
		return true;
	}

		

}
