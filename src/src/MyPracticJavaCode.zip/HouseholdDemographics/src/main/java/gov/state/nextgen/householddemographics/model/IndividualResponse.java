/**
 * 
 */
package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;


/**
 * @author rudeshmukh
 *
 */

public class IndividualResponse implements Serializable {

	private static final String ZERO = "0";

	private static final long serialVersionUID = 1L;

	private Integer individualSequenceNumber;

	private IndividualDetailsResponse individualDetailsResponse;
	
	private String client_id;

	public IndividualResponse(APP_INDV_Cargo cargo) {
		this.setIndividualSequenceNumber(cargo.getIndv_seq_num());
		if(null != cargo.getCinNumber()
				&& !StringUtils.isEmpty(cargo.getCinNumber())) {
			this.setClient_id(cargo.getCinNumber());
		} else {
			this.setClient_id(cargo.getBenefitsCalIndividualId().toString());
		}
		individualDetailsResponse = new IndividualDetailsResponse();
		individualDetailsResponse.setDateOfBirth(cargo.getBrth_dt());
		individualDetailsResponse.setFirstName(cargo.getFst_nam());
		individualDetailsResponse.setLastName(cargo.getLast_nam());
		individualDetailsResponse.setMiddleInitial(cargo.getMid_init());
		individualDetailsResponse.setSuffixName(cargo.getSuffix_name());
		String ssnNum = cargo.getSsn_num();
		if (Objects.nonNull(ssnNum) && !ZERO.equalsIgnoreCase(ssnNum) && !ssnNum.isEmpty()) {
			individualDetailsResponse.setLast4ssn(ssnNum.substring(ssnNum.length() - 4));
		}
		individualDetailsResponse.setGenderCode(cargo.getSex_ind());
		individualDetailsResponse.setPrimaryPersonSw(cargo.getPrim_prsn_sw());

	}

	public Integer getIndividualSequenceNumber() {
		return individualSequenceNumber;
	}

	public void setIndividualSequenceNumber(Integer individualSequenceNumber) {
		this.individualSequenceNumber = individualSequenceNumber;
	}

	public void setIndividualSequenceNumber(String individualSequenceNumber) {
		if (Objects.nonNull(individualSequenceNumber)) {
			if (individualSequenceNumber.contains(".")) {
				this.individualSequenceNumber = Double.valueOf(individualSequenceNumber).intValue();
			} else {
				this.individualSequenceNumber = Integer.valueOf(individualSequenceNumber);
			}
		}
	}

	public IndividualDetailsResponse getIndividualDetailsResponse() {
		return individualDetailsResponse;
	}

	public void setIndividualDetailsResponse(IndividualDetailsResponse individualDetailsResponse) {
		this.individualDetailsResponse = individualDetailsResponse;
	}

	public String getClient_id() {
		return client_id;
	}

	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}

}
