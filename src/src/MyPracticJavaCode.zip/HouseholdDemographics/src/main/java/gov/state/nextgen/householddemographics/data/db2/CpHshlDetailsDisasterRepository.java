package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.CP_HSHL_DETAILS_DISASTER_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_HSHL_DETAILS_DISASTER_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_HSHL_DETAILS_DISASTER_Key;

@Repository
public interface CpHshlDetailsDisasterRepository extends CrudRepository<CP_HSHL_DETAILS_DISASTER_Cargo, CP_HSHL_DETAILS_DISASTER_Key>{
    
	@Query("select c from CP_HSHL_DETAILS_DISASTER_Cargo c where c.app_number = ?1")
	public CP_HSHL_DETAILS_DISASTER_Collection getHshlDtlsDisasterByAppNum(Integer appNumber);
	

}
