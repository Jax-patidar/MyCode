package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "CP_APP_IN_TAX_RETURNS")
@IdClass(APP_IN_TAX_RETURNS_Key.class)
public class APP_IN_TAX_RETURNS_Cargo extends AbstractCargo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Transient
	private boolean isDirty = false;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private Integer indv_seq_num;
	
	private String src_app_ind;
	private Integer rec_cplt_ind;
	private String file_tax_jointly_ind;
	private String tax_dependent_resp;
	private String tax_dependent_claim_ind;
	private Integer tax_dependent_claim_seq_num;

	/**
	 * @return the tax_dependent_claim_seq_num
	 */
	public Integer getTax_dependent_claim_seq_num() {
		return tax_dependent_claim_seq_num;
	}

	/**
	 * @param tax_dependent_claim_seq_num the tax_dependent_claim_seq_num to set
	 */
	public void setTax_dependent_claim_seq_num(final Integer tax_dependent_claim_seq_num) {
		this.tax_dependent_claim_seq_num = tax_dependent_claim_seq_num;
	}

	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * @return the rec_cplt_ind
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * @param rec_cplt_ind the rec_cplt_ind to set
	 */
	public void setRec_cplt_ind(final Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * @return the file_tax_joiintly_ind
	 */
	public String getFile_tax_jointly_ind() {
		return file_tax_jointly_ind;
	}

	/**
	 * @param file_tax_jointly_ind the file_tax_jointly_ind to set
	 */
	public void setFile_tax_jointly_ind(final String file_tax_jointly_ind) {
		this.file_tax_jointly_ind = file_tax_jointly_ind;
	}

	/**
	 * @return the tax_dependent_resp
	 */
	public String getTax_dependent_resp() {
		return tax_dependent_resp;
	}

	/**
	 * @param tax_dependent_resp the tax_dependent_resp to set
	 */
	public void setTax_dependent_resp(final String tax_dependent_resp) {
		this.tax_dependent_resp = tax_dependent_resp;
	}

	/**
	 * @return the tax_dependent_claim_ind
	 */
	public String getTax_dependent_claim_ind() {
		return tax_dependent_claim_ind;
	}

	/**
	 * @param tax_dependent_claim_ind the tax_dependent_claim_ind to set
	 */
	public void setTax_dependent_claim_ind(final String tax_dependent_claim_ind) {
		this.tax_dependent_claim_ind = tax_dependent_claim_ind;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((app_num == null) ? 0 : app_num.trim().hashCode());
		result = (prime * result) + ((file_tax_jointly_ind == null) ? 0 : file_tax_jointly_ind.trim().hashCode());
		result = (prime * result) + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = (prime * result) + ((rec_cplt_ind == null) ? 0 : rec_cplt_ind.hashCode());
		result = (prime * result) + ((src_app_ind == null) ? 0 : src_app_ind.trim().hashCode());
		result = (prime * result) + ((tax_dependent_claim_ind == null) ? 0 : tax_dependent_claim_ind.trim().hashCode());
		result = (prime * result) + ((tax_dependent_resp == null) ? 0 : tax_dependent_resp.trim().hashCode());
		result = (prime * result) + ((tax_dependent_claim_seq_num == null) ? 0 : tax_dependent_claim_seq_num.hashCode());
		return result;
	}

	
}
