/*
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class acts as a wrapper for one or many cargos
 *
 * @author Architecture Team
 * Creation Date Mon Feb 06 09:53:47 CST 2006 Modified By: Modified on: PCR#
 */
public class APP_USER_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.householdemographics.business.entities.APP_USER";

	public APP_USER_Collection() {
	}

	public void addCargo(final APP_USER_Cargo newCargo) {
		add(newCargo);
	}

	/**
	 * Returns the package name.
	 *
	 * Creation Date Mon Feb 06 09:53:47 CST 2006
	 * @return gov.state.nextgen.access.business.entities.APP_USER_Collection
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	

	/**
	 * Sets cargo array into collection.
	 *
	 * Creation Date Mon Feb 06 09:53:47 CST 2006
	 * @param cbArray
	 *            The cbArray to set
	 */

	public void setResults(final APP_USER_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets a cargo into particular index of the collection
	 *
	 * Creation Date Mon Feb 06 09:53:47 CST 2006
	 * @param cb
	 *            The cbarray to set
	 * @param idx
	 *            The idx to set
	 */

	public void setResults(final int idx, final APP_USER_Cargo cb) {
		set(idx, cb);
	}

	/**
	 * Sets a cargo into particular index of the collection
	 *
	 * Creation Date Mon Feb 06 09:53:47 CST 2006
	 * @param obj
	 *            The cbarray to set
	 */

	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_USER_Cargo[]) {
			final APP_USER_Cargo[] cbArray = (APP_USER_Cargo[]) obj;
			for (int i = 0; i < cbArray.length; i++) {
				add(cbArray[i]);
			}
		}
	}

	/**
	 * Returns cargo array.
	 *
	 * Creation Date Mon Feb 06 09:53:47 CST 2006
	 * @return gov.state.nextgen.access.business.entities.APP_USER_Collection[]
	 */
	public APP_USER_Cargo[] getResults() {
		final APP_USER_Cargo[] cbArray = new APP_USER_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * Returns a particular cargo.
	 *
	 * Creation Date Mon Feb 06 09:53:47 CST 2006
	 * @return gov.state.nextgen.access.business.entities.APP_USER_Collection
	 */
	public APP_USER_Cargo getResult(final int idx) {
		return (APP_USER_Cargo) get(idx);
	}

	/**
	 * Returns size of a collection.
	 *
	 * Creation Date Mon Feb 06 09:53:47 CST 2006
	 * @return int
	 */
	public int getResultsSize() {
		return size();
	}


}
