package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;


@Entity
@Table(name = "CP_APP_IN_DABL")
@IdClass(APP_IN_DABL_Key.class)
public class APP_IN_DABL_Cargo extends AbstractCargo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private Integer indv_seq_num;
	
	private String src_app_ind;
	
	@Id
	private Integer seq_num;
	@JsonFormat(pattern="MM/dd/yyyy")
	private Date ssa_applied_last_dt;
	@Transient
	@JsonFormat(pattern="MM/dd/yyyy")
	private Date blnd_dt;
	@Transient
	@JsonFormat(pattern="MM/dd/yyyy")
	private Date dabl_dt;
	@Transient
	private String estb_blnd_resp;
	@Transient
	private String estb_dabl_resp;
	@Transient
	private String irwe_sw;
	private String rec_cplt_ind;
	@Column(name="unabl_work_sw")
	private String uabl_work_sw;
	private String reduced_child_care_ind;
	private String someone_provide_care_ind;
	private String ssi_payment_stopped_ind;
	private String ssi_railrdret_ben_app_ind;
	@Column(name="ssi_rcvd_ind")
	private String ssi_received_ind;
	@Transient
	private String medical_cond_post_denial_dtl;
	@Transient
	private String medical_cond_post_denial_ind;
	private String no_long_caring_disabled_resp;
	private String no_long_disabled_resp;
	private String benefit_denial_appeal_ind;
	private String benefit_denial_appeal_outcome;
	private String caring_disabled_resp;
	@Transient
	@JsonFormat(pattern="MM/dd/yyyy")
	private Date disability_end_dt;
	private String dabl_type_cd;
	@Column(name="ssa_dabl_appr_src_other_dsc")
	private String ssa_dbal_appr_src_oth_dsc;
	@Column(name="ssa_dabl_appr_src_cd")
	private String ssa_dbal_appr_src_cd;
	@Column(name="dabl_type_other_dsc")
	private String dabl_type_oth_dsc;
	@Column(name="ssa_dabl_benefit_rcv_ind")
	private String ssa_dbal_bnft_rcv_ind;
	@Transient
	private String estb_phy_resp;
	@Transient
	private Integer ecp_id;
	@Transient
	private String loopingQuestion;
	@Transient
	private String fts_nam;
	@Transient
	private String firstname;
	@Transient
	private String lastname;
	@Transient
	private Integer age;
	
	private String dabl_lim_activity_ind;
	@Column(name="nur_care_ind")
	private String nursing_care_ind;
	private String dabl_caring_desc;
	private String need_care_work_schl_ind;
	private String need_care_other_hhm;
	private String need_care_other_hhm_desc;
	private String dabl_med_expens_work_ind;
	private String dabl_med_expens_work_desc;
	private String dabl_more_than_one_yr_ind;
	private String nur_hspc_prvd_nm;
	private String from_injury_ind; 
	
	
	
	
	
	
	
	public String getFrom_injury_ind() {
		return from_injury_ind;
	}
	public void setFrom_injury_ind(String from_injury_ind) {
		this.from_injury_ind = from_injury_ind;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDabl_lim_activity_ind() {
		return dabl_lim_activity_ind;
	}
	public void setDabl_lim_activity_ind(String dabl_lim_activity_ind) {
		this.dabl_lim_activity_ind = dabl_lim_activity_ind;
	}
	public String getNursing_care_ind() {
		return nursing_care_ind;
	}
	public void setNursing_care_ind(String nursing_care_ind) {
		this.nursing_care_ind = nursing_care_ind;
	}
	public String getDabl_caring_desc() {
		return dabl_caring_desc;
	}
	public void setDabl_caring_desc(String dabl_caring_desc) {
		this.dabl_caring_desc = dabl_caring_desc;
	}
	public String getNeed_care_work_schl_ind() {
		return need_care_work_schl_ind;
	}
	public void setNeed_care_work_schl_ind(String need_care_work_schl_ind) {
		this.need_care_work_schl_ind = need_care_work_schl_ind;
	}
	public String getNeed_care_other_hhm() {
		return need_care_other_hhm;
	}
	public void setNeed_care_other_hhm(String need_care_other_hhm) {
		this.need_care_other_hhm = need_care_other_hhm;
	}
	public String getNeed_care_other_hhm_desc() {
		return need_care_other_hhm_desc;
	}
	public void setNeed_care_other_hhm_desc(String need_care_other_hhm_desc) {
		this.need_care_other_hhm_desc = need_care_other_hhm_desc;
	}
	public String getDabl_med_expens_work_ind() {
		return dabl_med_expens_work_ind;
	}
	public void setDabl_med_expens_work_ind(String dabl_med_expens_work_ind) {
		this.dabl_med_expens_work_ind = dabl_med_expens_work_ind;
	}
	public String getDabl_med_expens_work_desc() {
		return dabl_med_expens_work_desc;
	}
	public void setDabl_med_expens_work_desc(String dabl_med_expens_work_desc) {
		this.dabl_med_expens_work_desc = dabl_med_expens_work_desc;
	}
	public String getDabl_more_than_one_yr_ind() {
		return dabl_more_than_one_yr_ind;
	}
	public void setDabl_more_than_one_yr_ind(String dabl_more_than_one_yr_ind) {
		this.dabl_more_than_one_yr_ind = dabl_more_than_one_yr_ind;
	}
	
	/**
	 * @return the fts_nam
	 */
	public String getFts_nam() {
		return fts_nam;
	}
	/**
	 * @param fts_nam the fts_nam to set
	 */
	public void setFts_nam(String fts_nam) {
		this.fts_nam = fts_nam;
	}
	/**
	 * @param loopingQuestion the loopingQuestion to set
	 */
	public void setLoopingQuestion(String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}
	@Column(name="change_dt")
	@JsonFormat(pattern="MM/dd/yyyy")
	private Date chg_dt;
	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	
	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	/**
	 * @return the seq_num
	 */
	public Integer getSeq_num() {
		return seq_num;
	}
	/**
	 * @param seq_num the seq_num to set
	 */
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	/**
	 * @return the ssa_applied_last_dt
	 */
	public Date getSsa_applied_last_dt() {
		if(ssa_applied_last_dt == null) {
		return null;
		}else {
			return (Date) ssa_applied_last_dt.clone();
		}
	}
	/**
	 * @param ssa_applied_last_dt the ssa_applied_last_dt to set
	 */
	public void setSsa_applied_last_dt(Date ssa_applied_last_dt) {
		if(ssa_applied_last_dt == null) {
			this.ssa_applied_last_dt = null;
		}else {
		this.ssa_applied_last_dt = (Date) ssa_applied_last_dt.clone();
		}
	}
	/**
	 * @return the blnd_dt
	 */
	public Date getBlnd_dt() {
		if(blnd_dt == null) {
		return null;
		}else {
			return (Date) blnd_dt.clone();
		}
		
	}
	/**
	 * @param blnd_dt the blnd_dt to set
	 */
	public void setBlnd_dt(Date blnd_dt) {
		
		if(blnd_dt == null) {
			this.blnd_dt = null;
		}else {
		this.blnd_dt = (Date) blnd_dt.clone();
		}
	}
	/**
	 * @return the dabl_dt
	 */
	public Date getDabl_dt() {
		if(dabl_dt == null) {
			return null;
		}else {
			return (Date) dabl_dt.clone();
		}
		
	}
	/**
	 * @param dabl_dt the dabl_dt to set
	 */
	public void setDabl_dt(Date dabl_dt) {
		if(dabl_dt == null) {
			this.dabl_dt = null;
		}else {
		this.dabl_dt = (Date) dabl_dt.clone();
		}
	}
	/**
	 * @return the estb_blnd_resp
	 */
	public String getEstb_blnd_resp() {
		return estb_blnd_resp;
	}
	/**
	 * @param estb_blnd_resp the estb_blnd_resp to set
	 */
	public void setEstb_blnd_resp(String estb_blnd_resp) {
		this.estb_blnd_resp = estb_blnd_resp;
	}
	/**
	 * @return the estb_dabl_resp
	 */
	public String getEstb_dabl_resp() {
		return estb_dabl_resp;
	}
	/**
	 * @param estb_dabl_resp the estb_dabl_resp to set
	 */
	public void setEstb_dabl_resp(String estb_dabl_resp) {
		this.estb_dabl_resp = estb_dabl_resp;
	}
	/**
	 * @return the irwe_sw
	 */
	public String getIrwe_sw() {
		return irwe_sw;
	}
	/**
	 * @param irwe_sw the irwe_sw to set
	 */
	public void setIrwe_sw(String irwe_sw) {
		this.irwe_sw = irwe_sw;
	}
	/**
	 * @return the rec_cplt_ind
	 */
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	/**
	 * @param rec_cplt_ind the rec_cplt_ind to set
	 */
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	/**
	 * @return the uabl_work_sw
	 */
	public String getUabl_work_sw() {
		return uabl_work_sw;
	}
	/**
	 * @param uabl_work_sw the uabl_work_sw to set
	 */
	public void setUabl_work_sw(String uabl_work_sw) {
		this.uabl_work_sw = uabl_work_sw;
	}
	/**
	 * @return the reduced_child_care_ind
	 */
	public String getReduced_child_care_ind() {
		return reduced_child_care_ind;
	}
	/**
	 * @param reduced_child_care_ind the reduced_child_care_ind to set
	 */
	public void setReduced_child_care_ind(String reduced_child_care_ind) {
		this.reduced_child_care_ind = reduced_child_care_ind;
	}
	/**
	 * @return the someone_provide_care_ind
	 */
	public String getSomeone_provide_care_ind() {
		return someone_provide_care_ind;
	}
	/**
	 * @param someone_provide_care_ind the someone_provide_care_ind to set
	 */
	public void setSomeone_provide_care_ind(String someone_provide_care_ind) {
		this.someone_provide_care_ind = someone_provide_care_ind;
	}
	/**
	 * @return the ssi_payment_stopped_ind
	 */
	public String getSsi_payment_stopped_ind() {
		return ssi_payment_stopped_ind;
	}
	/**
	 * @param ssi_payment_stopped_ind the ssi_payment_stopped_ind to set
	 */
	public void setSsi_payment_stopped_ind(String ssi_payment_stopped_ind) {
		this.ssi_payment_stopped_ind = ssi_payment_stopped_ind;
	}
	/**
	 * @return the ssi_railrdret_ben_app_ind
	 */
	public String getSsi_railrdret_ben_app_ind() {
		return ssi_railrdret_ben_app_ind;
	}
	/**
	 * @param ssi_railrdret_ben_app_ind the ssi_railrdret_ben_app_ind to set
	 */
	public void setSsi_railrdret_ben_app_ind(String ssi_railrdret_ben_app_ind) {
		this.ssi_railrdret_ben_app_ind = ssi_railrdret_ben_app_ind;
	}
	/**
	 * @return the ssi_received_ind
	 */
	public String getSsi_received_ind() {
		return ssi_received_ind;
	}
	/**
	 * @param ssi_received_ind the ssi_received_ind to set
	 */
	public void setSsi_received_ind(String ssi_received_ind) {
		this.ssi_received_ind = ssi_received_ind;
	}
	/**
	 * @return the medical_cond_post_denial_dtl
	 */
	public String getMedical_cond_post_denial_dtl() {
		return medical_cond_post_denial_dtl;
	}
	/**
	 * @param medical_cond_post_denial_dtl the medical_cond_post_denial_dtl to set
	 */
	public void setMedical_cond_post_denial_dtl(String medical_cond_post_denial_dtl) {
		this.medical_cond_post_denial_dtl = medical_cond_post_denial_dtl;
	}
	/**
	 * @return the medical_cond_post_denial_ind
	 */
	public String getMedical_cond_post_denial_ind() {
		return medical_cond_post_denial_ind;
	}
	/**
	 * @param medical_cond_post_denial_ind the medical_cond_post_denial_ind to set
	 */
	public void setMedical_cond_post_denial_ind(String medical_cond_post_denial_ind) {
		this.medical_cond_post_denial_ind = medical_cond_post_denial_ind;
	}
	/**
	 * @return the no_long_caring_disabled_resp
	 */
	public String getNo_long_caring_disabled_resp() {
		return no_long_caring_disabled_resp;
	}
	/**
	 * @param no_long_caring_disabled_resp the no_long_caring_disabled_resp to set
	 */
	public void setNo_long_caring_disabled_resp(String no_long_caring_disabled_resp) {
		this.no_long_caring_disabled_resp = no_long_caring_disabled_resp;
	}
	/**
	 * @return the no_long_disabled_resp
	 */
	public String getNo_long_disabled_resp() {
		return no_long_disabled_resp;
	}
	/**
	 * @param no_long_disabled_resp the no_long_disabled_resp to set
	 */
	public void setNo_long_disabled_resp(String no_long_disabled_resp) {
		this.no_long_disabled_resp = no_long_disabled_resp;
	}
	/**
	 * @return the benefit_denial_appeal_ind
	 */
	public String getBenefit_denial_appeal_ind() {
		return benefit_denial_appeal_ind;
	}
	/**
	 * @param benefit_denial_appeal_ind the benefit_denial_appeal_ind to set
	 */
	public void setBenefit_denial_appeal_ind(String benefit_denial_appeal_ind) {
		this.benefit_denial_appeal_ind = benefit_denial_appeal_ind;
	}
	/**
	 * @return the benefit_denial_appeal_outcome
	 */
	public String getBenefit_denial_appeal_outcome() {
		return benefit_denial_appeal_outcome;
	}
	/**
	 * @param benefit_denial_appeal_outcome the benefit_denial_appeal_outcome to set
	 */
	public void setBenefit_denial_appeal_outcome(String benefit_denial_appeal_outcome) {
		this.benefit_denial_appeal_outcome = benefit_denial_appeal_outcome;
	}
	/**
	 * @return the caring_disabled_resp
	 */
	public String getCaring_disabled_resp() {
		return caring_disabled_resp;
	}
	/**
	 * @param caring_disabled_resp the caring_disabled_resp to set
	 */
	public void setCaring_disabled_resp(String caring_disabled_resp) {
		this.caring_disabled_resp = caring_disabled_resp;
	}
	/**
	 * @return the disability_end_dt
	 */
	public Date getDisability_end_dt() {
		if(disability_end_dt == null) {
			return null;
		}else {
		return disability_end_dt;
		}
	}
	/**
	 * @param disability_end_dt the disability_end_dt to set
	 */
	public void setDisability_end_dt(Date disability_end_dt) {
		if(disability_end_dt == null) {
			this.disability_end_dt = null;
		}else {
		this.disability_end_dt = disability_end_dt;
		}
	}
	/**
	 * @return the dabl_type_cd
	 */
	public String getDabl_type_cd() {
		return dabl_type_cd;
	}
	/**
	 * @param dabl_type_cd the dabl_type_cd to set
	 */
	public void setDabl_type_cd(String dabl_type_cd) {
		this.dabl_type_cd = dabl_type_cd;
	}
	/**
	 * @return the ssa_dbal_appr_src_oth_dsc
	 */
	public String getSsa_dbal_appr_src_oth_dsc() {
		return ssa_dbal_appr_src_oth_dsc;
	}
	/**
	 * @param ssa_dbal_appr_src_oth_dsc the ssa_dbal_appr_src_oth_dsc to set
	 */
	public void setSsa_dbal_appr_src_oth_dsc(String ssa_dbal_appr_src_oth_dsc) {
		this.ssa_dbal_appr_src_oth_dsc = ssa_dbal_appr_src_oth_dsc;
	}
	/**
	 * @return the ssa_dbal_appr_src_cd
	 */
	public String getSsa_dbal_appr_src_cd() {
		return ssa_dbal_appr_src_cd;
	}
	/**
	 * @param ssa_dbal_appr_src_cd the ssa_dbal_appr_src_cd to set
	 */
	public void setSsa_dbal_appr_src_cd(String ssa_dbal_appr_src_cd) {
		this.ssa_dbal_appr_src_cd = ssa_dbal_appr_src_cd;
	}
	/**
	 * @return the dabl_type_oth_dsc
	 */
	public String getDabl_type_oth_dsc() {
		return dabl_type_oth_dsc;
	}
	/**
	 * @param dabl_type_oth_dsc the dabl_type_oth_dsc to set
	 */
	public void setDabl_type_oth_dsc(String dabl_type_oth_dsc) {
		this.dabl_type_oth_dsc = dabl_type_oth_dsc;
	}
	/**
	 * @return the ssa_dbal_bnft_rcv_ind
	 */
	public String getSsa_dbal_bnft_rcv_ind() {
		return ssa_dbal_bnft_rcv_ind;
	}
	/**
	 * @param ssa_dbal_bnft_rcv_ind the ssa_dbal_bnft_rcv_ind to set
	 */
	public void setSsa_dbal_bnft_rcv_ind(String ssa_dbal_bnft_rcv_ind) {
		this.ssa_dbal_bnft_rcv_ind = ssa_dbal_bnft_rcv_ind;
	}
	/**
	 * @return the estb_phy_resp
	 */
	public String getEstb_phy_resp() {
		return estb_phy_resp;
	}
	/**
	 * @param estb_phy_resp the estb_phy_resp to set
	 */
	public void setEstb_phy_resp(String estb_phy_resp) {
		this.estb_phy_resp = estb_phy_resp;
	}
	/**
	 * @return the ecp_id
	 */
	public Integer getEcp_id() {
		return ecp_id;
	}
	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(Integer ecp_id) {
		this.ecp_id = ecp_id;
	}
	/**
	 * @return the chg_dt
	 */
	public Date getChg_dt() {
		if(chg_dt == null) {
		return null;
		}else {
			return chg_dt;
		}
	}
	
	/**
	 * @param chg_dt the chg_dt to set
	 */
	
	/**
	 * @return the loopingQuestion
	 */
	public String getLoopingQuestion() {
		return loopingQuestion;
	}
	
	public void setChg_dt(Date chg_dt) {
		if(chg_dt == null) {
		this.chg_dt = null;
		}else {
			this.chg_dt =chg_dt;
		}
	}
	public String getNur_hspc_prvd_nm() {
		return nur_hspc_prvd_nm;
	}
	public void setNur_hspc_prvd_nm(String nur_hspc_prvd_nm) {
		this.nur_hspc_prvd_nm = nur_hspc_prvd_nm;
	}


}
