package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.APP_IN_INST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_INST_Key;

@NoRepositoryBean
public interface CpAppInstRepository  extends CrudRepository<APP_IN_INST_Cargo, APP_IN_INST_Key>{

	@Query("select c from APP_IN_INST_Cargo c where c.app_num = ?1")
	public APP_IN_INST_Cargo[] getByAppNum(String appNum); 
}
