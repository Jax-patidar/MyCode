/**
 * 
 */
package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.business.entities.CP_CMB_CASE_INFORMATION_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_CMB_CASE_INFORMATION_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

/**
 * @author shtony
 *
 */
@Component("CMBCL")
@Scope("prototype")
public class GetCpCmbDataWrapper implements LogicResponseInterface {
	
	private static final String PAGE_ID = "CMBCL";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTxn.getPageCollection();
	List<CP_CMB_CASE_INFORMATION_Cargo> cpCmbList = new ArrayList<CP_CMB_CASE_INFORMATION_Cargo>();
		CP_CMB_CASE_INFORMATION_Cargo cpCmbCaseInfoCargo= new CP_CMB_CASE_INFORMATION_Cargo();
		CP_CMB_CASE_INFORMATION_Collection cpCmbCaseInfoColl = pageCollection.get("CP_CMB_CASE_INFORMATION_Collection") != null ? (CP_CMB_CASE_INFORMATION_Collection) pageCollection.get("CP_CMB_CASE_INFORMATION_Collection") : null;
	
		if(cpCmbCaseInfoColl != null && !cpCmbCaseInfoColl.isEmpty() && cpCmbCaseInfoColl.size() >0) {			
			for (int i = 0; i < cpCmbCaseInfoColl.size(); i++) {
				cpCmbCaseInfoCargo = (CP_CMB_CASE_INFORMATION_Cargo) cpCmbCaseInfoColl.get(i);
				cpCmbList.add(cpCmbCaseInfoCargo);
			}
		}
		driverPageResponse.getPageCollection().put("CP_CMB_CASE_INFORMATION_Collection", cpCmbList);
		return driverPageResponse;
	}

}
