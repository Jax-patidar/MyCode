package gov.state.nextgen.householddemographics.responsewrappers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.driver.FwPageManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.access.management.references.ReferenceTableManager;
import gov.state.nextgen.access.management.util.DateRoutine;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.householddemographics.business.rules.PeopleHandler;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.HouseholdSummarySectionRow;
import gov.state.nextgen.householddemographics.model.Individual;
import gov.state.nextgen.householddemographics.model.IndividualDropDownRow;
import gov.state.nextgen.householddemographics.model.IndvMovedOutSummarySectionRow;
import gov.state.nextgen.householddemographics.model.PageResponse;
import gov.state.nextgen.householddemographics.model.SummarySection;

@Component("ARHCS")
@Scope("prototype")
public class HouseholdInfoSummaryView implements LogicResponseInterface {

    private static final String PAGE_ID = "ARHCS";
    private static final String NO_ONE = "No One";

    private IReferenceTableManager iref = ReferenceTableManager.getInstance();

    @Autowired
    private PeopleHandler peopleHandler;

    @Autowired
    private FwPageManager pageManager;

    /**
     * Construct the pageResponse
     * @param txBean
     * @return
     */
    public PageResponse constructPageResponse(FwTransaction txBean) {
        PageResponse driverPageResponse = new PageResponse();
        Map pageCollection = txBean.getPageCollection();

        String language = AppConstants.EN;
        final String appType = String.valueOf(FwConstants.RMC_APP_TYPE);
        final String appNum = (String) txBean.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM);

        peopleHandler.getHouseholdIndividuals(appNum);
        INDIVIDUAL_Custom_Collection otherIncColl = peopleHandler.getInHomeIndividuals(appNum);
        INDIVIDUAL_Custom_Collection indivCustColl  = peopleHandler.getAllIndvCustomCollectionFromAppNum(appNum);

        INDIVIDUAL_Custom_Collection people_movedOut = (INDIVIDUAL_Custom_Collection) pageCollection.get("PEOPLE_20055");

        /**
         * Some left the House START
         */
        APP_INDV_Collection indvLiveChgColl = (APP_INDV_Collection)pageCollection.get("ARHCS_LEFTHOME_DETAILS_COLLECTION");
        List<SummarySection> indvMovedOutSummarySecList = new ArrayList<SummarySection>();
        indvMovedOutSummarySecList.add(populateIndvMovedOutSummarySection(indvLiveChgColl, appType, language, peopleHandler, people_movedOut));

        /**
         * Some left the House END
         */

        /**
         * Head of household summary(s) START
          */
        List householdCheck = new ArrayList<>();
            householdCheck.add("false");

        final APP_INDV_Collection roomColl = (APP_INDV_Collection)pageCollection.get("APP_IN_INDV_Collection");

        List<SummarySection> householdSummarySecList = new ArrayList<SummarySection>();
        householdSummarySecList.add(populateHouseholdSummarySection(roomColl, appType, language, peopleHandler));

        /**
         * Household Member(s) Summary End
         */

        /**
         * Someone Moved In Start
         */
        List movedInCheck = new ArrayList<>();
            movedInCheck.add("false");

        final APP_INDV_Collection appIndvColl = (APP_INDV_Collection)pageCollection.get("ARHCS_ADD_PRSN_DTLS_COLLECTION");

        List<SummarySection> movedInSummarySecList = new ArrayList<SummarySection>();
        movedInSummarySecList.add(populateMovedInSummarySection(appIndvColl, appType, language, peopleHandler));
        /**
         * Someone Moved In End
         */

        return driverPageResponse;
    }

    /**
     * Populate MovedIn Summary section.
     * @param appIndvCol
     * @param appType
     * @param language
     * @param peopleHandler
     * @return
     */
    private SummarySection populateMovedInSummarySection(final APP_INDV_Collection appIndvCol, final String appType, final String language, final PeopleHandler peopleHandler) {

        APP_INDV_Collection appIndvColl = getMovedInIndvColl(appIndvCol);
        final int rowCount = appIndvColl.size();
        int rows = 0;
        APP_INDV_Cargo cargo = null;

        List<IndvMovedOutSummarySectionRow> movedInSecRowList = new ArrayList<IndvMovedOutSummarySectionRow>(rowCount);
        for(int j=0; j<rowCount; j++) {
            movedInSecRowList.add(new IndvMovedOutSummarySectionRow());
        }

        for (int i = 0; i < rowCount; i++) {

            cargo = appIndvColl.getCargo(i);
            String indvSeqNum = StringUtils.EMPTY;

            if(Objects.nonNull(cargo.getIndv_seq_num())){
                indvSeqNum = String.valueOf(cargo.getIndv_seq_num());
            }
            IndvMovedOutSummarySectionRow movedInSecRow = new IndvMovedOutSummarySectionRow();
            Individual indv = new Individual();

            INDIVIDUAL_Custom_Cargo indCargo = peopleHandler.getIndividual(indvSeqNum);
            if(indCargo != null) {
                indv.setAge(indCargo.getIndv_age().getYears());
                indv.setFirstName(indCargo.getFst_nam());
                indv.setGender(indCargo.getSex_ind());
            }
            indv.setIndvSeqNumber(indvSeqNum);

            if("EN".equals(language))
            {
                movedInSecRow.setInformation("New Person Added to Home");
            }else {
                movedInSecRow.setInformation("Nueva persona agregada al hogar");
            }

            movedInSecRow.setIndiv(indv);
            movedInSecRow.setShowDelete(true);
            movedInSecRow.setShowEdit(true);
            movedInSecRow.setEditAction("ARHCSEditMovedIn");
            movedInSecRow.setDeleteAction("ARHCSEraseMovedIn");
            movedInSecRow.setRowName("LISTVIEW_SUMMARY_APPINDV_" + String.valueOf(i));
            movedInSecRow.setRowValue(indvSeqNum);
            movedInSecRow.setRowEndsWith("APPINDV_" + String.valueOf(i));

            movedInSecRow.setIndvSeqNo(indvSeqNum);
            movedInSecRowList.set(i, movedInSecRow);

        }
        SummarySection movedInSec = new SummarySection();
        movedInSec.setRowList(movedInSecRowList);
        movedInSec.setShowAddSection(FwConstants.YES);

        return movedInSec;
    }

    /**
     * Gets the moved in indv coll.
     *
     * @param allIndvColl the all indv coll
     * @return the moved in indv coll
     */
    private APP_INDV_Collection getMovedInIndvColl(final APP_INDV_Collection allIndvColl) {
        final APP_INDV_Collection movedInColl = new APP_INDV_Collection();

        for (int i = 0; i < allIndvColl.size(); i++) {
            final APP_INDV_Cargo aCargo = allIndvColl.getCargo(i);
            if (AppConstants.RMC_NEW_RECORD_IND.equals(aCargo.getSrc_app_ind())) {
                movedInColl.addCargo(aCargo);
            }
        }

        return movedInColl;
    }

    /**
     * Populate Moved Out summary section.
     * @param indvLiveChgColl
     * @param appType
     * @param language
     * @param peopleHandler
     * @param JobIncColl
     * @return
     */
    private SummarySection populateIndvMovedOutSummarySection(final APP_INDV_Collection indvLiveChgColl, final String appType, final String language, final PeopleHandler peopleHandler, final INDIVIDUAL_Custom_Collection JobIncColl) {

        int size = 0;

        if(indvLiveChgColl != null && !indvLiveChgColl.isEmpty()) {
            size = indvLiveChgColl.size();
        }

        int rows = 0;
        APP_INDV_Cargo cargo = null;

        List<IndvMovedOutSummarySectionRow> indvMovedOutSecRowList = new ArrayList<IndvMovedOutSummarySectionRow>(size);
        for(int j=0; j<size; j++) {
            indvMovedOutSecRowList.add(new IndvMovedOutSummarySectionRow());
        }
        int row = rows - 1;

        for (int i = 0; i < size; i++) {
            cargo = indvLiveChgColl.getCargo(i);
            String indvSeqNum = StringUtils.EMPTY;
            if(Objects.nonNull(cargo.getIndv_seq_num())){
                indvSeqNum = cargo.getIndv_seq_num().toString();
            }
            IndvMovedOutSummarySectionRow indvMovedOutSecRow = new IndvMovedOutSummarySectionRow();
            Individual indv = new Individual();
            INDIVIDUAL_Custom_Cargo indCargo = peopleHandler.getIndividual(indvSeqNum);
            indv.setAge(indCargo.getIndv_age().getYears());
            indv.setFirstName(indCargo.getFst_nam());
            indv.setGender(indCargo.getSex_ind());
            indv.setIndvSeqNumber(indvSeqNum);

            indvMovedOutSecRow.setIndiv(indv);

            /* Who*/
            if (cargo.getIndv_seq_num() != null) {
                indvMovedOutSecRow.setIndvSeqNo(indvSeqNum);
            } else {
                indvMovedOutSecRow.setIndvSeqNo(null);
            }

            /* Reason*/
            if (cargo.getLeft_home_reason_cd() != null) {
                indvMovedOutSecRow.setLeft_home_reason_cd(cargo.getLeft_home_reason_cd());

            } else {
                indvMovedOutSecRow.setLeft_home_reason_cd(FwConstants.EMPTY_STRING);
            }

            /* Date Moved Out*/
            if (cargo.getLeft_home_dt() != null) {
                String leftHomeDt = cargo.getLeft_home_dt().toString();
                indvMovedOutSecRow.setLeft_home_dt(new SimpleDateFormat("MM/dd/yyyy").format(DateRoutine.getInstance().getDateFromTimeStamp(leftHomeDt)));

            } else {
                indvMovedOutSecRow.setLeft_home_dt(FwConstants.EMPTY_STRING);
            }
            indvMovedOutSecRow.setShowEdit(true);
            indvMovedOutSecRow.setShowDelete(true);
            indvMovedOutSecRow.setEditAction("ARHCSEditMovedOut");
            indvMovedOutSecRow.setDeleteAction("ARHCSEraseMovedOut");

            indvMovedOutSecRow.setRowName("LISTVIEW_SUMMARY_INDVLIVECHG_" + String.valueOf(i));
            indvMovedOutSecRow.setRowValue(indvSeqNum);
            indvMovedOutSecRow.setRowEndsWith("INDVLIVECHG_" + String.valueOf(i));

            indvMovedOutSecRow.setIndvSeqNo(indvSeqNum);
            indvMovedOutSecRowList.set(i, indvMovedOutSecRow);

        }
        SummarySection indvMovedOutSec = new SummarySection();
        indvMovedOutSec.setRowList(indvMovedOutSecRowList);


        List<IndividualDropDownRow> indvDDList = new ArrayList<IndividualDropDownRow>();
        Map indvMap = peopleHandler.sortIndividualsForDropdown(JobIncColl);
        List indvSeqNum = (List) indvMap.get(AppConstants.INDV_SEQUENCE_NUMBERS);
        List desc = (List) indvMap.get(AppConstants.INDV_DESCRIPTIONS);

        for (int i = 0; i < indvSeqNum.size(); i++) {
            boolean matchFoundMO = false;
            String newIndvSeqNum = (String) indvSeqNum.get(i);
            for(int j=0; j < indvMovedOutSecRowList.size(); j++) {
                String populateIndvSeq = (indvMovedOutSecRowList.get(j)).getIndvSeqNo();
                if(populateIndvSeq.equals(newIndvSeqNum)){
                    matchFoundMO = true;
                    break;
                }
            }
            if(!matchFoundMO){
                IndividualDropDownRow indvDDRow = new IndividualDropDownRow();
                indvDDRow.setValue((String) indvSeqNum.get(i));
                indvDDRow.setDescription((String) desc.get(i));
                indvDDList.add(indvDDRow);
            }
        }
        indvMovedOutSec.setIndvDDList(indvDDList);
        if(indvDDList != null && indvDDList.size() > 0) {
            indvMovedOutSec.setShowAddSection(FwConstants.YES);
        } else {
            indvMovedOutSec.setShowAddSection(FwConstants.NO);
        }
        return indvMovedOutSec;
    }

    /**
     * Populate Household summary section
     * @param roomColl
     * @param appType
     * @param language
     * @param peopleHandler
     * @return
     */
    private SummarySection populateHouseholdSummarySection(final APP_INDV_Collection roomColl, final String appType, final String language, final PeopleHandler peopleHandler) {
        int size = 0;
        if(roomColl != null && !roomColl.isEmpty()) {
            size = roomColl.size();
        }
        int rows = 0;


        for (int i = 0; i < size; i++) {
            final APP_INDV_Cargo roomCargo = roomColl.getCargo(i);
            final String srcAppInd = roomCargo.getSrc_app_ind();
            if (AppConstants.RMC_MODIFIED_RECORD_IND.equals(srcAppInd)) {
                rows++;
            }
        }

        rows = size - rows;

        List<HouseholdSummarySectionRow> householdSecRowList = new ArrayList<HouseholdSummarySectionRow>(rows);
        for(int j=0; j<rows; j++) {
            householdSecRowList.add(new HouseholdSummarySectionRow());
        }
        int row = rows - 1;
        APP_INDV_Cargo prevCargo = null;

        for (int i = size - 1; i > -1; i--) {

            final APP_INDV_Cargo cargo = roomColl.getCargo(i);
            String indvSeqNum = StringUtils.EMPTY;
            if(Objects.nonNull(cargo.getIndv_seq_num())){
                indvSeqNum = cargo.getIndv_seq_num().toString();
            }
            final String srcAppInd = cargo.getSrc_app_ind();

            HouseholdSummarySectionRow householdSecRow = new HouseholdSummarySectionRow();
            Individual indv = new Individual();

            INDIVIDUAL_Custom_Cargo indCargo = peopleHandler.getIndividual(indvSeqNum);
            if(indCargo != null) {
                indv.setAge(indCargo.getIndv_age().getYears());
                indv.setFirstName(indCargo.getFst_nam());
                indv.setGender(indCargo.getSex_ind());
            }
            indv.setIndvSeqNumber(indvSeqNum);

            householdSecRow.setIndiv(indv);


            if (cargo.getFst_nam() != null) {
                householdSecRow.setFst_nam(cargo.getFst_nam().trim());
            }

            if (cargo.getLast_nam() != null) {
                householdSecRow.setLast_nam(cargo.getLast_nam().trim());
            }

            if (cargo.getMid_init() != null) {
                householdSecRow.setMid_init(cargo.getMid_init().trim());
            }
            if (cargo.getSex_ind() != null) {
                String temp = null;
                if (cargo.getSex_ind() != null) {
                    temp = cargo.getSex_ind();
                } else {
                    temp = FwConstants.EMPTY_STRING;
                }

                householdSecRow.setSex_ind(temp);
            }
            if (cargo.getBrth_dt()!= null) {
                householdSecRow.setBrth_dt(getMMDDYYYYDate(cargo.getBrth_dt().toString()));
            }
            if (cargo.getSsn_num() != null) {
                String ssnNumber = FwConstants.EMPTY_STRING;
                if ((cargo.getSsn_num() != null) && (cargo.getSsn_num().trim().length() > 4)) {
                    ssnNumber = "XXXXX" + cargo.getSsn_num().trim().substring(5);
                }
                householdSecRow.setSsn_num(ssnNumber);
            }

            if (cargo.getSs_num_app_dt() != null) {
                if(Objects.nonNull(cargo.getSs_num_app_dt())){
                String temp = cargo.getSs_num_app_dt().toString();
                if ((temp != null) && !temp.equals(HouseHoldDemoGraphicsConstants.HIGH_DATE_OBJ.toString())) {
                    temp = getMMDDYYYYDate(temp);
                } else {
                    temp = FwConstants.EMPTY_STRING;
                }
                householdSecRow.setSs_num_app_dt(temp);
                }
            }

            if (cargo.getMrtl_stat_cd() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getMrtl_stat_cd() != null)
                        && !FwConstants.EMPTY_STRING.equals(cargo.getMrtl_stat_cd().trim())) {
                    temp = cargo.getMrtl_stat_cd().trim();
                }
                householdSecRow.setMrtl_stat_cd(temp);
            }

            if (cargo.getLang_cd() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getLang_cd() != null) && !FwConstants.EMPTY_STRING.equals(cargo.getLang_cd().trim())) {
                    temp = iref.getColumnValue("TLAG", 61, cargo.getLang_cd().trim(), language);
                }
                householdSecRow.setLang_cd(temp);
            }

            if (cargo.getTrb_mbr_resp() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getTrb_mbr_resp() != null)
                        && !FwConstants.EMPTY_STRING.equals(cargo.getTrb_mbr_resp().trim())) {
                    temp = iref.getColumnValue("TYNI", 123, cargo.getTrb_mbr_resp().trim(), language);
                }
                householdSecRow.setTrb_mbr_resp(temp);
            }
            if (cargo.getChld_trb_mbr_resp() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getChld_trb_mbr_resp() != null)
                        && !FwConstants.EMPTY_STRING.equals(cargo.getChld_trb_mbr_resp().trim())) {
                    temp = iref.getColumnValue("TYNI", 123, cargo.getChld_trb_mbr_resp().trim(), language);
                }
                householdSecRow.setChld_trb_mbr_resp(temp);
            }

            if (cargo.getUs_ctzn_sw() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getUs_ctzn_sw() != null)
                        && !FwConstants.EMPTY_STRING.equals(cargo.getUs_ctzn_sw().trim())) {
                    temp = iref.getColumnValue("TYNI", 123, cargo.getUs_ctzn_sw().trim(), language);
                }
                householdSecRow.setUs_ctzn_sw(temp);
            }



            final StringBuilder ch = new StringBuilder();
            if (cargo.getAi_ind() != null) {
                final String value = (String) cargo.getAi_ind();
                if ("1".equals(value)) {
                    ch.append(pageManager.getDisplayText(30797, language));
                }

            }

            if (cargo.getAsia_ind() != null) {
                final String value = (String) cargo.getAsia_ind() ;
                if ("1".equals(value)) {
                    if(!ch.toString().isEmpty())
                        ch.append(",");
                    ch.append(pageManager.getDisplayText(30798, language));
                }

            }

            if (cargo.getWht_ind() != null) {
                final String value = (String) cargo.getWht_ind();
                if ("1".equals(value)) {
                    if(!ch.toString().isEmpty())
                        ch.append(",");
                    ch.append(pageManager.getDisplayText(30819, language));
                }
            }

            if (cargo.getBlk_ind() != null) {
                final String value = (String) cargo.getBlk_ind();
                if ("1".equals(value)) {
                    if(!ch.toString().isEmpty())
                        ch.append(",");
                    ch.append(pageManager.getDisplayText(30799, language));
                }

            }

            if (cargo.getPac_isl_ind() != null) {
                final String value = (String) cargo.getPac_isl_ind();
                if ("1".equals(value)) {
                    if(!ch.toString().isEmpty())
                        ch.append(",");
                    ch.append(pageManager.getDisplayText(30818, language));
                }
            }

            if (cargo.getHspc_ind() != null) {
                final String value = (String) cargo.getHspc_ind();
                if ("1".equals(value)) {
                    if(!ch.toString().isEmpty())
                        ch.append(",");
                    ch.append(pageManager.getDisplayText(30820, language));
                }

            }
            householdSecRow.setRace_ethnicity(ch.toString());

            if (cargo.getRes_wi_sw() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getRes_wi_sw() != null) && !FwConstants.EMPTY_STRING.equals(cargo.getRes_wi_sw().trim())) {
                    temp = cargo.getRes_wi_sw().trim();
                }
                householdSecRow.setRes_wi_sw(temp);
            }

            if (cargo.getIntn_res_resp() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getIntn_res_resp() != null)
                        && !FwConstants.EMPTY_STRING.equals(cargo.getIntn_res_resp().trim())) {
                    temp = cargo.getIntn_res_resp().trim();
                }
                householdSecRow.setIntn_res_resp(temp);
            }

            if (cargo.getMig_farm_wrkr_sw() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getMig_farm_wrkr_sw() != null)
                        && !FwConstants.EMPTY_STRING.equals(cargo.getMig_farm_wrkr_sw().trim())) {
                    temp = cargo.getMig_farm_wrkr_sw().trim();
                }
                householdSecRow.setMig_farm_wrkr_sw(temp);
            }

            if (cargo.getMa_ind() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getMa_ind() != null) && !FwConstants.EMPTY_STRING.equals(cargo.getMa_ind().trim())) {
                    temp = cargo.getMa_ind().trim();
                }
                householdSecRow.setMa_ind(temp);
            }
            if (cargo.getCc_ind() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getCc_ind() != null) && !FwConstants.EMPTY_STRING.equals(cargo.getCc_ind().trim())) {
                    temp = cargo.getCc_ind().trim();
                }
                householdSecRow.setCc_ind(temp);
            }
            if (cargo.getWic_ind() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getWic_ind() != null) && !FwConstants.EMPTY_STRING.equals(cargo.getWic_ind().trim())) {
                    temp = cargo.getWic_ind().trim();
                }
                householdSecRow.setWic_ind(temp);
            }

            if (cargo.getSnap_ind() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getSnap_ind() != null) && !FwConstants.EMPTY_STRING.equals(cargo.getSnap_ind().trim())) {
                    temp = cargo.getSnap_ind().trim();
                }
                householdSecRow.setSnap_ind(temp);
            }

            if (cargo.getTanf_ind() != null) {
                String temp = FwConstants.EMPTY_STRING;
                if ((cargo.getTanf_ind() != null) && !FwConstants.EMPTY_STRING.equals(cargo.getTanf_ind().trim())) {
                    temp = cargo.getTanf_ind().trim();
                }
                householdSecRow.setTanf_ind(temp);
            }

            // Start: Summary Grid Changes
            if (srcAppInd.equals(AppConstants.RMC_MODIFIED_RECORD_IND)) {
                householdSecRow.setShowEdit(true);
                householdSecRow.setShowDelete(true);
                householdSecRow.setEditAction("ARHCSEditHouseholdMemberDetails");
                householdSecRow.setDeleteAction("ARHCSEraseHouseholdMemberDetails");
            } else if (srcAppInd.equals(AppConstants.CWW_RECORD_IND) && (prevCargo == null)) {
                householdSecRow.setShowEdit(true);
                householdSecRow.setShowDelete(false);
                householdSecRow.setEditAction("ARHCSEditHouseholdMemberDetails");
            }
            // End: Summary Grid Changes
            if(srcAppInd.equals(AppConstants.RMC_MODIFIED_RECORD_IND)
                    || (srcAppInd.equals(AppConstants.CWW_RECORD_IND) && (prevCargo == null))) {
                householdSecRow.setRowName("RMB_SUMMARY_LISTVIEW_HOUSEHOLD_" + String.valueOf(row));
                householdSecRow.setRowValue(cargo.getIndv_seq_num() + AppConstants.PIPE + cargo.getSrc_app_ind());
                householdSecRow.setRowEndsWith("HOUSEHOLD_" + String.valueOf(row));

                if(Objects.nonNull(cargo.getIndv_seq_num())){
                    householdSecRow.setIndvSeqNo(cargo.getIndv_seq_num().toString());
                }
                householdSecRowList.set(row, householdSecRow);
            }

            if (AppConstants.RMC_MODIFIED_RECORD_IND.equals(srcAppInd)) {
                prevCargo = cargo;
            } else {
                prevCargo = null;
                row--;
            }

        }
        SummarySection householdSec = new SummarySection();
        householdSec.setRowList(householdSecRowList);
        householdSec.setShowAddSection(FwConstants.NO);

        return householdSec;
    }

    /**
     * getMMDDYYYYDate
     * @param yyyyMmDd
     * @return
     */
    public String getMMDDYYYYDate(String yyyyMmDd) {
        String result = "";
        // Get the values for the date, month and year from the given sql date
        yyyyMmDd = yyyyMmDd.substring(0, 10);
        final String yyyy = yyyyMmDd.substring(0, 4);
        final String mm = yyyyMmDd.substring(5, 7);
        final String dd = yyyyMmDd.substring(8, 10);

        result = new StringBuilder(mm).append("/").append(dd).append("/").append(yyyy).toString();
        return result;
    }

}
