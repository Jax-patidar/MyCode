package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseIndividualDetailsLtcNewPersonDetail implements Serializable {
	
	private static final long serialVersionUID = 7341537121787366615L;
	
	@JsonProperty("LtcInd")
	private boolean ltcind;
	
	@JsonProperty("facilityName")
	private String facilityName;
	
	@JsonProperty("facilityAddress")
	private LtcNewPersonDetailAddress facilityAddress;
	
	@JsonProperty("domesticPartnerFirstName")
	private String domesticPartnerFirstName;
	
	@JsonProperty("domesticPartnerMidName")
	private String domesticPartnerMidName;
	
	@JsonProperty("domesticPartnerLastName")
	private String domesticPartnerLastName;

	@JsonProperty("domesticPartnerAddress")
	private LtcNewPersonDetailAddress domesticPartnerAddress;
	
	@JsonProperty("entanceDate")
	private Date entanceDate;
	
	@JsonProperty("dischargeDate")
	private Date dischargeDate;
	
	public boolean getLtcind() {
		return ltcind;
	}

	public void setLtcind(boolean ltcind) {
		this.ltcind = ltcind;
	}

	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getDomesticPartnerFirstName() {
		return domesticPartnerFirstName;
	}

	public void setDomesticPartnerFirstName(String domesticPartnerFirstName) {
		this.domesticPartnerFirstName = domesticPartnerFirstName;
	}

	public Date getEntanceDate() {
		return entanceDate;
	}

	public void setEntanceDate(Date entanceDate) {
		this.entanceDate = entanceDate;
	}

	public Date getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	public LtcNewPersonDetailAddress getFacilityAddress() {
		return facilityAddress;
	}

	public void setFacilityAddress(LtcNewPersonDetailAddress facilityAddress) {
		this.facilityAddress = facilityAddress;
	}

	public LtcNewPersonDetailAddress getDomesticPartnerAddress() {
		return domesticPartnerAddress;
	}

	public void setDomesticPartnerAddress(LtcNewPersonDetailAddress domesticPartnerAddress) {
		this.domesticPartnerAddress = domesticPartnerAddress;
	}

	public String getDomesticPartnerMidName() {
		return domesticPartnerMidName;
	}

	public void setDomesticPartnerMidName(String domesticPartnerMidName) {
		this.domesticPartnerMidName = domesticPartnerMidName;
	}

	public String getDomesticPartnerLastName() {
		return domesticPartnerLastName;
	}

	public void setDomesticPartnerLastName(String domesticPartnerLastName) {
		this.domesticPartnerLastName = domesticPartnerLastName;
	}
	
}
