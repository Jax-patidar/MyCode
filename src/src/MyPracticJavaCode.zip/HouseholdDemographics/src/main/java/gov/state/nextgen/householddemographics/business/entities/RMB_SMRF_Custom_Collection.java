/*
 * Created on Sep 9, 2009
 *
 */
package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * @author nagargo
 *
 */
public class RMB_SMRF_Custom_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.customEntities.RMB_SMRF_Custom_Cargo";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final RMB_SMRF_Custom_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final RMB_SMRF_Custom_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final RMB_SMRF_Custom_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public RMB_SMRF_Custom_Cargo[] getResults() {
		final RMB_SMRF_Custom_Cargo[] cbArray = new RMB_SMRF_Custom_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public RMB_SMRF_Custom_Cargo getCargo(final int idx) {
		return (RMB_SMRF_Custom_Cargo) get(idx);
	}


	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof RMB_SMRF_Custom_Cargo[]) {
			final RMB_SMRF_Custom_Cargo[] cbArray = (RMB_SMRF_Custom_Cargo[]) obj;
			setResults(cbArray);
		}
	}

}
