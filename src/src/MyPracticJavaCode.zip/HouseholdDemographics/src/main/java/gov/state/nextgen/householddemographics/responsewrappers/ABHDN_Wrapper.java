package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABHDN")
@Scope("prototype")
public class ABHDN_Wrapper implements LogicResponseInterface{
	private static final String PAGE_ID = "ABHDN";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
	
		Map pageCollection = fwTrxn.getPageCollection();
		
		List<APP_INDV_Cargo> indvList = new ArrayList<APP_INDV_Cargo>();
		APP_INDV_Cargo cargo = new APP_INDV_Cargo();
		
		Integer[] pgmKey =  (Integer[]) pageCollection.get("pgmKey");
		APP_INDV_Collection appCollection = pageCollection.get("APP_INDV_Collection") != null ? (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection") : null;
		if(appCollection != null && !appCollection.isEmpty() && appCollection.size() > 0) {
			cargo = appCollection.getCargo(0);
			if(pgmKey != null) {
				if(pgmKey[0] == 1)
					cargo.setMaFlag(true);
				if(pgmKey[2] == 1)
					cargo.setSnapFlag(true);
				if(pgmKey[9] == 1)
					cargo.setTanfFlag(true);
			}
		}
		
		indvList.add(cargo);
		
		driverPageResponse.getPageCollection().put("APP_INDV_Collection", indvList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getRequest().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		return driverPageResponse;
	}

}
