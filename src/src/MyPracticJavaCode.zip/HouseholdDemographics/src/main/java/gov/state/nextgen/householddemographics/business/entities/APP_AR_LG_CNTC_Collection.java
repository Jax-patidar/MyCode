package gov.state.nextgen.householddemographics.business.entities;

/**
 * This class contains the collection of entities of CP_APP_AR_LG_CNTC
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_AR_LG_CNTC_Collection extends AbstractCollection  {

	private static final long serialVersionUID = 3369374131543926787L;

	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.APP_AR_LG_CNTC";
	
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_AR_LG_CNTC_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_AR_LG_CNTC_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_AR_LG_CNTC_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_AR_LG_CNTC_Cargo[] getResults() {
		final APP_AR_LG_CNTC_Cargo[] cbArray = new APP_AR_LG_CNTC_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_AR_LG_CNTC_Cargo getCargo(final int idx) {
		return (APP_AR_LG_CNTC_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_AR_LG_CNTC_Cargo[] cloneResults() {
		final APP_AR_LG_CNTC_Cargo[] rescargo = new APP_AR_LG_CNTC_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_AR_LG_CNTC_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_AR_LG_CNTC_Cargo();
			rescargo[i].setCon_name(cargo.getCon_name());
			rescargo[i].setAgency_name(cargo.getAgency_name());
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setCity_adr(cargo.getCity_adr());
			rescargo[i].setLine1_adr(cargo.getLine1_adr());
			rescargo[i].setLine2_adr(cargo.getLine2_adr());
			rescargo[i].setPhone_num(cargo.getPhone_num());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setState_adr(cargo.getState_adr());
			rescargo[i].setZip_adr(cargo.getZip_adr());
			rescargo[i].setAr_rlt_with_app_cd(cargo.getAr_rlt_with_app_cd()); // AFB
			// Changes
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_AR_LG_CNTC_Cargo[]) {
			final APP_AR_LG_CNTC_Cargo[] cbArray = (APP_AR_LG_CNTC_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
	
