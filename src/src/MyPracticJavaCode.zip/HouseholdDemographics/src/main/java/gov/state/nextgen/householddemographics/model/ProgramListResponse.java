/**
 * 
 */
package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

/**
 * @author rudeshmukh
 *
 */
public class ProgramListResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String programCode;
	private List<Integer> programIndividualsSequenceNumber;

	
	public String getProgramCode() {
		return programCode;
	}
	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}
	public List<Integer> getProgramIndividualsSequenceNumber() {
		return programIndividualsSequenceNumber;
	}
	public void setProgramIndividualsSequenceNumber(List<Integer> programIndividualsSequenceNumber) {
		this.programIndividualsSequenceNumber = programIndividualsSequenceNumber;
	}
	
}
