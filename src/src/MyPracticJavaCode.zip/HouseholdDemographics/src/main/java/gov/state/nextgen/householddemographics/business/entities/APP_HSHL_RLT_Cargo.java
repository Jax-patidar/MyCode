package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.ICargo;
import gov.state.nextgen.householddemographics.model.Individual;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


public class APP_HSHL_RLT_Cargo extends AbstractCargo {

    /**
	 * 
	 */
	private static final long serialVersionUID = -4939527281586501899L;
	
	private String app_num;
    private Integer ref_indv_seq_num;
    private Integer src_indv_seq_num;
    private String src_app_ind;
    private String care_resp;
    private String chg_eff_dt;
    private String pnp_tghr_sw;
    private String rec_cplt_ind;
    private String rlt_cd;
    private String phy_boe_sep_sw;
    private String tax_dpnd_resp;
    private String chg_dt;
    private String user;
    private Individual sourceIndividual;
    private Individual referenceIndividual;
    private List<String> applicableRelationShipCodesList;

	/**
     * @return the chg_dt
     */
    public String getChg_dt() {
        return chg_dt;
    }

    /**
     * @param chg_dt the chg_dt to set
     */
    public void setChg_dt(String chg_dt) {
        this.chg_dt = chg_dt;
    }

    public String getTax_dpnd_resp() {
        return tax_dpnd_resp;
    }

    public void setTax_dpnd_resp(final String tax_dpnd_resp) {
        this.tax_dpnd_resp = tax_dpnd_resp;
    }

    /**
     * returns the app_num value.
     */
    public String getApp_num() {
        return app_num;
    }

    /**
     * sets the app_num value.
     */
    public void setApp_num(final String app_num) {
        this.app_num = app_num;
    }

    /**
     * returns the ref_indv_seq_num value.
     */
    public Integer getRef_indv_seq_num() {
        return ref_indv_seq_num;
    }

    /**
     * sets the ref_indv_seq_num value.
     */
    public void setRef_indv_seq_num(final Integer ref_indv_seq_num) {
        this.ref_indv_seq_num = ref_indv_seq_num;
    }

    /**
     * returns the src_indv_seq_num value.
     */
    public Integer getSrc_indv_seq_num() {
        return src_indv_seq_num;
    }

    /**
     * sets the src_indv_seq_num value.
     */
    public void setSrc_indv_seq_num(final Integer src_indv_seq_num) {
        this.src_indv_seq_num = src_indv_seq_num;
    }

    /**
     * returns the src_app_ind value.
     */
    public String getSrc_app_ind() {
        return src_app_ind;
    }

    /**
     * sets the src_app_ind value.
     */
    public void setSrc_app_ind(final String src_app_ind) {
        this.src_app_ind = src_app_ind;
    }

    /**
     * returns the care_resp value.
     */
    public String getCare_resp() {
        return care_resp;
    }

    /**
     * sets the care_resp value.
     */
    public void setCare_resp(final String care_resp) {
        this.care_resp = care_resp;
    }

    /**
     * returns the chg_eff_dt value.
     */
    public String getChg_eff_dt() {
        return chg_eff_dt;
    }

    /**
     * sets the chg_eff_dt value.
     */
    public void setChg_eff_dt(final String chg_eff_dt) {
        this.chg_eff_dt = chg_eff_dt;
    }

    /**
     * returns the pnp_tghr_sw value.
     */
    public String getPnp_tghr_sw() {
        return pnp_tghr_sw;
    }

    /**
     * sets the pnp_tghr_sw value.
     */
    public void setPnp_tghr_sw(final String pnp_tghr_sw) {
        this.pnp_tghr_sw = pnp_tghr_sw;
    }

    /**
     * returns the rec_cplt_ind value.
     */
    public String getRec_cplt_ind() {
        return rec_cplt_ind;
    }

    /**
     * sets the rec_cplt_ind value.
     */
    public void setRec_cplt_ind(final String rec_cplt_ind) {
        this.rec_cplt_ind = rec_cplt_ind;
    }

    /**
     * returns the rlt_cd value.
     */
    public String getRlt_cd() {
        return rlt_cd;
    }

    /**
     * sets the rlt_cd value.
     */
    public void setRlt_cd(final String rlt_cd) {
        this.rlt_cd = rlt_cd;
    }

    /**
     * returns the phy_boe_sep_sw value.
     */
    public String getPhy_boe_sep_sw() {
        return phy_boe_sep_sw;
    }

    /**
     * sets the phy_boe_sep_sw value.
     */
    public void setPhy_boe_sep_sw(final String phy_boe_sep_sw) {
        this.phy_boe_sep_sw = phy_boe_sep_sw;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

	public Individual getSourceIndividual() {
		return sourceIndividual;
	}

	public void setSourceIndividual(Individual sourceIndividual) {
		this.sourceIndividual = sourceIndividual;
	}

	public Individual getReferenceIndividual() {
		return referenceIndividual;
	}

	public void setReferenceIndividual(Individual referenceIndividual) {
		this.referenceIndividual = referenceIndividual;
	}

	public List<String> getApplicableRelationShipCodesList() {
		return applicableRelationShipCodesList;
	}

	public void setApplicableRelationShipCodesList(List<String> applicableRelationShipCodesList) {
		this.applicableRelationShipCodesList = applicableRelationShipCodesList;
	}

    @Override
    public int hashCode() {
        if(Objects.nonNull(this.getSrc_indv_seq_num()) && Objects.nonNull(this.getRef_indv_seq_num())){
            return Integer.valueOf(this.getSrc_indv_seq_num()) * Integer.valueOf(this.getRef_indv_seq_num());
        }
        return 0;
    }

    
}
