package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABBPL")
@Scope("prototype")
public class BirthPlaceResponseView implements LogicResponseInterface{
    private static final String PAGE_ID = "ABBPL";
    
    private static final String APP_INDV_COLLECTION = "APP_INDV_Collection";
    
    public PageResponse constructPageResponse(FwTransaction fwTxn) {
        DriverPageResponse driverPageResponse = new DriverPageResponse();
        Map<Object,Object> pageCollection = fwTxn.getPageCollection();
        List<APP_INDV_Cargo> appIndvCargoList = new ArrayList<APP_INDV_Cargo>();
        APP_INDV_Cargo appIndvCargo;
        APP_INDV_Collection appIndvCollection = pageCollection.get(APP_INDV_COLLECTION) != null ? (APP_INDV_Collection) pageCollection.get(APP_INDV_COLLECTION) : null;
        if(appIndvCollection != null && !appIndvCollection.isEmpty() && appIndvCollection.size() >0) {            
            for (int i = 0; i < appIndvCollection.size(); i++) {
            	appIndvCargo = (APP_INDV_Cargo) appIndvCollection.get(i);
                appIndvCargoList.add(appIndvCargo);
            }
        }
        driverPageResponse.getPageCollection().put(APP_INDV_COLLECTION, appIndvCargoList);
        driverPageResponse.setCurrentPageID(PAGE_ID);
        driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
        driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
        driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
        driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
        return driverPageResponse;
    }

}
