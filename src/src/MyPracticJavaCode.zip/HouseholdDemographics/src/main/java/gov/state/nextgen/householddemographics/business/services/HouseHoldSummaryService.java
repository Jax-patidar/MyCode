package gov.state.nextgen.householddemographics.business.services;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClient;
import com.amazonaws.services.lambda.model.InvocationType;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.amazonaws.util.CollectionUtils;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.business.entities.ServiceResponseCargo;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.access.management.util.ServiceChainUtil;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_SHLTC_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_SHLTC_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Collection;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Collection;
import gov.state.nextgen.householddemographics.business.rules.HouseHoldSummaryBO;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;

@SuppressWarnings("squid:S2229")
@Service("HouseHoldSummaryService")
public class HouseHoldSummaryService implements HouseholdDemographicsService {

	@Autowired
	private HouseHoldSummaryBO houseHoldSummaryBO;
	
	@Autowired
    private CpAppIndvRepository cpAppIndvRepository;
	
	@Autowired
    private ExceptionUtil exceptionUtil;
	
	private static final String INDV_ID = "indvIds";
	
	private static final String GET_SERVICE_CLASS = "getServiceClass";
	
	private static final String GET_DISABILITY_SUMMARY = "getDisabilitySummary";
	
	private static final String GET_GOV_AID_SUMM = "getGovernmentAidSummary";
	
	private static final String GET_PRIMARY_CARE_TAKER = "getPrimartCaretaker";
	
	private static final String GET_FOOD_PROG_SUM = "getFoodProgramSummary";
	
	private static final String GET_ARMED_FOR_SUMM = "getArmedForcesSummary";
	
	private static final String GET_UNABLE_TO_FIX_MEALS = "getUnableToFixMealsSummary";
	
	private static final String GET_CHILD_ADULT_CARE_SUMM = "getChildAdultCareSummary";
	
	private static final String GET_FOSTER_CARE = "getFosterCareSummary";
	
	private static final String GET_FOSTER_CHILD = "getFosterChildSummary";
	
	private static final String GET_IMMIGRATION_SUM = "getImmigrationSummary";
	
	private static final String GET_LEAVING_CALIFORNIA = "getLeavingCaliforniaSummary";
	
	private static final String APP_IMMIGRATION_COLL="APP_IN_IMMIGRATION_Collection";
	
	@Override
	public void callBusinessLogic(String methodName, FwTransaction FwTxn) {
		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.GET_PRFL_DATA:
			getPrflData(FwTxn);
			break;
		default:
		}

	}
	
	@Transactional
	public void getPrflData(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryService.getPrflData() - START",fwTxn);
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();
			Map pageCollection = fwTxn.getPageCollection();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList= new ArrayList<Integer>();
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
			indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			}else {
				indvIds=new ArrayList<String>();
				APP_INDV_Cargo[] appIndvCargoArray =  cpAppIndvRepository.getByAppNum(Integer.parseInt(appNum));
				if(Objects.nonNull(appIndvCargoArray) && ArrayUtils.isNotEmpty(appIndvCargoArray)) {
					for (APP_INDV_Cargo cargo:appIndvCargoArray) {
						indvIds.add(cargo.getIndv_seq_num().toString());
                    }
					pageCollection.put(INDV_ID, indvIds);
					fwTxn.setPageCollection(pageCollection);
					indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
							.collect(Collectors.toList());
				}
			}
			APP_INDV_Collection appIndvColl = houseHoldSummaryBO.loadAppIndvCollection(appNum,indvIdList);

			if (!appIndvColl.isEmpty()) {
				try {
					getDablSummary(fwTxn, appIndvColl);
					getTeenParentSummary(fwTxn, appIndvColl);
					getGovernmentAidSummary(fwTxn, appIndvColl);
					getPrimartCaretakerSummary(fwTxn, appIndvColl);
					getFoodProgramSummary(fwTxn, appIndvColl);
					getArmedForcesSummary(fwTxn, appIndvColl);
					getUnableToFixMealsSummary(fwTxn, appIndvColl);
					getChildAdultCareSummary(fwTxn, appIndvColl);
					getFosterCareSummary(fwTxn, appIndvColl);
					getFosterChildSummary(fwTxn, appIndvColl);
					getLeavingCaliforniaSummary(fwTxn, appIndvColl);
					getCollegeTradeSchoolSummary(fwTxn, appIndvColl);
					getTaxFilerSummary(fwTxn, appIndvColl);
					getPregnancySummary(fwTxn, appIndvColl);
					getBreastFeedingSummary(fwTxn, appIndvColl);
					//Added for RMC
					getImmigrationSummary(fwTxn, appIndvColl);
					getFacilityShelterSummary(fwTxn, appIndvColl);
					
				}catch (Exception e) {
					FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getPrflData()", e);
				}
			}

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getPrflData()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getPrflData", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryService.getPrflData() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime), fwTxn );
	}


	

	private void getDablSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getDisabilityDetails() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			APP_IN_DABL_Collection appInDablColl = houseHoldSummaryBO.loadDisability(appnum,indvIdList);
			if (appInDablColl.size() > 0) {
				APP_IN_DABL_Collection newcoll = new APP_IN_DABL_Collection();
				for (int i = 0; i < appInDablColl.size(); i++) {
					for (int j = 0; j < appIndvColl.size(); j++) {
						APP_IN_DABL_Cargo dablCargo = (APP_IN_DABL_Cargo) appInDablColl.get(i);
						APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
						if (dablCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num())) {
							dablCargo.setLastname(indvCargo.getLast_nam());
							dablCargo.setFirstname(indvCargo.getFst_nam());
							dablCargo.setAge(calculateAge(indvCargo.getBrth_dt()));
							newcoll.addCargo(dablCargo);
						}
					}
				}
				pageCollection.put("APP_IN_DABL_Collection", newcoll);
			} else {
				APP_IN_DABL_Collection emptyCollection = new APP_IN_DABL_Collection();
				pageCollection.put("APP_IN_DABL_Collection", emptyCollection);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getDisabilitySummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, GET_DISABILITY_SUMMARY, fe);
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getDisabilitySummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	private void getGovernmentAidSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getGovernmentAidSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			APP_IN_OUT_ST_BNFT_Collection appInbnftColl = houseHoldSummaryBO.loadGovernmentAid(appnum, indvIdList);
			if (appInbnftColl.size() > 0) {
				APP_IN_OUT_ST_BNFT_Collection newcoll = new APP_IN_OUT_ST_BNFT_Collection();
				for (int i = 0; i < appInbnftColl.size(); i++) {
					for (int j = 0; j < appIndvColl.size(); j++) {
						APP_IN_OUT_ST_BNFT_Cargo bnftCargo = (APP_IN_OUT_ST_BNFT_Cargo) appInbnftColl.get(i);
						APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
						if (bnftCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num())) {
							bnftCargo.setLast_name(indvCargo.getLast_nam());
							bnftCargo.setFirst_name(indvCargo.getFst_nam());
							bnftCargo.setAge(calculateAge(indvCargo.getBrth_dt()));
							newcoll.addCargo(bnftCargo);

						}

					}
				}
				pageCollection.put("APP_IN_OUT_ST_BNFT_Collection", newcoll);

			} else {
				APP_IN_OUT_ST_BNFT_Collection emptyCollection = new APP_IN_OUT_ST_BNFT_Collection();
				pageCollection.put("APP_IN_OUT_ST_BNFT_Collection", emptyCollection);
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getGovernmentAidSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, GET_GOV_AID_SUMM, fe);
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getDisabilitySummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	private void getPrimartCaretakerSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getPrimartCaretakerSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			OTHER_HOUSEHOLD_DETAILS_Collection otherHHCollection = houseHoldSummaryBO.getOtherHouseHoldDetails(appnum,indvIdList);
			if (otherHHCollection.size() > 0) {
				APP_INDV_Collection newcoll = new APP_INDV_Collection();
				for (int i = 0; i < otherHHCollection.size(); i++) {
					for (int j = 0; j < appIndvColl.size(); j++) {
						OTHER_HOUSEHOLD_DETAILS_Cargo bnftCargo = (OTHER_HOUSEHOLD_DETAILS_Cargo) otherHHCollection
								.get(i);
						APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
						if (bnftCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num())
								&& StringUtils.isNotEmpty(bnftCargo.getCare_taker_resp())
								&& bnftCargo.getCare_taker_resp().equals("Y")) {
							indvCargo.setAge(String.valueOf(calculateAge(indvCargo.getBrth_dt())));
							newcoll.addCargo(indvCargo);
						}
					}
				}

				pageCollection.put("APP_IN_Primary_Caretaker_Collection", newcoll);

			} else {
				APP_INDV_Collection emptyCollection = new APP_INDV_Collection();
				pageCollection.put("APP_IN_Primary_Caretaker_Collection", emptyCollection);
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getPrimartCaretaker()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, GET_PRIMARY_CARE_TAKER, fe);
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getPrimartCaretaker() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	private void getFoodProgramSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getFoodProgramSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();

			final int sizeColl = appIndvColl.size();
			if (sizeColl > 0) {
				APP_INDV_Collection newcoll = new APP_INDV_Collection();
				for (int j = 0; j < appIndvColl.size(); j++) {
					APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
					if (StringUtils.isNotEmpty(indvCargo.getIs_food_program())) {
						indvCargo.setAge(calculateAge(indvCargo.getBrth_dt()).toString());
						newcoll.addCargo(indvCargo);
					}
				}
				pageCollection.put("APP_IN_Food_Program_Collection", newcoll);

			}

		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getFoodProgramSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	private void getArmedForcesSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getArmedForcesSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();

			final int sizeColl = appIndvColl.size();
			if (sizeColl > 0) {
				APP_INDV_Collection newcoll = new APP_INDV_Collection();
				for (int j = 0; j < appIndvColl.size(); j++) {
					APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
					if (StringUtils.isNotEmpty(indvCargo.getVet_act_duty_resp())
							|| StringUtils.isNotEmpty(indvCargo.getVet_resp())
							|| StringUtils.isNotEmpty(indvCargo.getVet_dep_resp())) {
						indvCargo.setAge(calculateAge(indvCargo.getBrth_dt()).toString());
						newcoll.addCargo(indvCargo);
					}
				}

				pageCollection.put("APP_IN_Armed_Forces_Collection", newcoll);

			}

		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getArmedForcesSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime),fwTxn);

	}

	private void getUnableToFixMealsSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getUnableToFixMealsSummary() - START");
		try {
			Map pageCollection = fwTxn.getPageCollection();

			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			OTHER_HOUSEHOLD_DETAILS_Collection otherHHCollection = houseHoldSummaryBO.getOtherHouseHoldDetails(appnum, indvIdList);
			if (otherHHCollection.size() > 0) {
				APP_INDV_Collection newcoll = new APP_INDV_Collection();
				for (int i = 0; i < otherHHCollection.size(); i++) {
					for (int j = 0; j < appIndvColl.size(); j++) {
						OTHER_HOUSEHOLD_DETAILS_Cargo bnftCargo = (OTHER_HOUSEHOLD_DETAILS_Cargo) otherHHCollection
								.get(i);
						APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
						if (bnftCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num())
								&& StringUtils.isNotEmpty(bnftCargo.getFix_meal_personselection_resp()) 
								&& bnftCargo.getFix_meal_personselection_resp().equals("Y")) {
							indvCargo.setAge(String.valueOf(calculateAge(indvCargo.getBrth_dt())));
							newcoll.addCargo(indvCargo);
						}
					}
				}

				pageCollection.put("APP_IN_Meals_Collection", newcoll);

			} else {
				APP_INDV_Collection emptyCollection = new APP_INDV_Collection();
				pageCollection.put("APP_IN_Meals_Collection", emptyCollection);
			}

		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getUnableToFixMealsSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime),fwTxn);

	}

	private void getChildAdultCareSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getChildAdultCareSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();

			final int sizeColl = appIndvColl.size();
			if (sizeColl > 0) {
				APP_INDV_Collection newcoll = new APP_INDV_Collection();
				for (int j = 0; j < appIndvColl.size(); j++) {
					APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
					if (StringUtils.isNotEmpty(indvCargo.getIs_child_needs_care())) {
						indvCargo.setAge(calculateAge(indvCargo.getBrth_dt()).toString());
						newcoll.addCargo(indvCargo);
					}
				}

				pageCollection.put("APP_IN_Childcare_Collection", newcoll);

			}

		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getChildAdultCareSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );

	}

	private void getFosterCareSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getFosterCareSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();

			final int sizeColl = appIndvColl.size();
			if (sizeColl > 0) {
				APP_INDV_Collection newcoll = new APP_INDV_Collection();
				for (int j = 0; j < appIndvColl.size(); j++) {
					APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
					if (StringUtils.isNotEmpty(indvCargo.getIs_foster_care())) {
						indvCargo.setAge(calculateAge(indvCargo.getBrth_dt()).toString());
						newcoll.addCargo(indvCargo);
					}
				}

				pageCollection.put("APP_IN_FosterCare_Collection", newcoll);

			}

		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getFosterCareSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	private void getFosterChildSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getFosterChildSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();

			final int sizeColl = appIndvColl.size();
			if (sizeColl > 0) {
				APP_INDV_Collection newcoll = new APP_INDV_Collection();
				for (int j = 0; j < appIndvColl.size(); j++) {
					APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
					if (StringUtils.isNotEmpty(indvCargo.getIs_foster_child())) {
						indvCargo.setAge(calculateAge(indvCargo.getBrth_dt()).toString());
						newcoll.addCargo(indvCargo);
					}
				}
				pageCollection.put("APP_IN_FosterChild_Collection", newcoll);

			}

		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getFosterChildSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	private void getLeavingCaliforniaSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getLeavingCaliforniaSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();

			final int sizeColl = appIndvColl.size();
			if (sizeColl > 0) {
				APP_INDV_Collection newcoll = new APP_INDV_Collection();
				for (int j = 0; j < appIndvColl.size(); j++) {
					APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
					if (StringUtils.isNotEmpty(indvCargo.getIs_leaving_CA())) {
						indvCargo.setAge(calculateAge(indvCargo.getBrth_dt()).toString());
						newcoll.addCargo(indvCargo);
					}
				}
				pageCollection.put("APP_IN_LeavingCA_Collection", newcoll);

			}

		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getLeavingCaliforniaSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );

	}

	private void getPregnancySummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getPregnancySummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());

			CP_APP_IN_PREG_Collection appInPregColl = houseHoldSummaryBO.loadPregnancy(appnum, indvIdList);
			if (appInPregColl.size() > 0) {
				CP_APP_IN_PREG_Collection newcoll = new CP_APP_IN_PREG_Collection();
				for (int i = 0; i < appInPregColl.size(); i++) {
					for (int j = 0; j < appIndvColl.size(); j++) {
						CP_APP_IN_PREG_Cargo pregCargo = (CP_APP_IN_PREG_Cargo) appInPregColl.get(i);
						APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
						if (pregCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num())) {
							pregCargo.setLast_name(indvCargo.getLast_nam());
							pregCargo.setFirst_name(indvCargo.getFst_nam());
							pregCargo.setAge(calculateAge(indvCargo.getBrth_dt()));
							newcoll.addCargo(pregCargo);
						}

					}
				}
				pageCollection.put("APP_IN_PREG_Collection", newcoll);
			} else {
				CP_APP_IN_PREG_Collection emptyCollection = new CP_APP_IN_PREG_Collection();
				pageCollection.put("APP_IN_PREG_Collection", emptyCollection);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getPregnancySummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, "getPregnancySummaryes", fe);
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getPregnancySummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime),fwTxn);

	}

	private void getFacilityShelterSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getFacilityShelterSummary() - START", fwTxn);
		try {

			Map pageCollection = fwTxn.getPageCollection();

			
			
			
			CP_APP_IN_SHLTC_Collection appInShltcColl = getFacilityData(fwTxn);
			
			
			if (appInShltcColl.size() > 0) {
				CP_APP_IN_SHLTC_Collection newcoll = new CP_APP_IN_SHLTC_Collection();
				for (int i = 0; i < appInShltcColl.size(); i++) {
					for (int j = 0; j < appIndvColl.size(); j++) {
						CP_APP_IN_SHLTC_Cargo shltcCargo = (CP_APP_IN_SHLTC_Cargo) appInShltcColl.get(i);
						APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);

						if (shltcCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num())) {

							shltcCargo.setLastname(indvCargo.getLast_nam());
							shltcCargo.setFirstname(indvCargo.getFst_nam());

							Date birthDate = null;

							shltcCargo.setAge(calculateAge(indvCargo.getBrth_dt()));
							newcoll.addCargo(shltcCargo);
						}

					}
				}
				pageCollection.put("APP_IN_SHLTC_Collection", newcoll);
			} else {
				CP_APP_IN_SHLTC_Collection emptyCollection = new CP_APP_IN_SHLTC_Collection();
				pageCollection.put("APP_IN_SHLTC_Collection", emptyCollection);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getFacilityShelterSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, "getFacilityShelterSummarys", fe);
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getFacilityShelterSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	
	/** Method to call asynchronously APP Submission API
	 * @param fwTx
	 * @throws Exception
	 */
	private CP_APP_IN_SHLTC_Collection getFacilityData(FwTransaction fwTx) throws Exception {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getFacilityData() - START", fwTx);
		
		PageActionDetails action = fwTx.getCurrentActionDetails();
		action.setPageAction("ABFINLoad");
		action.setPageId("ABFIN");
		
		fwTx.setCurrentActionDetails(action);
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "URL: "+fwTx.getCurrentActionDetails().getPageAction());

		String payload = ServiceChainUtil.prepareAWSRequest(FwConstants.POST, "/financialinfo/ABFIN/ABFINLoad", "/financialinfo/ABFIN/ABFINLoad", fwTx);
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Gateway object complete");
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Payload received "+payload);
		
		AWSLambda  client = AWSLambdaClient.builder().withRegion("us-west-2").build();
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Function Name "+System.getenv("FINANCIAL_FUNC"));

	    InvokeRequest request = new InvokeRequest();
	    request.setInvocationType(InvocationType.RequestResponse);
	    request.setFunctionName(System.getenv("FINANCIAL_FUNC"));
	    request.setPayload(payload);
	    
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Invoking client");
		 InvokeResult invoke = client.invoke(request);
		 String response = null;
		 DriverPageResponse pageResponse;
		 CP_APP_IN_SHLTC_Collection facilityColl = new CP_APP_IN_SHLTC_Collection();
		 FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Status code: "+invoke.getStatusCode());
		 if(invoke.getStatusCode() == 200) {
			  response = new String(invoke.getPayload().array(), "UTF-8");
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Response received : "+response);

		 }
		 
		 if(response !=null) {
			 ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			 try{
				 FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Converting Json");
				 
				 ServiceResponseCargo responseObj = mapper.readValue(response, ServiceResponseCargo.class);

				 String body = responseObj.getBody();
				 
				 
				 FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Body Received: "+body);

				 pageResponse= mapper.readValue(body, DriverPageResponse.class);
				 Map pageObject = pageResponse.getPageCollection();
				 facilityColl  = (CP_APP_IN_SHLTC_Collection) pageResponse.getCollectionData(pageObject, "CP_APP_IN_SHLTC_Collection");
				 
				 
				 FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Object fetched");

			 }
			 catch (Exception e) {
				 FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getFacilityData()", fwTx);
				 throw e;
			 }
		 }
		 FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseHoldSummaryService.getFacilityData() - END", fwTx);
		
		return facilityColl;

	}
	
	private void getTaxFilerSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldSummaryService.getTaxFilerSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			CP_APP_IN_TAX_RETURN_Collection appInTaxColl = houseHoldSummaryBO.loadTaxFilerSummary(appnum, indvIdList);
			if (appInTaxColl.size() > 0) {
				CP_APP_IN_TAX_RETURN_Collection newcoll = new CP_APP_IN_TAX_RETURN_Collection();
				for (int i = 0; i < appInTaxColl.size(); i++) {
					for (int j = 0; j < appIndvColl.size(); j++) {
						CP_APP_IN_TAX_RETURN_Cargo taxCargo = (CP_APP_IN_TAX_RETURN_Cargo) appInTaxColl.get(i);
						APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
						if (taxCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num())) {
							taxCargo.setFst_name(indvCargo.getFst_nam());
							taxCargo.setLast_name(indvCargo.getLast_nam());
							taxCargo.setAge(calculateAge(indvCargo.getBrth_dt()));
							newcoll.addCargo(taxCargo);

						}
					}
				}
				pageCollection.put("CP_APP_IN_TAX_RETURN_Collection", newcoll);

			} else {
				CP_APP_IN_TAX_RETURN_Collection emptyCollection = new CP_APP_IN_TAX_RETURN_Collection();
				pageCollection.put("CP_APP_IN_TAX_RETURN_Collection", emptyCollection);
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getTaxFilerSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, "getTaxFilerSummaryes", fe);
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getTaxFilerSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	private void getCollegeTradeSchoolSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getCollegeTradeSchoolSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			APP_IN_SCHLE_Collection appInSchleColl = houseHoldSummaryBO.loadCollegeTradeSchool(appnum, indvIdList);
			if (appInSchleColl.size() > 0) {
				APP_IN_SCHLE_Collection newcoll = new APP_IN_SCHLE_Collection();
				for (int i = 0; i < appInSchleColl.size(); i++) {
					for (int j = 0; j < appIndvColl.size(); j++) {
						APP_IN_SCHLE_Cargo SchleCargo = (APP_IN_SCHLE_Cargo) appInSchleColl.get(i);
						APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
						if (SchleCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num())
								&& "CL".equals(SchleCargo.getSchool_type_cd())) {
							SchleCargo.setLast_name(indvCargo.getLast_nam());
							SchleCargo.setFirst_name(indvCargo.getFst_nam());
							SchleCargo.setAge(calculateAge(indvCargo.getBrth_dt()));
							newcoll.addCargo(SchleCargo);
						}
					}
				}
				pageCollection.put("APP_IN_SCHLE_Collection", newcoll);
			} else {
				APP_IN_SCHLE_Collection emptyCollection = new APP_IN_SCHLE_Collection();
				pageCollection.put("APP_IN_SCHLE_Collection", emptyCollection);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getCollegeTradeSchoolSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, "getCollegeTradeSchoolSummaryes", fe);
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getCollegeTradeSchoolSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	private void getBreastFeedingSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getBreastFeedingSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());

			CP_APP_IN_PREG_Collection appInPregColl = houseHoldSummaryBO.loadBreastFeedingDetails(appnum, indvIdList);
			if (appInPregColl.size() > 0) {
				CP_APP_IN_PREG_Collection newcoll = new CP_APP_IN_PREG_Collection();
				for (int i = 0; i < appInPregColl.size(); i++) {
					for (int j = 0; j < appIndvColl.size(); j++) {
						CP_APP_IN_PREG_Cargo teenCargo = (CP_APP_IN_PREG_Cargo) appInPregColl.get(i);
						APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
						if (teenCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num())) {
							teenCargo.setFirst_name(indvCargo.getFst_nam());
							teenCargo.setLast_name(indvCargo.getLast_nam());
							teenCargo.setAge(calculateAge(indvCargo.getBrth_dt()));
							newcoll.addCargo(teenCargo);
						}
					}
				}
				pageCollection.put("APP_IN_BreastFeeding_Collection", newcoll);
			} else {
				CP_APP_IN_PREG_Collection emptyCollection = new CP_APP_IN_PREG_Collection();
				pageCollection.put("APP_IN_BreastFeeding_Collection", emptyCollection);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getBreastFeedingSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, "getBreastFeedingSummaryess", fe);
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getBreastFeedingSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );

	}

	private void getTeenParentSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getTeenParentSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			APP_IN_SCHLE_Collection appInTeenColl = houseHoldSummaryBO.loadTeenParentDetails(appnum,indvIdList);
			if (appInTeenColl.size() > 0) {
				APP_IN_SCHLE_Collection newcoll = new APP_IN_SCHLE_Collection();
				for (int i = 0; i < appInTeenColl.size(); i++) {
					for (int j = 0; j < appIndvColl.size(); j++) {
						APP_IN_SCHLE_Cargo teenCargo = (APP_IN_SCHLE_Cargo) appInTeenColl.get(i);
						APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
						if (teenCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num())
								&& "TN".equals(teenCargo.getSchool_type_cd())) {
							teenCargo.setLast_name(indvCargo.getLast_nam());
							teenCargo.setFirst_name(indvCargo.getFst_nam());
							teenCargo.setAge(calculateAge(indvCargo.getBrth_dt()));
							newcoll.addCargo(teenCargo);
						}
					}
				}
				pageCollection.put("APP_IN_Teen_Parent_Collection", newcoll);
			} else {
				APP_IN_SCHLE_Collection emptyCollection = new APP_IN_SCHLE_Collection();
				pageCollection.put("APP_IN_Teen_Parent_Collection", emptyCollection);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldSummaryService.getTeenParentSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, "getTeenParentSummaryss", fe);
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldSummaryService.getTeenParentSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}
	
	private void getImmigrationSummary(FwTransaction fwTxn, APP_INDV_Collection appIndvColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getImmigrationSummary() - START");
		try {
			Map pageCollection = fwTxn.getPageCollection();

			final int sizeColl = appIndvColl.size();
			if (sizeColl > 0) {
				APP_INDV_Collection newcoll = new APP_INDV_Collection();
				for (int j = 0; j < appIndvColl.size(); j++) {
					APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) appIndvColl.get(j);
					if (StringUtils.isNotEmpty(indvCargo.getAlien_status_cd()) && FwConstants.YES.equalsIgnoreCase(indvCargo.getAlien_status_cd())) {
						indvCargo.setAge(calculateAge(indvCargo.getBrth_dt()).toString());
						newcoll.addCargo(indvCargo);
					}
				}
				pageCollection.put(APP_IMMIGRATION_COLL, newcoll);

			}

		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.GET_IMMIGRATION_SUM() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) );

	}

	public static Integer calculateAge(Date date) {
		Integer age = 0;
		if(Objects.nonNull(date)) {
			LocalDate localBirthDate = LocalDate.parse(date.toString());
			age = Period.between(localBirthDate, LocalDate.now()).getYears();
		}
		return age;
	}
}
