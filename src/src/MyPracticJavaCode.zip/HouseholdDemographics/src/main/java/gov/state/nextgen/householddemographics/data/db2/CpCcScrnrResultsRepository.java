package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_RESULTS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_RESULTS_Key;

@NoRepositoryBean
public interface CpCcScrnrResultsRepository extends CrudRepository<CP_CC_SCRNR_RESULTS_Cargo,CP_CC_SCRNR_RESULTS_Key>{
	
	@Query("select c from CP_CC_SCRNR_RESULTS_Cargo c where c.app_num = ?1")
	public CP_CC_SCRNR_RESULTS_Cargo[] getByAppNum(String appNum);

	
}
