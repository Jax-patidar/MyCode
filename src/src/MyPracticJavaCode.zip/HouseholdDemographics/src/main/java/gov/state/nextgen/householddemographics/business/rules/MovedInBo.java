package gov.state.nextgen.householddemographics.business.rules;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.data.db2.IndividualInformationRepo;

/**
 * Moved In Business Object
 */
@Component
public class MovedInBo extends HouseHoldBaseBO {

    public static final Logger logger = LoggerFactory.getLogger(MovedInBo.class);

    protected IndividualInformationRepo individualInformationRepo;

    /**
     * Load Application Individual collection.
     * @param appNum
     * @return
     */
    public APP_INDV_Collection loadAppIndvColl(String appNum) {
        final long startTime = System.currentTimeMillis();
        logger.info("MovedInBO.loadAppIndvColl() - START");
        APP_INDV_Collection appIndvColl = new APP_INDV_Collection();
        List<APP_INDV_Cargo> appIndvCargoList = getAppIndvCargos(individualInformationRepo.findByAppNum(Integer.parseInt(appNum)));
        if(!CollectionUtils.isEmpty(appIndvCargoList)){
            appIndvColl.setResults(appIndvCargoList.toArray(new APP_INDV_Cargo[appIndvCargoList.size()]));
        }
        return appIndvColl;
    }

    /**
     *
     * @param appNum
     * @return
     */
    public APP_INDV_Collection getHouseHoldMemberDetails(String appNum) {
        final long startTime = System.currentTimeMillis();
        logger.info("MovedInBo.getHouseHoldMemberDetails - START");
        APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
        List<APP_INDV_Cargo> appIndvCargoList = getAppIndvCargos(individualInformationRepo.findByAppNumWithConditionalSrcAppInd(Integer.parseInt(appNum)));
        if(!CollectionUtils.isEmpty(appIndvCargoList)){
            appIndvCollection.setResults(appIndvCargoList.toArray(new APP_INDV_Cargo[appIndvCargoList.size()]));
        }
        return appIndvCollection;
    }
}
