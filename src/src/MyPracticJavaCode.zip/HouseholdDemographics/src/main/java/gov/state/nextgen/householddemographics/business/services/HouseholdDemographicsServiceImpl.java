package gov.state.nextgen.householddemographics.business.services;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

//import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.business.entities.ICargo;
import gov.state.nextgen.access.driver.FwPageManager;
import gov.state.nextgen.access.driver.IPage;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessage;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.access.management.util.DateRoutine;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.access.management.util.FwDate;
import gov.state.nextgen.framework.business.model.IndividualCategorySequenceDetails;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.ADD_VAL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.ADD_VAL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_IMG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_IMG_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_ABSNP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_ABSNP_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_INST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_INST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SPS_IMPOV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SPS_IMPOV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_USER_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_USER_Collection;
import gov.state.nextgen.householddemographics.business.entities.Address_Validate_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.Address_Validate_Custom_Collection;
import gov.state.nextgen.householddemographics.business.entities.ApplicationRequest_Cargo;
import gov.state.nextgen.householddemographics.business.entities.ApplicationRequest_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IMMED_CASH_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_SHLTC_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_SHLTC_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_DEPENDENTS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_SUPPORT_SERVICES_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_AUTOMATED_SMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_HSHL_DETAILS_DISASTER_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_HSHL_DETAILS_DISASTER_Collection;
import gov.state.nextgen.householddemographics.business.entities.CaseIndividualDetails;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4MoveoutSsiSsp_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4MoveoutSsiSsp_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4Redet_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4Redet_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Collection;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.business.rules.ABAbsentParentBO;
import gov.state.nextgen.householddemographics.business.rules.ABAuthorizedRepresentativeBO;
import gov.state.nextgen.householddemographics.business.rules.ABCreateAppNumBO;
import gov.state.nextgen.householddemographics.business.rules.ABDisabilityBO;
import gov.state.nextgen.householddemographics.business.rules.ABHouseHoldMemberBO;
import gov.state.nextgen.householddemographics.business.rules.ABHouseHoldRelationshipBO;
import gov.state.nextgen.householddemographics.business.rules.ABHouseholdMembersSummaryBO;
import gov.state.nextgen.householddemographics.business.rules.ABProgramInformationBO;
import gov.state.nextgen.householddemographics.business.rules.ABRegistrationBO;
import gov.state.nextgen.householddemographics.business.rules.ABSupportServicesBO;
import gov.state.nextgen.householddemographics.business.rules.AbsentParentBO;
import gov.state.nextgen.householddemographics.business.rules.AddressValidationAPI;
import gov.state.nextgen.householddemographics.business.rules.ContactInformationBO;
import gov.state.nextgen.householddemographics.business.rules.DisasterBO;
import gov.state.nextgen.householddemographics.business.rules.FosterCareBO;
import gov.state.nextgen.householddemographics.business.rules.HelpWithApplicationBO;
import gov.state.nextgen.householddemographics.business.rules.HouseHoldSummaryBO;
import gov.state.nextgen.householddemographics.business.rules.HouseholdApplicationBO;
import gov.state.nextgen.householddemographics.business.rules.ImmediateCashAssistanceBO;
import gov.state.nextgen.householddemographics.business.rules.OtherHouseholdDetailsBO;
import gov.state.nextgen.householddemographics.business.rules.PeopleHandler;
import gov.state.nextgen.householddemographics.business.rules.RMBRequestBO;
import gov.state.nextgen.householddemographics.business.rules.RMBRequestDetailBO;
import gov.state.nextgen.householddemographics.business.rules.TaxInformationBO;
import gov.state.nextgen.householddemographics.configuration.AWSProperties;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.AppSbmsRepository;
import gov.state.nextgen.householddemographics.data.db2.AutomatedSMSRepository;
import gov.state.nextgen.householddemographics.data.db2.CP_APP_RGST_Repository;
import gov.state.nextgen.householddemographics.data.db2.CpAbsPrntRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppAuthRepRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInDablRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInPrflRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppRgstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;
import gov.state.nextgen.householddemographics.model.AppSummaryDtlsModel;
import gov.state.nextgen.householddemographics.model.ChangeRenewalApplicationsRespone;
import gov.state.nextgen.householddemographics.model.IndivTypeSeq;
import gov.state.nextgen.householddemographics.model.IndivTypeSeqBean;
import gov.state.nextgen.householddemographics.model.Individual;
import gov.state.nextgen.householddemographics.model.NotificationModel;
import gov.state.nextgen.householddemographics.model.OngoingApplicationsResponse;
import gov.state.nextgen.householddemographics.responsewrappers.AppHistoryView;

/**
 * Service layer class of HouseholdDemographics.
 *
 * Created by @DeloitteUSI team Creation Date Wed Sep 29 11:34:07 IST 2020
 * 
 * @authors: @prabhasingh
 */

@SuppressWarnings("squid:S2229")
@Service("HouseholdDemographicsService")
public class HouseholdDemographicsServiceImpl implements HouseholdDemographicsService {

	/** The date routine. */
	DateRoutine dateRoutine = DateRoutine.getInstance();

	/** The fw date. */
	FwDate fwDate = FwDate.getInstance();

	@Autowired
	private ABProgramInformationBO programInfoBo;

	@Autowired
	private ABAuthorizedRepresentativeBO abAuthorizedRepresentativeBO;

	@Autowired
	private ImmediateCashAssistanceBO immedCashBO;

	private static final String TILDE = "~";

	@Autowired
	private CpAppAuthRepRepository cpAppAuthRepRepository;

	@Autowired
	private CP_APP_RGST_Repository cpAppRgstRepo;

	@Autowired
	private ContactInformationBO contInfoBO;

	@Autowired
	private HelpWithApplicationBO helpBO;

	@Autowired
	private ABHouseHoldMemberBO houseHoldBo;

	@Autowired
	private IReferenceTableManager iref;

	@Autowired
	private ABRegistrationBO registrationBo;

	@Autowired
	PeopleHandler peopleHandler;

	@Autowired
	private CpAppRgstRepository cpAppRgstRepository;

	private CpAppInPrflRepository cpAppInPrflRepository;

	@Autowired
	private ABDisabilityBO disabilityBo;

	@Autowired
	private ABAbsentParentBO abAbsentParentBo;

	@Autowired
	AbsentParentBO absentParentBo;

	@Autowired
	private CpAppPgmRqstRepository cpAppPgmRqstRepository;

	@Autowired
	private HouseholdRelationshipRepo householdRelationshipRepo;

	@Autowired
	private CpAppIndvRepository cpAppIndvRepository;

	@Autowired
	private ABHouseHoldRelationshipBO houseHoldRelationBo;

	@Autowired
	private ABCreateAppNumBO abcreateAppNumBO;

	@Autowired
	private CpAppInDablRepository cpAppInDablRepository;

	@Autowired
	private FosterCareBO fosterCareBO;

	@Autowired
	private AddressValidationAPI addressValidationRef;

	@Autowired
	private CpAbsPrntRepository absPrntRepository;

	@Autowired
	private CpAppPgmIndvRepository cpAppPgmIndvRepository;

	@Autowired
	private CP_APP_RGST_Repository cp_app_rgst_repo;

	@Autowired
	private ABHouseholdMembersSummaryBO aBHouseholdMembersSummaryBO;

	@Autowired
	private ExceptionUtil exceptionUtil;

	@Autowired
	private AppSbmsRepository appSbmsRepository;

	@Autowired
	private HouseHoldSummaryBO houseHoldSummaryBO;

	@Autowired
	private AppSbmsRepository appsbms;

	@Autowired
	private ABSupportServicesBO supportBO;

	@Autowired
	private AWSSQSService sqsService;

	@Autowired
	private AWSProperties awsProperties;

	@Autowired
	private HouseholdApplicationBO householdApplicationBO;

	@Autowired
	private OtherHouseholdDetailsBO otherBO;

	@Autowired
	private TaxInformationBO taxBO;

	private AppHistoryView appHistoryView;

	@Autowired
	protected ApplicationContext applicationContext;

	@Autowired
	private DisasterBO disasterBO;

	@Autowired
	private ABCreateAppNumBO appUserBO;

	@Autowired
	CpAppRqstRepository appRqstRepository;

	@Autowired
	private CP_APP_RGST_Repository cpAppRgstRepos;
	
	@Autowired 
	UserCredentialServImpl userCredService;
	
	@Autowired
    RMBRequestBO rmbRequestBO;
	
	@Autowired
	RMBRequestDetailBO rmbRequestDetailBO;
	
	@Autowired
    private HouseHoldSummaryService houseHoldSummaryService;
	
	@Autowired
	private ARTransactionManagedServImpl arTransactionService;
	
	@Autowired
	AutomatedSMSRepository autoSMSRepo;

	private static final String INDV_ID = "indvIds";

	private static final String APP_INDV_COLL = "APP_INDV_Collection";

	private static final String CP_APP_RGST_COLL = "CP_APP_RGST_Collection";

	private static final String APP_RGST_COLL = "APP_RGST_Collection";

	private static final String APP_PGM_RQST_COLL = "APP_PGM_RQST_Collection";

	private static final String APP_ABS_PRNT_COLL = "APP_ABS_PRNT_Collection";

	private static final String GET_SERVICE_CLASS = "getServiceClass";

	private static final String APP_FILE_HELP_COLL = "APP_FILE_HELP_Collection";

	private static final String CP_APP_AUTH_REP_COLL = "CP_APP_AUTH_REP_Collection";

	private static final String CP_APP_PGM_INDV_COLL = "CP_APP_PGM_INDV_Collection";

	private static final String APP_SBMS_COLL = "APP_SBMS_Collection";

	private static final String LOAD_SUMM_TEMP = "loadSummaryTemplate";

	private static final String STORE_DIS_SUMM = "storeDisabilitySummary";

	private static final String GET_DIS_SUM = "getDisabilitySummary";

	private static final String STORE_DIS_DET = "storeDisabilityDetails";

	private static final String LOAD_MILITARY_INFO_ERROR = "Error occured in HouseholdDemographicsServiceImpl.loadMilitaryInfoSummary()";

	private static final String DELETE_WHEN_HOMELESS_ERROR = "Error occured in HouseholdDemographicsServiceImpl.deleteWhenHomeless()";

	private static final String MILLISECONDS = " milliseconds";

	private static final String GET_DISABILITY_DETAILS_START = "HouseholdDemographicsService.getDisabilityDetails() - START";

	private static final String GET_PEOPLE_HANDLER_INFO_START = "HouseholdDemographicsServiceImpl.getPeopleHandlerInformation() - START";

	private static final String CP_APP_PGM_RQST_COLL = "CP_APP_PGM_RQST_Collection";

	private static final String CP_APP_HSHL_RLT_COLL = "CP_APP_HSHL_RLT_Collection";

	private static final String APP_INDV_IMG_COLL = "APP_INDV_IMG_Collection";

	@Override
	public void callBusinessLogic(String methodName, FwTransaction FwTxn) {

		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.GET_DISABILITY_SUMMARY:
			getDisabilitySummary(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_DISABILITY_SUMMARY:
			storeDisabilitySummary(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_CONTACT_INFO_AFB:
			storeContactInformationAFB(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_CONTACT_INFO_AFB:
			getContactInformation(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_REG_INFO:
			try {
				storeRegistrationInformation(FwTxn);
			} catch (Exception e) {
				FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
						"Error occured in Case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_REG_INFO",
						e);
			}

			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_REG_INFO:
			getRegistrationInformation(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.COMPLETE_APP_STORE_METHOD:
			storeHelpWithApplications(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.COMPLETE_APP_LOAD_METHOD:
			getHelpWithApplications(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_ADDRESS_INFO_AFB:
			storeMailingAddressDetail(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_DISABILITY_DETAILS:
			getDisabilityDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_DISABILITY_DETAILS:
			storeLangNameAndDisabilityDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_ABSENT_PARENT_DETAILS:
			getAbsentParentDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_NEXT_ABSENT_PARENT_DETAILS:
			storeAbsentParentDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.PROGRAM_INFO_LOAD_METHOD:
			getProgramInformation(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.PROGRAM_INFO_STORE_METHOD:
			storeProgramInformation(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.AUTHORIZED_REPRESENTATIVE_LOAD_METHOD:
			getAuthorizedRepresentativeDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.AUTHORIZED_REPRESENTATIVE_STORE_METHOD:
			storeAuthorizedRepresentativeDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_PERSONAL_INFO1:
			getHouseHoldMembersDetail(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_NEXT_PERSONAL_INFO1:
			try {
				storeHouseHoldMembersDetail(FwTxn);
			} catch (ParseException e1) {
				FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
						"Error occured in Case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_NEXT_PERSONAL_INFO1",
						e1);
			}
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_PERSONAL_INFO2:
			try {
				getImmigrationDetails(FwTxn);
			} catch (ParseException e) {
				FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
						"Error occured in Case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_PERSONAL_INFO2",
						e);
			}
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_NEXT_PERSONAL_INFO2:
			storeImmigrationDetail(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_GET_LEAVING_CA_DETAILS:
			getLeavingCADetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_STORE_LEAVING_CA_DETAILS:
			storeLeavingCADetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_GET_PEOPLE_HANDLER_INFO:
			getPeopleHandlerInformation(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_GET_INDV_CUSTOM_COLLECTION:
			getIndividualCustomCollection(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_GET_FOSTER_CARE_DETAILS:
			getFosterCareDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_STORE_FOSTER_CARE_DETAILS:
			storeFosterCareDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_DELETE_FOSTER_CARE_DETAILS:
			deleteFosterCareDetails(FwTxn);
			break;
		// Added as part of CSPM-2783
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_FOSTERCHILD_DATA:
			storeFosterChildData(FwTxn);
			break;

		// Added as part of CSPM-2783
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_GET_FOSTERCHILD_DATA:
			getFosterChildData(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.DELETE_FOSTER_CHILD_DATA:
			deleteFosterChildData(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_GET_PARENT_SITUATION_ABSENT_DETAILS:
			getParentSituationAbsentDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_STORE_PARENT_SITUATION_ABSENT_DETAILS:
			storeParentSituationAbsentDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_FACILITY_INFO:
			storeFacilityInformation(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.LOADFACILITYINFORMATION:
			loadFacilityInformation(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_GET_EXP_ASSISTANCE_INFO:
			getExpeditedAssistanceInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_EXP_ASSISTANCE_INFO:
			storeExpeditedAssistanceInfo(FwTxn);
			break;

		// Start: Added as a part of CSPM-2627
		case HouseHoldDemoGraphicsConstants.INDV_FOOD_SERVICES_PROGRAM_NEXT_METHOD:
			storeIndvFoodProgramDetails(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.INDV_FOOD_SERVICES_PROGRAM_LOAD_METHOD:
			getAllIndvFoodProgramDetails(FwTxn);
			break;
		// End: Added as a part of CSPM-2627
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_GET_ADDR_VALIDATION_INFORMATION:
			getAddressValidationInformation(FwTxn);
			break;

		// Added for Email Receipt Service - CSPM-2083
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_EMAIL_RECEIPT_INFO:
			getEmailReceiptDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_AUTH_REP_DET:
			storeAuthRepDetails(FwTxn);
			break;
		// CSPM-2161-Additional County Programs
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_ADDITIONAL_COUNTY_PROGRAMS:
			storeAdditionalCountyProgramDetails(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_ADDITIONAL_COUNTY_PROGRAMS:
			loadAdditionalCountyProgramDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.SAVE_MISSING_INFO:
			saveMissingInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_GET_PARENT_SITUATION_PERSONALINFORMATION_DETAILS:
			getParentSituationDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.REMOVE_LEAVE_CA_DET:
			removeLeavingCADetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.REMOVE_DIS_SUM:
			removeDisabilitySummary(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_STORE_PARENT_SITUATION_DETAILS:
			storeParentSituationDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_STORE_OTHERREVIEW_APPLICATION_SUMMARY:
			storeOtherReviewAppSummary(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_LOAD_OTHERREVIEW_APPLICATION_SUMMARY:
			loadOtherReviewAppSummary(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_LOAD_MILITARY_INFO_SUMMARY:
			loadMilitaryInfoSummary(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_SAVE_MILITARY_INFO:
			saveMilitaryInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_REMOVE_MILITARY_INFO:
			removeMilitaryInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.DELETE_FOOD_PROGRAM_DETAILS:
			deleteFoodProgramDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.GET_AFB_INDV_DET:
			getAFBIndividualDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_MOVED_IN_DATE:
			saveMovedInDate(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.STORE_CHILD_CAREDET:

			storeChildCareDetails(FwTxn);
			break;
		case "getIndvListServiceChaining":
			getIndvListServiceChaining(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.SAVE_ESIGN_INFO:
			storeSigningYourApplication(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.LOAD_SIGNING_INFO:
			loadSigningYourApplication(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.PERSIST_INTERVIEW_PREF:
			persistInterviewPref(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.FETCH_CASE_APPLICATIONS_DETAILS:
			fetchCaseApplicationsDetails(FwTxn);
			break;

		// CSPM-8493
		case HouseHoldDemoGraphicsConstants.LOAD_SUMMARY_TEMPLATE:
			loadSummaryTemplate(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.SEND_EMAIL_TEXT_TO_API:
			senEmailOrTextMessageToAPI(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_PROGRAM_SELECTION_MEMBER:
			storeProgramSelectionMember(FwTxn);
			break;
		// CSPM-11321
		case HouseHoldDemoGraphicsConstants.CREATE_QUEUE_TO_PUSH_MESSAGE_RDCW:
			try {
			pushMessageForRedetCWToInvokeSAWS2PLUS(FwTxn);
			} catch (ParseException e) {
				FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
						"Error occured in Case HouseHoldDemoGraphicsConstants.CREATE_QUEUE_TO_PUSH_MESSAGE_RDCW",
						e);				
			}
			break;

		// CSPM-12779
		case HouseHoldDemoGraphicsConstants.GET_APP_HISTORY:
			loadAppDetails(FwTxn);
			break;
		// CSPM-11601
		case HouseHoldDemoGraphicsConstants.REMOVE_CONTACT_INFO:
			removeContactInfoSummary(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.GET_CONTACT_INFO:
			getContactInformationActiveIndv(FwTxn);

			break;

		// CSPM-12263
		case HouseHoldDemoGraphicsConstants.HOUSEHOLD_DETAILS_DCF:
			storeHouseholdDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.LOAD_HOUSEHOLD_DETAILS_DCF:
			loadDCFHouseholdDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.GET_DISASTER_SUMMARY:
			getDisasterSummary(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.UPDATE_CF37MAILING_ADDRESS:
			updateCF37MailingAddress(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.UPDATE_CF37_CONTACT_INFO:
			updateContactInformationCF37(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_CONTACT_DETAILS_AFB:
			storeContactDetailsAFB(FwTxn);
			break;
		// BCUAT-838
		case HouseHoldDemoGraphicsConstants.ANAID_PAGE:
			storeANAIDPage(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.LOAD_INCARCERATED_INFO:
			loadIncarceratedInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.SAVE_INCARCERATED_INTO:
			saveIncarceratedInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.SAVE_DECEASED_INFO:
			saveDeceasedInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.DELETE_INCARCERATED_INFO:
			removeIncarceratedInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_IMMIGRATION_INFO:
			storeImmigrationInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.LOAD_IMMIGRATION_INFO:
			loadImmigrationInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.REMOVE_IMMIGRATION_INFO:
			removeImmigrationInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_MEDICAL_OR_MEDICARE_INFO:
			storeMedicalOrMeicareInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.GET_MEDICAL_OR_MEDICARE_INFO:
			getMedicalOrMeicareInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.REMOVE_MEDICAL_OR_MEDICARE_INFO:
			removeMedicalOrMeicareInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.PERSIST_ADDRESS_CHANGED:
			persistAddressChangedInd(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.UPDATE_MEDICAL_OR_MEDICARE_INFO:
			updateMedicalOrMeicareInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.LOADINCARCERATEDDETAILS:
			loadIncarceratedDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.UPDATE_DT_FOR_APP:
			updateUpdateDateForApp(FwTxn);
			break;
//			CSPM-30573
		case HouseHoldDemoGraphicsConstants.APDEL_PAGE:
			deleteAPDELPage(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.GET_APP_SUMMARY:
	            getApplicationSummaryData(FwTxn);
	            break;
		case HouseHoldDemoGraphicsConstants.DELETE_WHEN_HOMELESS:
			deleteWhenHomeless(FwTxn);
			break;
        case HouseHoldDemoGraphicsConstants.APPDETAILS_APPNUM:
        	getAppStatusByAppNum(FwTxn);
            break;
		default:
			break;
		}
	}

	// Start CSPM-6364
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadMilitaryInfoSummary(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.loadMilitaryInfoSummary() - START", fwTxn);
		Map pageCollection = fwTxn.getPageCollection();
		try {
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());

			APP_INDV_Cargo[] appIndvCargoaArray = cpAppIndvRepository.loadIndvDataByIndvIds(Integer.parseInt(appNumber), indvIdList);
			List<APP_INDV_Cargo> appIndvCargos = Arrays.asList(appIndvCargoaArray);

			/*
			 * CSPM-15032 (fetching pageId from FWTransaction).
			 */
			String pageId = fwTxn.getCurrentActionDetails().getPageId();

			/*
			 * CSPM-15032 (If PageId as MCIFS, load Income Fluctuation summary details..
			 * data).
			 */
			if (HouseHoldDemoGraphicsConstants.PAGEID_MCIFS.equals(pageId)) {
				List<APP_INDV_Cargo> incomeFlucAppIndvCargos = filterIncomeFlucIndv(appIndvCargos);
				pageCollection.put(APP_INDV_COLL, incomeFlucAppIndvCargos);
				fwTxn.setPageCollection(pageCollection);
			} else {
				List<APP_INDV_Cargo> militaryAppIndvCargos = filterMilterIndv(appIndvCargos);
				pageCollection.put(APP_INDV_COLL, militaryAppIndvCargos);
				fwTxn.setPageCollection(pageCollection);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, LOAD_MILITARY_INFO_ERROR, fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadMilitaryInfoSummary",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.loadMilitaryInfoSummary() - END", fwTxn);
	}
	
	private void loadIncarceratedDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.loadIncarceratedDetails() - Start");
		try {
			APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();

			APP_INDV_Cargo[] updatedAppIndvArr = cpAppIndvRepository.getByAppNum(Integer.parseInt(appNumber));
			if (Objects.nonNull(updatedAppIndvArr) && updatedAppIndvArr.length > 0) {
				for (APP_INDV_Cargo existingAppIndvCargo : Arrays.asList(updatedAppIndvArr)) {
					String calsawsObject = existingAppIndvCargo.getCalsawsObject();
					if (Objects.nonNull(calsawsObject)) {
						CaseIndividualDetails caseIndividual = new ObjectMapper().readValue(calsawsObject,
								CaseIndividualDetails.class);
						if (Objects.nonNull(caseIndividual.getIncarceratedDetail())
								&& caseIndividual.getIncarceratedDetail().isIncarceratedInd()) {
							appIndvCollection.add(existingAppIndvCargo);
						}
					}
				}
				pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
			}
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadIncarceratedDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.loadIncarceratedDetails() - END");

	}


	private List<APP_INDV_Cargo> filterIncomeFlucIndv(List<APP_INDV_Cargo> appIndvCargos) {
		List<APP_INDV_Cargo> incomeFlucAppIndvCargos = new ArrayList<>();

		for (APP_INDV_Cargo appIndvCargo : appIndvCargos) {
			if (appIndvCargo.getAnticipatedAmt() != null) {
				incomeFlucAppIndvCargos.add(appIndvCargo);
			}
		}
		return incomeFlucAppIndvCargos;
	}

	private List<APP_INDV_Cargo> filterMilterIndv(List<APP_INDV_Cargo> appIndvCargos) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.filterMilterIndv() - START");
		List<APP_INDV_Cargo> militaryAppIndvCargos = new ArrayList<APP_INDV_Cargo>();
		for (APP_INDV_Cargo appIndvCargo : appIndvCargos) {
			if (appIndvCargo.getVet_act_duty_resp() != null || appIndvCargo.getVet_resp() != null
					|| appIndvCargo.getVet_dep_resp() != null) {
				militaryAppIndvCargos.add(appIndvCargo);
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsServiceImpl.filterMilterIndv() - END");
		return militaryAppIndvCargos;
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void saveMilitaryInfo(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.saveMilitaryInfo() - START",
				txnBean);
		try {
			final Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appNumber = txnBean.getUserDetails().getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			final APP_INDV_Collection appIndvCollection = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);
			APP_INDV_Cargo appIndvCargo = appIndvCollection.getCargo(0);
			APP_INDV_Cargo appIndvCargoext = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNumber),
					indv_seq_num);

			/*
			 * CSPM-15032 (fetching pageId from FWTransaction).
			 */
			String pageId = txnBean.getCurrentActionDetails().getPageId();

			/*
			 * CSPM-15032 (If PageId as MCIFS, load Income Fluctuation summary details..
			 * data).
			 */
			 //set update date
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			appIndvCargoext.setUpdate_dt(currentTimeStamp);
			if (HouseHoldDemoGraphicsConstants.PAGEID_MCIFI.equals(pageId)) {
				appIndvCargoext.setAnticipatedAmt(appIndvCargo.getAnticipatedAmt());
				appIndvCargoext.setIncomeFluctuationInd(appIndvCargo.getIncomeFluctuationInd());
				cpAppIndvRepository.save(appIndvCargoext);
			} else {
				appIndvCargoext.setVet_serv_from_dt(appIndvCargo.getVet_serv_from_dt());
				appIndvCargoext.setVet_serv_to_dt(appIndvCargo.getVet_serv_to_dt());
				appIndvCargoext.setVet_hon_discharge_ind(appIndvCargo.getVet_hon_discharge_ind());
				appIndvCargoext.setVet_act_duty_resp(appIndvCargo.getVet_act_duty_resp());
				appIndvCargoext.setVet_resp(appIndvCargo.getVet_resp());
				appIndvCargoext.setVet_dep_resp(appIndvCargo.getVet_dep_resp());
				// To DO update armed_forces_resp indicator in Profile Table
				cpAppIndvRepository.save(appIndvCargoext);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.saveMilitaryInfo()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "saveMilitaryInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.saveMilitaryInfo() - END",
				txnBean);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void removeMilitaryInfo(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.removeMilitaryInfo() - START",
				txnBean);
		try {
			final Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Integer individualSequence = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			APP_INDV_Cargo appIndvCargoext = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNumber),
					individualSequence);

			/*
			 * CSPM-15032 (fetching pageId from FWTransaction).
			 */
			String pageId = txnBean.getCurrentActionDetails().getPageId();

			/*
			 * CSPM-15032 (If PageId as MCIFS, load Income Fluctuation summary details..
			 * data).
			 */
			if (HouseHoldDemoGraphicsConstants.PAGEID_MCIFS.equals(pageId)) {
				appIndvCargoext.setAnticipatedAmt(null);
				appIndvCargoext.setIncomeFluctuationInd(null);
			} else {
				appIndvCargoext.setVet_serv_from_dt(null);
				appIndvCargoext.setVet_serv_to_dt(null);
				appIndvCargoext.setVet_hon_discharge_ind(null);
				appIndvCargoext.setVet_act_duty_resp(null);
				appIndvCargoext.setVet_resp(null);
				appIndvCargoext.setVet_dep_resp(null);
			}
			//set update date
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			appIndvCargoext.setUpdate_dt(currentTimeStamp);
			cpAppIndvRepository.save(appIndvCargoext);
			// To DO update armed_forces_resp indicator in Profile Table
			List<APP_INDV_Cargo> militaryAppIndvCargos = new ArrayList<>();
			pageCollection.put(APP_INDV_COLL, militaryAppIndvCargos);
			txnBean.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.removeMilitaryInfo()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "removeMilitaryInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.removeMilitaryInfo() - END",
				txnBean);

	}
	// End CSPM-6364

	/**
	 * Load Other Review and Submit Application summary
	 * 
	 * @param fwTxn
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadOtherReviewAppSummary(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.loadOtherReviewAppSummary() - START", fwTxn);
		Map<String, Object> pageCollection = null;
		try {
			final Map request = fwTxn.getRequest();
			pageCollection = fwTxn.getPageCollection();
			String appNumber = null;

			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			appNumber = fwTxn.getUserDetails().getAppNumber();

			CP_APP_RGST_Cargo contactCargo = contInfoBO.loadContactInformationforAppNum(appNumber,
					HouseHoldDemoGraphicsConstants.APP_IND_AFB, indv_seq_num);
			final CP_APP_RGST_Collection contactColl = new CP_APP_RGST_Collection();

			if (contactCargo == null) {
				contactCargo = new CP_APP_RGST_Cargo();
				contactCargo.setApp_num(appNumber);
				contactCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
			}
			contactColl.addCargo(contactCargo);
			pageCollection.put(CP_APP_RGST_COLL, contactColl);

			APP_INDV_Collection indvColl = contInfoBO.loadIndvdtl(appNumber, indv_seq_num);
			pageCollection.put(APP_INDV_COLL, indvColl);

			fwTxn.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.loadOtherReviewAppSummary()", fwTxn);
			Map<String, FwMessageList> request = new HashMap<String, FwMessageList>();
			/*
			 * author : swabehera@deloitte.com Method ComputeExceptionMsgBasedOnCode will
			 * accept the exception code and fetch exception serverity and description like
			 * code and exception message
			 * 
			 * As of now set the error code = 100, for specific error message return in page
			 * response Also, only in methods where flow needs to continue without throwing
			 * exception, this error code and message has to be written. i.e.,
			 * handleException method last parameter set to false
			 */
			String errorCodeSetBasedOnCondn = "100";
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadOtherReviewAppSummary",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		} finally {
			fwTxn.setPageCollection(pageCollection);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.loadOtherReviewAppSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	@SuppressWarnings("squid:S3776")
	private void saveMovedInDate(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.saveMovedInDate() - START",
				txnBean);
		try {
			final Map pageCollection = txnBean.getPageCollection();
			String mode = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.MODE);
			UserDetails userDetails = txnBean.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			final APP_INDV_Collection appIndvCollection = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);			
			APP_INDV_Cargo appIndvCargo = appIndvCollection.getCargo(0);
			APP_INDV_Cargo appIndvCargoToSave = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNumber),
					indv_seq_num);
			appIndvCargoToSave.setMoved_in_dt(appIndvCargo.getMoved_in_dt());
			appIndvCargoToSave.setMove_in_ind(appIndvCargo.getMove_in_ind());
			appIndvCargoToSave.setMrtl_stat_cd(appIndvCargo.getMrtl_stat_cd());

            //set update date
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			appIndvCargoToSave.setUpdate_dt(currentTimeStamp);
			cpAppIndvRepository.save(appIndvCargoToSave);
			if(null != mode && mode.equals(HouseHoldDemoGraphicsConstants.FORM_TYPE_RAC)) {
				final CP_APP_RGST_Collection appRgstCollection = (CP_APP_RGST_Collection) pageCollection.get(CP_APP_RGST_COLL);
				if(null != appRgstCollection && !appRgstCollection.isEmpty()) {
				for(CP_APP_RGST_Cargo appRgstCargo : appRgstCollection.getResults()) {
				CP_APP_RGST_Cargo exisitingAppRgstCargo = cp_app_rgst_repo.getCpAppRgstDetails(Integer.parseInt(appNumber),indv_seq_num);
				if(null != exisitingAppRgstCargo) {
					exisitingAppRgstCargo.setHshl_zip_adr((null != appRgstCargo.getHshl_zip_adr() && !appRgstCargo.getHshl_zip_adr().isEmpty()) ? appRgstCargo.getHshl_zip_adr() : exisitingAppRgstCargo.getHshl_zip_adr());
					exisitingAppRgstCargo.setHshl_l1_adr((null != appRgstCargo.getHshl_l1_adr() && !appRgstCargo.getHshl_l1_adr().isEmpty()) ? appRgstCargo.getHshl_l1_adr() : exisitingAppRgstCargo.getHshl_l1_adr());
					exisitingAppRgstCargo.setHshl_l2_adr((null != appRgstCargo.getHshl_l2_adr() && !appRgstCargo.getHshl_l2_adr().isEmpty()) ? appRgstCargo.getHshl_l2_adr() : exisitingAppRgstCargo.getHshl_l2_adr());
					exisitingAppRgstCargo.setHshl_sta_adr((null != appRgstCargo.getHshl_sta_adr() && !appRgstCargo.getHshl_sta_adr().isEmpty()) ? appRgstCargo.getHshl_sta_adr() : exisitingAppRgstCargo.getHshl_sta_adr());
					exisitingAppRgstCargo.setHshl_city_adr((null != appRgstCargo.getHshl_city_adr() && !appRgstCargo.getHshl_city_adr().isEmpty()) ? appRgstCargo.getHshl_city_adr() : exisitingAppRgstCargo.getHshl_city_adr());
					exisitingAppRgstCargo.setHshl_cell_phn_num((null != appRgstCargo.getHshl_cell_phn_num() && !appRgstCargo.getHshl_cell_phn_num().isEmpty()) ? appRgstCargo.getHshl_cell_phn_num() : exisitingAppRgstCargo.getHshl_cell_phn_num());
					exisitingAppRgstCargo.setHshl_email_adr((null != appRgstCargo.getHshl_email_adr() && !appRgstCargo.getHshl_email_adr().isEmpty()) ? appRgstCargo.getHshl_email_adr() : exisitingAppRgstCargo.getHshl_email_adr());
					exisitingAppRgstCargo.setHshl_home_phn_num((null != appRgstCargo.getHshl_home_phn_num() && !appRgstCargo.getHshl_home_phn_num().isEmpty()) ? appRgstCargo.getHshl_home_phn_num() : exisitingAppRgstCargo.getHshl_home_phn_num());
					exisitingAppRgstCargo.setHshl_work_phn_num((null != appRgstCargo.getHshl_work_phn_num() && !appRgstCargo.getHshl_work_phn_num().isEmpty()) ? appRgstCargo.getHshl_work_phn_num() : exisitingAppRgstCargo.getHshl_work_phn_num());
					exisitingAppRgstCargo.setAlt_l1_adr((null != appRgstCargo.getAlt_l1_adr() && !appRgstCargo.getAlt_l1_adr().isEmpty()) ? appRgstCargo.getAlt_l1_adr() : exisitingAppRgstCargo.getAlt_l1_adr());
					exisitingAppRgstCargo.setAlt_l2_adr((null != appRgstCargo.getAlt_l2_adr() && !appRgstCargo.getAlt_l2_adr().isEmpty()) ? appRgstCargo.getAlt_l2_adr() : exisitingAppRgstCargo.getAlt_l2_adr());
					exisitingAppRgstCargo.setAlt_city_adr((null != appRgstCargo.getAlt_city_adr() && !appRgstCargo.getAlt_city_adr().isEmpty()) ? appRgstCargo.getAlt_city_adr() : exisitingAppRgstCargo.getAlt_city_adr());
					exisitingAppRgstCargo.setAlt_sta_adr((null != appRgstCargo.getAlt_sta_adr() && !appRgstCargo.getAlt_sta_adr().isEmpty()) ? appRgstCargo.getAlt_sta_adr() : exisitingAppRgstCargo.getAlt_sta_adr());
					exisitingAppRgstCargo.setAlt_zip_adr((null != appRgstCargo.getAlt_zip_adr() && !appRgstCargo.getAlt_zip_adr().isEmpty()) ? appRgstCargo.getAlt_zip_adr() : exisitingAppRgstCargo.getAlt_zip_adr());
					cp_app_rgst_repo.save(exisitingAppRgstCargo);
				}else {
					appRgstCargo.setApp_num(appNumber);
					appRgstCargo.setIndv_seq_num(indv_seq_num);
					appRgstCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);				
					cp_app_rgst_repo.save(appRgstCargo);
				}
				
				}
			}
			}
			
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.saveMovedInDate()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "saveMovedInDate",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.saveMovedInDate() - END",
				txnBean);
	}

	/**
	 * Store Other Review and submit application summary
	 * 
	 * @param fwTxn
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeOtherReviewAppSummary(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeOtherReviewAppSummary() - START", fwTxn);
		try {

			final Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();

			String appNumber = (String) userDetails.getAppNumber();
			String firstName = (String) userDetails.getFirstName();
			String lastName = (String) userDetails.getLastName();
			String srcAppIndv = HouseHoldDemoGraphicsConstants.APP_IND_AFB;

			Integer indv_seq_num = 0;
			if (null != (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence())
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indv_seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}

			CP_APP_RGST_Collection cpAppRgstCollection = (CP_APP_RGST_Collection) pageCollection.get(CP_APP_RGST_COLL);

			// Store Person informationRh
			if (Objects.nonNull(fwTxn.getPageCollection())) {
				APP_INDV_Collection appIndvCollection = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);
				/**
				 * APP Indv Collection
				 */
				if (Objects.nonNull(appIndvCollection)) {
					for (APP_INDV_Cargo cargo : appIndvCollection.getResults()) {
						cargo.setApp_num(appNumber);
						cargo.setSrc_app_ind(srcAppIndv);
						cargo.setFst_nam(firstName);
						cargo.setLast_nam(lastName);
						peopleHandler.updateIndividual(cargo);
					}
				}
				/**
				 * Contact Information
				 */
				validateAppIndvColl(appNumber, indv_seq_num, cpAppRgstCollection);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeOtherReviewAppSummary()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeOtherReviewAppSummary",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeOtherReviewAppSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	private void validateAppIndvColl(String appNumber, Integer indv_seq_num,
			CP_APP_RGST_Collection cpAppRgstCollection) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.validateAppIndvColl() - START");
		try {
			if (Objects.nonNull(cpAppRgstCollection) && ArrayUtils.isNotEmpty(cpAppRgstCollection.getResults())) {
				for (CP_APP_RGST_Cargo contactCargo : cpAppRgstCollection.getResults()) {
					contactCargo.setApp_num(appNumber);
					contactCargo.setIndv_seq_num(indv_seq_num);
					contactCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
					validateAppIndvAddr(contactCargo);
					if (Objects.nonNull(contactCargo.getHshl_home_phn_num())) {
						String phnNum = contactCargo.getHshl_home_phn_num();
						phnNum.replaceAll(" ", "").replaceAll("\\(", "").replaceAll("\\)", "").replaceAll("\\-", "");
						contactCargo.setHshl_home_phn_num(phnNum);
					}
					contInfoBO.storeContactInformation(contactCargo);
				}
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.validateAppIndvColl()");
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.validateAppIndvColl() - START");
	}

	private void validateAppIndvAddr(CP_APP_RGST_Cargo contactCargo) {
		if (contactCargo.getHshl_city_adr() == null)
			contactCargo.setHshl_city_adr(FwConstants.SPACE);
		if (contactCargo.getHshl_sta_adr() == null)
			contactCargo.setHshl_sta_adr(FwConstants.SPACE);
		if ("email".equalsIgnoreCase(contactCargo.getPref_cont_method_cd())) {
			contactCargo.setPref_cont_method_cd("eml");
		} else if ("usmail".equalsIgnoreCase(contactCargo.getPref_cont_method_cd())) {
			contactCargo.setPref_cont_method_cd("usm");
		}
	}

	/*
	 * Created as part of CSP-2161 -For loading AdditionalCountyPrograms
	 */
	@Transactional
	public void loadAdditionalCountyProgramDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeAdditionalCountyProgramDetails() - START", fwTxn);
		try {

			final Map pageCollection = fwTxn.getPageCollection();
			String appNumber = null;
			String countyNum = null;
			Integer flag = 0;
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			appNumber = fwTxn.getUserDetails().getAppNumber();
			APP_RGST_Collection existingRgstColl;
			APP_RGST_Collection newColl = new APP_RGST_Collection();
			APP_RGST_Cargo existingRgstCargo = new APP_RGST_Cargo();
			existingRgstColl = programInfoBo.loadCpAppRgstDetails(appNumber, indv_seq_num);
			if (null != existingRgstColl && !existingRgstColl.isEmpty()) {
				existingRgstCargo = existingRgstColl.getCargo(0);
			}

			if (null != existingRgstCargo.getCnty_num()) {
				countyNum = existingRgstCargo.getCnty_num();
				flag = programInfoBo.compareCountyProvidingMedical(countyNum);
				existingRgstCargo.setFlag(flag);
			}
			newColl.addCargo(existingRgstCargo);
			pageCollection.put(APP_RGST_COLL, newColl);
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeAdditionalCountyProgramDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(),
					"loadAdditionalCountyProgramDetails", fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeAdditionalCountyProgramDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	/*
	 * ADDED AS PART OF CSPM- 2161 -Additional County Programs
	 */
	@Transactional
	public void storeAdditionalCountyProgramDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeAdditionalCountyProgramDetails() - START", fwTxn);
		try {

			final Map pageCollection = fwTxn.getPageCollection();
			String appNumber = null;
			String pageId = null;
			appNumber = fwTxn.getUserDetails().getAppNumber();
			APP_PGM_RQST_Collection existingPgmRqstColl;
			APP_PGM_RQST_Collection updatedCollection = new APP_PGM_RQST_Collection();
			APP_PGM_RQST_Cargo existingPgmRqstCargo = new APP_PGM_RQST_Cargo();
			APP_PGM_RQST_Collection pgmRqstCollection = null;
			APP_PGM_RQST_Cargo pgmRqstcargo = new APP_PGM_RQST_Cargo();
			if (Objects.nonNull(pageCollection.get(APP_PGM_RQST_COLL))) {
				pgmRqstCollection = (APP_PGM_RQST_Collection) pageCollection.get(APP_PGM_RQST_COLL);

				pgmRqstcargo = pgmRqstCollection.getCargo(0);
			}

			// DB call to fetch existing cargo
			existingPgmRqstColl = programInfoBo.loadProgramRqstColl(appNumber);
			if (null != existingPgmRqstColl && !existingPgmRqstColl.isEmpty()) {

				existingPgmRqstCargo = existingPgmRqstColl.getCargo(0);
			}
			existingPgmRqstCargo.setApp_num(appNumber);
			existingPgmRqstCargo.setCapi_request_ind(pgmRqstcargo.getCapi_request_ind());
			// Data will be present only for applicable countys
			if (Objects.nonNull(pgmRqstcargo.getCounty_med_ind())) {
				existingPgmRqstCargo.setCounty_med_ind(pgmRqstcargo.getCounty_med_ind());
			}
			//set update date 
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			existingPgmRqstCargo.setUpdate_dt(currentTimeStamp);
			updatedCollection.addCargo(existingPgmRqstCargo);
			if (!ArrayUtils.isEmpty(updatedCollection.getResults())) {
				programInfoBo.saveAdditionalCountyDetails(updatedCollection);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeAdditionalCountyProgramDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(),
					"storeAdditionalCountyProgramDetails", fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeAdditionalCountyProgramDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	// Start: Added as a part of CSPM-2627
	@Transactional
	public void storeIndvFoodProgramDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeIndvFoodProgramDetails() - Start", txnBean);
		try {
			final Map pageCollection = txnBean.getPageCollection();
			PageActionDetails currentActionDetails = txnBean.getCurrentActionDetails();
			UserDetails userDetails = txnBean.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			final APP_INDV_Collection appIndvCollection = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);
			APP_INDV_Cargo appIndvCargo = appIndvCollection.getCargo(0);
			Integer individualSequence = Integer
					.parseInt(currentActionDetails.getIndividualCategorySequenceDetails().getIndividualSequence());
			APP_INDV_Cargo appIndvCargoext = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNumber),
					individualSequence);
			appIndvCargoext.setOther_food_program_name(appIndvCargo.getOther_food_program_name());
			appIndvCargoext.setIs_food_program("Y");
			//set update date
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			appIndvCargoext.setUpdate_dt(currentTimeStamp);
			cpAppIndvRepository.save(appIndvCargoext);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeIndvFoodProgramDetails()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeIndvFoodProgramDetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeIndvFoodProgramDetails() - END", txnBean);
	}

	@Transactional
	public void getAllIndvFoodProgramDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getAllIndvFoodProgramDetails() - START", fwTxn);
		Map pageCollection = fwTxn.getPageCollection();
		try {

			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			List<APP_INDV_Cargo> appIndvCargos = null;
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			if (indvIds != null) {
				List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());

				appIndvCargos = cpAppIndvRepository.getAllIndvFoodProgramDetails(Integer.parseInt(appNumber), indvIdList);
			}
			pageCollection.put(APP_INDV_COLL, appIndvCargos);
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getAllIndvFoodProgramDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getAllIndvFoodProgramDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getAllIndvFoodProgramDetails() - END", fwTxn);

	}

	// End: Added as a part of CSPM-2627
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadFacilityInformation(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "BenefitsService.getSchoolEnrollment() - START", fwTxn);
		try {

			Map pageCollection;

			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			pageCollection = new HashMap();

			CP_APP_IN_SHLTC_Collection appInShltcColl = new CP_APP_IN_SHLTC_Collection();

			CP_APP_IN_SHLTC_Collection newColl = new CP_APP_IN_SHLTC_Collection();
			CP_APP_IN_SHLTC_Cargo cargoSes = new CP_APP_IN_SHLTC_Cargo();
			int size = 0;
			size = appInShltcColl.size();
			if (size > 0) {
				// get last cargo from session
				cargoSes = appInShltcColl.getCargo(size - 1);
			}
			newColl.addCargo(cargoSes);

			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_IN_SHLTC_COLL, appInShltcColl);

			filterFacilitySummary(fwTxn, pageCollection);
			pageCollection.put(HouseHoldDemoGraphicsConstants.STORED_APP_IN_SHLTC_COLL, appInShltcColl);

			pageCollection.put(AppConstants.INDV_SEQUENCE_NUMBERS, indv_seq_num);
			pageCollection.put(AppConstants.CURRENT_INDIV_SEQ_NUM, indv_seq_num);
			fwTxn.setPageCollection(pageCollection);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"BenefitsService.getSchoolEnrollment() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
					fwTxn);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getSchoolEnrollment()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadFacilityInformation",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

	}

	private void filterFacilitySummary(FwTransaction fwTxn, Map pageCollection) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.filterFacilitySummary() - START", fwTxn);
		if (Objects.nonNull(fwTxn) && Objects.nonNull(fwTxn.getCurrentActionDetails())
				&& Objects.nonNull(fwTxn.getCurrentActionDetails().getPageId())
				&& fwTxn.getCurrentActionDetails().getPageId().equals(HouseHoldDemoGraphicsConstants.ABFIN)) {

			APP_INDV_Collection indvColl = new APP_INDV_Collection();

			CP_APP_IN_SHLTC_Collection facilityInfoDtls = new CP_APP_IN_SHLTC_Collection();

			for (int i = 0; i < facilityInfoDtls.size(); i++) {
				for (int j = 0; j < indvColl.size(); j++) {
					CP_APP_IN_SHLTC_Cargo facilityCargo = (CP_APP_IN_SHLTC_Cargo) facilityInfoDtls.get(i);
					APP_INDV_Cargo indvCustomCargo = (APP_INDV_Cargo) indvColl.get(j);
					if (facilityCargo.getIndv_seq_num().equals(indvCustomCargo.getIndv_seq_num())) {

						facilityCargo.setLastname(indvCustomCargo.getLast_nam());
						facilityCargo.setFirstname(indvCustomCargo.getFst_nam());
						facilityCargo.setAge(calculateAge(indvCustomCargo.getBrth_dt().toString()));
					}
				}
			}

			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_IN_SHLTC_COLL, facilityInfoDtls);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDemographicsServiceImpl.filterFacilitySummary() - END", fwTxn);
		}
	}

	public static Integer calculateAge(String birthDate) {
		Integer age = 0;
		LocalDate localBirthDate = LocalDate.parse(birthDate);
		age = Period.between(localBirthDate, LocalDate.now()).getYears();
		return age;
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeFacilityInformation(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "BenefitsService.storeSchoolEnrollment() - START", fwTxn);
		try {

			Map pageCollection = fwTxn.getPageCollection();

			String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seq_num = 0;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			CP_APP_IN_SHLTC_Collection appInShltcColl = (CP_APP_IN_SHLTC_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_SHLTC_COLL);

			CP_APP_IN_SHLTC_Cargo appInShltcCargo;

			if (appInShltcColl != null && !appInShltcColl.isEmpty() && appInShltcColl.size() > 0) {

				appInShltcCargo = appInShltcColl.getCargo(0);

				appInShltcCargo.setApp_num(appNum);
				appInShltcCargo.setIndv_seq_num(indv_seq_num);
				CP_APP_IN_SHLTC_Collection facilityInfoDtls = new CP_APP_IN_SHLTC_Collection();
				if (null != seq_num) {
					seq_num = 1;
					if (!facilityInfoDtls.isEmpty()) {
						int index = facilityInfoDtls.size() - 1;
						CP_APP_IN_SHLTC_Cargo lastCargo = (CP_APP_IN_SHLTC_Cargo) facilityInfoDtls.get(index);
						seq_num = lastCargo.getSeq_num() + 1;
					}
					if (seq_num != null) {
						fwTxn.getNextActionDetails().getIndividualCategorySequenceDetails()
								.setCategorySequence(seq_num.toString());
						appInShltcCargo.setSeq_num(seq_num);
					}
				}
				appInShltcCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"BenefitsService.storeSchoolEnrollment() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
					fwTxn);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeFacilityInformation()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeFacilityInformation",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
	}

	/* Start : CSPM-7108 */
	@SuppressWarnings("squid:S2259")
	@Transactional
	public void storeParentSituationAbsentDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeParentSituationAbsentDetails() - START", fwTxn);
		try {
			final UserDetails userDetails = fwTxn.getUserDetails();
			final Map pageCollection = fwTxn.getPageCollection();
			APP_ABS_PRNT_Collection appAbsColl = (APP_ABS_PRNT_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_ABS_PRNT_COLL);
			APP_ABS_PRNT_Cargo appAbsCargo;
			String app_num = userDetails.getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			appAbsCargo = appAbsColl.getCargo(0);
			absPrntRepository.deleteAbsPrntDetails(Integer.parseInt(app_num), indv_seq_num);
			APP_ABS_PRNT_Cargo parentOneCargo = prepareAbsPrntCargo(app_num);
			parentOneCargo.setIndv_seq_num(indv_seq_num);
			parentOneCargo.setApFstNam(appAbsCargo.getParentOneFirstName());
			parentOneCargo.setApLastNam(appAbsCargo.getParentOneLastName());
			parentOneCargo.setAp_absn_rsn_cd(appAbsCargo.getAp_absn_rsn_cd());
			parentOneCargo.setApSeqNum(Double.valueOf(1));
			absPrntRepository.save(parentOneCargo);

			if ((appAbsCargo.getParentTwoFirstName() != null && !appAbsCargo.getParentTwoFirstName().isEmpty()) || 
					(appAbsCargo.getParentTwoLastName() != null && !appAbsCargo.getParentTwoLastName().isEmpty())	) {
				APP_ABS_PRNT_Cargo parentTwoCargo = prepareAbsPrntCargo(app_num);
				parentTwoCargo.setIndv_seq_num(indv_seq_num);
				parentTwoCargo.setApFstNam(appAbsCargo.getParentTwoFirstName());
				parentTwoCargo.setApLastNam(appAbsCargo.getParentTwoLastName());
				parentTwoCargo.setAp_absn_rsn_cd(appAbsCargo.getAp_absn_rsn_cd());
				parentTwoCargo.setApSeqNum(Double.valueOf(2));
				absPrntRepository.save(parentTwoCargo);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, LOAD_MILITARY_INFO_ERROR, fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(),
					"storeParentSituationAbsentDetails", fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeParentSituationAbsentDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	private APP_ABS_PRNT_Cargo prepareAbsPrntCargo(String app_num) {
		APP_ABS_PRNT_Cargo appAbsCargo = new APP_ABS_PRNT_Cargo();
		appAbsCargo.setAppNum(app_num);
		appAbsCargo.setRec_cplt_ind(Double.valueOf(FwConstants.ONE));
		if (null == appAbsCargo.getCaseGdcsClmSw()) {
			appAbsCargo.setCaseGdcsClmSw(FwConstants.SPACE);
		}
		if ((null == appAbsCargo.getApSexInd()) || AppConstants.NULL_STRING.equals(appAbsCargo.getApSexInd()) || appAbsCargo.getApSexInd().isEmpty()) {
			appAbsCargo.setApSexInd(AppConstants.SEX_IND_UNKNOWN);
		}
		if ((null == appAbsCargo.getSrcAppInd()) || AppConstants.NULL_STRING.equals(appAbsCargo.getApSexInd())) {
			appAbsCargo.setSrcAppInd("AB");
		}
		return appAbsCargo;
	}

	@Transactional
	public void storeParentSituationDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"New HouseholdDemographicsService.storeParentSituationDetails() - START", fwTxn);
		try {
			final UserDetails userDetails = fwTxn.getUserDetails();
			final Map pageCollection = fwTxn.getPageCollection();
			APP_ABS_PRNT_Collection appAbsColl = (APP_ABS_PRNT_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_ABS_PRNT_COLL);
			APP_ABS_PRNT_Cargo appAbsCargo;
			String app_num = userDetails.getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			appAbsCargo = appAbsColl.getCargo(0);
			APP_ABS_PRNT_Cargo parentOneCargo = prepareAbsPrntCargo(app_num);
			parentOneCargo.setIndv_seq_num(indv_seq_num);
			parentOneCargo.setAp_absn_rsn_cd(appAbsCargo.getAp_absn_rsn_cd());
			parentOneCargo.setApSeqNum(Double.valueOf(1));
			absPrntRepository.save(parentOneCargo);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeParentSituationDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeParentSituationDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeParentSituationDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	/* End : CSPM-7108 */
	@Transactional
	public void getParentSituationAbsentDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.getParentSituationAbsentDetails() - START", fwTxn);

		final UserDetails userDetails = fwTxn.getUserDetails();
		final Map pageCollection = fwTxn.getPageCollection();

		String pageId = null;
		String previousPageId = null;
		String appNumber = null;
		String indvSeqNumber = null;
		String seqNumber = null;
		String absInd = null;
		int currentRecordIndex = 0;

		IndivTypeSeqBean detailKeyBean = null;

		boolean detailKeyBeanFlag = false;
		try {
			appNumber = userDetails.getAppNumber();

			Map beforeColl = null;
			final Map request = fwTxn.getRequest();
			pageId = (String) request.get(FwConstants.CURRENT_PAGE_ID);

			beforeColl = fwTxn.getPageCollection();
			String appnum = userDetails.getAppNumber();

			APP_ABS_PRNT_Collection newcoll = new APP_ABS_PRNT_Collection();

			APP_ABS_PRNT_Collection existingappAbsColl = absentParentBo.loadParentSituationAbsentDetails(appnum);
			APP_ABS_PRNT_Cargo cargoSes = null;
			if (existingappAbsColl != null && !(existingappAbsColl.isEmpty()) && existingappAbsColl.size() > 0) {
				for (int i = 0; i < existingappAbsColl.size(); i++) {
					cargoSes = existingappAbsColl.getCargo(i);
					newcoll.addCargo(cargoSes);
				}
			} else {
				cargoSes = new APP_ABS_PRNT_Cargo();
				cargoSes.setAppNum(appnum);
				newcoll.addCargo(cargoSes);
			}

			pageCollection.put(APP_ABS_PRNT_COLL, newcoll);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getParentSituationAbsentDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getParentSituationAbsentDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"BenefitsEJBBean.getAbsentParentDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getFosterChildData(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.getFosterChildData() - START",
				fwTxn);
		try {
			APP_INDV_Cargo[] appIndvArrayFromDB = null;
			APP_INDV_Collection appIndvCollToRequest = null;
			String appNumber = null;
			UserDetails userDetails = fwTxn.getUserDetails();
			appNumber = userDetails.getAppNumber();
			final Map pageCollection = fwTxn.getPageCollection();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			// Fetching latest data from Database
			List<APP_INDV_Cargo> appIndvCargos = cpAppIndvRepository.getAllFosterChildDetails(Integer.parseInt(appNumber), indvIdList);
			if (null != appIndvCargos && !appIndvCargos.isEmpty()) {
				appIndvCollToRequest = new APP_INDV_Collection();
				for (APP_INDV_Cargo cargo : appIndvCargos) {
					if (StringUtils.isNotEmpty(cargo.getIs_foster_child()))
						appIndvCollToRequest.addCargo(cargo);
				}
				pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollToRequest);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDemographicsService.getFosterChildData() - END", fwTxn);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsService.getFosterChildData()", fwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "getFosterChildData",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.getFosterChildData() - END", fwTxn);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeFosterChildData(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeFosterChildData() - START", fwTxn);
		try {

			final Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();

			PageActionDetails currentActionDetails = null;
			String indvSeqNum = "0";

			// Fetching data from request
			currentActionDetails = (PageActionDetails) fwTxn.getCurrentActionDetails();
			if (Objects.nonNull(currentActionDetails)
					&& Objects.nonNull(currentActionDetails.getIndividualCategorySequenceDetails())) {
				indvSeqNum = currentActionDetails.getIndividualCategorySequenceDetails().getIndividualSequence();
			}

			persistFosterChildDetails(pageCollection, appNum, indvSeqNum);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsService.storeFosterChildData()", fwTxn);

			FwExceptionManager.handleException(e, this.getClass().getName(), "storeFosterChildData",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);

		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.storeFosterChildData() - END",
				fwTxn);
	}

	private void persistFosterChildDetails(Map pageCollection, String appNum, String indvSeqNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.persistFosterChildDetails() - START");
		APP_INDV_Collection appIndvCollFromDB = null;
		APP_INDV_Collection appIndvCollFromRequest = null;
		PageActionDetails currentActionDetails = null;

		appIndvCollFromRequest = (APP_INDV_Collection) pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
		if (null != appIndvCollFromRequest && !appIndvCollFromRequest.isEmpty()) {
			APP_INDV_Cargo[] appIndvArray = appIndvCollFromRequest.getResults();
			for (APP_INDV_Cargo cargo : appIndvArray) {
				appIndvCollFromDB = cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNum), Integer.parseInt(indvSeqNum));
				if (null != appIndvCollFromDB && !appIndvCollFromDB.isEmpty()) {
					APP_INDV_Cargo appIndvCargoFromDB = appIndvCollFromDB.getCargo(0);
					appIndvCargoFromDB.setFoster_court_ord_dep_ind(cargo.getFoster_court_ord_dep_ind());
					appIndvCargoFromDB.setFoster_incl_calfresh_ind(cargo.getFoster_incl_calfresh_ind());
					appIndvCargoFromDB.setIs_foster_child("Y");
					;
					//set update date
					Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
					appIndvCargoFromDB.setUpdate_dt(currentTimeStamp);
					cpAppIndvRepository.save(appIndvCargoFromDB);
				}
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.persistFosterChildDetails() - END");
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void persistInterviewPref(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getContactInformation() - START", fwTxn);

		try {
			final Map pageColl = fwTxn.getPageCollection();

			CP_APP_RGST_Cargo contactCargoFromDB = null;
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();
			Integer indvSeqNum = 0;
			String indvSeq = "0";
			PageActionDetails currentActionDetails = null;
			CP_APP_RGST_Collection contactColl = new CP_APP_RGST_Collection();

			currentActionDetails = fwTxn.getCurrentActionDetails();
			if (Objects.nonNull(currentActionDetails)
					&& Objects.nonNull(currentActionDetails.getIndividualCategorySequenceDetails()) && Objects.nonNull(
							currentActionDetails.getIndividualCategorySequenceDetails().getIndividualSequence())) {
				indvSeqNum = Integer
						.parseInt(currentActionDetails.getIndividualCategorySequenceDetails().getIndividualSequence());
				indvSeq = currentActionDetails.getIndividualCategorySequenceDetails().getIndividualSequence();
			}

			APP_INDV_Cargo indvDtl = cpAppIndvRepository.getPrimaryApplicantIndvDetails(Integer.parseInt(appNum));
			if (indvDtl != null && indvDtl.getIndv_seq_num() != null) {
				indvSeqNum = indvDtl.getIndv_seq_num();
			}

			if (pageColl.containsKey(CP_APP_RGST_COLL) && pageColl.get(CP_APP_RGST_COLL) != null) {
				contactColl = (CP_APP_RGST_Collection) pageColl.get(CP_APP_RGST_COLL);
			}

			contactCargoFromDB = saveInterviewPrefAndPhCollData(appNum, indvSeqNum, contactColl, indvSeq);

			contactColl.addCargo(contactCargoFromDB);
			pageColl.put(CP_APP_RGST_COLL, contactColl);

			fwTxn.setPageCollection(pageColl);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getContactInformation()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "persistInterviewPref",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.getContactInformation() - END",
				fwTxn);
	}

	private CP_APP_RGST_Cargo saveInterviewPrefAndPhCollData(final String appNum, Integer indvSeqNum,
			CP_APP_RGST_Collection contactColl, String indvSeq) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.saveInterviewPrefAndPhCollData() - START");
		CP_APP_RGST_Cargo contactCargoFromDB;
		String srcAppInd = AppConstants.AFB_SRC_APP_IND;

		contactCargoFromDB = contInfoBO.loadDataInerPerfforAppNumAndSrcAppInd(appNum, indvSeqNum, srcAppInd);

		if (Objects.isNull(contactCargoFromDB)) {
			contactCargoFromDB = new CP_APP_RGST_Cargo();
			contactCargoFromDB.setApp_num(appNum);
			contactCargoFromDB.setSrc_app_ind(srcAppInd);
			// Setting blank space because of not null contraint
			contactCargoFromDB.setHshl_city_adr("");
			contactCargoFromDB.setHshl_sta_adr("");
			contactCargoFromDB.setIndv_seq_num(Integer.parseInt(indvSeq));
		}
		if (null != contactColl && !contactColl.isEmpty()) {
			CP_APP_RGST_Cargo[] appRgstArray = contactColl.getResults();
			for (CP_APP_RGST_Cargo cargo : appRgstArray) {
				contactCargoFromDB.setPref_cntc_ind(cargo.getPref_cntc_ind());
				contactCargoFromDB.setOther_assistance_sw(cargo.getOther_assistance_sw());
				if (Objects.nonNull(cargo.getPref_cntc_ind()) && cargo.getPref_cntc_ind() == 1) {
					contactCargoFromDB.setMsg_phn_num(null);
				} else {
					contactCargoFromDB.setMsg_phn_num(cargo.getMsg_phn_num());
				}
				contInfoBO.storeContactInformation(contactCargoFromDB);
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.saveInterviewPrefAndPhCollData() - END");
		return contactCargoFromDB;
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeImmigrationDetail(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "PeopleInYourHomeService.storeImmigrationDetail() - START",
				fwTxn);

		try {
			final Map request = fwTxn.getRequest();
			final Map pageCollection = fwTxn.getPageCollection();
			FwMessageList validationInfo = new FwMessageList();

			List immigrationInfoList = null;

			APP_INDV_Collection appInImmColl = null;
			APP_INDV_Collection appIndvColl = null;
			APP_INDV_Cargo appInImmCargo = null;
			APP_INDV_Cargo appInIndvCargo = null;

			immigrationInfoList = (List) pageCollection.get("ImmigrationList");
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			int indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			boolean isBlindOrDisabled = false;

			APP_IN_PRFL_Collection appInPrflColl = cpAppInPrflRepository.findCollByAppIdnvNum(appNum, indv_seq_num);
			Integer i = 1;

			// fetch from db
			final Integer[] programKey = houseHoldBo.getProgKeyArray(appNum);

			boolean indvFMAFlag = false;
			boolean indvFSFlag = false;
			boolean indvTANFFlag = false;
			boolean indvCClag = false;

			if (appInPrflColl != null && !appInPrflColl.isEmpty()) {
				APP_IN_PRFL_Cargo prflCargo = appInPrflColl.getCargo(0);
				if (i == (int) prflCargo.getIndv_fma_rqst_ind())
					indvFMAFlag = true;
				if (i == (int) prflCargo.getIndv_fs_rqst_ind())
					indvFSFlag = true;
				if (i == (int) prflCargo.getIndv_tanf_rqst_ind())
					indvTANFFlag = true;
				if (i == (int) prflCargo.getIndv_cc_rqst_ind())
					indvCClag = true;
			}
			if (pageCollection.containsKey(APP_INDV_COLL)) {
				appInImmColl = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);
			}

			appIndvColl = houseHoldBo.loadAppIndvCollection(appNum);
			if ((appInImmColl != null) && !appInImmColl.isEmpty()) {
				appInImmCargo = appInImmColl.getCargo(0);
				appInImmCargo.setApp_num(appNum);
				appInImmCargo.setIndv_seq_num(indv_seq_num);
				appInImmCargo.setSrc_app_ind("AB");
				validationInfo = houseHoldBo.validateImmigrationDetails(appInImmColl, programKey, indvFMAFlag,
						indvFSFlag, indvTANFFlag, indvCClag);
				if ((validationInfo != null) && validationInfo.hasMessages()) {
					request.put(FwConstants.MESSAGE_LIST, validationInfo);
					pageCollection.put(APP_INDV_COLL, appInImmColl);
					pageCollection.put(AppConstants.INDV_SEQUENCE_NUMBERS, indv_seq_num);
					pageCollection.put(AppConstants.CURRENT_INDIV_SEQ_NUM, indv_seq_num);

					return;
				}

				if ((appInImmCargo.getBlnd_dabl_ind() == null)
						|| (appInImmCargo.getBlnd_dabl_ind().trim().length() == 0)
						|| FwConstants.ZERO.equalsIgnoreCase(appInImmCargo.getBlnd_dabl_ind())) {
					appInImmCargo.setBlnd_dabl_ind(FwConstants.NO);
				}

				if (FwConstants.YES.equals(appInImmCargo.getBlnd_dabl_ind())) {
					isBlindOrDisabled = true;
				}
				if ((appIndvColl != null) && !appIndvColl.isEmpty()) {
					appInIndvCargo = appIndvColl.getCargo(0);

					// completeness check
					if ((appInImmCargo.getUs_ctzn_sw() != null) && (appInImmCargo.getUs_ctzn_sw().trim().length() > 0)
							&& (appInIndvCargo.getSsn_num() != null)
							&& (appInIndvCargo.getSsn_num().trim().length() > 1)) {
						appInImmCargo.setRec_cplt_ind(1);
					} else {
						appInImmCargo.setRec_cplt_ind(0);
					}

					appInImmCargo.setFst_nam(appInIndvCargo.getFst_nam());
					appInImmCargo.setLast_nam(appInIndvCargo.getLast_nam());
					appInImmCargo.setSex_ind(appInIndvCargo.getSex_ind());
				}

				houseHoldBo.storeImmigrationDetail(appInImmCargo);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeImmigrationDetail()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeImmigrationDetail",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"PeopleInYourHomeService.storeImmigrationDetail() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getImmigrationDetails(FwTransaction fwTxn) throws ParseException {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "PeopleInYourHomeService.getImmigrationDetails() - START",
				fwTxn);

		try {
			final Map request = fwTxn.getRequest();
			Map pageCollection = fwTxn.getPageCollection();

			List immigrationInfoList = null;
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			pageCollection = new HashMap();
			immigrationInfoList = houseHoldBo.findAllPeople(peopleHandler);

			pageCollection.put("ImmigrationList", immigrationInfoList);

			APP_INDV_Collection appIndvColl = houseHoldBo.loadAppIndvCollection(appNum);

			if (appIndvColl == null) {
				appIndvColl = new APP_INDV_Collection();
				appIndvColl.addCargo(new APP_INDV_Cargo());
			}
			pageCollection.put(APP_INDV_COLL, appIndvColl);

			final INDIVIDUAL_Custom_Cargo indvCargo = peopleHandler.getIndividual(String.valueOf((indv_seq_num)));
			boolean isFemOver18 = false;
			if (indvCargo != null) {
				final String dob = indvCargo.getBrth_dt();
				// Converting String to Date
				SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date date = formatter.parse(dob);
				// Converting obtained Date object to LocalDate object
				Instant instant = date.toInstant();
				ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
				LocalDate givenDate = zone.toLocalDate();
				// Calculating the difference between given date to current date.
				Period period = Period.between(givenDate, LocalDate.now());
				// getting age
				final int age = period.getYears();
				final String sexInd = indvCargo.getSex_ind();
				if ((age > 18) && AppConstants.SEX_IND_FEMALE.equals(sexInd)) {
					isFemOver18 = true;
				}
			}

			Integer appPgmRqstCollArray[] = houseHoldBo.getProgKeyArray(appNum);
			pageCollection.put("pgmKey", appPgmRqstCollArray);

			pageCollection.put("FEM_OVER_18", isFemOver18);
			final INDIVIDUAL_Custom_Collection indvCustColl = new INDIVIDUAL_Custom_Collection();
			indvCustColl.addCargo(indvCargo);
			pageCollection.put(AppConstants.INDV_SEQUENCE_NUMBERS, indv_seq_num);
			pageCollection.put(AppConstants.CURRENT_INDIV_SEQ_NUM, indv_seq_num);

			APP_INDV_Collection indvColl = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);
			APP_INDV_Cargo indvCargoDB = (APP_INDV_Cargo) indvColl.get(0);
			pageCollection.put(AppConstants.WIC_CLINIC_INFO, houseHoldBo.loadWICClncInfo());
			pageCollection.put(AppConstants.WIC_CLNC_NAME, houseHoldBo.loadWICClncName(indvCargoDB.getWic_clnc_cd()));
			// WIC clinic details end
			fwTxn.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getImmigrationDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"PeopleInYourHomeService.getImmigrationDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeChildCareDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsServiceImpl.storeChildCareDetails() - START",
				fwTxn);
		try {
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Map pageCollection = fwTxn.getPageCollection();
			List<String> reqIndvIds = (List<String>) pageCollection.get("childCareArray");

			String description = null;
			String isChildCare = null;

			APP_INDV_Cargo[] dbCargoaArray = cpAppIndvRepository.getByAppNum(Integer.parseInt(appNumber));
			if (dbCargoaArray.length > 0) {
				for (APP_INDV_Cargo curCargo : dbCargoaArray) {
					peopleHandler.updateChildCareValue(appNumber, curCargo.getIndv_seq_num(),
							HouseHoldDemoGraphicsConstants.APP_IND_AFB, description, isChildCare);
				}
			}

			if (reqIndvIds.size() > 0) {
				for (String currentCargo : reqIndvIds) {
					String reqdescription = (String) pageCollection.get("oth_hhm_care_desc");
					isChildCare = "Y";
					if (StringUtils.isNotEmpty(reqdescription)) {
						description = reqdescription;
					}
					peopleHandler.updateChildCareValue(appNumber, Integer.parseInt(currentCargo),
							HouseHoldDemoGraphicsConstants.APP_IND_AFB, description, isChildCare);
				}
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeChildCareDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeChildCareDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsServiceImpl.storeChildCareDetails() - END",
				fwTxn);
	}

	/**
	 * Store Household member details
	 * 
	 * @Module - Your Information - Individual Info
	 * @Technology-Grouping : AFB- Individual Information 2
	 * @CalsAWS-Code-Changes -
	 *                       https://calsaws-portal-mobile-jira.atlassian.net/browse/CSPM-2255
	 * @param fwTxn
	 * @throws ParseException
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeHouseHoldMembersDetail(FwTransaction fwTxn) throws ParseException {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeHouseHoldMembersDetail() - STARGT", fwTxn);
		final Map request = fwTxn.getRequest();
		Map pageCollection = fwTxn.getPageCollection();
		UserDetails userDetails = fwTxn.getUserDetails();
		String appNumber = null;
		APP_INDV_Collection appIndvColl = null;
		APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
		APP_IN_PRFL_Collection appInPrflColl = null;
		APP_IN_PRFL_Cargo appInPrflCargo = new APP_IN_PRFL_Cargo();
		APP_IN_PRFL_Collection appInPrflSessionColl = null;
		APP_IN_PRFL_Cargo appInPrflSessionCargo = null;
		APP_INDV_Collection appIndvBeforeColl = null;
		APP_INDV_Cargo appIndvBeforeCargo = null;
		APP_IN_PRFL_Collection appInPrflBeforeColl = null;
		APP_IN_PRFL_Cargo appInPrflBeforeCargo = null;
		INDIVIDUAL_Custom_Collection indvCustColl = null;
		INDIVIDUAL_Custom_Cargo indvCustCargo = null;
		FwMessageList validateInfo = null;
		Integer indvSeqNumber = null;
		final String childOutofYourhome = null;
		int currentPageStatus = 0;
		CP_APP_HSHL_RLT_Collection appRelationColl = null;
		CP_APP_HSHL_RLT_Cargo appRelationCargo = null;
		String currentPageId = Objects.nonNull(fwTxn.getCurrentActionDetails())
				? fwTxn.getCurrentActionDetails().getPageId()
				: StringUtils.EMPTY;
		boolean checkPageId = currentPageId.equalsIgnoreCase("ABPDJ") || currentPageId.equalsIgnoreCase("ABBPL")
				|| currentPageId.equalsIgnoreCase("ABVAC") || currentPageId.equalsIgnoreCase("ABSCS");
		try {

			appNumber = userDetails.getAppNumber();
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence() != null) {

				indvSeqNumber = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			appIndvColl = (APP_INDV_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			appInPrflColl = (APP_IN_PRFL_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_IN_PRFL_COLLECTION);

			peopleHandler.loadPeopleHandler(appNumber);

			// Added for CSPM-2719 ends

			if ((appIndvColl != null) && (!appIndvColl.isEmpty())) {
				appIndvCargo = appIndvColl.getCargo(0);
			}

			boolean ccFlag = false;
			boolean snapFlag = false;
			boolean tanfFlag = false;
			boolean maFlag = false;
			boolean wicFlag = false;
			boolean eaFlag = false;
			boolean validatePOBFlag = false;
			boolean cCareFlag = false;
			boolean ccFlagOnly = false;

			final Integer[] programKeyArray = houseHoldBo.getProgKeyArray(appNumber);

			String reqWarningMsgs = "";
			if (null != request.get(FwConstants.WARNING_MSG_DETAILS)
					&& !request.get(FwConstants.WARNING_MSG_DETAILS).toString().isEmpty()) {
				if (request.get(FwConstants.WARNING_MSG_DETAILS) instanceof String) {
					reqWarningMsgs = (String) request.get(FwConstants.WARNING_MSG_DETAILS);
				}
			}

			if ((appIndvCargo.getChld_out_home_resp() != null)
					&& FwConstants.NO.equals(appIndvCargo.getChld_out_home_resp().trim())) {
				appIndvCargo.setAbsence_reason_cd(FwConstants.DEFAULT_DROPDOWN_SEL);
			}

			boolean isProgramSpecificLogic = false;
			// If block added for CSPM-2719
			if (Objects.nonNull(fwTxn) && Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getPageId())
					&& (!fwTxn.getCurrentActionDetails().getPageId().equals(HouseHoldDemoGraphicsConstants.ABMIS))) {

				// EDSP CP Starts: Atleast one pgrm should be selected for
				// individuals when selected at household level
				// now i am getting the app in profile session collection

				if (pageCollection.containsKey(HouseHoldDemoGraphicsConstants.APP_IN_PRFL_COLLECTION)) {
					appInPrflSessionColl = (APP_IN_PRFL_Collection) pageCollection
							.get(HouseHoldDemoGraphicsConstants.APP_IN_PRFL_COLLECTION);
				}

				final APP_IN_PRFL_Collection tempAppInPrflSessionColl = new APP_IN_PRFL_Collection();
				if ((appInPrflSessionColl != null) && (!appInPrflSessionColl.isEmpty())) {
					for (int i = 0; i < appInPrflSessionColl.size(); i++) {
						if ((appInPrflSessionColl.getCargo(i).getIndv_seq_num() != null)
								&& !(appInPrflSessionColl.getCargo(i).getIndv_seq_num().equals(indvSeqNumber))) {
							tempAppInPrflSessionColl.add(appInPrflSessionColl.get(i));
						}
					}

				}

				tempAppInPrflSessionColl.add(appInPrflCargo);
				if (null != appIndvCargo.getLooping_ind() && !appIndvCargo.getLooping_ind().isEmpty()
						&& AppConstants.NO.equals(appIndvCargo.getLooping_ind())) {
					if (tempAppInPrflSessionColl != null) {

						validateInfo = houseHoldBo.validateProgramsForIndividuals(tempAppInPrflSessionColl,
								programKeyArray);
					}
				}

				// EDSP CP ends: Atleast one pgrm should be selected for individuals
				// when selected at household level

				if ((validateInfo != null) && validateInfo.hasMessages()
						&& (null != validateInfo && !StringUtils.isNotEmpty(reqWarningMsgs)
								|| (validateInfo.getMessageListSize() != 1)
								|| !validateInfo.containsMessage(HouseHoldDemoGraphicsConstants.MSG_99001))) {

					appIndvBeforeCargo = cpAppIndvRepository.getCargoByAppNum(Integer.parseInt(appNumber));

					request.put(FwConstants.MESSAGE_LIST, validateInfo);
					pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvColl);
					pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_PRFL_COLLECTION, appInPrflColl);
					pageCollection.put(AppConstants.INDV_SEQUENCE_NUMBERS, indvSeqNumber);

					displayProgramSpecificDetails(appInPrflCargo, pageCollection);

					isProgramSpecificLogic = true;
					return;
				}
			}

			// for the null fields i am setting the default values
			// setting the default values for the individual information
			if ((appIndvColl != null) && (!appIndvColl.isEmpty())) {
				appIndvCargo.setApp_num(appNumber);
				appIndvCargo.setChld_trb_mbr_resp(FwConstants.SPACE);
				appIndvCargo.setTrb_mbr_resp(FwConstants.SPACE);

				appIndvCargo.setIndv_seq_num(indvSeqNumber);
				if (appIndvCargo.getAln_sponser_sw() == null) {
					appIndvCargo.setAln_sponser_sw(FwConstants.SPACE);
				}
				if (appIndvCargo.getIntn_res_resp() == null) {
					appIndvCargo.setIntn_res_resp(FwConstants.SPACE);
				}
				if (FwConstants.DEFAULT_DROPDOWN_SEL.equals(appIndvCargo.getLang_cd())) {
					appIndvCargo.setLang_cd(FwConstants.SPACE);
				}
				if (FwConstants.EMPTY_STRING.equals(appIndvCargo.getLang_oth_dsc())) {
					appIndvCargo.setLang_oth_dsc(FwConstants.SPACE);
				}
				if (FwConstants.EMPTY_STRING.equals(appIndvCargo.getInter_oth_dsc())) {
					appIndvCargo.setInter_oth_dsc(FwConstants.SPACE);
				}
				appIndvCargo.setBrth_dt(appIndvCargo.getBrth_dt());
				if (null == appIndvCargo.getLive_arng_typ()) {
					appIndvCargo.setLive_arng_typ(FwConstants.SPACE);
				}
				if (null == appIndvCargo.getMig_farm_wrkr_sw()) {
					appIndvCargo.setMig_farm_wrkr_sw(FwConstants.SPACE);
				}
				// VACMS start - marital status now on registration page: EDSP
				// CP: uncommented

				if ((null == appIndvCargo.getMrtl_stat_cd())
						|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appIndvCargo.getMrtl_stat_cd())) {
					appIndvCargo.setMrtl_stat_cd(FwConstants.SPACE);
				}

				// VACMS end - marital status now on registration page: EDSP CP:
				// uncommented

				// EDSP CP starts: Suffix

				if ((appIndvCargo.getSuffix_name() == null)
						|| FwConstants.HYPHEN_HYPHEN.equals(appIndvCargo.getSuffix_name())) {
					appIndvCargo.setSuffix_name(FwConstants.SPACE);
				}
				if (appIndvCargo.getChld_out_home_resp() == null) {
					appIndvCargo.setChld_out_home_resp(FwConstants.SPACE);
				}

				if (appIndvCargo.getPreg_resp() == null) {
					appIndvCargo.setPreg_resp(FwConstants.SPACE);
				}
				if (appIndvCargo.getPrim_prsn_sw() == null) {
					if (HouseHoldDemoGraphicsConstants.ONE == (indvSeqNumber)) {
						appIndvCargo.setPrim_prsn_sw(FwConstants.YES);
					} else {
						appIndvCargo.setPrim_prsn_sw(FwConstants.NO);
					}
				}
				if ((appIndvCargo.getMid_init() == null) || (appIndvCargo.getMid_init().length() == 0)) {
					appIndvCargo.setMid_init(FwConstants.SPACE);
				}
				/*
				 * VG SONAR Cleanup - 08/26/2015 Deleted 3,3,1,1 lines Commented Code in this
				 * block
				 */

				// EDSP CP: code commented
				if (appIndvCargo.getRes_va_sw() == null) {
					appIndvCargo.setRes_va_sw(FwConstants.SPACE);
				}
				if (appIndvCargo.getRlvn_ind() == null) {
					// Rlvn_ind beens set to 1 because Absent Parents and More
					// About Parents
					// screens have been deprecated. When enabled this should be
					// set to 0.
					appIndvCargo.setRlvn_ind(HouseHoldDemoGraphicsConstants.ONE);
				}
				// EDSP CP Starts: code commented
				if ((appIndvCargo.getSs_num_app_dt() == null)
						|| (appIndvCargo.getSs_num_app_dt().toString().trim().length() == 0)) {
					appIndvCargo.setSs_num_app_dt(HouseHoldDemoGraphicsConstants.HIGH_DATE);
				} else {
					appIndvCargo.setSs_num_app_dt(appIndvCargo.getSs_num_app_dt());
				}
				// EDSP CP ends: code commented

				if ((appIndvCargo.getSsn_num() == null) || (appIndvCargo.getSsn_num().trim().length() == 0)) {
					appIndvCargo.setSsn_num(FwConstants.ZERO);
					// EDSP CP Starts: code modified

					// EDSP CP ends: code modified
				}
				// This code is added to check for race and ethinicity
				if (appIndvCargo.getAi_ind() == null) {
					// VACMS start - changed to 0
					// VACMS end - changed to 0
					appIndvCargo.setAi_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getRace_oth_asian_ind() == null) {
					// VACMS start - changed to 0
					// VACMS end - changed to 0
					appIndvCargo.setRace_oth_asian_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getComm_asst_email_ind() == null) {
					appIndvCargo.setComm_asst_email_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getComm_asst_lg_print_ind() == null) {
					appIndvCargo.setComm_asst_lg_print_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getComm_asst_none_ind() == null) {
					appIndvCargo.setComm_asst_none_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getComm_asst_baille_ind() == null) {
					appIndvCargo.setComm_asst_baille_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getComm_asst_vedrel_ind() == null) {
					appIndvCargo.setComm_asst_vedrel_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getComm_asst_sl_interp_ind() == null) {
					appIndvCargo.setComm_asst_sl_interp_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getComm_asst_tty_ind() == null) {
					appIndvCargo.setComm_asst_tty_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getAsia_ind() == null) {
					appIndvCargo.setAsia_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getBlk_ind() == null) {
					appIndvCargo.setBlk_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getPac_isl_ind() == null) {
					appIndvCargo.setPac_isl_ind(FwConstants.ZERO);
				}
				if (appIndvCargo.getWht_ind() == null) {
					appIndvCargo.setWht_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getNon_hspc_ind() == null) {
					appIndvCargo.setNon_hspc_ind(FwConstants.SPACE);
				}
				if (appIndvCargo.getReq_interp_ind() == null) {
					appIndvCargo.setReq_interp_ind(FwConstants.SPACE);
				}

				if (appIndvCargo.getHspc_ind() == null) {
					appIndvCargo.setHspc_ind(FwConstants.ZERO);
				}

				if ((appIndvCargo.getLiving_arrangement_cd() == null)
						|| HouseHoldDemoGraphicsConstants.MSG_000.equals(appIndvCargo.getLiving_arrangement_cd())) {
					appIndvCargo.setLiving_arrangement_cd(FwConstants.SPACE);
				}

				if ((appIndvCargo.getIf_out_arrangement() == null)
						|| HouseHoldDemoGraphicsConstants.MSG_000.equals(appIndvCargo.getIf_out_arrangement())) {
					appIndvCargo.setIf_out_arrangement(FwConstants.SPACE);
				}
				if ((appIndvCargo.getTax_joint_file_ind() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getTax_joint_file_ind())) {
					appIndvCargo.setTax_joint_file_ind(FwConstants.SPACE);
				}
				if ((appIndvCargo.getLive_at_same_addr_ind() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getLive_at_same_addr_ind())) {
					appIndvCargo.setLive_at_same_addr_ind(FwConstants.SPACE);
				}
				if ((appIndvCargo.getTax_dp_outside_home_ind() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getTax_dp_outside_home_ind())) {
					appIndvCargo.setTax_dp_outside_home_ind(FwConstants.SPACE);
				}
				if ((appIndvCargo.getAlias_ind() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getAlias_ind())) {
					appIndvCargo.setAlias_ind(FwConstants.SPACE);
				}
				if ((appIndvCargo.getAlias_fst_nam() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getAlias_fst_nam())) {
					appIndvCargo.setAlias_fst_nam(FwConstants.SPACE);
				}
				if ((appIndvCargo.getAlias_last_nam() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getAlias_last_nam())) {
					appIndvCargo.setAlias_last_nam(FwConstants.SPACE);
				}
				if ((appIndvCargo.getAlias_suffix_name() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getAlias_suffix_name())) {
					appIndvCargo.setAlias_suffix_name(FwConstants.SPACE);
				}
				if ((appIndvCargo.getAlias_mid_init() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getAlias_mid_init())) {
					appIndvCargo.setAlias_mid_init(FwConstants.SPACE);
				}

				if ((appIndvCargo.getHspc_dsc_cd() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getHspc_dsc_cd())) {
					appIndvCargo.setHspc_dsc_cd(FwConstants.SPACE);
				}

				if (appIndvCargo.getSsn_info_ack_ind() == null) {
					appIndvCargo.setSsn_info_ack_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getRace_oth_asian_ind() == null) {
					appIndvCargo.setRace_oth_asian_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getRace_samoan_ind() == null) {
					appIndvCargo.setRace_samoan_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getRace_filipino_ind() == null) {
					appIndvCargo.setRace_filipino_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getRace_chinese_ind() == null) {
					appIndvCargo.setRace_chinese_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getRace_vie_ind() == null) {
					appIndvCargo.setRace_vie_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getRace_korean_ind() == null) {
					appIndvCargo.setRace_korean_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getRace_guam_ind() == null) {
					appIndvCargo.setRace_guam_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getRace_nhpi_ind() == null) {
					appIndvCargo.setRace_nhpi_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getRace_oth_ind() == null) {
					appIndvCargo.setRace_oth_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getRace_japanese_ind() == null) {
					appIndvCargo.setRace_japanese_ind(FwConstants.ZERO);
				}

				if ((appIndvCargo.getRace_memb_fed_rec_trb_ind() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getRace_memb_fed_rec_trb_ind())) {
					appIndvCargo.setRace_memb_fed_rec_trb_ind(FwConstants.SPACE);
				}

				if ((appIndvCargo.getTribe_name() == null)
						|| FwConstants.EMPTY_STRING.equals(appIndvCargo.getTribe_name())) {
					appIndvCargo.setTribe_name(FwConstants.SPACE);
				}
				if (appIndvCargo.getUs_ctzn_sw() == null) {
					appIndvCargo.setUs_ctzn_sw(FwConstants.SPACE);
				}

				if (((appIndvCargo.getUs_ctzn_sw() != null) && (appIndvCargo.getUs_ctzn_sw().trim().length() > 0))
						&& (appIndvCargo.getSsn_num() != null) && (appIndvCargo.getSsn_num().trim().length() > 1)) {
					appIndvCargo.setRec_cplt_ind(HouseHoldDemoGraphicsConstants.ONE);
				} else {
					appIndvCargo.setRec_cplt_ind(HouseHoldDemoGraphicsConstants.ZERO);
				}
				// EDSP - Manish ends
				// This code is added for new database feilds
				if ((appIndvCargo.getDt_leave_facty() == null)
						|| (appIndvCargo.getDt_leave_facty().toString().trim().length() == 0)) {
					appIndvCargo.setDt_leave_facty(HouseHoldDemoGraphicsConstants.HIGH_DATE);
				} else {
					appIndvCargo.setDt_leave_facty(appIndvCargo.getDt_leave_facty());
				}

				if (appIndvCargo.getNon_hspc_ind() == null) {
					appIndvCargo.setNon_hspc_ind(FwConstants.ZERO);
				}

				if (appIndvCargo.getChld_pa_act_duty_resp() == null) {
					appIndvCargo.setChld_pa_act_duty_resp(FwConstants.ZERO);
				}

				if (appIndvCargo.getChld_deceased_vet_resp() == null) {
					appIndvCargo.setChld_deceased_vet_resp(FwConstants.ZERO);
				}

				if (appIndvCargo.getSps_deceased_vet_resp() == null) {
					appIndvCargo.setSps_deceased_vet_resp(FwConstants.ZERO);
				}

				if (appIndvCargo.getDisable_vet_resp() == null) {
					appIndvCargo.setDisable_vet_resp(FwConstants.ZERO);
				}
				if (appIndvCargo.getSexual_orientation() == null) {
					appIndvCargo.setSexual_orientation(FwConstants.SPACE);
				}
				// New Code Fix
				if (FwConstants.DEFAULT_DROPDOWN_SEL.equals(appIndvCargo.getLive_arng_typ())) {
					appIndvCargo.setLive_arng_typ(FwConstants.SPACE);
				}
				if (appIndvCargo.getJob_commitment_resp() == null) {
					appIndvCargo.setJob_commitment_resp(FwConstants.ZERO);
				}

			}

			appIndvBeforeColl = cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNumber), indvSeqNumber);

			// compare and saving the individual information
			if ((appIndvBeforeColl != null) && (appIndvBeforeColl.size() > 0)) {

				appIndvBeforeCargo = appIndvBeforeColl.getCargo(0);
				// now we need to compare the cargos
				// setting the previous values

				appIndvCargo.setPreg_resp(appIndvBeforeCargo.getPreg_resp());
				appIndvCargo.setRlvn_ind(appIndvBeforeCargo.getRlvn_ind());

				// Setting the previous information about Immigration
				appIndvCargo.setRes_ga_ind(appIndvBeforeCargo.getRes_ga_ind());
				appIndvCargo.setDisabled_resp(appIndvBeforeCargo.getDisabled_resp());
				appIndvCargo.setUs_ctzn_sw(appIndvBeforeCargo.getUs_ctzn_sw());
				appIndvCargo.setAlien_status_cd(appIndvBeforeCargo.getAlien_status_cd());
				appIndvCargo.setEntry_into_us_dt(appIndvBeforeCargo.getEntry_into_us_dt());
				appIndvCargo.setAlien_doc_cd(appIndvBeforeCargo.getAlien_doc_cd());
				appIndvCargo.setAlien_num(appIndvBeforeCargo.getAlien_num());
				appIndvCargo.setChld_pa_act_duty_resp(appIndvBeforeCargo.getChld_pa_act_duty_resp());
				appIndvCargo.setBrst_cer_cancer_diag_ind(appIndvBeforeCargo.getBrst_cer_cancer_diag_ind());
				appIndvCargo.setBrst_cer_cancer_diag_dt(appIndvBeforeCargo.getBrst_cer_cancer_diag_dt());

				appIndvCargo.setChld_trb_mbr_resp(FwConstants.SPACE);
				appIndvCargo.setTrb_mbr_resp(FwConstants.SPACE);
				appIndvCargo.setWic_clnc_cd(appIndvBeforeCargo.getWic_clnc_cd());
				appIndvCargo.setWic_clnc_cnty(appIndvBeforeCargo.getWic_clnc_cnty());
				appIndvCargo.setChange_description(appIndvBeforeCargo.getChange_description());
				appIndvCargo.setPers_info_change_desc(appIndvBeforeCargo.getPers_info_change_desc());
				appIndvCargo.setPersoninfo_change_dt(appIndvBeforeCargo.getPersoninfo_change_dt());
				appIndvCargo.setOth_info_change_dt(appIndvBeforeCargo.getOth_info_change_dt());
			}

			// the below will add a new individual or update the existing one.
			appIndvCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
			peopleHandler.updateIndividual(appIndvCargo);

			// Added for CSPM-2719 starts
			if (Objects.nonNull(fwTxn) && Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getPageId())
					&& fwTxn.getCurrentActionDetails().getPageId().equals(HouseHoldDemoGraphicsConstants.ABMIS)) {
				pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvColl);
				return;
			}
			// Added for CSPM-2719 ends

			/**
			 * Below block exits the method after updating the individual information, Since
			 * for an individual update - ProfileManager related details are not necessary.
			 */

			if (currentPageId.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.SERVICE_SAVE_ENDPOINT_MARITAL_STATUS)
					|| checkPageId || currentPageId
							.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.SERVICE_SAVE_RC_ENDPOINT_MARITAL_STATUS)) {
				return;
			}

			// profile update
			if ((appIndvColl != null) && (!appIndvColl.isEmpty())) {
				if ((appInPrflColl != null) && (!appInPrflColl.isEmpty()) && (appInPrflCargo != null)) {
					appInPrflCargo.setApp_num(appNumber);
					appInPrflCargo.setIndv_seq_num(indvSeqNumber);

					if (appInPrflCargo.getIndv_fs_rqst_ind() == null) {
						appInPrflCargo.setIndv_fs_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO);
					}

					if ((appInPrflCargo.getIndv_cc_rqst_ind() == null)
							&& (appInPrflCargo.getIndv_fpw_rqst_ind() == null)
							&& (appInPrflCargo.getIndv_fma_rqst_ind() == null)
							&& (appInPrflCargo.getIndv_tanf_rqst_ind() == null)
							&& (appInPrflCargo.getIndv_wic_rqst_ind() == null)) {

					}
					if (appInPrflCargo.getIndv_cc_rqst_ind() == null) {
						appInPrflCargo.setIndv_cc_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO);
					}
					// VACMS end - converting FS to CC

					if (appInPrflCargo.getIndv_fpw_rqst_ind() == null) {
						appInPrflCargo.setIndv_fpw_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO);
					}
					if (appInPrflCargo.getIndv_fma_rqst_ind() == null) {
						appInPrflCargo.setIndv_fma_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO);
					}
					if (appInPrflCargo.getIndv_tanf_rqst_ind() == null) {
						appInPrflCargo.setIndv_tanf_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO);
					}
					if (appInPrflCargo.getIndv_wic_rqst_ind() == null) {
						appInPrflCargo.setIndv_wic_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO);
					}
					if (appInPrflCargo.getIndv_magi_rqst_ind() == null) {
						appInPrflCargo.setIndv_magi_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO);
					}
					if (appInPrflCargo.getIndv_peach_rqst_ind() == null) {
						appInPrflCargo.setIndv_peach_rqst_ind(FwConstants.ZERO);
					}

					// EDSP START
					if (programKeyArray[10] == 1) {
						appInPrflCargo.setIndv_ca_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
					}
					if (programKeyArray[11] == 1) {
						appInPrflCargo.setIndv_cr_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
					}
					if (programKeyArray[12] == 1) {
						appInPrflCargo.setIndv_fu_rqst_ind(HouseHoldDemoGraphicsConstants.ONE);
					}
					if (appInPrflCargo.getIndv_ca_rqst_ind() == null) {
						appInPrflCargo.setIndv_ca_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO);
					}
					if (appInPrflCargo.getIndv_cr_rqst_ind() == null) {
						appInPrflCargo.setIndv_cr_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO);
					}
					if (appInPrflCargo.getIndv_fu_rqst_ind() == null) {
						appInPrflCargo.setIndv_fu_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO);
					}
					// EDSP END

					// Changed By rashmi
					if ((appInPrflCargo.getRefusal_to_work_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getRefusal_to_work_resp().trim())) {
						appInPrflCargo.setRefusal_to_work_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getPresc_drug_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getPresc_drug_resp().trim())) {
						appInPrflCargo.setPresc_drug_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getAssociation_fee_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getAssociation_fee_resp().trim())) {
						appInPrflCargo.setAssociation_fee_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getUnocc_home_paymt_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getUnocc_home_paymt_resp().trim())) {
						appInPrflCargo.setUnocc_home_paymt_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getOther_housing_bill_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getOther_housing_bill_resp().trim())) {
						appInPrflCargo.setOther_housing_bill_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getPrsnl_care_provided_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getPrsnl_care_provided_resp().trim())) {
						appInPrflCargo.setPrsnl_care_provided_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getOthr_incm_unemp_bnfts_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getOthr_incm_unemp_bnfts_resp().trim())) {
						appInPrflCargo.setOthr_incm_unemp_bnfts_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getOut_patient_treatment_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getOut_patient_treatment_resp().trim())) {
						appInPrflCargo.setOut_patient_treatment_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getMed_equip_supplies_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getMed_equip_supplies_resp().trim())) {
						appInPrflCargo.setMed_equip_supplies_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getDiabets_edu_prg_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getDiabets_edu_prg_resp().trim())) {
						appInPrflCargo.setDiabets_edu_prg_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getOthr_incm_rentl_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getOthr_incm_rentl_resp().trim())) {
						appInPrflCargo.setOthr_incm_rentl_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getHlth_hosp_insurance_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getHlth_hosp_insurance_resp().trim())) {
						appInPrflCargo.setHlth_hosp_insurance_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getHlth_hosp_insurance_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getHlth_hosp_insurance_resp().trim())) {
						appInPrflCargo.setHlth_hosp_insurance_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getOthr_incm_trbl_ga_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getOthr_incm_trbl_ga_resp().trim())) {
						appInPrflCargo.setOthr_incm_trbl_ga_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getPostage_mail_presc_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getPostage_mail_presc_resp().trim())) {
						appInPrflCargo.setPostage_mail_presc_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getMed_dent_vision_services_resp() == null) || FwConstants.EMPTY_STRING
							.equals(appInPrflCargo.getMed_dent_vision_services_resp().trim())) {
						appInPrflCargo.setMed_dent_vision_services_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getLand_contract_mortgage_resp() == null) || FwConstants.EMPTY_STRING
							.equals(appInPrflCargo.getLand_contract_mortgage_resp().trim())) {
						appInPrflCargo.setLand_contract_mortgage_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getAttdt_hsekpr_srvc_animal_resp() == null) || FwConstants.EMPTY_STRING
							.equals(appInPrflCargo.getAttdt_hsekpr_srvc_animal_resp().trim())) {
						appInPrflCargo.setAttdt_hsekpr_srvc_animal_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getChild_care_provider_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getChild_care_provider_resp().trim())) {
						appInPrflCargo.setChild_care_provider_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getResettlement_incm_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getResettlement_incm_resp().trim())) {
						appInPrflCargo.setResettlement_incm_resp(FwConstants.SPACE);
					}

					if ((appInPrflCargo.getNursing_care_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getNursing_care_resp().trim())) {
						appInPrflCargo.setNursing_care_resp(FwConstants.SPACE);
					}
					if ((appInPrflCargo.getTrbl_ser_resp() == null)
							|| FwConstants.EMPTY_STRING.equals(appInPrflCargo.getTrbl_ser_resp().trim())) {
						appInPrflCargo.setTrbl_ser_resp(FwConstants.SPACE);
					}

				}

				appRelationColl = householdRelationshipRepo.getByAppNum(Integer.parseInt(appNumber));

				if ((appRelationColl != null) && (!appRelationColl.isEmpty())) {
					appRelationCargo = appRelationColl.getCargo(0);
					// Setting Default values if the before cargo values are
					if (appRelationCargo.getSrcAppIndiv() == null) {
						appRelationCargo.setSrcAppIndiv(FwConstants.SPACE);
					}
					if (appRelationCargo.getChange_dt() == null) {
						appRelationCargo.setChange_dt(HouseHoldDemoGraphicsConstants.HIGH_DATE);
					}
					houseHoldRelationBo.storeHousholdRelationshipDetails(appRelationColl);
				}
				appInPrflBeforeColl = cpAppInPrflRepository.findCollByAppIdnvNum(appNumber, indvSeqNumber);

				// saving the profile information
				if ((appInPrflColl != null) && (appInPrflBeforeColl != null) && (appInPrflBeforeColl.size() > 0)
						&& (appInPrflColl.getCargo(0) != null)) {
					appInPrflCargo = appInPrflColl.getCargo(0);
					appInPrflBeforeCargo = appInPrflBeforeColl.getCargo(0);
					if ((appInPrflBeforeCargo != null) && (!appInPrflBeforeCargo.getIndv_cc_rqst_ind()
							.equals(appInPrflCargo.getIndv_cc_rqst_ind())
							|| !appInPrflBeforeCargo.getIndv_fs_rqst_ind().equals(appInPrflCargo.getIndv_fs_rqst_ind())
							|| !appInPrflBeforeCargo.getIndv_fpw_rqst_ind()
									.equals(appInPrflCargo.getIndv_fpw_rqst_ind())
							|| !appInPrflBeforeCargo.getIndv_fma_rqst_ind()
									.equals(appInPrflCargo.getIndv_fma_rqst_ind())
							|| !appInPrflBeforeCargo.getIndv_tanf_rqst_ind()
									.equals(appInPrflCargo.getIndv_tanf_rqst_ind())
							|| !appInPrflBeforeCargo.getIndv_ca_rqst_ind().equals(appInPrflCargo.getIndv_ca_rqst_ind())
							|| !appInPrflBeforeCargo.getIndv_cr_rqst_ind().equals(appInPrflCargo.getIndv_cr_rqst_ind())
							|| !appInPrflBeforeCargo.getIndv_fu_rqst_ind()
									.equals(appInPrflCargo.getIndv_fu_rqst_ind()))) {

						appInPrflCargo.setIndv_ebd_rqst_ind(appInPrflBeforeCargo.getIndv_ebd_rqst_ind());
						appInPrflCargo.setIndv_hc_rqst_ind(appInPrflBeforeCargo.getIndv_hc_rqst_ind());
						// update program related info if any
						cpAppInPrflRepository.save(appInPrflCargo);
					}
				} else {
					// if it is new person then i am setting that person
					// information in the data base
					// as well as app in prfl

					appInPrflCargo = houseHoldRelationBo.createAppIndividualProfile(appInPrflCargo);
					cpAppInPrflRepository.save(appInPrflCargo);
					if (appInPrflSessionColl != null) {
						appInPrflSessionColl.add(appInPrflCargo);
					}
				}
			}

			// EDSP CP Starts: Program specific logic for next individuals
			if (!isProgramSpecificLogic) {
				displayProgramSpecificInfo(programKeyArray, pageCollection);
			}
			// EDSP CP ends: Program specific logic for next individuals

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeHouseHoldMembersDetail()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeHouseHoldMembersDetail",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeHouseHoldMembersDetail() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}
	@SuppressWarnings("squid:S3776")
	private void persistLangNameAndDisabilityDetails(Map pageCollection, String appNumber, Integer indvSeqNumber) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.persistLangNameAndDisabilityDetails() - START");

		APP_INDV_Collection appIndvCollFromDB = null;
		APP_INDV_Collection appIndvCollFromRequest = null;
		APP_INDV_Cargo appIndvCargoFromRequest = null;

		// Fetching data from request
		appIndvCollFromRequest = (APP_INDV_Collection) pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
		appIndvCollFromDB = cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNumber), indvSeqNumber);

		if (null != appIndvCollFromRequest && !appIndvCollFromRequest.isEmpty()) {
			appIndvCargoFromRequest = appIndvCollFromRequest.getCargo(0);

			if (null != appIndvCollFromDB && appIndvCollFromDB.size() > 0) {
				APP_INDV_Cargo appIndvCargoFromDB = appIndvCollFromDB.getCargo(0);

				// Setting lang details
				appIndvCargoFromDB.setLang_cd(appIndvCargoFromRequest.getLang_cd());
				appIndvCargoFromDB.setLang_cd_sp(appIndvCargoFromRequest.getLang_cd_sp());
				appIndvCargoFromDB.setLang_oth_dsc(appIndvCargoFromRequest.getLang_oth_dsc());

				// Setting name details
				appIndvCargoFromDB.setFst_nam(appIndvCargoFromRequest.getFst_nam());
				appIndvCargoFromDB.setMid_init(appIndvCargoFromRequest.getMid_init());
				appIndvCargoFromDB.setLast_nam(appIndvCargoFromRequest.getLast_nam());
				appIndvCargoFromDB.setSuffix_name(appIndvCargoFromRequest.getSuffix_name());
				appIndvCargoFromDB.setAlias_oth_nam(appIndvCargoFromRequest.getAlias_oth_nam());

				// Setting Disability details
				appIndvCargoFromDB.setEstb_dabl_resp(appIndvCargoFromRequest.getEstb_dabl_resp());
				appIndvCargoFromDB.setEstb_deaf_resp(appIndvCargoFromRequest.getEstb_deaf_resp());

				appIndvCargoFromDB.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);

				// Tribal details start
				appIndvCargoFromDB.setHspc_ind(appIndvCargoFromRequest.getHspc_ind());
				appIndvCargoFromDB.setHspc_dsc_cd(appIndvCargoFromRequest.getHspc_dsc_cd());
				appIndvCargoFromDB.setHspc_oth_dsc(appIndvCargoFromRequest.getHspc_oth_dsc());
				appIndvCargoFromDB.setRace_memb_fed_rec_trb_ind(appIndvCargoFromRequest.getRace_memb_fed_rec_trb_ind());
				appIndvCargoFromDB.setTribe_name(appIndvCargoFromRequest.getTribe_name());
				appIndvCargoFromDB.setEthnicity_cd(appIndvCargoFromRequest.getEthnicity_cd());
				appIndvCargoFromDB.setRace_oth_dsc(appIndvCargoFromRequest.getRace_oth_dsc());
				appIndvCargoFromDB.setRace_cd(appIndvCargoFromRequest.getRace_cd());
				appIndvCargoFromDB.setRecv_srvc_sw(appIndvCargoFromRequest.getRecv_srvc_sw());
				appIndvCargoFromDB.setEligible_hs_ind(appIndvCargoFromRequest.getEligible_hs_ind());
				// Tribal details ends
				// CitizenShip details
				houseHoldBo.citizenShipDetails(appIndvCargoFromDB, appIndvCargoFromRequest);

				if (pageCollection.get(AppConstants.FLOW_MODE) != null && ((AppConstants.DCF_FLOW)
						.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
						|| (HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING)
								.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
						|| (HouseHoldDemoGraphicsConstants.CALFRESH_F37)
								.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString()))) {
					appIndvCargoFromDB.setSsn_num(null == appIndvCargoFromRequest.getSsn_num()
							|| (appIndvCargoFromRequest.getSsn_num().isEmpty()) ? FwConstants.ZERO
									: appIndvCargoFromRequest.getSsn_num());
					appIndvCargoFromDB.setBrth_dt(appIndvCargoFromRequest.getBrth_dt());
				} else {

					// Setting lang details
					appIndvCargoFromDB.setLang_cd(appIndvCargoFromRequest.getLang_cd());
					appIndvCargoFromDB.setLang_cd_sp(appIndvCargoFromRequest.getLang_cd_sp());
					appIndvCargoFromDB.setLang_oth_dsc(appIndvCargoFromRequest.getLang_oth_dsc());

					// Setting Disability details
					appIndvCargoFromDB.setEstb_dabl_resp(appIndvCargoFromRequest.getEstb_dabl_resp());
					appIndvCargoFromDB.setEstb_deaf_resp(appIndvCargoFromRequest.getEstb_deaf_resp());

					// Tribal details start
					appIndvCargoFromDB.setHspc_ind(appIndvCargoFromRequest.getHspc_ind());
					appIndvCargoFromDB.setHspc_dsc_cd(appIndvCargoFromRequest.getHspc_dsc_cd());
					appIndvCargoFromDB.setHspc_oth_dsc(appIndvCargoFromRequest.getHspc_oth_dsc());
					appIndvCargoFromDB
							.setRace_memb_fed_rec_trb_ind(appIndvCargoFromRequest.getRace_memb_fed_rec_trb_ind());
					appIndvCargoFromDB.setTribe_name(appIndvCargoFromRequest.getTribe_name());
					appIndvCargoFromDB.setEthnicity_cd(appIndvCargoFromRequest.getEthnicity_cd());
					appIndvCargoFromDB.setRace_oth_dsc(appIndvCargoFromRequest.getRace_oth_dsc());
					appIndvCargoFromDB.setRace_cd(appIndvCargoFromRequest.getRace_cd());
					appIndvCargoFromDB.setRecv_srvc_sw(appIndvCargoFromRequest.getRecv_srvc_sw());
					appIndvCargoFromDB.setEligible_hs_ind(appIndvCargoFromRequest.getEligible_hs_ind());

					// Tribal details ends
					// CitizenShip details
					houseHoldBo.citizenShipDetails(appIndvCargoFromDB, appIndvCargoFromRequest);
				}
				if (pageCollection.get(AppConstants.FLOW_MODE) != null
						&& (HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING
								.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
								|| HouseHoldDemoGraphicsConstants.CALFRESH_F37
										.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString()))) {
					if (appIndvCargoFromDB.getMove_in_ind() == null
							&& appIndvCargoFromRequest.getMove_in_ind() != null) {
						appIndvCargoFromDB.setMove_in_ind(appIndvCargoFromRequest.getMove_in_ind());
					}
					if (appIndvCargoFromRequest.getMove_in_ind() != null
							|| appIndvCargoFromRequest.getNew_born_ind() != null) {
						appIndvCargoFromDB.setMoved_in_dt(appIndvCargoFromRequest.getMoved_in_dt());
					}
					if (appIndvCargoFromDB.getNew_born_ind() == null
							&& appIndvCargoFromRequest.getNew_born_ind() != null) {
						appIndvCargoFromDB.setNew_born_ind(appIndvCargoFromRequest.getNew_born_ind());
					}
					if (appIndvCargoFromRequest.getDeceased_ind() != null) {
						appIndvCargoFromDB.setDecease_dt(appIndvCargoFromRequest.getDecease_dt());
					}
					if (appIndvCargoFromDB.getPassedaway_other_ind() == null
							&& appIndvCargoFromRequest.getPassedaway_other_ind() != null) {
						appIndvCargoFromDB.setPassedaway_other_ind(appIndvCargoFromRequest.getPassedaway_other_ind());
					}
					if (appIndvCargoFromDB.getDeceased_ind() == null
							&& appIndvCargoFromRequest.getDeceased_ind() != null) {
						appIndvCargoFromDB.setDeceased_ind(appIndvCargoFromRequest.getDeceased_ind());
					}
				}
				//set update date
				Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
				appIndvCargoFromDB.setUpdate_dt(currentTimeStamp);
				cpAppIndvRepository.save(appIndvCargoFromDB);
				appIndvCollFromRequest.set(0, appIndvCargoFromDB);
				pageCollection.replace(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollFromRequest);

			} else {
				appIndvCargoFromRequest.setIndv_seq_num(indvSeqNumber);
				appIndvCargoFromRequest.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				appIndvCargoFromRequest.setApp_num(appNumber);
				cpAppIndvRepository.save(appIndvCargoFromRequest);
				pageCollection.replace(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollFromRequest);
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.persistLangNameAndDisabilityDetails() - END");

	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getHouseHoldMembersDetail(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getHouseHoldMembersDetail() - START", fwTxn);
		final Map request = fwTxn.getRequest();
		Map pageCollection = fwTxn.getPageCollection();
		UserDetails userDetails = fwTxn.getUserDetails();

		String appNumber = null;
		// int indvSeqNumber = 1;
		APP_IN_PRFL_Collection appInPrflcoll = new APP_IN_PRFL_Collection();
		APP_IN_PRFL_Cargo appInPrflSessionCargo = null;
		APP_IN_PRFL_Collection appInPrflColl = null;
		APP_IN_PRFL_Collection appInPrflCloneColl = null;
		APP_INDV_Collection appIndvColl = null;
		INDIVIDUAL_Custom_Collection indvCustColl = null;
		INDIVIDUAL_Custom_Collection indvCustCollMaster = null;
		APP_PGM_RQST_Collection appPgmRqstColl = null;
		APP_PGM_RQST_Cargo appPgmRqstCargo = null;
		String pageId = null;
		int pageStatus = 0;
		int peopleCount = 0;
		int childCount = 0;

		try {
			appNumber = userDetails.getAppNumber();
			appPgmRqstColl = houseHoldBo.loadProgramDetail(appNumber);
			pageCollection.put(APP_PGM_RQST_COLL, appPgmRqstColl);
			String individualSeqNumber = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence();
			appIndvColl = houseHoldBo.loadHouseholdMemberDetail(appNumber, Integer.parseInt(individualSeqNumber));

			// Added for CSPM-2719 starts
			if (Objects.nonNull(fwTxn) && Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getPageId())
					&& (fwTxn.getCurrentActionDetails().getPageId().equals(HouseHoldDemoGraphicsConstants.ABCCE)
							|| fwTxn.getCurrentActionDetails().getPageId()
									.equals(HouseHoldDemoGraphicsConstants.ABMIS))) {
				APP_INDV_Cargo[] appIndvCargoArray = cpAppIndvRepository.getByAppNum(Integer.parseInt(appNumber));
				if (ArrayUtils.isNotEmpty(appIndvCargoArray)) {
					APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
					for (APP_INDV_Cargo cargo : appIndvCargoArray) {
						appIndvCollection.addCargo(cargo);
					}
					pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
					pageCollection.put(HouseHoldDemoGraphicsConstants.STORED_APP_INDV_COLLECTION, appIndvColl);
				}
				return;
			}
			// Added for CSPM-2719 ends

			if (appIndvColl != null && appIndvColl.size() > 0) {
				int tempIndvSeqNum = Integer.parseInt(individualSeqNumber);
				// appPgmRqstColl = houseHoldBo.loadProgramDetail(appNumber);
				APP_IN_PRFL_Cargo[] appInPrflCargo = cpAppInPrflRepository.findByAppIdnvNum(appNumber, tempIndvSeqNum);
				if (appInPrflCargo.length > 0) {
					appInPrflcoll.setResults(appInPrflCargo);
				}
			} else {
				appIndvColl = new APP_INDV_Collection();
				appInPrflcoll = new APP_IN_PRFL_Collection();
				APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
				APP_IN_PRFL_Cargo appInPrflCargo = new APP_IN_PRFL_Cargo();
			}
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvColl);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_PRFL_COLLECTION, appInPrflcoll);

			fwTxn.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getHouseHoldMembersDetail()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getHouseHoldMembersDetail",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getHouseHoldMembersDetail() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getDisabilityDetails(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		// log(ILog.INFO, "HouseHoldInfoEJBBean.getDisabilityDetails() - START");

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, GET_DISABILITY_DETAILS_START, fwTxn);
		try {
			final Map request = fwTxn.getRequest();
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();

			int currentPageStatus = 0;
			request.put("loopingQuestion", FwConstants.NO);

			final String previousPageId = (String) request.get(FwConstants.PREVIOUS_PAGE_ID);

			// new line
			String appnum = userDetails.getAppNumber();

			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			Integer seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			String firstname = peopleHandler.getFirstName(indv_seq_num.toString(), appnum);

			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {
				// get LiquidAsset details from LiquidAsset details table in
				// database
				final IndivTypeSeq indv = (IndivTypeSeq) pageCollection.get(FwConstants.DETAIL_KEY_BEAN);
				pageCollection = new HashMap();
				// get Details_Collection from DataBase and set to
				// PageCollection

				// DOUBT
				final APP_IN_DABL_Collection apliqAsetCol = disabilityBo.loadDisabilityDetails(appnum,
						indv.getIndivSeqNum(), indv.getSeqNum());
				// DOUBT
				APP_IN_DABL_Collection newApliqAssetColl = new APP_IN_DABL_Collection();
				APP_IN_DABL_Cargo newApliqAssetCargo = new APP_IN_DABL_Cargo();
				APP_IN_DABL_Cargo[] apliqAsetArray = apliqAsetCol.getResults();
				for (int i = 0; i < apliqAsetArray.length; i++) {
					newApliqAssetCargo = apliqAsetArray[0];
					newApliqAssetCargo.setFts_nam(firstname);
					newApliqAssetColl.add(newApliqAssetCargo);
				}
				pageCollection.put("APP_IN_DABL_Collection", newApliqAssetColl);

				String showLoopingQuestionFlag = (String) fwTxn.getRequest().get("showLoopingQuestion");
				populateDisabilityCargo(firstname, pageCollection, showLoopingQuestionFlag);
				pageCollection.put("showLoopingQuestion", FwConstants.NO);
			} else {
				pageCollection = new HashMap();
				pageCollection.put("showLoopingQuestion", FwConstants.YES);
				APP_IN_DABL_Collection collses = disabilityBo.loadDisabilityDetails(appnum, indv_seq_num, seq_num);
				APP_IN_DABL_Collection newColl = new APP_IN_DABL_Collection();
				APP_IN_DABL_Cargo cargoSes = null;
				final int size = collses.size();
				if (size > 0) {
					// get last cargo from session
					cargoSes = collses.getCargo(size - 1);
					cargoSes.setFts_nam(firstname);

				} else {
					cargoSes = new APP_IN_DABL_Cargo();
					cargoSes.setFts_nam(firstname);
					cargoSes.setIndv_seq_num(indv_seq_num);
					cargoSes.setSeq_num(seq_num);
				}
				newColl.addCargo(cargoSes);
				pageCollection.put(AppConstants.FIRST_NAME, firstname);
				// set Details_Collection from session to PageCollection
				pageCollection.put("APP_IN_DABL_Collection", newColl);
			}
			pageCollection.put(AppConstants.CURRENT_INDIV_SEQ_NUM, indv_seq_num);
			// Getting people handler object from session
			fwTxn.setPageCollection(pageCollection);
			// EDSP CP Starts: Program specific logic for next individuals

			// EDSP CP ends: Program specific logic for next individuals
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.getDisabilityDetails()", fwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "getDisabilityDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getDisabilityDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	private void populateDisabilityCargo(final String firstname, final Map pageCollection,
			final String showLoopingQuestionFlag) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.populateDisabilityCargo() - START");
			pageCollection.put(AppConstants.FIRST_NAME, firstname);

			pageCollection.put("ShowLoopingQuestionFlag", showLoopingQuestionFlag);
		

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.populateDisabilityCargo() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

	}

	@Transactional
	@SuppressWarnings("squid:S3776")
	public void storeLangNameAndDisabilityDetails(final FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeLangNameAndDisabilityDetails() - START", fwTxn);
		try {
			final Map request = fwTxn.getRequest();
			final Map pageCollection = fwTxn.getPageCollection();

			UserDetails userDetails = fwTxn.getUserDetails();
			String pageId = null;
			FwMessageList validateInfo = new FwMessageList();

			String appNumber = userDetails.getAppNumber();
			Integer indv_seq_num = 0;
			Integer cat_Seq_Num = 0;

			// Added as part of CSPM-543: To store Lang, indv details and disability details
			// in resp cargos
			if (null != fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence()) {

				indv_seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			}
			// Save for MC Redet flow - start
			if (pageCollection.containsKey(AppConstants.FLOW_MODE) && (AppConstants.MCR_FLOW).equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())) {
				APP_INDV_Collection appIndvCollFromDB = null;
				APP_INDV_Collection appIndvCollFromRequest = null;
				APP_INDV_Cargo appIndvCargoFromRequest = null;

				// Fetching data from request
				appIndvCollFromRequest = (APP_INDV_Collection) pageCollection
						.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
				appIndvCollFromDB = cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNumber), indv_seq_num);

				if (null != appIndvCollFromRequest && !appIndvCollFromRequest.isEmpty()) {
					appIndvCargoFromRequest = appIndvCollFromRequest.getCargo(0);

					if (null != appIndvCollFromDB && appIndvCollFromDB.size() > 0) {
						APP_INDV_Cargo appIndvCargoFromDB = appIndvCollFromDB.getCargo(0);

						// Setting name details
						appIndvCargoFromDB.setFst_nam(appIndvCargoFromRequest.getFst_nam());
						appIndvCargoFromDB.setMid_init(appIndvCargoFromRequest.getMid_init());
						appIndvCargoFromDB.setLast_nam(appIndvCargoFromRequest.getLast_nam());
						appIndvCargoFromDB.setSuffix_name(appIndvCargoFromRequest.getSuffix_name());
						appIndvCargoFromDB.setAlias_oth_nam(appIndvCargoFromRequest.getAlias_oth_nam());

						// appIndvCargoFromDB.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
						appIndvCargoFromDB.setLang_cd(appIndvCargoFromRequest.getLang_cd());
                        appIndvCargoFromDB.setLang_cd_sp(appIndvCargoFromRequest.getLang_cd_sp());
						
						//set update date
 				        Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
 				        appIndvCargoFromDB.setUpdate_dt(currentTimeStamp);
 				        
						appIndvCargoFromDB
								.setChg_dt(Date.valueOf(Timestamp.from(Instant.now()).toLocalDateTime().toLocalDate()));

						cpAppIndvRepository.save(appIndvCargoFromDB);
						appIndvCollFromRequest.set(0, appIndvCargoFromDB);
						pageCollection.replace(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION,
								appIndvCollFromRequest);
					}
				}
			}
			// Save for MC Redet flow - end
			else {
				persistLangNameAndDisabilityDetails(pageCollection, appNumber, indv_seq_num);

				/*
				 * Usage of mode to use specific flow functionality Here for DCF flow,
				 * Relationship service invoked when relationship drop down selected
				 * 
				 * Similarly for other flows, specific functionality can be invoked
				 */
				if (pageCollection.containsKey(AppConstants.FLOW_MODE) && ((AppConstants.DCF_FLOW)
						.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
						|| (HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING)
								.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
						|| (HouseHoldDemoGraphicsConstants.CALFRESH_F37)
								.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString()))) {

					CP_APP_HSHL_RLT_Collection appHshlRltColl = (CP_APP_HSHL_RLT_Collection) pageCollection
							.get(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION);

					if (null != appHshlRltColl && !appHshlRltColl.isEmpty()) {
						HouseholdDemographicsService service = (HouseholdDemographicsService) applicationContext
								.getBean("HouseholdDemographicsInvidualRelationsService");
						service.callBusinessLogic("storeRelationshipandBuyPrepareFoodDetails", fwTxn);
					}
				}
			}

			if (validateInfo.hasMessages()) {
				APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);
				request.put(FwConstants.MESSAGE_LIST, validateInfo);
				pageCollection.put(APP_INDV_COLL, appIndvColl);
				// pageCollection.put(FwConstants.PAGE_COMPONENT_LIST,
				// beforeColl.get(FwConstants.PAGE_COMPONENT_LIST));
				pageCollection.put(AppConstants.INDV_SEQUENCE_NUMBERS, indv_seq_num);
				pageCollection.put(AppConstants.CURRENT_INDIV_SEQ_NUM, indv_seq_num);
				pageCollection.put(AppConstants.FIRST_NAME, userDetails.getFirstName());

				return;
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.storeLangNameAndDisabilityDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), "storeLangNameAndDisabilityDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);

		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeLangNameAndDisabilityDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	@Transactional
	public void storeMailingAddressDetail(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService..storeMailingAddressDetail() - START", fwTxn);
		try {

			Map pageCollection = fwTxn.getPageCollection();
			Map request = fwTxn.getRequest();
			UserDetails userDetails = fwTxn.getUserDetails();

			String appNumber = null;

			appNumber = userDetails.getAppNumber();

			final String tsrcAppInd = AppConstants.SRC_APP_IND_AFB;

			// getting radios and cargo
			ADD_VAL_Collection addrValColl = (ADD_VAL_Collection) pageCollection.get("ADD_VAL_Collection");
			String homeAddressRadio = "";
			String mailAddressRadio = "";

			if (null != addrValColl) {
				final ADD_VAL_Cargo addrValCargo = addrValColl.getCargo(0);
				homeAddressRadio = addrValCargo.getRadioGroup_HOME();
				mailAddressRadio = addrValCargo.getRadioGroup_MAIL();
			}

			APP_RGST_Collection coll = (APP_RGST_Collection) pageCollection.get(APP_RGST_COLL);

			if ((null == coll) || (null == coll.getCargo(0))) {
				coll = new APP_RGST_Collection();

				final APP_RGST_Cargo[] rgstCargo = (APP_RGST_Cargo[]) cpAppRgstRepository
						.getByAppNumAndSrcApp(Integer.parseInt(appNumber), tsrcAppInd);
				coll.addCargo(rgstCargo[0]);
			}

			final APP_RGST_Cargo rgstCargo = coll.getCargo(0);

			// update address to db
			boolean addrChanged = false;

			APP_RGST_Cargo cargo = new APP_RGST_Cargo();
			cargo.setApp_num(appNumber);
			cargo.setSrc_app_ind(tsrcAppInd);

			if ("STANDARD".equals(homeAddressRadio)) {
				// update house hold address with standard

				cargo.setHshl_l1_adr(rgstCargo.getHshl_l1_adr());
				cargo.setHshl_l2_adr(rgstCargo.getHshl_l2_adr());
				cargo.setHshl_city_adr(rgstCargo.getHshl_city_adr());
				cargo.setHshl_sta_adr(rgstCargo.getHshl_sta_adr());
				final String altZipAdr = rgstCargo.getHshl_zip_adr();

				final String[] zip = altZipAdr.split("-");
				final String zip1 = zip[0];
				cargo.setHshl_zip_adr(zip1);
				if (zip[1] != null && zip[1].matches("[0-9]*")) {
					cargo.setHshl_addr_zip4(zip[1]);
				}
				addrChanged = true;

			}
			if ("STANDARD".equals(mailAddressRadio)) {
				// update house hold address with standard

				cargo.setAlt_st_adr(rgstCargo.getAlt_l1_adr());
				cargo.setAlt_l2_adr(rgstCargo.getAlt_l2_adr());
				cargo.setAlt_city_adr(rgstCargo.getAlt_city_adr());
				cargo.setAlt_sta_adr(rgstCargo.getAlt_sta_adr());
				final String altZipAdr = rgstCargo.getAlt_zip_adr();

				final String[] zip = altZipAdr.split("-");
				final String zip1 = zip[0];
				cargo.setAlt_zip_adr(zip1);
				if (zip[1] != null && zip[1].matches("[0-9]*")) {
					cargo.setAlt_addr_zip4(zip[1]);
				}
				addrChanged = true;

			}

			if (addrChanged) {
				cpAppRgstRepository.save(cargo);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService..storeMailingAddressDetail()", fwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeMailingAddressDetail",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeMailingAddressDetail() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	/**
	 * Method to load/get Information About You/About You - ABRGI and Address
	 * Validation - ABAVD
	 * 
	 * @param FwTransaction object
	 *
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getRegistrationInformation(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getRegistrationInformation() - START", fwTxn);

		Map pageCollection = fwTxn.getPageCollection();
		Map request = fwTxn.getRequest();
		UserDetails userDetails = fwTxn.getUserDetails();

		String appNumber = null;

		try {
			appNumber = userDetails.getAppNumber();

			// we need to get the page data from the data base

			pageCollection = registrationBo.loadRegistrationInformation(appNumber, pageCollection);

			Map ccPrescreenMap = null;
			if (ccPrescreenMap == null || ccPrescreenMap.isEmpty()) {
				ccPrescreenMap = new HashMap();
				registrationBo.loadCCScreenerResults(appNumber, ccPrescreenMap);
			}

			fwTxn.setPageCollection(pageCollection);

			peopleHandler.loadPeopleHandler(appNumber);

			pageCollection.put(AppConstants.WIC_CLINIC_INFO, registrationBo.loadWICClncInfo());
			fwTxn.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured In HouseholdDemographicsService.getRegistrationInformation()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getRegistrationInformation",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getRegistrationInformation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	/**
	 * Method to store Information About You/About You - ABRGI
	 * 
	 * @param FwTransaction object
	 * @throws Exception
	 * 
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeRegistrationInformation(FwTransaction fwTxn) throws Exception {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeRegistrationInformation() - START", fwTxn);

		final Map request = fwTxn.getRequest();
		final Map pageCollection = fwTxn.getPageCollection();
		UserDetails userDetails = fwTxn.getUserDetails();

		String appNumber = null;

		// Cargos
		APP_IN_INST_Cargo appInInstCargo = null;
		APP_INDV_Cargo appIndvCargo = null;
		APP_IN_SPS_IMPOV_Cargo appInSpsImpovCargo = null;
		APP_RGST_Cargo appRgstCargo = null;

		// Collections
		APP_IN_INST_Collection appInInstColl = null;
		APP_INDV_Collection appIndvColl = null;
		APP_IN_SPS_IMPOV_Collection appInSpsImpovColl = null;
		APP_RGST_Collection appRgstColl = null;

		try {

			appNumber = userDetails.getAppNumber();

			appIndvColl = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);
			appRgstColl = (APP_RGST_Collection) pageCollection.get(APP_RGST_COLL);
			appInInstColl = (APP_IN_INST_Collection) pageCollection.get("APP_IN_INST_Collection");
			appInSpsImpovColl = (APP_IN_SPS_IMPOV_Collection) pageCollection.get("APP_IN_SPS_IMPOV_Collection");

			// getting cargo from collection
			if ((appIndvColl != null) && (!appIndvColl.isEmpty())) {
				appIndvCargo = appIndvColl.getCargo(0);
			}
			if ((appRgstColl != null) && (!appRgstColl.isEmpty())) {
				appRgstCargo = appRgstColl.getCargo(0);
			}

			if ((appInInstColl != null) && (!appInInstColl.isEmpty())) {
				appInInstCargo = appInInstColl.getCargo(0);
			}
			if ((appInSpsImpovColl != null) && (!appInSpsImpovColl.isEmpty())) {
				appInSpsImpovCargo = appInSpsImpovColl.getCargo(0);
			}
			//

			// Saving data into cargo which will call BO for validation before inserting in
			// DB.
			registrationBo.storeRegistrationInformation(appInInstCargo, appInInstColl, appIndvCargo, appIndvColl,
					appRgstCargo, appRgstColl, appInSpsImpovCargo, appInSpsImpovColl, appNumber, request,
					pageCollection, fwTxn);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.storeRegistrationInformation()", fwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeRegistrationInformation",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeRegistrationInformation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	/**
	 * Method to load/get contact information - ABCON
	 * 
	 * @param FwTransaction object
	 *
	 */
	@Transactional
	public void getContactInformation(FwTransaction FwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getContactInformation() - START", FwTxn);

		try {
			final Map pageColl = FwTxn.getPageCollection();
			UserDetails userDetails = FwTxn.getUserDetails();
			final String appNum = userDetails.getAppNumber();
			Integer indv_seq_num = 0;
			if (null != (FwTxn.getNextActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence())
					&& !"".equalsIgnoreCase(FwTxn.getNextActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indv_seq_num = Integer.parseInt(
						FwTxn.getNextActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}

			final CP_APP_RGST_Collection contactColl = new CP_APP_RGST_Collection();
			String src_app_ind = AppConstants.AFB_SRC_APP_IND;

			CP_APP_RGST_Cargo contactCargo = contInfoBO.loadContactInformationforAppNum(appNum, src_app_ind,
					indv_seq_num);

			if (contactCargo == null) {
				contactCargo = new CP_APP_RGST_Cargo();
				contactCargo.setApp_num(appNum);
				contactCargo.setSrc_app_ind(src_app_ind);
			}
			contactColl.addCargo(contactCargo);
			pageColl.put(CP_APP_RGST_COLL, contactColl);

			APP_INDV_Collection indvColl = contInfoBO.loadIndvdtl(appNum, indv_seq_num);
			pageColl.put(APP_INDV_COLL, indvColl);

			FwTxn.setPageCollection(pageColl);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.getContactInformation()", FwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "getContactInformation",
					FwTxn.getUserDetails().getAppNumber(), FwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getContactInformation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				FwTxn);

	}

	/**
	 * Method to store contact information - ABCON
	 * 
	 * @param FwTransaction object
	 * 
	 */
	@Transactional
	public void storeContactInformationAFB(FwTransaction FwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeContactInformationAFB() - START", FwTxn);
		try {

			final Map pageCollection = FwTxn.getPageCollection();
			UserDetails userDetails = FwTxn.getUserDetails();
			String src_app_ind_pr_cf37;
			String appNumber = (String) userDetails.getAppNumber();
			Integer indv_seq_num = 0;
			if (null != (FwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence())
					&& !"".equalsIgnoreCase(FwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indv_seq_num = Integer.parseInt(
						FwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			CP_APP_RGST_Collection contactColl;
			CP_APP_RGST_Cargo contactCargo;
			CP_APP_RGST_Cargo exsitingCargo;

			if (pageCollection.containsKey(CP_APP_RGST_COLL) && (pageCollection.get(CP_APP_RGST_COLL) != null)) {
				contactColl = (CP_APP_RGST_Collection) pageCollection.get(CP_APP_RGST_COLL);
				if (contactColl != null && !contactColl.isEmpty()) {

					contactCargo = contactColl.getCargo(0);
					contactCargo.setApp_num(appNumber);
					contactCargo.setIndv_seq_num(indv_seq_num);
					src_app_ind_pr_cf37 = contactCargo.getSrc_app_ind();
					if (pageCollection.get(HouseHoldDemoGraphicsConstants.MODE) != null
							&& (pageCollection.get(HouseHoldDemoGraphicsConstants.MODE).equals("CF")
									|| pageCollection.get(HouseHoldDemoGraphicsConstants.MODE).equals("S7"))) {
						contactCargo.setSrc_app_ind(src_app_ind_pr_cf37);
					} else {
						contactCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
					}
					contactCargo.setMsg_phn_num(contactCargo.getHshl_cell_phn_num());
					if (contactCargo.getHshl_city_adr() == null) {
						contactCargo.setHshl_city_adr(FwConstants.SPACE);
					}
					if (contactCargo.getAlt_st_adr() == null) {
						contactCargo.setAlt_st_adr(FwConstants.SPACE);
					}

					if (contactCargo.getAlt_l1_adr() == null) {
						contactCargo.setAlt_l1_adr(FwConstants.SPACE);
					}
					if (contactCargo.getAlt_l2_adr() == null) {
						contactCargo.setAlt_l2_adr(FwConstants.SPACE);
					}
					if (contactCargo.getAlt_city_adr() == null) {
						contactCargo.setAlt_city_adr(FwConstants.SPACE);
					}
					if (contactCargo.getAlt_city_adr() == null) {
						contactCargo.setAlt_city_adr(FwConstants.SPACE);
					}
					if (contactCargo.getAlt_sta_adr() == null) {
						contactCargo.setAlt_sta_adr(FwConstants.SPACE);
					}
					if (contactCargo.getAlt_zip_adr() == null) {
						contactCargo.setAlt_zip_adr(FwConstants.SPACE);
					}
					if (Objects.nonNull(contactCargo.getHshl_email_adr())
							&& contactCargo.getHshl_email_adr().equals(HouseHoldDemoGraphicsConstants.EMPTY)
							&& Objects.nonNull(contactCargo.getHshl_email_adrA())
							&& !contactCargo.getHshl_email_adrA().equals(HouseHoldDemoGraphicsConstants.EMPTY)) {
						contactCargo.setHshl_email_adr(contactCargo.getHshl_email_adrA());
					}

					if (contactCargo.getHshl_sta_adr() == null) {

						contactCargo.setHshl_sta_adr(FwConstants.SPACE);

						if (contactCargo.getPhonenum_receipt() == null) {
							contactCargo.setPhonenum_receipt(contactCargo.getHshl_home_phn_num());
						}
						if (contactCargo.getEmail_receipt() == null) {
							contactCargo.setEmail_receipt(contactCargo.getHshl_email_adr());
						}
					}
					if (contactCargo != null && !pageCollection.get(HouseHoldDemoGraphicsConstants.MODE).equals("MR")) {
						contactCargo.setPref_cont_method_cd(contactCargo.getPref_cont_method_cd());
					} else if (pageCollection.get(HouseHoldDemoGraphicsConstants.MODE).equals("MR")) {
						List<String> preferContactList = (List<String>) pageCollection
								.get(HouseHoldDemoGraphicsConstants.PREFERCONTACTLIST);
						contactCargo.setPref_cont_method_cd(fetchPreferContactStr(preferContactList));
					}
					if(pageCollection.get(HouseHoldDemoGraphicsConstants.MODE) != null
                            && (pageCollection.get(HouseHoldDemoGraphicsConstants.MODE).equals("MR"))) {
                        contactCargo.setChg_dt(java.util.Date.from(Instant.now()));
                    }
					
					if (pageCollection.get(HouseHoldDemoGraphicsConstants.MODE) != null
							&& (pageCollection.get(HouseHoldDemoGraphicsConstants.MODE).equals("RAC"))) {
						exsitingCargo = cpAppRgstRepo.getCpAppRgstDetails(Integer.parseInt(appNumber), indv_seq_num);
						if(null != exsitingCargo) {
						saveMailingAdr(exsitingCargo, contactCargo);
					}
					}

					contInfoBO.storeContactInformation(contactCargo);

				}
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.storeContactInformationAFB()", FwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeContactInformationAFB",
					FwTxn.getUserDetails().getAppNumber(), FwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeContactInformationAFB() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				FwTxn);
	}

	private String fetchPreferContactStr(List<String> preferContactList) {
		if (Objects.nonNull(preferContactList) && !preferContactList.isEmpty()) {
			return String.join(",", preferContactList);
		} else {
			return null;
		}
	}

	/**
	 * Store contact information
	 * 
	 * @param fwTxn
	 */
	@Transactional
	public void storeContactDetailsAFB(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeContactDetailsAFB() - START", fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String srcAppInd = AppConstants.AFB_SRC_APP_IND;

			String appNumber = userDetails.getAppNumber();
			Integer indvSeqNum = 0;
			if (null != (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence())
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			APP_INDV_Collection indvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			if (null != indvColl) {
				for (int i = 0; i < indvColl.size(); i++) {
					validateStoreCoDet(fwTxn, pageCollection, srcAppInd, appNumber, indvSeqNum, indvColl, i);
				}
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.storeContactDetailsAFB()", fwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeContactDetailsAFB",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeContactDetailsAFB() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	private void validateStoreCoDet(FwTransaction fwTxn, final Map pageCollection, String srcAppInd, String appNumber,
			Integer indvSeqNum, APP_INDV_Collection indvColl, int i) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.validateStoreCoDet() - START", fwTxn);
		APP_INDV_Cargo indvCargo = indvColl.getCargo(i);
		if (indvCargo.getIndv_seq_num().equals(indvSeqNum)) {
			if (indvCargo.getLiving_arrangement_cd() != null
					&& HouseHoldDemoGraphicsConstants.IN_HOME.equalsIgnoreCase(indvCargo.getLiving_arrangement_cd())) {
				Integer primaryApplicantIndvSeqNum = getPrimaryApplicantIndvSeqNum(appNumber);
				CP_APP_RGST_Collection contactColl = (CP_APP_RGST_Collection) pageCollection.get(CP_APP_RGST_COLL);

				CP_APP_RGST_Cargo contactDBCargo = contInfoBO.loadContactInformationforAppNum(appNumber, srcAppInd,
						primaryApplicantIndvSeqNum);
				if (contactDBCargo != null && null != contactColl && !contactColl.isEmpty()) {
					CP_APP_RGST_Cargo contactCargo = contactColl.getCargo(0);
					if (contactCargo != null) {
						contactCargo.setApp_num(appNumber);
						contactCargo.setIndv_seq_num(indvSeqNum);
						contactCargo.setSrc_app_ind(srcAppInd);
						saveMailingAdr(contactDBCargo, contactCargo);
						contactCargo.setHshl_l1_adr(contactDBCargo.getHshl_l1_adr());
						contactCargo.setHshl_l2_adr(contactDBCargo.getHshl_l2_adr());
						contactCargo.setHshl_city_adr(contactDBCargo.getHshl_city_adr());
						contactCargo.setCnty_num(contactDBCargo.getCnty_num());
						contactCargo.setHshl_sta_adr(contactDBCargo.getHshl_sta_adr());
						contactCargo.setHshl_zip_adr(contactDBCargo.getHshl_zip_adr());
						contactCargo.setHless_sw(contactDBCargo.getHless_sw());
						contInfoBO.storeContactInformation(contactCargo);
					}
				}
			} else {

				storeContactInformationAFB(fwTxn);
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.validateStoreCoDet() - END", fwTxn);
	}

	public void saveMailingAdr(CP_APP_RGST_Cargo contactDBCargo, CP_APP_RGST_Cargo contactCargo) {
		contactCargo.setAlt_st_adr(contactDBCargo.getAlt_st_adr());
		contactCargo.setAlt_l2_adr(contactDBCargo.getAlt_l2_adr());
		contactCargo.setAlt_city_adr(contactDBCargo.getAlt_city_adr());
		contactCargo.setAlt_sta_adr(contactDBCargo.getAlt_sta_adr());
		contactCargo.setAlt_zip_adr(contactDBCargo.getAlt_zip_adr());
		contactCargo.setAlt_l1_adr(contactDBCargo.getAlt_l1_adr());
	}

	/**
	 * Method store help with application.
	 *
	 * @param txnBean the txn bean @
	 */
	@Transactional
	public void storeHelpWithApplications(final FwTransaction txnBean) {

		System.currentTimeMillis();
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDemographicsService.storeHelpWithApplications() - START", txnBean);

			final Map request = txnBean.getRequest();
			final Map pageCollection = txnBean.getPageCollection();
			String appNumber = null;
			APP_FILE_HELP_Collection appHelpColl = null;
			APP_FILE_HELP_Cargo appHelpCargo = new APP_FILE_HELP_Cargo();
			FwMessageList validateInfo = null;

			appNumber = txnBean.getUserDetails().getAppNumber();
			if (pageCollection.containsKey(APP_FILE_HELP_COLL)) {
				appHelpColl = (APP_FILE_HELP_Collection) pageCollection.get(APP_FILE_HELP_COLL);
			}

			if ((appHelpColl != null) && !appHelpColl.isEmpty()) {
				appHelpCargo = appHelpColl.getCargo(0);
				validateInfo = helpBO.validateHelpWithApplication(appHelpCargo);
			}
			if (appNumber != null && Objects.nonNull(appHelpCargo)) {
				appHelpCargo.setApp_num(appNumber);
			}
			FwMessageList msgLst = new FwMessageList();

			if ((validateInfo != null) && validateInfo.hasMessages()) {

				request.put(FwConstants.MESSAGE_LIST, validateInfo);
				pageCollection.put(APP_FILE_HELP_COLL, appHelpColl);
				return;
			}

			// check and set default values
			validateStoreHelpWithApp(appNumber, appHelpColl, appHelpCargo);

			txnBean.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDemographicsService.storeHelpWithApplications() - END", txnBean);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.storeHelpWithApplications()", txnBean);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeHelpWithApplications",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

	}

	private void validateStoreHelpWithApp(String appNumber, APP_FILE_HELP_Collection appHelpColl,
			APP_FILE_HELP_Cargo appHelpCargo) {
		if (Objects.nonNull(appNumber) && Objects.nonNull(appHelpCargo)) {
			appHelpCargo.setApp_num(appNumber);
		}
		// added by EDSP-CP Team
		if (Objects.nonNull(appHelpCargo) && appHelpCargo.getHelp_indv_ind() != null) {
			appHelpCargo.setHelp_individual_cd(helpBO.getFilingRepresentativeCode(appHelpCargo.getHelp_indv_ind()));

		}

		String agencyNumberEntered = null;
		if (Objects.nonNull(appHelpCargo) && appHelpCargo.getAgcy_num() != null) {
			agencyNumberEntered = appHelpCargo.getAgcy_num().toString();
		}
		if ((Objects.nonNull(appHelpCargo) && agencyNumberEntered == null)
				|| FwConstants.EMPTY_STRING.equals(agencyNumberEntered)) {
			appHelpCargo.setAgcy_num(Integer.parseInt(FwConstants.ZERO));
		}

		helpBO.storeHelpWithApplication(appHelpColl);
		String checkOptionStr = null;
		if ((appHelpCargo != null) && (appHelpCargo.getHelp_indv_ind() != null)) {
			checkOptionStr = appHelpCargo.getHelp_indv_ind().toString();
		}
	}

	/**
	 * Method get help with applications.
	 *
	 * @param txnBean the txn bean
	 */
	@Transactional
	public void getHelpWithApplications(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getHelpWithApplications() - START", txnBean);
		try {
			final Map pageCollection = txnBean.getPageCollection();
			APP_FILE_HELP_Cargo helpCargo = null;
			final String appNum = txnBean.getUserDetails().getAppNumber();
			// application
			// number
			// from
			// session
			final APP_FILE_HELP_Collection helpColl = new APP_FILE_HELP_Collection();

			helpCargo = helpBO.loadHelpWithApplication(appNum);

			helpColl.addCargo(helpCargo);
			pageCollection.put(APP_FILE_HELP_COLL, helpColl);

			txnBean.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.getHelpWithApplications()", txnBean);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "getHelpWithApplications",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getHelpWithApplications() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				txnBean);

	}

	/**
	 * Absent Parent Load Method.
	 *
	 * @author - Numa Canedo
	 * @param txnBean the txn bean Creation Date Thu Sep 14 16:28:00 EDT 2015
	 */
	@Transactional
	public void getAbsentParentDetails(final FwTransaction fwTran) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.getAbsentParentDetails() - START", fwTran);

		final UserDetails userDetails = fwTran.getUserDetails();
		final Map pageCollection = fwTran.getPageCollection();

		List fatherMotherList = new ArrayList();

		String pageId = null;
		String previousPageId = null;
		String appNumber = null;
		String indvSeqNumber = null;
		String seqNumber = null;
		String absInd = null;
		int currentRecordIndex = 0;

		IndivTypeSeqBean detailKeyBean = null;

		boolean detailKeyBeanFlag = false;
		try {
			// ----------------------------------------------------------------------------------------------------
			// Get standard values
			// ----------------------------------------------------------------------------------------------------
			appNumber = userDetails.getAppNumber();

			pageId = fwTran.getCurrentActionDetails().getPageId();
			final APP_IN_PRFL_Collection sesAppInPrflColl = abAbsentParentBo.getAppInPrflCollection(appNumber);

			// getting program information -- start

			final short[] programKey = { 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
			// getting program information -- end

			// ----------------------------------------------------------------------------------------------------
			// Page loads for the first time
			// ----------------------------------------------------------------------------------------------------
			if (Objects.nonNull(pageId)) {
				// Fetch FatherMotherList from session
				fatherMotherList = abAbsentParentBo.loadAbsentParentDB(appNumber);
			} else // ----------------------------------------------------------------------------------------------------
					// Comming from the same page
					// ----------------------------------------------------------------------------------------------------
			if (pageCollection.containsKey(FwConstants.DETAIL_KEY_BEAN)) {
				// ----------------------------------------------------------------------------------------------------
				// Comming from previous button
				// ----------------------------------------------------------------------------------------------------
				detailKeyBeanFlag = true;
				detailKeyBean = (IndivTypeSeqBean) pageCollection.get(FwConstants.DETAIL_KEY_BEAN);
			}

			seqNumber = FwConstants.ONE;
			indvSeqNumber = FwConstants.ONE;

			// Load absent parent details from DB
			pageCollection.putAll(abAbsentParentBo.loadAbsentParentDetailsPageCollection(appNumber, indvSeqNumber,
					seqNumber, absInd));

			// ----------------------------------------------------------------------------------------------------
			// Setup Page Collection and Before Collection
			// ----------------------------------------------------------------------------------------------------
			pageCollection.put(FwConstants.RECORD_ARRAY, fatherMotherList); // THIS
			// ENABLES
			// PREVIOUS
			// NAVIGATION
			pageCollection.put(FwConstants.CURRENT_RECORD_INDEX, "" + currentRecordIndex);
			pageCollection.put("FatherMotherList", fatherMotherList);
			pageCollection.put(AppConstants.INDV_SEQUENCE_NUMBERS, indvSeqNumber);

			Individual indv = new Individual();
			indv.setFirstName("child");
			pageCollection.put("childIndv", indv);
			fwTran.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getAbsentParentDetails()", fwTran);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getAbsentParentDetails",
					fwTran.getUserDetails().getAppNumber(), fwTran.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getAbsentParentDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTran);
	}

	/**
	 * Method stores absent parent details.
	 *
	 * @param fwTran the txn bean
	 * 
	 */
	@Transactional
	public void storeAbsentParentDetails(final FwTransaction fwTran) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeAbsentParentDetails() - START", fwTran);
		final UserDetails userDetails = fwTran.getUserDetails();
		final PageActionDetails currentActionDetails = fwTran.getCurrentActionDetails();
		final Map pageCollection = fwTran.getPageCollection();
		FwMessageList validateInfo = null;
		List fatherMotherList = null;
		int currentRecordIndex = 0;

		String pageId = null;
		String appNumber = null;
		Map beforeColl = null;
		int currentPageStatus = 0;

		String indvSeqNumber = null;
		String apSeqNum = FwConstants.ZERO;
		boolean updatedDetailRecFlag = false;
		boolean pageComplete = false;

		// Collections
		APP_IN_ABSNP_Collection appInAbsColl = new APP_IN_ABSNP_Collection();
		APP_ABS_PRNT_Collection appAbsColl = new APP_ABS_PRNT_Collection();

		APP_IN_ABSNP_Cargo appInAbsCargo = new APP_IN_ABSNP_Cargo();
		APP_ABS_PRNT_Cargo appAbsCargo = new APP_ABS_PRNT_Cargo();

		try {
			// ----------------------------------------------------------------------------------------------------
			// Get standard values
			// ----------------------------------------------------------------------------------------------------
			pageId = currentActionDetails.getPageId();
			appNumber = userDetails.getAppNumber();
			beforeColl = fwTran.getPageCollection();

			fatherMotherList = (List) beforeColl.get("FatherMotherList");
			if (Objects.nonNull(beforeColl.get(FwConstants.CURRENT_RECORD_INDEX))) {
				currentRecordIndex = Integer.valueOf((String) beforeColl.get(FwConstants.CURRENT_RECORD_INDEX));
			}

			// ----------------------------------------------------------------------------------------------------
			// Fetch Collections and Cargos
			// ----------------------------------------------------------------------------------------------------
			// Get Absent Parent Before Collections

			// Get Absent Parent Collections
			if (null != pageCollection.get("APP_IN_ABSNP_Collection")) {
				appInAbsColl = (APP_IN_ABSNP_Collection) pageCollection.get("APP_IN_ABSNP_Collection");
			}
			if (null != pageCollection.get(APP_ABS_PRNT_COLL)) {
				appAbsColl = (APP_ABS_PRNT_Collection) pageCollection.get(APP_ABS_PRNT_COLL);
			}

			// Get Absent Parent Before Cargos

			// Get Absent Parent Cargos
			if (null != appInAbsColl && !appInAbsColl.isEmpty() && null != appInAbsColl.getCargo(0)) {
				appInAbsCargo = appInAbsColl.getCargo(0);
			}
			if (null != appAbsColl && !appAbsColl.isEmpty() && null != appAbsColl.getCargo(0)) {
				appAbsCargo = appAbsColl.getCargo(0);
			}

			// ----------------------------------------------------------------------------------------------------
			// Validate for null fields and prepare Cargo
			// ----------------------------------------------------------------------------------------------------
			appAbsCargo.setAppNum(appNumber);
			appAbsCargo.setRec_cplt_ind(Double.valueOf(FwConstants.ONE));

			if ((null != appAbsCargo.getAp_absn_dt()) && (Objects.nonNull(appAbsCargo.getAp_absn_dt()))) {
				appAbsCargo.setAp_absn_dt(Date.valueOf(getYYYYMMDDDate(appAbsCargo.getAp_absn_dt().toString())));
			} else {
				appAbsCargo.setAp_absn_dt(null);
			}
			if (null == appAbsCargo.getCaseGdcsClmSw()) {
				appAbsCargo.setCaseGdcsClmSw(FwConstants.SPACE);
			}
			if (Objects.isNull(appAbsCargo.getApSeqNum())) {
				appAbsCargo.setApSeqNum(0);
			}
			if ((null == appAbsCargo.getApSexInd()) || AppConstants.NULL_STRING.equals(appAbsCargo.getApSexInd())
					|| appAbsCargo.getApSexInd().isEmpty()) {
				appAbsCargo.setApSexInd(AppConstants.SEX_IND_UNKNOWN);
			}
			if ((null == appAbsCargo.getSrcAppInd()) || AppConstants.NULL_STRING.equals(appAbsCargo.getApSexInd())) {
				appAbsCargo.setSrcAppInd("AB");
			}

			// logic to identify value of Ap_sep_num
			List<APP_ABS_PRNT_Cargo> cargoTempLst = absentParentBo.loadAbsentParentDetails(appNumber,
					appAbsCargo.getSrcAppInd());
			if (Objects.nonNull(cargoTempLst) && !cargoTempLst.isEmpty()) {
				APP_ABS_PRNT_Cargo appAbsPrntCargoTemp = absentParentBo.loadAbsentParentDetails(appNumber,
						appAbsCargo.getApFstNam(), appAbsCargo.getApLastNam(), appAbsCargo.getApSexInd(),
						appAbsCargo.getSrcAppInd());
				if (Objects.nonNull(appAbsPrntCargoTemp)) {
					appAbsCargo.setApSeqNum(appAbsPrntCargoTemp.getApSeqNum());
				} else {
					int size = cargoTempLst.size();
					appAbsCargo.setApSeqNum(++size);
				}
			} else {
				appAbsCargo.setApSeqNum(Double.valueOf(FwConstants.ONE));
				updatedDetailRecFlag = true;
			}
			absentParentBo.storeAbsentParentDetails(appAbsCargo);

			// Update Seq Num to enable Previous Navigation for New Absent
			// Parents
			if ((null != fatherMotherList) && (!fatherMotherList.isEmpty())) {
				final IndivTypeSeqBean indivTypeSeqBean = (IndivTypeSeqBean) fatherMotherList.get(currentRecordIndex);

				if ((null == indivTypeSeqBean.getSeqNum()) || indivTypeSeqBean.getSeqNum().trim().isEmpty()
						|| "0".equals(indivTypeSeqBean.getSeqNum().trim())) {
					indivTypeSeqBean.setSeqNum(apSeqNum);

					fatherMotherList.set(currentRecordIndex, indivTypeSeqBean);
					beforeColl.put("FatherMotherList", fatherMotherList);
				}
			}

			// Insert Master Record
			if (updatedDetailRecFlag) {
				appInAbsCargo.setAppNum(appNumber);
				appInAbsCargo.setApSeqNum(Double.valueOf(apSeqNum));
				appInAbsCargo.setIndvSeqNum(Double.valueOf(FwConstants.ONE));
				appInAbsCargo.setPaterEstbSw(AppConstants.SPACE);
				appInAbsCargo.setRecCpltInd(Double.valueOf(FwConstants.ONE));

				absentParentBo.storeAbsentParentDetails(appInAbsCargo);
			}

		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeAbsentParentDetails",
					fwTran.getUserDetails().getAppNumber(), fwTran.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeAbsentParentDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTran);
	}

	/**
	 * Outputs the given String date mm/dd/yyyy in the format "yyyy-mm-dd"
	 */
	public String getYYYYMMDDDate(final String mmDdYyyy) {

		String result = "";
		// Get the values for the date, month and year from the given sql date
		if ((mmDdYyyy.length() == 10) && (mmDdYyyy.charAt(2) == '/')) {
			final String yyyy = mmDdYyyy.substring(6, 10);
			final String mm = mmDdYyyy.substring(0, 2);
			final String dd = mmDdYyyy.substring(3, 5);
			result = new StringBuilder(yyyy).append("-").append(mm).append("-").append(dd).toString();
			return result;
		} else {
			return mmDdYyyy;
		}

	}

	/**
	 * This method is used for getting the program information.
	 *
	 * @param txnBean the txn bean
	 */
	@Transactional

	public void getProgramInformation(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getProgramInformation() - START", txnBean);

		final Map request = txnBean.getRequest();

		Map pageCollection = null;
		final String appNumber = txnBean.getUserDetails().getAppNumber();
		Integer[] programKeyArray = null;
		java.util.Calendar coolingStart = java.util.Calendar.getInstance();
		java.util.Calendar coolingEnd = java.util.Calendar.getInstance();
		java.util.Calendar heatingStart = java.util.Calendar.getInstance();
		java.util.Calendar heatingEnd = java.util.Calendar.getInstance();
		java.util.Calendar crisisStart = java.util.Calendar.getInstance();
		java.util.Calendar crisisEnd = java.util.Calendar.getInstance();
		final java.util.Calendar calCurrent = java.util.Calendar.getInstance();
		APP_PGM_RQST_Cargo appPgmRqstBeforeCargo = null;
		APP_PGM_RQST_Collection appPgmRqstBeforeColl = (APP_PGM_RQST_Collection) programInfoBo.loadDetails(appNumber);
		if ((appPgmRqstBeforeColl != null) && (!appPgmRqstBeforeColl.isEmpty())) {
			appPgmRqstBeforeCargo = appPgmRqstBeforeColl.getCargo(0);
		} else {
			appPgmRqstBeforeCargo = null;
		}
		programKeyArray = setProgramKeyArray(appPgmRqstBeforeCargo);

		try {

			// now i am setting the values to the collection
			final APP_PGM_RQST_Collection appPgmRqstColl = new APP_PGM_RQST_Collection();
			final APP_PGM_RQST_Cargo appPgmRqstCargo = new APP_PGM_RQST_Cargo();
			appPgmRqstCargo.setApp_num(appNumber);
			appPgmRqstCargo.setFma_rqst_ind(programKeyArray[0]);
			appPgmRqstCargo.setFpw_rqst_ind(programKeyArray[1]);
			appPgmRqstCargo.setFs_rqst_ind(programKeyArray[2]);
			// VACMS start - converting FS to CC
			appPgmRqstCargo.setCc_rqst_ind(programKeyArray[8]);
			// VACMS end - converting FS to CC
			// EDSP CP Start - Initializing new programs and dates
			appPgmRqstCargo.setTanf_rqst_ind(programKeyArray[9]);
			appPgmRqstCargo.setCooling_assistance_rqst_ind(programKeyArray[10]);
			appPgmRqstCargo.setCrisis_assistance_rqst_ind(programKeyArray[11]);
			appPgmRqstCargo.setFuel_assistance_rqst_ind(programKeyArray[12]);
			appPgmRqstCargo.setNo_snap_rqst_ind(programKeyArray[13]);
			appPgmRqstCargo.setWic_rqst_ind(programKeyArray[14]);
			appPgmRqstCargo.setLiheap_rqst_ind(programKeyArray[15]);
			appPgmRqstCargo.setMagi_rqst_ind(programKeyArray[16]);
			appPgmRqstCargo.setPeach_rqst_ind(programKeyArray[17]);
			appPgmRqstCargo.setGgr_ind(programKeyArray[18]);

			// EDSP CP checking if the date is between the application dates for
			// Crisis,Fuel and Cooling
			// Programs

			coolingStart = getCalendar(iref.getColumnValue("TPAD", 951, "COOAS", "EN"));
			coolingEnd = getCalendar(iref.getColumnValue("TPAD", 952, "COOAS", "EN"));
			heatingStart = getCalendar(iref.getColumnValue("TPAD", 951, "FUEAS", "EN"));
			heatingEnd = getCalendar(iref.getColumnValue("TPAD", 952, "FUEAS", "EN"));
			crisisStart = getCalendar(iref.getColumnValue("TPAD", 951, "CRIAS", "EN"));
			crisisEnd = getCalendar(iref.getColumnValue("TPAD", 952, "CRIAS", "EN"));

			boolean iscurrdatewithincooling = false;
			boolean iscurrdatewithincrisis = false;
			boolean iscurrdatewithinfuel = false;
			if ((calCurrent.after(coolingStart) && calCurrent.before(coolingEnd)) || calCurrent.equals(coolingStart)
					|| calCurrent.equals(coolingEnd)) {

				iscurrdatewithincooling = true;
			}
			if ((calCurrent.after(crisisStart) && calCurrent.before(crisisEnd)) || calCurrent.equals(crisisStart)
					|| calCurrent.equals(crisisEnd)) {

				iscurrdatewithincrisis = true;
			}
			if ((calCurrent.after(heatingStart) && calCurrent.before(heatingEnd)) || calCurrent.equals(heatingStart)
					|| calCurrent.equals(heatingEnd)) {

				iscurrdatewithinfuel = true;
			}

			// EDSP CP End - Initializing new programs and dates

			appPgmRqstColl.add(appPgmRqstCargo);
			pageCollection = new HashMap();
			pageCollection.put(APP_PGM_RQST_COLL, appPgmRqstColl);

			// now i am getting the months

			final APP_RQST_Collection appRqstColl = programInfoBo.loadProgramInformation(appNumber);

			// Loading Medicaid months
			pageCollection.put("MA_BACK_DTD_MTS", dateRoutine.getBackDatedMonths(fwDate.getDate()));
			if ((appRqstColl != null) && (!appRqstColl.isEmpty())) {
				final APP_RQST_Cargo appRqstCargo = appRqstColl.getCargo(0);
				final int currentMonth = fwDate.getMonth(fwDate.getDate());
				int startDateMonth = 0;

				if (appRqstCargo.getApp_strt_tms() != null) {
					startDateMonth = fwDate
							.getMonth(dateRoutine.getDateFromTimeStamp(appRqstCargo.getUpdt_dt().toString()));
				} else {
					startDateMonth = currentMonth;
				}
				if (startDateMonth != currentMonth) {
					appRqstCargo.setMa_backdt_mo_1_ind(Integer.parseInt(FwConstants.ZERO));
					appRqstCargo.setMa_backdt_mo_2_ind(Integer.parseInt(FwConstants.ZERO));
					appRqstCargo.setMa_backdt_mo_3_ind(Integer.parseInt(FwConstants.ZERO));
				}
				pageCollection.put("APP_RQST_Collection", appRqstColl);
			}

			txnBean.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getProgramInformation()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getProgramInformation",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getProgramInformation() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				txnBean);
	}

	/**
	 * Creates a <code>Calendar</code> object from the date passed in
	 * <code>mm/dd/yyyy</code> format.
	 *
	 * @param date the date
	 * @return the calendar
	 */
	private java.util.Calendar getCalendar(final String date) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.getCalendar() - START");
		final java.util.Calendar cal = java.util.Calendar.getInstance();
		int year = 0;
		int month = 0;
		int day = 0;
		String[] tempDate;

		if (date != null) {
			tempDate = date.split("/");
			if ((tempDate != null) && (tempDate.length > 2)) {
				month = Integer.parseInt(tempDate[0]);
				// Java MONTH starts from 0
				if (month > 0) {
					month = month - 1;
				}
				day = Integer.parseInt(tempDate[1]);
				year = Integer.parseInt(tempDate[2]);
			}
		}

		cal.set(year, month, day);

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getCalendar() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);
		return cal;
	}

	/**
	 * Method store program inforamtion.
	 *
	 * @param txnBean the txn bean @
	 */
	@Transactional
	public void storeProgramInformation(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeProgramInformation() - START", txnBean);
		// final Map session = txnBean.getSession();
		final Map request = txnBean.getRequest();
		final Map pageCollection = txnBean.getPageCollection();
		// final Map httpSessionMap = (Map) session.get(FwConstants.HTTP_SESSION);

		FwMessageList validateInfo = new FwMessageList();
		int[] driverArray = null;
		String appNumber = null;
		Map beforeMap = new HashMap();
		APP_PGM_RQST_Cargo appPgmRqstCargo = new APP_PGM_RQST_Cargo();
		APP_PGM_RQST_Cargo appPgmRqstBeforeCargo = new APP_PGM_RQST_Cargo();
		APP_PGM_RQST_Collection appPgmRqstColl = null;
		APP_RQST_Collection appRqstColl = null;
		APP_RQST_Cargo appRqstCargo = null;
		APP_RQST_Cargo appRqstBeforeCargo = null;
		APP_RGST_Collection appRgstAfterColl = null;
		APP_RGST_Cargo appRgstAfterCargo = null;
		CP_APP_RGST_Collection addressColl = null;
		appNumber = txnBean.getUserDetails().getAppNumber();
		APP_RQST_Collection appRqstBeforeColl = (APP_RQST_Collection) programInfoBo.loadAllDetails(appNumber);
		APP_PGM_RQST_Collection appPgmRqstBeforeColl = (APP_PGM_RQST_Collection) programInfoBo.loadDetails(appNumber);
		Integer[] programKeyArray = null;
		int currentPageStatus = 0;
		try {

			if (pageCollection.get(APP_PGM_RQST_COLL) != null) {
				appPgmRqstColl = (APP_PGM_RQST_Collection) pageCollection.get(APP_PGM_RQST_COLL);
				appPgmRqstCargo = appPgmRqstColl.getCargo(0);
				if (appPgmRqstCargo.getFs_rqst_ind() == null) {
					appPgmRqstCargo.setFs_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				// VACMS start - converting FS to CC
				if (appPgmRqstCargo.getCc_rqst_ind() == null) {
					appPgmRqstCargo.setCc_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				// VACMS end - converting FS to CC
				if (appPgmRqstCargo.getFpw_rqst_ind() == null) {
					appPgmRqstCargo.setFpw_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if (appPgmRqstCargo.getFma_rqst_ind() == null) {
					appPgmRqstCargo.setFma_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				// EDSP CP start - Setting null values of request indicators to
				// FwConstants . ZERO
				if (appPgmRqstCargo.getFpw_rqst_ind() == null) {
					appPgmRqstCargo.setFpw_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if (appPgmRqstCargo.getCooling_assistance_rqst_ind() == null) {
					appPgmRqstCargo.setCooling_assistance_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if (appPgmRqstCargo.getFuel_assistance_rqst_ind() == null) {
					appPgmRqstCargo.setFuel_assistance_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if (appPgmRqstCargo.getNo_snap_rqst_ind() == null) {
					appPgmRqstCargo.setNo_snap_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if (appPgmRqstCargo.getTanf_rqst_ind() == null) {
					appPgmRqstCargo.setTanf_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if (appPgmRqstCargo.getWic_rqst_ind() == null) {
					appPgmRqstCargo.setWic_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if (appPgmRqstCargo.getCrisis_assistance_rqst_ind() == null) {
					appPgmRqstCargo.setCrisis_assistance_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if (appPgmRqstCargo.getWic_rqst_ind() == null) {
					appPgmRqstCargo.setWic_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if (appPgmRqstCargo.getMagi_rqst_ind() == null) {
					appPgmRqstCargo.setMagi_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if (appPgmRqstCargo.getPeach_rqst_ind() == null) {
					appPgmRqstCargo.setPeach_rqst_ind(Integer.parseInt(FwConstants.ZERO));
				}
				if(appPgmRqstCargo.getGgr_ind() == null) {
					appPgmRqstCargo.setGgr_ind(Integer.parseInt(FwConstants.ZERO));
				}

				if (pageCollection.containsKey(AppConstants.FLOW_MODE) && ((AppConstants.DCF_FLOW)
						.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString()))) {
					appPgmRqstCargo.setDcalfresh_request_ind(HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED);
				}

				appPgmRqstCargo.setApp_num(appNumber);

			}
			if (pageCollection.containsKey("APP_RQST_Collection")) {
				appRqstColl = (APP_RQST_Collection) pageCollection.get("APP_RQST_Collection");
				appRqstCargo = appRqstColl.getCargo(0);
			}
			if (pageCollection.containsKey(APP_RGST_COLL)) {
				appRgstAfterColl = (APP_RGST_Collection) pageCollection.get(APP_RGST_COLL);
				appRgstAfterCargo = appRgstAfterColl.getCargo(0);
				appRgstAfterCargo.setApp_num(appNumber);
			}
			// CSPM-15590: added this line to check for address cargo
			if (pageCollection.containsKey(CP_APP_RGST_COLL)) {
				addressColl = (CP_APP_RGST_Collection) pageCollection.get(CP_APP_RGST_COLL);
				CP_APP_RGST_Cargo cargo = addressColl.getCargo(0);
				String indv_seq_num = (String) pageCollection.get("indvId");
				if (cargo != null) {
					cargo.setApp_num(appNumber);

					cargo.setSrc_app_ind("AB");
					try {

						if (indv_seq_num != null) {
							cargo.setIndv_seq_num(Integer.parseInt(indv_seq_num));
						}
						contInfoBO.storeContactInformation(cargo);
					} catch (Exception e) {
						FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error in parsing Indv Seq Number", e);
					}
				}
			}

			// before storing the values in the database we need to do the cargo
			// Comparison
			boolean programAddedFlag = false;
			if ((appPgmRqstBeforeColl != null) && (!appPgmRqstBeforeColl.isEmpty())) {
				appPgmRqstBeforeCargo = appPgmRqstBeforeColl.getCargo(0);
				if (!appPgmRqstCargo.getFma_rqst_ind().equals(appPgmRqstBeforeCargo.getFma_rqst_ind())
						&& HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getFma_rqst_ind())) {
					programAddedFlag = true;
				}
				if (!appPgmRqstCargo.getFpw_rqst_ind().equals(appPgmRqstBeforeCargo.getFpw_rqst_ind())
						&& HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getFpw_rqst_ind())) {
					programAddedFlag = true;
				}
				if (!appPgmRqstCargo.getFs_rqst_ind().equals(appPgmRqstBeforeCargo.getFs_rqst_ind())
						&& HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getFs_rqst_ind())) {
					programAddedFlag = true;
				}

				if (!appPgmRqstCargo.getCc_rqst_ind().equals(appPgmRqstBeforeCargo.getCc_rqst_ind())
						&& HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getCc_rqst_ind())) {
					programAddedFlag = true;
				}
				if (!appPgmRqstCargo.getCooling_assistance_rqst_ind()
						.equals(appPgmRqstBeforeCargo.getCooling_assistance_rqst_ind())
						&& HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED
								.equals(appPgmRqstCargo.getCooling_assistance_rqst_ind())) {
					programAddedFlag = true;
				}
				if (!appPgmRqstCargo.getCrisis_assistance_rqst_ind()
						.equals(appPgmRqstBeforeCargo.getCrisis_assistance_rqst_ind())
						&& HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED
								.equals(appPgmRqstCargo.getCrisis_assistance_rqst_ind())) {
					programAddedFlag = true;
				}
				if (!appPgmRqstCargo.getFuel_assistance_rqst_ind()
						.equals(appPgmRqstBeforeCargo.getFuel_assistance_rqst_ind())
						&& HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED
								.equals(appPgmRqstCargo.getFuel_assistance_rqst_ind())) {
					programAddedFlag = true;
				}
				if (!appPgmRqstCargo.getTanf_rqst_ind().equals(appPgmRqstBeforeCargo.getTanf_rqst_ind())
						&& HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getTanf_rqst_ind())) {
					programAddedFlag = true;
				}
				if (!appPgmRqstCargo.getWic_rqst_ind().equals(appPgmRqstBeforeCargo.getWic_rqst_ind())
						&& HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getWic_rqst_ind())) {
					programAddedFlag = true;
				}
				if (!appPgmRqstCargo.getGgr_ind().equals(appPgmRqstBeforeCargo.getGgr_ind())
						&& HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getGgr_ind())) {
					programAddedFlag = true;
				}

			}

			if (programAddedFlag) {
				if (request.get("InformationalMessage") != null) {
					programAddedFlag = false;
				} else {
					request.put("InformationalMessage", FwConstants.YES);
				}
			}

			/* Community Partner Logic based on profile */
			String adminIndicator = AppConstants.EMPTY_STRING;
			boolean isHideFma = false;

			final String lang = (String) request.get(AppConstants.LANGUAGE);
			final IPage ipage = FwPageManager.createInstance();
			Map pgmDplyMap = programInfoBo.getPgmDplyMap(iref);
			Map ccPrescreenMap = (request.get(AppConstants.CC_PRESCREEN_MAP) != null
					? (Map) request.get(AppConstants.CC_PRESCREEN_MAP)
					: new HashMap<>());
			validateInfo = programInfoBo.validateProgramSelection(appPgmRqstCargo, programAddedFlag, appRqstCargo,
					appRgstAfterCargo, lang, isHideFma, (Map) request.get("CMB_PRGM_CD"), pgmDplyMap,
					ccPrescreenMap.isEmpty());

			if ((validateInfo != null) && validateInfo.hasMessages()) {
				final String reqWarningMsgs = (String) request.get(FwConstants.WARNING_MSG_DETAILS);
				boolean checkWaringMessages = false;
				int count = 0;

				if (StringUtils.isNotBlank(reqWarningMsgs)) {
					ArrayList fwMessageList = validateInfo.getMessageList();

					String[] temp = reqWarningMsgs.split("~");

					for (int a = 0; a < fwMessageList.size(); a++) {
						FwMessage fwMessage = (FwMessage) fwMessageList.get(a);
						for (int i = 0; i < temp.length; i++) {
							if (temp[i].toString().equals(fwMessage.getMessageCode().toString())) {
								count++;
							}
						}
					}

					if (temp.length == count && validateInfo.getMessageListSize() > count) {
						checkWaringMessages = true;
					}
				}

				if (!checkForWarningMesgs(reqWarningMsgs, programInfoBo.getMessageList()) || checkWaringMessages) {

					request.put(FwConstants.MESSAGE_LIST, validateInfo);
					appRqstColl = new APP_RQST_Collection();
					appRqstColl.add(appRqstCargo);
					pageCollection.put("MA_BACK_DTD_MTS", beforeMap.get("MA_BACK_DTD_MTS"));
					pageCollection.put(APP_PGM_RQST_COLL, appPgmRqstColl);
					pageCollection.put("APP_RQST_Collection", appRqstColl);
					pageCollection.put(APP_RGST_COLL, appRgstAfterColl);
					pageCollection.put(CP_APP_RGST_COLL, addressColl);
					return;
				}
			}

			if ((appPgmRqstBeforeColl != null) && (!appPgmRqstBeforeColl.isEmpty())) {
				appPgmRqstBeforeCargo = appPgmRqstBeforeColl.getCargo(0);
			} else {
				appPgmRqstBeforeCargo = null;
			}
			programKeyArray = setProgramKeyArray(appPgmRqstBeforeCargo);

			boolean fsRequested = false;
			boolean ccRequested = false;
			boolean ccDeRequested = false;
			boolean fmaRequested = false;
			boolean fmaDeRequested = false;
			boolean tanfRequested = false;
			boolean wicRequested = false;
			if ((appPgmRqstBeforeColl != null) && (!appPgmRqstBeforeColl.isEmpty())) {
				appPgmRqstBeforeCargo = appPgmRqstBeforeColl.getCargo(0);
				// Get Program Key Array from DB

				appPgmRqstCargo = (APP_PGM_RQST_Cargo) isChanged(appPgmRqstBeforeCargo, appPgmRqstCargo);
				if (appPgmRqstCargo != null && appPgmRqstCargo.isDirty()) {
					if (!appPgmRqstCargo.getFma_rqst_ind().equals(appPgmRqstBeforeCargo.getFma_rqst_ind())) {
						if (Objects.nonNull(appPgmRqstCargo.getFma_rqst_ind()) && AppConstants.PROGRAM_NOT_SELECTED
								.equals(appPgmRqstCargo.getFma_rqst_ind().toString())) {
							programInfoBo.removeProgram(appNumber, FwConstants.FMA_INDEX, programKeyArray);
							fmaDeRequested = true;
						} else {
							programInfoBo.addProgram(appNumber, FwConstants.FMA_INDEX, programKeyArray);
							fmaRequested = true;
						}
					}

					if (!appPgmRqstCargo.getFs_rqst_ind().equals(appPgmRqstBeforeCargo.getFs_rqst_ind())) {
						if (Objects.nonNull(appPgmRqstCargo.getFs_rqst_ind()) && AppConstants.PROGRAM_NOT_SELECTED
								.equals(appPgmRqstCargo.getFs_rqst_ind().toString())) {
							programInfoBo.removeProgram(appNumber, FwConstants.FS_INDEX, programKeyArray);
						} else {
							programInfoBo.addProgram(appNumber, FwConstants.FS_INDEX, programKeyArray);
							fsRequested = true;
						}
					}

					if (!appPgmRqstCargo.getTanf_rqst_ind().equals(appPgmRqstBeforeCargo.getTanf_rqst_ind())) {
						if (Objects.nonNull(appPgmRqstCargo.getTanf_rqst_ind()) && AppConstants.PROGRAM_NOT_SELECTED
								.equals(appPgmRqstCargo.getTanf_rqst_ind().toString())) {
							programInfoBo.removeProgram(appNumber, FwConstants.TANF_INDEX, programKeyArray);
						} else {
							programInfoBo.addProgram(appNumber, FwConstants.TANF_INDEX, programKeyArray);
							tanfRequested = true;
						}
					}
					
					if (!appPgmRqstCargo.getGgr_ind().equals(appPgmRqstBeforeCargo.getGgr_ind())) {
						if (Objects.nonNull(appPgmRqstCargo.getGgr_ind()) && AppConstants.PROGRAM_NOT_SELECTED
								.equals(appPgmRqstCargo.getGgr_ind().toString())) {
							programInfoBo.removeProgram(appNumber, FwConstants.GGR_INDEX, programKeyArray);
						} else {
							programInfoBo.addProgram(appNumber, FwConstants.GGR_INDEX, programKeyArray);
						}
					}

				}
			}

			else {
				if (appPgmRqstCargo != null) {
					if (HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getFma_rqst_ind())) {
						programInfoBo.addProgram(appNumber, FwConstants.FMA_INDEX, programKeyArray);
						fmaRequested = true;
					}

					if (HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getFs_rqst_ind())) {
						programInfoBo.addProgram(appNumber, FwConstants.FS_INDEX, programKeyArray);
						fsRequested = true;
					}

					if (HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getTanf_rqst_ind())) {
						programInfoBo.addProgram(appNumber, FwConstants.TANF_INDEX, programKeyArray);
						tanfRequested = true;
					}
					
					if (HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPgmRqstCargo.getGgr_ind())) {
						programInfoBo.addProgram(appNumber, FwConstants.GGR_INDEX, programKeyArray);
					}

				}
			}

			cpAppPgmRqstRepository.save(appPgmRqstCargo);

			if ((appRqstColl != null) && (appRqstCargo != null)) {
				if (appRqstCargo.getMa_backdt_mo_1_ind() != HouseHoldDemoGraphicsConstants.ZERO) {
					appRqstCargo.setMa_backdt_mo_1_ind(HouseHoldDemoGraphicsConstants.ONE);
				} else {
					appRqstCargo.setMa_backdt_mo_1_ind(HouseHoldDemoGraphicsConstants.ZERO);
				}
				if (appRqstCargo.getMa_backdt_mo_2_ind() != HouseHoldDemoGraphicsConstants.ZERO) {
					appRqstCargo.setMa_backdt_mo_2_ind(HouseHoldDemoGraphicsConstants.ONE);
				} else {
					appRqstCargo.setMa_backdt_mo_2_ind(HouseHoldDemoGraphicsConstants.ZERO);
				}
				if (appRqstCargo.getMa_backdt_mo_3_ind() != HouseHoldDemoGraphicsConstants.ZERO) {
					appRqstCargo.setMa_backdt_mo_3_ind(HouseHoldDemoGraphicsConstants.ONE);
				} else {
					appRqstCargo.setMa_backdt_mo_3_ind(HouseHoldDemoGraphicsConstants.ZERO);
				}
			}

			// storing App reg data
			if (appRgstAfterCargo != null) {
				APP_RGST_Collection appRgstStoreColl = new APP_RGST_Collection();
				APP_RGST_Cargo appRegStoreCargo = new APP_RGST_Cargo();
				appRegStoreCargo.setApp_num(appNumber);
				appRegStoreCargo.setWic_dsclsr(appRgstAfterCargo.getWic_dsclsr());
				// defaults
				appRegStoreCargo.setHshl_indv_ct(Integer.parseInt(FwConstants.ZERO));
				appRegStoreCargo.setRec_cplt_ind(Integer.parseInt(FwConstants.ZERO));
				appRegStoreCargo.setPref_cntc_ind(Integer.parseInt(FwConstants.ZERO));
				appRegStoreCargo.setDays_at_address_num(Integer.parseInt(FwConstants.ZERO));
				appRegStoreCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				appRegStoreCargo.setHshl_city_adr(FwConstants.SPACE);
				appRegStoreCargo.setHshl_sta_adr(FwConstants.SPACE);

				appRegStoreCargo.setRowAction(FwConstants.ROWACTION_INSERT);
				appRgstStoreColl.add(appRegStoreCargo);
				programInfoBo.storeDBData(appRgstStoreColl);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeProgramInformation()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeProgramInformation",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeProgramInformation() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				txnBean);
	}

	public Integer[] setProgramKeyArray(APP_PGM_RQST_Cargo appPgmRqstBeforeCargo) {
		final Integer[] programKeyArray = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
		if (appPgmRqstBeforeCargo != null) {
			programKeyArray[0] = appPgmRqstBeforeCargo.getFma_rqst_ind() != null
					? appPgmRqstBeforeCargo.getFma_rqst_ind()
					: 0;
			programKeyArray[1] = appPgmRqstBeforeCargo.getFpw_rqst_ind() != null
					? appPgmRqstBeforeCargo.getFpw_rqst_ind()
					: 0;
			programKeyArray[2] = appPgmRqstBeforeCargo.getFs_rqst_ind() != null ? appPgmRqstBeforeCargo.getFs_rqst_ind()
					: 0;
			programKeyArray[3] = (Integer) 0;
			programKeyArray[4] = appPgmRqstBeforeCargo.getEbd_rqst_ind() != null
					? appPgmRqstBeforeCargo.getEbd_rqst_ind()
					: 0;
			programKeyArray[5] = appPgmRqstBeforeCargo.getSer_rqst_ind() != null
					? appPgmRqstBeforeCargo.getSer_rqst_ind()
					: 0;
			programKeyArray[6] = (Integer) 0;
			programKeyArray[7] = (Integer) 0;
			programKeyArray[8] = appPgmRqstBeforeCargo.getCc_rqst_ind() != null ? appPgmRqstBeforeCargo.getCc_rqst_ind()
					: 0;
			programKeyArray[9] = appPgmRqstBeforeCargo.getTanf_rqst_ind() != null
					? appPgmRqstBeforeCargo.getTanf_rqst_ind()
					: 0;
			programKeyArray[10] = appPgmRqstBeforeCargo.getCooling_assistance_rqst_ind() != null
					? appPgmRqstBeforeCargo.getCooling_assistance_rqst_ind()
					: 0;
			programKeyArray[11] = appPgmRqstBeforeCargo.getCrisis_assistance_rqst_ind() != null
					? appPgmRqstBeforeCargo.getCrisis_assistance_rqst_ind()
					: 0;
			programKeyArray[12] = appPgmRqstBeforeCargo.getFuel_assistance_rqst_ind() != null
					? appPgmRqstBeforeCargo.getFuel_assistance_rqst_ind()
					: 0;
			programKeyArray[13] = appPgmRqstBeforeCargo.getNo_snap_rqst_ind() != null
					? appPgmRqstBeforeCargo.getNo_snap_rqst_ind()
					: 0;
			programKeyArray[14] = appPgmRqstBeforeCargo.getWic_rqst_ind() != null
					? appPgmRqstBeforeCargo.getWic_rqst_ind()
					: 0;
			programKeyArray[15] = appPgmRqstBeforeCargo.getLiheap_rqst_ind() != null
					? appPgmRqstBeforeCargo.getLiheap_rqst_ind()
					: 0;
			programKeyArray[16] = appPgmRqstBeforeCargo.getMagi_rqst_ind() != null
					? appPgmRqstBeforeCargo.getMagi_rqst_ind()
					: 0;
			programKeyArray[17] = appPgmRqstBeforeCargo.getPeach_rqst_ind() != null
					? appPgmRqstBeforeCargo.getPeach_rqst_ind()
					: 0;
			programKeyArray[18] = appPgmRqstBeforeCargo.getGgr_ind() != null
							? appPgmRqstBeforeCargo.getGgr_ind()
							: 0;		
		}

		return programKeyArray;
	}

	protected ICargo isChanged(final ICargo aBeforeCargo, final ICargo aAfterCargo) throws FwException {

		try {
			if (aBeforeCargo == aAfterCargo) {
				aAfterCargo.setDirty(false);
			} else {

				if (null != aAfterCargo) {
					if ((aBeforeCargo == null) || (aBeforeCargo.hashCode() != aAfterCargo.hashCode())) {
						aAfterCargo.setDirty(true);
					} else
						aAfterCargo.setDirty(false);
				}
			}
			return aAfterCargo;
		} catch (final FwException fe) {
			throw fe;

		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * This method checks for warning messages that has been already displayed in
	 * the jsp.
	 *
	 * @author govinpr
	 * @param reqWarningMsg the req warning msg
	 * @param messageList   gov.state.nextgen.framework.management.messages.FwMessageList
	 * @return messageFlag boolean
	 */
	public boolean checkForWarningMesgs(final String reqWarningMsg, final FwMessageList messageList) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.checkForWarningMesgs() - START");

		try {
			// Code to check for Warning Messages
			boolean noValidation = false;
			if ((reqWarningMsg != null) && (reqWarningMsg.trim().length() > 0)) {
				int messageListSize = validateMsgList(messageList);
				final List warningMsgList = new ArrayList();
				// Collecting warning message in a list. Return false, if the
				// message list has other than warning message
				if (messageList != null && messageListSize > 0) {
					for (int i = 0; i < messageListSize; i++) {
						if (AppConstants.WARNING.equals(messageList.getMessageAtIndex(i).getMessageSeverity())) {
							warningMsgList.add(messageList.getMessageAtIndex(i).getMessageCode());
						} else {
							return noValidation;
						}
					}
				}
				noValidation = validateData(reqWarningMsg, noValidation, warningMsgList);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDemographicsService.checkForWarningMesgs() - END");
			return noValidation;
		} catch (final Exception e) {
			throw e;
		}
	}

	private int validateMsgList(final FwMessageList messageList) {
		int messageListSize = 0;
		if (messageList != null) {
			messageListSize = messageList.getMessageListSize();
		}
		return messageListSize;
	}

	private boolean validateData(final String reqWarningMsg, boolean noValidation, final List warningMsgList) {
		final List reqMsgList = addReqMsgList(reqWarningMsg);
		final int warningMsgListSize = warningMsgList.size();
		final int reqMsgListSize = reqMsgList.size();
		for (int r = 0; r < reqMsgListSize; r++) {
			noValidation = validateReqMsgList(noValidation, warningMsgList, reqMsgList, warningMsgListSize, r);
		}
		return noValidation;
	}

	private List addReqMsgList(final String reqWarningMsg) {
		final StringTokenizer tokenizer = new StringTokenizer(reqWarningMsg, TILDE);
		final List reqMsgList = new ArrayList();
		while (tokenizer.hasMoreElements()) {
			reqMsgList.add(tokenizer.nextElement());
		}
		return reqMsgList;
	}

	private boolean validateReqMsgList(boolean noValidation, final List warningMsgList, final List reqMsgList,
			final int warningMsgListSize, int r) {
		final String msgStr = reqMsgList.get(r).toString();
		for (int w = 0; w < warningMsgListSize; w++) {
			final String warMsgStr = warningMsgList.get(w).toString();
			if (warMsgStr.equals(msgStr)) {
				noValidation = true;
				break;
			}
			if (noValidation) {
				break;
			}
		}
		return noValidation;
	}

	/**
	 * Gets the authorized representative details.
	 *
	 * @param txnBean the txn bean
	 */
	@Transactional
	public void getAuthorizedRepresentativeDetails(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getAuthorizedRepresentativeDetails() - START", txnBean);
		try {
			final int seq_num = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			final Map pageCollection = txnBean.getPageCollection();
			CP_APP_AUTH_REP_Collection cpAppAuthRepColl = new CP_APP_AUTH_REP_Collection();
			final String appNum = txnBean.getUserDetails().getAppNumber();

			cpAppAuthRepColl = abAuthorizedRepresentativeBO.loadAuthorizedRepresentativeInformation(appNum, seq_num,
					"CF");

			pageCollection.put(CP_APP_AUTH_REP_COLL, cpAppAuthRepColl);
			txnBean.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, LOAD_MILITARY_INFO_ERROR, txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(),
					"getAuthorizedRepresentativeDetails", txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getAuthorizedRepresentativeDetails() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				txnBean);

	}

	/**
	 * Store authorized representative details.
	 *
	 * @param txnBean the txn bean
	 */
	@Transactional
	public void storeAuthorizedRepresentativeDetails(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeAuthorizedRepresentativeDetails() - START", txnBean);
		try {

			final Map request = txnBean.getRequest();
			final Map pageCollection = txnBean.getPageCollection();
			FwMessageList validateInfo = null;

			final String appNumber = txnBean.getUserDetails().getAppNumber();
			final String src_app_ind = "AB";

			final int seq_num = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			final CP_APP_AUTH_REP_Collection cpAppAuthRepColl = (CP_APP_AUTH_REP_Collection) pageCollection
					.get(CP_APP_AUTH_REP_COLL);
			CP_APP_AUTH_REP_Cargo cpAppAuthRepCargo = cpAppAuthRepColl.getCargo(0);

			CP_APP_AUTH_REP_Collection cpAppAuthRepBeforeColl = abAuthorizedRepresentativeBO.loadDetails(appNumber,
					seq_num, HouseHoldDemoGraphicsConstants.CALFRESH_ABBREV);
			CP_APP_AUTH_REP_Cargo cpAppAuthRepBeforeCargo = new CP_APP_AUTH_REP_Cargo();

			if ((cpAppAuthRepBeforeColl != null) && !cpAppAuthRepBeforeColl.isEmpty()
					&& (cpAppAuthRepBeforeColl.getCargo(0) != null)) {
				cpAppAuthRepBeforeCargo = cpAppAuthRepBeforeColl.getCargo(0);
				cpAppAuthRepBeforeCargo.setApp_num(appNumber);
			}

			validateInfo = abAuthorizedRepresentativeBO.validateAuthorizedRepresentativeInformation(cpAppAuthRepCargo,
					FwConstants.EMPTY_STRING, request);
			if ((validateInfo != null) && validateInfo.hasMessages()) {
				request.put(FwConstants.MESSAGE_LIST, validateInfo);
				pageCollection.put(CP_APP_AUTH_REP_COLL, cpAppAuthRepColl);
				return;
			}

			if ((cpAppAuthRepBeforeColl != null) && (!cpAppAuthRepBeforeColl.isEmpty())) {

				cpAppAuthRepBeforeCargo.setAuth_rep_fst_nam(null == cpAppAuthRepCargo.getAuth_rep_fst_nam()
						|| (cpAppAuthRepCargo.getAuth_rep_fst_nam().isEmpty()) ? null
								: cpAppAuthRepCargo.getAuth_rep_fst_nam());
				cpAppAuthRepBeforeCargo.setAuth_rep_last_nam(null == cpAppAuthRepCargo.getAuth_rep_last_nam()
						|| (cpAppAuthRepCargo.getAuth_rep_last_nam().isEmpty()) ? null
								: cpAppAuthRepCargo.getAuth_rep_last_nam());
				cpAppAuthRepBeforeCargo.setPhn_num(
						null == cpAppAuthRepCargo.getPhn_num() || (cpAppAuthRepCargo.getPhn_num().isEmpty()) ? null
								: cpAppAuthRepCargo.getPhn_num());
				cpAppAuthRepBeforeCargo.setL1_adr(
						null == cpAppAuthRepCargo.getL1_adr() || (cpAppAuthRepCargo.getL1_adr().isEmpty()) ? null
								: cpAppAuthRepCargo.getL1_adr());
				cpAppAuthRepBeforeCargo.setL2_adr(
						null == cpAppAuthRepCargo.getL2_adr() || (cpAppAuthRepCargo.getL2_adr().isEmpty()) ? null
								: cpAppAuthRepCargo.getL2_adr());
				cpAppAuthRepBeforeCargo.setCity_adr(
						null == cpAppAuthRepCargo.getCity_adr() || (cpAppAuthRepCargo.getCity_adr().isEmpty()) ? null
								: cpAppAuthRepCargo.getCity_adr());
				cpAppAuthRepBeforeCargo.setSta_adr(
						null == cpAppAuthRepCargo.getSta_adr() || (cpAppAuthRepCargo.getSta_adr().isEmpty()) ? null
								: cpAppAuthRepCargo.getSta_adr());
				cpAppAuthRepBeforeCargo.setZip_adr(
						null == cpAppAuthRepCargo.getZip_adr() || (cpAppAuthRepCargo.getZip_adr().isEmpty()) ? null
								: cpAppAuthRepCargo.getZip_adr());

				abAuthorizedRepresentativeBO.storeAuthorizedRepresentativeDetails(cpAppAuthRepBeforeCargo);

			} else {
				cpAppAuthRepCargo.setApp_num(appNumber);
				cpAppAuthRepCargo.setSeq_num(seq_num);
				cpAppAuthRepCargo.setSrc_app_ind(src_app_ind);
				cpAppAuthRepCargo.setRep_code("CF");
				abAuthorizedRepresentativeBO.storeAuthorizedRepresentativeDetails(cpAppAuthRepCargo);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeAuthorizedRepresentativeDetails()",
					txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(),
					"storeAuthorizedRepresentativeDetails", txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeAuthorizedRepresentativeDetails() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				txnBean);

	}

	private void displayProgramSpecificInfo(Integer[] programKeyArray, Map pageCollection) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldInfoEJBBean.displayProgramSpecificInfo() - START");
		try {
			boolean isFMARequestedFlag = false;
			boolean isCCRequestedFlag = false;
			boolean isSNAPRequestedFlag = false;
			boolean isTANFRequestedFlag = false;
			boolean isEARequestedFlag = false;
			final List cmpList = (ArrayList) pageCollection.get("PAGE_COMPONENT_LIST");
			if (isThisProgramRequested(programKeyArray, FwConstants.CC_INDEX)) {
				pageCollection.put("CC_FLAG", true);
				isCCRequestedFlag = true;
			}
			if (isThisProgramRequested(programKeyArray, FwConstants.WIC_INDEX)) {
				pageCollection.put("WIC_FLAG", true);
			}
			if (isThisProgramRequested(programKeyArray, FwConstants.FMA_INDEX)) {
				isFMARequestedFlag = true;
				pageCollection.put("FMA_FLAG", true);
				if (cmpList != null) {
					cmpList.add("64");
					cmpList.add("66");
					cmpList.add("67");
				}
			}

			if (isThisProgramRequested(programKeyArray, FwConstants.TANF_INDEX)) {
				pageCollection.put("TANF_FLAG", true);
				isTANFRequestedFlag = true;
			}
			if (isThisProgramRequested(programKeyArray, FwConstants.FS_INDEX)) {
				pageCollection.put("SNAP_FLAG", true);
				isSNAPRequestedFlag = true;
			}
			if (isThisProgramRequested(programKeyArray, FwConstants.CRISIS_ASST_INDEX)
					|| isThisProgramRequested(programKeyArray, FwConstants.COOLING_ASST_INDEX)
					|| isThisProgramRequested(programKeyArray, FwConstants.FUEL_ASST_INDEX)) {
				isEARequestedFlag = true;
			}
			if (!isCCRequestedFlag && (!isFMARequestedFlag && !isTANFRequestedFlag) && !isSNAPRequestedFlag
					&& isEARequestedFlag) {
				pageCollection.put("EA_FLAG", true);
			}
			pageCollection.put("PROGRAM_SPECIFIC_FLAG", true);
			pageCollection.put("PAGE_COMPONENT_LIST", cmpList);
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.displayProgramSpecificInfo()");
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldInfoEJBBean.displayProgramSpecificInfo() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

	}

	private boolean isThisProgramRequested(Integer[] prgKey, short progInd) {
		try {
			boolean programRequested = false;
			if (prgKey[progInd] == 1) {
				programRequested = true;
			}
			return programRequested;
		} catch (Exception e) {
			throw e;
		}
	}

	private void displayProgramSpecificDetails(APP_IN_PRFL_Cargo ppInPrflSessionCargo, Map pageCollection) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldDemographicsService.displayProgramSpecificDetails() - START");
		try {
			final Integer[] programKeyArray = (Integer[]) pageCollection.get(FwConstants.AFB_PROGRAM_KEY);
			boolean isFMAProgramRequestedFlag = false;
			boolean isCCProgramRequestedFlag = false;
			boolean isSNAPProgramRequestedFlag = false;
			boolean isTANFProgramRequestedFlag = false;
			boolean isEARequestedFlag = false;
			validateDispProgSpeciDet(ppInPrflSessionCargo, pageCollection, programKeyArray);
			if (isThisProgramRequested(programKeyArray, FwConstants.FMA_INDEX)
					&& (ppInPrflSessionCargo.getIndv_fma_rqst_ind() != null)
					&& HouseHoldDemoGraphicsConstants.ONE == (ppInPrflSessionCargo.getIndv_fma_rqst_ind())) {
				pageCollection.put("FMA_FLAG", true);
			}
			if (isThisProgramRequested(programKeyArray, FwConstants.FMA_INDEX)) {
				pageCollection.put("FMA_PROG_FLAG", true);
				isFMAProgramRequestedFlag = true;
			}

			if (isThisProgramRequested(programKeyArray, FwConstants.TANF_INDEX)
					&& (ppInPrflSessionCargo.getIndv_tanf_rqst_ind() != null)
					&& HouseHoldDemoGraphicsConstants.ONE == (ppInPrflSessionCargo.getIndv_tanf_rqst_ind())) {
				pageCollection.put("TANF_FLAG", true);
				isTANFProgramRequestedFlag = true;
			}
			if (isThisProgramRequested(programKeyArray, FwConstants.TANF_INDEX)) {
				pageCollection.put("TANF_PROG_FLAG", true);
			}
			if (isThisProgramRequested(programKeyArray, FwConstants.FS_INDEX)
					&& (ppInPrflSessionCargo.getIndv_fs_rqst_ind() != null)
					&& HouseHoldDemoGraphicsConstants.ONE == (ppInPrflSessionCargo.getIndv_fs_rqst_ind())) {
				pageCollection.put("SNAP_FLAG", true);
			}
			if (isThisProgramRequested(programKeyArray, FwConstants.FS_INDEX)) {
				pageCollection.put("SNAP_PROG_FLAG", true);
				isSNAPProgramRequestedFlag = true;
			}
			if (isThisProgramRequested(programKeyArray, FwConstants.CRISIS_ASST_INDEX)
					|| isThisProgramRequested(programKeyArray, FwConstants.COOLING_ASST_INDEX)
					|| isThisProgramRequested(programKeyArray, FwConstants.FUEL_ASST_INDEX)) {
				isEARequestedFlag = true;
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.displayProgramSpecificDetails()");
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldDemographicsService.displayProgramSpecificDetails() - END");

	}

	private void validateDispProgSpeciDet(APP_IN_PRFL_Cargo ppInPrflSessionCargo, Map pageCollection,
			final Integer[] programKeyArray) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldDemographicsService.displayProgramSpecificDetails() - START");
		boolean isCCProgramRequestedFlag;
		if (isThisProgramRequested(programKeyArray, FwConstants.CC_INDEX)
				&& (ppInPrflSessionCargo.getIndv_cc_rqst_ind() != null)
				&& HouseHoldDemoGraphicsConstants.ONE == (ppInPrflSessionCargo.getIndv_cc_rqst_ind())) {
			pageCollection.put("CC_FLAG", true);
		}
		if (isThisProgramRequested(programKeyArray, FwConstants.CC_INDEX)) {
			pageCollection.put("CC_PROG_FLAG", true);
			isCCProgramRequestedFlag = true;
		}

		if (isThisProgramRequested(programKeyArray, FwConstants.WIC_INDEX)
				&& (ppInPrflSessionCargo.getIndv_wic_rqst_ind() != null)
				&& HouseHoldDemoGraphicsConstants.ONE == (ppInPrflSessionCargo.getIndv_wic_rqst_ind())) {
			pageCollection.put("WIC_FLAG", true);
		}
		if (isThisProgramRequested(programKeyArray, FwConstants.WIC_INDEX)) {
			pageCollection.put("WIC_PROG_FLAG", true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldDemographicsService.displayProgramSpecificDetails() - END");
	}

	/**
	 * Gets Individual details from People Handler service.
	 * 
	 * @param fwTransaction
	 */
	@Transactional
	public void getPeopleHandlerInformation(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, GET_PEOPLE_HANDLER_INFO_START, fwTransaction);
		try {
			Map pageCollection = new HashMap<String, Object>();
			PageActionDetails currentActionDetails = fwTransaction.getCurrentActionDetails();
			UserDetails userDetails = fwTransaction.getUserDetails();
			if (Objects.nonNull(currentActionDetails)) {
				IndividualCategorySequenceDetails indvSeqDetails = currentActionDetails
						.getIndividualCategorySequenceDetails();
				if (Objects.nonNull(indvSeqDetails)) {
					String individualSequence = indvSeqDetails.getIndividualSequence();
					if (Objects.nonNull(userDetails)) {
						String appNumber = userDetails.getAppNumber();
						String firstname = peopleHandler.getFirstName(individualSequence, appNumber);
						APP_INDV_Collection individualCollection = new APP_INDV_Collection();
						APP_INDV_Cargo cargo = new APP_INDV_Cargo();
						cargo.setFst_nam(firstname);
						individualCollection.add(cargo);
						pageCollection.put(APP_INDV_COLL, individualCollection);
						fwTransaction.setPageCollection(pageCollection);
					}
				}
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getPeopleHandlerInformation()", fwTransaction);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getPeopleHandlerInformation",
					fwTransaction.getUserDetails().getAppNumber(), fwTransaction.getUserDetails().getLoginUserId(),
					true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, GET_PEOPLE_HANDLER_INFO_START, fwTransaction);
	}

	/**
	 * Gets Individual custom collection from People Handler service.
	 * 
	 * @param fwTransaction
	 */
	@Transactional
	public void getIndividualCustomCollection(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, GET_PEOPLE_HANDLER_INFO_START, fwTransaction);
		try {
			Map pageCollection = new HashMap<String, Object>();
			PageActionDetails currentActionDetails = fwTransaction.getCurrentActionDetails();
			UserDetails userDetails = fwTransaction.getUserDetails();
			if (Objects.nonNull(userDetails)) {
				String appNumber = userDetails.getAppNumber();
				peopleHandler.loadPeopleHandler(appNumber);
				INDIVIDUAL_Custom_Collection indivCustCol = peopleHandler.getRelevantIndividuals();
				pageCollection.put("INDIVIDUAL_Custom_Collection", indivCustCol);
				fwTransaction.setPageCollection(pageCollection);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getPeopleHandlerInformation()", fwTransaction);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getIndividualCustomCollection",
					fwTransaction.getUserDetails().getAppNumber(), fwTransaction.getUserDetails().getLoginUserId(),
					true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, GET_PEOPLE_HANDLER_INFO_START, fwTransaction);
	}

	/**
	 * store Foster Care Details
	 * 
	 * @param fwTxn
	 * 
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeFosterCareDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeFosterCareDetails() - START", fwTxn);
		try {
			Map<Object, Object> pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			APP_INDV_Collection appIndvBeforeCollection = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);

			if (appIndvBeforeCollection != null && !appIndvBeforeCollection.isEmpty()
					&& appIndvBeforeCollection.size() > 0) {
				APP_INDV_Cargo appIndvCargo = appIndvBeforeCollection.getCargo(0);
				APP_INDV_Collection existingAppIndvCollection = fosterCareBO.getAppIndvByAppNumIndvSeqNum(appNum,
						indv_seq_num);
				if (Objects.nonNull(existingAppIndvCollection) && !(existingAppIndvCollection.isEmpty())
						&& existingAppIndvCollection.size() > 0) {
					APP_INDV_Cargo existingCargo = existingAppIndvCollection.getCargo(0);
					if (Objects.nonNull(existingCargo)) {
						populateAppIndvCargo(appIndvCargo, existingCargo);
						existingCargo.setIs_foster_care("Y");
						if (AppConstants.MCR_FLOW.equals(String.valueOf(pageCollection.get(AppConstants.FLOW_MODE)))) {
							existingCargo.setFormer_foster_state(appIndvCargo.getFormer_foster_state());
						}
						fosterCareBO.saveFosterCareDetails(existingCargo);
					}
				}

			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeFosterCareDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeFosterCareDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeFosterCareDetails() - START", fwTxn);

	}

	private void populateAppIndvCargo(APP_INDV_Cargo appIndvCargo, APP_INDV_Cargo existingCargo) {
		if (appIndvCargo.getFormer_foster_from_dt() != null) {
			existingCargo.setFormer_foster_from_dt(appIndvCargo.getFormer_foster_from_dt());
		}
		if (appIndvCargo.getFormer_foster_from_dt() != null) {
			existingCargo.setFormer_foster_to_dt(appIndvCargo.getFormer_foster_to_dt());
		}
		if (appIndvCargo.getFormer_foster_from_dt() != null) {
			existingCargo.setFormer_foster_state(appIndvCargo.getFormer_foster_state());
		}
		if (appIndvCargo.getFormer_foster_from_dt() != null) {
			existingCargo.setIn_foster_eighteenth_brth_ind(appIndvCargo.getIn_foster_eighteenth_brth_ind());
		}
	}

	/**
	 * load Foster Care Details
	 * 
	 * @param fwTxn
	 * 
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getFosterCareDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.getFosterCareDetails() - START", fwTxn);
		try {
			Map<Object, Object> pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			APP_INDV_Collection appIndvCollection;
			appIndvCollection = fosterCareBO.getAllAPPIndividuals(appNum, indvIdList);
			pageCollection.put(APP_INDV_COLL, appIndvCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getFosterCareDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getFosterCareDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.getFosterCareDetails() - END", fwTxn);

	}

	@Transactional
	public void deleteFosterCareDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.deleteFosterCareDetails() - START", fwTxn);
		try {
			Map<Object, Object> pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			APP_INDV_Collection appIndvBeforeCollection = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);
			if (Objects.nonNull(appIndvBeforeCollection) && !(appIndvBeforeCollection.isEmpty())
					&& appIndvBeforeCollection.size() > 0) {
				APP_INDV_Cargo appIndvCargo = appIndvBeforeCollection.getCargo(0);
				if (appIndvCargo.getApp_num() != null && indv_seq_num != null) {
					fosterCareBO.deleteFosterCareDetails(appNum, indv_seq_num);
				}
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.deleteFosterCareDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteFosterCareDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.deleteFosterCareDetails() - START", fwTxn);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getDisabilitySummary(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, GET_DISABILITY_DETAILS_START, fwTxn);
		try {

			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();

			String appnum = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			APP_IN_DABL_Collection collses = disabilityBo.loadDisabilityDetails(appnum, indvIdList);
			APP_IN_DABL_Collection newColl = new APP_IN_DABL_Collection();
			APP_IN_DABL_Cargo cargoSes = null;
			final int sizeColl = collses.size();
			if (sizeColl > 0) {
				for (int i = 0; i < sizeColl; i++) {
					cargoSes = collses.getCargo(i);
					newColl.addCargo(cargoSes);
				}
			}

			pageCollection.put("APP_IN_DABL_Collection", newColl);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, GET_DISABILITY_DETAILS_START, fwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), GET_DIS_SUM,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getDisabilitySummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeDisabilitySummary(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeDisabilitySummary() - START", fwTxn);
		try {

			final Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();

			String appNumber = userDetails.getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			Integer seq_num = 0;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			APP_IN_DABL_Collection appInDablColl = (APP_IN_DABL_Collection) pageCollection

					.get(HouseHoldDemoGraphicsConstants.APP_IN_DABL_COLL);
			APP_IN_DABL_Cargo appInDablCargo;

			if (appInDablColl != null && !appInDablColl.isEmpty() && appInDablColl.size() > 0) {

				appInDablCargo = appInDablColl.getCargo(0);
				appInDablCargo.setApp_num(appNumber);
				appInDablCargo.setIndv_seq_num(indv_seq_num);
				APP_IN_DABL_Collection dablcoll = disabilityBo.loadDisabilityDtls(appNumber, indv_seq_num);
				if (Objects.isNull(seq_num)) {
					seq_num = 1;
					if (!dablcoll.isEmpty()) {
						int index = dablcoll.size() - 1;
						APP_IN_DABL_Cargo lastCargo = (APP_IN_DABL_Cargo) dablcoll.get(index);
						if (null != lastCargo.getSeq_num()) {
							seq_num = lastCargo.getSeq_num() + 1;
						}

					}
				}
				fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.setCategorySequence(seq_num.toString());
				appInDablCargo.setSeq_num(seq_num);
				appInDablCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
				appInDablCargo.setRec_cplt_ind("1");
				appInDablCargo.setFrom_injury_ind(appInDablCargo.getFrom_injury_ind());
			}

			disabilityBo.storeDisabilitySummary(appInDablColl);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"Error Occured in HouseholdDemographicsService.storeDisabilitySummary()", fwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), STORE_DIS_SUMM,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeDisabilitySummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	public static Integer calculateAge(Date date) {
		Integer age = 0;
		LocalDate localBirthDate = LocalDate.parse(date.toString());
		age = Period.between(localBirthDate, LocalDate.now()).getYears();
		return age;

	}

	/**
	 * Gets the expedited food assistance details.
	 *
	 * @param txnBean the txn bean
	 */
	@Transactional
	public void getExpeditedAssistanceInfo(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getExpeditedAssistanceInfo() - START", txnBean);
		try {

			final Map pageCollection = txnBean.getPageCollection();
			CP_APP_INDV_ADDI_INFO_Collection cpAppIndvAdInfoColl;
			final String appNum = txnBean.getUserDetails().getAppNumber();

			cpAppIndvAdInfoColl = houseHoldBo.loadExpeditedAssistanceInfo(appNum);
			pageCollection.put("CP_APP_INDV_ADDI_INFO_Collection", cpAppIndvAdInfoColl);
			txnBean.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getExpeditedAssistanceInfo()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(),
					"getHouseHoldExpeditedAssistanceDetails", txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getExpeditedAssistanceInfo() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				txnBean);

	}

	/**
	 * stores the expedited food assistance details.
	 *
	 * @param txnBean the txn bean
	 */
	@Transactional
	public void storeExpeditedAssistanceInfo(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeExpeditedAssistanceInfo() - START", txnBean);
		try {

			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();

			final CP_APP_INDV_ADDI_INFO_Collection cpAppIndvAdInfoColl = (CP_APP_INDV_ADDI_INFO_Collection) pageCollection
					.get("CP_APP_INDV_ADDI_INFO_Collection");
			CP_APP_INDV_ADDI_INFO_Cargo cpAppIndvAdInfoCargo = cpAppIndvAdInfoColl.getCargo(0);
			cpAppIndvAdInfoCargo.setApp_number(Objects.nonNull(appNumber) ? Integer.parseInt(appNumber) : 0);

			CP_APP_INDV_ADDI_INFO_Collection cpAppIndvAdInfBeforeColl = (CP_APP_INDV_ADDI_INFO_Collection) houseHoldBo
					.loadExpeditedAssistanceInfo(appNumber);
			CP_APP_INDV_ADDI_INFO_Cargo cpAppIndvAdInfoBeforeCargo = new CP_APP_INDV_ADDI_INFO_Cargo();

			if ((cpAppIndvAdInfBeforeColl != null) && !cpAppIndvAdInfBeforeColl.isEmpty()
					&& (cpAppIndvAdInfBeforeColl.getCargo(0) != null)) {
				cpAppIndvAdInfoBeforeCargo = cpAppIndvAdInfBeforeColl.getCargo(0);
			}

			if (cpAppIndvAdInfBeforeColl != null && !cpAppIndvAdInfBeforeColl.isEmpty()
					&& !HouseHoldDemoGraphicsConstants.EMPTY.equals(cpAppIndvAdInfoBeforeCargo.getApp_num())
					&& cpAppIndvAdInfoBeforeCargo.getApp_num().equalsIgnoreCase(cpAppIndvAdInfoCargo.getApp_num())) {

				cpAppIndvAdInfoCargo = (CP_APP_INDV_ADDI_INFO_Cargo) isChanged(cpAppIndvAdInfoBeforeCargo,
						cpAppIndvAdInfoCargo);

				if (cpAppIndvAdInfoCargo.isDirty()) {
					cpAppIndvAdInfoCargo.setRowAction(FwConstants.ROWACTION_UPDATE);
				}
			} else if (!cpAppIndvAdInfoColl.isEmpty()) {
				cpAppIndvAdInfoCargo.setRowAction(FwConstants.ROWACTION_INSERT);
				cpAppIndvAdInfoCargo.setDirty(true);
			}
			if (cpAppIndvAdInfoCargo.isDirty()) {
				houseHoldBo.storeExpeditedAssistanceInfo(cpAppIndvAdInfoColl);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeExpeditedAssistanceInfo()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(),
					"storeHouseHoldExpeditedAssistanceDetails", txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeExpeditedAssistanceInfo() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				txnBean);
	}

	/**
	 * CSPM-2809 Leaving CA Service.
	 * 
	 * @param fwTxn as FwTransaction
	 */
	@Transactional
	public void getLeavingCADetails(FwTransaction fwTxn) {
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographics.getLeavingCADetails() - START",
					fwTxn);
			APP_INDV_Cargo[] appIndvArray = null;
			APP_INDV_Collection appIndvCollToRequest = null;
			String appNumber = null;
			UserDetails userDetails = fwTxn.getUserDetails();
			appNumber = userDetails.getAppNumber();
			final Map pageCollection = fwTxn.getPageCollection();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			// Fetching data from Database
			appIndvArray = cpAppIndvRepository.loadIndvDataByIndvIds(Integer.parseInt(appNumber), indvIdList);
			if (null != appIndvArray && appIndvArray.length > 0) {
				appIndvCollToRequest = new APP_INDV_Collection();
				for (APP_INDV_Cargo cargo : appIndvArray) {
					if (StringUtils.isNotEmpty(cargo.getIs_leaving_CA()))
						appIndvCollToRequest.addCargo(cargo);
				}
				pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollToRequest);
			}

			loadPgmRqst(appNumber, pageCollection);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographics.getLeavingCADetails() - END",
					fwTxn);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getLeavingCADetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getLeavingCADetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
	}

	/**
	 * CSPM-2809 Leaving CA Service.
	 * 
	 * @param appNumber      as String
	 * @param pageCollection as Map
	 */
	private void loadPgmRqst(String appNumber, final Map pageCollection) {
		APP_PGM_RQST_Collection appPgmRqstColl = null;
		appPgmRqstColl = cpAppPgmRqstRepository.getDetails(Integer.parseInt(appNumber));
		if (null != appPgmRqstColl && !appPgmRqstColl.isEmpty()) {
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL, appPgmRqstColl);
		}
	}

	/**
	 * CSPM-2809 Leaving CA Service.
	 * 
	 * @param txnBean as FwTransaction
	 */
	@Transactional
	public void storeLeavingCADetails(final FwTransaction txnBean) {
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographics.storeLeavingCADetails() - START",
					txnBean);
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			final String src_app_ind = "AB";
			APP_INDV_Collection appIndvCollFromDB = null;
			APP_INDV_Cargo appIndvCargoFromDB = null;

			final APP_INDV_Collection cpAppIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			Integer indv_seq_num = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			APP_INDV_Cargo[] allResults = cpAppIndvColl.getResults();
			APP_INDV_Cargo cpAppIndvCargo = new APP_INDV_Cargo();
			for (APP_INDV_Cargo cargo : allResults) {
				if (cargo.getIndv_seq_num().equals(indv_seq_num))
					cpAppIndvCargo = cargo;
			}

			cpAppIndvCargo.setApp_num(String.valueOf(appNumber));
			cpAppIndvCargo.setSrc_app_ind(src_app_ind);

			int indvSeqNum = Integer.valueOf(cpAppIndvCargo.getIndv_seq_num());

			appIndvCollFromDB = cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNumber), indvSeqNum);

			if (null != appIndvCollFromDB && appIndvCollFromDB.size() > 0) {
				validateStoreLeavCa(appIndvCollFromDB, cpAppIndvCargo);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographics.storeLeavingCADetails() - END",
					txnBean);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographics.storeLeavingCADetails()", txnBean);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeLeavingCADetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
	}

	private void validateStoreLeavCa(APP_INDV_Collection appIndvCollFromDB, APP_INDV_Cargo cpAppIndvCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.loadMilitaryInfoSummary() - START");
		APP_INDV_Cargo appIndvCargoFromDB;
		appIndvCargoFromDB = appIndvCollFromDB.getCargo(0);
		// Setting leaving ca reason details
		appIndvCargoFromDB.setLeaving_ca_rsn_desc(cpAppIndvCargo.getLeaving_ca_rsn_desc());
		if (Objects.nonNull(cpAppIndvCargo.getCa_leave_thirty_ind())
				|| (Objects.nonNull(cpAppIndvCargo.getCa_leave_thirty_ind())
						&& cpAppIndvCargo.getCa_leave_thirty_ind().equalsIgnoreCase("N")))
			appIndvCargoFromDB.setCa_leave_thirty_ind(cpAppIndvCargo.getCa_leave_thirty_ind());
		if (Objects.nonNull(cpAppIndvCargo.getCa_dep_dt()) || (Objects.nonNull(cpAppIndvCargo.getCa_leave_thirty_ind())
				&& cpAppIndvCargo.getCa_leave_thirty_ind().equalsIgnoreCase("N")))
			appIndvCargoFromDB.setCa_dep_dt(cpAppIndvCargo.getCa_dep_dt());
		if (Objects.nonNull(cpAppIndvCargo.getCa_ret_ind()) || (Objects.nonNull(cpAppIndvCargo.getCa_leave_thirty_ind())
				&& cpAppIndvCargo.getCa_leave_thirty_ind().equalsIgnoreCase("N")))
			appIndvCargoFromDB.setCa_ret_ind(cpAppIndvCargo.getCa_ret_ind());
		if (Objects.nonNull(cpAppIndvCargo.getCa_pland_ret_dt())
				|| (Objects.nonNull(cpAppIndvCargo.getCa_leave_thirty_ind())
						&& cpAppIndvCargo.getCa_leave_thirty_ind().equalsIgnoreCase("N")))
			appIndvCargoFromDB.setCa_pland_ret_dt(cpAppIndvCargo.getCa_pland_ret_dt());
		appIndvCargoFromDB.setIs_leaving_CA("Y");
		//set update date
		Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
		appIndvCargoFromDB.setUpdate_dt(currentTimeStamp);
		cpAppIndvRepository.save(appIndvCargoFromDB);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.loadMilitaryInfoSummary() - END");
	}

	@Transactional
	public void removeLeavingCADetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.removeLeavingCADetails() - START", txnBean);
		try {
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			String indv_seq_num = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence();
			int indvSeqNum = Integer.valueOf(indv_seq_num);

			APP_INDV_Collection appIndvCollFromDB = null;
			APP_INDV_Cargo appIndvCargoFromDB = null;

			appIndvCollFromDB = cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNumber), indvSeqNum);

			if (null != appIndvCollFromDB && appIndvCollFromDB.size() > 0) {
				appIndvCargoFromDB = appIndvCollFromDB.getCargo(0);
				// Setting leaving ca reason details
				appIndvCargoFromDB.setLeaving_ca_rsn_desc(null);
				appIndvCargoFromDB.setCa_leave_thirty_ind(null);
				appIndvCargoFromDB.setCa_dep_dt(null);
				appIndvCargoFromDB.setCa_ret_ind(null);
				appIndvCargoFromDB.setCa_pland_ret_dt(null);
				appIndvCargoFromDB.setIs_leaving_CA(null);
				//set update date
				Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
				appIndvCargoFromDB.setUpdate_dt(currentTimeStamp);
				cpAppIndvRepository.save(appIndvCargoFromDB);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.removeLeavingCADetails()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "removeLeavingCADetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.removeLeavingCADetails() - END", txnBean);
	}

	@Transactional
	public void removeDisabilitySummary(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.removeDisabilitySummary() - START", txnBean);
		try {
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			int seqNum = 0;
			String indv_seq_num = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence();
			int indvSeqNum = Integer.valueOf(indv_seq_num);
			String seq_num = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getCategorySequence();
			if (null != seq_num)
				seqNum = Integer.valueOf(seq_num);

			APP_INDV_Collection appIndvCollFromDB = null;
			APP_IN_DABL_Cargo appInDablCargoFromDB = null;

			APP_IN_DABL_Collection dablcoll = cpAppInDablRepository.getDisabilityDtl(Integer.parseInt(appNumber), indvSeqNum, seqNum);

			if (null != dablcoll && dablcoll.size() > 0) {
				appInDablCargoFromDB = dablcoll.getCargo(0);
				cpAppInDablRepository.delete(appInDablCargoFromDB);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.removeDisabilitySummary()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "removeDisabilitySummary",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.removeDisabilitySummary() - END", txnBean);
	}

	/**
	 * Method to load/get Information after Address Validation Validation - ABAVD
	 * 
	 * @param FwTransaction object
	 *
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getAddressValidationInformation(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getAddressValidationInformation() - START", fwTxn);

		Map pageCollection = fwTxn.getPageCollection();

		try {

			Address_Validate_Custom_Collection addrsValidateColl = null;
			Address_Validate_Custom_Collection addrsValidateRespColl = null;
			Address_Validate_Custom_Cargo addrsValidateRequest = null;
			Address_Validate_Custom_Cargo suggestedAddressResponse = null;

			addrsValidateColl = (Address_Validate_Custom_Collection) pageCollection
					.get("Address_Validate_Custom_Collection");

			if ((addrsValidateColl != null) && (!addrsValidateColl.isEmpty())) {
				addrsValidateRequest = addrsValidateColl.getCargo(0);
			}

			// we need to get the page data from the data base

			addressValidationRef = new AddressValidationAPI();

			suggestedAddressResponse = addressValidationRef.callPostAddressValidationRequest(addrsValidateRequest);

			if (null != suggestedAddressResponse) {
				addrsValidateRespColl = new Address_Validate_Custom_Collection();
				addrsValidateRespColl.addCargo(suggestedAddressResponse);
				pageCollection.put("Address_Validate_Custom_Collection", addrsValidateRespColl);
			}

			fwTxn.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.getAddressValidationInformation()", fwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "getAddressValidationInformation",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getAddressValidationInformation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Load method to get Email Receipt info (CSPM - 2083)
	 * 
	 * 
	 ********************************************************************************************************************
	 */
	@SuppressWarnings({"squid:S2230","squid:S3776"})
	@Transactional
	private void getEmailReceiptDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getEmailReceiptDetails() - START", fwTxn);
		StringBuilder buffer = null;
		String emailBody = null;
		String emailSubject = null;
		String textBody = null;
		try {
			Map pageCollection = fwTxn.getPageCollection();
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			final String srcAppInd = (String) pageCollection.get("srcAppInd");
			final String receiptType = (String) pageCollection.get("receiptType");
			Map contentAttributes = (Map) pageCollection.get("contentAttributes");
			Integer indvSeqNum = getPrimaryApplicantIndvSeqNum(appNum);
			if (null != srcAppInd) {
				// TNB4 Email body subject message construct
				if (HouseHoldDemoGraphicsConstants.TNB4_TN.equalsIgnoreCase(srcAppInd)) {
					emailBody = HouseHoldDemoGraphicsConstants.TN_EMAIL_BODY;
					emailSubject = HouseHoldDemoGraphicsConstants.TN_EMAIL_SUBJECT;
					textBody = HouseHoldDemoGraphicsConstants.TN_TEXT_BODY;
				} // The code-block below is coded as such, because the GSD is not updated for AFB
					// Confirmation.
					// This will be updated once we have the latest GSD updates for the same.
				else if (HouseHoldDemoGraphicsConstants.AFB_AB.equalsIgnoreCase(srcAppInd)
						|| HouseHoldDemoGraphicsConstants.CALFRESH_F37.equalsIgnoreCase(srcAppInd)
						|| HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING.equalsIgnoreCase(srcAppInd)) {
					emailBody = "Email Body for AFB Confirmation";
					emailSubject = "Email Subject: AFB Confirmation";
					textBody = "Text Receipt for AFB Confirmation";
				} else if (HouseHoldDemoGraphicsConstants.RMC_SRC_APP_IND.equalsIgnoreCase(srcAppInd)) {
					emailBody = "This is a receipt that confirms the following document has been uploaded: \r\n" + "";
					emailSubject = "BenefitsCal: Receipt of Report a Change";
					textBody = "Your changes have been submitted:";
				}

				// Add if block for any new Src App Ind or any other different type of renewal
				// here
			}
			final CP_APP_RGST_Collection cpAPPRGSTColl = contInfoBO.getEmailReceiptInfo(appNum, srcAppInd, indvSeqNum);

			if (Objects.nonNull(cpAPPRGSTColl) && !(cpAPPRGSTColl.isEmpty())) {
				if (null != receiptType) {
					if (receiptType.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.TEXT)) {
						buffer = new StringBuilder();
						buffer.append(textBody);
						buffer.append(HouseHoldDemoGraphicsConstants.LINE_SEPARATOR);
						((CP_APP_RGST_Cargo) cpAPPRGSTColl.get(0)).setTextBody(formEmailOrTextMessage(contentAttributes,
								buffer, "Source App Ind :" + srcAppInd + " Receipt type : " + receiptType));
					}
					if (receiptType.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.EMAIL)) {
						((CP_APP_RGST_Cargo) cpAPPRGSTColl.get(0)).setEmailSubject(emailSubject);
						buffer = new StringBuilder();
						buffer.append(emailBody);
						buffer.append(HouseHoldDemoGraphicsConstants.LINE_SEPARATOR);
						((CP_APP_RGST_Cargo) cpAPPRGSTColl.get(0))
								.setEmailBody(formEmailOrTextMessage(contentAttributes, buffer,
										"Source App Ind :" + srcAppInd + " Receipt type : " + receiptType));
					}
				}
				pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION, cpAPPRGSTColl);
			}
			/*
			 * Fetching APP_RQST_Collection to get form_report_type for all flows to send to
			 * front end for email receipt screen, BCUAT-1912 fix
			 */
			APP_RQST_Collection rqstCollection = appRqstRepository.getByAppNum(Integer.parseInt(appNum));
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, rqstCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getEmailReceiptDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getEmailReceiptDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getEmailReceiptDetails() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	public String formEmailOrTextMessage(Map contentAttributes, StringBuilder buffer, String srcAppIndReceiptType) {
		if (Objects.nonNull(contentAttributes)) {
			for (Object key : contentAttributes.entrySet()) {
				String attribute = key.toString();
				attribute = attribute.replace("=", " : ");
				buffer.append(attribute);
				buffer.append(HouseHoldDemoGraphicsConstants.LINE_SEPARATOR);
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"Form Renewal Type message construct : " + srcAppIndReceiptType + ". " + buffer.toString());
		return buffer.toString();
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Method to get Individual Sequence Number of Primary Applicant (CSPM - 2083)
	 * 
	 * 
	 ********************************************************************************************************************
	 */
	private Integer getPrimaryApplicantIndvSeqNum(String appNum) {
		APP_INDV_Collection appIndvColl = contInfoBO.getAllIndividuals(appNum);
		if (Objects.nonNull(appIndvColl) && !(appIndvColl.isEmpty()) && appIndvColl.size() > 0) {
			for (APP_INDV_Cargo individual : appIndvColl.getResults()) {
				if (Objects.nonNull(individual.getPrim_prsn_sw()) && individual.getPrim_prsn_sw().equals("Y")) {
					return individual.getIndv_seq_num();
				}
			}
		}
		return 0;
	}

	@SuppressWarnings("squid:S3776")
	@Transactional
	public void storeAuthRepDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.storeAuthRepDetails() - START",
				fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			int seqNum = 0;
			final String src_app_ind = "AB";
			final String rep_cd = "AR";
			seqNum = abAuthorizedRepresentativeBO.getMaxAuthRepSeq(appNumber, src_app_ind, rep_cd);
			CP_APP_AUTH_REP_Collection cpAppAuthRepColl;
			cpAppAuthRepColl = (CP_APP_AUTH_REP_Collection) pageCollection.get(CP_APP_AUTH_REP_COLL);
			CP_APP_AUTH_REP_Cargo cpAuthRepCargo;
			CP_APP_AUTH_REP_Collection beforRepColl = new CP_APP_AUTH_REP_Collection();
			cpAuthRepCargo = (CP_APP_AUTH_REP_Cargo) cpAppAuthRepColl.get(0);

			String snapAuthRepInd = cpAuthRepCargo.getSnap_auth_rep_ind();
			String mediCalAuthRepInd = cpAuthRepCargo.getAuth_rep_medical_assist_ind();
			String spendBenefitsInd = cpAuthRepCargo.getAuth_rep_req_ind();
			String sameBeneficiaryInd = cpAuthRepCargo.getAuthRepMedInd();

			if ((snapAuthRepInd != null && snapAuthRepInd.equals("Y")) || (spendBenefitsInd != null
					&& "Y".equals(spendBenefitsInd) && "Y".equalsIgnoreCase(sameBeneficiaryInd))) {
				beforRepColl = cpAppAuthRepRepository.getCalfreshAuthRep(Integer.parseInt(appNumber), src_app_ind, "Y");
			} else if (spendBenefitsInd != null && spendBenefitsInd.equals("Y")
					&& "N".equalsIgnoreCase(sameBeneficiaryInd)) {
				beforRepColl = cpAppAuthRepRepository.getBeneficiaryRep(Integer.parseInt(appNumber), src_app_ind, snapAuthRepInd);
				if(null == snapAuthRepInd &&   (null == beforRepColl || beforRepColl.isEmpty()))
				{
					beforRepColl = cpAppAuthRepRepository.getBeneficiaryRepSnapAuthNull(Integer.parseInt(appNumber), src_app_ind);
				}
			} else if (mediCalAuthRepInd != null && mediCalAuthRepInd.equals("Y")) {
				beforRepColl = cpAppAuthRepRepository.getMediCalAuthRep(Integer.parseInt(appNumber), src_app_ind, mediCalAuthRepInd);
			} else if (pageCollection.containsKey(AppConstants.FLOW_MODE) && AppConstants.DCF_FLOW.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())) {
				beforRepColl = cpAppAuthRepRepository.getBeforeColl(Integer.parseInt(appNumber), src_app_ind, rep_cd);
			}
			if (!beforRepColl.isEmpty()) {
				CP_APP_AUTH_REP_Cargo cargo = (CP_APP_AUTH_REP_Cargo) beforRepColl.get(0);
				cpAuthRepCargo.setApp_num(appNumber);
				cpAuthRepCargo.setSrc_app_ind(src_app_ind);
				cpAuthRepCargo.setRep_code(rep_cd);
				cpAuthRepCargo.setSeq_num(cargo.getSeq_num());
				if ("Y".equals(cargo.getSnap_auth_rep_ind()) && "Y".equals(sameBeneficiaryInd)) {
					cpAuthRepCargo.setSnap_auth_rep_ind(cargo.getSnap_auth_rep_ind());
					cpAuthRepCargo.setAuth_rep_fst_nam(cargo.getAuth_rep_fst_nam());
					cpAuthRepCargo.setAuth_rep_last_nam(cargo.getAuth_rep_last_nam());
					cpAuthRepCargo.setPhn_num(cargo.getPhn_num());
				}
			} else {
				cpAuthRepCargo.setApp_num(appNumber);
				cpAuthRepCargo.setSrc_app_ind(src_app_ind);
				cpAuthRepCargo.setRep_code(rep_cd);
				cpAuthRepCargo.setSeq_num(seqNum + 1);
			}
			CP_APP_AUTH_REP_Collection persistRepColl = new CP_APP_AUTH_REP_Collection();
			persistRepColl.add(cpAuthRepCargo);
			abAuthorizedRepresentativeBO.storeAuthorizedRepresentativeInformation(persistRepColl);

			/*
			 * If mode is DCF, invoke Program service to save/update Disaster calsfresh
			 * indicator for the app num
			 */
			callStoreProgramServiceDCF(fwTxn, pageCollection.containsKey(AppConstants.FLOW_MODE) ? pageCollection.get(AppConstants.FLOW_MODE).toString() : null);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDemographicsService.storeAuthRepDetails() - END", fwTxn);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeAuthRepDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeAuthRepDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
	}

	private void callStoreProgramServiceDCF(FwTransaction fwTxn, String mode) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.callStoreProgramServiceDCF() - START", fwTxn);

		try {
			if ((AppConstants.DCF_FLOW).equalsIgnoreCase(mode)) {
				storeProgramInformation(fwTxn);
				storeHouseholdDetails(fwTxn);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDemographicsService.callStoreProgramServiceDCF() - END", fwTxn);
		} catch (Exception ex) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.callStoreProgramServiceDCF()", fwTxn);
			FwLogger.log(this.getClass(), Level.ERROR, ex.getMessage());
		}
	}

	@Transactional
	public void saveMissingInfo(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.saveMissingInfo() - START",
				fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Integer primaryApplicantIndvSeqNum = null;
			final APP_INDV_Collection appIndvCollection = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);
			final CP_APP_RGST_Collection appRgstCollection = (CP_APP_RGST_Collection) pageCollection
					.get(CP_APP_RGST_COLL);
			APP_INDV_Cargo appIndvCargoext = cpAppIndvRepository.getPrimaryApplicantIndvDetails(Integer.parseInt(appNumber));
			primaryApplicantIndvSeqNum = appIndvCargoext.getIndv_seq_num();
			if (null != appIndvCollection && appIndvCollection.size() > 0) {
				APP_INDV_Cargo appIndvCargo = appIndvCollection.getCargo(0);
				appIndvCargoext.setSsn_num(appIndvCargo.getSsn_num());
				//set update date
				Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
				appIndvCargoext.setUpdate_dt(currentTimeStamp);
				cpAppIndvRepository.save(appIndvCargoext);
			}
			if (null != appRgstCollection && appRgstCollection.size() > 0 && primaryApplicantIndvSeqNum != null) {
				CP_APP_RGST_Cargo appRgstCargo = appRgstCollection.getCargo(0);
				CP_APP_RGST_Cargo exstingAppRgstCargo = cp_app_rgst_repo.getCpAppRgstDetails(Integer.parseInt(appNumber),
						primaryApplicantIndvSeqNum);
				exstingAppRgstCargo.setHshl_home_phn_num(appRgstCargo.getHshl_home_phn_num());
				exstingAppRgstCargo.setPhonenum_receipt(appRgstCargo.getHshl_home_phn_num());
				exstingAppRgstCargo.setHshl_email_adr(appRgstCargo.getHshl_email_adr());
				exstingAppRgstCargo.setEmail_receipt(appRgstCargo.getHshl_email_adr());
				if (Objects.nonNull(appRgstCargo.getHshl_email_adr())
						&& appRgstCargo.getHshl_email_adr().equals(HouseHoldDemoGraphicsConstants.EMPTY)
						&& Objects.nonNull(appRgstCargo.getHshl_email_adrA())
						&& !appRgstCargo.getHshl_email_adrA().equals(HouseHoldDemoGraphicsConstants.EMPTY)) {
					exstingAppRgstCargo.setHshl_email_adr(appRgstCargo.getHshl_email_adrA());
				}
				cp_app_rgst_repo.save(exstingAppRgstCargo);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.saveMissingInfo()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "saveMissingInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.saveMissingInfo() - END",
				fwTxn);

	}

	// Code Fot Getting Parent Situation Details
	@Transactional
	@SuppressWarnings("squid:S3776")
	public void getParentSituationDetails(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,

				"HouseholdDemographicsServiceImpl.getParentSituationsDetails() - START", fwTxn);

		final UserDetails userDetails = fwTxn.getUserDetails();

		final Map pageCollection = fwTxn.getPageCollection();

		String pageId = null;

		String previousPageId = null;

		String appNumber = null;

		String indvSeqNumber = null;

		String seqNumber = null;

		String absInd = null;

		int currentRecordIndex = 0;

		IndivTypeSeqBean detailKeyBean = null;

		boolean detailKeyBeanFlag = false;

		try {

			appNumber = userDetails.getAppNumber();

			Map beforeColl = null;

			beforeColl = fwTxn.getPageCollection();

			String appnum = fwTxn.getUserDetails().getAppNumber();

			Integer indv_seq_num = 1;

			APP_ABS_PRNT_Collection appAbsColl = new APP_ABS_PRNT_Collection();

			// PGM Table

			APP_ABS_PRNT_Collection newcoll = new APP_ABS_PRNT_Collection();

			APP_INDV_Collection indvNewCol = new APP_INDV_Collection();

			if (beforeColl != null) {

				appAbsColl = (APP_ABS_PRNT_Collection) beforeColl.get(APP_ABS_PRNT_COLL);

			}

			for (int i = 0; i <= 1; i++) {

				if (null != appAbsColl && !appAbsColl.isEmpty()) {

				}

			}

			APP_ABS_PRNT_Collection existingappAbsColl = absentParentBo.loadParentSituationAbsentDetails(appnum);

			APP_INDV_Collection existingappIndvColl = absentParentBo.loadParentSituation(appnum);

			// pgm

			CP_APP_PGM_INDV_Collection existingPgmCol = cpAppPgmIndvRepository.getDetails(Integer.parseInt(appNumber));

			APP_ABS_PRNT_Cargo cargoSes = null;

			APP_INDV_Cargo indvCargo = null;

			APP_PGM_RQST_Cargo pgmNewCargo = null;

			for (int i = 0; i <= 1; i++) {

				if (existingappAbsColl != null && existingappAbsColl.size() > 0) {

					cargoSes = existingappAbsColl.getCargo(i);

				} else {

					cargoSes = new APP_ABS_PRNT_Cargo();

					cargoSes.setAppNum(appnum);

				}

				newcoll.addCargo(cargoSes);

			}

			for (int i = 0; i <= 1; i++) {

				if (existingappIndvColl != null && existingappIndvColl.size() > 0) {

					indvCargo = existingappIndvColl.getCargo(i);

				} else {

					indvCargo = new APP_INDV_Cargo();

					indvCargo.setApp_num(appnum);

				}

				indvNewCol.addCargo(indvCargo);

			}

			pageCollection.put(APP_INDV_COLL, indvNewCol);
			pageCollection.put(APP_ABS_PRNT_COLL, newcoll);
			pageCollection.put(CP_APP_PGM_INDV_COLL, existingPgmCol);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getParentSituationsDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getParentSituationDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"BenefitsEJBBean.getParentSituationsDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	/**
	 * deleteFoodProgramDetails is to delete the food program details from DB .
	 *
	 * @param fwTxn the txn object
	 */
	@Transactional
	public void deleteFoodProgramDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.deleteFoodProgramDetails() - START",
				fwTxn);
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();

			Integer indvSeqNumber = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			cpAppIndvRepository.deleteFoodProgramDetail(Integer.parseInt(appNum), indvSeqNumber);
			getAllIndvFoodProgramDetails(fwTxn);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.deleteFoodProgramDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteFoodProgramDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.deleteFoodProgramDetails() - END",
				fwTxn);
	}

	/**
	 * deleteFosterChildData is to delete the foster child records from DB .
	 *
	 * @param fwTxn the txn object
	 */
	@Transactional
	public void deleteFosterChildData(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.deleteFosterChildData() - START", fwTxn);
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();

			Integer indvSeqNumber = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			APP_INDV_Collection appIndvCollFromDB = null;
			APP_INDV_Cargo appIndvCargoFromDB = null;
			appIndvCollFromDB = cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNum), indvSeqNumber);

			if (null != appIndvCollFromDB && appIndvCollFromDB.size() > 0) {
				appIndvCargoFromDB = appIndvCollFromDB.getCargo(0);
				// Setting leaving ca reason details to null
				appIndvCargoFromDB.setFoster_court_ord_dep_ind(null);
				appIndvCargoFromDB.setFoster_incl_calfresh_ind(null);
				appIndvCargoFromDB.setIs_foster_child(null);
				//set update date
				Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
				appIndvCargoFromDB.setUpdate_dt(currentTimeStamp);

				cpAppIndvRepository.save(appIndvCargoFromDB);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.deleteFosterChildData()", fwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteFosterChildData",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.deleteFosterChildData() - END",
				fwTxn);
	}

	@Transactional
	public void getAFBIndividualDetails(FwTransaction txBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.getAFBIndividualDetails() - START", txBean);
		final Map pageCollection = txBean.getPageCollection();
		UserDetails userDetails = txBean.getUserDetails();
		String appNumber = userDetails.getAppNumber();
		// get CP_APP_INDV data

		try {
			APP_INDV_Collection coll = aBHouseholdMembersSummaryBO.loadPersonDetailsByAppNum(appNumber);

			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, coll);

			CP_APP_INDV_ADDI_INFO_Collection addColl = aBHouseholdMembersSummaryBO.loadAdditionalInfoDetails(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_INDV_ADD_INFO_COLLECTION, addColl);

			// get HH detail Data

			CP_APP_RGST_Collection contactCargoColl = contInfoBO.loadContactforAppNum(appNumber,
					HouseHoldDemoGraphicsConstants.APP_IND_AFB);
			pageCollection.put(CP_APP_RGST_COLL, contactCargoColl);

			APP_ABS_PRNT_Collection existingappAbsColl = absentParentBo.loadParentSituationAbsentDetails(appNumber);
			pageCollection.put(APP_ABS_PRNT_COLL, existingappAbsColl);

			CP_APP_PGM_INDV_Collection existingPgmCol = cpAppPgmIndvRepository.getDetails(Integer.parseInt(appNumber));
			pageCollection.put(CP_APP_PGM_INDV_COLL, existingPgmCol);

			APP_PGM_RQST_Collection pgmColl = absentParentBo.loadProgrammeSelection(appNumber);
			pageCollection.put(CP_APP_PGM_RQST_COLL, pgmColl);

			CP_APP_IMMED_CASH_Collection immedCashColl = immedCashBO.getByAppNum(appNumber);
			pageCollection.put("CP_APP_IMMED_CASH_Collection", immedCashColl);

			CP_APP_AUTH_REP_Collection cpAppAuthRepColl = abAuthorizedRepresentativeBO.getByAppNum(appNumber);
			pageCollection.put(CP_APP_AUTH_REP_COLL, cpAppAuthRepColl);

			APP_SBMS_Collection sbmsColl = appsbms.findAllByAppNum(Integer.parseInt(appNumber));
			pageCollection.put(APP_SBMS_COLL, sbmsColl);

			CP_APP_SUPPORT_SERVICES_Collection supportColl = supportBO.fetchSupportServicesDetails(appNumber);
			pageCollection.put("CP_APP_SUPPORT_SERVICES_Collection", supportColl);

			CP_APP_HSHL_RLT_Collection appRelationColl = householdRelationshipRepo.getByAppNum(Integer.parseInt(appNumber));
			pageCollection.put(CP_APP_HSHL_RLT_COLL, appRelationColl);

			OTHER_HOUSEHOLD_DETAILS_Collection otherColl = otherBO.loadOtherHouseholdDetails(appNumber);
			pageCollection.put("OTHER_HOUSEHOLD_DETAILS_Collection", otherColl);

			CP_APP_IN_TAX_DEPENDENTS_Collection dependentColl = taxBO.loadTaxDepInfoByAppNum(appNumber);
			pageCollection.put("CP_APP_IN_TAX_DEPENDENTS_Collection", dependentColl);
			
			APP_USER_Collection appUserColl = appUserBO.getByAppNum(appNumber);
			pageCollection.put("APP_USER_Collection", appUserColl);
			
			RMB_RQST_Collection rmbRqstColl = rmbRequestBO.fetchRMBRqstInfoByAppNum(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION, rmbRqstColl);
			
			if (Objects.nonNull(rmbRqstColl) && !rmbRqstColl.isEmpty()) {
				CpRmbRequestDetails_Collection rmbRqstDetailColl = rmbRequestDetailBO
						.fetchRMBRqstDetailInfo(rmbRqstColl.getCargo(0).getCp_rmb_request_id());
				pageCollection.put(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION, rmbRqstDetailColl);
			}

		} catch (Exception exception) {
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_INDV_ADD_INFO_COLLECTION, null);
			pageCollection.put(CP_APP_RGST_COLL, null);
			pageCollection.put(APP_ABS_PRNT_COLL, null);
			pageCollection.put(CP_APP_PGM_RQST_COLL, null);
			pageCollection.put(CP_APP_PGM_INDV_COLL, null);
			pageCollection.put("CP_APP_IMMED_CASH_Collection", null);
			pageCollection.put(CP_APP_AUTH_REP_COLL, null);
			pageCollection.put(APP_SBMS_COLL, null);
			pageCollection.put("CP_APP_SUPPORT_SERVICES_Collection", null);
			pageCollection.put(CP_APP_HSHL_RLT_COLL, null);
			pageCollection.put("CP_APP_IN_TAX_DEPENDENTS_Collection", null);
			pageCollection.put("APP_USER_Collection", null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION, null);
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getAFBIndividualDetails()", txBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getAFBIndividualDetails",
					txBean.getUserDetails().getAppNumber(), txBean.getUserDetails().getLoginUserId(), true);
			
		}

		txBean.setPageCollection(pageCollection);
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsServiceImpl.getAFBIndividualDetails() - END",
				txBean);

	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getIndvListServiceChaining(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.getIndvListServiceChaining() - START", fwTxn);

		Map pageCollection = new HashMap();
		UserDetails userDetails = fwTxn.getUserDetails();
		String appNumber = null;
		String pageId = null;
		int pageStatus = 0;
		try {
			appNumber = userDetails.getAppNumber();
			APP_INDV_Cargo[] appIndvCargoArray = cpAppIndvRepository.getByAppNum(Integer.parseInt(appNumber));
			if (Objects.nonNull(appIndvCargoArray) && ArrayUtils.isNotEmpty(appIndvCargoArray)) {
				APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
				for (APP_INDV_Cargo cargo : appIndvCargoArray) {
					appIndvCollection.addCargo(cargo);
				}
				pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
			}

			fwTxn.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDemographicsServiceImpl.getIndvListServiceChaining() - END", fwTxn);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getIndvListServiceChaining()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getIndvListServiceChaining",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

	}

	public void loadSigningYourApplication(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.loadSigningYourApplication() - START",
				txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appnum = userDetails.getAppNumber();
			APP_SBMS_Collection sbmsCollection = appSbmsRepository.findAllByAppNum(Integer.parseInt(appnum));

			if (sbmsCollection != null) {
				pageCollection.put(APP_SBMS_COLL, sbmsCollection);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.loadSigningYourApplication()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadSigningYourApplication",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.loadSigningYourApplication() - END",
				txnBean);

	}

	/**
	 * storeSigningYourApplication method is used to store esign data of TNB4
	 * applicant in APP_SBMS table. After storing into DB table this method will
	 * send the APP_SBMS esign data back in the response.
	 * 
	 * @param txnBean
	 */
	@Transactional
	@SuppressWarnings("squid:S3776")
	public void storeSigningYourApplication(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.storeSigningYourApplication() - START",
				txnBean);
		try {
			APP_SBMS_Collection derivedColl = new APP_SBMS_Collection();
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();

			APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
			// Below block of code will populate the APP_SBMS table with Esign data received
			// in txnbean.
			if (null != appSbmsColl && !appSbmsColl.isEmpty() && null != appSbmsColl.getCargo(0)) {

				APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);
				appSbmsCargo.setSign_dt(copyTimeToDate(appSbmsCargo.getSign_dt()));
				appSbmsCargo.setApp_num(appNumber);
				appSbmsCargo.setE_sign_ind("N");
				if (null != appSbmsCargo.getEsignArr() && !appSbmsCargo.getEsignArr().isEmpty()
						&& appSbmsCargo.getEsignArr().get(0).equals("Y")) {
					appSbmsCargo.setE_sign_ind("Y");
				}
				appSbmsRepository.save(appSbmsCargo);
			}

			// Below block of code will retrieve the APP_SBMS data for appnum so as to send
			// the data back in
			// the response. Setting the APP_SBMS collection into pageCollection and front
			// code will access the pageCollection
			APP_SBMS_Cargo[] smbmsArr = appSbmsRepository.findByAppNum(Integer.parseInt(appNumber));
			if (null != smbmsArr && smbmsArr.length > 0) {
				for (APP_SBMS_Cargo cargo : smbmsArr) {
					cargo.seteSign_time(getOnlyTime(cargo.getSign_dt()));
					derivedColl.add(cargo);
				}
			}
			pageCollection.put(APP_SBMS_COLL, derivedColl);
			txnBean.setPageCollection(pageCollection);

			// added to update cp_app_rgst table data with the new data coming from Contact
			// info screen CSPM-17092
			CP_APP_RGST_Collection appRgstCollectionFromScreen = (CP_APP_RGST_Collection) pageCollection
					.get(CP_APP_RGST_COLL);
			CP_APP_RGST_Cargo existingAppRgstCargo = cp_app_rgst_repo.getCpAppRgstDetails(Integer.parseInt(appNumber), 1);
			CP_APP_RGST_Cargo appRgstCargoFromScreen = (Objects.nonNull(appRgstCollectionFromScreen)
					&& !appRgstCollectionFromScreen.isEmpty()) ? appRgstCollectionFromScreen.getCargo(0) : null;
			if (Objects.nonNull(appRgstCargoFromScreen) && Objects.nonNull(existingAppRgstCargo)) {
				existingAppRgstCargo.setHshl_city_adr(appRgstCargoFromScreen.getHshl_city_adr());
				existingAppRgstCargo.setHshl_sta_adr(appRgstCargoFromScreen.getHshl_sta_adr());
				existingAppRgstCargo.setHshl_l1_adr(appRgstCargoFromScreen.getHshl_l1_adr());
				existingAppRgstCargo.setHshl_l2_adr(appRgstCargoFromScreen.getHshl_l2_adr());
				existingAppRgstCargo.setHshl_zip_adr(appRgstCargoFromScreen.getHshl_zip_adr());
				existingAppRgstCargo.setHshl_home_phn_num(appRgstCargoFromScreen.getHshl_home_phn_num());
				cp_app_rgst_repo.save(existingAppRgstCargo);
			} else if (Objects.nonNull(appRgstCargoFromScreen)) {
				appRgstCargoFromScreen.setApp_num(appNumber);
				appRgstCargoFromScreen.setIndv_seq_num(1);
				appRgstCargoFromScreen.setSrc_app_ind(HouseHoldDemoGraphicsConstants.TNB4_TN);
				appRgstCargoFromScreen.setCnty_num(null);
				cp_app_rgst_repo.save(appRgstCargoFromScreen);
			}

			// added to update application status after app submission
			APP_RQST_Collection rqstCollection = appRqstRepository.getByAppNum(Integer.parseInt(appNumber));
			if (Objects.nonNull(rqstCollection) && !rqstCollection.isEmpty()) {
				APP_RQST_Cargo rqstCargo = rqstCollection.getCargo(0);
				Date fwDate = FwDate.getInstance().getDate();
				rqstCargo.setAppSbmtTms(fwDate);
				rqstCargo.setApp_stat_cd(HouseHoldDemoGraphicsConstants.APP_STATUS_CODE);
				rqstCollection.setCargo(0, rqstCargo);
				appRqstRepository.save(rqstCargo);
			}

			// Below method is to send Appnum, formtype into a queue before hitting
			// Interface API.
			putRequestIntoQueue(appNumber);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeSigningYourApplication()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "saveEsignInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.storeSigningYourApplication() - END",
				txnBean);
	}

	/**
	 * load Recertification Summary Template
	 * 
	 * @param txnBean
	 */
	// CSPM-8493 start
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadSummaryTemplate(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseldDemographicsServiceImpl.loadSummaryTemplate() - START", txnBean);

		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appnum = userDetails.getAppNumber();

			APP_SBMS_Collection appInSumTem = houseHoldSummaryBO.loadSummaryTemplate(appnum);
			if (null != appInSumTem && appInSumTem.size() > 0) {
				((APP_SBMS_Cargo) appInSumTem.get(0))
						.seteSign_time(getOnlyTime(((APP_SBMS_Cargo) appInSumTem.get(0)).getSign_dt()));
				pageCollection.put(APP_SBMS_COLL, appInSumTem);
			} else {
				APP_SBMS_Collection emptyCollection = new APP_SBMS_Collection();
				pageCollection.put(" APP_SBMS_Collection", emptyCollection);

			}

			CpAppTnb4Redet_Collection apptnb4 = houseHoldSummaryBO.loadtnb4redet(appnum);

			if (null != apptnb4 && apptnb4.size() > 0) {
				CpAppTnb4MoveoutSsiSsp_Collection appMoveOutSsiSsp = houseHoldSummaryBO.loadMoveOutSsiSsp(appnum);

				if (null != appMoveOutSsiSsp && appMoveOutSsiSsp.size() > 0) {

					((CpAppTnb4Redet_Cargo) apptnb4.get(0)).setMoveOut(getMoveOrSsiDetails(appMoveOutSsiSsp, "MO"));
					((CpAppTnb4Redet_Cargo) apptnb4.get(0)).setSsiSsp(getMoveOrSsiDetails(appMoveOutSsiSsp, "SI"));
					((CpAppTnb4Redet_Cargo) apptnb4.get(0))
							.setTnb4MoveoutssiSspList(getMoveOrSsiCargo(appMoveOutSsiSsp));

				}
				APP_INDV_Collection appIndvColl = aBHouseholdMembersSummaryBO.loadPersonDetailsByAppNum(appnum);
				if (null != appIndvColl && appIndvColl.size() > 0) {
					pageCollection.put(APP_INDV_COLL, appIndvColl);
				} else {
					APP_INDV_Collection emptyCollection = new APP_INDV_Collection();
					pageCollection.put(" APP_INDV_Collection", emptyCollection);

				}
				pageCollection.put("CpAppTnb4Redet_Collection", apptnb4);
			} else {

				pageCollection.put(" CpAppTnb4Redet_Collection", apptnb4);

			}
			txnBean.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.loadSummaryTemplate()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), LOAD_SUMM_TEMP,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseldDemographicsServiceImpl.loadSummaryTemplate() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				txnBean);

	}

	private String[] getMoveOrSsiDetails(CpAppTnb4MoveoutSsiSsp_Collection appMoveOutSsiSsp, String indvType) {

		ArrayList<String> list = new ArrayList<String>();

		if (null != appMoveOutSsiSsp && appMoveOutSsiSsp.size() > 0) {

			for (CpAppTnb4MoveoutSsiSsp_Cargo moveOut_Cargo : appMoveOutSsiSsp.getResults()) {
				if (null != moveOut_Cargo.getIndvType() && moveOut_Cargo.getIndvType().equals(indvType)) {

					list.add(moveOut_Cargo.getIndvSeqNum().intValue() + "");

				}
			}
		}

		String[] arr = list.toArray(new String[0]);
		return arr;
	}

	private List<CpAppTnb4MoveoutSsiSsp_Cargo> getMoveOrSsiCargo(CpAppTnb4MoveoutSsiSsp_Collection appMoveOutSsiSsp) {

		List<CpAppTnb4MoveoutSsiSsp_Cargo> list = new ArrayList<CpAppTnb4MoveoutSsiSsp_Cargo>();

		if (null != appMoveOutSsiSsp && appMoveOutSsiSsp.size() > 0) {

			for (CpAppTnb4MoveoutSsiSsp_Cargo moveOut_Cargo : appMoveOutSsiSsp.getResults()) {
				CpAppTnb4MoveoutSsiSsp_Cargo cargo = new CpAppTnb4MoveoutSsiSsp_Cargo();
				cargo.setSrcAppInd(moveOut_Cargo.getSrcAppInd());
				cargo.setIndvSeqNum(moveOut_Cargo.getIndvSeqNum());
				cargo.setIndvType(moveOut_Cargo.getIndvType());
				cargo.setAppNum(moveOut_Cargo.getAppNum());
				list.add(cargo);
			}

		}
		return list;

	}

	public java.util.Date copyTimeToDate(java.util.Date date) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.copyTimeToDate() - START");
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(date);
			Calendar t = Calendar.getInstance();
			c.set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY));
			c.set(Calendar.MINUTE, t.get(Calendar.MINUTE));
			c.set(Calendar.SECOND, t.get(Calendar.SECOND));
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.copyTimeToDate() - END");
		}
		return c.getTime();
	}

	public String getOnlyTime(java.util.Date date) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.getOnlyTime() - START");
		String time = "";
		
		if (null != date) {
			DateFormat dateFormat = new SimpleDateFormat("hh:mm a");
			time = dateFormat.format(date);
			time = time.toLowerCase();
		}
		
		return time;
	}

	private void putRequestIntoQueue(String appNum) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.putRequestIntoQueue() - START");

		try {
			Map<String, String> mapPayLoad = new HashMap<>();
			mapPayLoad.put("appNum", appNum);
			mapPayLoad.put("formType", "TNB4");

			String payLoad = sqsService.getResponseBody(mapPayLoad);
			sqsService.sendMessage(payLoad, awsProperties.getTnb4RedetQueueName());

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.putRequestIntoQueue()");
		}

		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.putRequestIntoQueue() - END");
	}

	@Transactional
	public void fetchCaseApplicationsDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdApplicationService.fetchCaseApplicationsDetails - START",
				txnBean);
		List<ChangeRenewalApplicationsRespone> changeRenewableApplicationsList = new ArrayList<>(0);
		List<OngoingApplicationsResponse> ongoingApplicationResponsesList = new ArrayList<>(0);

		try {
			
			Map pageCollection = txnBean.getPageCollection();
			ApplicationRequest_Collection applicationRequestCollection = (ApplicationRequest_Collection) pageCollection
					.get("ApplicationRequest_Collection");

			FwLogger.log(this.getClass(), Level.DEBUG,
					"HouseholdApplicationService.fetchCaseApplicationsDetails: applicationRequestCollection received:  "
							+ applicationRequestCollection);
			if (Objects.nonNull(applicationRequestCollection) && !applicationRequestCollection.isEmpty()) {
				ApplicationRequest_Cargo applicationRequest = (ApplicationRequest_Cargo) applicationRequestCollection
						.get(0);
				String gUID = applicationRequest.getgUID();
				List<String> caseList = applicationRequest.getCaseList();
				List<Integer> appNumList = null;
				
				if (null != txnBean && null != txnBean.getUserDetails()
						&& null != txnBean.getUserDetails().getLoginUserId()
						&& !"".equals(txnBean.getUserDetails().getLoginUserId()))
					appNumList = householdApplicationBO
							.getAllApplicationForUserFromDashboardService(txnBean.getUserDetails().getLoginUserId());
				else
					appNumList = householdApplicationBO.getAllApplicationForUserFromDashboardService("");
				
				FwLogger.log(this.getClass(), Level.DEBUG,
						"HouseholdApplicationService.fetchCaseApplicationsDetails: get all application from dashboard "
								+ "received total app list size:  " + appNumList.size());

				APP_RQST_Collection appRequestcoll = householdApplicationBO
						.getAllOngoingApplicationsRequestData(appNumList);

				FwLogger.log(this.getClass(), Level.DEBUG,
						"HouseholdApplicationService.fetchCaseApplicationsDetails: get all application" + ""
								+ appRequestcoll.size());

				List<APP_RQST_Cargo> caseNumNullAppList = Stream.of(appRequestcoll.getResults())
						.filter(appRqst -> Objects.isNull(appRqst.getCaseNum())).collect(Collectors.toList());

				ongoingApplicationResponsesList = householdApplicationBO
						.getAllOngoingApplicationsResponseList(caseNumNullAppList);

				FwLogger.log(this.getClass(), Level.DEBUG,
						"HouseholdApplicationService.fetchCaseApplicationsDetails: get ongoing application response: "
								+ "" + ongoingApplicationResponsesList.size());

				if (Objects.nonNull(caseList) && !caseList.isEmpty()) {
					List<APP_RQST_Cargo> caseAppList = Stream.of(appRequestcoll.getResults())
							.filter(appRqst -> Objects.nonNull(appRqst.getCaseNum())).collect(Collectors.toList());

					changeRenewableApplicationsList = householdApplicationBO
							.getChangeRenewalApplicationsResponeResponse(caseList, caseAppList);

					FwLogger.log(this.getClass(), Level.DEBUG,
							"HouseholdApplicationService.fetchCaseApplicationsDetails: get change renewal application response: "
									+ "" + changeRenewableApplicationsList.size());

				}
			}
			pageCollection.put(HouseHoldDemoGraphicsConstants.ONGOING_APPLICATION, ongoingApplicationResponsesList);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CHANGE_RENEWAL_APPLICATIONS,
					changeRenewableApplicationsList);

			FwLogger.log(this.getClass(), Level.INFO, "HouseholdApplicationService.fetchCaseApplicationsDetails - END",
					txnBean);
			txnBean.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.fetchCaseApplicationsDetails()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "fetchCaseApplicationsDetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
	}

	@Transactional
	public void senEmailOrTextMessageToAPI(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.senEmailOrTextMessageToAPI() - START", fwTxn);
		CP_APP_RGST_Cargo appRgstCargo = new CP_APP_RGST_Cargo();
		List<CP_APP_RGST_Cargo> appRgstCargoList = new ArrayList<>();
		try {
			Map pageCollection = fwTxn.getPageCollection();
			final String pageId = fwTxn.getCurrentActionDetails().getPageId();
			if (HouseHoldDemoGraphicsConstants.ABTMR.equalsIgnoreCase(pageId)) {
				appRgstCargo.setPhonenum_receipt((String) pageCollection.get("textReceipt"));
				appRgstCargo.setTextBody((String) pageCollection.get("textBody"));
				appRgstCargoList.add(appRgstCargo);
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Text Recipient: "
						+ appRgstCargo.getPhonenum_receipt() + " Text Body : " + appRgstCargo.getTextBody());
			}
			if (HouseHoldDemoGraphicsConstants.ABEMR.equalsIgnoreCase(pageId)) {
				appRgstCargo.setEmail_receipt((String) pageCollection.get("emailReceipt"));
				appRgstCargo.setEmailSubject((String) pageCollection.get("emailSubject"));
				appRgstCargo.setEmailBody((String) pageCollection.get("emailBody"));
				appRgstCargoList.add(appRgstCargo);
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"Email Recipient: " + appRgstCargo.getEmail_receipt() + " Email Subject : "
								+ appRgstCargo.getEmailSubject() + " Email Body : " + appRgstCargo.getEmailBody());
			}
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, LOAD_MILITARY_INFO_ERROR, fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "sendEmailTextToAPI",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.senEmailOrTextMessageToAPI() - END", fwTxn);

	}

	@Transactional
	public void storeProgramSelectionMember(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeProgramSelectionMember() - START", fwTxn);
		try {
			final UserDetails userDetails = fwTxn.getUserDetails();
			final Map pageCollection = fwTxn.getPageCollection();
			String appNum = userDetails.getAppNumber();
			Integer indvSeqNum = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			CP_APP_PGM_INDV_Collection appPgmIndvCollection = (CP_APP_PGM_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_APP_PGM_INDV_Collection);
			if ((appPgmIndvCollection != null) && !appPgmIndvCollection.isEmpty()) {
				for (CP_APP_PGM_INDV_Cargo cpAppPgmIndvCargo : appPgmIndvCollection.getResults()) {
					cpAppPgmIndvCargo.setApp_pgm_indv_id(String.valueOf(indvSeqNum));
					cpAppPgmIndvCargo.setIndv_seq_num(Double.valueOf(indvSeqNum));
					cpAppPgmIndvCargo.setApp_num(appNum);
					//set update date
					Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
					cpAppPgmIndvCargo.setUpdate_dt(currentTimeStamp);
					cpAppPgmIndvRepository.save(cpAppPgmIndvCargo);
				}
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeProgramSelectionMember()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeProgramSelectionMember",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeProgramSelectionMember() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	// CSPM-11321

	private void pushMessageForRedetCWToInvokeSAWS2PLUS(FwTransaction txnBean) throws ParseException {
		FwLogger.log(this.getClass(), Level.INFO,
				"HouseholdDemographicsService.pushMessageForRedetCWToInvokeSAWS2PLUS() - START", txnBean);
		String formReportType = HouseHoldDemoGraphicsConstants.SAWS2PLUS;
		final String appNumber = txnBean.getUserDetails().getAppNumber();
		try {

			// Change the status of Redet CW/CF application flow
			changeRedetCWCFApplicationStatus(txnBean);

			// call method to store sbms_dt
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"Call storeRedetCWCFApplicationSubmissionDate() to store sbms_dt");
			storeRedetCWCFApplicationSubmissionDate(txnBean);
			final Map pageCollection = txnBean.getPageCollection();
			if(pageCollection.get(AppConstants.FLOW_MODE) != null &&  HouseHoldDemoGraphicsConstants.CW_REDET_MODE.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
			&& pageCollection.get(HouseHoldDemoGraphicsConstants.SMS_NOTIFICATION_DATA) != null)
			{
				Map smsNOtificationMap=(Map) pageCollection.get(HouseHoldDemoGraphicsConstants.SMS_NOTIFICATION_DATA);
				if(smsNOtificationMap != null)
				{
					ObjectMapper objectMapper = new ObjectMapper();
					NotificationModel smsPayLoadModel=objectMapper.convertValue(smsNOtificationMap, NotificationModel.class);
					if(smsPayLoadModel != null)
					{
						Map params=smsPayLoadModel.getParams();
						if(smsPayLoadModel.getSmsInfo() != null && smsPayLoadModel.getSmsInfo().getTo() != null && smsPayLoadModel.getSmsInfo().getFrom() != null
						&& params != null && params.get(HouseHoldDemoGraphicsConstants.SEND_NEXT_DAY) != null 
						&& HouseHoldDemoGraphicsConstants.Y.equalsIgnoreCase(params.get(HouseHoldDemoGraphicsConstants.SEND_NEXT_DAY).toString()))
						{
							CP_AUTOMATED_SMS_Cargo smsObj=new CP_AUTOMATED_SMS_Cargo();
							smsObj.setFrom_number(smsPayLoadModel.getSmsInfo().getFrom());
							smsObj.setTo_number(smsPayLoadModel.getSmsInfo().getTo());
							smsObj.setFlow_name(pageCollection.get(AppConstants.FLOW_MODE).toString());
							smsObj.setNotification_status(HouseHoldDemoGraphicsConstants.OPEN_STATUS);
							String appNumVal=appNumber;
							if(params.get(HouseHoldDemoGraphicsConstants.APPLICATION_NUM) != null )
							{
								String caseNumVal=params.get(HouseHoldDemoGraphicsConstants.APPLICATION_NUM)+"";
								if(caseNumVal != null && !HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(caseNumVal.trim()))
								{
									appNumVal=caseNumVal;
								}
							}
							if(appNumVal != null && !HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(appNumVal.trim()))
							{
								smsObj.setApp_case_num(appNumVal);
							}
						
							if(params.get(HouseHoldDemoGraphicsConstants.RECV_FLOW_TEXT) != null
							&& params.get(HouseHoldDemoGraphicsConstants.TEXT_FLOW_TYPE) != null
							&& params.get(HouseHoldDemoGraphicsConstants.RECV_FLOW_COM_TEXT) != null
							&& params.get(HouseHoldDemoGraphicsConstants.TEXT_PHONE_NUM) != null
							&& params.get(HouseHoldDemoGraphicsConstants.TEXT_DATE) != null
							)
							{
								String message="BenefitsCal: "+params.get(HouseHoldDemoGraphicsConstants.RECV_FLOW_TEXT)+" "+
										params.get(HouseHoldDemoGraphicsConstants.TEXT_FLOW_TYPE)+
										params.get(HouseHoldDemoGraphicsConstants.RECV_FLOW_COM_TEXT)+" "+
										params.get(HouseHoldDemoGraphicsConstants.TEXT_PHONE_NUM);
								smsObj.setText_message(message);
								SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
								smsObj.setText_sent_date(format.parse(params.get(HouseHoldDemoGraphicsConstants.TEXT_DATE).toString()));
								if(params.get(HouseHoldDemoGraphicsConstants.TEXT_HOURS) != null
								&& params.get(HouseHoldDemoGraphicsConstants.TEXT_HOURS_VALUE) != null)
								{
									String messageN=params.get(HouseHoldDemoGraphicsConstants.TEXT_HOURS)+" "+
												params.get(HouseHoldDemoGraphicsConstants.TEXT_HOURS_VALUE);
									smsObj.setText_message(smsObj.getText_message()+messageN);
									String textHours=params.get(HouseHoldDemoGraphicsConstants.TEXT_HOURS_VALUE).toString();
									String startHourVal="";
									if(textHours != null && !HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(textHours.trim()))
									{
										startHourVal=textHours.split("-")[0];
										if(startHourVal != null && !HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(startHourVal.trim()))
										{
											String startTimeVal=startHourVal.split(":")[0];
											if(startTimeVal != null && !HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(startTimeVal.trim())
											&& startTimeVal.length() == 1)
											{
												startTimeVal="0"+startTimeVal;
											}
											String finalHour=startTimeVal;
											if(startHourVal.split(":").length > 1)
											{
												finalHour=finalHour+":"+startHourVal.split(":")[1];
											}
											smsObj.setStart_hour(finalHour.trim());
										}
									}
									autoSMSRepo.save(smsObj);
								}
							}
						}
					}
				}
			}
			// Below method is to send Appnum, formtype into a queue before hitting
			// Interface API.
			putRequestIntoQueue(appNumber, formReportType);
			//AppSummary pdf integration
			if(txnBean.getPageCollection().containsKey(HouseHoldDemoGraphicsConstants.MODE))
			{
				String mode = (String) txnBean.getPageCollection().get(HouseHoldDemoGraphicsConstants.MODE);
				if(HouseHoldDemoGraphicsConstants.CW_REDET_MODE.equalsIgnoreCase(mode))
				{
					AppSummaryDtlsModel appSummaryPayload = getAppSummaryPayload(txnBean,mode);
					arTransactionService.addMessageToQueue(appSummaryPayload);
				}
			}	
		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessageText());
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.pushMessageForRedetCWToInvokeSAWS2PLUS()",
					txnBean);
		} catch (Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"HouseholdDemographicsService.pushMessageForRedetCWToInvokeSAWS2PLUS() - END", txnBean);
	}

	private AppSummaryDtlsModel getAppSummaryPayload(FwTransaction txnBean,String mode)
	{
		FwLogger.log(this.getClass(), Level.INFO,
				"HouseholdDemographicsService.getAppSummaryPayload() - START");
		final Map pageCollection = txnBean.getPageCollection();
		AppSummaryDtlsModel appSummaryPayLoad = new AppSummaryDtlsModel();
		if(pageCollection.containsKey(APP_SBMS_COLL))
			{
					APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
					APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);
					appSummaryPayLoad.setCaseNumber(appSbmsCargo.getCase_num());
			}
		if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_COUNTY_CODE))

		{
				String countyCode = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_COUNTY_CODE);
				appSummaryPayLoad.setCountyCode(countyCode);	

		}
		if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_CASE_ID))
		{
			String caseID = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_CASE_ID);
			appSummaryPayLoad.setCaseId(caseID);
		}
		if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_CASE_NAME))
		{
			String caseName = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_CASE_NAME);
			appSummaryPayLoad.setCaseName(caseName);
		}
		appSummaryPayLoad.setGuid(txnBean.getUserDetails().getLoginUserId());
		appSummaryPayLoad.setAppNum(txnBean.getUserDetails().getAppNumber());
		appSummaryPayLoad.setFormType(mode);
		appSummaryPayLoad.setLangCode(getLangCode(pageCollection));
		FwLogger.log(this.getClass(), Level.INFO,
				"HouseholdDemographicsService.getAppSummaryPayload() - END");
		return appSummaryPayLoad;
	}
	
	private String getLangCode(Map pageCollection)
	{
		String languageCode = "EN";
		if(pageCollection.containsKey("LANGUAGE"))
		{
			String langcode = (String) pageCollection.get("LANGUAGE");
			if(null != langcode && !langcode.trim().isEmpty())
			{
				languageCode = langcode;
			}
		}
		return languageCode;
	}
	private void changeRedetCWCFApplicationStatus(FwTransaction fwTxn) {

		final String appNum = fwTxn.getUserDetails().getAppNumber();
		APP_RQST_Collection rqstCollection = appRqstRepository.getByAppNum(Integer.parseInt(appNum));
		if (!rqstCollection.isEmpty()) {
			APP_RQST_Cargo rqstCargo = rqstCollection.getCargo(0);

			rqstCargo.setAppSbmtTms(fwDate.getDate());
			rqstCargo.setApp_stat_cd(HouseHoldDemoGraphicsConstants.APP_STATUS_CODE);

			rqstCollection.setCargo(0, rqstCargo);
			appRqstRepository.save(rqstCargo);
		}
	}

	// new method to store sbms_dt
	public void storeRedetCWCFApplicationSubmissionDate(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeRedetCWCFApplicationSubmissionDate() - START", txnBean);
		final Map pageCollection = txnBean.getPageCollection();
		final String appNumber = txnBean.getUserDetails().getAppNumber();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Inside storeRedetCWCFApplicationSubmissionDate method");
		APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
		APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);
		((APP_SBMS_Cargo) appSbmsCargo).setApp_num(String.valueOf(appNumber));

		appSbmsCargo.setSbms_dt(fwDate.getDate());
		appsbms.save(appSbmsCargo);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.storeRedetCWCFApplicationSubmissionDate() - END", txnBean);
	}

	private void putRequestIntoQueue(String appNum, String formReportType) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.putRequestIntoQueue() - START");
		FwLogger.log(this.getClass(), Level.INFO,
				"HouseholdDemographicsService.putRequestIntoQueue() - AppNum in START: " + appNum + " Form Type :"
						+ formReportType);

		try {
			Map<String, String> mapPayLoad = new HashMap<>();
			String queueName = "";
			mapPayLoad.put("appNum", appNum);
			if (formReportType != null && formReportType.equals(HouseHoldDemoGraphicsConstants.SAWS2PLUS)) {
				mapPayLoad.put("formType", HouseHoldDemoGraphicsConstants.SAWS2PLUS);
				queueName = awsProperties.getSaws2PlusQueueName();
			}

			String payLoad = sqsService.getResponseBody(mapPayLoad);
			sqsService.sendMessage(payLoad, queueName);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"Successfully sent message" + formReportType + "message to" + queueName);
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.putRequestIntoQueue()");
		}

		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.putRequestIntoQueue() - END");

	}

	public void storeANAIDPage(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ARTransactionManagedEJBBean.storeANAIDPage() - START");
		try {
			FwLogger.log(this.getClass(), Level.INFO, "ARTransactionManagedEJBBean::storeANAIDPage");
			FwLogger.log(this.getClass(), Level.INFO, "store called");
			// Getting the session
			final UserDetails userDet = txnBean.getUserDetails();
			/*
			 * final Map beforeColl = (Map) session .get(FwConstants.BEFORE_COLLECTION);
			 */
			String appNumber = null;
			/*
			 * final Map httpSessionMap = (Map) session .get(FwConstants.HTTP_SESSION);
			 * httpSessionMap.get(FwConstants.SECURED_SESSION);
			 */

			String acsId = userDet.getLoginUserId();
			appNumber = userDet.getAppNumber();
			appUserBO.storeAcsIdAndAppNum(acsId, appNumber);
			userCredService.addNewApplicationToUser(appNumber, acsId);
			FwLogger.log(this.getClass(), Level.INFO, "ARTransactionManagedEJBBean::storeANAIDPage:End");
		} catch (Exception exception) {
			Map<String, FwMessageList> request = new HashMap<String, FwMessageList>();
			FwMessageList validateInfo = exceptionUtil.computeExceptionMsgBasedOnCode();
			request.put(FwConstants.MESSAGE_LIST, validateInfo);
			txnBean.setRequest(request);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeANAIDPage",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), false);
		}

		FwLogger.log(this.getClass(), Level.INFO, "ARTransactionManagedEJBBean.storeANAIDPage() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime));

	}

	/**
	 * 
	 * @param fwTxn Created as part of CSPM-12779 -For loading loadAppDetails for
	 *              APP History
	 */
	public void loadAppDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsServiceImpl.loadAppDetails() - START",
				fwTxn);
		try {
			final UserDetails userDetails = fwTxn.getUserDetails();
			final Map<String, Object> pageCollection = fwTxn.getPageCollection();
			String gUID = userDetails.getLoginUserId();
			APP_USER_Cargo[] cpAppUserCargos = abcreateAppNumBO.findAllByAcsId(gUID);
			Set<Integer> appnums = new TreeSet<>();
			for (APP_USER_Cargo cpAppUserCargo : cpAppUserCargos) {
				if (StringUtils.isNotEmpty(cpAppUserCargo.getApp_num())) {
					appnums.add(Integer.parseInt(cpAppUserCargo.getApp_num()));
				}
			}
			APP_RQST_Collection appreqst = abcreateAppNumBO.getAllDetails(appnums);
			pageCollection.put("GET_APP_HISTORY", appreqst);
			fwTxn.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.loadAppDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadAppDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.loadAppDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	public void removeContactInfoSummary(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.removeContactInfoSummary() - START",
				txnBean);
		try {
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			String indvSequenceNum = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence();
			int indvSeqNum = Integer.parseInt(indvSequenceNum);
			CP_APP_RGST_Cargo cpAppRgst = contInfoBO.loadContactInfoAppIndv(appNumber, indvSeqNum);
			final Map<String, Object> pageColl = txnBean.getPageCollection();
			CP_APP_RGST_Collection cpAppRgstColl = new CP_APP_RGST_Collection();
			if (null != cpAppRgst) {
				CP_APP_RGST_Cargo cpAppRgstCargo = cpAppRgst;
				cpAppRgstCargo.setContact_eff_dt(null);
				cpAppRgstCargo.setHshl_home_phn_num(FwConstants.EMPTY_STRING);
				cpAppRgstCargo.setHshl_cell_phn_num(FwConstants.EMPTY_STRING);
				cpAppRgstCargo.setHshl_work_phn_num(FwConstants.EMPTY_STRING);
				cpAppRgstCargo.setHshl_email_adr(FwConstants.EMPTY_STRING);
				cpAppRgstCargo.setMsg_phn_num(FwConstants.EMPTY_STRING);
				cpAppRgstCargo.setPhonenum_receipt(FwConstants.EMPTY_STRING);
				cpAppRgstCargo.setEmail_receipt(FwConstants.EMPTY_STRING);
				cpAppRgstCargo.setWork_phone_num(FwConstants.EMPTY_STRING);
				contInfoBO.storeContactInformation(cpAppRgstCargo);
				cpAppRgstColl.add(cpAppRgstCargo);
				pageColl.put(CP_APP_RGST_COLL, cpAppRgstColl);
				txnBean.setPageCollection(pageColl);
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.removeContactInfoSummary()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "removeContactInfoSummary",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "HouseholdDemographicsService.removeContactInfoSummary() - END",
				txnBean);
	}

	/**
	 * Method to load/get contact information - RCCCS
	 * 
	 * @param FwTransaction object
	 *
	 */

	public void getContactInformationActiveIndv(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getContactInformationRC() - START", fwTxn);

		try {
			final Map<String, Object> pageColl = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			final String appNum = userDetails.getAppNumber();
			String pageId = fwTxn.getCurrentActionDetails().getPageId();

			final CP_APP_RGST_Collection contactColl = new CP_APP_RGST_Collection();

			APP_INDV_Collection indvColl = contInfoBO.loadActiveIndvdtl(appNum);
			if (!indvColl.isEmpty()) {
				pageColl.put(APP_INDV_COLL, indvColl);
			}
			List<Integer> indvs = new ArrayList<>();
			if (HouseHoldDemoGraphicsConstants.RCCCS.equalsIgnoreCase(pageId)) {
				for (Iterator<APP_INDV_Cargo> iterator = indvColl.iterator(); iterator.hasNext();) {
					APP_INDV_Cargo appIndvCarg = iterator.next();
					if(appIndvCarg.getMove_in_ind()== null || appIndvCarg.getMove_in_ind().equals("") || !("Y".equalsIgnoreCase(appIndvCarg.getMove_in_ind()))) {
						indvs.add(appIndvCarg.getIndv_seq_num());
					}
				}
			}else {
				for (Iterator<APP_INDV_Cargo> iterator = indvColl.iterator(); iterator.hasNext();) {
					APP_INDV_Cargo appIndvCarg = iterator.next();
					indvs.add(appIndvCarg.getIndv_seq_num());
				}
			}

			List<CP_APP_RGST_Cargo> contactCargo = contInfoBO.loadContactSummaryforActiveIndv(appNum, indvs);

			if (contactCargo == null) {
				CP_APP_RGST_Cargo contactCar = new CP_APP_RGST_Cargo();
				contactCar.setApp_num(appNum);
				contactColl.addCargo(contactCar);
			} else {
				for (CP_APP_RGST_Cargo cp_APP_RGST_Cargo : contactCargo) {
					contactColl.addCargo(cp_APP_RGST_Cargo);
				}
			}

			pageColl.put(CP_APP_RGST_COLL, contactColl);

			fwTxn.setPageCollection(pageColl);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getContactInformationRC()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getContactInformationRC",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getContactInformationRC() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);

	}

	private void storeHouseholdDetails(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeHouseholdDetails() - START", fwTxn);

		Map<String, Object> pageCollection = null;

		CP_HSHL_DETAILS_DISASTER_Cargo cpHshlDtlsDisasterCargo = null;
		CP_HSHL_DETAILS_DISASTER_Collection cpHshlDtlsDisasterColl = null;

		String appNumber = fwTxn.getUserDetails().getAppNumber();
		Integer indvSeqNum = 1;

		try {

			pageCollection = fwTxn.getPageCollection();

			if (pageCollection.get(HouseHoldDemoGraphicsConstants.CP_HSHL_DETAILS_DISASTER_COLLECTION) != null) {
				cpHshlDtlsDisasterColl = (CP_HSHL_DETAILS_DISASTER_Collection) pageCollection
						.get(HouseHoldDemoGraphicsConstants.CP_HSHL_DETAILS_DISASTER_COLLECTION);

				cpHshlDtlsDisasterCargo = cpHshlDtlsDisasterColl.getCargo(0);

				cpHshlDtlsDisasterCargo.setApp_num(appNumber);
				cpHshlDtlsDisasterCargo.setIndv_seq_num(indvSeqNum);
				cpHshlDtlsDisasterCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);

				disasterBO.storeHouseholdInformation(cpHshlDtlsDisasterCargo);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeHouseholdDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeHouseholdDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeHouseholdDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	private void loadDCFHouseholdDetails(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.loadDCFHouseholdDetails() - START", fwTxn);

		Map<String, Object> pageCollection = null;
		String appNumber = fwTxn.getUserDetails().getAppNumber();
		try {

			pageCollection = fwTxn.getPageCollection();

			CP_HSHL_DETAILS_DISASTER_Collection cpHshlDisasterColl = disasterBO.loadHouseholdDetailsDCF(appNumber);

			if (Objects.nonNull(cpHshlDisasterColl) && !cpHshlDisasterColl.isEmpty()) {
				pageCollection.put(HouseHoldDemoGraphicsConstants.CP_HSHL_DETAILS_DISASTER_COLLECTION,
						cpHshlDisasterColl);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.loadDCFHouseholdDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadDCFHouseholdDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		} finally {
			fwTxn.setPageCollection(pageCollection);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.loadDCFHouseholdDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	// START DCF
	public void getDisasterSummary(FwTransaction txBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.getDisasterSummary() - START", txBean);
		final Map<String, Object> pageCollection = txBean.getPageCollection();
		UserDetails userDetails = txBean.getUserDetails();
		String appNumber = userDetails.getAppNumber();

		try {
			APP_INDV_Collection coll = aBHouseholdMembersSummaryBO.loadPersonDetailsByAppNum(appNumber);

			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, coll);

			CP_APP_RGST_Collection contactCargoColl = contInfoBO.loadContactforAppNum(appNumber,
					HouseHoldDemoGraphicsConstants.APP_IND_AFB);
			pageCollection.put(CP_APP_RGST_COLL, contactCargoColl);

			APP_PGM_RQST_Collection pgmColl = absentParentBo.loadProgrammeSelection(appNumber);
			pageCollection.put(CP_APP_PGM_RQST_COLL, pgmColl);

			CP_APP_AUTH_REP_Collection cpAppAuthRepColl = abAuthorizedRepresentativeBO.getByAppNum(appNumber);
			pageCollection.put(CP_APP_AUTH_REP_COLL, cpAppAuthRepColl);

			CP_APP_HSHL_RLT_Collection appRelationColl = householdRelationshipRepo.getByAppNum(Integer.parseInt(appNumber));
			pageCollection.put(CP_APP_HSHL_RLT_COLL, appRelationColl);

			CP_HSHL_DETAILS_DISASTER_Collection cpHshlDtlsDisasterColl = disasterBO.loadHouseholdDetailsDCF(appNumber);
			pageCollection.put("CP_HSHL_DETAILS_DISASTER_Collection", cpHshlDtlsDisasterColl);

			APP_SBMS_Collection sbmsColl = appsbms.findAllByAppNum(Integer.parseInt(appNumber));
			pageCollection.put(APP_SBMS_COLL, sbmsColl);

		} catch (Exception e) {
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, null);
			pageCollection.put(CP_APP_RGST_COLL, null);
			pageCollection.put(CP_APP_PGM_RQST_COLL, null);
			pageCollection.put(CP_APP_AUTH_REP_COLL, null);
			pageCollection.put(CP_APP_HSHL_RLT_COLL, null);
			pageCollection.put("CP_HSHL_DETAILS_DISASTER_Collection", null);
			pageCollection.put(APP_SBMS_COLL, null);
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getDisasterSummary()", txBean);

			FwExceptionManager.handleException(e, this.getClass().getName(), "getDisasterSummary",
					txBean.getUserDetails().getAppNumber(), txBean.getUserDetails().getLoginUserId(), true);

		}

		txBean.setPageCollection(pageCollection);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.getDisasterSummary() - END", txBean);

	}

	public void updateCF37MailingAddress(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService..updateCF37MailingAddress() - START", fwTxn);
		try {

			Map pageCollection = fwTxn.getPageCollection();
			Map request = fwTxn.getRequest();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = null;
			List<CP_APP_RGST_Cargo> rgstCargoList = null;
			CP_APP_RGST_Cargo jsonrgstCargo = null;
			CP_APP_RGST_Cargo dbrgstCargo = null;
			appNumber = userDetails.getAppNumber();
			CP_APP_RGST_Collection coll = (CP_APP_RGST_Collection) pageCollection.get(CP_APP_RGST_COLL);
			if (null != coll && !coll.isEmpty()) {
				jsonrgstCargo = coll.getCargo(0);
			}
			if (null != appNumber && !appNumber.isEmpty()) {
				rgstCargoList = (List<CP_APP_RGST_Cargo>) cpAppRgstRepos.getRgstListByAppNum(Integer.parseInt(appNumber));
				if (null != rgstCargoList && !rgstCargoList.isEmpty()) {
					dbrgstCargo = rgstCargoList.get(0);
				}
			}
			if (null != jsonrgstCargo && null != dbrgstCargo) {
				dbrgstCargo.setAlt_st_adr(jsonrgstCargo.getAlt_l1_adr());
				dbrgstCargo.setAlt_l2_adr(jsonrgstCargo.getAlt_l2_adr());
				dbrgstCargo.setAlt_city_adr(jsonrgstCargo.getAlt_city_adr());
				dbrgstCargo.setAlt_sta_adr(jsonrgstCargo.getAlt_sta_adr());
				dbrgstCargo.setAlt_zip_adr(jsonrgstCargo.getAlt_zip_adr());
				if(null!=jsonrgstCargo.getHless_sw()) {
				dbrgstCargo.setHless_sw(jsonrgstCargo.getHless_sw());
				}
				cpAppRgstRepos.save(dbrgstCargo);
			}
			if (null != jsonrgstCargo && null == dbrgstCargo) {
				jsonrgstCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				cpAppRgstRepos.save(jsonrgstCargo);
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, LOAD_MILITARY_INFO_ERROR, fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), "updateCF37MailingAddress",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.updateCF37MailingAddress() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	public void updateContactInformationCF37(FwTransaction FwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.updateContactInformationCF37() - START", FwTxn);
		try {
			final Map pageCollection = FwTxn.getPageCollection();
			ArrayList<String> signIndArray = (ArrayList<String>) pageCollection.get("text_sent_ind_checkbox");
			String signInd = HouseHoldDemoGraphicsConstants.EMPTY;
			if (signIndArray != null && signIndArray.contains(HouseHoldDemoGraphicsConstants.Y)) {
				signInd = HouseHoldDemoGraphicsConstants.Y;
			}
			UserDetails userDetails = FwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Integer primaryApplicantIndvSeqNum = null;
			final APP_INDV_Collection appIndvCollection = (APP_INDV_Collection) pageCollection.get(APP_INDV_COLL);
			final CP_APP_RGST_Collection appRgstCollection = (CP_APP_RGST_Collection) pageCollection
					.get(CP_APP_RGST_COLL);
			APP_INDV_Cargo appIndvCargoext = cpAppIndvRepository.getPrimaryApplicantIndvDetails(Integer.parseInt(appNumber));
			primaryApplicantIndvSeqNum = appIndvCargoext.getIndv_seq_num();
			if (null != appRgstCollection && appRgstCollection.size() > 0 && primaryApplicantIndvSeqNum != null) {
				CP_APP_RGST_Cargo appRgstCargo = appRgstCollection.getCargo(0);
				CP_APP_RGST_Cargo exstingAppRgstCargo = cp_app_rgst_repo.getCpAppRgstDetails(Integer.parseInt(appNumber),
						primaryApplicantIndvSeqNum);
				exstingAppRgstCargo.setHshl_home_phn_num(appRgstCargo.getHshl_home_phn_num());
				exstingAppRgstCargo.setHshl_cell_phn_num(appRgstCargo.getHshl_cell_phn_num());
				exstingAppRgstCargo.setHshl_work_phn_num(appRgstCargo.getHshl_work_phn_num());
				exstingAppRgstCargo.setHshl_email_adr(appRgstCargo.getHshl_email_adr());
				exstingAppRgstCargo.setText_sent_ind(signInd);
				cp_app_rgst_repo.save(exstingAppRgstCargo);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.updateContactInformationCF37()", FwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), "updateContactInformationCF37",
					FwTxn.getUserDetails().getAppNumber(), FwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.updateContactInformationCF37() - END", FwTxn);
	}

	/**
	 * This method saves the incarcerated information for the app number & app
	 * individual.
	 * 
	 * @param fwTxn
	 * 
	 */
	private void saveIncarceratedInfo(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.saveIncarceratedInfo() - START", txnBean);
		try {
			final Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Integer indvSeqNum = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			Map incarceratedCollMap = (Map) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INCARCERATED_COLL);
			String dateString = (String) incarceratedCollMap.get(HouseHoldDemoGraphicsConstants.DATE_OF_RELEASE);
			LocalDate releaseDt = null;
			if (Objects.nonNull(dateString) && !"".equals(dateString)) {
				releaseDt = LocalDate.parse(dateString);
			}
			APP_INDV_Cargo appIndvCargoext = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNumber), indvSeqNum);
			if (Objects.nonNull(incarceratedCollMap.get("incarceratedind"))) {
				appIndvCargoext.setIncarceratedind((String) incarceratedCollMap.get("incarceratedind"));
			}
			appIndvCargoext.setDateOfRelease(releaseDt);
			// To DO update armed_forces_resp indicator in Profile Table
			//set update date
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			appIndvCargoext.setUpdate_dt(currentTimeStamp);
			cpAppIndvRepository.save(appIndvCargoext);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.saveIncarceratedInfo()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), "saveIncarceratedInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.saveIncarceratedInfo() - END",
				txnBean);
	}

	/**
	 * This method load the incarcerated information for the app number & app
	 * individuals.
	 * 
	 * @param fwTxn
	 */
	private void loadIncarceratedInfo(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.loadIncarceratedInfo() - START", fwTxn);
		Map pageCollection = fwTxn.getPageCollection();
		try {
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());

			APP_INDV_Cargo[] appIndvCargoaArray = cpAppIndvRepository.getByAppNum(Integer.parseInt(appNumber));

			APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
			appIndvCollection.setResults(appIndvCargoaArray);
			List<APP_INDV_Cargo> appIndvList = Arrays.asList(appIndvCargoaArray);
			List<APP_INDV_Cargo> incarceratedIndvList = appIndvList.stream()
					.filter(indv -> AppConstants.YES.equals(indv.getIncarceratedind())
							&& !AppConstants.YES.equals(indv.getDeceased_ind())
							&& !AppConstants.YES.equals(indv.getMove_out_ind()))
					.collect(Collectors.toList());
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INCARCERATED_COLL, incarceratedIndvList);
			fwTxn.setPageCollection(pageCollection);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.loadIncarceratedInfo()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), "loadIncarceratedInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.loadIncarceratedInfo() - END",
				fwTxn);
	}

	/**
	 * This method removes the incarcerated information for the app number & app
	 * individual.
	 * 
	 * @param fwTxn
	 */
	private void removeIncarceratedInfo(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.removeIncarceratedInfo() - START", txnBean);
		try {
			UserDetails userDetails = txnBean.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Integer individualSequence = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			APP_INDV_Cargo appIndvCargoext = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNumber),
					individualSequence);
			appIndvCargoext.setDateOfRelease(null);
			appIndvCargoext.setIncarceratedind(null);
			//set update date
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			appIndvCargoext.setUpdate_dt(currentTimeStamp);
			cpAppIndvRepository.save(appIndvCargoext);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.removeIncarceratedInfo()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), "removeIncarceratedInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.removeIncarceratedInfo() - END", txnBean);

	}

	private void storeImmigrationInfo(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeImmigrationInfo() - START", fwTxn);

		try {
			final Map pageColl = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();
			Integer indvSeqNum = 0;
			PageActionDetails currentActionDetails = null;

			currentActionDetails = fwTxn.getCurrentActionDetails();
			if (Objects.nonNull(currentActionDetails)
					&& Objects.nonNull(currentActionDetails.getIndividualCategorySequenceDetails()) && Objects.nonNull(
							currentActionDetails.getIndividualCategorySequenceDetails().getIndividualSequence())) {
				indvSeqNum = Integer
						.parseInt(currentActionDetails.getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			APP_INDV_IMG_Collection appIndvImgColl = (APP_INDV_IMG_Collection) pageColl.get(APP_INDV_IMG_COLL);

			if (appIndvImgColl != null && !appIndvImgColl.isEmpty()
					&& appIndvImgColl.size() > 0) {
				APP_INDV_IMG_Cargo appIndvImgCargo = appIndvImgColl.getCargo(0);
				APP_INDV_Cargo existingCargo = houseHoldBo.getIndividual(appNum, indvSeqNum);
				if (Objects.nonNull(existingCargo)) {
					existingCargo.setAlien_num(appIndvImgCargo.getAlien_num());
					existingCargo.setAlien_status_cd("Y");
					FwLogger.log(this.getClass(), FwLogger.Level.INFO,
							"HouseholdDemographicsService.storeImmigrationInfo() - Saving info for " + appNum + " "
									+ indvSeqNum);
					houseHoldBo.storeImmigrationDetail(existingCargo);
				}

			}

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeImmigrationInfo()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), "storeImmigrationInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.storeImmigrationInfo() - END",
				fwTxn);
	}

	public void loadImmigrationInfo(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.loadImmigrationInfo() - START",
				txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appnum = userDetails.getAppNumber();
			String statusCd = "Y";
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"OtherExpensesServImpl.loadImmigrationInfo() - Getting data for appnum " + appnum);

			APP_INDV_IMG_Collection indvColl = houseHoldBo.loadImmigrationInfo(appnum, statusCd);
			if (!indvColl.isEmpty()) {
				pageCollection.put(APP_INDV_IMG_COLL, indvColl);
			}

		} catch (FwException e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.loadImmigrationInfo()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), "loadImmigrationInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.loadImmigrationInfo() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				txnBean);
	}

	@SuppressWarnings("squid:S4973")
	public void removeImmigrationInfo(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.removeImmigrationInfo() - START", txnBean);
		try {
			Map pageColl = txnBean.getPageCollection();
			String appNum = txnBean.getUserDetails().getAppNumber();
			Integer seqNum = null;
			Integer indvSeqNum = null;
			String statusCd = "Y";
			if (Objects.nonNull(txnBean.getCurrentActionDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.getIndividualSequence());
			}
			if (Objects.nonNull(txnBean.getCurrentActionDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			Integer indvId = (Integer) pageColl.get("indvId");

			APP_INDV_IMG_Collection appIndvCollection = (APP_INDV_IMG_Collection) pageColl.get(APP_INDV_IMG_COLL);
			APP_INDV_Cargo immiCargo = new APP_INDV_Cargo();
			APP_INDV_IMG_Cargo cargo;

			for (int i = 0; i < appIndvCollection.size(); i++) {
				if (null != appIndvCollection && !appIndvCollection.isEmpty()) {
					cargo = appIndvCollection.getCargo(i);
					if (null != cargo && null != cargo.getIndv_seq_num() && null != indvSeqNum
							&& cargo.getIndv_seq_num().equals(indvId)) {
						immiCargo.setApp_num(appNum);
						immiCargo.setIndv_seq_num(indvSeqNum);
						immiCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
						immiCargo.setAlien_num(null);
						immiCargo.setAlien_status_cd(null);
						immiCargo.setFst_nam(cargo.getFst_nam());
						immiCargo.setLast_nam(cargo.getLast_nam());
						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"HouseHoldDemographicsIndividualServiceImpl.removeImmigrationInfo() - deleting info for "
										+ appNum + " " + indvSeqNum + " " + seqNum);
						houseHoldBo.storeImmigrationDetail(immiCargo);
					}
				}
			}

			APP_INDV_IMG_Collection indvColl = houseHoldBo.loadImmigrationInfo(appNum, statusCd);
			pageColl.put(APP_INDV_IMG_COLL, indvColl);

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.removeImmigrationInfo()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), "removeImmigrationInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.removeImmigrationInfo() - END",
				txnBean);

	}

	private void removeMedicalOrMeicareInfo(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.removeMedicalAndMeicareInfo() - START", txnBean);
		try {
			UserDetails userDetails = txnBean.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Integer individualSequence = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			String pageId = txnBean.getCurrentActionDetails().getPageId();
			APP_INDV_Cargo appIndvCargoext = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNumber),
					individualSequence);
			if (HouseHoldDemoGraphicsConstants.MCEMS.equalsIgnoreCase(pageId)) {
				appIndvCargoext.setExtra_medicare_beneficiary_name(null);
				appIndvCargoext.setExtra_medicare_premium(null);
				appIndvCargoext.setExtra_medicare_ind(null);
			}
			if (HouseHoldDemoGraphicsConstants.MCOSS.equalsIgnoreCase(pageId)) {
				appIndvCargoext.setSsn_num(null);
				appIndvCargoext.setBrth_dt(null);
				appIndvCargoext.setApply_for_medical_sw(null);

			}
			//set update date
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			appIndvCargoext.setUpdate_dt(currentTimeStamp);
			cpAppIndvRepository.save(appIndvCargoext);
			getMedicalOrMeicareInfo(txnBean);
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.removeMedicalAndMeicareInfo()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), "removeMedicalAndMeicareInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.removeMedicalAndMeicareInfo() - END", txnBean);

	}
	@SuppressWarnings("squid:S3776")
	public void getMedicalOrMeicareInfo(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getMedicalOrMeicareInfo() - Start", fwTxn);
		try {
			APP_INDV_Cargo[] appIndvArray = null;
			APP_INDV_Collection appIndvCollToRequest = null;
			String appNumber = null;
			UserDetails userDetails = fwTxn.getUserDetails();
			appNumber = userDetails.getAppNumber();
			Map<String, Object> pageCollection = fwTxn.getPageCollection();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			if (indvIds != null) {
				List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());

				appIndvArray = cpAppIndvRepository.loadIndvDataByIndvIds(Integer.parseInt(appNumber), indvIdList);
			}

			String pageId = fwTxn.getCurrentActionDetails().getPageId();

			if (null != appIndvArray && appIndvArray.length > 0) {
				appIndvCollToRequest = new APP_INDV_Collection();
				for (APP_INDV_Cargo cargo : appIndvArray) {
					if (HouseHoldDemoGraphicsConstants.MCEMS.equalsIgnoreCase(pageId) && (StringUtils
							.isNotEmpty(cargo.getExtra_medicare_beneficiary_name())
							|| (cargo.getExtra_medicare_premium() != null && cargo.getExtra_medicare_premium() >= 0))) {
						appIndvCollToRequest.addCargo(cargo);
					}
					if (HouseHoldDemoGraphicsConstants.MCOSS.equalsIgnoreCase(pageId) && (StringUtils
							.isNotEmpty(cargo.getSsn_num())
							|| (cargo.getBrth_dt() != null && StringUtils.isNotEmpty(cargo.getBrth_dt().toString())))) {
						appIndvCollToRequest.addCargo(cargo);
					}
				}
				pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollToRequest);
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.getMedicalOrMeicareInfo()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), "getMedicalOrMeicareInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getMedicalOrMeicareInfo() - END", fwTxn);

	}

	public void storeMedicalOrMeicareInfo(final FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeMedicalOrMeicareInfo() - START", fwTxn);
		try {
			final Map<String, Object> pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Integer indvSeqNum = 0;

			if (null != fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence()) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}

			APP_INDV_Collection appIndvCollFromDB = null;
			APP_INDV_Collection appIndvCollFromRequest = null;
			APP_INDV_Cargo appIndvCargoFromRequest = null;

			appIndvCollFromRequest = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			appIndvCollFromDB = cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNumber), indvSeqNum);
			if (null != appIndvCollFromRequest && !appIndvCollFromRequest.isEmpty()) {
				appIndvCargoFromRequest = appIndvCollFromRequest.getCargo(0);

				if (null != appIndvCollFromDB && appIndvCollFromDB.size() > 0) {
					APP_INDV_Cargo appIndvCargoFromDB = appIndvCollFromDB.getCargo(0);

					appIndvCargoFromDB.setBrth_dt(appIndvCargoFromRequest.getBrth_dt());
					appIndvCargoFromDB.setSsn_num(appIndvCargoFromRequest.getSsn_num());
					appIndvCargoFromDB.setExtra_medicare_beneficiary_name(
							appIndvCargoFromRequest.getExtra_medicare_beneficiary_name());
					appIndvCargoFromDB.setExtra_medicare_premium(appIndvCargoFromRequest.getExtra_medicare_premium());
					if (appIndvCargoFromRequest.getFlowType().equalsIgnoreCase("MediCal")) {
						appIndvCargoFromDB.setApply_for_medical_sw("Y");
					} else if (appIndvCargoFromRequest.getFlowType().equalsIgnoreCase("ExtraMedicare")) {
						appIndvCargoFromDB.setExtra_medicare_ind("Y");
					}
					//set update date
					Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
					appIndvCargoFromDB.setUpdate_dt(currentTimeStamp);
					cpAppIndvRepository.save(appIndvCargoFromDB);
					appIndvCollFromRequest.set(0, appIndvCargoFromDB);
					pageCollection.replace(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollFromRequest);

				}
			}

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.storeMedicalOrMeicareInfo()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), "storeMedicalOrMeicareInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.storeMedicalOrMeicareInfo() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS,
				fwTxn);
	}

	private void persistAddressChangedInd(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.persistAddressChangedInd() - START", fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Integer primaryApplicantIndvSeqNum = getPrimaryApplicantIndvSeqNum(appNumber);
			List<CP_APP_RGST_Cargo> rgstCargoListFromDB = null;
			rgstCargoListFromDB = (List<CP_APP_RGST_Cargo>) cpAppRgstRepos.getRgstListByAppNum(Integer.parseInt(appNumber));
			final CP_APP_RGST_Collection appRgstCollection = (CP_APP_RGST_Collection) pageCollection
					.get(CP_APP_RGST_COLL);
			if (Objects.nonNull(appRgstCollection) && appRgstCollection.size() > 0) {
				CP_APP_RGST_Cargo appRgstCargoFromFE = appRgstCollection.getCargo(0);
				if (Objects.nonNull(appRgstCargoFromFE.getAddress_change_ind())) {
					settingDataToRgstCargo(appRgstCargoFromFE, rgstCargoListFromDB);
				}
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.persistAddressChangedInd()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), "persistAddressChangedInd",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.persistAddressChangedInd() - END", fwTxn);
	}

	@SuppressWarnings({"squid:S4973","squid:S3776"})
	private void settingDataToRgstCargo(CP_APP_RGST_Cargo appRgstCargoFromFE,
			List<CP_APP_RGST_Cargo> rgstCargoListFromDB) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.persistAddressChangedInd() - START");
		try {
			if (Objects.nonNull(rgstCargoListFromDB)) {
				for (CP_APP_RGST_Cargo cargoFromDb : rgstCargoListFromDB) {
					if (appRgstCargoFromFE.getIndv_seq_num() == cargoFromDb.getIndv_seq_num()) {
						if (Objects.nonNull(appRgstCargoFromFE.getAddress_change_ind()) && appRgstCargoFromFE
								.getAddress_change_ind().equalsIgnoreCase(HouseHoldDemoGraphicsConstants.N)) {
							cargoFromDb.setChg_eff_dt(null);
						} else {
							if (Objects.nonNull(appRgstCargoFromFE.getChg_eff_dt()))
								cargoFromDb.setChg_eff_dt(appRgstCargoFromFE.getChg_eff_dt());
						}
						cargoFromDb.setAddress_change_ind(appRgstCargoFromFE.getAddress_change_ind());
						cp_app_rgst_repo.save(cargoFromDb);
					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.persistAddressChangedInd()");
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsServiceImpl.persistAddressChangedInd() - END");
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void saveDeceasedInfo(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.DeceasedInfo() - Start");
		try {
			final Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String pageID = txnBean.getCurrentActionDetails().getPageId();
			String appNumber = userDetails.getAppNumber();
			APP_INDV_Cargo appIndvCargoDeceased = new APP_INDV_Cargo();
			Integer indvSeqNum = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			APP_INDV_Collection deceasedColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			if (deceasedColl != null && !deceasedColl.isEmpty()) {
				appIndvCargoDeceased = deceasedColl.getCargo(0);
			}
			APP_INDV_Cargo appIndvCargoext = cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNumber), indvSeqNum);
			if ((appIndvCargoext) != null) {
				appIndvCargoext.setDeceased_ind(appIndvCargoDeceased.getDeceased_ind());
				appIndvCargoext.setDecease_dt(appIndvCargoDeceased.getDecease_dt());
				appIndvCargoext.setDeceaseComments(appIndvCargoDeceased.getDeceaseComments());
				//set update date
				Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
				appIndvCargoext.setUpdate_dt(currentTimeStamp);
				cpAppIndvRepository.save(appIndvCargoext);
			} else {
				cpAppIndvRepository.save(appIndvCargoDeceased);
			}

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), Level.ERROR, "saveDeceasedInfo", fe);
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.saveDeceasedInfo() - END");
	}

	/*
	 * 
	 * Update the indicators and the respective data fileds in backend on selection
	 * of No in gatepost
	 * 
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void updateMedicalOrMeicareInfo(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.updateMedicalOrMeicareInfo() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appNumber = userDetails.getAppNumber();

			String pageId = txnBean.getCurrentActionDetails().getPageId();
			APP_INDV_Collection appIndvColl = cpAppIndvRepository.loadCpAppIndvDetails(Integer.parseInt(appNumber));

			for (int i = 0; i < appIndvColl.size(); i++) {
				APP_INDV_Cargo appIndvCargoext = appIndvColl.getCargo(i);

				if (HouseHoldDemoGraphicsConstants.RMCEM.equalsIgnoreCase(pageId)) {
					String extraMedicareInd = (String) pageCollection.get("extra_medicare_ind");
					if ("N".equalsIgnoreCase(extraMedicareInd)) {
						appIndvCargoext.setExtra_medicare_ind("N");
					}else {
						appIndvCargoext.setExtra_medicare_ind(null);
					}
					appIndvCargoext.setExtra_medicare_beneficiary_name(null);
					appIndvCargoext.setExtra_medicare_premium(null);
				}

				if (HouseHoldDemoGraphicsConstants.MCOQH.equalsIgnoreCase(pageId)) {
					String applyForMedicalSw = (String) pageCollection.get("apply_for_medical_sw");
					if ("N".equalsIgnoreCase(applyForMedicalSw)) {
						appIndvCargoext.setApply_for_medical_sw("N");
					} else {
						appIndvCargoext.setApply_for_medical_sw(null);
					}
					appIndvCargoext.setSsn_num(null);
					// appIndvCargoext.setBrth_dt(null);
				}

				cpAppIndvRepository.save(appIndvCargoext);
			}

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographicsServiceImpl.updateMedicalOrMeicareInfo()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), "updateMedicalOrMeicareInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.updateMedicalOrMeicareInfo() - END", txnBean);

	}
	
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void updateUpdateDateForApp(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.updateUpdateDateForApp() - START", txnBean);
	try {
		UserDetails userDetails = txnBean.getUserDetails();
		String appNum = userDetails.getAppNumber();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"appNum : " + appNum, txnBean);
		APP_RQST_Collection rqstCollection = appRqstRepository.getByAppNum(Integer.parseInt(appNum));
		if (null != rqstCollection && !rqstCollection.isEmpty()) {
			APP_RQST_Cargo rqstCargo = rqstCollection.getCargo(0);

			rqstCargo.setUpdt_dt(fwDate.getDate());
			rqstCollection.setCargo(0, rqstCargo);
			appRqstRepository.save(rqstCargo);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"appNum exists", txnBean);
		}
	}catch (Exception e) {
		FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
				"Error occured in HouseholdDemographicsServiceImpl.updateUpdateDateForApp()", txnBean);
		FwExceptionManager.handleException(e, this.getClass().getName(), "updateUpdateDateForApp",
				txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
	}
	FwLogger.log(this.getClass(), FwLogger.Level.INFO,
			"HouseholdDemographicsService.updateUpdateDateForApp() - END", txnBean);
	}
	
	@Transactional
	public void deleteAPDELPage(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.deleteAppDetails() - START", fwTxn);
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();

			abcreateAppNumBO.deleteAppDetails(appNum);
			abcreateAppNumBO.setSspAppNumAsNull(appNum);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error Occured in HouseholdDemographicsService.deleteAppDetails()", fwTxn);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteAppDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsService.deleteAppDetails() - END",
				fwTxn);
	}
	
	public void getApplicationSummaryData(FwTransaction fwTxn)
	{
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getApplicationSummaryData() - START", fwTxn);
		try {
			this.getAFBIndividualDetails(fwTxn);
			houseHoldSummaryService.getPrflData(fwTxn);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getApplicationSummaryData",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.getApplicationSummaryData() - END", fwTxn);
	}

	@Transactional
	public void deleteWhenHomeless(FwTransaction fwTxn){
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.deleteWhenHomeless() - START", fwTxn);
		Map pageCollection = fwTxn.getPageCollection();
		try {
			UserDetails userDetails = fwTxn.getUserDetails();			
			String appNumber = (String) userDetails.getAppNumber();
			Integer indv_seq_num = 0;
			if (null != (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence())
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indv_seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			
			CP_APP_RGST_Collection contactColl;
			CP_APP_RGST_Cargo contactCargo;
			CP_APP_RGST_Cargo exsitingCargo;

			if (pageCollection.containsKey(CP_APP_RGST_COLL) && (pageCollection.get(CP_APP_RGST_COLL) != null)) {
				exsitingCargo = cpAppRgstRepo.getCpAppRgstDetails(Integer.parseInt(appNumber), indv_seq_num);
				if(exsitingCargo != null) {
					contactColl = (CP_APP_RGST_Collection) pageCollection.get(CP_APP_RGST_COLL);
					contactCargo = contactColl.getCargo(0);
					contInfoBO.storeContactInformation(contactCargo);
				}
			}
		}
		catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, DELETE_WHEN_HOMELESS_ERROR, fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteWhenHomeless",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsService.deleteWhenHomeless() - END", fwTxn);
	}
	
    public void getAppStatusByAppNum(FwTransaction fwTxn)
    {
        try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
			        "HouseholdDemographicsService.getAppStatusByAppNum() - START", fwTxn);
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			Map pageCollection = fwTxn.getPageCollection();
			APP_RQST_Collection appNumberDetails = new APP_RQST_Collection();
			if(appNumber!= null && !appNumber.isEmpty())
			{
			    appNumberDetails = appRqstRepository.getByAppNum(Integer.parseInt(appNumber));
			}
			else
			{
			    FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "getAppStatusByAppNum :: appNumber is empty or null appNumber ->"+appNumber);
			}
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION, appNumberDetails);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDemographicsService.getAppStatusByAppNum() - END", fwTxn);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "getAppStatusByAppNum", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getAppStatusByAppNum",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
    }

}