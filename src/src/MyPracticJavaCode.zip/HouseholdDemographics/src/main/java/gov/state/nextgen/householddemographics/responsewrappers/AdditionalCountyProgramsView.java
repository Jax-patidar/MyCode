package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;


@Component("ABACP")
@Scope("prototype")
public class AdditionalCountyProgramsView implements LogicResponseInterface{


	
	private static final String PAGE_ID = "ABACP";
	
	private static final String APP_PGM_RQST_COLL = "APP_PGM_RQST_Collection";
	
	private static final String APP_RGST_COLL = "APP_RGST_Collection";

	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTxn.getPageCollection();
		
		//For APP_INDV.
		List<APP_PGM_RQST_Cargo> rqstList = new ArrayList<APP_PGM_RQST_Cargo>();
		APP_PGM_RQST_Cargo rqstCargo;
		APP_PGM_RQST_Collection rqstColl = pageCollection.get(APP_PGM_RQST_COLL) != null ? (APP_PGM_RQST_Collection) pageCollection.get(APP_PGM_RQST_COLL) : null;
		
		if(rqstColl != null && !rqstColl.isEmpty() && rqstColl.size() >0) {			
			for (int i = 0; i < rqstColl.size(); i++) {
				rqstCargo = (APP_PGM_RQST_Cargo) rqstColl.get(i);
				rqstList.add(rqstCargo);
			}
		}
		
		//For APP_RGST
		List<APP_RGST_Cargo> rgstList = new ArrayList<APP_RGST_Cargo>();
		APP_RGST_Cargo rgstCargo;
		APP_RGST_Collection rgstCollection = pageCollection.get(APP_RGST_COLL) != null ? (APP_RGST_Collection) pageCollection.get(APP_RGST_COLL) : null;
		
		if(rgstCollection != null && !rgstCollection.isEmpty() && rgstCollection.size() >0) {			
			for (int i = 0; i < rgstCollection.size(); i++) {
				rgstCargo = (APP_RGST_Cargo) rgstCollection.get(i);
				rgstList.add(rgstCargo);
			}
		}
		
		driverPageResponse.getPageCollection().put(APP_PGM_RQST_COLL, rqstList);
		driverPageResponse.getPageCollection().put(APP_RGST_COLL, rgstList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		
		return driverPageResponse;
		
		
	}
	



}
