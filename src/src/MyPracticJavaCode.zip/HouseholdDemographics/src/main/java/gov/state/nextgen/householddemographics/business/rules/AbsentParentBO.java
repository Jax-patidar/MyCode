/*
 * 
 */
package gov.state.nextgen.householddemographics.business.rules;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_ABSNP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.data.db2.CpAbsPrntRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInAbsnpRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.access.management.logging.FwLogger;

/**
 * ABAbsentParentBO - Business Object skeleton auto generated - Architecture
 * Team
 *
 * Creation Date :Tue Dec 27 11:22:35 CST 2005 Modified By: Modified on:
 */
@Service
public class AbsentParentBO extends AbstractHouseHoldBO {

	@Autowired
	private CpAbsPrntRepository cpAbsPrntRepository;
	
	private CpAppInAbsnpRepository cpAppInAbsnpRepository;
	
	private CpAppIndvRepository cpAppIndvRepo;

	@Autowired
	private CpAppPgmRqstRepository cpAppPgmRqstRepository;
	
	/**
	 * Constructor
	 */
	public AbsentParentBO() {
	}
	
	public void storeAbsentParentDetails(APP_ABS_PRNT_Cargo appAbsPrrntCargo) {
		cpAbsPrntRepository.save(appAbsPrrntCargo);
	}
	
	public void storeAbsentParentDetails(APP_IN_ABSNP_Cargo appInAbsnpCargo) {
		cpAppInAbsnpRepository.save(appInAbsnpCargo);
	}
	
	public APP_ABS_PRNT_Cargo loadAbsentParentDetails(String appNum, String firstName, String lastName, String sexInd, String srcAppInd) {
		return cpAbsPrntRepository.findByAppFstLstNmSexSrcInd(Integer.parseInt(appNum), firstName, lastName, sexInd, srcAppInd);
	}
	
	public List<APP_ABS_PRNT_Cargo> loadAbsentParentDetails(String appNum, String srcAppInd){
		return cpAbsPrntRepository.findByAppNumSrcInd(Integer.parseInt(appNum), srcAppInd);
	}

	public void storeParentSituationAbsentDetails(APP_ABS_PRNT_Cargo appabscargo) {
		try {

				cpAbsPrntRepository.save(appabscargo);
		}catch (final FwException fe) {
            final FwWrappedException fwWrappedException = new FwWrappedException(fe);
            fwWrappedException.setCallingClassID(getClass().getName());
            fwWrappedException.setCallingMethodID("saveRelationshipandBuyPrepareNewDetails");
            fwWrappedException.setFwException(fe);
            throw fwWrappedException;
        } catch (final Exception exception) {
            throw exception;
        }
		
	}
	public APP_ABS_PRNT_Collection loadParentSituationAbsentDetails(String appnum) {
		return cpAbsPrntRepository.loadParentSituationAbsentDetails(Integer.parseInt(appnum));
	}
	
	public APP_INDV_Collection loadParentSituation(

			final String appNumber) {


		final long startTime = System.currentTimeMillis();

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,

				"ParentSituation.loadParentSituation() - START, Time Taken : "

						+ (System.currentTimeMillis() - startTime)

						);

		try {


			APP_INDV_Collection appInColl;


			appInColl = cpAppIndvRepo.getByAppNum1(Integer.parseInt(appNumber));


			FwLogger.log(this.getClass(), FwLogger.Level.INFO,


					"ParentSituation.loadParentSituation() - END, Time Taken : "

							+ (System.currentTimeMillis() - startTime)


							);

			return appInColl;

		} catch (final FwException fe) {


			throw fe;


		} catch (final Exception e) {


		throw e;


		}


	}


	public void storeParentSituationIndvInfo(


			final APP_INDV_Collection appIndvInfoColl) {




		final long startTime = System.currentTimeMillis();


		FwLogger.log(this.getClass(), FwLogger.Level.INFO,


				"AbsentParentInfo.storeParentSituationIndvInfo() - START, Time Taken : "


						+ (System.currentTimeMillis() - startTime)


						);


		try {


			if (appIndvInfoColl != null && !appIndvInfoColl.isEmpty()) {


				APP_INDV_Cargo cargo;


				cargo = appIndvInfoColl.getCargo(0);


				cpAppIndvRepo.save(cargo);
			}

		} catch (final FwException fe) {
			throw fe;

		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"AbsentParentInfo.storeParentSituationIndvInfo() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						);
	}
	
			// Load PGM Table
			public APP_PGM_RQST_Collection loadProgrammeSelection(String appPgmRqstCargo) {
				return cpAppPgmRqstRepository.loadProgrammeSelection(Integer.parseInt(appPgmRqstCargo));
			}

			// code for storing in App_indv Table
			public void storeParentSituationDetails(APP_INDV_Cargo appIndvCargo) {
						cpAppIndvRepo.save(appIndvCargo);
			}
}

