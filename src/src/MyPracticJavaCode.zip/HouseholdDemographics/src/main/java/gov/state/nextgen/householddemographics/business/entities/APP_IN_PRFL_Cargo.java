package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;


public class APP_IN_PRFL_Cargo extends AbstractCargo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String app_num;
	@Id
	private Integer indv_seq_num;
	private String dabl_resp;
	private String dependent_care_resp;
	private String fstr_care_resp;
	private Double indv_fs_request_ind;
	private String kinship_care_resp;
	private String med_exp_resp;
	private String mil_allot_resp;
	private String preg_resp;
	private String rcv_fs_other_st_resp;
	private String schl_enrl_resp;
	private String su_cst_fuel_resp;
	private String su_cst_mtge_resp;
	private String su_cst_phn_resp;
	private String dup_food_assisstance;
	private String work_comp_resp;
	private String other_asset_bur_resp;
	private String other_asset_veh_resp;
	private String cash_gifts_resp;
	private String child_support_income_resp;
	private String current_new_job_resp;
	private String food_clothing_util_rent_resp;
	private String insurance_settlement_resp;
	private String liquid_asset_money_lgl_resp;
	private String parole_violation_resp;
	private String real_asset_home_resp;
	private String money_mkt_account;
	private String real_asset_unoccupy_home_resp;
	private String shlt_expense_resp;
	private String income_room_boarder_resp;
	private String cnvct_of_tr_fs_drg_resp;
	private String comm_care_resp;
	private String uei_lottery_win_resp;
	private String cnvct_of_tr_fs_gun_resp;
	private String hshl_primary_care_taker_ind;
	private String pers_prop_livestock;
	private String housing_bill_mortgage_resp;
	private String liquid_asset_trust_fund_resp;
	private String uei_net_rent_royalty_resp;
	private String uei_int_div_pymt_resp;
	private String housing_bill_prop_tax_resp;
	private String liquid_asset_ira_resp;
	private String uei_alimony_resp;
	private String other_income_contrib_resp;
	private String cash_stp_pnl_sanc;
	private String special_needs_resp;
	private String liquid_asset_stocks_bonds_resp;
	private String cnvct_of_buy_sell_fs_resp;
	private String pers_prop_saf_depst_box;
	private String rcv_benefit_other_st_resp;
	private String breast_feed_resp;
	private String former_fstr_care_resp;
	private String pers_prop_bus_eqpt;
	private String uei_pension_resp;
	private String uei_rr_retire_resp;
	private String med_type_spec_needs_resp;
	private String cash_stp_welf_frd;
	private String med_type_thr_mnth_resp;
	private String med_type_sixty_dabl_resp;
	private String er_med_care_resp;
	private String health_insurance_resp;
	private String tanf_fund_misuse_resp;
	private String btd_other;
	private String tanf_disqualify_resp;
	private String file_tax_resp;
	private String bonds;
	private String cash;
	private String checkin_account;
	private String savings_account;
	private String loan_rcvd;
	private String sell_ebt_card;
	private String leave_ca;
	private String strike_benefits;
	private String included_unearned_income;
	private String health_insurance_ninety_end_resp;
	private String in_kind_support;
	private String avd_prsctn_fstf;
	private String su_cst_wtr_swr_trsh_resp;
	private String housing_bill_hless_shlt_resp;
	private String liquid_asset_cert_resp;
	private String oil_min_rts;
	private String uncshd_checks;
	private String other_asset_resp;
	private String real_asset_home_mov_resp;
	private String pers_prop_jwl_art;
	private String pers_prop_gds_guns;
	private String pers_prop_pers_tools;
	private String pers_prop_bus_tools;
	private String pers_prop_bus_invent;
	private String pers_trl_bts;
	private String pers_prop_camp_shell;
	private String child_support_exp_resp;
	private String change_in_cash_bonus_penalty;
	private String change_in_cash_dvrsn_payment_noncash_serv;
	private String change_in_disb_or_retirement;
	private String change_in_finance_aid;
	private String change_in_prgm_asst;
	private String change_in_ssi_or_ssp;
	private String change_in_ssr;
	private String change_in_tribal_payments;
	private String change_in_vetinc_or_edubenefit;
	private String change_in_unempl_or_sdi;
	private String special_needs_desc;
	private String unabl_buy_food_sixty;
	private String med_type_three_month_resp;
	private String change_in_ssd;
	private String uei_net_farm_fish_resp;
	private String teen_prnt_resp;
	@Transient
	private Integer indv_fma_rqst_ind;
	@Transient
	private Integer indv_fs_rqst_ind;
	@Transient
	private Integer indv_tanf_rqst_ind;
	@Transient
	private Integer indv_cc_rqst_ind;
	@Transient
	private Integer indv_wic_rqst_ind;
	@Transient
	private Integer indv_magi_rqst_ind;
	@Transient
	private String indv_peach_rqst_ind;
	@Transient
	private Integer indv_ca_rqst_ind;
	@Transient
	private Integer indv_cr_rqst_ind;
	@Transient
	private Integer indv_fu_rqst_ind;
	@Transient
	private String refusal_to_work_resp;
	@Transient
	private String presc_drug_resp;
	@Transient
	private String association_fee_resp;
	@Transient
	private String unocc_home_paymt_resp;
	@Transient
	private String other_housing_bill_resp;
	@Transient
	private String prsnl_care_provided_resp;
	@Transient
	private String othr_incm_unemp_bnfts_resp;
	@Transient
	private String out_patient_treatment_resp;
	@Transient
	private String med_equip_supplies_resp;
	@Transient
	private String diabets_edu_prg_resp;
	@Transient
	private Integer indv_fpw_rqst_ind;
	@Transient
	private String othr_incm_rentl_resp;
	@Transient
	private String postage_mail_presc_resp;
	@Transient
	private String hlth_hosp_insurance_resp;
	@Transient
	private String othr_incm_trbl_ga_resp;
	@Transient
	private String attdt_hsekpr_srvc_animal_resp;
	@Transient
	private String child_care_provider_resp;
	@Transient
	private String resettlement_incm_resp;
	@Transient
	private String nursing_care_resp;
	@Transient
	private String trbl_ser_resp;
	@Transient
	private String med_dent_vision_services_resp;
	@Transient
	private String land_contract_mortgage_resp;
	@Transient
	private Integer indv_ebd_rqst_ind;
	@Transient
	private Integer indv_hc_rqst_ind;
	@Transient
	private String acdt_resp;
	@Transient
	private String adpt_asst_resp;
	@Transient
	private String almy_rcv_resp;
	@Transient
	private String bnft_anty_resp;
	@Transient
	private String bnft_chl_sprt_resp;
	@Transient
	private String bnft_chrt_resp;
	@Transient
	private String bnft_dabl_resp;
	@Transient
	private String bnft_divnd_resp;
	@Transient
	private String bnft_est_trst_resp;
	@Transient
	private String bnft_rr_resp;
	@Transient
	private String bnft_uempl_resp;
	@Transient
	private String bnft_vet_resp;
	@Transient
	private String chld_sprt_pay_resp;
	@Transient
	private String dpnd_care_resp;
	@Transient
	private String drug_feln_resp;
	@Transient
	private String empl_resp;
	@Transient
	private String fset_sctn_resp;
	@Transient
	private String gen_rlf_resp;
	@Transient
	private String incm_dcon_resp;
	@Transient
	private String incm_int_resp;
	@Transient
	private String job_iknd_resp;
	@Transient
	private String loss_empl_resp;
	@Transient
	private String med_ins_resp;
	@Transient
	private String medcr_ettl_resp;
	@Transient
	private String mony_othr_resp;
	@Transient
	private String natl_rfge_resp;
	@Transient
	private String need_ind_resp;
	@Transient
	private String on_strk_sw;
	@Transient
	private String op_aoda_tmt_rcv_sw;
	@Transient
	private String othr_incm_resp;
	@Transient
	private String othr_src_resp;
	@Transient
	private String pay_rmr_brd_resp;
	@Transient
	private String pnsn_retr_resp;
	@Transient
	private String prop_sold_resp;
	@Transient
	private String rcv_fs_oth_st_resp;
	@Transient
	private String rcv_ss_resp;
	@Transient
	private String rcv_ssi_ever_resp;
	@Transient
	private String rcv_ssi_ltr_resp;
	@Transient
	private String rcv_ssi_sw;
	@Transient
	private String rmr_brd_inc_resp;
	@Transient
	private String self_empl_resp;
	@Transient
	private String sep_fs_rqst_sw;
	@Transient
	private String shlt_cst_resp;
	@Transient
	private String ssi_1619b_rcv_sw;
	@Transient
	private String su_cst_ases_resp;
	@Transient
	private String su_cst_coal_resp;
	@Transient
	private String su_cst_elec_resp;
	@Transient
	private String su_cst_gas_resp;
	@Transient
	private String su_cst_home_resp;
	@Transient
	private String su_cst_istl_resp;
	@Transient
	private String su_cst_lpgas_resp;
	@Transient
	private String su_cst_mbl_resp;
	@Transient
	private String su_cst_othr_resp;
	@Transient
	private String su_cst_rent_resp;

	@Transient
	private String cool_exp_resp;

	@Transient
	private String ser_rqst_ind;

	@Transient
	private String ser_eb_resp;

	@Transient
	private String ser_ed_resp;

	@Transient
	private String ser_hd_resp;

	@Transient
	private String ser_he_resp;

	@Transient
	private String ser_fr_resp;

	@Transient
	private String garnishment_resp;

	@Transient
	private String basic_allow_housing_mil_resp;

	@Transient
	private String cloth_maint_allow_mil_resp;

	@Transient
	private String other_deduction_resp;

	@Transient
	private String deduction_resp;

	@Transient
	private String bnft_bl_resp;

	@Transient
	private String bnft_va_resp;

	@Transient
	private String emergency_medical_service_resp;

	@Transient
	private String head_of_household_resp;
	@Transient
	private String hlth_insurance_cur_cvrg_resp;
	@Transient
	private String hlth_insurance_past_cvrg_resp;

	@Transient
	private String housing_bill_home_ins_resp;

	@Transient
	private String housing_bill_others_resp;
	@Transient
	private String income_change_resp;
	

	@Transient private String su_cst_swr_resp;
	@Transient private String su_cst_tax_resp;
	
	@Transient private String su_cst_trsh_resp;
	
	@Transient private String su_cst_wood_resp;
	
	@Transient private String su_cst_wtr_resp;
	
	@Transient private String su_cst_wwt_resp;
	@Transient private String trb_tanf_resp;
	@Transient private String turn_down_job_resp;
	
	@Transient private String util_exp_resp;
	
	@Transient private String trb_cpta_resp;
	@Transient private String bury_aset_c_resp;
	@Transient private String bury_aset_ibt_resp;
	@Transient private String bury_aset_ins_resp;
	@Transient private String bury_aset_mas_resp;
	@Transient private String bury_aset_oth_resp;
	@Transient private String bury_aset_plt_resp;
	@Transient private String bury_aset_rbt_resp;
	@Transient private String bury_aset_v_resp;
	@Transient private String educ_aid_resp;
	
	@Transient private String li_aset_g_l_resp;
	@Transient private String li_aset_g_t_resp;
	@Transient private String li_aset_trm_resp;
	
	@Transient private String li_aset_unv_resp;
	@Transient private String li_aset_w_l_resp;
	
	@Transient private String lqd_aset_c_a_resp;
	@Transient private String lqd_aset_cash_resp;
	@Transient private String lqd_aset_eb_a_resp;
	@Transient private String lqd_aset_h_s_resp;
	@Transient private String lqd_aset_ira_resp;
	@Transient private String lqd_aset_k_p_resp;
	@Transient private String lqd_aset_m_o_resp;
	@Transient private String lqd_aset_mm_a_resp;
	@Transient private String lqd_aset_o_t_resp;
	@Transient private String lqd_aset_othr_resp;
	
	@Transient private String lqd_aset_s_a_resp;
	@Transient private String lqd_aset_s_c_resp;
	@Transient private String lqd_aset_st_b_resp;
	@Transient private String lqd_aset_tr_f_resp;
	
	@Transient private String lqd_aset_tx_s_resp;
	@Transient private String lqd_aset_us_b_resp;
	
	@Transient private String lqd_aset_xmas_resp;
	@Transient private String othr_aset_bur_resp;
	@Transient private String othr_aset_l_i_resp;
	@Transient private String othr_aset_p_p_resp;
	@Transient private String othr_aset_r_p_resp;
	@Transient private String othr_aset_veh_resp;
	@Transient private String othr_aset_xfr_resp;
	@Transient private String real_aset_apt_resp;
	@Transient private String real_aset_con_resp;
	@Transient private String real_aset_dup_resp;
	@Transient private String real_aset_frm_resp;
	@Transient private String real_aset_hse_resp;
	@Transient private String real_aset_lnd_resp;
	@Transient private String real_aset_m_h_resp;
	@Transient private String real_aset_oth_resp;
	@Transient private String veh_aset_arpl_resp;
	@Transient private String veh_aset_auto_resp;
	@Transient private String veh_aset_boat_resp;
	@Transient private String veh_aset_camp_resp;
	@Transient private String veh_aset_mcyc_resp;
	@Transient private String veh_aset_mped_rsp;
	@Transient private String veh_aset_nm_b_resp;
	@Transient private String veh_aset_othr_resp;
	@Transient private String veh_aset_rv_resp;
	@Transient private String veh_aset_s_mb_resp;
	@Transient private String veh_aset_trk_resp;
	@Transient private String veh_aset_trlr_resp;
	@Transient private String veh_aset_van_resp;
	@Transient private String veh_aset_fmeq_resp;
	@Transient private String emer_ma_resp;
	@Transient private String tb_resp;
	@Transient private String chld_trb_mbr_resp;
	@Transient private String trb_mbr_resp;
	@Transient private String yeohc_resp;

	@Transient private String legal_child_support_resp;
	@Transient private String liquid_aset_bank_acc_resp;
	
	@Transient private String liquid_asset_deed_trust_resp;
	@Transient private String liquid_asset_pension_plan_resp;
	@Transient private String liquid_asset_promissory_resp;
	@Transient private String liquid_asset_retirement_resp;
	
	@Transient private String loan_resp;
	
	@Transient private String medical_service_resp;
	@Transient private String medicare_part_a_b_d_resp;
	@Transient private String past_job_resp;
	
	@Transient private String pending_social_assistance_resp;
	
	@Transient private String prize_winning_resp;
	
	@Transient private String public_assistance_resp;
	
	@Transient private String prop_tax_mobile_home_resp;
	@Transient private String real_asset_life_estate_resp;
	@Transient private String real_estate_tax_resp;
	
	@Transient private String rent_exp_resp;
	
	@Transient private String student_financial_aid_resp;
	
	@Transient private String training_allowance_resp;
	@Transient private String work_related_expense_resp;
	
	@Transient private String utility_bills_kerosene_resp;
	@Transient private String lqd_asset_irs_collge_plan_resp;
	@Transient private String lqd_asset_irs_retirement_resp;
	
	@Transient private String vehicle_asset_animal_drwn_resp;
	 
	@Transient private String vehicle_asset_tractor_resp;
	@Transient private String vehicle_asset_golf_cart_resp;
	
	@Transient private String vehicle_asset_nmot_camper_resp;
	@Transient private String lifeinsurance_asset_other_resp;
	@Transient private String shelter_expense_resp;
	
	@Transient private String service_provider_co_resp;
	
	@Transient private String service_provider_fu_resp;
	
	@Transient private String service_provider_cr_resp;
	
	@Transient private String auth_rep_resp;
	
	@Transient private String benefits_on_strike_resp;
	@Transient private String othr_social_security_bnft_resp;
	
	@Transient private String uei_none_resp;
	@Transient private String uei_rental_incm_resp;
	
	@Transient private String liquid_asset_annuity_resp;
	@Transient private String elg_rcv_energy_assist_resp;
	
	@Transient private String liquid_asset_none_resp;
	
	@Transient private String othr_incm_dcss_sup_resp;
	
	@Transient private String li_aset_none_resp;
	
	@Transient private String mig_farm_wrkr_job_end_resp;
	
	@Transient private String curr_rcv_tanf_resp;
	@Transient private String real_aset_vac_resp;
	
	@Transient private String oth_bill_unpaid_med_resp;
	@Transient private String uei_gen_assist_resp;
	
	@Transient private String veh_aset_none_resp;
	
	@Transient private String housing_bill_rent_resp;
	@Transient private String uei_dr_relief_resp;
	
	@Transient private String oth_bill_chld_sup_oblig_resp;
	@Transient private String veh_aset_unlic_resp;
	@Transient private String cur_rcv_energy_assist_resp;
	@Transient private String avoid_pros_resp;
	@Transient private String uei_tanf_pymt_resp;
	@Transient private String pers_prop_oth_val;
	
	@Transient private String real_aset_none_resp;
	@Transient private String uei_ira_dist_resp;
	
	@Transient private String liquid_asset_irs_col_plan_resp;
	@Transient private String liquid_asset_irs_retirmnt_resp;
	
	@Transient private String real_aset_lest_resp;
	@Transient private String uei_edu_assist_resp;
	@Transient private String hospital_stay_resp;
	@Transient private String uei_worker_comp_resp;
	@Transient private String uei_death_bnft_resp;
	@Transient private String uei_energy_assist_resp;
	
	@Transient private String oth_bill_b_tax_ded_resp;
	
	@Transient private String house_assist_rcv_ind;
	
	@Transient private String oth_bill_incm_tax_ded_resp;
	
	@Transient private String house_hc_src_type_cd;
	
	@Transient private String mig_farm_wrkr_job_rate_resp;
	@Transient private String othr_incm_vets_bnft_resp;
	@Transient private String fs_disqualify_resp;
	@Transient private String pers_prop_cemetary_lot;
	
	@Transient private String lost_ins_spl_care_need_resp;
	
	@Transient private String mig_farm_wrkr_resp;
	
	@Transient private String othr_incm_ssi_resp;
	
	@Transient private String housing_bill_none_resp;
	@Transient private String uei_adoption_pymt_resp;
	
	@Transient private String lost_ins_new_born_resp;
	
	@Transient private String li_aset_oth_resp;
	@Transient private String cnvct_of_false_info_resp;
	@Transient private String grp_care_grc_resp;
	@Transient private String uei_capital_gains_resp;
	
	@Transient private String house_liheap_rcv_ind;
	@Transient private String othr_incm_contrib_resp;
	@Transient private String katie_beckett_medicaid_resp;
	
	@Transient private String lost_ins_empl_stop_resp;
	@Transient private String uei_pymt_bo_resp;
	@Transient private String rcv_hospice_care_resp;
	
	@Transient private String lost_ins_divorce_parent_resp;
	@Transient private String uei_oth_resp;
	@Transient private String uei_rel_care_resp;
	
	@Transient private String oth_bill_med_resp;
	@Transient private String uei_foster_care_pymt_resp;
	
	@Transient private String pub_hsa_rcv_pay_own_bill_ind;
	@Transient private String uei_lump_sum_resp;
	
	@Transient private String utility_bill_resp;
	
	@Transient private String oth_bill_chld_adult_care_resp;
	
	@Transient
	private String inheritance_resp;
	

	@Transient private String lost_ins_dis_fmcov_5pct_inc;
	
	@Transient private String house_rent_assist_type;
	@Transient private String rcv_bnft_oth_st_resp;
	@Transient private String chld_prot_srvs_resp;
	@Transient private String uei_agent_orng_pymt_resp;
	@Transient private String uei_worker_study_resp;
	@Transient private String uei_refugee_cash_resp;
	
	@Transient private String lost_ins_fmcov_5pct_inc;
	@Transient private String uei_anny_pymt_resp;
	@Transient private String uei_frm_alot_resp;
	@Transient private String uei_mil_alot_resp;
	@Transient private String bnft_ssi_ended_resp;
	@Transient private String real_aset_rental_resp;
	@Transient private String uei_dabl_incm_resp;
	@Transient private String uei_adoption_assist_resp;
	
	@Transient private String lost_ins_chg_empl_resp;
	@Transient private String trbl_ser_elg_resp;
	@Transient private String uei_unempl_resp;
	
	@Transient private String othr_incm_ss_resp;
	
	@Transient private String pers_prop_none;
	
	@Transient private String housing_bill_resp;
	
	@Transient private String liquid_asset_checking_acc_resp;
	@Transient private String medtyp_other;
	@Transient private String medtyp_attendant_care;
	@Transient private String medtyp_rx_cost;
	@Transient private String medtyp_insur_premium;
	@Transient private String medtyp_doctor;
	@Transient private String medtyp_hsa_contrib;
	@Transient private String medtyp_trans_med;
	@Transient private String able_to_conceive_resp;
	@Transient private String medtyp_med_equip;
	@Transient private String uei_mon_fro_oth_resp;
	@Transient private String medtyp_dental;
	@Transient private String medtyp_hosp_bills;
	@Transient private String underweight_birth_resp;
	@Transient private String trbl_hlth_serv_resp;
	
	@Transient private String lost_health_insurance_resp;
	
	@Transient private String nursing_home_care_resp;
	@Transient private String victim_dv_resp;
	@Transient private String indp_living_prg_resp;
	@Transient private String disaster_repair_resp;
	@Transient private String prevent_eviction_resp;
	@Transient private String other_housing_resp;
	
	@Transient private String medicare_resp;
	@Transient private String tax_claim_dependant_resp;
	
	@Transient private String tribal_ind_resp;
	@Transient private String btd_pre_tax_ins;
	@Transient private String btd_vis_care_ins;
	@Transient private String btd_dent_ins;
	@Transient private String income_tax_deduction;
	@Transient private String btd_flex_acc;
	 
	@Transient private String btd_def_comp;
	@Transient private String btd_med_ins;
	@Transient private String before_tax_resp;
	
	@Transient private String tax_dependents_outside_resp;
	@Transient private String oth_ind_gambl_pmnts;
	@Transient private String medicare_part_a;
	@Transient private String medicare_part_b;
	@Transient private String medicare_part_c;
	@Transient private String medicare_part_d;
	 
	@Transient private String ccsp_provider_payment;
	@Transient private String animals_to_assist_disabled;
	@Transient private String funeral_death_expense;
	@Transient private String blind_work_expense;
	@Transient private String impairment_work_expense;
	@Transient private String dividend;
	
	@Transient private String hlth_reimbur_acct;
	
	@Transient private String indv_dvlp_acct;
	@Transient private String uniform_gifts;
	@Transient private String income_from_resource;
	@Transient private String indian_gambling_payments;
	@Transient private String inheritance;
	@Transient private String insuance_benefits;
	@Transient private String loan_received;
	@Transient private String loan_repayment_income;
	@Transient private String managed_income;
	@Transient private String match_grant;
	@Transient private String montgomery_gi_bill;
	@Transient private String out_of_state_public;
	@Transient private String refunds_from_dch;
	@Transient private String restitutions_settlements;
	@Transient private String senior_companion;
	@Transient private String severance_pay;
	@Transient private String trade_readjustment;
	@Transient private String uniform_relocation;
	@Transient private String union_funds;
	@Transient private String vendor_excluded;
	@Transient private String victim_restitution;
	@Transient private String volunteer_payment;
	@Transient private String volunteer_payment_titlei;
	@Transient private String wia_training_and_allowance;
	@Transient private String tanf_max_au_allotment;
	@Transient private String tanf_max_grg_allotment;
	@Transient private String charitable_donation;
	@Transient private String child_nutrition_payments;
	@Transient private String black_lung_benefits;
	@Transient private String child_support_court;
	@Transient private String child_support_gap_payment;
	@Transient private String civil_service;
	
	@Transient private String deferred_compensation_plans;
	@Transient private String disability_insurance;
	@Transient private String excluded_unearned_income;
	@Transient private String fema_payment_disaster;
	@Transient private String fema_payment_non_disaster;
	@Transient private String health_savings_account;
	@Transient private String foster_grandparent_program;
	@Transient private String disaster_unemployment;
	@Transient private String dividends;
	@Transient private String charitable_donation_federal;
	
	@Transient private String trust_fund;
	@Transient private String patient_fund;
	@Transient private String disaster_assistance;
	@Transient private String non_business_equipment;
	@Transient private String household_goods;
	@Transient private String other_non_countable;
	
	
	@Transient private String death_benefit_state_federal;
	@Transient private String social_security_survivor;
	@Transient private String vendor_payments;
	@Transient private String cntrl_subs_resp;
	@Transient private String heat_cool_src;
	@Transient private String disq_snap_resp;
	@Transient private String plan_helthy_baby_res;
	@Transient private String liquid_asset_ida_resp;
	@Transient private String liquid_asset_hra_resp;
	
	
	

	public String getDeath_benefit_state_federal() {
		return death_benefit_state_federal;
	}

	public void setDeath_benefit_state_federal(String death_benefit_state_federal) {
		this.death_benefit_state_federal = death_benefit_state_federal;
	}

	public String getSocial_security_survivor() {
		return social_security_survivor;
	}

	public void setSocial_security_survivor(String social_security_survivor) {
		this.social_security_survivor = social_security_survivor;
	}

	public String getVendor_payments() {
		return vendor_payments;
	}

	public void setVendor_payments(String vendor_payments) {
		this.vendor_payments = vendor_payments;
	}

	public String getCntrl_subs_resp() {
		return cntrl_subs_resp;
	}

	public void setCntrl_subs_resp(String cntrl_subs_resp) {
		this.cntrl_subs_resp = cntrl_subs_resp;
	}

	public String getHeat_cool_src() {
		return heat_cool_src;
	}

	public void setHeat_cool_src(String heat_cool_src) {
		this.heat_cool_src = heat_cool_src;
	}

	public String getDisq_snap_resp() {
		return disq_snap_resp;
	}

	public void setDisq_snap_resp(String disq_snap_resp) {
		this.disq_snap_resp = disq_snap_resp;
	}

	public String getPlan_helthy_baby_res() {
		return plan_helthy_baby_res;
	}

	public void setPlan_helthy_baby_res(String plan_helthy_baby_res) {
		this.plan_helthy_baby_res = plan_helthy_baby_res;
	}

	public String getLiquid_asset_ida_resp() {
		return liquid_asset_ida_resp;
	}

	public void setLiquid_asset_ida_resp(String liquid_asset_ida_resp) {
		this.liquid_asset_ida_resp = liquid_asset_ida_resp;
	}

	public String getLiquid_asset_hra_resp() {
		return liquid_asset_hra_resp;
	}

	public void setLiquid_asset_hra_resp(String liquid_asset_hra_resp) {
		this.liquid_asset_hra_resp = liquid_asset_hra_resp;
	}

	public String getInheritance_resp() {
		return inheritance_resp;
	}

	public void setInheritance_resp(String inheritance_resp) {
		this.inheritance_resp = inheritance_resp;
	}

	public String getLost_ins_dis_fmcov_5pct_inc() {
		return lost_ins_dis_fmcov_5pct_inc;
	}

	public void setLost_ins_dis_fmcov_5pct_inc(String lost_ins_dis_fmcov_5pct_inc) {
		this.lost_ins_dis_fmcov_5pct_inc = lost_ins_dis_fmcov_5pct_inc;
	}

	public String getHouse_rent_assist_type() {
		return house_rent_assist_type;
	}

	public void setHouse_rent_assist_type(String house_rent_assist_type) {
		this.house_rent_assist_type = house_rent_assist_type;
	}

	public String getRcv_bnft_oth_st_resp() {
		return rcv_bnft_oth_st_resp;
	}

	public void setRcv_bnft_oth_st_resp(String rcv_bnft_oth_st_resp) {
		this.rcv_bnft_oth_st_resp = rcv_bnft_oth_st_resp;
	}

	public String getChld_prot_srvs_resp() {
		return chld_prot_srvs_resp;
	}

	public void setChld_prot_srvs_resp(String chld_prot_srvs_resp) {
		this.chld_prot_srvs_resp = chld_prot_srvs_resp;
	}

	public String getUei_agent_orng_pymt_resp() {
		return uei_agent_orng_pymt_resp;
	}

	public void setUei_agent_orng_pymt_resp(String uei_agent_orng_pymt_resp) {
		this.uei_agent_orng_pymt_resp = uei_agent_orng_pymt_resp;
	}

	public String getUei_worker_study_resp() {
		return uei_worker_study_resp;
	}

	public void setUei_worker_study_resp(String uei_worker_study_resp) {
		this.uei_worker_study_resp = uei_worker_study_resp;
	}

	public String getUei_refugee_cash_resp() {
		return uei_refugee_cash_resp;
	}

	public void setUei_refugee_cash_resp(String uei_refugee_cash_resp) {
		this.uei_refugee_cash_resp = uei_refugee_cash_resp;
	}

	public String getLost_ins_fmcov_5pct_inc() {
		return lost_ins_fmcov_5pct_inc;
	}

	public void setLost_ins_fmcov_5pct_inc(String lost_ins_fmcov_5pct_inc) {
		this.lost_ins_fmcov_5pct_inc = lost_ins_fmcov_5pct_inc;
	}

	public String getUei_anny_pymt_resp() {
		return uei_anny_pymt_resp;
	}

	public void setUei_anny_pymt_resp(String uei_anny_pymt_resp) {
		this.uei_anny_pymt_resp = uei_anny_pymt_resp;
	}

	public String getUei_frm_alot_resp() {
		return uei_frm_alot_resp;
	}

	public void setUei_frm_alot_resp(String uei_frm_alot_resp) {
		this.uei_frm_alot_resp = uei_frm_alot_resp;
	}

	public String getUei_mil_alot_resp() {
		return uei_mil_alot_resp;
	}

	public void setUei_mil_alot_resp(String uei_mil_alot_resp) {
		this.uei_mil_alot_resp = uei_mil_alot_resp;
	}

	public String getBnft_ssi_ended_resp() {
		return bnft_ssi_ended_resp;
	}

	public void setBnft_ssi_ended_resp(String bnft_ssi_ended_resp) {
		this.bnft_ssi_ended_resp = bnft_ssi_ended_resp;
	}

	public String getReal_aset_rental_resp() {
		return real_aset_rental_resp;
	}

	public void setReal_aset_rental_resp(String real_aset_rental_resp) {
		this.real_aset_rental_resp = real_aset_rental_resp;
	}

	public String getUei_dabl_incm_resp() {
		return uei_dabl_incm_resp;
	}

	public void setUei_dabl_incm_resp(String uei_dabl_incm_resp) {
		this.uei_dabl_incm_resp = uei_dabl_incm_resp;
	}

	public String getUei_adoption_assist_resp() {
		return uei_adoption_assist_resp;
	}

	public void setUei_adoption_assist_resp(String uei_adoption_assist_resp) {
		this.uei_adoption_assist_resp = uei_adoption_assist_resp;
	}

	public String getLost_ins_chg_empl_resp() {
		return lost_ins_chg_empl_resp;
	}

	public void setLost_ins_chg_empl_resp(String lost_ins_chg_empl_resp) {
		this.lost_ins_chg_empl_resp = lost_ins_chg_empl_resp;
	}

	public String getTrbl_ser_elg_resp() {
		return trbl_ser_elg_resp;
	}

	public void setTrbl_ser_elg_resp(String trbl_ser_elg_resp) {
		this.trbl_ser_elg_resp = trbl_ser_elg_resp;
	}

	public String getUei_unempl_resp() {
		return uei_unempl_resp;
	}

	public void setUei_unempl_resp(String uei_unempl_resp) {
		this.uei_unempl_resp = uei_unempl_resp;
	}

	public String getOthr_incm_ss_resp() {
		return othr_incm_ss_resp;
	}

	public void setOthr_incm_ss_resp(String othr_incm_ss_resp) {
		this.othr_incm_ss_resp = othr_incm_ss_resp;
	}

	public String getPers_prop_none() {
		return pers_prop_none;
	}

	public void setPers_prop_none(String pers_prop_none) {
		this.pers_prop_none = pers_prop_none;
	}

	public String getHousing_bill_resp() {
		return housing_bill_resp;
	}

	public void setHousing_bill_resp(String housing_bill_resp) {
		this.housing_bill_resp = housing_bill_resp;
	}

	public String getLiquid_asset_checking_acc_resp() {
		return liquid_asset_checking_acc_resp;
	}

	public void setLiquid_asset_checking_acc_resp(String liquid_asset_checking_acc_resp) {
		this.liquid_asset_checking_acc_resp = liquid_asset_checking_acc_resp;
	}

	public String getMedtyp_other() {
		return medtyp_other;
	}

	public void setMedtyp_other(String medtyp_other) {
		this.medtyp_other = medtyp_other;
	}

	public String getMedtyp_attendant_care() {
		return medtyp_attendant_care;
	}

	public void setMedtyp_attendant_care(String medtyp_attendant_care) {
		this.medtyp_attendant_care = medtyp_attendant_care;
	}

	public String getMedtyp_rx_cost() {
		return medtyp_rx_cost;
	}

	public void setMedtyp_rx_cost(String medtyp_rx_cost) {
		this.medtyp_rx_cost = medtyp_rx_cost;
	}

	public String getMedtyp_insur_premium() {
		return medtyp_insur_premium;
	}

	public void setMedtyp_insur_premium(String medtyp_insur_premium) {
		this.medtyp_insur_premium = medtyp_insur_premium;
	}

	public String getMedtyp_doctor() {
		return medtyp_doctor;
	}

	public void setMedtyp_doctor(String medtyp_doctor) {
		this.medtyp_doctor = medtyp_doctor;
	}

	public String getMedtyp_hsa_contrib() {
		return medtyp_hsa_contrib;
	}

	public void setMedtyp_hsa_contrib(String medtyp_hsa_contrib) {
		this.medtyp_hsa_contrib = medtyp_hsa_contrib;
	}

	public String getMedtyp_trans_med() {
		return medtyp_trans_med;
	}

	public void setMedtyp_trans_med(String medtyp_trans_med) {
		this.medtyp_trans_med = medtyp_trans_med;
	}

	public String getAble_to_conceive_resp() {
		return able_to_conceive_resp;
	}

	public void setAble_to_conceive_resp(String able_to_conceive_resp) {
		this.able_to_conceive_resp = able_to_conceive_resp;
	}

	public String getMedtyp_med_equip() {
		return medtyp_med_equip;
	}

	public void setMedtyp_med_equip(String medtyp_med_equip) {
		this.medtyp_med_equip = medtyp_med_equip;
	}

	public String getUei_mon_fro_oth_resp() {
		return uei_mon_fro_oth_resp;
	}

	public void setUei_mon_fro_oth_resp(String uei_mon_fro_oth_resp) {
		this.uei_mon_fro_oth_resp = uei_mon_fro_oth_resp;
	}

	public String getMedtyp_dental() {
		return medtyp_dental;
	}

	public void setMedtyp_dental(String medtyp_dental) {
		this.medtyp_dental = medtyp_dental;
	}

	public String getMedtyp_hosp_bills() {
		return medtyp_hosp_bills;
	}

	public void setMedtyp_hosp_bills(String medtyp_hosp_bills) {
		this.medtyp_hosp_bills = medtyp_hosp_bills;
	}

	public String getUnderweight_birth_resp() {
		return underweight_birth_resp;
	}

	public void setUnderweight_birth_resp(String underweight_birth_resp) {
		this.underweight_birth_resp = underweight_birth_resp;
	}

	public String getTrbl_hlth_serv_resp() {
		return trbl_hlth_serv_resp;
	}

	public void setTrbl_hlth_serv_resp(String trbl_hlth_serv_resp) {
		this.trbl_hlth_serv_resp = trbl_hlth_serv_resp;
	}

	public String getLost_health_insurance_resp() {
		return lost_health_insurance_resp;
	}

	public void setLost_health_insurance_resp(String lost_health_insurance_resp) {
		this.lost_health_insurance_resp = lost_health_insurance_resp;
	}

	public String getNursing_home_care_resp() {
		return nursing_home_care_resp;
	}

	public void setNursing_home_care_resp(String nursing_home_care_resp) {
		this.nursing_home_care_resp = nursing_home_care_resp;
	}

	public String getVictim_dv_resp() {
		return victim_dv_resp;
	}

	public void setVictim_dv_resp(String victim_dv_resp) {
		this.victim_dv_resp = victim_dv_resp;
	}

	public String getIndp_living_prg_resp() {
		return indp_living_prg_resp;
	}

	public void setIndp_living_prg_resp(String indp_living_prg_resp) {
		this.indp_living_prg_resp = indp_living_prg_resp;
	}

	public String getDisaster_repair_resp() {
		return disaster_repair_resp;
	}

	public void setDisaster_repair_resp(String disaster_repair_resp) {
		this.disaster_repair_resp = disaster_repair_resp;
	}

	public String getPrevent_eviction_resp() {
		return prevent_eviction_resp;
	}

	public void setPrevent_eviction_resp(String prevent_eviction_resp) {
		this.prevent_eviction_resp = prevent_eviction_resp;
	}

	public String getOther_housing_resp() {
		return other_housing_resp;
	}

	public void setOther_housing_resp(String other_housing_resp) {
		this.other_housing_resp = other_housing_resp;
	}

	public String getMedicare_resp() {
		return medicare_resp;
	}

	public void setMedicare_resp(String medicare_resp) {
		this.medicare_resp = medicare_resp;
	}

	public String getTax_claim_dependant_resp() {
		return tax_claim_dependant_resp;
	}

	public void setTax_claim_dependant_resp(String tax_claim_dependant_resp) {
		this.tax_claim_dependant_resp = tax_claim_dependant_resp;
	}

	public String getTribal_ind_resp() {
		return tribal_ind_resp;
	}

	public void setTribal_ind_resp(String tribal_ind_resp) {
		this.tribal_ind_resp = tribal_ind_resp;
	}

	public String getBtd_pre_tax_ins() {
		return btd_pre_tax_ins;
	}

	public void setBtd_pre_tax_ins(String btd_pre_tax_ins) {
		this.btd_pre_tax_ins = btd_pre_tax_ins;
	}

	public String getBtd_vis_care_ins() {
		return btd_vis_care_ins;
	}

	public void setBtd_vis_care_ins(String btd_vis_care_ins) {
		this.btd_vis_care_ins = btd_vis_care_ins;
	}

	public String getBtd_dent_ins() {
		return btd_dent_ins;
	}

	public void setBtd_dent_ins(String btd_dent_ins) {
		this.btd_dent_ins = btd_dent_ins;
	}

	public String getIncome_tax_deduction() {
		return income_tax_deduction;
	}

	public void setIncome_tax_deduction(String income_tax_deduction) {
		this.income_tax_deduction = income_tax_deduction;
	}

	public String getBtd_flex_acc() {
		return btd_flex_acc;
	}

	public void setBtd_flex_acc(String btd_flex_acc) {
		this.btd_flex_acc = btd_flex_acc;
	}

	public String getBtd_def_comp() {
		return btd_def_comp;
	}

	public void setBtd_def_comp(String btd_def_comp) {
		this.btd_def_comp = btd_def_comp;
	}

	public String getBtd_med_ins() {
		return btd_med_ins;
	}

	public void setBtd_med_ins(String btd_med_ins) {
		this.btd_med_ins = btd_med_ins;
	}

	public String getBefore_tax_resp() {
		return before_tax_resp;
	}

	public void setBefore_tax_resp(String before_tax_resp) {
		this.before_tax_resp = before_tax_resp;
	}

	public String getTax_dependents_outside_resp() {
		return tax_dependents_outside_resp;
	}

	public void setTax_dependents_outside_resp(String tax_dependents_outside_resp) {
		this.tax_dependents_outside_resp = tax_dependents_outside_resp;
	}

	public String getOth_ind_gambl_pmnts() {
		return oth_ind_gambl_pmnts;
	}

	public void setOth_ind_gambl_pmnts(String oth_ind_gambl_pmnts) {
		this.oth_ind_gambl_pmnts = oth_ind_gambl_pmnts;
	}

	public String getMedicare_part_a() {
		return medicare_part_a;
	}

	public void setMedicare_part_a(String medicare_part_a) {
		this.medicare_part_a = medicare_part_a;
	}

	public String getMedicare_part_b() {
		return medicare_part_b;
	}

	public void setMedicare_part_b(String medicare_part_b) {
		this.medicare_part_b = medicare_part_b;
	}

	public String getMedicare_part_c() {
		return medicare_part_c;
	}

	public void setMedicare_part_c(String medicare_part_c) {
		this.medicare_part_c = medicare_part_c;
	}

	public String getMedicare_part_d() {
		return medicare_part_d;
	}

	public void setMedicare_part_d(String medicare_part_d) {
		this.medicare_part_d = medicare_part_d;
	}

	public String getCcsp_provider_payment() {
		return ccsp_provider_payment;
	}

	public void setCcsp_provider_payment(String ccsp_provider_payment) {
		this.ccsp_provider_payment = ccsp_provider_payment;
	}

	public String getAnimals_to_assist_disabled() {
		return animals_to_assist_disabled;
	}

	public void setAnimals_to_assist_disabled(String animals_to_assist_disabled) {
		this.animals_to_assist_disabled = animals_to_assist_disabled;
	}

	public String getFuneral_death_expense() {
		return funeral_death_expense;
	}

	public void setFuneral_death_expense(String funeral_death_expense) {
		this.funeral_death_expense = funeral_death_expense;
	}

	public String getBlind_work_expense() {
		return blind_work_expense;
	}

	public void setBlind_work_expense(String blind_work_expense) {
		this.blind_work_expense = blind_work_expense;
	}

	public String getImpairment_work_expense() {
		return impairment_work_expense;
	}

	public void setImpairment_work_expense(String impairment_work_expense) {
		this.impairment_work_expense = impairment_work_expense;
	}

	public String getDividend() {
		return dividend;
	}

	public void setDividend(String dividend) {
		this.dividend = dividend;
	}

	public String getHlth_reimbur_acct() {
		return hlth_reimbur_acct;
	}

	public void setHlth_reimbur_acct(String hlth_reimbur_acct) {
		this.hlth_reimbur_acct = hlth_reimbur_acct;
	}

	public String getIndv_dvlp_acct() {
		return indv_dvlp_acct;
	}

	public void setIndv_dvlp_acct(String indv_dvlp_acct) {
		this.indv_dvlp_acct = indv_dvlp_acct;
	}

	public String getUniform_gifts() {
		return uniform_gifts;
	}

	public void setUniform_gifts(String uniform_gifts) {
		this.uniform_gifts = uniform_gifts;
	}

	public String getIncome_from_resource() {
		return income_from_resource;
	}

	public void setIncome_from_resource(String income_from_resource) {
		this.income_from_resource = income_from_resource;
	}

	public String getIndian_gambling_payments() {
		return indian_gambling_payments;
	}

	public void setIndian_gambling_payments(String indian_gambling_payments) {
		this.indian_gambling_payments = indian_gambling_payments;
	}

	public String getInheritance() {
		return inheritance;
	}

	public void setInheritance(String inheritance) {
		this.inheritance = inheritance;
	}

	public String getInsuance_benefits() {
		return insuance_benefits;
	}

	public void setInsuance_benefits(String insuance_benefits) {
		this.insuance_benefits = insuance_benefits;
	}

	public String getLoan_received() {
		return loan_received;
	}

	public void setLoan_received(String loan_received) {
		this.loan_received = loan_received;
	}

	public String getLoan_repayment_income() {
		return loan_repayment_income;
	}

	public void setLoan_repayment_income(String loan_repayment_income) {
		this.loan_repayment_income = loan_repayment_income;
	}

	public String getManaged_income() {
		return managed_income;
	}

	public void setManaged_income(String managed_income) {
		this.managed_income = managed_income;
	}

	public String getMatch_grant() {
		return match_grant;
	}

	public void setMatch_grant(String match_grant) {
		this.match_grant = match_grant;
	}

	public String getMontgomery_gi_bill() {
		return montgomery_gi_bill;
	}

	public void setMontgomery_gi_bill(String montgomery_gi_bill) {
		this.montgomery_gi_bill = montgomery_gi_bill;
	}

	public String getOut_of_state_public() {
		return out_of_state_public;
	}

	public void setOut_of_state_public(String out_of_state_public) {
		this.out_of_state_public = out_of_state_public;
	}

	public String getRefunds_from_dch() {
		return refunds_from_dch;
	}

	public void setRefunds_from_dch(String refunds_from_dch) {
		this.refunds_from_dch = refunds_from_dch;
	}

	public String getRestitutions_settlements() {
		return restitutions_settlements;
	}

	public void setRestitutions_settlements(String restitutions_settlements) {
		this.restitutions_settlements = restitutions_settlements;
	}

	public String getSenior_companion() {
		return senior_companion;
	}

	public void setSenior_companion(String senior_companion) {
		this.senior_companion = senior_companion;
	}

	public String getSeverance_pay() {
		return severance_pay;
	}

	public void setSeverance_pay(String severance_pay) {
		this.severance_pay = severance_pay;
	}

	public String getTrade_readjustment() {
		return trade_readjustment;
	}

	public void setTrade_readjustment(String trade_readjustment) {
		this.trade_readjustment = trade_readjustment;
	}

	public String getUniform_relocation() {
		return uniform_relocation;
	}

	public void setUniform_relocation(String uniform_relocation) {
		this.uniform_relocation = uniform_relocation;
	}

	public String getUnion_funds() {
		return union_funds;
	}

	public void setUnion_funds(String union_funds) {
		this.union_funds = union_funds;
	}

	public String getVendor_excluded() {
		return vendor_excluded;
	}

	public void setVendor_excluded(String vendor_excluded) {
		this.vendor_excluded = vendor_excluded;
	}

	public String getVictim_restitution() {
		return victim_restitution;
	}

	public void setVictim_restitution(String victim_restitution) {
		this.victim_restitution = victim_restitution;
	}

	public String getVolunteer_payment() {
		return volunteer_payment;
	}

	public void setVolunteer_payment(String volunteer_payment) {
		this.volunteer_payment = volunteer_payment;
	}

	public String getVolunteer_payment_titlei() {
		return volunteer_payment_titlei;
	}

	public void setVolunteer_payment_titlei(String volunteer_payment_titlei) {
		this.volunteer_payment_titlei = volunteer_payment_titlei;
	}

	public String getWia_training_and_allowance() {
		return wia_training_and_allowance;
	}

	public void setWia_training_and_allowance(String wia_training_and_allowance) {
		this.wia_training_and_allowance = wia_training_and_allowance;
	}

	public String getTanf_max_au_allotment() {
		return tanf_max_au_allotment;
	}

	public void setTanf_max_au_allotment(String tanf_max_au_allotment) {
		this.tanf_max_au_allotment = tanf_max_au_allotment;
	}

	public String getTanf_max_grg_allotment() {
		return tanf_max_grg_allotment;
	}

	public void setTanf_max_grg_allotment(String tanf_max_grg_allotment) {
		this.tanf_max_grg_allotment = tanf_max_grg_allotment;
	}

	public String getCharitable_donation() {
		return charitable_donation;
	}

	public void setCharitable_donation(String charitable_donation) {
		this.charitable_donation = charitable_donation;
	}

	public String getChild_nutrition_payments() {
		return child_nutrition_payments;
	}

	public void setChild_nutrition_payments(String child_nutrition_payments) {
		this.child_nutrition_payments = child_nutrition_payments;
	}

	public String getBlack_lung_benefits() {
		return black_lung_benefits;
	}

	public void setBlack_lung_benefits(String black_lung_benefits) {
		this.black_lung_benefits = black_lung_benefits;
	}

	public String getChild_support_court() {
		return child_support_court;
	}

	public void setChild_support_court(String child_support_court) {
		this.child_support_court = child_support_court;
	}

	public String getChild_support_gap_payment() {
		return child_support_gap_payment;
	}

	public void setChild_support_gap_payment(String child_support_gap_payment) {
		this.child_support_gap_payment = child_support_gap_payment;
	}

	public String getCivil_service() {
		return civil_service;
	}

	public void setCivil_service(String civil_service) {
		this.civil_service = civil_service;
	}

	public String getDeferred_compensation_plans() {
		return deferred_compensation_plans;
	}

	public void setDeferred_compensation_plans(String deferred_compensation_plans) {
		this.deferred_compensation_plans = deferred_compensation_plans;
	}

	public String getDisability_insurance() {
		return disability_insurance;
	}

	public void setDisability_insurance(String disability_insurance) {
		this.disability_insurance = disability_insurance;
	}

	public String getExcluded_unearned_income() {
		return excluded_unearned_income;
	}

	public void setExcluded_unearned_income(String excluded_unearned_income) {
		this.excluded_unearned_income = excluded_unearned_income;
	}

	public String getFema_payment_disaster() {
		return fema_payment_disaster;
	}

	public void setFema_payment_disaster(String fema_payment_disaster) {
		this.fema_payment_disaster = fema_payment_disaster;
	}

	public String getFema_payment_non_disaster() {
		return fema_payment_non_disaster;
	}

	public void setFema_payment_non_disaster(String fema_payment_non_disaster) {
		this.fema_payment_non_disaster = fema_payment_non_disaster;
	}

	public String getHealth_savings_account() {
		return health_savings_account;
	}

	public void setHealth_savings_account(String health_savings_account) {
		this.health_savings_account = health_savings_account;
	}

	public String getFoster_grandparent_program() {
		return foster_grandparent_program;
	}

	public void setFoster_grandparent_program(String foster_grandparent_program) {
		this.foster_grandparent_program = foster_grandparent_program;
	}

	public String getDisaster_unemployment() {
		return disaster_unemployment;
	}

	public void setDisaster_unemployment(String disaster_unemployment) {
		this.disaster_unemployment = disaster_unemployment;
	}

	public String getDividends() {
		return dividends;
	}

	public void setDividends(String dividends) {
		this.dividends = dividends;
	}

	public String getCharitable_donation_federal() {
		return charitable_donation_federal;
	}

	public void setCharitable_donation_federal(String charitable_donation_federal) {
		this.charitable_donation_federal = charitable_donation_federal;
	}

	public String getTrust_fund() {
		return trust_fund;
	}

	public void setTrust_fund(String trust_fund) {
		this.trust_fund = trust_fund;
	}

	public String getPatient_fund() {
		return patient_fund;
	}

	public void setPatient_fund(String patient_fund) {
		this.patient_fund = patient_fund;
	}

	public String getDisaster_assistance() {
		return disaster_assistance;
	}

	public void setDisaster_assistance(String disaster_assistance) {
		this.disaster_assistance = disaster_assistance;
	}

	public String getNon_business_equipment() {
		return non_business_equipment;
	}

	public void setNon_business_equipment(String non_business_equipment) {
		this.non_business_equipment = non_business_equipment;
	}

	public String getHousehold_goods() {
		return household_goods;
	}

	public void setHousehold_goods(String household_goods) {
		this.household_goods = household_goods;
	}

	public String getOther_non_countable() {
		return other_non_countable;
	}

	public void setOther_non_countable(String other_non_countable) {
		this.other_non_countable = other_non_countable;
	}

	public String getLegal_child_support_resp() {
		return legal_child_support_resp;
	}

	public void setLegal_child_support_resp(String legal_child_support_resp) {
		this.legal_child_support_resp = legal_child_support_resp;
	}

	public String getLiquid_aset_bank_acc_resp() {
		return liquid_aset_bank_acc_resp;
	}

	public void setLiquid_aset_bank_acc_resp(String liquid_aset_bank_acc_resp) {
		this.liquid_aset_bank_acc_resp = liquid_aset_bank_acc_resp;
	}

	public String getLiquid_asset_deed_trust_resp() {
		return liquid_asset_deed_trust_resp;
	}

	public void setLiquid_asset_deed_trust_resp(String liquid_asset_deed_trust_resp) {
		this.liquid_asset_deed_trust_resp = liquid_asset_deed_trust_resp;
	}

	public String getLiquid_asset_pension_plan_resp() {
		return liquid_asset_pension_plan_resp;
	}

	public void setLiquid_asset_pension_plan_resp(String liquid_asset_pension_plan_resp) {
		this.liquid_asset_pension_plan_resp = liquid_asset_pension_plan_resp;
	}

	public String getLiquid_asset_promissory_resp() {
		return liquid_asset_promissory_resp;
	}

	public void setLiquid_asset_promissory_resp(String liquid_asset_promissory_resp) {
		this.liquid_asset_promissory_resp = liquid_asset_promissory_resp;
	}

	public String getLiquid_asset_retirement_resp() {
		return liquid_asset_retirement_resp;
	}

	public void setLiquid_asset_retirement_resp(String liquid_asset_retirement_resp) {
		this.liquid_asset_retirement_resp = liquid_asset_retirement_resp;
	}

	public String getLoan_resp() {
		return loan_resp;
	}

	public void setLoan_resp(String loan_resp) {
		this.loan_resp = loan_resp;
	}

	public String getMedical_service_resp() {
		return medical_service_resp;
	}

	public void setMedical_service_resp(String medical_service_resp) {
		this.medical_service_resp = medical_service_resp;
	}

	public String getMedicare_part_a_b_d_resp() {
		return medicare_part_a_b_d_resp;
	}

	public void setMedicare_part_a_b_d_resp(String medicare_part_a_b_d_resp) {
		this.medicare_part_a_b_d_resp = medicare_part_a_b_d_resp;
	}

	public String getPast_job_resp() {
		return past_job_resp;
	}

	public void setPast_job_resp(String past_job_resp) {
		this.past_job_resp = past_job_resp;
	}

	public String getPending_social_assistance_resp() {
		return pending_social_assistance_resp;
	}

	public void setPending_social_assistance_resp(String pending_social_assistance_resp) {
		this.pending_social_assistance_resp = pending_social_assistance_resp;
	}

	public String getPrize_winning_resp() {
		return prize_winning_resp;
	}

	public void setPrize_winning_resp(String prize_winning_resp) {
		this.prize_winning_resp = prize_winning_resp;
	}

	public String getPublic_assistance_resp() {
		return public_assistance_resp;
	}

	public void setPublic_assistance_resp(String public_assistance_resp) {
		this.public_assistance_resp = public_assistance_resp;
	}

	public String getProp_tax_mobile_home_resp() {
		return prop_tax_mobile_home_resp;
	}

	public void setProp_tax_mobile_home_resp(String prop_tax_mobile_home_resp) {
		this.prop_tax_mobile_home_resp = prop_tax_mobile_home_resp;
	}

	public String getReal_asset_life_estate_resp() {
		return real_asset_life_estate_resp;
	}

	public void setReal_asset_life_estate_resp(String real_asset_life_estate_resp) {
		this.real_asset_life_estate_resp = real_asset_life_estate_resp;
	}

	public String getReal_estate_tax_resp() {
		return real_estate_tax_resp;
	}

	public void setReal_estate_tax_resp(String real_estate_tax_resp) {
		this.real_estate_tax_resp = real_estate_tax_resp;
	}

	public String getRent_exp_resp() {
		return rent_exp_resp;
	}

	public void setRent_exp_resp(String rent_exp_resp) {
		this.rent_exp_resp = rent_exp_resp;
	}

	public String getStudent_financial_aid_resp() {
		return student_financial_aid_resp;
	}

	public void setStudent_financial_aid_resp(String student_financial_aid_resp) {
		this.student_financial_aid_resp = student_financial_aid_resp;
	}

	public String getTraining_allowance_resp() {
		return training_allowance_resp;
	}

	public void setTraining_allowance_resp(String training_allowance_resp) {
		this.training_allowance_resp = training_allowance_resp;
	}

	public String getWork_related_expense_resp() {
		return work_related_expense_resp;
	}

	public void setWork_related_expense_resp(String work_related_expense_resp) {
		this.work_related_expense_resp = work_related_expense_resp;
	}

	public String getUtility_bills_kerosene_resp() {
		return utility_bills_kerosene_resp;
	}

	public void setUtility_bills_kerosene_resp(String utility_bills_kerosene_resp) {
		this.utility_bills_kerosene_resp = utility_bills_kerosene_resp;
	}

	public String getLqd_asset_irs_collge_plan_resp() {
		return lqd_asset_irs_collge_plan_resp;
	}

	public void setLqd_asset_irs_collge_plan_resp(String lqd_asset_irs_collge_plan_resp) {
		this.lqd_asset_irs_collge_plan_resp = lqd_asset_irs_collge_plan_resp;
	}

	public String getLqd_asset_irs_retirement_resp() {
		return lqd_asset_irs_retirement_resp;
	}

	public void setLqd_asset_irs_retirement_resp(String lqd_asset_irs_retirement_resp) {
		this.lqd_asset_irs_retirement_resp = lqd_asset_irs_retirement_resp;
	}

	public String getVehicle_asset_animal_drwn_resp() {
		return vehicle_asset_animal_drwn_resp;
	}

	public void setVehicle_asset_animal_drwn_resp(String vehicle_asset_animal_drwn_resp) {
		this.vehicle_asset_animal_drwn_resp = vehicle_asset_animal_drwn_resp;
	}

	public String getVehicle_asset_tractor_resp() {
		return vehicle_asset_tractor_resp;
	}

	public void setVehicle_asset_tractor_resp(String vehicle_asset_tractor_resp) {
		this.vehicle_asset_tractor_resp = vehicle_asset_tractor_resp;
	}

	public String getVehicle_asset_golf_cart_resp() {
		return vehicle_asset_golf_cart_resp;
	}

	public void setVehicle_asset_golf_cart_resp(String vehicle_asset_golf_cart_resp) {
		this.vehicle_asset_golf_cart_resp = vehicle_asset_golf_cart_resp;
	}

	public String getVehicle_asset_nmot_camper_resp() {
		return vehicle_asset_nmot_camper_resp;
	}

	public void setVehicle_asset_nmot_camper_resp(String vehicle_asset_nmot_camper_resp) {
		this.vehicle_asset_nmot_camper_resp = vehicle_asset_nmot_camper_resp;
	}

	public String getLifeinsurance_asset_other_resp() {
		return lifeinsurance_asset_other_resp;
	}

	public void setLifeinsurance_asset_other_resp(String lifeinsurance_asset_other_resp) {
		this.lifeinsurance_asset_other_resp = lifeinsurance_asset_other_resp;
	}

	public String getShelter_expense_resp() {
		return shelter_expense_resp;
	}

	public void setShelter_expense_resp(String shelter_expense_resp) {
		this.shelter_expense_resp = shelter_expense_resp;
	}

	public String getService_provider_co_resp() {
		return service_provider_co_resp;
	}

	public void setService_provider_co_resp(String service_provider_co_resp) {
		this.service_provider_co_resp = service_provider_co_resp;
	}

	public String getService_provider_fu_resp() {
		return service_provider_fu_resp;
	}

	public void setService_provider_fu_resp(String service_provider_fu_resp) {
		this.service_provider_fu_resp = service_provider_fu_resp;
	}

	public String getService_provider_cr_resp() {
		return service_provider_cr_resp;
	}

	public void setService_provider_cr_resp(String service_provider_cr_resp) {
		this.service_provider_cr_resp = service_provider_cr_resp;
	}

	public String getAuth_rep_resp() {
		return auth_rep_resp;
	}

	public void setAuth_rep_resp(String auth_rep_resp) {
		this.auth_rep_resp = auth_rep_resp;
	}

	public String getBenefits_on_strike_resp() {
		return benefits_on_strike_resp;
	}

	public void setBenefits_on_strike_resp(String benefits_on_strike_resp) {
		this.benefits_on_strike_resp = benefits_on_strike_resp;
	}

	public String getOthr_social_security_bnft_resp() {
		return othr_social_security_bnft_resp;
	}

	public void setOthr_social_security_bnft_resp(String othr_social_security_bnft_resp) {
		this.othr_social_security_bnft_resp = othr_social_security_bnft_resp;
	}

	public String getUei_none_resp() {
		return uei_none_resp;
	}

	public void setUei_none_resp(String uei_none_resp) {
		this.uei_none_resp = uei_none_resp;
	}

	public String getUei_rental_incm_resp() {
		return uei_rental_incm_resp;
	}

	public void setUei_rental_incm_resp(String uei_rental_incm_resp) {
		this.uei_rental_incm_resp = uei_rental_incm_resp;
	}

	public String getLiquid_asset_annuity_resp() {
		return liquid_asset_annuity_resp;
	}

	public void setLiquid_asset_annuity_resp(String liquid_asset_annuity_resp) {
		this.liquid_asset_annuity_resp = liquid_asset_annuity_resp;
	}

	public String getElg_rcv_energy_assist_resp() {
		return elg_rcv_energy_assist_resp;
	}

	public void setElg_rcv_energy_assist_resp(String elg_rcv_energy_assist_resp) {
		this.elg_rcv_energy_assist_resp = elg_rcv_energy_assist_resp;
	}

	public String getLiquid_asset_none_resp() {
		return liquid_asset_none_resp;
	}

	public void setLiquid_asset_none_resp(String liquid_asset_none_resp) {
		this.liquid_asset_none_resp = liquid_asset_none_resp;
	}

	public String getOthr_incm_dcss_sup_resp() {
		return othr_incm_dcss_sup_resp;
	}

	public void setOthr_incm_dcss_sup_resp(String othr_incm_dcss_sup_resp) {
		this.othr_incm_dcss_sup_resp = othr_incm_dcss_sup_resp;
	}

	public String getLi_aset_none_resp() {
		return li_aset_none_resp;
	}

	public void setLi_aset_none_resp(String li_aset_none_resp) {
		this.li_aset_none_resp = li_aset_none_resp;
	}

	public String getMig_farm_wrkr_job_end_resp() {
		return mig_farm_wrkr_job_end_resp;
	}

	public void setMig_farm_wrkr_job_end_resp(String mig_farm_wrkr_job_end_resp) {
		this.mig_farm_wrkr_job_end_resp = mig_farm_wrkr_job_end_resp;
	}

	public String getCurr_rcv_tanf_resp() {
		return curr_rcv_tanf_resp;
	}

	public void setCurr_rcv_tanf_resp(String curr_rcv_tanf_resp) {
		this.curr_rcv_tanf_resp = curr_rcv_tanf_resp;
	}

	public String getReal_aset_vac_resp() {
		return real_aset_vac_resp;
	}

	public void setReal_aset_vac_resp(String real_aset_vac_resp) {
		this.real_aset_vac_resp = real_aset_vac_resp;
	}

	public String getOth_bill_unpaid_med_resp() {
		return oth_bill_unpaid_med_resp;
	}

	public void setOth_bill_unpaid_med_resp(String oth_bill_unpaid_med_resp) {
		this.oth_bill_unpaid_med_resp = oth_bill_unpaid_med_resp;
	}

	public String getUei_gen_assist_resp() {
		return uei_gen_assist_resp;
	}

	public void setUei_gen_assist_resp(String uei_gen_assist_resp) {
		this.uei_gen_assist_resp = uei_gen_assist_resp;
	}

	public String getVeh_aset_none_resp() {
		return veh_aset_none_resp;
	}

	public void setVeh_aset_none_resp(String veh_aset_none_resp) {
		this.veh_aset_none_resp = veh_aset_none_resp;
	}

	public String getHousing_bill_rent_resp() {
		return housing_bill_rent_resp;
	}

	public void setHousing_bill_rent_resp(String housing_bill_rent_resp) {
		this.housing_bill_rent_resp = housing_bill_rent_resp;
	}

	public String getUei_dr_relief_resp() {
		return uei_dr_relief_resp;
	}

	public void setUei_dr_relief_resp(String uei_dr_relief_resp) {
		this.uei_dr_relief_resp = uei_dr_relief_resp;
	}

	public String getOth_bill_chld_sup_oblig_resp() {
		return oth_bill_chld_sup_oblig_resp;
	}

	public void setOth_bill_chld_sup_oblig_resp(String oth_bill_chld_sup_oblig_resp) {
		this.oth_bill_chld_sup_oblig_resp = oth_bill_chld_sup_oblig_resp;
	}

	public String getVeh_aset_unlic_resp() {
		return veh_aset_unlic_resp;
	}

	public void setVeh_aset_unlic_resp(String veh_aset_unlic_resp) {
		this.veh_aset_unlic_resp = veh_aset_unlic_resp;
	}

	public String getCur_rcv_energy_assist_resp() {
		return cur_rcv_energy_assist_resp;
	}

	public void setCur_rcv_energy_assist_resp(String cur_rcv_energy_assist_resp) {
		this.cur_rcv_energy_assist_resp = cur_rcv_energy_assist_resp;
	}

	public String getAvoid_pros_resp() {
		return avoid_pros_resp;
	}

	public void setAvoid_pros_resp(String avoid_pros_resp) {
		this.avoid_pros_resp = avoid_pros_resp;
	}

	public String getUei_tanf_pymt_resp() {
		return uei_tanf_pymt_resp;
	}

	public void setUei_tanf_pymt_resp(String uei_tanf_pymt_resp) {
		this.uei_tanf_pymt_resp = uei_tanf_pymt_resp;
	}

	public String getPers_prop_oth_val() {
		return pers_prop_oth_val;
	}

	public void setPers_prop_oth_val(String pers_prop_oth_val) {
		this.pers_prop_oth_val = pers_prop_oth_val;
	}

	public String getReal_aset_none_resp() {
		return real_aset_none_resp;
	}

	public void setReal_aset_none_resp(String real_aset_none_resp) {
		this.real_aset_none_resp = real_aset_none_resp;
	}

	public String getUei_ira_dist_resp() {
		return uei_ira_dist_resp;
	}

	public void setUei_ira_dist_resp(String uei_ira_dist_resp) {
		this.uei_ira_dist_resp = uei_ira_dist_resp;
	}

	public String getLiquid_asset_irs_col_plan_resp() {
		return liquid_asset_irs_col_plan_resp;
	}

	public void setLiquid_asset_irs_col_plan_resp(String liquid_asset_irs_col_plan_resp) {
		this.liquid_asset_irs_col_plan_resp = liquid_asset_irs_col_plan_resp;
	}

	public String getLiquid_asset_irs_retirmnt_resp() {
		return liquid_asset_irs_retirmnt_resp;
	}

	public void setLiquid_asset_irs_retirmnt_resp(String liquid_asset_irs_retirmnt_resp) {
		this.liquid_asset_irs_retirmnt_resp = liquid_asset_irs_retirmnt_resp;
	}

	public String getReal_aset_lest_resp() {
		return real_aset_lest_resp;
	}

	public void setReal_aset_lest_resp(String real_aset_lest_resp) {
		this.real_aset_lest_resp = real_aset_lest_resp;
	}

	public String getUei_edu_assist_resp() {
		return uei_edu_assist_resp;
	}

	public void setUei_edu_assist_resp(String uei_edu_assist_resp) {
		this.uei_edu_assist_resp = uei_edu_assist_resp;
	}

	public String getHospital_stay_resp() {
		return hospital_stay_resp;
	}

	public void setHospital_stay_resp(String hospital_stay_resp) {
		this.hospital_stay_resp = hospital_stay_resp;
	}

	public String getUei_worker_comp_resp() {
		return uei_worker_comp_resp;
	}

	public void setUei_worker_comp_resp(String uei_worker_comp_resp) {
		this.uei_worker_comp_resp = uei_worker_comp_resp;
	}

	public String getUei_death_bnft_resp() {
		return uei_death_bnft_resp;
	}

	public void setUei_death_bnft_resp(String uei_death_bnft_resp) {
		this.uei_death_bnft_resp = uei_death_bnft_resp;
	}

	public String getUei_energy_assist_resp() {
		return uei_energy_assist_resp;
	}

	public void setUei_energy_assist_resp(String uei_energy_assist_resp) {
		this.uei_energy_assist_resp = uei_energy_assist_resp;
	}

	public String getOth_bill_b_tax_ded_resp() {
		return oth_bill_b_tax_ded_resp;
	}

	public void setOth_bill_b_tax_ded_resp(String oth_bill_b_tax_ded_resp) {
		this.oth_bill_b_tax_ded_resp = oth_bill_b_tax_ded_resp;
	}

	public String getHouse_assist_rcv_ind() {
		return house_assist_rcv_ind;
	}

	public void setHouse_assist_rcv_ind(String house_assist_rcv_ind) {
		this.house_assist_rcv_ind = house_assist_rcv_ind;
	}

	public String getOth_bill_incm_tax_ded_resp() {
		return oth_bill_incm_tax_ded_resp;
	}

	public void setOth_bill_incm_tax_ded_resp(String oth_bill_incm_tax_ded_resp) {
		this.oth_bill_incm_tax_ded_resp = oth_bill_incm_tax_ded_resp;
	}

	public String getHouse_hc_src_type_cd() {
		return house_hc_src_type_cd;
	}

	public void setHouse_hc_src_type_cd(String house_hc_src_type_cd) {
		this.house_hc_src_type_cd = house_hc_src_type_cd;
	}

	public String getMig_farm_wrkr_job_rate_resp() {
		return mig_farm_wrkr_job_rate_resp;
	}

	public void setMig_farm_wrkr_job_rate_resp(String mig_farm_wrkr_job_rate_resp) {
		this.mig_farm_wrkr_job_rate_resp = mig_farm_wrkr_job_rate_resp;
	}

	public String getOthr_incm_vets_bnft_resp() {
		return othr_incm_vets_bnft_resp;
	}

	public void setOthr_incm_vets_bnft_resp(String othr_incm_vets_bnft_resp) {
		this.othr_incm_vets_bnft_resp = othr_incm_vets_bnft_resp;
	}

	public String getFs_disqualify_resp() {
		return fs_disqualify_resp;
	}

	public void setFs_disqualify_resp(String fs_disqualify_resp) {
		this.fs_disqualify_resp = fs_disqualify_resp;
	}

	public String getPers_prop_cemetary_lot() {
		return pers_prop_cemetary_lot;
	}

	public void setPers_prop_cemetary_lot(String pers_prop_cemetary_lot) {
		this.pers_prop_cemetary_lot = pers_prop_cemetary_lot;
	}

	public String getLost_ins_spl_care_need_resp() {
		return lost_ins_spl_care_need_resp;
	}

	public void setLost_ins_spl_care_need_resp(String lost_ins_spl_care_need_resp) {
		this.lost_ins_spl_care_need_resp = lost_ins_spl_care_need_resp;
	}

	public String getMig_farm_wrkr_resp() {
		return mig_farm_wrkr_resp;
	}

	public void setMig_farm_wrkr_resp(String mig_farm_wrkr_resp) {
		this.mig_farm_wrkr_resp = mig_farm_wrkr_resp;
	}

	public String getOthr_incm_ssi_resp() {
		return othr_incm_ssi_resp;
	}

	public void setOthr_incm_ssi_resp(String othr_incm_ssi_resp) {
		this.othr_incm_ssi_resp = othr_incm_ssi_resp;
	}

	public String getHousing_bill_none_resp() {
		return housing_bill_none_resp;
	}

	public void setHousing_bill_none_resp(String housing_bill_none_resp) {
		this.housing_bill_none_resp = housing_bill_none_resp;
	}

	public String getUei_adoption_pymt_resp() {
		return uei_adoption_pymt_resp;
	}

	public void setUei_adoption_pymt_resp(String uei_adoption_pymt_resp) {
		this.uei_adoption_pymt_resp = uei_adoption_pymt_resp;
	}

	public String getLost_ins_new_born_resp() {
		return lost_ins_new_born_resp;
	}

	public void setLost_ins_new_born_resp(String lost_ins_new_born_resp) {
		this.lost_ins_new_born_resp = lost_ins_new_born_resp;
	}

	public String getLi_aset_oth_resp() {
		return li_aset_oth_resp;
	}

	public void setLi_aset_oth_resp(String li_aset_oth_resp) {
		this.li_aset_oth_resp = li_aset_oth_resp;
	}

	public String getCnvct_of_false_info_resp() {
		return cnvct_of_false_info_resp;
	}

	public void setCnvct_of_false_info_resp(String cnvct_of_false_info_resp) {
		this.cnvct_of_false_info_resp = cnvct_of_false_info_resp;
	}

	public String getGrp_care_grc_resp() {
		return grp_care_grc_resp;
	}

	public void setGrp_care_grc_resp(String grp_care_grc_resp) {
		this.grp_care_grc_resp = grp_care_grc_resp;
	}

	public String getUei_capital_gains_resp() {
		return uei_capital_gains_resp;
	}

	public void setUei_capital_gains_resp(String uei_capital_gains_resp) {
		this.uei_capital_gains_resp = uei_capital_gains_resp;
	}

	public String getHouse_liheap_rcv_ind() {
		return house_liheap_rcv_ind;
	}

	public void setHouse_liheap_rcv_ind(String house_liheap_rcv_ind) {
		this.house_liheap_rcv_ind = house_liheap_rcv_ind;
	}

	public String getOthr_incm_contrib_resp() {
		return othr_incm_contrib_resp;
	}

	public void setOthr_incm_contrib_resp(String othr_incm_contrib_resp) {
		this.othr_incm_contrib_resp = othr_incm_contrib_resp;
	}

	public String getKatie_beckett_medicaid_resp() {
		return katie_beckett_medicaid_resp;
	}

	public void setKatie_beckett_medicaid_resp(String katie_beckett_medicaid_resp) {
		this.katie_beckett_medicaid_resp = katie_beckett_medicaid_resp;
	}

	public String getLost_ins_empl_stop_resp() {
		return lost_ins_empl_stop_resp;
	}

	public void setLost_ins_empl_stop_resp(String lost_ins_empl_stop_resp) {
		this.lost_ins_empl_stop_resp = lost_ins_empl_stop_resp;
	}

	public String getUei_pymt_bo_resp() {
		return uei_pymt_bo_resp;
	}

	public void setUei_pymt_bo_resp(String uei_pymt_bo_resp) {
		this.uei_pymt_bo_resp = uei_pymt_bo_resp;
	}

	public String getRcv_hospice_care_resp() {
		return rcv_hospice_care_resp;
	}

	public void setRcv_hospice_care_resp(String rcv_hospice_care_resp) {
		this.rcv_hospice_care_resp = rcv_hospice_care_resp;
	}

	public String getLost_ins_divorce_parent_resp() {
		return lost_ins_divorce_parent_resp;
	}

	public void setLost_ins_divorce_parent_resp(String lost_ins_divorce_parent_resp) {
		this.lost_ins_divorce_parent_resp = lost_ins_divorce_parent_resp;
	}

	public String getUei_oth_resp() {
		return uei_oth_resp;
	}

	public void setUei_oth_resp(String uei_oth_resp) {
		this.uei_oth_resp = uei_oth_resp;
	}

	public String getUei_rel_care_resp() {
		return uei_rel_care_resp;
	}

	public void setUei_rel_care_resp(String uei_rel_care_resp) {
		this.uei_rel_care_resp = uei_rel_care_resp;
	}

	public String getOth_bill_med_resp() {
		return oth_bill_med_resp;
	}

	public void setOth_bill_med_resp(String oth_bill_med_resp) {
		this.oth_bill_med_resp = oth_bill_med_resp;
	}

	public String getUei_foster_care_pymt_resp() {
		return uei_foster_care_pymt_resp;
	}

	public void setUei_foster_care_pymt_resp(String uei_foster_care_pymt_resp) {
		this.uei_foster_care_pymt_resp = uei_foster_care_pymt_resp;
	}

	public String getPub_hsa_rcv_pay_own_bill_ind() {
		return pub_hsa_rcv_pay_own_bill_ind;
	}

	public void setPub_hsa_rcv_pay_own_bill_ind(String pub_hsa_rcv_pay_own_bill_ind) {
		this.pub_hsa_rcv_pay_own_bill_ind = pub_hsa_rcv_pay_own_bill_ind;
	}

	public String getUei_lump_sum_resp() {
		return uei_lump_sum_resp;
	}

	public void setUei_lump_sum_resp(String uei_lump_sum_resp) {
		this.uei_lump_sum_resp = uei_lump_sum_resp;
	}

	public String getUtility_bill_resp() {
		return utility_bill_resp;
	}

	public void setUtility_bill_resp(String utility_bill_resp) {
		this.utility_bill_resp = utility_bill_resp;
	}

	public String getOth_bill_chld_adult_care_resp() {
		return oth_bill_chld_adult_care_resp;
	}

	public void setOth_bill_chld_adult_care_resp(String oth_bill_chld_adult_care_resp) {
		this.oth_bill_chld_adult_care_resp = oth_bill_chld_adult_care_resp;
	}

	public String getSu_cst_swr_resp() {
		return su_cst_swr_resp;
	}

	public void setSu_cst_swr_resp(String su_cst_swr_resp) {
		this.su_cst_swr_resp = su_cst_swr_resp;
	}

	public String getSu_cst_tax_resp() {
		return su_cst_tax_resp;
	}

	public void setSu_cst_tax_resp(String su_cst_tax_resp) {
		this.su_cst_tax_resp = su_cst_tax_resp;
	}

	public String getSu_cst_trsh_resp() {
		return su_cst_trsh_resp;
	}

	public void setSu_cst_trsh_resp(String su_cst_trsh_resp) {
		this.su_cst_trsh_resp = su_cst_trsh_resp;
	}

	public String getSu_cst_wood_resp() {
		return su_cst_wood_resp;
	}

	public void setSu_cst_wood_resp(String su_cst_wood_resp) {
		this.su_cst_wood_resp = su_cst_wood_resp;
	}

	public String getSu_cst_wtr_resp() {
		return su_cst_wtr_resp;
	}

	public void setSu_cst_wtr_resp(String su_cst_wtr_resp) {
		this.su_cst_wtr_resp = su_cst_wtr_resp;
	}

	public String getSu_cst_wwt_resp() {
		return su_cst_wwt_resp;
	}

	public void setSu_cst_wwt_resp(String su_cst_wwt_resp) {
		this.su_cst_wwt_resp = su_cst_wwt_resp;
	}

	public String getTrb_tanf_resp() {
		return trb_tanf_resp;
	}

	public void setTrb_tanf_resp(String trb_tanf_resp) {
		this.trb_tanf_resp = trb_tanf_resp;
	}

	public String getTurn_down_job_resp() {
		return turn_down_job_resp;
	}

	public void setTurn_down_job_resp(String turn_down_job_resp) {
		this.turn_down_job_resp = turn_down_job_resp;
	}

	public String getUtil_exp_resp() {
		return util_exp_resp;
	}

	public void setUtil_exp_resp(String util_exp_resp) {
		this.util_exp_resp = util_exp_resp;
	}

	public String getTrb_cpta_resp() {
		return trb_cpta_resp;
	}

	public void setTrb_cpta_resp(String trb_cpta_resp) {
		this.trb_cpta_resp = trb_cpta_resp;
	}

	public String getBury_aset_c_resp() {
		return bury_aset_c_resp;
	}

	public void setBury_aset_c_resp(String bury_aset_c_resp) {
		this.bury_aset_c_resp = bury_aset_c_resp;
	}

	public String getBury_aset_ibt_resp() {
		return bury_aset_ibt_resp;
	}

	public void setBury_aset_ibt_resp(String bury_aset_ibt_resp) {
		this.bury_aset_ibt_resp = bury_aset_ibt_resp;
	}

	public String getBury_aset_ins_resp() {
		return bury_aset_ins_resp;
	}

	public void setBury_aset_ins_resp(String bury_aset_ins_resp) {
		this.bury_aset_ins_resp = bury_aset_ins_resp;
	}

	public String getBury_aset_mas_resp() {
		return bury_aset_mas_resp;
	}

	public void setBury_aset_mas_resp(String bury_aset_mas_resp) {
		this.bury_aset_mas_resp = bury_aset_mas_resp;
	}

	public String getBury_aset_oth_resp() {
		return bury_aset_oth_resp;
	}

	public void setBury_aset_oth_resp(String bury_aset_oth_resp) {
		this.bury_aset_oth_resp = bury_aset_oth_resp;
	}

	public String getBury_aset_plt_resp() {
		return bury_aset_plt_resp;
	}

	public void setBury_aset_plt_resp(String bury_aset_plt_resp) {
		this.bury_aset_plt_resp = bury_aset_plt_resp;
	}

	public String getBury_aset_rbt_resp() {
		return bury_aset_rbt_resp;
	}

	public void setBury_aset_rbt_resp(String bury_aset_rbt_resp) {
		this.bury_aset_rbt_resp = bury_aset_rbt_resp;
	}

	public String getBury_aset_v_resp() {
		return bury_aset_v_resp;
	}

	public void setBury_aset_v_resp(String bury_aset_v_resp) {
		this.bury_aset_v_resp = bury_aset_v_resp;
	}

	public String getEduc_aid_resp() {
		return educ_aid_resp;
	}

	public void setEduc_aid_resp(String educ_aid_resp) {
		this.educ_aid_resp = educ_aid_resp;
	}

	public String getLi_aset_g_l_resp() {
		return li_aset_g_l_resp;
	}

	public void setLi_aset_g_l_resp(String li_aset_g_l_resp) {
		this.li_aset_g_l_resp = li_aset_g_l_resp;
	}

	public String getLi_aset_g_t_resp() {
		return li_aset_g_t_resp;
	}

	public void setLi_aset_g_t_resp(String li_aset_g_t_resp) {
		this.li_aset_g_t_resp = li_aset_g_t_resp;
	}

	public String getLi_aset_trm_resp() {
		return li_aset_trm_resp;
	}

	public void setLi_aset_trm_resp(String li_aset_trm_resp) {
		this.li_aset_trm_resp = li_aset_trm_resp;
	}

	public String getLi_aset_unv_resp() {
		return li_aset_unv_resp;
	}

	public void setLi_aset_unv_resp(String li_aset_unv_resp) {
		this.li_aset_unv_resp = li_aset_unv_resp;
	}

	public String getLi_aset_w_l_resp() {
		return li_aset_w_l_resp;
	}

	public void setLi_aset_w_l_resp(String li_aset_w_l_resp) {
		this.li_aset_w_l_resp = li_aset_w_l_resp;
	}

	public String getLqd_aset_c_a_resp() {
		return lqd_aset_c_a_resp;
	}

	public void setLqd_aset_c_a_resp(String lqd_aset_c_a_resp) {
		this.lqd_aset_c_a_resp = lqd_aset_c_a_resp;
	}

	public String getLqd_aset_cash_resp() {
		return lqd_aset_cash_resp;
	}

	public void setLqd_aset_cash_resp(String lqd_aset_cash_resp) {
		this.lqd_aset_cash_resp = lqd_aset_cash_resp;
	}

	public String getLqd_aset_eb_a_resp() {
		return lqd_aset_eb_a_resp;
	}

	public void setLqd_aset_eb_a_resp(String lqd_aset_eb_a_resp) {
		this.lqd_aset_eb_a_resp = lqd_aset_eb_a_resp;
	}

	public String getLqd_aset_h_s_resp() {
		return lqd_aset_h_s_resp;
	}

	public void setLqd_aset_h_s_resp(String lqd_aset_h_s_resp) {
		this.lqd_aset_h_s_resp = lqd_aset_h_s_resp;
	}

	public String getLqd_aset_ira_resp() {
		return lqd_aset_ira_resp;
	}

	public void setLqd_aset_ira_resp(String lqd_aset_ira_resp) {
		this.lqd_aset_ira_resp = lqd_aset_ira_resp;
	}

	public String getLqd_aset_k_p_resp() {
		return lqd_aset_k_p_resp;
	}

	public void setLqd_aset_k_p_resp(String lqd_aset_k_p_resp) {
		this.lqd_aset_k_p_resp = lqd_aset_k_p_resp;
	}

	public String getLqd_aset_m_o_resp() {
		return lqd_aset_m_o_resp;
	}

	public void setLqd_aset_m_o_resp(String lqd_aset_m_o_resp) {
		this.lqd_aset_m_o_resp = lqd_aset_m_o_resp;
	}

	public String getLqd_aset_mm_a_resp() {
		return lqd_aset_mm_a_resp;
	}

	public void setLqd_aset_mm_a_resp(String lqd_aset_mm_a_resp) {
		this.lqd_aset_mm_a_resp = lqd_aset_mm_a_resp;
	}

	public String getLqd_aset_o_t_resp() {
		return lqd_aset_o_t_resp;
	}

	public void setLqd_aset_o_t_resp(String lqd_aset_o_t_resp) {
		this.lqd_aset_o_t_resp = lqd_aset_o_t_resp;
	}

	public String getLqd_aset_othr_resp() {
		return lqd_aset_othr_resp;
	}

	public void setLqd_aset_othr_resp(String lqd_aset_othr_resp) {
		this.lqd_aset_othr_resp = lqd_aset_othr_resp;
	}

	public String getLqd_aset_s_a_resp() {
		return lqd_aset_s_a_resp;
	}

	public void setLqd_aset_s_a_resp(String lqd_aset_s_a_resp) {
		this.lqd_aset_s_a_resp = lqd_aset_s_a_resp;
	}

	public String getLqd_aset_s_c_resp() {
		return lqd_aset_s_c_resp;
	}

	public void setLqd_aset_s_c_resp(String lqd_aset_s_c_resp) {
		this.lqd_aset_s_c_resp = lqd_aset_s_c_resp;
	}

	public String getLqd_aset_st_b_resp() {
		return lqd_aset_st_b_resp;
	}

	public void setLqd_aset_st_b_resp(String lqd_aset_st_b_resp) {
		this.lqd_aset_st_b_resp = lqd_aset_st_b_resp;
	}

	public String getLqd_aset_tr_f_resp() {
		return lqd_aset_tr_f_resp;
	}

	public void setLqd_aset_tr_f_resp(String lqd_aset_tr_f_resp) {
		this.lqd_aset_tr_f_resp = lqd_aset_tr_f_resp;
	}

	public String getLqd_aset_tx_s_resp() {
		return lqd_aset_tx_s_resp;
	}

	public void setLqd_aset_tx_s_resp(String lqd_aset_tx_s_resp) {
		this.lqd_aset_tx_s_resp = lqd_aset_tx_s_resp;
	}

	public String getLqd_aset_us_b_resp() {
		return lqd_aset_us_b_resp;
	}

	public void setLqd_aset_us_b_resp(String lqd_aset_us_b_resp) {
		this.lqd_aset_us_b_resp = lqd_aset_us_b_resp;
	}

	public String getLqd_aset_xmas_resp() {
		return lqd_aset_xmas_resp;
	}

	public void setLqd_aset_xmas_resp(String lqd_aset_xmas_resp) {
		this.lqd_aset_xmas_resp = lqd_aset_xmas_resp;
	}

	public String getOthr_aset_bur_resp() {
		return othr_aset_bur_resp;
	}

	public void setOthr_aset_bur_resp(String othr_aset_bur_resp) {
		this.othr_aset_bur_resp = othr_aset_bur_resp;
	}

	public String getOthr_aset_l_i_resp() {
		return othr_aset_l_i_resp;
	}

	public void setOthr_aset_l_i_resp(String othr_aset_l_i_resp) {
		this.othr_aset_l_i_resp = othr_aset_l_i_resp;
	}

	public String getOthr_aset_p_p_resp() {
		return othr_aset_p_p_resp;
	}

	public void setOthr_aset_p_p_resp(String othr_aset_p_p_resp) {
		this.othr_aset_p_p_resp = othr_aset_p_p_resp;
	}

	public String getOthr_aset_r_p_resp() {
		return othr_aset_r_p_resp;
	}

	public void setOthr_aset_r_p_resp(String othr_aset_r_p_resp) {
		this.othr_aset_r_p_resp = othr_aset_r_p_resp;
	}

	public String getOthr_aset_veh_resp() {
		return othr_aset_veh_resp;
	}

	public void setOthr_aset_veh_resp(String othr_aset_veh_resp) {
		this.othr_aset_veh_resp = othr_aset_veh_resp;
	}

	public String getOthr_aset_xfr_resp() {
		return othr_aset_xfr_resp;
	}

	public void setOthr_aset_xfr_resp(String othr_aset_xfr_resp) {
		this.othr_aset_xfr_resp = othr_aset_xfr_resp;
	}

	public String getReal_aset_apt_resp() {
		return real_aset_apt_resp;
	}

	public void setReal_aset_apt_resp(String real_aset_apt_resp) {
		this.real_aset_apt_resp = real_aset_apt_resp;
	}

	public String getReal_aset_con_resp() {
		return real_aset_con_resp;
	}

	public void setReal_aset_con_resp(String real_aset_con_resp) {
		this.real_aset_con_resp = real_aset_con_resp;
	}

	public String getReal_aset_dup_resp() {
		return real_aset_dup_resp;
	}

	public void setReal_aset_dup_resp(String real_aset_dup_resp) {
		this.real_aset_dup_resp = real_aset_dup_resp;
	}

	public String getReal_aset_frm_resp() {
		return real_aset_frm_resp;
	}

	public void setReal_aset_frm_resp(String real_aset_frm_resp) {
		this.real_aset_frm_resp = real_aset_frm_resp;
	}

	public String getReal_aset_hse_resp() {
		return real_aset_hse_resp;
	}

	public void setReal_aset_hse_resp(String real_aset_hse_resp) {
		this.real_aset_hse_resp = real_aset_hse_resp;
	}

	public String getReal_aset_lnd_resp() {
		return real_aset_lnd_resp;
	}

	public void setReal_aset_lnd_resp(String real_aset_lnd_resp) {
		this.real_aset_lnd_resp = real_aset_lnd_resp;
	}

	public String getReal_aset_m_h_resp() {
		return real_aset_m_h_resp;
	}

	public void setReal_aset_m_h_resp(String real_aset_m_h_resp) {
		this.real_aset_m_h_resp = real_aset_m_h_resp;
	}

	public String getReal_aset_oth_resp() {
		return real_aset_oth_resp;
	}

	public void setReal_aset_oth_resp(String real_aset_oth_resp) {
		this.real_aset_oth_resp = real_aset_oth_resp;
	}

	public String getVeh_aset_arpl_resp() {
		return veh_aset_arpl_resp;
	}

	public void setVeh_aset_arpl_resp(String veh_aset_arpl_resp) {
		this.veh_aset_arpl_resp = veh_aset_arpl_resp;
	}

	public String getVeh_aset_auto_resp() {
		return veh_aset_auto_resp;
	}

	public void setVeh_aset_auto_resp(String veh_aset_auto_resp) {
		this.veh_aset_auto_resp = veh_aset_auto_resp;
	}

	public String getVeh_aset_boat_resp() {
		return veh_aset_boat_resp;
	}

	public void setVeh_aset_boat_resp(String veh_aset_boat_resp) {
		this.veh_aset_boat_resp = veh_aset_boat_resp;
	}

	public String getVeh_aset_camp_resp() {
		return veh_aset_camp_resp;
	}

	public void setVeh_aset_camp_resp(String veh_aset_camp_resp) {
		this.veh_aset_camp_resp = veh_aset_camp_resp;
	}

	public String getVeh_aset_mcyc_resp() {
		return veh_aset_mcyc_resp;
	}

	public void setVeh_aset_mcyc_resp(String veh_aset_mcyc_resp) {
		this.veh_aset_mcyc_resp = veh_aset_mcyc_resp;
	}

	public String getVeh_aset_mped_rsp() {
		return veh_aset_mped_rsp;
	}

	public void setVeh_aset_mped_rsp(String veh_aset_mped_rsp) {
		this.veh_aset_mped_rsp = veh_aset_mped_rsp;
	}

	public String getVeh_aset_nm_b_resp() {
		return veh_aset_nm_b_resp;
	}

	public void setVeh_aset_nm_b_resp(String veh_aset_nm_b_resp) {
		this.veh_aset_nm_b_resp = veh_aset_nm_b_resp;
	}

	public String getVeh_aset_othr_resp() {
		return veh_aset_othr_resp;
	}

	public void setVeh_aset_othr_resp(String veh_aset_othr_resp) {
		this.veh_aset_othr_resp = veh_aset_othr_resp;
	}

	public String getVeh_aset_rv_resp() {
		return veh_aset_rv_resp;
	}

	public void setVeh_aset_rv_resp(String veh_aset_rv_resp) {
		this.veh_aset_rv_resp = veh_aset_rv_resp;
	}

	public String getVeh_aset_s_mb_resp() {
		return veh_aset_s_mb_resp;
	}

	public void setVeh_aset_s_mb_resp(String veh_aset_s_mb_resp) {
		this.veh_aset_s_mb_resp = veh_aset_s_mb_resp;
	}

	public String getVeh_aset_trk_resp() {
		return veh_aset_trk_resp;
	}

	public void setVeh_aset_trk_resp(String veh_aset_trk_resp) {
		this.veh_aset_trk_resp = veh_aset_trk_resp;
	}

	public String getVeh_aset_trlr_resp() {
		return veh_aset_trlr_resp;
	}

	public void setVeh_aset_trlr_resp(String veh_aset_trlr_resp) {
		this.veh_aset_trlr_resp = veh_aset_trlr_resp;
	}

	public String getVeh_aset_van_resp() {
		return veh_aset_van_resp;
	}

	public void setVeh_aset_van_resp(String veh_aset_van_resp) {
		this.veh_aset_van_resp = veh_aset_van_resp;
	}

	public String getVeh_aset_fmeq_resp() {
		return veh_aset_fmeq_resp;
	}

	public void setVeh_aset_fmeq_resp(String veh_aset_fmeq_resp) {
		this.veh_aset_fmeq_resp = veh_aset_fmeq_resp;
	}

	public String getEmer_ma_resp() {
		return emer_ma_resp;
	}

	public void setEmer_ma_resp(String emer_ma_resp) {
		this.emer_ma_resp = emer_ma_resp;
	}

	public String getTb_resp() {
		return tb_resp;
	}

	public void setTb_resp(String tb_resp) {
		this.tb_resp = tb_resp;
	}

	public String getChld_trb_mbr_resp() {
		return chld_trb_mbr_resp;
	}

	public void setChld_trb_mbr_resp(String chld_trb_mbr_resp) {
		this.chld_trb_mbr_resp = chld_trb_mbr_resp;
	}

	public String getTrb_mbr_resp() {
		return trb_mbr_resp;
	}

	public void setTrb_mbr_resp(String trb_mbr_resp) {
		this.trb_mbr_resp = trb_mbr_resp;
	}

	public String getYeohc_resp() {
		return yeohc_resp;
	}

	public void setYeohc_resp(String yeohc_resp) {
		this.yeohc_resp = yeohc_resp;
	}

	

	public String getCool_exp_resp() {
		return cool_exp_resp;
	}

	public void setCool_exp_resp(String cool_exp_resp) {
		this.cool_exp_resp = cool_exp_resp;
	}

	public String getSer_rqst_ind() {
		return ser_rqst_ind;
	}

	public void setSer_rqst_ind(String ser_rqst_ind) {
		this.ser_rqst_ind = ser_rqst_ind;
	}

	public String getSer_eb_resp() {
		return ser_eb_resp;
	}

	public void setSer_eb_resp(String ser_eb_resp) {
		this.ser_eb_resp = ser_eb_resp;
	}

	public String getSer_ed_resp() {
		return ser_ed_resp;
	}

	public void setSer_ed_resp(String ser_ed_resp) {
		this.ser_ed_resp = ser_ed_resp;
	}

	public String getSer_hd_resp() {
		return ser_hd_resp;
	}

	public void setSer_hd_resp(String ser_hd_resp) {
		this.ser_hd_resp = ser_hd_resp;
	}

	public String getSer_he_resp() {
		return ser_he_resp;
	}

	public void setSer_he_resp(String ser_he_resp) {
		this.ser_he_resp = ser_he_resp;
	}

	public String getSer_fr_resp() {
		return ser_fr_resp;
	}

	public void setSer_fr_resp(String ser_fr_resp) {
		this.ser_fr_resp = ser_fr_resp;
	}

	public String getGarnishment_resp() {
		return garnishment_resp;
	}

	public void setGarnishment_resp(String garnishment_resp) {
		this.garnishment_resp = garnishment_resp;
	}

	public String getBasic_allow_housing_mil_resp() {
		return basic_allow_housing_mil_resp;
	}

	public void setBasic_allow_housing_mil_resp(String basic_allow_housing_mil_resp) {
		this.basic_allow_housing_mil_resp = basic_allow_housing_mil_resp;
	}

	public String getCloth_maint_allow_mil_resp() {
		return cloth_maint_allow_mil_resp;
	}

	public void setCloth_maint_allow_mil_resp(String cloth_maint_allow_mil_resp) {
		this.cloth_maint_allow_mil_resp = cloth_maint_allow_mil_resp;
	}

	public String getOther_deduction_resp() {
		return other_deduction_resp;
	}

	public void setOther_deduction_resp(String other_deduction_resp) {
		this.other_deduction_resp = other_deduction_resp;
	}

	public String getDeduction_resp() {
		return deduction_resp;
	}

	public void setDeduction_resp(String deduction_resp) {
		this.deduction_resp = deduction_resp;
	}

	public String getBnft_bl_resp() {
		return bnft_bl_resp;
	}

	public void setBnft_bl_resp(String bnft_bl_resp) {
		this.bnft_bl_resp = bnft_bl_resp;
	}

	public String getBnft_va_resp() {
		return bnft_va_resp;
	}

	public void setBnft_va_resp(String bnft_va_resp) {
		this.bnft_va_resp = bnft_va_resp;
	}

	public String getEmergency_medical_service_resp() {
		return emergency_medical_service_resp;
	}

	public void setEmergency_medical_service_resp(String emergency_medical_service_resp) {
		this.emergency_medical_service_resp = emergency_medical_service_resp;
	}

	public String getHead_of_household_resp() {
		return head_of_household_resp;
	}

	public void setHead_of_household_resp(String head_of_household_resp) {
		this.head_of_household_resp = head_of_household_resp;
	}

	public String getHlth_insurance_cur_cvrg_resp() {
		return hlth_insurance_cur_cvrg_resp;
	}

	public void setHlth_insurance_cur_cvrg_resp(String hlth_insurance_cur_cvrg_resp) {
		this.hlth_insurance_cur_cvrg_resp = hlth_insurance_cur_cvrg_resp;
	}

	public String getHlth_insurance_past_cvrg_resp() {
		return hlth_insurance_past_cvrg_resp;
	}

	public void setHlth_insurance_past_cvrg_resp(String hlth_insurance_past_cvrg_resp) {
		this.hlth_insurance_past_cvrg_resp = hlth_insurance_past_cvrg_resp;
	}

	public String getHousing_bill_home_ins_resp() {
		return housing_bill_home_ins_resp;
	}

	public void setHousing_bill_home_ins_resp(String housing_bill_home_ins_resp) {
		this.housing_bill_home_ins_resp = housing_bill_home_ins_resp;
	}

	public String getHousing_bill_others_resp() {
		return housing_bill_others_resp;
	}

	public void setHousing_bill_others_resp(String housing_bill_others_resp) {
		this.housing_bill_others_resp = housing_bill_others_resp;
	}

	public String getIncome_change_resp() {
		return income_change_resp;
	}

	public void setIncome_change_resp(String income_change_resp) {
		this.income_change_resp = income_change_resp;
	}

	public String getJob_iknd_resp() {
		return job_iknd_resp;
	}

	public void setJob_iknd_resp(String job_iknd_resp) {
		this.job_iknd_resp = job_iknd_resp;
	}

	public String getLoss_empl_resp() {
		return loss_empl_resp;
	}

	public void setLoss_empl_resp(String loss_empl_resp) {
		this.loss_empl_resp = loss_empl_resp;
	}

	public String getMed_ins_resp() {
		return med_ins_resp;
	}

	public void setMed_ins_resp(String med_ins_resp) {
		this.med_ins_resp = med_ins_resp;
	}

	public String getMedcr_ettl_resp() {
		return medcr_ettl_resp;
	}

	public void setMedcr_ettl_resp(String medcr_ettl_resp) {
		this.medcr_ettl_resp = medcr_ettl_resp;
	}

	public String getMony_othr_resp() {
		return mony_othr_resp;
	}

	public void setMony_othr_resp(String mony_othr_resp) {
		this.mony_othr_resp = mony_othr_resp;
	}

	public String getNatl_rfge_resp() {
		return natl_rfge_resp;
	}

	public void setNatl_rfge_resp(String natl_rfge_resp) {
		this.natl_rfge_resp = natl_rfge_resp;
	}

	public String getNeed_ind_resp() {
		return need_ind_resp;
	}

	public void setNeed_ind_resp(String need_ind_resp) {
		this.need_ind_resp = need_ind_resp;
	}

	public String getOn_strk_sw() {
		return on_strk_sw;
	}

	public void setOn_strk_sw(String on_strk_sw) {
		this.on_strk_sw = on_strk_sw;
	}

	public String getOp_aoda_tmt_rcv_sw() {
		return op_aoda_tmt_rcv_sw;
	}

	public void setOp_aoda_tmt_rcv_sw(String op_aoda_tmt_rcv_sw) {
		this.op_aoda_tmt_rcv_sw = op_aoda_tmt_rcv_sw;
	}

	public String getOthr_incm_resp() {
		return othr_incm_resp;
	}

	public void setOthr_incm_resp(String othr_incm_resp) {
		this.othr_incm_resp = othr_incm_resp;
	}

	public String getOthr_src_resp() {
		return othr_src_resp;
	}

	public void setOthr_src_resp(String othr_src_resp) {
		this.othr_src_resp = othr_src_resp;
	}

	public String getPay_rmr_brd_resp() {
		return pay_rmr_brd_resp;
	}

	public void setPay_rmr_brd_resp(String pay_rmr_brd_resp) {
		this.pay_rmr_brd_resp = pay_rmr_brd_resp;
	}

	public String getPnsn_retr_resp() {
		return pnsn_retr_resp;
	}

	public void setPnsn_retr_resp(String pnsn_retr_resp) {
		this.pnsn_retr_resp = pnsn_retr_resp;
	}

	public String getProp_sold_resp() {
		return prop_sold_resp;
	}

	public void setProp_sold_resp(String prop_sold_resp) {
		this.prop_sold_resp = prop_sold_resp;
	}

	public String getRcv_fs_oth_st_resp() {
		return rcv_fs_oth_st_resp;
	}

	public void setRcv_fs_oth_st_resp(String rcv_fs_oth_st_resp) {
		this.rcv_fs_oth_st_resp = rcv_fs_oth_st_resp;
	}

	public String getRcv_ss_resp() {
		return rcv_ss_resp;
	}

	public void setRcv_ss_resp(String rcv_ss_resp) {
		this.rcv_ss_resp = rcv_ss_resp;
	}

	public String getRcv_ssi_ever_resp() {
		return rcv_ssi_ever_resp;
	}

	public void setRcv_ssi_ever_resp(String rcv_ssi_ever_resp) {
		this.rcv_ssi_ever_resp = rcv_ssi_ever_resp;
	}

	public String getRcv_ssi_ltr_resp() {
		return rcv_ssi_ltr_resp;
	}

	public void setRcv_ssi_ltr_resp(String rcv_ssi_ltr_resp) {
		this.rcv_ssi_ltr_resp = rcv_ssi_ltr_resp;
	}

	public String getRcv_ssi_sw() {
		return rcv_ssi_sw;
	}

	public void setRcv_ssi_sw(String rcv_ssi_sw) {
		this.rcv_ssi_sw = rcv_ssi_sw;
	}

	public String getRmr_brd_inc_resp() {
		return rmr_brd_inc_resp;
	}

	public void setRmr_brd_inc_resp(String rmr_brd_inc_resp) {
		this.rmr_brd_inc_resp = rmr_brd_inc_resp;
	}

	public String getSelf_empl_resp() {
		return self_empl_resp;
	}

	public void setSelf_empl_resp(String self_empl_resp) {
		this.self_empl_resp = self_empl_resp;
	}

	public String getSep_fs_rqst_sw() {
		return sep_fs_rqst_sw;
	}

	public void setSep_fs_rqst_sw(String sep_fs_rqst_sw) {
		this.sep_fs_rqst_sw = sep_fs_rqst_sw;
	}

	public String getShlt_cst_resp() {
		return shlt_cst_resp;
	}

	public void setShlt_cst_resp(String shlt_cst_resp) {
		this.shlt_cst_resp = shlt_cst_resp;
	}

	public String getSsi_1619b_rcv_sw() {
		return ssi_1619b_rcv_sw;
	}

	public void setSsi_1619b_rcv_sw(String ssi_1619b_rcv_sw) {
		this.ssi_1619b_rcv_sw = ssi_1619b_rcv_sw;
	}

	public String getSu_cst_ases_resp() {
		return su_cst_ases_resp;
	}

	public void setSu_cst_ases_resp(String su_cst_ases_resp) {
		this.su_cst_ases_resp = su_cst_ases_resp;
	}

	public String getSu_cst_coal_resp() {
		return su_cst_coal_resp;
	}

	public void setSu_cst_coal_resp(String su_cst_coal_resp) {
		this.su_cst_coal_resp = su_cst_coal_resp;
	}

	public String getSu_cst_elec_resp() {
		return su_cst_elec_resp;
	}

	public void setSu_cst_elec_resp(String su_cst_elec_resp) {
		this.su_cst_elec_resp = su_cst_elec_resp;
	}

	public String getSu_cst_gas_resp() {
		return su_cst_gas_resp;
	}

	public void setSu_cst_gas_resp(String su_cst_gas_resp) {
		this.su_cst_gas_resp = su_cst_gas_resp;
	}

	public String getSu_cst_home_resp() {
		return su_cst_home_resp;
	}

	public void setSu_cst_home_resp(String su_cst_home_resp) {
		this.su_cst_home_resp = su_cst_home_resp;
	}

	public String getSu_cst_istl_resp() {
		return su_cst_istl_resp;
	}

	public void setSu_cst_istl_resp(String su_cst_istl_resp) {
		this.su_cst_istl_resp = su_cst_istl_resp;
	}

	public String getSu_cst_lpgas_resp() {
		return su_cst_lpgas_resp;
	}

	public void setSu_cst_lpgas_resp(String su_cst_lpgas_resp) {
		this.su_cst_lpgas_resp = su_cst_lpgas_resp;
	}

	public String getSu_cst_mbl_resp() {
		return su_cst_mbl_resp;
	}

	public void setSu_cst_mbl_resp(String su_cst_mbl_resp) {
		this.su_cst_mbl_resp = su_cst_mbl_resp;
	}

	public String getSu_cst_othr_resp() {
		return su_cst_othr_resp;
	}

	public void setSu_cst_othr_resp(String su_cst_othr_resp) {
		this.su_cst_othr_resp = su_cst_othr_resp;
	}

	public String getSu_cst_rent_resp() {
		return su_cst_rent_resp;
	}

	public void setSu_cst_rent_resp(String su_cst_rent_resp) {
		this.su_cst_rent_resp = su_cst_rent_resp;
	}

	public String getAcdt_resp() {
		return acdt_resp;
	}

	public void setAcdt_resp(String acdt_resp) {
		this.acdt_resp = acdt_resp;
	}

	public String getAdpt_asst_resp() {
		return adpt_asst_resp;
	}

	public void setAdpt_asst_resp(String adpt_asst_resp) {
		this.adpt_asst_resp = adpt_asst_resp;
	}

	public String getAlmy_rcv_resp() {
		return almy_rcv_resp;
	}

	public void setAlmy_rcv_resp(String almy_rcv_resp) {
		this.almy_rcv_resp = almy_rcv_resp;
	}

	public String getBnft_anty_resp() {
		return bnft_anty_resp;
	}

	public void setBnft_anty_resp(String bnft_anty_resp) {
		this.bnft_anty_resp = bnft_anty_resp;
	}

	public String getBnft_chl_sprt_resp() {
		return bnft_chl_sprt_resp;
	}

	public void setBnft_chl_sprt_resp(String bnft_chl_sprt_resp) {
		this.bnft_chl_sprt_resp = bnft_chl_sprt_resp;
	}

	public String getBnft_chrt_resp() {
		return bnft_chrt_resp;
	}

	public void setBnft_chrt_resp(String bnft_chrt_resp) {
		this.bnft_chrt_resp = bnft_chrt_resp;
	}

	public String getBnft_dabl_resp() {
		return bnft_dabl_resp;
	}

	public void setBnft_dabl_resp(String bnft_dabl_resp) {
		this.bnft_dabl_resp = bnft_dabl_resp;
	}

	public String getBnft_divnd_resp() {
		return bnft_divnd_resp;
	}

	public void setBnft_divnd_resp(String bnft_divnd_resp) {
		this.bnft_divnd_resp = bnft_divnd_resp;
	}

	public String getBnft_est_trst_resp() {
		return bnft_est_trst_resp;
	}

	public void setBnft_est_trst_resp(String bnft_est_trst_resp) {
		this.bnft_est_trst_resp = bnft_est_trst_resp;
	}

	public String getBnft_rr_resp() {
		return bnft_rr_resp;
	}

	public void setBnft_rr_resp(String bnft_rr_resp) {
		this.bnft_rr_resp = bnft_rr_resp;
	}

	public String getBnft_uempl_resp() {
		return bnft_uempl_resp;
	}

	public void setBnft_uempl_resp(String bnft_uempl_resp) {
		this.bnft_uempl_resp = bnft_uempl_resp;
	}

	public String getBnft_vet_resp() {
		return bnft_vet_resp;
	}

	public void setBnft_vet_resp(String bnft_vet_resp) {
		this.bnft_vet_resp = bnft_vet_resp;
	}

	public String getChld_sprt_pay_resp() {
		return chld_sprt_pay_resp;
	}

	public void setChld_sprt_pay_resp(String chld_sprt_pay_resp) {
		this.chld_sprt_pay_resp = chld_sprt_pay_resp;
	}

	public String getDpnd_care_resp() {
		return dpnd_care_resp;
	}

	public void setDpnd_care_resp(String dpnd_care_resp) {
		this.dpnd_care_resp = dpnd_care_resp;
	}

	public String getDrug_feln_resp() {
		return drug_feln_resp;
	}

	public void setDrug_feln_resp(String drug_feln_resp) {
		this.drug_feln_resp = drug_feln_resp;
	}

	public String getEmpl_resp() {
		return empl_resp;
	}

	public void setEmpl_resp(String empl_resp) {
		this.empl_resp = empl_resp;
	}

	public String getFset_sctn_resp() {
		return fset_sctn_resp;
	}

	public void setFset_sctn_resp(String fset_sctn_resp) {
		this.fset_sctn_resp = fset_sctn_resp;
	}

	public String getGen_rlf_resp() {
		return gen_rlf_resp;
	}

	public void setGen_rlf_resp(String gen_rlf_resp) {
		this.gen_rlf_resp = gen_rlf_resp;
	}

	public String getIncm_dcon_resp() {
		return incm_dcon_resp;
	}

	public void setIncm_dcon_resp(String incm_dcon_resp) {
		this.incm_dcon_resp = incm_dcon_resp;
	}

	public String getIncm_int_resp() {
		return incm_int_resp;
	}

	public void setIncm_int_resp(String incm_int_resp) {
		this.incm_int_resp = incm_int_resp;
	}

	public Integer getIndv_hc_rqst_ind() {
		return indv_hc_rqst_ind;
	}

	public void setIndv_hc_rqst_ind(Integer indv_hc_rqst_ind) {
		this.indv_hc_rqst_ind = indv_hc_rqst_ind;
	}

	public String getMed_dent_vision_services_resp() {
		return med_dent_vision_services_resp;
	}

	public void setMed_dent_vision_services_resp(String med_dent_vision_services_resp) {
		this.med_dent_vision_services_resp = med_dent_vision_services_resp;
	}

	public String getLand_contract_mortgage_resp() {
		return land_contract_mortgage_resp;
	}

	public void setLand_contract_mortgage_resp(String land_contract_mortgage_resp) {
		this.land_contract_mortgage_resp = land_contract_mortgage_resp;
	}

	public Integer getIndv_ebd_rqst_ind() {
		return indv_ebd_rqst_ind;
	}

	public void setIndv_ebd_rqst_ind(Integer indv_ebd_rqst_ind) {
		this.indv_ebd_rqst_ind = indv_ebd_rqst_ind;
	}

	public Integer getIndv_fpw_rqst_ind() {
		return indv_fpw_rqst_ind;
	}

	public void setIndv_fpw_rqst_ind(Integer indv_fpw_rqst_ind) {
		this.indv_fpw_rqst_ind = indv_fpw_rqst_ind;
	}

	public String getAttdt_hsekpr_srvc_animal_resp() {
		return attdt_hsekpr_srvc_animal_resp;
	}

	public void setAttdt_hsekpr_srvc_animal_resp(String attdt_hsekpr_srvc_animal_resp) {
		this.attdt_hsekpr_srvc_animal_resp = attdt_hsekpr_srvc_animal_resp;
	}

	public String getChild_care_provider_resp() {
		return child_care_provider_resp;
	}

	public void setChild_care_provider_resp(String child_care_provider_resp) {
		this.child_care_provider_resp = child_care_provider_resp;
	}

	public String getResettlement_incm_resp() {
		return resettlement_incm_resp;
	}

	public void setResettlement_incm_resp(String resettlement_incm_resp) {
		this.resettlement_incm_resp = resettlement_incm_resp;
	}

	public String getNursing_care_resp() {
		return nursing_care_resp;
	}

	public void setNursing_care_resp(String nursing_care_resp) {
		this.nursing_care_resp = nursing_care_resp;
	}

	public String getTrbl_ser_resp() {
		return trbl_ser_resp;
	}

	public void setTrbl_ser_resp(String trbl_ser_resp) {
		this.trbl_ser_resp = trbl_ser_resp;
	}

	public String getIndv_peach_rqst_ind() {
		return indv_peach_rqst_ind;
	}

	public String getDiabets_edu_prg_resp() {
		return diabets_edu_prg_resp;
	}

	public void setDiabets_edu_prg_resp(String diabets_edu_prg_resp) {
		this.diabets_edu_prg_resp = diabets_edu_prg_resp;
	}

	public String getOthr_incm_rentl_resp() {
		return othr_incm_rentl_resp;
	}

	public void setOthr_incm_rentl_resp(String othr_incm_rentl_resp) {
		this.othr_incm_rentl_resp = othr_incm_rentl_resp;
	}

	public String getPostage_mail_presc_resp() {
		return postage_mail_presc_resp;
	}

	public void setPostage_mail_presc_resp(String postage_mail_presc_resp) {
		this.postage_mail_presc_resp = postage_mail_presc_resp;
	}

	public String getHlth_hosp_insurance_resp() {
		return hlth_hosp_insurance_resp;
	}

	public void setHlth_hosp_insurance_resp(String hlth_hosp_insurance_resp) {
		this.hlth_hosp_insurance_resp = hlth_hosp_insurance_resp;
	}

	public String getOthr_incm_trbl_ga_resp() {
		return othr_incm_trbl_ga_resp;
	}

	public void setOthr_incm_trbl_ga_resp(String othr_incm_trbl_ga_resp) {
		this.othr_incm_trbl_ga_resp = othr_incm_trbl_ga_resp;
	}

	public void setIndv_peach_rqst_ind(String indv_peach_rqst_ind) {
		this.indv_peach_rqst_ind = indv_peach_rqst_ind;
	}

	public String getApp_num() {
		return app_num;
	}

	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}

	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public String getDabl_resp() {
		return dabl_resp;
	}

	public void setDabl_resp(String dabl_resp) {
		this.dabl_resp = dabl_resp;
	}

	public String getDependent_care_resp() {
		return dependent_care_resp;
	}

	public void setDependent_care_resp(String dependent_care_resp) {
		this.dependent_care_resp = dependent_care_resp;
	}

	public String getFstr_care_resp() {
		return fstr_care_resp;
	}

	public void setFstr_care_resp(String fstr_care_resp) {
		this.fstr_care_resp = fstr_care_resp;
	}

	public Double getIndv_fs_request_ind() {
		return indv_fs_request_ind;
	}

	public void setIndv_fs_request_ind(Double indv_fs_request_ind) {
		this.indv_fs_request_ind = indv_fs_request_ind;
	}

	public String getKinship_care_resp() {
		return kinship_care_resp;
	}

	public void setKinship_care_resp(String kinship_care_resp) {
		this.kinship_care_resp = kinship_care_resp;
	}

	public String getMed_exp_resp() {
		return med_exp_resp;
	}

	public void setMed_exp_resp(String med_exp_resp) {
		this.med_exp_resp = med_exp_resp;
	}

	public String getMil_allot_resp() {
		return mil_allot_resp;
	}

	public void setMil_allot_resp(String mil_allot_resp) {
		this.mil_allot_resp = mil_allot_resp;
	}

	public String getPreg_resp() {
		return preg_resp;
	}

	public void setPreg_resp(String preg_resp) {
		this.preg_resp = preg_resp;
	}

	public String getRcv_fs_other_st_resp() {
		return rcv_fs_other_st_resp;
	}

	public void setRcv_fs_other_st_resp(String rcv_fs_other_st_resp) {
		this.rcv_fs_other_st_resp = rcv_fs_other_st_resp;
	}

	public String getSchl_enrl_resp() {
		return schl_enrl_resp;
	}

	public void setSchl_enrl_resp(String schl_enrl_resp) {
		this.schl_enrl_resp = schl_enrl_resp;
	}

	public String getSu_cst_fuel_resp() {
		return su_cst_fuel_resp;
	}

	public void setSu_cst_fuel_resp(String su_cst_fuel_resp) {
		this.su_cst_fuel_resp = su_cst_fuel_resp;
	}

	public String getSu_cst_mtge_resp() {
		return su_cst_mtge_resp;
	}

	public void setSu_cst_mtge_resp(String su_cst_mtge_resp) {
		this.su_cst_mtge_resp = su_cst_mtge_resp;
	}

	public String getSu_cst_phn_resp() {
		return su_cst_phn_resp;
	}

	public void setSu_cst_phn_resp(String su_cst_phn_resp) {
		this.su_cst_phn_resp = su_cst_phn_resp;
	}

	public String getDup_food_assisstance() {
		return dup_food_assisstance;
	}

	public void setDup_food_assisstance(String dup_food_assisstance) {
		this.dup_food_assisstance = dup_food_assisstance;
	}

	public String getWork_comp_resp() {
		return work_comp_resp;
	}

	public void setWork_comp_resp(String work_comp_resp) {
		this.work_comp_resp = work_comp_resp;
	}

	public String getOther_asset_bur_resp() {
		return other_asset_bur_resp;
	}

	public void setOther_asset_bur_resp(String other_asset_bur_resp) {
		this.other_asset_bur_resp = other_asset_bur_resp;
	}

	public String getOther_asset_veh_resp() {
		return other_asset_veh_resp;
	}

	public void setOther_asset_veh_resp(String other_asset_veh_resp) {
		this.other_asset_veh_resp = other_asset_veh_resp;
	}

	public String getCash_gifts_resp() {
		return cash_gifts_resp;
	}

	public void setCash_gifts_resp(String cash_gifts_resp) {
		this.cash_gifts_resp = cash_gifts_resp;
	}

	public String getChild_support_income_resp() {
		return child_support_income_resp;
	}

	public void setChild_support_income_resp(String child_support_income_resp) {
		this.child_support_income_resp = child_support_income_resp;
	}

	public String getCurrent_new_job_resp() {
		return current_new_job_resp;
	}

	public void setCurrent_new_job_resp(String current_new_job_resp) {
		this.current_new_job_resp = current_new_job_resp;
	}

	public String getFood_clothing_util_rent_resp() {
		return food_clothing_util_rent_resp;
	}

	public void setFood_clothing_util_rent_resp(String food_clothing_util_rent_resp) {
		this.food_clothing_util_rent_resp = food_clothing_util_rent_resp;
	}

	public String getInsurance_settlement_resp() {
		return insurance_settlement_resp;
	}

	public void setInsurance_settlement_resp(String insurance_settlement_resp) {
		this.insurance_settlement_resp = insurance_settlement_resp;
	}

	public String getLiquid_asset_money_lgl_resp() {
		return liquid_asset_money_lgl_resp;
	}

	public void setLiquid_asset_money_lgl_resp(String liquid_asset_money_lgl_resp) {
		this.liquid_asset_money_lgl_resp = liquid_asset_money_lgl_resp;
	}

	public String getParole_violation_resp() {
		return parole_violation_resp;
	}

	public void setParole_violation_resp(String parole_violation_resp) {
		this.parole_violation_resp = parole_violation_resp;
	}

	public String getReal_asset_home_resp() {
		return real_asset_home_resp;
	}

	public void setReal_asset_home_resp(String real_asset_home_resp) {
		this.real_asset_home_resp = real_asset_home_resp;
	}

	public String getMoney_mkt_account() {
		return money_mkt_account;
	}

	public void setMoney_mkt_account(String money_mkt_account) {
		this.money_mkt_account = money_mkt_account;
	}

	public String getReal_asset_unoccupy_home_resp() {
		return real_asset_unoccupy_home_resp;
	}

	public void setReal_asset_unoccupy_home_resp(String real_asset_unoccupy_home_resp) {
		this.real_asset_unoccupy_home_resp = real_asset_unoccupy_home_resp;
	}

	public String getShlt_expense_resp() {
		return shlt_expense_resp;
	}

	public void setShlt_expense_resp(String shlt_expense_resp) {
		this.shlt_expense_resp = shlt_expense_resp;
	}

	public String getIncome_room_boarder_resp() {
		return income_room_boarder_resp;
	}

	public void setIncome_room_boarder_resp(String income_room_boarder_resp) {
		this.income_room_boarder_resp = income_room_boarder_resp;
	}

	public String getCnvct_of_tr_fs_drg_resp() {
		return cnvct_of_tr_fs_drg_resp;
	}

	public void setCnvct_of_tr_fs_drg_resp(String cnvct_of_tr_fs_drg_resp) {
		this.cnvct_of_tr_fs_drg_resp = cnvct_of_tr_fs_drg_resp;
	}

	public String getComm_care_resp() {
		return comm_care_resp;
	}

	public void setComm_care_resp(String comm_care_resp) {
		this.comm_care_resp = comm_care_resp;
	}

	public String getUei_lottery_win_resp() {
		return uei_lottery_win_resp;
	}

	public void setUei_lottery_win_resp(String uei_lottery_win_resp) {
		this.uei_lottery_win_resp = uei_lottery_win_resp;
	}

	public String getCnvct_of_tr_fs_gun_resp() {
		return cnvct_of_tr_fs_gun_resp;
	}

	public void setCnvct_of_tr_fs_gun_resp(String cnvct_of_tr_fs_gun_resp) {
		this.cnvct_of_tr_fs_gun_resp = cnvct_of_tr_fs_gun_resp;
	}

	public String getHshl_primary_care_taker_ind() {
		return hshl_primary_care_taker_ind;
	}

	public void setHshl_primary_care_taker_ind(String hshl_primary_care_taker_ind) {
		this.hshl_primary_care_taker_ind = hshl_primary_care_taker_ind;
	}

	public String getPers_prop_livestock() {
		return pers_prop_livestock;
	}

	public void setPers_prop_livestock(String pers_prop_livestock) {
		this.pers_prop_livestock = pers_prop_livestock;
	}

	public String getHousing_bill_mortgage_resp() {
		return housing_bill_mortgage_resp;
	}

	public void setHousing_bill_mortgage_resp(String housing_bill_mortgage_resp) {
		this.housing_bill_mortgage_resp = housing_bill_mortgage_resp;
	}

	public String getLiquid_asset_trust_fund_resp() {
		return liquid_asset_trust_fund_resp;
	}

	public void setLiquid_asset_trust_fund_resp(String liquid_asset_trust_fund_resp) {
		this.liquid_asset_trust_fund_resp = liquid_asset_trust_fund_resp;
	}

	public String getUei_net_rent_royalty_resp() {
		return uei_net_rent_royalty_resp;
	}

	public void setUei_net_rent_royalty_resp(String uei_net_rent_royalty_resp) {
		this.uei_net_rent_royalty_resp = uei_net_rent_royalty_resp;
	}

	public String getUei_int_div_pymt_resp() {
		return uei_int_div_pymt_resp;
	}

	public void setUei_int_div_pymt_resp(String uei_int_div_pymt_resp) {
		this.uei_int_div_pymt_resp = uei_int_div_pymt_resp;
	}

	public String getHousing_bill_prop_tax_resp() {
		return housing_bill_prop_tax_resp;
	}

	public void setHousing_bill_prop_tax_resp(String housing_bill_prop_tax_resp) {
		this.housing_bill_prop_tax_resp = housing_bill_prop_tax_resp;
	}

	public String getLiquid_asset_ira_resp() {
		return liquid_asset_ira_resp;
	}

	public void setLiquid_asset_ira_resp(String liquid_asset_ira_resp) {
		this.liquid_asset_ira_resp = liquid_asset_ira_resp;
	}

	public String getUei_alimony_resp() {
		return uei_alimony_resp;
	}

	public void setUei_alimony_resp(String uei_alimony_resp) {
		this.uei_alimony_resp = uei_alimony_resp;
	}

	public String getOther_income_contrib_resp() {
		return other_income_contrib_resp;
	}

	public void setOther_income_contrib_resp(String other_income_contrib_resp) {
		this.other_income_contrib_resp = other_income_contrib_resp;
	}

	public String getCash_stp_pnl_sanc() {
		return cash_stp_pnl_sanc;
	}

	public void setCash_stp_pnl_sanc(String cash_stp_pnl_sanc) {
		this.cash_stp_pnl_sanc = cash_stp_pnl_sanc;
	}

	public String getSpecial_needs_resp() {
		return special_needs_resp;
	}

	public void setSpecial_needs_resp(String special_needs_resp) {
		this.special_needs_resp = special_needs_resp;
	}

	public String getLiquid_asset_stocks_bonds_resp() {
		return liquid_asset_stocks_bonds_resp;
	}

	public void setLiquid_asset_stocks_bonds_resp(String liquid_asset_stocks_bonds_resp) {
		this.liquid_asset_stocks_bonds_resp = liquid_asset_stocks_bonds_resp;
	}

	public String getCnvct_of_buy_sell_fs_resp() {
		return cnvct_of_buy_sell_fs_resp;
	}

	public void setCnvct_of_buy_sell_fs_resp(String cnvct_of_buy_sell_fs_resp) {
		this.cnvct_of_buy_sell_fs_resp = cnvct_of_buy_sell_fs_resp;
	}

	public String getPers_prop_saf_depst_box() {
		return pers_prop_saf_depst_box;
	}

	public void setPers_prop_saf_depst_box(String pers_prop_saf_depst_box) {
		this.pers_prop_saf_depst_box = pers_prop_saf_depst_box;
	}

	public String getRcv_benefit_other_st_resp() {
		return rcv_benefit_other_st_resp;
	}

	public void setRcv_benefit_other_st_resp(String rcv_benefit_other_st_resp) {
		this.rcv_benefit_other_st_resp = rcv_benefit_other_st_resp;
	}

	public String getBreast_feed_resp() {
		return breast_feed_resp;
	}

	public void setBreast_feed_resp(String breast_feed_resp) {
		this.breast_feed_resp = breast_feed_resp;
	}

	public String getFormer_fstr_care_resp() {
		return former_fstr_care_resp;
	}

	public void setFormer_fstr_care_resp(String former_fstr_care_resp) {
		this.former_fstr_care_resp = former_fstr_care_resp;
	}

	public String getPers_prop_bus_eqpt() {
		return pers_prop_bus_eqpt;
	}

	public void setPers_prop_bus_eqpt(String pers_prop_bus_eqpt) {
		this.pers_prop_bus_eqpt = pers_prop_bus_eqpt;
	}

	public String getUei_pension_resp() {
		return uei_pension_resp;
	}

	public void setUei_pension_resp(String uei_pension_resp) {
		this.uei_pension_resp = uei_pension_resp;
	}

	public String getUei_rr_retire_resp() {
		return uei_rr_retire_resp;
	}

	public void setUei_rr_retire_resp(String uei_rr_retire_resp) {
		this.uei_rr_retire_resp = uei_rr_retire_resp;
	}

	public String getMed_type_spec_needs_resp() {
		return med_type_spec_needs_resp;
	}

	public void setMed_type_spec_needs_resp(String med_type_spec_needs_resp) {
		this.med_type_spec_needs_resp = med_type_spec_needs_resp;
	}

	public String getCash_stp_welf_frd() {
		return cash_stp_welf_frd;
	}

	public void setCash_stp_welf_frd(String cash_stp_welf_frd) {
		this.cash_stp_welf_frd = cash_stp_welf_frd;
	}

	public String getMed_type_thr_mnth_resp() {
		return med_type_thr_mnth_resp;
	}

	public void setMed_type_thr_mnth_resp(String med_type_thr_mnth_resp) {
		this.med_type_thr_mnth_resp = med_type_thr_mnth_resp;
	}

	public String getMed_type_sixty_dabl_resp() {
		return med_type_sixty_dabl_resp;
	}

	public void setMed_type_sixty_dabl_resp(String med_type_sixty_dabl_resp) {
		this.med_type_sixty_dabl_resp = med_type_sixty_dabl_resp;
	}

	public String getEr_med_care_resp() {
		return er_med_care_resp;
	}

	public void setEr_med_care_resp(String er_med_care_resp) {
		this.er_med_care_resp = er_med_care_resp;
	}

	public String getHealth_insurance_resp() {
		return health_insurance_resp;
	}

	public void setHealth_insurance_resp(String health_insurance_resp) {
		this.health_insurance_resp = health_insurance_resp;
	}

	public String getTanf_fund_misuse_resp() {
		return tanf_fund_misuse_resp;
	}

	public void setTanf_fund_misuse_resp(String tanf_fund_misuse_resp) {
		this.tanf_fund_misuse_resp = tanf_fund_misuse_resp;
	}

	public String getBtd_other() {
		return btd_other;
	}

	public void setBtd_other(String btd_other) {
		this.btd_other = btd_other;
	}

	public String getTanf_disqualify_resp() {
		return tanf_disqualify_resp;
	}

	public void setTanf_disqualify_resp(String tanf_disqualify_resp) {
		this.tanf_disqualify_resp = tanf_disqualify_resp;
	}

	public String getFile_tax_resp() {
		return file_tax_resp;
	}

	public void setFile_tax_resp(String file_tax_resp) {
		this.file_tax_resp = file_tax_resp;
	}

	public String getBonds() {
		return bonds;
	}

	public void setBonds(String bonds) {
		this.bonds = bonds;
	}

	public String getCash() {
		return cash;
	}

	public void setCash(String cash) {
		this.cash = cash;
	}

	public String getCheckin_account() {
		return checkin_account;
	}

	public void setCheckin_account(String checkin_account) {
		this.checkin_account = checkin_account;
	}

	public String getSavings_account() {
		return savings_account;
	}

	public void setSavings_account(String savings_account) {
		this.savings_account = savings_account;
	}

	public String getLoan_rcvd() {
		return loan_rcvd;
	}

	public void setLoan_rcvd(String loan_rcvd) {
		this.loan_rcvd = loan_rcvd;
	}

	public String getSell_ebt_card() {
		return sell_ebt_card;
	}

	public void setSell_ebt_card(String sell_ebt_card) {
		this.sell_ebt_card = sell_ebt_card;
	}

	public String getLeave_ca() {
		return leave_ca;
	}

	public void setLeave_ca(String leave_ca) {
		this.leave_ca = leave_ca;
	}

	public String getStrike_benefits() {
		return strike_benefits;
	}

	public void setStrike_benefits(String strike_benefits) {
		this.strike_benefits = strike_benefits;
	}

	public String getIncluded_unearned_income() {
		return included_unearned_income;
	}

	public void setIncluded_unearned_income(String included_unearned_income) {
		this.included_unearned_income = included_unearned_income;
	}

	public String getHealth_insurance_ninety_end_resp() {
		return health_insurance_ninety_end_resp;
	}

	public void setHealth_insurance_ninety_end_resp(String health_insurance_ninety_end_resp) {
		this.health_insurance_ninety_end_resp = health_insurance_ninety_end_resp;
	}

	public String getIn_kind_support() {
		return in_kind_support;
	}

	public void setIn_kind_support(String in_kind_support) {
		this.in_kind_support = in_kind_support;
	}

	public String getAvd_prsctn_fstf() {
		return avd_prsctn_fstf;
	}

	public void setAvd_prsctn_fstf(String avd_prsctn_fstf) {
		this.avd_prsctn_fstf = avd_prsctn_fstf;
	}

	public String getSu_cst_wtr_swr_trsh_resp() {
		return su_cst_wtr_swr_trsh_resp;
	}

	public void setSu_cst_wtr_swr_trsh_resp(String su_cst_wtr_swr_trsh_resp) {
		this.su_cst_wtr_swr_trsh_resp = su_cst_wtr_swr_trsh_resp;
	}

	public String getHousing_bill_hless_shlt_resp() {
		return housing_bill_hless_shlt_resp;
	}

	public void setHousing_bill_hless_shlt_resp(String housing_bill_hless_shlt_resp) {
		this.housing_bill_hless_shlt_resp = housing_bill_hless_shlt_resp;
	}

	public String getLiquid_asset_cert_resp() {
		return liquid_asset_cert_resp;
	}

	public void setLiquid_asset_cert_resp(String liquid_asset_cert_resp) {
		this.liquid_asset_cert_resp = liquid_asset_cert_resp;
	}

	public String getOil_min_rts() {
		return oil_min_rts;
	}

	public void setOil_min_rts(String oil_min_rts) {
		this.oil_min_rts = oil_min_rts;
	}

	public String getUncshd_checks() {
		return uncshd_checks;
	}

	public void setUncshd_checks(String uncshd_checks) {
		this.uncshd_checks = uncshd_checks;
	}

	public String getOther_asset_resp() {
		return other_asset_resp;
	}

	public void setOther_asset_resp(String other_asset_resp) {
		this.other_asset_resp = other_asset_resp;
	}

	public String getReal_asset_home_mov_resp() {
		return real_asset_home_mov_resp;
	}

	public void setReal_asset_home_mov_resp(String real_asset_home_mov_resp) {
		this.real_asset_home_mov_resp = real_asset_home_mov_resp;
	}

	public String getPers_prop_jwl_art() {
		return pers_prop_jwl_art;
	}

	public void setPers_prop_jwl_art(String pers_prop_jwl_art) {
		this.pers_prop_jwl_art = pers_prop_jwl_art;
	}

	public String getPers_prop_gds_guns() {
		return pers_prop_gds_guns;
	}

	public void setPers_prop_gds_guns(String pers_prop_gds_guns) {
		this.pers_prop_gds_guns = pers_prop_gds_guns;
	}

	public String getPers_prop_pers_tools() {
		return pers_prop_pers_tools;
	}

	public void setPers_prop_pers_tools(String pers_prop_pers_tools) {
		this.pers_prop_pers_tools = pers_prop_pers_tools;
	}

	public String getPers_prop_bus_tools() {
		return pers_prop_bus_tools;
	}

	public void setPers_prop_bus_tools(String pers_prop_bus_tools) {
		this.pers_prop_bus_tools = pers_prop_bus_tools;
	}

	public String getPers_prop_bus_invent() {
		return pers_prop_bus_invent;
	}

	public void setPers_prop_bus_invent(String pers_prop_bus_invent) {
		this.pers_prop_bus_invent = pers_prop_bus_invent;
	}

	public String getPers_trl_bts() {
		return pers_trl_bts;
	}

	public void setPers_trl_bts(String pers_trl_bts) {
		this.pers_trl_bts = pers_trl_bts;
	}

	public String getPers_prop_camp_shell() {
		return pers_prop_camp_shell;
	}

	public void setPers_prop_camp_shell(String pers_prop_camp_shell) {
		this.pers_prop_camp_shell = pers_prop_camp_shell;
	}

	public String getChild_support_exp_resp() {
		return child_support_exp_resp;
	}

	public void setChild_support_exp_resp(String child_support_exp_resp) {
		this.child_support_exp_resp = child_support_exp_resp;
	}

	public String getChange_in_cash_bonus_penalty() {
		return change_in_cash_bonus_penalty;
	}

	public void setChange_in_cash_bonus_penalty(String change_in_cash_bonus_penalty) {
		this.change_in_cash_bonus_penalty = change_in_cash_bonus_penalty;
	}

	public String getChange_in_cash_dvrsn_payment_noncash_serv() {
		return change_in_cash_dvrsn_payment_noncash_serv;
	}

	public void setChange_in_cash_dvrsn_payment_noncash_serv(String change_in_cash_dvrsn_payment_noncash_serv) {
		this.change_in_cash_dvrsn_payment_noncash_serv = change_in_cash_dvrsn_payment_noncash_serv;
	}

	public String getChange_in_disb_or_retirement() {
		return change_in_disb_or_retirement;
	}

	public void setChange_in_disb_or_retirement(String change_in_disb_or_retirement) {
		this.change_in_disb_or_retirement = change_in_disb_or_retirement;
	}

	public String getChange_in_finance_aid() {
		return change_in_finance_aid;
	}

	public void setChange_in_finance_aid(String change_in_finance_aid) {
		this.change_in_finance_aid = change_in_finance_aid;
	}

	public String getChange_in_prgm_asst() {
		return change_in_prgm_asst;
	}

	public void setChange_in_prgm_asst(String change_in_prgm_asst) {
		this.change_in_prgm_asst = change_in_prgm_asst;
	}

	public String getChange_in_ssi_or_ssp() {
		return change_in_ssi_or_ssp;
	}

	public void setChange_in_ssi_or_ssp(String change_in_ssi_or_ssp) {
		this.change_in_ssi_or_ssp = change_in_ssi_or_ssp;
	}

	public String getChange_in_ssr() {
		return change_in_ssr;
	}

	public void setChange_in_ssr(String change_in_ssr) {
		this.change_in_ssr = change_in_ssr;
	}

	public String getChange_in_tribal_payments() {
		return change_in_tribal_payments;
	}

	public void setChange_in_tribal_payments(String change_in_tribal_payments) {
		this.change_in_tribal_payments = change_in_tribal_payments;
	}

	public String getChange_in_vetinc_or_edubenefit() {
		return change_in_vetinc_or_edubenefit;
	}

	public void setChange_in_vetinc_or_edubenefit(String change_in_vetinc_or_edubenefit) {
		this.change_in_vetinc_or_edubenefit = change_in_vetinc_or_edubenefit;
	}

	public String getChange_in_unempl_or_sdi() {
		return change_in_unempl_or_sdi;
	}

	public void setChange_in_unempl_or_sdi(String change_in_unempl_or_sdi) {
		this.change_in_unempl_or_sdi = change_in_unempl_or_sdi;
	}

	public String getSpecial_needs_desc() {
		return special_needs_desc;
	}

	public void setSpecial_needs_desc(String special_needs_desc) {
		this.special_needs_desc = special_needs_desc;
	}

	public String getUnabl_buy_food_sixty() {
		return unabl_buy_food_sixty;
	}

	public void setUnabl_buy_food_sixty(String unabl_buy_food_sixty) {
		this.unabl_buy_food_sixty = unabl_buy_food_sixty;
	}

	public String getMed_type_three_month_resp() {
		return med_type_three_month_resp;
	}

	public void setMed_type_three_month_resp(String med_type_three_month_resp) {
		this.med_type_three_month_resp = med_type_three_month_resp;
	}

	public String getChange_in_ssd() {
		return change_in_ssd;
	}

	public void setChange_in_ssd(String change_in_ssd) {
		this.change_in_ssd = change_in_ssd;
	}

	public String getUei_net_farm_fish_resp() {
		return uei_net_farm_fish_resp;
	}

	public void setUei_net_farm_fish_resp(String uei_net_farm_fish_resp) {
		this.uei_net_farm_fish_resp = uei_net_farm_fish_resp;
	}

	public String getTeen_prnt_resp() {
		return teen_prnt_resp;
	}

	public void setTeen_prnt_resp(String teen_prnt_resp) {
		this.teen_prnt_resp = teen_prnt_resp;
	}

	public Integer getIndv_fma_rqst_ind() {
		return indv_fma_rqst_ind;
	}

	public void setIndv_fma_rqst_ind(Integer indv_fma_rqst_ind) {
		this.indv_fma_rqst_ind = indv_fma_rqst_ind;
	}

	public Integer getIndv_fs_rqst_ind() {
		return indv_fs_rqst_ind;
	}

	public void setIndv_fs_rqst_ind(Integer indv_fs_rqst_ind) {
		this.indv_fs_rqst_ind = indv_fs_rqst_ind;
	}

	public Integer getIndv_tanf_rqst_ind() {
		return indv_tanf_rqst_ind;
	}

	public void setIndv_tanf_rqst_ind(Integer indv_tanf_rqst_ind) {
		this.indv_tanf_rqst_ind = indv_tanf_rqst_ind;
	}

	public Integer getIndv_cc_rqst_ind() {
		return indv_cc_rqst_ind;
	}

	public void setIndv_cc_rqst_ind(Integer indv_cc_rqst_ind) {
		this.indv_cc_rqst_ind = indv_cc_rqst_ind;
	}

	public Integer getIndv_wic_rqst_ind() {
		return indv_wic_rqst_ind;
	}

	public void setIndv_wic_rqst_ind(Integer indv_wic_rqst_ind) {
		this.indv_wic_rqst_ind = indv_wic_rqst_ind;
	}

	public Integer getIndv_magi_rqst_ind() {
		return indv_magi_rqst_ind;
	}

	public void setIndv_magi_rqst_ind(Integer indv_magi_rqst_ind) {
		this.indv_magi_rqst_ind = indv_magi_rqst_ind;
	}

	public Integer getIndv_ca_rqst_ind() {
		return indv_ca_rqst_ind;
	}

	public void setIndv_ca_rqst_ind(Integer indv_ca_rqst_ind) {
		this.indv_ca_rqst_ind = indv_ca_rqst_ind;
	}

	public Integer getIndv_cr_rqst_ind() {
		return indv_cr_rqst_ind;
	}

	public void setIndv_cr_rqst_ind(Integer indv_cr_rqst_ind) {
		this.indv_cr_rqst_ind = indv_cr_rqst_ind;
	}

	public Integer getIndv_fu_rqst_ind() {
		return indv_fu_rqst_ind;
	}

	public void setIndv_fu_rqst_ind(Integer indv_fu_rqst_ind) {
		this.indv_fu_rqst_ind = indv_fu_rqst_ind;
	}

	public String getRefusal_to_work_resp() {
		return refusal_to_work_resp;
	}

	public void setRefusal_to_work_resp(String refusal_to_work_resp) {
		this.refusal_to_work_resp = refusal_to_work_resp;
	}

	public String getPresc_drug_resp() {
		return presc_drug_resp;
	}

	public void setPresc_drug_resp(String presc_drug_resp) {
		this.presc_drug_resp = presc_drug_resp;
	}

	public String getAssociation_fee_resp() {
		return association_fee_resp;
	}

	public void setAssociation_fee_resp(String association_fee_resp) {
		this.association_fee_resp = association_fee_resp;
	}

	public String getUnocc_home_paymt_resp() {
		return unocc_home_paymt_resp;
	}

	public void setUnocc_home_paymt_resp(String unocc_home_paymt_resp) {
		this.unocc_home_paymt_resp = unocc_home_paymt_resp;
	}

	public String getOther_housing_bill_resp() {
		return other_housing_bill_resp;
	}

	public void setOther_housing_bill_resp(String other_housing_bill_resp) {
		this.other_housing_bill_resp = other_housing_bill_resp;
	}

	public String getPrsnl_care_provided_resp() {
		return prsnl_care_provided_resp;
	}

	public void setPrsnl_care_provided_resp(String prsnl_care_provided_resp) {
		this.prsnl_care_provided_resp = prsnl_care_provided_resp;
	}

	public String getOthr_incm_unemp_bnfts_resp() {
		return othr_incm_unemp_bnfts_resp;
	}

	public void setOthr_incm_unemp_bnfts_resp(String othr_incm_unemp_bnfts_resp) {
		this.othr_incm_unemp_bnfts_resp = othr_incm_unemp_bnfts_resp;
	}

	public String getOut_patient_treatment_resp() {
		return out_patient_treatment_resp;
	}

	public void setOut_patient_treatment_resp(String out_patient_treatment_resp) {
		this.out_patient_treatment_resp = out_patient_treatment_resp;
	}

	public String getMed_equip_supplies_resp() {
		return med_equip_supplies_resp;
	}

	public void setMed_equip_supplies_resp(String med_equip_supplies_resp) {
		this.med_equip_supplies_resp = med_equip_supplies_resp;
	}

	
	
	
}