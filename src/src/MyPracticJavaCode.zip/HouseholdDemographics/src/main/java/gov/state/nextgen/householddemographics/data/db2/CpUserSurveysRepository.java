package gov.state.nextgen.householddemographics.data.db2;



import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.CpUserSurveysPrimaryKey;
import gov.state.nextgen.householddemographics.business.entities.CpUserSurveys_Cargo;

@Repository
public interface CpUserSurveysRepository extends CrudRepository<CpUserSurveys_Cargo, CpUserSurveysPrimaryKey>{

	@Query("select c from CpUserSurveys_Cargo c where  c.appNumber = ?1 and c.pageId = ?2")
	public CpUserSurveys_Cargo findByAppNumPageId(Integer appNumber, String pageId);
	
}
