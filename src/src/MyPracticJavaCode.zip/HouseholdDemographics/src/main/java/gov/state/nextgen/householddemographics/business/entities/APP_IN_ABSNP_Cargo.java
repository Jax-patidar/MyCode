package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


public class APP_IN_ABSNP_Cargo implements Serializable{

	private static final long serialVersionUID = -2634748670922778936L;

	@Id
	@Column(name = "app_num")
	private String appNum;
	
	@Column(name = "ap_seq_num")
	private double apSeqNum;
	
	@Column(name = "indv_seq_num")
	private double indvSeqNum;
	
	@Column(name = "pater_estb_sw")
	private String paterEstbSw;
	
	@Column(name = "rec_cplt_ind")
	private double recCpltInd;

	public String getAppNum() {
		return appNum;
	}

	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}

	public double getApSeqNum() {
		return apSeqNum;
	}

	public void setApSeqNum(double apSeqNum) {
		this.apSeqNum = apSeqNum;
	}

	public double getIndvSeqNum() {
		return indvSeqNum;
	}

	public void setIndvSeqNum(double indvSeqNum) {
		this.indvSeqNum = indvSeqNum;
	}

	public String getPaterEstbSw() {
		return paterEstbSw;
	}

	public void setPaterEstbSw(String paterEstbSw) {
		this.paterEstbSw = paterEstbSw;
	}

	public double getRecCpltInd() {
		return recCpltInd;
	}

	public void setRecCpltInd(double recCpltInd) {
		this.recCpltInd = recCpltInd;
	}
}
