package gov.state.nextgen.householddemographics.business.services;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_OTHER_SITUATIONS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_OTHER_SITUATIONS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import gov.state.nextgen.householddemographics.business.rules.ABHouseHoldMemberBO;
import gov.state.nextgen.householddemographics.business.rules.ABProgramInformationBO;
import gov.state.nextgen.householddemographics.business.rules.PROtherSituationsBO;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.constants.HouseholdApplicationConstants;

@Service("PeriodicReportsServiceImpl")
public class PeriodicReportsServiceImpl implements HouseholdDemographicsService {

	@Autowired
	public ABProgramInformationBO aBProgramInformationBO;

	@Autowired
	public PROtherSituationsBO pROtherSituationsBO;

	@Autowired
	private ABHouseHoldMemberBO houseHoldBo;

	private static final String MILLISECONDS = " milliseconds";
	
	private static final String CP_APP_OTHER_SITUATIONS_COLL = "CP_APP_OTHER_SITUATIONS_Collection";
	
	@Override
	public void callBusinessLogic(String methodName, FwTransaction FwTxn) {
		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.STORESTOPBENEFITSPROGRAMINFO:
			storeStopBenefitsProgramInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_OTHER_SITUATIONS:
			storeOtherSituations(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_INDV_MEDICAL_INFO_DETAILS:
			storeIndvMedicalInfoDetails(FwTxn);
			break;
		default:
		}

	}

	/*
	 * 
	 * CSPM-14418 Storing medical Indicator in db if user selected for it (Part of
	 * CF37 flow)
	 * 
	 */
	private void storeIndvMedicalInfoDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"PeriodicReportsServiceImpl.storeIndvMedicalInfoDetails() - START");

		try {

			final Map pageCollection = fwTxn.getPageCollection();
			String app_num = fwTxn.getUserDetails().getAppNumber();

			APP_INDV_Cargo oldcargo = new APP_INDV_Cargo();
			APP_INDV_Cargo newcargo = new APP_INDV_Cargo();

			APP_INDV_Collection coll = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			newcargo = coll.getCargo(0);
			Integer indv_seq_num = newcargo.getIndv_seq_num();

			APP_INDV_Collection appIndvColl = houseHoldBo.loadIndvDataCollection(app_num, indv_seq_num);

			if ((appIndvColl != null) && !appIndvColl.isEmpty()) {
				oldcargo = appIndvColl.getCargo(0);
				oldcargo.setApply_for_medical(newcargo.getApply_for_medical());
				//set update date
				Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
				oldcargo.setUpdate_dt(currentTimeStamp);
				houseHoldBo.storeImmigrationDetail(oldcargo);
			} else {
				newcargo.setApp_num(app_num);
				newcargo.setIndv_seq_num(indv_seq_num);
				houseHoldBo.storeImmigrationDetail(newcargo);
			}

		} catch(Exception exception) {
			FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeIndvMedicalInfoDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"PeriodicReportsServiceImpl.storeIndvMedicalInfoDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

	}

	private void storeStopBenefitsProgramInfo(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"PeriodicReportsServiceImpl.storeStopBenefitsProgramInfo() - START");
		try {

			final Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();

			APP_PGM_RQST_Collection coll = (APP_PGM_RQST_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL);
			APP_PGM_RQST_Cargo rqstcargo = coll.getCargo(0);

			APP_PGM_RQST_Collection existingPrimaryPgmCol = aBProgramInformationBO.loadProgramRqstColl(appNumber);
			if (!(existingPrimaryPgmCol.isEmpty())) {
				APP_PGM_RQST_Cargo existingcargo = existingPrimaryPgmCol.getCargo(0);
				existingcargo.setStop_fma_rqst_ind(rqstcargo.getStop_fma_rqst_ind());
				existingcargo.setStop_fs_rqst_ind(rqstcargo.getStop_fs_rqst_ind());
				existingcargo.setStop_tanf_rqst_ind(rqstcargo.getStop_tanf_rqst_ind());
				//set update date 
				Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
				existingcargo.setUpdate_dt(currentTimeStamp);
				aBProgramInformationBO.storeStopBenefitsProgramInfo(existingPrimaryPgmCol);
			} else {
				aBProgramInformationBO.storeStopBenefitsProgramInfo(coll);
			}

			CP_APP_PGM_INDV_Collection existingIndvPgmCol = aBProgramInformationBO
					.loadIndvProgrammeSelection(appNumber);
			CP_APP_PGM_INDV_Cargo[] indvData = existingIndvPgmCol.getResults();
			for (CP_APP_PGM_INDV_Cargo indvcargo : indvData) {
				indvcargo.setStop_fma_rqst_ind(rqstcargo.getStop_fma_rqst_ind());
				indvcargo.setStop_fs_rqst_ind(rqstcargo.getStop_fs_rqst_ind());
				indvcargo.setStop_tanf_rqst_ind(rqstcargo.getStop_tanf_rqst_ind());
				aBProgramInformationBO.storeStopBenefitsProgramIndvInfo(indvcargo);
			}

		} catch(Exception exception) {
			FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeStopBenefitsProgramInfo", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"PeriodicReportsServiceImpl.storeStopBenefitsProgramInfo() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

	}
	@SuppressWarnings("squid:S3776")
	private void storeOtherSituations(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "PeriodicReportsServiceImpl.storeOtherSituations() - START");
		try {
			final Map pageCollection = txnBean.getPageCollection();
			final String appNum = txnBean.getUserDetails().getAppNumber();
			final CP_APP_OTHER_SITUATIONS_Collection otherSitColl = new CP_APP_OTHER_SITUATIONS_Collection();
			List<String> otherSituationsArrray = new ArrayList<String>();
			CP_APP_OTHER_SITUATIONS_Collection otherSituationsSaveColl = new CP_APP_OTHER_SITUATIONS_Collection();
			CP_APP_OTHER_SITUATIONS_Collection otherSituationsColl = pROtherSituationsBO.getByAppNum(appNum);
			CP_APP_OTHER_SITUATIONS_Cargo otherSitCargo = null;

			if (otherSituationsColl.isEmpty()) {
				otherSitCargo = new CP_APP_OTHER_SITUATIONS_Cargo();
			} else {

				otherSitCargo = otherSituationsColl.getCargo(0);
				otherSitCargo.setFamily_change(null);
				otherSitCargo.setWork_status(null);
				otherSitCargo.setDisability(null);
				otherSitCargo.setImmigration(null);
				otherSitCargo.setInsurance(null);
				otherSitCargo.setCustody(null);
				otherSitCargo.setSchool_attendance(null);
				otherSitCargo.setIn_home_support_services(null);
				otherSitCargo.setSomeone_paid_explain(null);
				otherSitCargo.setOther_changes_explain(null);
				otherSitCargo.setSmone_paid_cmnt(null);
				otherSitCargo.setOthr_change_cmnt(null);
			}

			if (pageCollection.get("OtherSituationsGatepostListCheckBox") != null) {
				otherSituationsArrray = (List<String>) pageCollection.get("OtherSituationsGatepostListCheckBox");
				for (int i = 0; i < otherSituationsArrray.size(); i++) {
					if (otherSituationsArrray.get(i).equals("FC")) {
						otherSitCargo.setFamily_change("Y");
					} else if (otherSituationsArrray.get(i).equals("WS")) {
						otherSitCargo.setWork_status("Y");
					} else if (otherSituationsArrray.get(i).equals("DB")) {
						otherSitCargo.setDisability("Y");
					} else if (otherSituationsArrray.get(i).equals("GC")) {
						otherSitCargo.setImmigration("Y");
					} else if (otherSituationsArrray.get(i).equals("IS")) {
						otherSitCargo.setInsurance("Y");
					} else if (otherSituationsArrray.get(i).equals("CC")) {
						otherSitCargo.setCustody("Y");
					} else if (otherSituationsArrray.get(i).equals("SS")) {
						otherSitCargo.setSchool_attendance("Y");
					} else if (otherSituationsArrray.get(i).equals("HS")) {
						otherSitCargo.setIn_home_support_services("Y");
					} else if (otherSituationsArrray.get(i).equals("HP")) {
						otherSitCargo.setSomeone_paid_explain("Y");
					} else if (otherSituationsArrray.get(i).equals("OT")) {
						otherSitCargo.setOther_changes_explain("Y");
					} else if (otherSituationsArrray.get(i).equals("NA")) {
						otherSitCargo.setNone_of_these_apply("Y");
					}
				}
			}

			if (pageCollection.get(CP_APP_OTHER_SITUATIONS_COLL) != null) {
				CP_APP_OTHER_SITUATIONS_Collection exp = (CP_APP_OTHER_SITUATIONS_Collection) pageCollection
						.get(CP_APP_OTHER_SITUATIONS_COLL);
				if (otherSitCargo.getSomeone_paid_explain() != null) {
					otherSitCargo.setSmone_paid_cmnt(exp.getCargo(0).getSmone_paid_cmnt());
				} else {
					otherSitCargo.setSmone_paid_cmnt("");
				}
				if (otherSitCargo.getOther_changes_explain() != null) {
					otherSitCargo.setOthr_change_cmnt(exp.getCargo(0).getOthr_change_cmnt());
				} else {
					otherSitCargo.setOthr_change_cmnt("");
				}
			}
			otherSitCargo.setApp_num(appNum);
			otherSituationsSaveColl.addCargo(otherSitCargo);
			otherSituationsSaveColl.setCargo(0, otherSitCargo);
			pROtherSituationsBO.storeOtherSituations(otherSituationsSaveColl);
			pageCollection.put(CP_APP_OTHER_SITUATIONS_COLL, otherSituationsSaveColl);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"PeriodicReportsServiceImpl.storeOtherSituations() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

		} catch(Exception exception) {
			FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeOtherSituations", txnBean.getUserDetails().getAppNumber(),
        			txnBean.getUserDetails().getLoginUserId(), true);
		}

	}
}
