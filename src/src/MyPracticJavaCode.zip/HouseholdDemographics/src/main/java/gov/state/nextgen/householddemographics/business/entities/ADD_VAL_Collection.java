package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class ADD_VAL_Collection extends AbstractCollection {

	/**
	 * 
	 */
	private static final long serialVersionUID = 931351827730929527L;
	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.ADD_VAL_Collection";
	
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}
	
	public void addCargo(final ADD_VAL_Cargo aNewCargo) {
		add(aNewCargo);
	}

	private void setResults(ADD_VAL_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}
	
	public void setCargo(final int idx, final ADD_VAL_Cargo aCargo) {
		set(idx, aCargo);
	}
	
	public ADD_VAL_Cargo[] getResults() {
		final ADD_VAL_Cargo[] cbArray = new ADD_VAL_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}
	
	public ADD_VAL_Cargo getCargo(final int idx) {
		return (ADD_VAL_Cargo) get(idx);
	}
	
	public ADD_VAL_Cargo[] cloneResults() {
		final ADD_VAL_Cargo[] rescargo = new ADD_VAL_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final ADD_VAL_Cargo cargo = getCargo(i);
			rescargo[i] = new ADD_VAL_Cargo();
			rescargo[i].setRadioGroup_HOME(cargo.getRadioGroup_HOME());
			rescargo[i].setRadioGroup_MAIL(cargo.getRadioGroup_MAIL());
		}
		return rescargo;
	}
	
	@Override
	public void setGenericResults(Object obj) {
		if (obj instanceof ADD_VAL_Cargo[]) {
			final ADD_VAL_Cargo[] cbArray = (ADD_VAL_Cargo[]) obj;
			setResults(cbArray);
		}
	}
	


	public ADD_VAL_Cargo getResult(final int idx) {
		return (ADD_VAL_Cargo) get(idx);
	}

}
