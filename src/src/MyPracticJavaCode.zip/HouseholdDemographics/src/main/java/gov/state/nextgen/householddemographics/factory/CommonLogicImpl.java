package gov.state.nextgen.householddemographics.factory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.driver.FwPageManager;
import gov.state.nextgen.access.exceptions.BusinessWrappedNotInstantiatedException;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessage;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.householddemographics.business.services.HouseholdDemographicsService;
import gov.state.nextgen.householddemographics.model.PageResponse;

/**
 * Household demographics CommonLogicImpl with  householddemographics.properties pagemapping
 * 
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */
@Component
@PropertySource("classpath:householddemographics_pageaction.properties")
public class CommonLogicImpl implements CommonLogicInterface {

	private static final Logger log = LoggerFactory.getLogger(CommonLogicImpl.class);

	@Autowired
	protected Environment env;

	@Autowired
	private FwPageManager pageManager;
	
	@Autowired
	protected ApplicationContext applicationContext;
	
	@Autowired
	private RestTemplate restTemplate; 

	/**
	 * Process business logic.
	 * @param fwTxn
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public PageResponse processLogic(FwTransaction fwTxn) throws Exception {

		FwLogger.log(this.getClass(), Level.INFO, "CommonLogicImpl : processLogic : Start");
		
		PageResponse pageResponse = null;
		String currentPageId = null;
		String currentPageAction = null;
		String nextPageAction = null;

		if(fwTxn.getCurrentActionDetails() != null) {
			currentPageId = fwTxn.getCurrentActionDetails().getPageId();	
			currentPageAction = fwTxn.getCurrentActionDetails().getPageAction();
		}
		if(fwTxn.getNextActionDetails() != null) {
			nextPageAction = fwTxn.getNextActionDetails().getPageAction();
		}
		try {
			if(null != currentPageAction && null != nextPageAction) {
				pageResponse = saveCurrentPageAndLoadNextPage(fwTxn);
			} else if (null != currentPageAction) {
				pageResponse = loadPageDetails(fwTxn,currentPageId, currentPageAction);
			}
		}catch(FwException exception) {
			FwLogger.log(this.getClass(), Level.INFO, "CommonLogicImpl : processLogic : End");
			throw exception;
		}
		return pageResponse;
	}

	private PageResponse saveCurrentPageAndLoadNextPage(FwTransaction fwTxn) throws Exception {
		
		boolean isValid = true;
		PageResponse pageResponse = null;
		String currentPageId = fwTxn.getCurrentActionDetails().getPageId();;
		String currentPageAction = fwTxn.getCurrentActionDetails().getPageAction();
		boolean isCurrentPageActionCompleted = fwTxn.getCurrentActionDetails().getActionCompleted();
		
		if(!isCurrentPageActionCompleted) {
			String currentpageActionDetails = env.getProperty(currentPageAction);
			if (StringUtils.isNotEmpty(currentpageActionDetails)) {
				/* Calling current Page Save Action */
				callBusinessLogic(currentpageActionDetails,fwTxn);
				if (fwTxn.getRequest() != null && fwTxn.getRequest().get(FwConstants.MESSAGE_LIST) != null) {
					isValid = false;
					pageResponse = getResponseInstance(currentPageId).constructPageResponse(fwTxn);
					populateValidationMessages(fwTxn, pageResponse);
				}
				fwTxn.getCurrentActionDetails().setActionCompleted(true);
			}
		}
		/* Calling Load Method of Next Page after completing
			current Page Save Action with out any validation error */
		if(isValid) {
			// Save action is completed and only Load Action is Pending
			// Now Next Page Load Action will be Current Action so 
			// Create New FwTransaction Object and Map the values to it
			FwTransaction newFwTxn = new FwTransaction();
			newFwTxn.setUserDetails(fwTxn.getUserDetails());
			newFwTxn.setCurrentActionDetails(fwTxn.getNextActionDetails());
			// PageCollection of Old Transaction Object has the details of the Previous Page
			// Therefore creating new map for Page collection of Next page
			Map pageCollection = new HashMap();
			newFwTxn.setPageCollection(pageCollection);
			String pageId = newFwTxn.getCurrentActionDetails().getPageId();
			String pageAction = newFwTxn.getCurrentActionDetails().getPageAction();	
			pageResponse = loadPageDetails(newFwTxn, pageId, pageAction);
		}
		return pageResponse;
	}
	
	private PageResponse loadPageDetails(FwTransaction fwTxn, String pageId, String pageAction) throws Exception {
		PageResponse pageResponse = null;
		if(pageAction!= null && pageId != null ) {
			String loadPageActionDetails = env.getProperty(pageAction);
			if(StringUtils.isNotBlank(loadPageActionDetails)) {
				callBusinessLogic(loadPageActionDetails, fwTxn);
				pageResponse =getResponseInstance(pageId).constructPageResponse(fwTxn);
				/*
				 * Added by swabehera@deloitte.com
				 * To populate exception message based on severity code set in request message list
				 */
				if (fwTxn.getRequest() != null && fwTxn.getRequest().get(FwConstants.MESSAGE_LIST) != null) {
					populateValidationMessages(fwTxn, pageResponse);
				}
				
			}else {
				pageResponse = callNextServiceLoadMethod(fwTxn, pageResponse);
			}
		}
		return pageResponse;
	}
	
	/**
	 * 
	 * @param fwTxn
	 * @param pageResponse
	 * @throws Exception 
	 */
	private PageResponse callNextServiceLoadMethod(FwTransaction fwTxn, PageResponse pageResponse) throws Exception {
		HttpHeaders headers = new HttpHeaders();
			String url = Objects.nonNull(fwTxn.getNextActionDetails())? fwTxn.getNextActionDetails().getPageActionUrl(): StringUtils.EMPTY ;
			if (StringUtils.isNotBlank(url)) {
				headers.setContentType(MediaType.APPLICATION_JSON);
				HttpEntity<FwTransaction> httpentity = new HttpEntity<FwTransaction>(fwTxn, headers);
				if (restTemplate == null) {
					restTemplate = new RestTemplate();
				}
				try {
					ResponseEntity<PageResponse> response = restTemplate.postForEntity(url, httpentity, PageResponse.class);
					if (response.getStatusCode().equals(HttpStatus.OK)) {
						pageResponse = (PageResponse) response.getBody();
					}
					return pageResponse;
				} catch (FwException fe) {
					final FwWrappedException fwx = new FwWrappedException();
					fwx.setFwException(fe);
					fwx.setCallingMethodID(this.getClass().getName());
					fwx.setCallingMethodID("callNextServiceLoadMethod");
					throw createFwException(getClass().getName(), "callNextServiceLoadMethod", fwx);
				} catch (final Exception e) {
					throw createFwException(getClass().getName(), "callNextServiceLoadMethod", e);
				}

			}
		return pageResponse;
	}
	
	private void callBusinessLogic(String pageActionDetails, FwTransaction fwTxn) {

		String[] businessLogicDetails = pageActionDetails.split(FwConstants.COMMA);
		String serviceClassName = businessLogicDetails[0];
		String serviceMethod = businessLogicDetails[1];

		HouseholdDemographicsService service = (HouseholdDemographicsService) applicationContext.getBean(serviceClassName);
		service.callBusinessLogic(serviceMethod, fwTxn);

	}
	

	/**
	 * 
	 * @param pageId
	 * @return
	 * @throws BusinessWrappedNotInstantiatedException
	 */
	private LogicResponseInterface getResponseInstance(String pageId) throws BusinessWrappedNotInstantiatedException {
		return LogicWrapperFactory.createPageResponse(pageId);
	}
	

	/**
	 * This method populates the validation text messages in the FwTransaction for
	 * the message codes returned from the BO layer.
	 * 
	 * @param fwTxn
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private void populateValidationMessages(FwTransaction fwTxn, PageResponse pageResponse) {

		FwMessageList fwMessageList = null;
		List<FwMessage> fwMessages = null;

		// logic for extracting and setting the messages
		if (hasValidationErrors(fwTxn)) {

			fwMessageList = (FwMessageList) fwTxn.getRequest().get(FwConstants.MESSAGE_LIST);
			fwMessages = fwMessageList.getMessageList();

			fwMessages.forEach(fwMessage -> {

				fwMessage.setEnglishMessage(fwMessage.getEnglishMessage());

			});

			pageResponse.setValidationMessages(fwMessages);

		}

	}
	
	protected boolean hasValidationErrors(FwTransaction fwTxn) {

		boolean hasValidationErrors = false;

		if (fwTxn.getRequest().get(FwConstants.MESSAGE_LIST) != null) {

			hasValidationErrors = true;
		}
		return hasValidationErrors;

	}

	/**
	 * The method returns the message description by looking up the PageMap
	 * (Messages) which is cached on server startup using message code and language.
	 *
	 * @param messageCode
	 * @param language
	 * @return
	 */

	/**
	 * creates a new FwException with the given class name, method name and
	 * exception 
	 * 
	 * @param className class name
	 * @param methodName method name
	 * @param e exception
	 * @return Framework exception
	 * 
	 */
	private Exception createFwException(final String className, final String methodName, final Exception e) {
		final FwException fe = FwExceptionManager.createFwException(className, methodName, e);
		return fe;
	}

	

}
