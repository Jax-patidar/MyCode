package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Key;
/**
 * Crud Interface and/or Repository for APP_RQST.
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

@Repository
public interface CpAppRqstRepository extends CrudRepository<APP_RQST_Cargo,APP_RQST_Key>{
	
	@Query("select c from APP_RQST_Cargo c where c.app_number = ?1")
	public APP_RQST_Collection getByAppNum(Integer appNum); 
	
	@Query("select c from APP_RQST_Cargo c where c.app_number = ?1")
	public APP_RQST_Collection getAllDetails(Integer appNum);

	@Query("select c from APP_RQST_Cargo c where c.app_stat_cd not in ('IP', 'DL') and c.app_number in (?1) and c.appSbmtTms > (current_date - 548) order by appSbmtTms desc")
	public APP_RQST_Collection getAllDetails(Set<Integer> appNum);
	
	
	@Query(value ="select c.hshl_indv_ct from APP_RQST_Cargo c where c.app_number = ?1")
	public List<APP_RQST_Cargo> findHshlIndvCnt(Integer appNum);
	
	@Query(value ="select c.chld_out_home_ct from APP_RQST_Cargo c where c.app_number = ?1")
	public List<APP_RQST_Cargo> findChildOHCnt(Integer appNum);
	
	@Query("select c from APP_RQST_Cargo c where  c.app_number in ?1 and c.app_stat_cd not in ?2")
	public APP_RQST_Cargo[] findByAppNumInAndAppStatCdNot(List<Integer> appNumList, List<String> statCd);

}
