package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * @author ransahu
 *
 */
@Entity
@Table(name = "cp_user_surveys")
@IdClass(CpUserSurveysPrimaryKey.class)
public class CpUserSurveys_Cargo extends AbstractCargo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1257712578195845863L;
	
	@Id
	@Column(name = "app_num")
	private int appNumber;
	
	@Id
	@Column(name = "page_id")
	private String pageId;
	
	@Column(name = "create_user_id")
	private String createUserId;
	
	@Column(name = "create_dt")
	private LocalDateTime createDt;
	
	@Column(name = "sentiment_cd")
	private String sentimentCd;

	public int getAppNumber() {
		return appNumber;
	}

	public void setAppNumber(int appNumber) {
		this.appNumber = appNumber;
	}

	public String getPageId() {
		return pageId;
	}

	public void setPageId(String pageId) {
		this.pageId = pageId;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public LocalDateTime getCreateDt() {
		return createDt;
	}

	public void setCreateDt(LocalDateTime createDt) {
		this.createDt = createDt;
	}

	public String getSentimentCd() {
		return sentimentCd;
	}

	public void setSentimentCd(String sentimentCd) {
		this.sentimentCd = sentimentCd;
	}
	
}
