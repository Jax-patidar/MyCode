package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("MCEMS")
@Scope("prototype")
public class MCEMSResponseWrapper implements LogicResponseInterface{
	private static final String PAGE_ID = "MCEMS";
	private static final String APP_INDV_MEDICARE_PRGM_COLL = "APP_INDV_medicare_Collection";

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map<String,Object> pageCollection = fwTxn.getPageCollection();
		List<APP_INDV_Cargo> appIndvList = new ArrayList<APP_INDV_Cargo>();
		APP_INDV_Cargo cpAppIndvCargo;
		APP_INDV_Collection cpAppIndvCollection = pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) != null ? (APP_INDV_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) : null;
	
		if(cpAppIndvCollection != null && !cpAppIndvCollection.isEmpty() && cpAppIndvCollection.size() >0) {			
			for (int i = 0; i < cpAppIndvCollection.size(); i++) {
				cpAppIndvCargo = (APP_INDV_Cargo) cpAppIndvCollection.get(i);
				appIndvList.add(cpAppIndvCargo);
			}
		}				
		driverPageResponse.getPageCollection().put(APP_INDV_MEDICARE_PRGM_COLL, appIndvList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		
		return driverPageResponse;
	}
}
