package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ARESN")
@Scope("prototype")
public class ARESNViewWrapper implements LogicResponseInterface {

    private static final String PAGE_ID = "ARESN";
    
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

    	DriverPageResponse driverPageResponse = new DriverPageResponse();
    	List<APP_SBMS_Cargo> appSbmsList = new ArrayList<APP_SBMS_Cargo>();
    	APP_SBMS_Cargo appSbmsCargo = new APP_SBMS_Cargo();
        Map<Object,Object> pageCollection = fwTxn.getPageCollection();

        APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get("APP_SBMS_Collection");
        
        
    	if(appSbmsColl != null) {
    		appSbmsCargo = (APP_SBMS_Cargo) appSbmsColl.get(0);
		}
    	appSbmsList.add(appSbmsCargo);
		driverPageResponse.getPageCollection().put("APP_SBMS_Collection", appSbmsList);
			
		
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

        return driverPageResponse;

    }

}
