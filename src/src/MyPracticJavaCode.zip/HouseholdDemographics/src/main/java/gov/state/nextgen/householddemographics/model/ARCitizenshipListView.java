package gov.state.nextgen.householddemographics.model;

import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Collection;

import java.io.Serializable;

public class ARCitizenshipListView implements Serializable {

    private static final long serialVersionUID = 3867322755063080017L;

    private String name = "listView";
    private INDIVIDUAL_Custom_Collection coll = null;
    private INDIVIDUAL_Custom_Cargo cargo = null;
    private APP_INDV_Collection appIndvCollection = null;
    private String listViewName = "HHINFO";
    private String[] values = new String[4];
    private String[] displayColHeader;
    private int[] colWidth;
    private String language = null;

    public INDIVIDUAL_Custom_Collection getColl() {
        return coll;
    }

    public void setColl(INDIVIDUAL_Custom_Collection coll) {
        this.coll = coll;
    }

    public INDIVIDUAL_Custom_Cargo getCargo() {
        return cargo;
    }

    public void setCargo(INDIVIDUAL_Custom_Cargo cargo) {
        this.cargo = cargo;
    }

    public String getListViewName() {
        return listViewName;
    }

    public void setListViewName(String listViewName) {
        this.listViewName = listViewName;
    }

    public String[] getValues() {
        return values;
    }

    public void setValues(String[] values) {
        this.values = values;
    }

    public String[] getDisplayColHeader() {
        return displayColHeader;
    }

    public void setDisplayColHeader(String[] displayColHeader) {
        this.displayColHeader = displayColHeader;
    }

    public int[] getColWidth() {
        return colWidth;
    }

    public void setColWidth(int[] colWidth) {
        this.colWidth = colWidth;
    }

    public APP_INDV_Collection getAppIndvCollection() {
        return appIndvCollection;
    }

    public void setAppIndvCollection(APP_INDV_Collection appIndvCollection) {
        this.appIndvCollection = appIndvCollection;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }
}
