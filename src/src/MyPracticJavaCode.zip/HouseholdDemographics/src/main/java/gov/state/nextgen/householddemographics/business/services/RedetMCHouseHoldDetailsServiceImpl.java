package gov.state.nextgen.householddemographics.business.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_SUPPORT_SERVICES_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.business.rules.ABDisabilityBO;
import gov.state.nextgen.householddemographics.business.rules.ABHouseholdMembersSummaryBO;
import gov.state.nextgen.householddemographics.business.rules.ABProgramInformationBO;
import gov.state.nextgen.householddemographics.business.rules.ABSupportServicesBO;
import gov.state.nextgen.householddemographics.business.rules.AFBHouseholdPregnancyBO;
import gov.state.nextgen.householddemographics.business.rules.AFBSchoolEnrollmentBO;
import gov.state.nextgen.householddemographics.business.rules.AbsentParentBO;
import gov.state.nextgen.householddemographics.business.rules.ContactInformationBO;
import gov.state.nextgen.householddemographics.business.rules.RMBRequestBO;
import gov.state.nextgen.householddemographics.business.rules.RMBRequestDetailBO;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.AppSbmsRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInTaxReturnRepository;
import gov.state.nextgen.householddemographics.data.db2.CpRmbLtcDtlsRepository;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;

/**
 * Redet MC Submit load Household Service
 * 
 * @author Saravanan Balasubramaniam
 *
 */
@Service("RedetMCHouseHoldDetailsService")
public class RedetMCHouseHoldDetailsServiceImpl implements HouseholdDemographicsService {

	@Autowired
	ABHouseholdMembersSummaryBO aBHouseholdMembersSummaryBO;

	@Autowired
	ContactInformationBO contInfoBO;

	@Autowired
	AbsentParentBO absentParentBo;

	@Autowired
	HouseholdRelationshipRepo householdRelationshipRepo;

	@Autowired
	ABProgramInformationBO programInfoBo;

	@Autowired
	AppSbmsRepository appsbms;

	@Autowired
	CpRmbLtcDtlsRepository cpRmbLtcDtlsRepo;

	@Autowired
	CpAppInTaxReturnRepository taxReturnRepo;

	@Autowired
	ABSupportServicesBO supportServicesBO;

	@Autowired
	AFBHouseholdPregnancyBO houseHoldPregnancyBO;

	@Autowired
	ABDisabilityBO disabilityBO;
	
	@Autowired
	AFBSchoolEnrollmentBO afbSchlEnrlmntBO;
	
	@Autowired
    RMBRequestBO rmbRequestBO;
	
	@Autowired
	RMBRequestDetailBO rmbRequestDetailBO;

	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {

		if ("getRedetMCHouseHoldDetails".equals(methodName)) {
			this.getRedetMCHouseHoldDetails(txnBean);
		} else {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "No Service called");
		}
	}

	public void getRedetMCHouseHoldDetails(FwTransaction txBean) {
		final Map<String, Object> pageCollection = txBean.getPageCollection();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedetMCHouseHoldDetailsServiceImpl.getRedetMCHouseHoldDetails() - START", txBean);

		try {
			UserDetails userDetails = txBean.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			
			APP_INDV_Collection coll = aBHouseholdMembersSummaryBO.loadPersonDetailsByAppNum(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, coll);

			CP_APP_RGST_Collection contactCargoColl = contInfoBO.loadCpRgstCollection(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION, contactCargoColl);

			APP_PGM_RQST_Collection pgmColl = absentParentBo.loadProgrammeSelection(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_PGM_RQST_COLLECTION, pgmColl);
			
			RMB_RQST_Collection rmbRqstColl = rmbRequestBO.fetchRMBRqstInfoByAppNum(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION, rmbRqstColl);
			
			if (Objects.nonNull(rmbRqstColl) && !rmbRqstColl.isEmpty()) {
				CpRmbRequestDetails_Collection rmbRqstDetailColl = rmbRequestDetailBO
						.fetchRMBRqstDetailInfo(rmbRqstColl.getCargo(0).getCp_rmb_request_id());
				pageCollection.put(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION, rmbRqstDetailColl);
			}
			
			APP_RQST_Collection appRqstColl = programInfoBo.loadProgramInformation(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, appRqstColl);

			CP_APP_PGM_INDV_Collection appPgmIndvColl = programInfoBo.loadIndvProgrammeSelection(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_PGM_INDV_COLL, appPgmIndvColl);

			CP_APP_HSHL_RLT_Collection appRelationColl = householdRelationshipRepo.getByAppNum(Integer.parseInt(appNumber));
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTIONS, appRelationColl);

			CpRmbLtcDtls_Collection cpRmbLtcDtlsCollection = cpRmbLtcDtlsRepo.getLtcDtlsByAppNum(Integer.parseInt(appNumber));
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_RMBLTCDTLSCOLL, cpRmbLtcDtlsCollection);

			APP_SBMS_Collection sbmsColl = appsbms.findAllByAppNum(Integer.parseInt(appNumber));
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_SBMS_COLLECTION, sbmsColl);

			CP_APP_IN_TAX_RETURN_Collection taxReturnColl = taxReturnRepo.loadTaxtReturninfo(Integer.parseInt(appNumber));
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_RETURN_COLLECTION, taxReturnColl);

			CP_APP_SUPPORT_SERVICES_Collection supportServicesColl = supportServicesBO
					.fetchSupportServicesDetails(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_SUPPORT_SERVICES_COLL, supportServicesColl);

			CP_APP_IN_PREG_Collection appInPregColl = houseHoldPregnancyBO.loadPregDetailsByAppNum(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_PREG_COLLECTION, appInPregColl);

			APP_IN_DABL_Collection appInDablColl = disabilityBO.loadDisabilityDetailsByAppNum(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_DABL_COLL, appInDablColl);
			
			APP_IN_SCHLE_Collection appInSchlColl = afbSchlEnrlmntBO.loadCollegeEnrollmentDetails(appNumber);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION, appInSchlColl);

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in RedetMCHouseHoldDetailsServiceImpl.getRedetMCHouseHoldDetails()", txBean);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_PGM_INDV_COLL, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTIONS, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_RMBLTCDTLSCOLL, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_SBMS_COLLECTION, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_RETURN_COLLECTION, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_SUPPORT_SERVICES_COLL, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_PREG_COLLECTION, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_DABL_COLL, null);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION, null);
			FwExceptionManager.handleException(e, this.getClass().getName(), "getRedetMCHouseHoldDetails",
					txBean.getUserDetails().getAppNumber(), txBean.getUserDetails().getLoginUserId(), true);
		}

		txBean.setPageCollection(pageCollection);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedetMCHouseHoldDetailsServiceImpl.getRedetMCHouseHoldDetails() - END", txBean);
	}

}
