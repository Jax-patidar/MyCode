package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

public class ComponentFlags extends BaseDomainObject implements Serializable {

	private static final long serialVersionUID = -8222849801270324769L;

	private Boolean show344Component;
	private Boolean show5098Component;
	private Boolean show5135Component;
	private Boolean show64Component;
	private Boolean show32Component;
	private Boolean show20084Component;

	private Boolean show20069Component;
	private Boolean show20070Component;
	private Boolean show20071Component;
	private Boolean show20072Component;
	private Boolean show20073Component;
	private Boolean show20074Component;
	
	private Boolean show501Component;
	private Boolean show505Component;
	private Boolean show514Component;
	private Boolean show509Component;
	private Boolean show510Component;
	
	private Boolean show366Component;
	private Boolean show10000Component;
	private Boolean show10003Component;
	private Boolean show10014Component;

	private Boolean show20007Component;
	private Boolean show20008Component;
	private Boolean show20009Component;
	private Boolean show20010Component;
	private Boolean show20011Component;
	private Boolean show20012Component;

	private Boolean show20013Component;
	private Boolean show20015Component;
	private Boolean show20016Component;
	private Boolean show20017Component;
	private Boolean show20018Component;

	private Boolean show20019Component;
	private Boolean show20020Component;
	private Boolean show20021Component;
	private Boolean show20022Component;
	private Boolean show20027Component;
	private Boolean show20028Component;

	private Boolean show20042Component;
	private Boolean show20048Component;
	private Boolean show20061Component;

	private Boolean show377Component;
	
	private Boolean show407Component;
	private Boolean show408Component;
	private Boolean show20032Component;
	
	private Boolean show381Component;
	private Boolean show382Component;
	private Boolean show383Component;
	private Boolean show384Component;
	private Boolean show385Component;
	
	

	public Boolean getShow381Component() {
		return show381Component;
	}

	public void setShow381Component(Boolean show381Component) {
		this.show381Component = show381Component;
	}

	public Boolean getShow382Component() {
		return show382Component;
	}

	public void setShow382Component(Boolean show382Component) {
		this.show382Component = show382Component;
	}

	public Boolean getShow383Component() {
		return show383Component;
	}

	public void setShow383Component(Boolean show383Component) {
		this.show383Component = show383Component;
	}

	public Boolean getShow384Component() {
		return show384Component;
	}

	public void setShow384Component(Boolean show384Component) {
		this.show384Component = show384Component;
	}

	public Boolean getShow385Component() {
		return show385Component;
	}

	public void setShow385Component(Boolean show385Component) {
		this.show385Component = show385Component;
	}

	public Boolean getShow344Component() {
		return show344Component;
	}

	public void setShow344Component(Boolean show344Component) {
		this.show344Component = show344Component;
	}

	public Boolean getShow5098Component() {
		return show5098Component;
	}

	public void setShow5098Component(Boolean show5098Component) {
		this.show5098Component = show5098Component;
	}

	public Boolean getShow5135Component() {
		return show5135Component;
	}

	public void setShow5135Component(Boolean show5135Component) {
		this.show5135Component = show5135Component;
	}

	public Boolean getShow64Component() {
		return show64Component;
	}

	public void setShow64Component(Boolean show64Component) {
		this.show64Component = show64Component;
	}

	public Boolean getShow32Component() {
		return show32Component;
	}

	public void setShow32Component(Boolean show32Component) {
		this.show32Component = show32Component;
	}

	public Boolean getShow20084Component() {
		return show20084Component;
	}

	public void setShow20084Component(Boolean show20084Component) {
		this.show20084Component = show20084Component;
	}

	public Boolean getShow20069Component() {
		return show20069Component;
	}

	public void setShow20069Component(Boolean show20069Component) {
		this.show20069Component = show20069Component;
	}

	public Boolean getShow20070Component() {
		return show20070Component;
	}

	public void setShow20070Component(Boolean show20070Component) {
		this.show20070Component = show20070Component;
	}

	public Boolean getShow20071Component() {
		return show20071Component;
	}

	public void setShow20071Component(Boolean show20071Component) {
		this.show20071Component = show20071Component;
	}

	public Boolean getShow20072Component() {
		return show20072Component;
	}

	public void setShow20072Component(Boolean show20072Component) {
		this.show20072Component = show20072Component;
	}

	public Boolean getShow20073Component() {
		return show20073Component;
	}

	public void setShow20073Component(Boolean show20073Component) {
		this.show20073Component = show20073Component;
	}

	public Boolean getShow20074Component() {
		return show20074Component;
	}

	public void setShow20074Component(Boolean show20074Component) {
		this.show20074Component = show20074Component;
	}

	public Boolean getShow20007Component() {
		return show20007Component;
	}

	public void setShow20007Component(Boolean show20007Component) {
		this.show20007Component = show20007Component;
	}

	public Boolean getShow20008Component() {
		return show20008Component;
	}

	public void setShow20008Component(Boolean show20008Component) {
		this.show20008Component = show20008Component;
	}

	public Boolean getShow20009Component() {
		return show20009Component;
	}

	public void setShow20009Component(Boolean show20009Component) {
		this.show20009Component = show20009Component;
	}

	public Boolean getShow20010Component() {
		return show20010Component;
	}

	public void setShow20010Component(Boolean show20010Component) {
		this.show20010Component = show20010Component;
	}

	public Boolean getShow20011Component() {
		return show20011Component;
	}

	public void setShow20011Component(Boolean show20011Component) {
		this.show20011Component = show20011Component;
	}

	public Boolean getShow20012Component() {
		return show20012Component;
	}

	public void setShow20012Component(Boolean show20012Component) {
		this.show20012Component = show20012Component;
	}

	public Boolean getShow20013Component() {
		return show20013Component;
	}

	public void setShow20013Component(Boolean show20013Component) {
		this.show20013Component = show20013Component;
	}

	public Boolean getShow20015Component() {
		return show20015Component;
	}

	public void setShow20015Component(Boolean show20015Component) {
		this.show20015Component = show20015Component;
	}

	public Boolean getShow20016Component() {
		return show20016Component;
	}

	public void setShow20016Component(Boolean show20016Component) {
		this.show20016Component = show20016Component;
	}

	public Boolean getShow20017Component() {
		return show20017Component;
	}

	public void setShow20017Component(Boolean show20017Component) {
		this.show20017Component = show20017Component;
	}

	public Boolean getShow20018Component() {
		return show20018Component;
	}

	public void setShow20018Component(Boolean show20018Component) {
		this.show20018Component = show20018Component;
	}

	public Boolean getShow20019Component() {
		return show20019Component;
	}

	public void setShow20019Component(Boolean show20019Component) {
		this.show20019Component = show20019Component;
	}

	public Boolean getShow20020Component() {
		return show20020Component;
	}

	public void setShow20020Component(Boolean show20020Component) {
		this.show20020Component = show20020Component;
	}

	public Boolean getShow20021Component() {
		return show20021Component;
	}

	public void setShow20021Component(Boolean show20021Component) {
		this.show20021Component = show20021Component;
	}

	public Boolean getShow20022Component() {
		return show20022Component;
	}

	public void setShow20022Component(Boolean show20022Component) {
		this.show20022Component = show20022Component;
	}

	public Boolean getShow20027Component() {
		return show20027Component;
	}

	public void setShow20027Component(Boolean show20027Component) {
		this.show20027Component = show20027Component;
	}

	public Boolean getShow20028Component() {
		return show20028Component;
	}

	public void setShow20028Component(Boolean show20028Component) {
		this.show20028Component = show20028Component;
	}

	public Boolean getShow20042Component() {
		return show20042Component;
	}

	public void setShow20042Component(Boolean show20042Component) {
		this.show20042Component = show20042Component;
	}

	public Boolean getShow20048Component() {
		return show20048Component;
	}

	public void setShow20048Component(Boolean show20048Component) {
		this.show20048Component = show20048Component;
	}

	public Boolean getShow20061Component() {
		return show20061Component;
	}

	public void setShow20061Component(Boolean show20061Component) {
		this.show20061Component = show20061Component;
	}

	public Boolean getShow377Component() {
		return show377Component;
	}

	public void setShow377Component(Boolean show377Component) {
		this.show377Component = show377Component;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Boolean getShow501Component() {
		return show501Component;
	}

	public void setShow501Component(Boolean show501Component) {
		this.show501Component = show501Component;
	}

	public Boolean getShow505Component() {
		return show505Component;
	}

	public void setShow505Component(Boolean show505Component) {
		this.show505Component = show505Component;
	}

	public Boolean getShow514Component() {
		return show514Component;
	}

	public void setShow514Component(Boolean show514Component) {
		this.show514Component = show514Component;
	}

	public Boolean getShow509Component() {
		return show509Component;
	}

	public void setShow509Component(Boolean show509Component) {
		this.show509Component = show509Component;
	}

	public Boolean getShow510Component() {
		return show510Component;
	}

	public void setShow510Component(Boolean show510Component) {
		this.show510Component = show510Component;
	}

	public Boolean getShow366Component() {
		return show366Component;
	}

	public void setShow366Component(Boolean show366Component) {
		this.show366Component = show366Component;
	}

	public Boolean getShow10000Component() {
		return show10000Component;
	}

	public void setShow10000Component(Boolean show10000Component) {
		this.show10000Component = show10000Component;
	}

	public Boolean getShow10003Component() {
		return show10003Component;
	}

	public void setShow10003Component(Boolean show10003Component) {
		this.show10003Component = show10003Component;
	}

	public Boolean getShow10014Component() {
		return show10014Component;
	}

	public void setShow10014Component(Boolean show10014Component) {
		this.show10014Component = show10014Component;
	}

	public Boolean getShow407Component() {
		return show407Component;
	}

	public void setShow407Component(Boolean show407Component) {
		this.show407Component = show407Component;
	}

	public Boolean getShow408Component() {
		return show408Component;
	}

	public void setShow408Component(Boolean show408Component) {
		this.show408Component = show408Component;
	}

	public Boolean getShow20032Component() {
		return show20032Component;
	}

	public void setShow20032Component(Boolean show20032Component) {
		this.show20032Component = show20032Component;
	}
	
	

}
