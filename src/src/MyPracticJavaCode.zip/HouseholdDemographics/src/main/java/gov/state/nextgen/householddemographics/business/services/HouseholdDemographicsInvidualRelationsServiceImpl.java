package gov.state.nextgen.householddemographics.business.services;

import static gov.state.nextgen.access.management.constants.FwConstants.CURRENT_PAGE_ID;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.SortedSet;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.access.management.util.IndividualAge;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PREG_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.CASE_PROGRAMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CASE_PROGRAMS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_ESGIN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_ESGIN_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.householddemographics.business.entities.NO_ONE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.NO_ONE_Collection;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMC_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMC_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMC_RESPONSE_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMC_RESPONSE_Custom_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMC_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.profilemanagers.CategorySelectionProfileManager;
import gov.state.nextgen.householddemographics.business.profilemanagers.RMCResponseProfileManager;
import gov.state.nextgen.householddemographics.business.rules.ABAbsentParentBO;
import gov.state.nextgen.householddemographics.business.rules.ABHouseHoldMemberBO;
import gov.state.nextgen.householddemographics.business.rules.ABHouseHoldRelationshipBO;
import gov.state.nextgen.householddemographics.business.rules.ABHouseholdMembersSummaryBO;
import gov.state.nextgen.householddemographics.business.rules.ARHouseHoldMemberBO;
import gov.state.nextgen.householddemographics.business.rules.ARHouseholdMembersSummaryBO;
import gov.state.nextgen.householddemographics.business.rules.CaretakerSelectionBO;
import gov.state.nextgen.householddemographics.business.rules.FixMealsPersonSelectionBO;
import gov.state.nextgen.householddemographics.business.rules.HouseHoldInfoBO;
import gov.state.nextgen.householddemographics.business.rules.HouseHoldRelationshipBO;
import gov.state.nextgen.householddemographics.business.rules.LivingArrangementBO;
import gov.state.nextgen.householddemographics.business.rules.MovedInBo;
import gov.state.nextgen.householddemographics.business.rules.OtherHouseholdDetailsBO;
import gov.state.nextgen.householddemographics.business.rules.PeopleHandler;
import gov.state.nextgen.householddemographics.business.rules.PeopleSummaryBO;
import gov.state.nextgen.householddemographics.business.validation.ARMOVValidator;
import gov.state.nextgen.householddemographics.business.validation.MovedOutValidator;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;
import gov.state.nextgen.householddemographics.data.db2.OtherHouseholdDetailsRepo;
import gov.state.nextgen.householddemographics.management.CategorySequenceDetail;
import gov.state.nextgen.householddemographics.management.RMCRequestManager;
import gov.state.nextgen.householddemographics.model.ARCitizenshipListView;
import gov.state.nextgen.householddemographics.model.IndivTypeSeqBean;
import gov.state.nextgen.householddemographics.responsewrappers.HouseholdInfoSummaryView;
import gov.state.nextgen.householddemographics.responsewrappers.HowAreYouRelatedView;
import gov.state.nextgen.householddemographics.utilities.AgeUtil;

/**
 * Household demographics Individual Relationship service.
 * 
 * @author srprasannakumar pageIds - [AFB -> ABDOC,ABHHR,ABAPD ; RMB/RMC -
 *         ARMOV,ARHMO,ARDOC & ARHRL ]
 */
@SuppressWarnings("squid:S2229")
@Service("HouseholdDemographicsInvidualRelationsService")
public class HouseholdDemographicsInvidualRelationsServiceImpl implements HouseholdDemographicsService {

	@Autowired
	protected PeopleHandler peopleHandler;

	@Autowired
	protected RMCResponseProfileManager rmcResponseProfileManager;

	@Autowired
	protected CategorySelectionProfileManager categorySelectionProfileManager;

	@Autowired
	protected LivingArrangementBO livingArrBO;

	@Autowired
	protected ARHouseholdMembersSummaryBO householdMembersSummaryBO;

	@Autowired
	protected ARHouseHoldMemberBO houseHoldMemberBO;

	@Autowired
	protected ABHouseholdMembersSummaryBO afbHouseholdMembersSummaryBO;

	@Autowired
	protected HouseHoldInfoBO houseHoldInfoBO;

	@Autowired
	protected HouseHoldRelationshipBO houseHoldRelationshipBO;

	@Autowired
	protected HowAreYouRelatedView howAreYouRelatedView;

	@Autowired
	protected HouseholdInfoSummaryView houseHoldSummaryView;

	@Autowired
	protected ABHouseHoldMemberBO abHouseHoldMemberBO;

	@Autowired
	protected ABHouseHoldRelationshipBO abHouseHoldRelationshipBO;

	@Autowired
	protected MovedInBo movedInBO;

	@Autowired
	protected FixMealsPersonSelectionBO fixMealsPersonSelectionBO;

	@Autowired
	private PeopleSummaryBO peopleSummaryBO;

	@Autowired
	private CaretakerSelectionBO caretakerSelectionBO;

	@Autowired
	protected IReferenceTableManager referenceTableManager;

	@Autowired
	private ABAbsentParentBO abAbsentParentBo;

	@Autowired
	protected OtherHouseholdDetailsRepo otherHouseholdDetailsRepo;

	@Autowired
	private OtherHouseholdDetailsBO otherHHDetailsBO;
	
	@Autowired
	private HouseholdRelationshipRepo appHshlRltRepository;
	
	@Autowired
    private ExceptionUtil exceptionUtil;

	private static Logger logger = LoggerFactory.getLogger(HouseholdDemographicsInvidualRelationsServiceImpl.class);

	private static final String FALSE = "false";

	private static final String STORE_HOUSEHOLD_REL_DET = "storeHouseHoldRelationshipDetails";

	private static final String CP_APP_HSHL_RLT = "CP_APP_HSHL_RLT_Collection";

	private static final String STORE_CARE_TAKER_PERSON_SELECTION_ERROR = "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.storeCaretakerPersonSelectionDetails()";
	
	private static final String STORE_HOUSEHOLD_RELATIONSHIP_DETAILS = "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldRelationshipDetails()";
	
	private static final String APP_HSHL_RLT_CARETAKER_COLLECTION = "APP_HSHL_RLT_CareTaker_Collection";
	
	/**
	 * Service level beforeCollection to carry data in between load/save calls and
	 * also to fetch initial load data.
	 */

	/**
	 * Invoke corresponding service method.
	 *
	 * @param methodName
	 * @param fwTransaction
	 * @return
	 */
	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTransaction) {
		try {
			switch (methodName) {
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_MOVED_OUT:
				storeMovedOut(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_HOUSEHOLD_MOVED_OUT_DETAILS:
				storeHouseHoldInfoMovedOutDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_MOVE_OUT:
				loadMovedOut(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_HOUSEHOLD_MOVED_OUT_DETAILS:
				loadHouseHoldInfoMovedOutDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_CITIZENSHIP_DECLARATION:
				loadCitizenshipDeclaration(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_CITIZENSHIP_DECLARATION:
				storeCitizenshipDeclaration(fwTransaction);
				loadHouseHoldInfoRelationshipDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_HOUSEHOLD_RELATIONSHIP_INFO:
				loadHouseHoldInfoRelationshipDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_HOUSEHOLD_RELATIONSHIP_INFO:
				storeHouseHoldInfoRelationshipDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_GET_CITIZENSHIP:
				getCitizenship(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_AFB_STORE_CITIZENSHIP:
				storeCitizenship(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_STORE_HOUSEHOLD_RELATIONS:
				storeHouseHoldRelationshipDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_GET_HOUSEHOLD_RELATIONS:
				getHouseHoldRelationshipDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_LOAD_FIX_MEALS_PERSON_SELECTION:
				getFixMealsPersonSelection(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_STORE_FIX_MEALS_PERSON_SELECTION:
				storeFixMealsPersonSelection(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_GET_RELATIONSHIP_AND_BUYPREPAREFOOD_DETAILS:
				getRelationshipandBuyPrepareFoodDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_STORE_RELATIONSHIP_AND_BUYPREPAREFOOD_DETAILS:
				storeRelationshipandBuyPrepareFoodDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_GET_PEOPLE_SUMMARY_DETAILS:
				getPeopleSummaryDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.BUSINESS_METHOD_AFB_STORE_CARETAKER_PERSON_SELECTION_DETAILS:
				storeCaretakerPersonSelectionDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.DEL_PEOPLE_SUMM:
				deletePeopleSummary(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.STORE_DUPLICATE_PROG_PER_SEL_DET:
				storeDuplicateProgramPersonSelectionDetails(fwTransaction);
				break;
			case HouseHoldDemoGraphicsConstants.STORE_TRADE_FOR_GUN_SEL_DET:
				storeTradedForGunsPersonSelectionDetails(fwTransaction);
				break;

			case HouseHoldDemoGraphicsConstants.GETPRPEOPLESUMMARYDETAILS:
				getPRPeopleSummaryDetails(fwTransaction);
				break;			

			default:
				logger.error(" Invalid serviceMethod ");
				break;
			}
		} catch (Exception exception) {
			logger.error("Failure in calling serviceMethod ", exception);
		}
	}

	/*
	 * Store method for CaretakerSelection Screen CSPM-1747
	 */
	@Transactional
	public void storeCaretakerPersonSelectionDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeCaretakerPersonSelectionDetails() - START", fwTxn);
		try {

			String appNumber = null;
			String pageId = null;
			int currentPageStatus = 0;
			Map beforeColl = null;

			CP_APP_HSHL_RLT_Cargo cpAppHshlRltCargo = null;
			Integer indvSeqNum = 0;
			Integer refIndvSeqNum = 0;
			ArrayList<Integer> indvCheckArray;
			appNumber = fwTxn.getUserDetails().getAppNumber();

			beforeColl = fwTxn.getPageCollection();
			OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection;
			OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo = new OTHER_HOUSEHOLD_DETAILS_Cargo();

			if (beforeColl != null && beforeColl.containsKey("caretakerArray")) {

				validateCareTakerColl(appNumber, beforeColl, otherHouseholdDetailsCargo);
			}

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_CARE_TAKER_PERSON_SELECTION_ERROR, fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeCaretakerPersonSelectionDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeCaretakerPersonSelectionDetails() - END", fwTxn);

	}

	private void validateCareTakerColl(String appNumber, Map beforeColl,
			OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.validateCareTakerColl() - START");
		Integer indvSeqNum;
		ArrayList<Integer> indvCheckArray;
		OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection;
		indvCheckArray = (ArrayList<Integer>) beforeColl.get("caretakerArray");
		caretakerSelectionBO.updateCareTakerAsEmptyByAppNum(appNumber);
		for (int i = 0; i < indvCheckArray.size(); i++) {
			String cast = String.valueOf(indvCheckArray.get(i));
			if (!FALSE.equals(cast)) {
				indvSeqNum = Integer.parseInt(cast);
				otherHouseholdDetailsCollection = (OTHER_HOUSEHOLD_DETAILS_Collection) caretakerSelectionBO
						.loadCaretakerExisitingDetail(appNumber, indvSeqNum);
				if (null != otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty()) {
					otherHouseholdDetailsCargo = otherHouseholdDetailsCollection.getCargo(0);
					otherHouseholdDetailsCargo.setCare_taker_resp("Y");

				} else {
					otherHouseholdDetailsCargo.setCare_taker_resp("Y");
					otherHouseholdDetailsCargo.setIndv_seq_num(indvSeqNum);
					otherHouseholdDetailsCargo.setApp_num(appNumber);
				}
				if (null != otherHouseholdDetailsCollection) {
					otherHouseholdDetailsCollection.addCargo(otherHouseholdDetailsCargo);
				}
				if (null != otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty()
						&& Objects.nonNull(otherHouseholdDetailsCollection)
						&& !ArrayUtils.isEmpty(otherHouseholdDetailsCollection.getResults())) {
					caretakerSelectionBO.saveCaretakerPersonDetail(otherHouseholdDetailsCollection);
				}
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.validateCareTakerColl() - END");

		}
	}

	@Transactional
	@SuppressWarnings("squid:S3776")
	public void storeDuplicateProgramPersonSelectionDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeDuplicateProgramPersonSelectionDetails() - START", fwTxn);
		try {

			String appNumber = null;
			String pageId = null;
			int currentPageStatus = 0;
			Map beforeColl = null;
			Integer indvSeqNum = 0;
			Integer refIndvSeqNum = 0;
			ArrayList<Integer> indvCheckArray;
			appNumber = fwTxn.getUserDetails().getAppNumber();

			beforeColl = fwTxn.getPageCollection();
			OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection;
			OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo;

			if (beforeColl != null && beforeColl.containsKey("dup_food_assisstance_array")) {

				indvCheckArray = (ArrayList<Integer>) beforeColl.get("dup_food_assisstance_array");
				for (int i = 0; i < indvCheckArray.size(); i++) {

					otherHouseholdDetailsCargo = new OTHER_HOUSEHOLD_DETAILS_Cargo();
					String cast = String.valueOf(indvCheckArray.get(i));
					if (!FALSE.equals(cast)) {
						indvSeqNum = Integer.parseInt(cast);
						otherHouseholdDetailsCollection = (OTHER_HOUSEHOLD_DETAILS_Collection) caretakerSelectionBO
								.loadCaretakerExisitingDetail(appNumber, indvSeqNum);
						if (null != otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty()) {
							otherHouseholdDetailsCargo = otherHouseholdDetailsCollection.getCargo(0);
							otherHouseholdDetailsCargo.setDup_food_assisstance("Y");
						} else {
							otherHouseholdDetailsCargo.setDup_food_assisstance("Y");
							otherHouseholdDetailsCargo.setIndv_seq_num(indvSeqNum);
							otherHouseholdDetailsCargo.setApp_num(appNumber);
						}
						otherHouseholdDetailsRepo.save(otherHouseholdDetailsCargo);

					}

				}
				
				// If user clicks back button and unselect some indivs, those indvs indicator
				// must be updated to N
				OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsSwitchToNCollection = caretakerSelectionBO.backUnselectIndvChangedToN(
						appNumber, indvCheckArray);
				if (Objects.nonNull(otherHouseholdDetailsSwitchToNCollection)
						&& !otherHouseholdDetailsSwitchToNCollection.isEmpty()) {
					for (int i = 0; i < otherHouseholdDetailsSwitchToNCollection.size(); i++) {
						OTHER_HOUSEHOLD_DETAILS_Cargo cargo = (OTHER_HOUSEHOLD_DETAILS_Cargo) otherHouseholdDetailsSwitchToNCollection
								.get(i);
						cargo.setDup_food_assisstance("N");
					}
					otherHouseholdDetailsRepo.saveAll(otherHouseholdDetailsSwitchToNCollection);
				}
			}

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.storeDuplicateProgramPersonSelectionDetails()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeDuplicateProgramPersonSelectionDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeDuplicateProgramPersonSelectionDetails() - END", fwTxn);

	}

	@Transactional
	public void storeTradedForGunsPersonSelectionDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeTradedForGunsPersonSelectionDetails() - START", fwTxn);
		try {

			String appNumber = null;
			String pageId = null;
			int currentPageStatus = 0;
			Map beforeColl = null;
			Integer indvSeqNum = 0;
			Integer refIndvSeqNum = 0;
			ArrayList<Integer> indvCheckArray;
			appNumber = fwTxn.getUserDetails().getAppNumber();

			beforeColl = fwTxn.getPageCollection();
			OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection;
			OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo;

			if (beforeColl != null && beforeColl.containsKey("cnvctOfTrFsGunRespArray")) {
				validateGunRespColl(appNumber, beforeColl);

			}

		} catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.storeTradedForGunsPersonSelectionDetails()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeTradedForGunsPersonSelectionDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeTradedForGunsPersonSelectionDetails() - END", fwTxn);

	}
	@SuppressWarnings("squid:S3776")
	private void validateGunRespColl(String appNumber, Map beforeColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.validateGunRespColl() - START");
	 try {	
		Integer indvSeqNum;
		ArrayList<Integer> indvCheckArray;
		OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection;
		OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo;
		// to save and update data for Traded for Guns screen

		indvCheckArray = (ArrayList<Integer>) beforeColl.get("cnvctOfTrFsGunRespArray");
		for (int i = 0; i < indvCheckArray.size(); i++) {

			otherHouseholdDetailsCargo = new OTHER_HOUSEHOLD_DETAILS_Cargo();
			String cast = String.valueOf(indvCheckArray.get(i));
			if (!FALSE.equals(cast)) {
				indvSeqNum = Integer.parseInt(cast);
				otherHouseholdDetailsCollection = (OTHER_HOUSEHOLD_DETAILS_Collection) otherHHDetailsBO
						.loadOtherHHDetail(appNumber, indvSeqNum);
				if (null != otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty()) {
					otherHouseholdDetailsCargo = otherHouseholdDetailsCollection.getCargo(0);
					otherHouseholdDetailsCargo.setCnvct_of_tr_fs_gun_resp("Y");

				} else {
					otherHouseholdDetailsCargo.setCnvct_of_tr_fs_gun_resp("Y");
					otherHouseholdDetailsCargo.setIndv_seq_num(indvSeqNum);
					otherHouseholdDetailsCargo.setApp_num(appNumber);
				}
				if (null != otherHouseholdDetailsCollection) {
					otherHouseholdDetailsCollection.addCargo(otherHouseholdDetailsCargo);
				}
				if (null != otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty()
						&& Objects.nonNull(otherHouseholdDetailsCollection)
						&& !ArrayUtils.isEmpty(otherHouseholdDetailsCollection.getResults())) {
					otherHHDetailsBO.saveOtherHHDetail(otherHouseholdDetailsCollection);
				}
			}
		}
	 }catch(Exception e) {
		 FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.validateGunRespColl()");
		 throw e;
	 }
	 FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.validateGunRespColl() - END");
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeRelationshipandBuyPrepareFoodDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeRelationshipandBuyPrepareFoodDetails() - START", fwTxn);

		String appNumber = null;
		String pageId = null;
		int currentPageStatus = 0;
		Map beforeColl = null;
		CP_APP_HSHL_RLT_Collection appHshlRltColl = null;
		CP_APP_HSHL_RLT_Cargo existingdbappHshlRltCargo = null;
		CP_APP_HSHL_RLT_Cargo appHshlRltCargo = new CP_APP_HSHL_RLT_Cargo();
		int indvSeqNumber = 1;
		Integer srcSeqNum = 1;
		Integer refSeqNum = null;
		boolean isSameCargo = false;
		Map pageCollection = fwTxn.getPageCollection();
		try {
			appNumber = fwTxn.getUserDetails().getAppNumber();
			indvSeqNumber = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			pageId = fwTxn.getCurrentActionDetails().getPageId();
			beforeColl = fwTxn.getPageCollection();

			// Getting the collection from fwtxn to appHshlRltColl
			if (beforeColl != null && (beforeColl.containsKey(CP_APP_HSHL_RLT))) {
				appHshlRltColl = (CP_APP_HSHL_RLT_Collection) beforeColl.get(CP_APP_HSHL_RLT);
			}
			// Getting cargo
			if (null != appHshlRltColl && !appHshlRltColl.isEmpty()) {
				appHshlRltCargo = appHshlRltColl.getCargo(0);
			}
			appHshlRltCargo.setSrcIndvSeqNum(srcSeqNum);
			appHshlRltCargo.setRefIndvSeqNum(indvSeqNumber);

			String buyprepare = null;
			// if Phy_boe_sep_sw from request is null, setting it to ""
			if (pageId.equals("ABBPF")) {
				if (appHshlRltCargo.getPhy_boe_sep_sw() == null
						|| FwConstants.EMPTY_STRING.equalsIgnoreCase(appHshlRltCargo.getPhy_boe_sep_sw().trim())) {

					appHshlRltCargo.setPhy_boe_sep_sw(FwConstants.SPACE);

				}

				appHshlRltCargo.setRec_cplt_ind(Integer.parseInt(FwConstants.ONE));
				if (Objects.nonNull(appHshlRltCargo.getChg_eff_dt())) {
					appHshlRltCargo.setChange_dt(null);
				}
			}
			appHshlRltCargo.setSrcAppIndiv(AppConstants.SRC_APP_IND_AFB);
			appHshlRltCargo.setApp_num(appNumber);
			if (appHshlRltColl != null) {
				appHshlRltColl.addCargo(appHshlRltCargo);
			}

			if (Objects.nonNull(appHshlRltColl) && !ArrayUtils.isEmpty(appHshlRltColl.getResults())) {
				// now we need to persist the collection
				List<CP_APP_HSHL_RLT_Cargo> list = appHshlRltRepository.findByAppNumSrcRefIndvSeqNum(
						Integer.parseInt(appNumber), srcSeqNum,indvSeqNumber);
					if (null != list && !list.isEmpty()) {
						CP_APP_HSHL_RLT_Cargo dBHshlcargo = list.get(0);
							dBHshlcargo.setPhy_boe_sep_sw(appHshlRltCargo.getPhy_boe_sep_sw());
							dBHshlcargo.setRltCd(appHshlRltCargo.getRltCd());	
							appHshlRltRepository.save(dBHshlcargo);
				}else {
					abHouseHoldRelationshipBO.saveRelationshipandBuyPrepareNewDetails(appHshlRltColl);
				}

			}

		} catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.storeRelationshipandBuyPrepareFoodDetails()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeRelationshipandBuyPrepareFoodDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeRelationshipandBuyPrepareFoodDetails() - END", fwTxn);

	}

	/*
	 * Load method for People Summary Screen
	 */
	@Transactional
	public void getPeopleSummaryDetails(FwTransaction FwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsIndividualRelationsService.getPeopleSummaryDetails() - START", FwTxn);
		try {

			Map pageCollection;

			String appNum = FwTxn.getUserDetails().getAppNumber();

			pageCollection = new HashMap();
			APP_INDV_Collection cpAppIndvColl;
			CP_APP_HSHL_RLT_Collection cpAppHshlRltColl;
			cpAppIndvColl = peopleSummaryBO.loadCpAppIndvDetails(appNum);
			cpAppHshlRltColl = peopleSummaryBO.loadCpAppHshlRltDetails(appNum);

			CP_APP_HSHL_RLT_Collection newColl = new CP_APP_HSHL_RLT_Collection();
			CP_APP_HSHL_RLT_Cargo cpAppHshlCargo;
			for (int size = 0; size < cpAppHshlRltColl.size(); size++) {
				// get last cargo from session
				cpAppHshlCargo = cpAppHshlRltColl.getCargo(size);
				validatePeopleSummDet(cpAppHshlCargo);
				validatePeopleSummaryDet(cpAppHshlCargo);
				newColl.addCargo(cpAppHshlCargo);
			}
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION_VALUE, cpAppIndvColl);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION, newColl);
			FwTxn.setPageCollection(pageCollection);
		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.getPeopleSummaryDetails()", FwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getPeopleSummaryDetails", FwTxn.getUserDetails().getAppNumber(),
        			FwTxn.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsIndividualRelationsService.getPeopleSummaryDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + "milliseconds", FwTxn);
	}



	
	public void getPRPeopleSummaryDetails(FwTransaction FwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getPRPeopleSummaryDetails() - START", FwTxn);
		try {
			final Map request = FwTxn.getRequest();
			Map pageCollection = FwTxn.getPageCollection();
			
			String appNum = FwTxn.getUserDetails().getAppNumber();
			//String src_app_ind = "AB";
			pageCollection = new HashMap();
			APP_INDV_Collection cpAppIndvColl = new APP_INDV_Collection();
			cpAppIndvColl = peopleSummaryBO.loadCpAppIndvDetails(appNum);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, cpAppIndvColl);
			FwTxn.setPageCollection(pageCollection);
		}catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.getPRPeopleSummaryDetails()", FwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getPRPeopleSummaryDetails", FwTxn.getUserDetails().getAppNumber(),
        			FwTxn.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getPRPeopleSummaryDetails() - END", FwTxn);
	}
	


	private void validatePeopleSummaryDet(CP_APP_HSHL_RLT_Cargo cpAppHshlCargo) {
		if (cpAppHshlCargo.getRltCd().equals("NE")) {
			cpAppHshlCargo.setRltCd("Nephew");
		}
		if (cpAppHshlCargo.getRltCd().equals("NI")) {
			cpAppHshlCargo.setRltCd("Neice");
		}
		if (cpAppHshlCargo.getRltCd().equals("OT")) {
			cpAppHshlCargo.setRltCd("Other relative");
		}
		if (cpAppHshlCargo.getRltCd().equals("SB")) {
			cpAppHshlCargo.setRltCd("Step Brother");
		}
		if (cpAppHshlCargo.getRltCd().equals("SF")) {
			cpAppHshlCargo.setRltCd("Step Father");
		}
		if (cpAppHshlCargo.getRltCd().equals("SD")) {
			cpAppHshlCargo.setRltCd("Step Daughter");
		}
		if (cpAppHshlCargo.getRltCd().equals("SM")) {
			cpAppHshlCargo.setRltCd("Step Mother");
		}
		if (cpAppHshlCargo.getRltCd().equals("SI")) {
			cpAppHshlCargo.setRltCd("Sister");
		}
		if (cpAppHshlCargo.getRltCd().equals("SO")) {
			cpAppHshlCargo.setRltCd("Son");
		}
		if (cpAppHshlCargo.getRltCd().equals("SS")) {
			cpAppHshlCargo.setRltCd("Step Son");
		}
		if (cpAppHshlCargo.getRltCd().equals("ST")) {
			cpAppHshlCargo.setRltCd("Step Sister");
		}
		if (cpAppHshlCargo.getRltCd().equals("UN")) {
			cpAppHshlCargo.setRltCd("Uncle");
		}
		if (cpAppHshlCargo.getRltCd().equals("UR")) {
			cpAppHshlCargo.setRltCd("Unrelated");
		}
		if (cpAppHshlCargo.getRltCd().equals("WI")) {
			cpAppHshlCargo.setRltCd("Wife");
		}
	}

	private void validatePeopleSummDet(CP_APP_HSHL_RLT_Cargo cpAppHshlCargo) {
		if (cpAppHshlCargo.getRltCd().equals("AU")) {
			cpAppHshlCargo.setRltCd("Aunt");
		}
		if (cpAppHshlCargo.getRltCd().equals("BR")) {
			cpAppHshlCargo.setRltCd("Brother");
		}
		if (cpAppHshlCargo.getRltCd().equals("CO")) {
			cpAppHshlCargo.setRltCd("Cousin");
		}
		if (cpAppHshlCargo.getRltCd().equals("DA")) {
			cpAppHshlCargo.setRltCd("Daughter");
		}
		if (cpAppHshlCargo.getRltCd().equals("FA")) {
			cpAppHshlCargo.setRltCd("Father");
		}
		if (cpAppHshlCargo.getRltCd().equals("GD")) {
			cpAppHshlCargo.setRltCd("Graddaughter");
		}
		if (cpAppHshlCargo.getRltCd().equals("GS")) {
			cpAppHshlCargo.setRltCd("Grandson");
		}
		if (cpAppHshlCargo.getRltCd().equals("GF")) {
			cpAppHshlCargo.setRltCd("Grandfather");
		}
		if (cpAppHshlCargo.getRltCd().equals("GM")) {
			cpAppHshlCargo.setRltCd("Grandmother");
		}
		if (cpAppHshlCargo.getRltCd().equals("HU")) {
			cpAppHshlCargo.setRltCd("Husband");
		}
		if (cpAppHshlCargo.getRltCd().equals("MO")) {
			cpAppHshlCargo.setRltCd("Mother");
		}
	}

	 

	/**
	 * Store House hold info moved out details - ARHMO.
	 *
	 * @param fwTransaction
	 * @throws Exception
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeHouseHoldInfoMovedOutDetails(FwTransaction fwTransaction) throws Exception {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldInfoMovedOutDetails() - START", fwTransaction);
		try {

			initializeHouseHoldInfoMovedOutDetails(fwTransaction);

			Map<Object, Object> request = fwTransaction.getRequest();
			Map<Object, Object> pageCollection = fwTransaction.getPageCollection();
			String currentPageID = (String) request.get(FwConstants.CURRENT_PAGE_ID);

			String appNum = (String) request.get(HouseHoldDemoGraphicsConstants.UI_APP_NUM);
			LivingArrangementBO livingArrBo = new LivingArrangementBO();

			SortedSet categorySelectionProfile = categorySelectionProfileManager
					.loadCategoryChangeSelectionProfile(appNum);

			Map<Object, Object> beforeColl = fwTransaction.getPageCollection(); // TODO: DEV_NOTE: Previous it used to
																				// get picked from session. Will
																				// refactor it.
			SortedSet leftTheHomeProfile = (SortedSet) beforeColl.get(AppConstants.RMC_CATEGORY_PAGE_PRFL);

			RMC_IN_PRFL_Collection appInPrflColl = rmcResponseProfileManager
					.loadProfile((String) fwTransaction.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM));

			APP_INDV_Collection beforeCollIndvLiveChgColl = (APP_INDV_Collection) beforeColl.get("APP_INDV_Collection");

			APP_INDV_Collection appIndvCollection = (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection");

			APP_INDV_Cargo appIndvCargo = appIndvCollection.getCargo(0);

			Map categoryTypes = new HashMap();
			CategorySequenceDetail categorySeqDetailBean = categorySelectionProfileManager
					.getCurrentSequenceDetail(leftTheHomeProfile);
			long catSeqNum = categorySeqDetailBean.getCategorySequence();
			String catType = categorySeqDetailBean.getCategoryType();
			short indvSeqNum = categorySeqDetailBean.getIndividualSequence();
			boolean valInd = false;

			appIndvCargo.setIndv_seq_num(Integer.valueOf(categorySeqDetailBean.getIndividualSequence()));

			categoryTypes.put("CATEGOTY_TYPE", catType);
			final String firstName = (String) beforeColl.get(AppConstants.FIRST_NAME);

			final String birDate = (String) beforeColl.get(AppConstants.BIRTH_DATE);

			// Validation of UI data - validationMessages will be added in request of
			// transaction object.
			if (!isValidHouseholdMovedOutDetails(fwTransaction, appIndvCargo, catType, firstName, birDate,
					beforeColl)) {
				return;
			}

			APP_INDV_Cargo indvLiveBeforeCargo = null;
			if (Objects.nonNull(beforeCollIndvLiveChgColl)
					&& ArrayUtils.isNotEmpty(beforeCollIndvLiveChgColl.getResults())) {
				for (APP_INDV_Cargo app_indv_cargo : beforeCollIndvLiveChgColl.getResults()) {
					String livArrngmnt = app_indv_cargo.getLive_arng_typ();
					if (appIndvCargo.getIndv_seq_num().equals(app_indv_cargo.getIndv_seq_num())) {
						if (StringUtils.isNotBlank(livArrngmnt)) {
							if (AppConstants.SOMEONE_DIED.equals(catType)
									&& AppConstants.SOMEONE_DIED.equals(livArrngmnt)) {
								indvLiveBeforeCargo = appIndvCargo;
								break;
							}
							if (AppConstants.LEFT_THE_HOME.equals(catType)
									&& !AppConstants.SOMEONE_DIED.equals(livArrngmnt)
									&& !AppConstants.DIVORCE_INDICATOR.equals(livArrngmnt)
									&& !AppConstants.MARRIAGE_INDICATOR.equals(livArrngmnt)) {
								indvLiveBeforeCargo = appIndvCargo;
								break;
							}
						}
					}
				}
			}

			if (AppConstants.LEFT_THE_HOME.equals(catType)) {

				APP_INDV_Collection indvUpdtColl = new APP_INDV_Collection();
				APP_INDV_Cargo indvCargo = new APP_INDV_Cargo();
				if (indvLiveBeforeCargo != null
						&& AppConstants.RMC_END_RECORD_IND.equalsIgnoreCase(indvLiveBeforeCargo.getSrc_app_ind())) {
					indvCargo = (APP_INDV_Cargo) indvLiveBeforeCargo.clone();
					indvCargo.setSrc_app_ind(AppConstants.RMC_END_RECORD_IND);
					indvCargo.setLeft_home_reason_cd(appIndvCargo.getLeft_home_reason_cd());
					if (Objects.nonNull(appIndvCargo) && Objects.nonNull(appIndvCargo.getLeft_home_dt())) {
						indvCargo.setLeft_home_dt(appIndvCargo.getLeft_home_dt());
						indvCargo.setChg_dt(new java.sql.Date(new Date().getTime()));
					} else {
						indvCargo.setLeft_home_dt(null);
					}
					indvCargo.setEntry_into_us_dt(null);
					indvUpdtColl.addCargo(indvCargo);
					livingArrBo.storeLivingArrangementDetails(indvUpdtColl);
				} else {
					if (indvLiveBeforeCargo != null) {
						indvCargo = (APP_INDV_Cargo) indvLiveBeforeCargo.clone();
						indvCargo.setLeft_home_reason_cd(appIndvCargo.getLeft_home_reason_cd());
						if (Objects.nonNull(appIndvCargo) && Objects.nonNull(appIndvCargo.getLeft_home_dt())) {
							indvCargo.setLeft_home_dt(appIndvCargo.getLeft_home_dt());
							indvCargo.setChg_dt(new java.sql.Date(new Date().getTime()));
						} else {
							indvCargo.setLeft_home_dt(null);
						}
						indvCargo.setEntry_into_us_dt(null);
						indvCargo.setSrc_app_ind(AppConstants.RMC_END_RECORD_IND);
						indvUpdtColl.addCargo(indvCargo);

						livingArrBo.storeLivingArrangementDetails(indvUpdtColl);
					}
				}
				categorySelectionProfileManager.updateSequence(leftTheHomeProfile, null,
						categorySeqDetailBean.getIndividualSequence(), catSeqNum,
						categorySeqDetailBean.getCategoryType());
			}

			boolean reqInd = false;
			short respTyp = HouseHoldDemoGraphicsConstants.MOVED_OUT_OF_HOME_RESP;
			if (appInPrflColl != null) {
				RMC_IN_PRFL_Cargo rmcResCargo = rmcResponseProfileManager.getProfile(appInPrflColl,
						String.valueOf(indvSeqNum));
				if (rmcResCargo != null && rmcResponseProfileManager.getProfileResponse(rmcResCargo, respTyp)
						.charAt(0) == HouseHoldDemoGraphicsConstants.STATUS_REQUIRED) {
					reqInd = true;
					rmcResponseProfileManager.makeComplete(HouseHoldDemoGraphicsConstants.MOVED_OUT_OF_HOME_RESP,
							rmcResCargo, true);
				}
			}

			peopleHandler.getHouseholdIndividuals(appNum);
			if (indvSeqNum > 0
					&& (AppConstants.LEFT_THE_HOME.equals(catType) || AppConstants.SOMEONE_DIED.equals(catType))) {
				peopleHandler.deleteOutOfHomeIndividual(indvSeqNum);
			}
			// Mark complete job sequence using common methods
			categorySelectionProfileManager.makeSequenceDetailComplete(categorySelectionProfile, appNum,
					categorySeqDetailBean.getIndividualSequence(), categorySeqDetailBean.getCategorySequence(),
					categorySeqDetailBean.getCategoryType());
			// if the profile response was not 'R' or if we came from gatepost then don't
			// persist else persist
			if (!reqInd || categorySeqDetailBean.getChangeSelectionCategoryCd() == null) {
				categorySelectionProfileManager.makeSequenceDetailComplete(leftTheHomeProfile, null,
						categorySeqDetailBean.getIndividualSequence(), categorySeqDetailBean.getCategorySequence(),
						categorySeqDetailBean.getCategoryType());
			} else {
				categorySelectionProfileManager.makeSequenceDetailComplete(leftTheHomeProfile, appNum,
						categorySeqDetailBean.getIndividualSequence(), categorySeqDetailBean.getCategorySequence(),
						categorySeqDetailBean.getCategoryType());
			}
			if (categorySelectionProfileManager.areAllSequencesComplete(leftTheHomeProfile)) {
				INDIVIDUAL_Custom_Collection indvColl = peopleHandler.getInHomeIndividuals(appNum);
				List pinNumList = new ArrayList();
				int indvCollSize = indvColl.size();
				INDIVIDUAL_Custom_Cargo indivCustCargo = null;
				String pinNumber = null;
				for (int i = 0; i < indvCollSize; i++) {
					indivCustCargo = indvColl.getResult(i);
					pinNumber = indivCustCargo.getIndv_pin_num();
					if (pinNumber != null) {
						pinNumList.add(indivCustCargo.getIndv_pin_num());
					}
				}
				final short[] programKey = getRMCProgramKeys();
				boolean scheduleARXHU = false;
				if (programKey[FwConstants.FSRR_INDEX] == 1 || programKey[FwConstants.EBDMA_INDEX] == 1) {
					scheduleARXHU = true;
				}
				if (pinNumList != null && !pinNumList.isEmpty() && scheduleARXHU) {
					String[] pageId = { "ARXHU" };
				}
			} else {
				categorySelectionProfileManager.getNextSequenceDetail(leftTheHomeProfile);
			}

		} catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldInfoMovedOutDetails()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeHouseHoldInfoMovedOutDetails", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldInfoMovedOutDetails() - START", fwTransaction);

	}

	private void initializeHouseHoldInfoMovedOutDetails(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.initializeHouseHoldInfoMovedOutDetails() - START", fwTransaction);
		SortedSet leftHomeProfile = null;
		String currentPageID = (String) fwTransaction.getRequest().get(FwConstants.CURRENT_PAGE_ID);
		String[] catType = new String[] { AppConstants.LEFT_THE_HOME, AppConstants.SOMEONE_DIED };
		String appNum = (String) fwTransaction.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM);

		SortedSet categorySelectionProfile = categorySelectionProfileManager.loadCategoryChangeSelectionProfile(
				(String) fwTransaction.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM));
		leftHomeProfile = categorySelectionProfileManager.createPageProfile(categorySelectionProfile, catType);
		updateLefHomeProfileBasedOnDriverFlow(fwTransaction, leftHomeProfile);

		CategorySequenceDetail categorySeqDetail = categorySelectionProfileManager
				.getCurrentSequenceDetail(leftHomeProfile);
		if (categorySeqDetail == null) {
			categorySeqDetail = categorySelectionProfileManager.getNextSequenceDetail(leftHomeProfile);
		}
		final String categoryType = categorySeqDetail.getCategoryType();
		Long.toString(categorySeqDetail.getCategorySequence());
		final String indvSeqNum = Short.toString(categorySeqDetail.getIndividualSequence());

		APP_INDV_Collection indvLiveChgColl = new APP_INDV_Collection();
		final APP_INDV_Cargo indvLiveChgCargo = new APP_INDV_Cargo();

		int pageStatus = 1;

		indvLiveChgColl = livingArrBO.loadIndvLivingArrangementDetails(appNum, indvSeqNum);

		// EDSP

		// EDSP
		if (indvLiveChgColl != null && !indvLiveChgColl.isEmpty() && (pageStatus == FwConstants.DRIVER_VISIT_AGAIN
				|| pageStatus == FwConstants.DRIVER_COMPLETE || pageStatus == FwConstants.DRIVER_REQUIRED)) {
			indvLiveChgColl.size();
			final APP_INDV_Collection indvLiveNewColl = new APP_INDV_Collection();
			APP_INDV_Cargo indvLiveCargo = splitIndvColl(indvLiveChgColl, AppConstants.RMC_END_RECORD_IND);
			if (indvLiveCargo != null) {
				// Setting the UI data to cargo
				indvLiveNewColl.add(indvLiveCargo);
			} else {
				indvLiveCargo = splitIndvColl(indvLiveChgColl, AppConstants.CWW_RECORD_IND);
				indvLiveNewColl.add(indvLiveCargo);
			}
			indvLiveChgColl = indvLiveNewColl;
		}
		fwTransaction.getPageCollection().put("APP_INDV_Collection", indvLiveChgColl);
		fwTransaction.getPageCollection().put("PAGE_STATUS", String.valueOf(pageStatus));
		fwTransaction.getPageCollection().put("CATEGORY_TYPE", categoryType);

		peopleHandler.getHouseholdIndividuals(appNum);

		fwTransaction.getPageCollection().put(AppConstants.FIRST_NAME, peopleHandler.getFirstName(indvSeqNum, appNum));
		fwTransaction.getPageCollection().put(AppConstants.BIRTH_DATE, peopleHandler.getBirthDt(indvSeqNum, appNum));
		fwTransaction.getPageCollection().put("INDV_SEQ_NUM", indvSeqNum);
		fwTransaction.getPageCollection().put(AppConstants.RMC_CATEGORY_PAGE_PRFL, leftHomeProfile);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.initializeHouseHoldInfoMovedOutDetails() - END", fwTransaction);
	}

	APP_INDV_Cargo splitIndvColl(final APP_INDV_Collection indvColl, final String recordIndicator) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.splitIndvColl() - START");
		try {
			if (indvColl != null && !indvColl.isEmpty()) {
				final int indvCollSize = indvColl.size();
				APP_INDV_Cargo indvCargo = null;
				for (int i = 0; i < indvCollSize; i++) {
					indvCargo = indvColl.getCargo(i);
					if (indvCargo.getSrc_app_ind().equals(recordIndicator)) {
						return indvColl.getCargo(i);
					}
				}

			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.splitIndvColl() - END");
			return null;
		} catch (final Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.splitIndvColl()");
			throw exception;
		}
		
	}

	@Transactional
	public void loadHouseHoldInfoMovedOutDetails(final FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadHouseHoldInfoMovedOutDetails() - START", fwTransaction);
		try {
		initializeHouseHoldInfoMovedOutDetails(fwTransaction);
		}catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.loadHouseHoldInfoMovedOutDetails()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadHouseHoldInfoMovedOutDetails", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadHouseHoldInfoMovedOutDetails() - END", fwTransaction);
	}

	private short[] getRMCProgramKeys() {
		return new short[5];
	}

	private void updateLefHomeProfileBasedOnDriverFlow(FwTransaction fwTransaction, SortedSet leftHomeProfile) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadHouseHoldInfoMovedOutDetails() - END", fwTransaction);
	}

	private boolean isValidHouseholdMovedOutDetails(FwTransaction fwTransaction, APP_INDV_Cargo appIndvCargo,
			String catType, String firstName, String birDate, Map<Object, Object> beforeColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.isValidHouseholdMovedOutDetails() - START", fwTransaction);
	try {	
		final String backToMyAccess = (String) fwTransaction.getRequest().get(AppConstants.BACK_TO_MY_ACCESS_BUTTON);
		MovedOutValidator arhmoVal = new MovedOutValidator();
		if (backToMyAccess == null) {
			arhmoVal.validateARHMO(appIndvCargo, catType, firstName, birDate);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.isValidHouseholdMovedOutDetails() - END", fwTransaction);
		return true;
	}catch(Exception e) {
		FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.isValidHouseholdMovedOutDetails()", fwTransaction);
		throw e;
	}
	}

	/**
	 * Store the moved out screen details pageId: ARMOV, pageAction: ARMOVNext
	 *
	 * @param fwTransaction
	 * @throws Exception
	 */
	@Transactional
	public void storeMovedOut(FwTransaction fwTransaction){
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeMovedOut() - START", fwTransaction);
		try {
		// Initializes all service related properties
		initializeServiceProperties(fwTransaction);

		int driverStatus = 4;

		/**
		 * Collection Objects prepared from pageCollection of UI.
		 */
		Map<Object, Object> pageCollection = fwTransaction.getPageCollection();
		Map<Object, Object> beforeColl = fwTransaction.getPageCollection(); // TODO: DEV_NOTE: Previous it used to get
																			// picked from session. Will refactor it.
		String appNum = (String) fwTransaction.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM);

		Map<Object, Object> noOneCheckedMap = (Map) pageCollection.get(AppConstants.NO_ONE_CHECKED_MAP);
		NO_ONE_Collection noOneCollection = (NO_ONE_Collection) pageCollection
				.get(HouseHoldDemoGraphicsConstants.NO_ONE_COLLECTION);

		// TODO: CalSAWS – Service Migration: Commenting out profiler code for
		// <Household-storeMovedOut> Profile collection master.
		final RMC_IN_PRFL_Collection rmcInPrflSessColl = (RMC_IN_PRFL_Collection) pageCollection
				.get(AppConstants.RMC_IN_PRFL_MASTER);
		RMC_IN_PRFL_Collection rmcInPrflPageColl = (RMC_IN_PRFL_Collection) pageCollection
				.get(HouseHoldDemoGraphicsConstants.RMC_IN_PRFL_COLLECTION);

		final int numofPplInHome = peopleHandler.getNumberOfIndividuals(peopleHandler.getHouseholdIndividuals(appNum));
		final RMC_RQST_Cargo rmcRqstCargo = populateRmcRequestCargo(fwTransaction);

		final boolean movedInFlag = rmcRqstCargo == null
				|| FwConstants.NO.equalsIgnoreCase(rmcRqstCargo.getPrsn_add_stat_sw()) ? false : true;

		if (Objects.nonNull(rmcInPrflPageColl) && !ArrayUtils.isNotEmpty(rmcInPrflPageColl.getResults())) {
			Arrays.asList(rmcInPrflPageColl.getResults()).stream().forEach(cargo -> {
				if (cargo.getMoved_out_of_home_resp() == null) {
					cargo.setMoved_out_of_home_resp(FwConstants.NO);
				}
			});
		}
		/**
		 * If the populated data is NOT valid and has validation messages in it.
		 */
		if (!isValidMovedOutDetailsRequestData(rmcInPrflPageColl, noOneCollection, noOneCheckedMap, numofPplInHome,
				movedInFlag, fwTransaction)) {
			addMovedOutValidationMessages(driverStatus, pageCollection, beforeColl, noOneCheckedMap, noOneCollection,
					rmcInPrflSessColl, rmcInPrflPageColl, appNum);
			fwTransaction.setRequest(fwTransaction.getRequest());
			fwTransaction.setPageCollection(pageCollection);
			return;
		}

		String[] indivResponseArrayForIndv = null;
		Map indivResponseMapForIndv = new HashMap();

		/**
		 * Populating response from the processed data above.
		 */
		RMC_RESPONSE_Custom_Collection rmcRespCustomColl = new RMC_RESPONSE_Custom_Collection();

		validateRmcPrflSessColl(driverStatus, appNum, rmcInPrflSessColl, rmcInPrflPageColl, indivResponseMapForIndv,
				rmcRespCustomColl);
		}catch(Exception exception) { FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.storeMovedOut()", fwTransaction);
			
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeMovedOut", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeMovedOut() - END", fwTransaction);
	}

	private void validateRmcPrflSessColl(int driverStatus, String appNum,
			final RMC_IN_PRFL_Collection rmcInPrflSessColl, RMC_IN_PRFL_Collection rmcInPrflPageColl,
			Map indivResponseMapForIndv, RMC_RESPONSE_Custom_Collection rmcRespCustomColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.validateRmcPrflSessColl() - START");
	 try {	
		String[] indivResponseArrayForIndv;
		for (int i = 0; i < rmcInPrflSessColl.size(); i++) {
			final RMC_IN_PRFL_Cargo sessionCargo = rmcInPrflSessColl.getCargo(i);
			for (int j = 0; j < rmcInPrflPageColl.size(); j++) {
				final RMC_IN_PRFL_Cargo pageCargo = rmcInPrflPageColl.getCargo(j);
				if (sessionCargo.getIndv_seq_num().equals(pageCargo.getIndv_seq_num())) {

					if (!sessionCargo.getMoved_out_of_home_resp()
							.equalsIgnoreCase(String.valueOf(HouseHoldDemoGraphicsConstants.STATUS_COMPLETE))) {
						// TODO: CalSAWS – Service Migration: Commenting out profiler code for
						// <Household-storeMovedOut> Driver service
						// Below block has statements which use makeDriverRequired methods.
						rmcResponseProfileManager.translateProfileResponses(pageCargo.getMoved_out_of_home_resp(),
								sessionCargo.getMoved_out_of_home_resp(), driverStatus,
								HouseHoldDemoGraphicsConstants.MOVED_OUT_OF_HOME_RESP, sessionCargo);

						RMC_RESPONSE_Custom_Cargo rmcRespCustomCargo = new RMC_RESPONSE_Custom_Cargo();
						rmcRespCustomCargo.setIndvSeqNum(sessionCargo.getIndv_seq_num());
						rmcRespCustomCargo.setCategoryType(AppConstants.LEFT_THE_HOME);
						rmcRespCustomCargo.setSeqNum(String.valueOf(i));
						rmcRespCustomCargo.setChangeSelectionCategoryCd(AppConstants.LEFT_THE_HOME);
						rmcRespCustomColl.addCargo(rmcRespCustomCargo);
					}

					indivResponseArrayForIndv = new String[1];
					indivResponseArrayForIndv[0] = sessionCargo.getMoved_out_of_home_resp();
					indivResponseMapForIndv.put(sessionCargo.getIndv_seq_num(), indivResponseArrayForIndv);
				}
			}
		}
		}catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.validateRmcPrflSessColl()");
			throw e;
	 }
	
		for (int i = 0; i < rmcInPrflSessColl.size(); i++) {
			final RMC_IN_PRFL_Cargo sessionCargo = rmcInPrflSessColl.getCargo(i);

			if (indivResponseMapForIndv.containsKey(sessionCargo.getIndv_seq_num())) {
				rmcResponseProfileManager.persistMovedOutDetails(appNum, sessionCargo.getIndv_seq_num(),
						HouseHoldDemoGraphicsConstants.MOVED_OUT_OF_HOME_RESP_VALUE,
						(String[]) indivResponseMapForIndv.get(sessionCargo.getIndv_seq_num()));
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeMovedOut() - END");
	}

	private void addMovedOutValidationMessages(int driverStatus, Map<Object, Object> pageCollection,
			Map<Object, Object> beforeColl, Map<Object, Object> noOneCheckedMap, NO_ONE_Collection noOneCollection,
			RMC_IN_PRFL_Collection rmcInPrflSessColl, RMC_IN_PRFL_Collection rmcInPrflPageColl, String appNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.addMovedOutValidationMessages() - START");
		for (int i = 0; i < rmcInPrflSessColl.size(); i++) {
			final RMC_IN_PRFL_Cargo sessionCargo = rmcInPrflSessColl.getCargo(i);
			final RMC_IN_PRFL_Cargo pageCollCargo = rmcResponseProfileManager.getProfile(rmcInPrflPageColl,
					sessionCargo.getIndv_seq_num());
			if (pageCollCargo == null) {
				sessionCargo.setMoved_out_of_home_resp(FwConstants.NO);
			} else {
				sessionCargo.setMoved_out_of_home_resp(pageCollCargo.getMoved_out_of_home_resp());
			}
		}
		createAndLoadARMOVResponseMapsToPageCollection(rmcInPrflSessColl, pageCollection, peopleHandler, true,
				driverStatus, appNum);
		if (noOneCollection != null && !noOneCollection.isEmpty()) {
			noOneCheckedMap.put(AppConstants.NO_ONE_CHECKED + "20055", FwConstants.YES);
		} else {
			noOneCheckedMap.put(AppConstants.NO_ONE_CHECKED + "20055", FwConstants.NO);
		}
		pageCollection.put(AppConstants.NO_ONE_CHECKED_MAP, noOneCheckedMap);
		pageCollection.put(FwConstants.PAGE_COMPONENT_LIST, beforeColl.get(FwConstants.PAGE_COMPONENT_LIST));
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.addMovedOutValidationMessages() - END");
	}

	/**
	 * Validate request data of moved out details
	 *
	 * @param rmcInPrflPageColl
	 * @param noOneCollection
	 * @param noOneCheckedMap
	 * @param numofPplInHome
	 * @param movedInFlag
	 * @return
	 * @pageID - ARMOV
	 */
	private boolean isValidMovedOutDetailsRequestData(RMC_IN_PRFL_Collection rmcInPrflPageColl,
			NO_ONE_Collection noOneCollection, Map<Object, Object> noOneCheckedMap, int numofPplInHome,
			boolean movedInFlag, FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.isValidMovedOutDetailsRequestData() - START", fwTransaction);
		ARMOVValidator movedOutBO = new ARMOVValidator();
		FwMessageList errorMessageList = movedOutBO.validateMovedOut(rmcInPrflPageColl, noOneCollection,
				noOneCheckedMap, numofPplInHome, movedInFlag);
		fwTransaction.getRequest().put(FwConstants.MESSAGE_LIST, errorMessageList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.isValidMovedOutDetailsRequestData() - END", fwTransaction);
		return Objects.nonNull(errorMessageList) && CollectionUtils.isEmpty(errorMessageList.getMessageList());
		
	}

	/**
	 * TODO: Below is the logic performed at RMCNavigationBO, which has to be
	 * populated to get to this page.
	 *
	 * @param fwTransaction
	 * @return
	 */
	private RMC_RQST_Cargo populateRmcRequestCargo(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.populateRmcRequestCargo() - START", fwTransaction);
		final RMCRequestManager rmcRequestManager = new RMCRequestManager();
		final RMC_RQST_Cargo rmcRqstCargo = rmcRequestManager
				.loadRMCRequest((String) fwTransaction.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM));
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.populateRmcRequestCargo() - END", fwTransaction);
		return rmcRqstCargo;
	}

	/**
	 * Initializing the properties in a transactionBean which later used in further
	 * processing.
	 *
	 * @param fwTransaction
	 */
	private void initializeServiceProperties(FwTransaction fwTransaction) throws Exception {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.initializeServiceProperties() - START", fwTransaction);
		String currentPageID = (String) fwTransaction.getRequest().get(CURRENT_PAGE_ID);
		loadCollectionAndProfiles(fwTransaction);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.initializeServiceProperties() - END", fwTransaction);
	}

	/**
	 * Load Moved Out Details screen.
	 *
	 * @throws Exception
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadMovedOut(FwTransaction fwTransaction){
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadMovedOut() - START", fwTransaction);
		try {
			loadCollectionAndProfiles(fwTransaction);
		} catch(Exception exception) {  
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.loadMovedOut()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadMovedOut", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadMovedOut() - END", fwTransaction);
	}

	/**
	 * Load Collection profiles.
	 *
	 * @param fwTransaction
	 * @throws Exception
	 */
	private void loadCollectionAndProfiles(FwTransaction fwTransaction) throws Exception {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadCollectionAndProfiles() - START", fwTransaction);
     try {
		final String appNum = (String) fwTransaction.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM);
		peopleHandler.getHouseholdIndividuals(appNum);

		/**
		 * Populate pageCollection
		 */
		Map pageCollectionMap = fwTransaction.getPageCollection();

		fwTransaction.setPageCollection(pageCollectionMap);

		int[] driverArray = { 0, 0, 4, 0, 0, 4, 4, 0, 4, 0, 4, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
				0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1,
				1, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0 };

		int driverStatus = 4;

		RMC_IN_PRFL_Collection rmcInPrflColl = rmcResponseProfileManager.loadProfile(appNum);
		pageCollectionMap.put(AppConstants.RMC_IN_PRFL_MASTER, rmcInPrflColl);

		createAndLoadARMOVResponseMapsToPageCollection(rmcInPrflColl, pageCollectionMap, peopleHandler, true,
				driverStatus, appNum);
     }catch(Exception e) {
    	 FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.loadCollectionAndProfiles()", fwTransaction);
    	 throw e;
     }
     FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadCollectionAndProfiles() - END", fwTransaction);
	}

	/**
	 * Create and Load ARMOV Response maps to page collection.
	 *
	 * @param appInPrflColl
	 * @param pageCollection
	 * @param peopleHandler
	 * @param pageLoad
	 * @param driverStatus
	 * @return
	 */
	private Map createAndLoadARMOVResponseMapsToPageCollection(final RMC_IN_PRFL_Collection appInPrflColl,
			final Map pageCollection, final PeopleHandler peopleHandler, final boolean pageLoad, final int driverStatus,
			String appNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.createAndLoadARMOVResponseMapsToPageCollection() - START");
		try {
			getPeopleCollectionAndUpdateMaps(appInPrflColl, pageCollection, peopleHandler, "20055",
					HouseHoldDemoGraphicsConstants.MOVED_OUT_OF_HOME_RESP, pageLoad, driverStatus, false, appNum);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.createAndLoadARMOVResponseMapsToPageCollection() - END");
			return pageCollection;
			
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.createAndLoadARMOVResponseMapsToPageCollection()");
			throw exception;
		}
		
	}

	/**
	 * GetPeopleCollectionAndUpdateMaps
	 *
	 * @param rmcInPrflColl
	 * @param pageCollection
	 * @param peopleHandler
	 * @param compID
	 * @param questionName
	 * @param pageLoad
	 * @param driverStatus
	 * @param getRelevant
	 * @return
	 */
	public Map getPeopleCollectionAndUpdateMaps(final RMC_IN_PRFL_Collection rmcInPrflColl, final Map pageCollection,
			final PeopleHandler peopleHandler, final String compID, final short questionName, final boolean pageLoad,
			final int driverStatus, final boolean getRelevant, String appNum) {
		return getPeopleCollectionAndUpdateMaps(rmcInPrflColl, pageCollection, peopleHandler, compID, questionName,
				pageLoad, driverStatus, getRelevant, null, appNum);
	}

	/**
	 * GetPeople collection and maps.
	 *
	 * @param rmcInPrflColl
	 * @param pageCollection
	 * @param peopleHandler
	 * @param compID
	 * @param questionName
	 * @param pageLoad
	 * @param driverStatus
	 * @param getRelevant
	 * @param individualSeqNum
	 * @return
	 */
	public Map getPeopleCollectionAndUpdateMaps(final RMC_IN_PRFL_Collection rmcInPrflColl, final Map pageCollection,
			final PeopleHandler peopleHandler, final String compID, final short questionName, final boolean pageLoad,
			final int driverStatus, final boolean getRelevant, final String individualSeqNum, String appNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getPeopleCollectionAndUpdateMaps() - START");
		try {
			// Declarations
			String indivSeqNum = null;
			INDIVIDUAL_Custom_Cargo indivCargo;
			INDIVIDUAL_Custom_Collection indivColl;
			final StringBuilder indivCollKey = new StringBuilder();
			indivCollKey.append(AppConstants.PEOPLE);
			indivCollKey.append(compID);

			// try to get a filtered list. If it doesn't exist, get the
			// peopleHandler getIndividuals
			if (pageCollection.get(indivCollKey.toString()) == null) {

				if (getRelevant) {
					indivColl = peopleHandler.getInHomeIndividuals(appNum);
				} else {
					indivColl = peopleHandler.getAllIndvCustomCollectionFromAppNum(appNum);
				}
			} else {
				indivColl = (INDIVIDUAL_Custom_Collection) pageCollection.get(indivCollKey.toString());
			}
			// set the passed response map = new map
			final Map questionRespMap = new HashMap();

			// create an appInPrfl object
			RMC_IN_PRFL_Cargo rmcInPrflCargo = null;

			// get size of the collection
			final int indivCollSize = indivColl.size();

			// Define NoOneChecked = YES flags for the question
			String noOneChecked = FwConstants.YES;

			// Loop for each Cargo in the people collection (for each person)
			for (int i = 0; i < indivCollSize; i++) {
				// get the indivCargo
				indivCargo = (INDIVIDUAL_Custom_Cargo) indivColl.get(i);

				// get app_indiv_seq_num
				indivSeqNum = indivCargo.getIndv_seq_num();

				// Get the rmcInPrflCargo for this person
				rmcInPrflCargo = rmcResponseProfileManager.getProfile(rmcInPrflColl, indivSeqNum);

				// get the RMC_IN_PRFL Response for the given question from this
				// cargo
				String questionResp = rmcResponseProfileManager.getProfileResponse(rmcInPrflCargo, questionName);

				if ((questionName == HouseHoldDemoGraphicsConstants.ROOM_AND_BOARD)
						&& AppConstants.REQUIRED.equals(questionResp)) {
					questionResp = AppConstants.REQUIRED;
				}

				// for this question, add the person's response to a map
				questionRespMap.put(indivSeqNum, questionResp);

				if (pageLoad && (questionResp != null)
						&& (questionResp.charAt(0) != HouseHoldDemoGraphicsConstants.STATUS_NOT_REQUIRED)) {
					noOneChecked = FwConstants.NO;
				}

			} // end for loop

			if (pageLoad) {
				if (driverStatus == FwConstants.DRIVER_REQUIRED) {
					noOneChecked = FwConstants.NO;
				}

				// get the NoOneChecked map from the pagecollection
				Map noOneCheckedMap = (Map) pageCollection.get(AppConstants.NO_ONE_CHECKED_MAP);
				if (noOneCheckedMap == null) {
					noOneCheckedMap = new HashMap();
				}

				// update the noOneCheckedMap and re-add it to the page coll
				final StringBuilder noOneCheckedString = new StringBuilder();
				noOneCheckedString.append(AppConstants.NO_ONE_CHECKED);
				noOneCheckedString.append(compID);// "20055"
				noOneCheckedMap.put(noOneCheckedString.toString(), noOneChecked);
				pageCollection.put(AppConstants.NO_ONE_CHECKED_MAP, noOneCheckedMap);
			}

			// Store all maps in page collection
			final StringBuilder respMapString = new StringBuilder();
			respMapString.append(AppConstants.RESP_MAP);
			respMapString.append(compID);
			pageCollection.put(respMapString.toString(), questionRespMap);

			// store people collection in page collection
			final StringBuilder peopleString = new StringBuilder();
			peopleString.append(AppConstants.PEOPLE);
			peopleString.append(compID);
			pageCollection.put(peopleString.toString(), indivColl);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getPeopleCollectionAndUpdateMaps() - END");
			return pageCollection;
			// exit
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.getPeopleCollectionAndUpdateMaps()");
			throw exception;
		}
		
	}

	
	
	/**
	 * Load citizenship declaration.
	 *
	 * @param fwTransaction the txn bean
	 */
	@Transactional
	public void loadCitizenshipDeclaration(FwTransaction fwTransaction){
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadCitizenshipDeclaration() - START", fwTransaction);
		try {
			initializeCitizenShipDeclaration(fwTransaction);
		} catch(Exception exception) { 
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadCitizenshipDeclaration", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadCitizenshipDeclaration() - END", fwTransaction);
	}

	public void initializeCitizenShipDeclaration(FwTransaction fwTransaction) throws Exception {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.initializeCitizenShipDeclaration() - START", fwTransaction);
		final long startTime = System.currentTimeMillis();
		CP_APP_ESGIN_Collection appEsignColl = null;
		final APP_INDV_Collection appIndvChildrenColl = new APP_INDV_Collection();
		Map listViewMap = null;

		int age = 0;
		try {
			Map<Object, Object> request = fwTransaction.getRequest();
			Map<Object, Object> pageCollection = fwTransaction.getPageCollection();
			String appNumber = (String) fwTransaction.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM);
			String languageCd = "EN";

			final String currentPageID = (String) request.get(FwConstants.CURRENT_PAGE_ID);

			logger.info("RMCHouseHoldInfoEJBBean::loadCitizenshipDeclaration:End");
			appEsignColl = houseHoldMemberBO.loadCitizenshipDeclarationDetails(appNumber);
			pageCollection.put("CP_APP_ESGIN_Collection", appEsignColl);

			final APP_INDV_Collection appIndvColl = householdMembersSummaryBO.loadHouseholdMembers(appNumber);

			// Prepare children collection for the listview
			for (int i = 0; i < appIndvColl.size(); i++) {
				final APP_INDV_Cargo tempCargo = (APP_INDV_Cargo) appIndvColl.get(i);
				if (Objects.nonNull(tempCargo.getBrth_dt())) {
					age = AgeUtil.calculateAge(tempCargo.getBrth_dt().toString());
				}
				if (age > 19) {
					continue;
				} else {
					appIndvChildrenColl.add(tempCargo);
				}
			}
			listViewMap = new HashMap();
			listViewMap.put("APP_INDV_Collection", appIndvChildrenColl);
			final ARCitizenshipListView listviewbean1 = new ARCitizenshipListView();
			listviewbean1.setLanguage(languageCd);
			listviewbean1.setAppIndvCollection(appIndvChildrenColl);
			pageCollection.put("ARCitizenshipListViewDetials", listviewbean1);
			pageCollection.put("rmc.householdmumber.collection", appIndvColl);

		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.initializeCitizenShipDeclaration()", fwTransaction);
			throw fe;
		}catch(Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.initializeCitizenShipDeclaration()", fwTransaction);
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.initializeCitizenShipDeclaration() - END", fwTransaction);
	}

	/**
	 * Store citizenship declaration.
	 *
	 * @param txnBean
	 */
	@Transactional
	public void storeCitizenshipDeclaration(final FwTransaction fwTransaction) throws Exception {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeCitizenshipDeclaration() - START", fwTransaction);
		initializeCitizenShipDeclaration(fwTransaction);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeCitizenshipDeclaration() - START", fwTransaction);
		String appNumber = (String) fwTransaction.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM);
		FwMessageList validateInfo = null;
		CP_APP_ESGIN_Collection esignColl = null;
		CP_APP_ESGIN_Collection esignBeforeColl = null;
		CP_APP_ESGIN_Cargo appEsignCargo = new CP_APP_ESGIN_Cargo();
		CP_APP_ESGIN_Cargo appEsignBeforeCargo = null;
		Map listViewMap = null;
		int age = 0;
		final APP_INDV_Collection appIndvChildrenColl = new APP_INDV_Collection();
		try {
			final Map request = fwTransaction.getRequest();
			final Map pageCollection = fwTransaction.getPageCollection();

			final String currentPageID = (String) request.get(FwConstants.CURRENT_PAGE_ID);

			String languageCd = "EN";

			final Map<Object, Object> beforeColl = (Map) fwTransaction.getPageCollection();

			if (beforeColl != null && !beforeColl.isEmpty()) {
				if (beforeColl.containsKey("CP_APP_ESGIN_Collection")) {
					esignBeforeColl = (CP_APP_ESGIN_Collection) beforeColl.get("CP_APP_ESGIN_Collection");
				}
			}
			if (esignBeforeColl != null && !esignBeforeColl.isEmpty()) {
				appEsignBeforeCargo = (CP_APP_ESGIN_Cargo) esignBeforeColl.get(0);
			}
			// Get the Esign page level collection from page collection
			esignColl = (CP_APP_ESGIN_Collection) pageCollection.get("CP_APP_ESGIN_Collection");

			if (esignColl != null && !esignColl.isEmpty()) {
				appEsignCargo = (CP_APP_ESGIN_Cargo) esignColl.get(0);
			}

			appEsignCargo.setAppNum(FwConstants.ONE);
			appEsignCargo.setSrcAppInd("RN");
			appEsignCargo.setAppl_citz_decl_esign_date(new Date());
			appEsignCargo.setSeqNum(Integer.parseInt(FwConstants.ONE));

			validateInfo = houseHoldMemberBO.validateCitizenDetails(esignColl);

			/**
			 * Validating the UI Data and appending the errorMessages
			 */
			if (Objects.nonNull(validateInfo)) {
				request.put(FwConstants.MESSAGE_LIST, validateInfo);
				pageCollection.put("CP_APP_ESGIN_Collection", esignColl);
				final APP_INDV_Collection appIndvColl = householdMembersSummaryBO.loadHouseholdMembers(appNumber);
				for (int i = 0; i < appIndvColl.size(); i++) {
					final APP_INDV_Cargo tempCargo = (APP_INDV_Cargo) appIndvColl.get(i);
					if (Objects.nonNull(tempCargo.getBrth_dt())) {
						age = AgeUtil.calculateAge(tempCargo.getBrth_dt().toString());
					}
					if (age > 19) {
						continue;
					} else {
						appIndvChildrenColl.add(tempCargo);
					}
				}

				listViewMap = new HashMap();
				listViewMap.put("APP_INDV_Collection", appIndvChildrenColl);

				final ARCitizenshipListView listviewbean1 = new ARCitizenshipListView();
				listviewbean1.setLanguage(languageCd);
				pageCollection.put("ARCitizenshipListViewDetials", listviewbean1);
				return;
			}

			houseHoldMemberBO.storeCitizenshipDeclaration(esignColl);

			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get("rmc.householdmumber.collection");
			final APP_INDV_Collection appIndvChildrenColl1 = new APP_INDV_Collection();
			boolean hasKids = false;
			for (int i = 0; i < appIndvColl.size(); i++) {
				final APP_INDV_Cargo cargoToPersist = (APP_INDV_Cargo) appIndvColl.get(i);
				if (Objects.nonNull(cargoToPersist.getBrth_dt())) {
					age = AgeUtil.calculateAge(cargoToPersist.getBrth_dt().toString());
				}
				if (age > 19) {
					continue;
				} else {
					if (cargoToPersist != null) {
						String usCtznSw = cargoToPersist.getUs_ctzn_sw();
						if (FwConstants.YES.equalsIgnoreCase(usCtznSw)) {
							householdMembersSummaryBO.updateCitizenShipWithExistingFlag(cargoToPersist, usCtznSw);
						}
					}
					hasKids = true;
				}
			}
			if (hasKids && (appIndvColl != null && !appIndvColl.isEmpty())) {
				// Persisting using BO service.
				householdMembersSummaryBO.updateChildCitizenShipStatus(appIndvColl);
			}

			/**
			 * Medicare section update based on citizenShip information.
			 */
			Boolean medFlag = afbHouseholdMembersSummaryBO.loadMedicaidProgram(appNumber);
			if (medFlag) {
				final APP_INDV_Collection tempColl = householdMembersSummaryBO.loadHouseholdMembers(appNumber);
				int ageMagi = 0;
				boolean fullMedicaid = false;
				for (int j = 0; j < tempColl.size(); j++) {
					final APP_INDV_Cargo tempCargo = (APP_INDV_Cargo) tempColl.get(j);

					if (Objects.nonNull(tempCargo.getBrth_dt())) {
						ageMagi = AgeUtil.calculateAge(tempCargo.getBrth_dt().toString());
					}

					if ((FwConstants.YES.equals(tempCargo.getDisabled_resp()) || (ageMagi >= 65))) {
						fullMedicaid = true;
						break;
					}
				}
				if (fullMedicaid) {
					afbHouseholdMembersSummaryBO.updateMagiProgram(appNumber);
				}
			}

			logger.info("RMCHouseHoldInfoEJBBEan::storeCitizenshipDeclaration:End");
		}catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.storeCitizenshipDeclaration()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeCitizenshipDeclaration", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		} 
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeCitizenshipDeclaration() - END", fwTransaction);
	}

	/**
	 * Load houseHold info relationship details.
	 *
	 * @param fwTransaction
	 * @throws FwWrappedException
	 */
	@Transactional
	public void loadHouseHoldInfoRelationshipDetails(final FwTransaction fwTransaction) throws FwWrappedException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadHouseHoldInfoRelationshipDetails() - START", fwTransaction);
		try {
		initializeHouseHoldInfoRelationshipDetails(fwTransaction);
		}catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_CARE_TAKER_PERSON_SELECTION_ERROR, fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadHouseHoldInfoRelationshipDetails", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadHouseHoldInfoRelationshipDetails() - END", fwTransaction);
	}

	/**
	 * Initiaze the properties of household info relationship details.
	 *
	 * @param fwTransaction
	 */
	public void initializeHouseHoldInfoRelationshipDetails(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.initializeHouseHoldInfoRelationshipDetails() - START", fwTransaction);
		final Map request = fwTransaction.getRequest();
		Map pageCollection = fwTransaction.getPageCollection();
		String appNumber = null;
		Map beforeColl = null;
		int[] driverArray = null;
		int indvSeqNumber = 1;
		INDIVIDUAL_Custom_Collection indvSortedCustColl = null;
		INDIVIDUAL_Custom_Collection newIndvSortedCustColl = null;
		INDIVIDUAL_Custom_Collection indvSrcCustColl = null;
		INDIVIDUAL_Custom_Collection indvRefCustColl = null;
		int relationPosition = 0;
		String pageId = null;
		int pageStatus = 1; // Initializing as per Legacy.
		int indvSortSize = 0;
		boolean detailKeyFlag = false;
		try {
			appNumber = (String) fwTransaction.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM);
			peopleHandler.getHouseholdIndividuals(appNumber);

			pageId = (String) request.get(FwConstants.CURRENT_PAGE_ID);

			indvSortSize = peopleHandler.getNumberOfIndividuals(peopleHandler.getHouseholdIndividuals(appNumber));
			beforeColl = (Map) fwTransaction.getPageCollection();

			indvSortedCustColl = (INDIVIDUAL_Custom_Collection) pageCollection.get("SortedColl");

			if (indvSortedCustColl == null) {
				// here we are getting the sorted collection
				// PCR 30516 - Get only In Home individuals
				indvSortedCustColl = peopleHandler.sortIndividualsByAge(peopleHandler.getInHomeIndividuals(appNumber));
			}

			if (beforeColl != null && !beforeColl.isEmpty()) {
				beforeColl.remove("INDV_SRC_CUST_Collection");
				beforeColl.remove("INDV_REF_CUST_Collection");
				if (beforeColl.containsKey(FwConstants.CURRENT_RECORD_INDEX)) {
					relationPosition = Integer.parseInt((String) beforeColl.get(FwConstants.CURRENT_RECORD_INDEX));
					relationPosition = relationPosition + 1;

					if (beforeColl.get("AgeGenderChangeFlag") != null) {
						relationPosition = 0;
						beforeColl.put(FwConstants.CURRENT_RECORD_INDEX, "0");
						beforeColl.put(FwConstants.LAST_RECORD_INDEX, "0");
						beforeColl.remove("AgeGenderChangeFlag");
						if (pageCollection.containsKey(FwConstants.DETAIL_KEY_BEAN)) {
							final IndivTypeSeqBean indvSeqBean = (IndivTypeSeqBean) pageCollection
									.get(FwConstants.DETAIL_KEY_BEAN);
							indvSeqBean.setIndivSeqNum("1");
							pageCollection.put(FwConstants.DETAIL_KEY_BEAN, indvSeqBean);
						}
					} else {
						final APP_HSHL_RLT_Cargo relationCargo = new APP_HSHL_RLT_Cargo();
						relationCargo.setApp_num(appNumber);
						relationCargo.setSrc_indv_seq_num(relationPosition);
						boolean found = false;
						APP_HSHL_RLT_Collection relationColl = houseHoldInfoBO.getRelationDetails(relationCargo);
						if (Objects.nonNull(relationColl)) {
							for (int i = 0; i < relationColl.size(); i++) {
								if ("RM".equals(relationColl.getCargo(i).getSrc_app_ind())) {
									found = true;
									break;
								}
							}
						}
						if (!found)
							relationPosition--;
						beforeColl.put(FwConstants.CURRENT_RECORD_INDEX, String.valueOf(relationPosition));
						if (pageCollection.containsKey(FwConstants.DETAIL_KEY_BEAN)) {
							final IndivTypeSeqBean indvSeqBean = (IndivTypeSeqBean) pageCollection
									.get(FwConstants.DETAIL_KEY_BEAN);
							indvSeqBean
									.setIndivSeqNum(indvSortedCustColl.getResult(relationPosition).getIndv_seq_num());
							pageCollection.put(FwConstants.DETAIL_KEY_BEAN, indvSeqBean);
						}
					}

				}
			}

			indvSortSize = indvSortedCustColl.size();
			newIndvSortedCustColl = (INDIVIDUAL_Custom_Collection) pageCollection.get("NewSortedColl");

			newIndvSortedCustColl = new INDIVIDUAL_Custom_Collection();
			newIndvSortedCustColl.addAll(indvSortedCustColl);

			final int newIndvSortedCustCollSize = newIndvSortedCustColl.size();
			if (pageCollection.containsKey(FwConstants.DETAIL_KEY_BEAN)) {
				final IndivTypeSeqBean indvSeqBean = (IndivTypeSeqBean) pageCollection.get(FwConstants.DETAIL_KEY_BEAN);
				indvSeqNumber = Integer.parseInt(indvSeqBean.getIndivSeqNum());

				// now we are finding that position
				for (int i = 0; i < newIndvSortedCustCollSize; i++) {
					if (newIndvSortedCustColl.getResult(i).getIndv_seq_num().equals(indvSeqBean.getIndivSeqNum())) {
						relationPosition = i;
						break;
					}
				}
				detailKeyFlag = true;
			} else if (pageStatus == FwConstants.DRIVER_COMPLETE) {
				INDIVIDUAL_Custom_Cargo indvSortCargo = null;
				for (int i = 0; i < newIndvSortedCustCollSize - 1; i++) {
					indvSortCargo = newIndvSortedCustColl.getResult(i);
					// here we need to determine the last record we need to show
					// are not
					if (indvSortSize == i + 1) {
						// now we need to determine that person rules
						indvSrcCustColl = new INDIVIDUAL_Custom_Collection();
						indvSrcCustColl.add(indvSortCargo);
					}
					populateRecordArray(new IndivTypeSeqBean(indvSortCargo.getIndv_seq_num(), FwConstants.EMPTY_STRING,
							FwConstants.EMPTY_STRING), beforeColl);
					relationPosition = i;
				}
			}

			// now i am creating the collections
			// first collection is src indv seq number
			indvSrcCustColl = new INDIVIDUAL_Custom_Collection();
			indvRefCustColl = new INDIVIDUAL_Custom_Collection();
			pageCollection = new HashMap();

			if (pageStatus == FwConstants.DRIVER_COMPLETE || pageStatus == FwConstants.DRIVER_VISIT_AGAIN
					|| pageStatus == FwConstants.DRIVER_REQUIRED || detailKeyFlag) {
				// first i need to get the rel point one to the src collection
				if (newIndvSortedCustCollSize > 0) {
					indvSrcCustColl.add(newIndvSortedCustColl.get(relationPosition));
					indvSeqNumber = Integer.parseInt(indvSrcCustColl.getResult(0).getIndv_seq_num());
				}

				// now i am loging the page informaton
				pageCollection = houseHoldRelationshipBO.loadHousholdRelationshipDetails(appNumber, indvSeqNumber,
						fwTransaction);

				for (int index = relationPosition + 1; index < indvSortSize; index++) {
					if (!indvSortedCustColl.getResult(index).getIndv_seq_num()
							.equals(indvSrcCustColl.getResult(0).getIndv_seq_num())) {
						indvRefCustColl.add(indvSortedCustColl.getResult(index));
					}
				}

				// now i am storing this seq number to the record array
				if (!detailKeyFlag && pageStatus != FwConstants.DRIVER_COMPLETE) {
					populateRecordArray(new IndivTypeSeqBean(indvSrcCustColl.getResult(0).getIndv_seq_num(),
							FwConstants.EMPTY_STRING, FwConstants.EMPTY_STRING), beforeColl);
				}
				// filtered values
				final APP_HSHL_RLT_Collection relationCollection = houseHoldRelationshipBO
						.checkExistingRelations(appNumber);
				if (relationCollection != null) {
					pageCollection.put("RelationCollection", relationCollection);
				}

				pageCollection.put("INDV_SRC_CUST_Collection", indvSrcCustColl);
				pageCollection.put("INDV_REF_CUST_Collection", indvRefCustColl);
				pageCollection.put("SortedColl", indvSortedCustColl);
				pageCollection.put("NewSortedColl", newIndvSortedCustColl);
				pageCollection.put(AppConstants.INDV_SEQUENCE_NUMBERS, String.valueOf(indvSeqNumber));
			}

			String snapPrgm = FwConstants.NO;

			LinkedHashMap<String, Object> programKey = (LinkedHashMap<String, Object>) fwTransaction.getPageCollection()
					.get("ProgramFlags");
			Boolean snapFlag = Boolean.valueOf((String) programKey.get("snapFlag"));

			if (snapFlag) {
				snapPrgm = FwConstants.YES;
			}

			pageCollection.put("SnapProgram", snapPrgm);
			pageCollection.put("CurrentPageStatus", String.valueOf(pageStatus));
			fwTransaction.setPageCollection(pageCollection);
			if (beforeColl == null) {
				beforeColl = new HashMap();
			}
			beforeColl.putAll(pageCollection);
			fwTransaction.getPageCollection().putAll(beforeColl);
		} catch (FwWrappedException fwWrappedException) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.initializeHouseHoldInfoRelationshipDetails()", fwTransaction);
			throw fwWrappedException;
		}catch(Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.initializeHouseHoldInfoRelationshipDetails() - END", fwTransaction);
	}

	/**
	 * Store houseHold info relationship details.
	 *
	 * @param fwTransaction
	 * @throws Exception
	 */
	@Transactional
	@SuppressWarnings("squid:S3776")
	public void storeHouseHoldInfoRelationshipDetails(final FwTransaction fwTransaction){

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldInfoRelationshipDetails() - START", fwTransaction);

		final long startTime = System.currentTimeMillis();
		initializeHouseHoldInfoRelationshipDetails(fwTransaction);

		final Map request = fwTransaction.getRequest();
		final Map<Object, Object> pageCollection = fwTransaction.getPageCollection();
		String appNumber = null;
		String pageId = null;
		Map<Object, Object> beforeColl = fwTransaction.getPageCollection();
		APP_HSHL_RLT_Collection appHshlRltColl = null;
		APP_HSHL_RLT_Collection appHshlRltBeforeColl = null;
		APP_HSHL_RLT_Cargo appHshlRltCargo = null;
		APP_HSHL_RLT_Cargo appHshlRltBeforeCargo = null;
		INDIVIDUAL_Custom_Collection newSortedColl = null;
		INDIVIDUAL_Custom_Collection refCustColl = null;
		String isTaxDepInd = "";
		int indvSeqNumber = 1;
		int newSortedCollSize = 0;
		String snapPrgm = FwConstants.EMPTY_STRING;
		String persistAction = StringUtils.EMPTY;
		int currentPageStatus = Integer.valueOf(1);

		try {
			appNumber = (String) fwTransaction.getRequest().get(HouseHoldDemoGraphicsConstants.UI_APP_NUM);

			pageId = (String) request.get(FwConstants.CURRENT_PAGE_ID);

			peopleHandler.getHouseholdIndividuals(appNumber);

			snapPrgm = (String) beforeColl.get("SnapProgram");

			appHshlRltColl = (APP_HSHL_RLT_Collection) pageCollection.get("APP_HSHL_RLT_Collection");
			if (beforeColl != null) {
				if (beforeColl.containsKey("NewSortedColl")) {
					newSortedColl = (INDIVIDUAL_Custom_Collection) beforeColl.get("NewSortedColl");
				}

				if (beforeColl.containsKey("APP_HSHL_RLT_Collection")) {
					appHshlRltBeforeColl = (APP_HSHL_RLT_Collection) beforeColl.get("APP_HSHL_RLT_Collection");
				}
				if (beforeColl.containsKey(AppConstants.INDV_SEQUENCE_NUMBERS)) {
					indvSeqNumber = Integer.parseInt((String) beforeColl.get(AppConstants.INDV_SEQUENCE_NUMBERS));
				}
				if (beforeColl.containsKey("INDV_REF_CUST_Collection")) {
					refCustColl = (INDIVIDUAL_Custom_Collection) beforeColl.get("INDV_REF_CUST_Collection");
				}

			}
			if (newSortedColl != null) {
				newSortedCollSize = newSortedColl.size();
			}
			final String backToMyAccess = (String) request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON);
			if (backToMyAccess == null) {
				pageCollection.put("SnapProgram", snapPrgm);
			}
			final boolean completeCareFlg = true;
			final List componentList = (ArrayList) beforeColl.get(FwConstants.PAGE_COMPONENT_LIST);
			// for the relation ship cargo
			if (appHshlRltColl != null && !appHshlRltColl.isEmpty()) {
				final int appHshlRltCollSize = appHshlRltColl.size();
				APP_HSHL_RLT_Collection appHshlRltDataColl = null;
				boolean foundFlag = false;
				boolean foundCWFlag = false;
				boolean rmRnEntryAvailable = false;
				Integer srcSeqNum = null;
				Integer refSeqNum = null;
				boolean completeRltFlag = true;

				for (int i = 0; i < appHshlRltCollSize; i++) {
					completeRltFlag = true;
					appHshlRltCargo = appHshlRltColl.getCargo(i);
					appHshlRltCargo.setApp_num(appNumber);
					appHshlRltCargo.setChg_eff_dt(AppConstants.HIGH_DATE);
					appHshlRltCargo.setSrc_app_ind(AppConstants.RMC_NEW_RECORD_IND);
					if (appHshlRltCargo.getCare_resp() == null) {
						appHshlRltCargo.setCare_resp(FwConstants.SPACE);
					}
					if (appHshlRltCargo.getPhy_boe_sep_sw() == null) {
						appHshlRltCargo.setPhy_boe_sep_sw(FwConstants.SPACE);
						if (componentList.contains("31")) {
							completeRltFlag = false;
						}
					}
					if (completeRltFlag && completeCareFlg) {
						appHshlRltCargo.setRec_cplt_ind(FwConstants.ONE);
					} else {
						appHshlRltCargo.setRec_cplt_ind(FwConstants.ZERO);
					}
					foundFlag = false;
					foundCWFlag = false;
					rmRnEntryAvailable = false;
					srcSeqNum = appHshlRltCargo.getSrc_indv_seq_num();
					refSeqNum = appHshlRltCargo.getRef_indv_seq_num();

					// now we are comparing the data
					if (appHshlRltBeforeColl != null && !appHshlRltBeforeColl.isEmpty()) {
						APP_HSHL_RLT_Cargo rmcNewBeforeCargo = houseHoldRelationshipBO.splitRelationWithRecIndSeqNum(
								appHshlRltBeforeColl, AppConstants.RMC_NEW_RECORD_IND, srcSeqNum, refSeqNum);
						APP_HSHL_RLT_Cargo rmcModifiedBeforeCargo = houseHoldRelationshipBO
								.splitRelationWithRecIndSeqNum(appHshlRltBeforeColl,
										AppConstants.RMC_MODIFIED_RECORD_IND, srcSeqNum, refSeqNum);

						APP_HSHL_RLT_Cargo cwwBeforeCargo = houseHoldRelationshipBO.splitRelationWithRecIndSeqNum(
								appHshlRltBeforeColl, AppConstants.CWW_RECORD_IND, srcSeqNum, refSeqNum);

						if (cwwBeforeCargo != null) {
							isTaxDepInd = cwwBeforeCargo.getTax_dpnd_resp();
						}

						if (rmcNewBeforeCargo != null) {
							appHshlRltCargo.setCare_resp(rmcNewBeforeCargo.getCare_resp());
							if (rmcNewBeforeCargo.getChg_eff_dt() != null) {
								appHshlRltCargo.setChg_eff_dt(rmcNewBeforeCargo.getChg_eff_dt());
							}
							appHshlRltCargo.setSrc_app_ind(rmcNewBeforeCargo.getSrc_app_ind());
							Boolean isChanged = (rmcNewBeforeCargo == null)
									|| (rmcNewBeforeCargo.hashCode() != appHshlRltCargo.hashCode());
							if (isChanged.booleanValue()) {

								persistAction = String.valueOf(FwConstants.ROWACTION_UPDATE);

								if (appHshlRltDataColl == null) {
									appHshlRltDataColl = new APP_HSHL_RLT_Collection();
								}
								appHshlRltDataColl.add(appHshlRltCargo);
							}
							appHshlRltBeforeColl.remove(rmcNewBeforeCargo);
							foundFlag = true;
						}

						if (rmcModifiedBeforeCargo != null) {
							if (!rmRnEntryAvailable) {
								rmRnEntryAvailable = true;
							}

							appHshlRltCargo.setCare_resp(rmcModifiedBeforeCargo.getCare_resp());
							if (rmcModifiedBeforeCargo.getChg_eff_dt() != null) {
								appHshlRltCargo.setChg_eff_dt(rmcModifiedBeforeCargo.getChg_eff_dt());
							}
							appHshlRltCargo.setSrc_app_ind(rmcModifiedBeforeCargo.getSrc_app_ind());
							Boolean isChanged = (rmcModifiedBeforeCargo == null)
									|| (rmcModifiedBeforeCargo.hashCode() != appHshlRltCargo.hashCode());
							if (isChanged.booleanValue()) {

								persistAction = String.valueOf(FwConstants.ROWACTION_UPDATE);

								if (appHshlRltDataColl == null) {
									appHshlRltDataColl = new APP_HSHL_RLT_Collection();
								}

								appHshlRltDataColl.add(appHshlRltCargo);
								String beforeRel = rmcModifiedBeforeCargo.getRlt_cd();
								String afterRel = appHshlRltCargo.getRlt_cd();

								if (!beforeRel.equals(afterRel) && currentPageStatus != FwConstants.DRIVER_REQUIRED) {
									ABHouseHoldMemberBO houseHoldMemberBo = new ABHouseHoldMemberBO();
									if ("FTR".equals(afterRel) || "MTR".equals(afterRel)) {
										if (Objects.nonNull(appHshlRltCargo.getRef_indv_seq_num())) {
											Integer refNumber = Integer.valueOf(appHshlRltCargo.getRef_indv_seq_num());
											final IndividualAge indvAge = peopleHandler.getIndividualAge(refNumber);
											if (indvAge.getYears() < 19) {
												houseHoldMemberBo.deleteAbsentParent(
														appHshlRltCargo.getRef_indv_seq_num(), appNumber);
											}
										}
									} else if ("SON".equals(afterRel) || "DAU".equals(afterRel)) {
										if (Objects.nonNull(appHshlRltCargo.getSrc_indv_seq_num())) {
											Integer indvSeq = Integer.valueOf(appHshlRltCargo.getSrc_indv_seq_num());
											final IndividualAge indvAge = peopleHandler.getIndividualAge(indvSeq);
											if (indvAge.getYears() < 19) {
												houseHoldMemberBo.deleteAbsentParent(
														appHshlRltCargo.getSrc_indv_seq_num(), appNumber);
											}
										}

									} else if (("HUS".equals(afterRel) || "WIF".equals(afterRel))
											&& (Objects.nonNull(appHshlRltCargo.getSrc_indv_seq_num()))) {

										Integer indvSeq = Integer.valueOf(appHshlRltCargo.getSrc_indv_seq_num());
										IndividualAge indvAge = peopleHandler.getIndividualAge(indvSeq);
										if (indvAge.getYears() < 19) {
											houseHoldMemberBo.deleteAbsentParent(appHshlRltCargo.getSrc_indv_seq_num(),
													appNumber);
										}
										indvAge = peopleHandler.getIndividualAge(indvSeq);
										if (indvAge.getYears() < 19) {
											houseHoldMemberBo.deleteAbsentParent(appHshlRltCargo.getRef_indv_seq_num(),
													appNumber);
										}

									}
								}
							}
							appHshlRltBeforeColl.remove(rmcModifiedBeforeCargo);
							foundFlag = true;
						}

						if (cwwBeforeCargo != null) {
							if (!rmRnEntryAvailable) {
								appHshlRltCargo.setSrc_app_ind(AppConstants.RMC_MODIFIED_RECORD_IND);
								foundCWFlag = true;
							}
							appHshlRltBeforeColl.remove(cwwBeforeCargo);
						}
					}
					if (!foundFlag || foundCWFlag) {
						persistAction = String.valueOf(FwConstants.ROWACTION_INSERT);

						if (appHshlRltDataColl == null) {
							appHshlRltDataColl = new APP_HSHL_RLT_Collection();
						}
						appHshlRltDataColl.add(appHshlRltCargo);
					}

					if (null != refSeqNum && FwConstants.ONE.equals(refSeqNum.toString().trim())) {
						peopleHandler.setRelationshipCode(srcSeqNum, appHshlRltCargo.getRlt_cd(), appNumber);
					} else if (null != srcSeqNum && FwConstants.ONE.equals(srcSeqNum.toString().trim())) {
						String gender = peopleHandler.getIndividual(String.valueOf(srcSeqNum)).getSex_ind();
						String relation = appHshlRltCargo.getRlt_cd();
						if (AppConstants.SEX_IND_MALE.equals(gender)) {
							peopleHandler.setRelationshipCode(refSeqNum,
									referenceTableManager.getColumnValue("TREL", 69, relation, FwConstants.ENGLISH),
									appNumber);
						} else {
							peopleHandler.setRelationshipCode(refSeqNum,
									referenceTableManager.getColumnValue("TREL", 70, relation, FwConstants.ENGLISH),
									appNumber);
						}
					}
				}
				if (appHshlRltBeforeColl != null && !appHshlRltBeforeColl.isEmpty()) {
					final int appHshlRltBeforeCollSize = appHshlRltBeforeColl.size();
					for (int i = 0; i < appHshlRltBeforeCollSize; i++) {
						appHshlRltBeforeCargo = appHshlRltBeforeColl.getCargo(i);
						if (!AppConstants.CWW_RECORD_IND.equals(appHshlRltBeforeCargo.getSrc_app_ind())) {

							persistAction = String.valueOf(FwConstants.ROWACTION_DELETE);

							if (appHshlRltDataColl == null) {
								appHshlRltDataColl = new APP_HSHL_RLT_Collection();
							}
							appHshlRltDataColl.add(appHshlRltBeforeCargo);
						}
					}
				}
				if (appHshlRltDataColl != null && !appHshlRltDataColl.isEmpty()) {
					APP_HSHL_RLT_Cargo appHshlRltParCargo = null;
					for (int j = 0; j < appHshlRltDataColl.size(); j++) {
						appHshlRltParCargo = appHshlRltDataColl.getCargo(j);
						if (appHshlRltParCargo.getChg_eff_dt() != null
								&& appHshlRltParCargo.getChg_eff_dt().length() > 10) {
							appHshlRltParCargo.setChg_eff_dt(appHshlRltParCargo.getChg_eff_dt().substring(0, 10));
						}
						if (isTaxDepInd != null && !"".equals(isTaxDepInd)) {
							appHshlRltParCargo.setTax_dpnd_resp(isTaxDepInd);
						} else {
							appHshlRltParCargo.setTax_dpnd_resp("");
						}
					}

					houseHoldRelationshipBO.storeHousholdRelationshipDetails(appHshlRltDataColl, null, persistAction);
				}
			} else if (appHshlRltBeforeColl != null && !appHshlRltBeforeColl.isEmpty()) {
				final int appHshlRltBeforeCollSize = appHshlRltBeforeColl.size();
				for (int i = 0; i < appHshlRltBeforeCollSize; i++) {
					appHshlRltBeforeCargo = appHshlRltBeforeColl.getCargo(i);
					if (!AppConstants.CWW_RECORD_IND.equals(appHshlRltBeforeCargo.getSrc_app_ind())) {
						persistAction = String.valueOf(FwConstants.ROWACTION_DELETE);
					}
				}
				houseHoldRelationshipBO.storeHousholdRelationshipDetails(appHshlRltBeforeColl, null, persistAction);
			}
			boolean pageComplete = false;
			if (currentPageStatus == FwConstants.DRIVER_REQUIRED
					|| currentPageStatus == FwConstants.DRIVER_VISIT_AGAIN) {
				final int currentArrayIndex = Integer
						.parseInt((String) beforeColl.get(FwConstants.CURRENT_RECORD_INDEX));
				if (currentArrayIndex + 1 == newSortedCollSize || currentArrayIndex + 2 == newSortedCollSize) {
					pageComplete = true;
					final String curArrayIndexRec = String.valueOf(currentArrayIndex + 1);
					beforeColl.put(FwConstants.CURRENT_RECORD_INDEX, curArrayIndexRec);
				}
			}

			if (currentPageStatus == FwConstants.DRIVER_ADD_NEW || currentPageStatus == FwConstants.DRIVER_COMPLETE) {
				pageComplete = true;
			}

			pageCollection.put("PageCompleteFlag",  Boolean.valueOf(pageComplete));
		} catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldInfoRelationshipDetails()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeHouseHoldInfoRelationshipDetails", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldInfoRelationshipDetails() - END", fwTransaction);
	}

	/**
	 * Populate Record Array
	 *
	 * @param indivTypeSeqBean
	 * @param session
	 */
	protected void populateRecordArray(final IndivTypeSeqBean indivTypeSeqBean, Map<Object, Object> beforeColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.populateRecordArray() - START");
		int currentRecordIndex = 0;
		int lastRecordindex = 0;
		List recordArray = null;
		try {
			if (beforeColl.isEmpty()) {
				beforeColl = new HashMap<Object, Object>();
			}

			if (beforeColl.get(FwConstants.RECORD_ARRAY) != null) {
				currentRecordIndex = Integer.parseInt((String) beforeColl.get(FwConstants.CURRENT_RECORD_INDEX));
				lastRecordindex = Integer.parseInt((String) beforeColl.get(FwConstants.LAST_RECORD_INDEX));
				recordArray = (ArrayList) beforeColl.get(FwConstants.RECORD_ARRAY);
				if (currentRecordIndex == lastRecordindex) {
					currentRecordIndex = lastRecordindex = lastRecordindex + 1;
					final int recordArraySize = recordArray.size();
					if (indivTypeSeqBean.getSeqNum() == null) {
						int maxSeqNum = 0;
						IndivTypeSeqBean chkIndvTypeSeqBean = null;
						for (int i = 0; i < recordArraySize; i++) {
							chkIndvTypeSeqBean = (IndivTypeSeqBean) recordArray.get(i);
							if (chkIndvTypeSeqBean.getIndivSeqNum().equals(indivTypeSeqBean.getIndivSeqNum())
									&& (Integer.parseInt(chkIndvTypeSeqBean.getSeqNum()) > maxSeqNum)) {
								maxSeqNum = Integer.parseInt(chkIndvTypeSeqBean.getSeqNum());
							}
						}
						indivTypeSeqBean.setSeqNum(String.valueOf(maxSeqNum + 1));
					}

					if (lastRecordindex != recordArraySize) {

						IndivTypeSeqBean chkIndvTypeSeqBean = null;
						final List newRecordArray = new ArrayList();
						for (int i = 0; i < recordArraySize; i++) {
							if (i == lastRecordindex) {
								newRecordArray.add(indivTypeSeqBean);
							}
							chkIndvTypeSeqBean = (IndivTypeSeqBean) recordArray.get(i);
							newRecordArray.add(chkIndvTypeSeqBean);
						}
						recordArray = newRecordArray;
					} else {
						recordArray.add(indivTypeSeqBean);
					}
					beforeColl.put(FwConstants.RECORD_ARRAY, recordArray);
					beforeColl.put(FwConstants.CURRENT_RECORD_INDEX, String.valueOf(currentRecordIndex));
					beforeColl.put(FwConstants.LAST_RECORD_INDEX, String.valueOf(lastRecordindex));
				} else {
					currentRecordIndex = lastRecordindex;
					beforeColl.put(FwConstants.CURRENT_RECORD_INDEX, String.valueOf(currentRecordIndex));
				}
			} else {
				recordArray = new ArrayList();
				if (indivTypeSeqBean.getSeqNum() == null) {
					indivTypeSeqBean.setSeqNum("1");
				}
				recordArray.add(indivTypeSeqBean);
				beforeColl.put(FwConstants.RECORD_ARRAY, recordArray);
				beforeColl.put(FwConstants.CURRENT_RECORD_INDEX, String.valueOf(currentRecordIndex));
				beforeColl.put(FwConstants.LAST_RECORD_INDEX, String.valueOf(lastRecordindex));
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.populateRecordArray() - END");
		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.populateRecordArray()");
			throw fe;
		}
	}

	/**
	 * Load summary screen details for ARHCS.
	 *
	 * @param fwTransaction
	 */
	public void loadHouseHoldInfoSummary(final FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadHouseHoldInfoSummary() - START", fwTransaction);
		try {
			final Map request = fwTransaction.getRequest();
			boolean isAnyChanges = false;
			Map<Object, Object> pageCollection = fwTransaction.getPageCollection();

			final String languageCd = "EN";
			final String appNum = (String) fwTransaction.getRequest().get(AppConstants.APP_NUM);

			final int driverStatus = 0;
			String applicationType = String.valueOf(FwConstants.RMC_APP_TYPE);

			SortedSet selectionProfile = categorySelectionProfileManager.loadCategoryChangeSelectionProfile(appNum);

			boolean loadCatSelProfile = false;
			if ((selectionProfile == null || selectionProfile.isEmpty())
					&& driverStatus != FwConstants.DRIVER_NOT_REQUIRED) {
				loadCatSelProfile = true;
			} else if (selectionProfile != null && !selectionProfile.isEmpty()) {
				CategorySequenceDetail catSeqDetail = categorySelectionProfileManager
						.getCurrentSequenceDetail(selectionProfile);
				if (catSeqDetail == null) {
					catSeqDetail = categorySelectionProfileManager.getNextSequenceDetail(selectionProfile);
					if (catSeqDetail != null && !"null".equals(catSeqDetail.getChangeSelectionCategoryCd())
							&& AppConstants.RMC_CAT_HO_COMP_PRFL.equals(catSeqDetail.getChangeSelectionCategoryCd())) {
						loadCatSelProfile = false;
					} else {
						loadCatSelProfile = true;
					}
				}
			}

			if (loadCatSelProfile) {
				selectionProfile = categorySelectionProfileManager.loadCategoryChangeSelectionProfile(appNum,
						AppConstants.RMC_CAT_HO_COMP_PRFL);
			}
			categorySelectionProfileManager.resetCurrentSeqeunceDetail(selectionProfile);

			APP_INDV_Collection appIndvColl = movedInBO.loadAppIndvColl(appNum);

			// show individuals who are on the case(in WP or only CW records)
			INDIVIDUAL_Custom_Collection indvCustomColl = new INDIVIDUAL_Custom_Collection();
			INDIVIDUAL_Custom_Collection filIndvCustomColl = new INDIVIDUAL_Custom_Collection();
			indvCustomColl.setResults(peopleHandler.getAllIndvCustomCollectionFromAppNum(appNum).cloneResults());
			APP_INDV_Collection cwIndvColl = splitCollection(appIndvColl, AppConstants.CWW_RECORD_IND);

			for (Object o : indvCustomColl) {
				INDIVIDUAL_Custom_Cargo indvCustCargo = (INDIVIDUAL_Custom_Cargo) o;

				for (Object p : cwIndvColl) {
					APP_INDV_Cargo indvCargo = (APP_INDV_Cargo) p;
					if (indvCustCargo.getIndv_seq_num().equals(indvCargo.getIndv_seq_num().toString())) {
						filIndvCustomColl.add(indvCustCargo);
						break;
					}
				}

			}
			pageCollection.put("PEOPLE_20055", filIndvCustomColl);

			/**
			 * Prepare left the home summary list
			 */
			APP_INDV_Collection prsnLeftTheHomeColl = livingArrBO.loadMoveOutCollection(appNum);
			pageCollection.put("ARHCS_LEFTHOME_DETAILS_COLLECTION", prsnLeftTheHomeColl);

			/**
			 * Prepare houseHoldSummaryList
			 */
			APP_INDV_Collection houseHoldSummaryList = movedInBO.getHouseHoldMemberDetails(appNum);
			pageCollection.put("APP_IN_INDV_Collection", houseHoldSummaryList);
			pageCollection.put("INDIVIDUAL_ON_CASE_Collection",
					String.valueOf(Objects.nonNull(houseHoldSummaryList) ? houseHoldSummaryList.size() : 0));

			/**
			 * Prepare SomeOne Moved In List
			 */
			APP_INDV_Collection movedInCollection = getMovedInIndvColl(appIndvColl);
			pageCollection.put("ARHCS_ADD_PRSN_DTLS_COLLECTION", movedInCollection);

			fwTransaction.setPageCollection(pageCollection);

			// Copying over to beforeCollection for View to process.
			Map<Object, Object> beforeColl = new HashMap();
			beforeColl.putAll(fwTransaction.getPageCollection());

			peopleHandler.getHouseholdIndividuals(appNum);
			INDIVIDUAL_Custom_Collection indvCollCare = peopleHandler.getSortedIndividualsByIndvSeqNum();
			pageCollection.put("INDV_SRC_CUST_Collection", indvCollCare);

		} catch (final Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.loadHouseHoldInfoSummary()", fwTransaction);
			throw exception;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.loadHouseHoldInfoSummary() - END", fwTransaction);
	}

	/**
	 * Split Collection
	 *
	 * @param aColl
	 * @param srcAppIndicator
	 * @return
	 */
	private APP_INDV_Collection splitCollection(APP_INDV_Collection aColl, String srcAppIndicator) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.splitCollection() - START");

		APP_INDV_Collection resultColl = new APP_INDV_Collection();

		for (int i = 0; i < aColl.size(); i++) {
			if (srcAppIndicator.equals(aColl.getCargo(i).getSrc_app_ind())) {
				resultColl.addCargo(aColl.getCargo(i));
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.splitCollection() - END");
		return resultColl;

	}

	/**
	 * Get Moved In Individual collection.
	 *
	 * @param allIndividualCollection
	 * @return
	 */
	private APP_INDV_Collection getMovedInIndvColl(APP_INDV_Collection allIndividualCollection) {FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.APP_INDV_Collection() - END");
		final APP_INDV_Collection movedInColl = new APP_INDV_Collection();

		for (int i = 0; i < allIndividualCollection.size(); i++) {
			final APP_INDV_Cargo aCargo = allIndividualCollection.getCargo(i);
			if (AppConstants.RMC_NEW_RECORD_IND.equals(aCargo.getSrc_app_ind())) {
				movedInColl.addCargo(aCargo);
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.APP_INDV_Collection() - END");
		return movedInColl;
	}

	/**
	 * Store citizenShip information for the AFB flow - ABDSM
	 *
	 * @param fwTransaction
	 */
	public void storeCitizenship(final FwTransaction fwTransaction) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeCitizenship() - START", fwTransaction);
		Integer indvSeqNum = Integer.parseInt(
				fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
		APP_INDV_Collection appIndvColl = new APP_INDV_Collection();
		try {
			logger.info("HouseholdDemographicsInvidualRelationsService::storeCitizenship:Start");
			final Map<String, Object> pageCollection = fwTransaction.getPageCollection();

			String appNumber = fwTransaction.getUserDetails().getAppNumber();

			String languageCd = "EN";
			APP_INDV_Cargo appIndvCargo = null;

			appIndvColl = (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection");

			if ((appIndvColl != null) && (!appIndvColl.isEmpty())) {
				appIndvCargo = (APP_INDV_Cargo) appIndvColl.get(0);
			}
			if (appIndvCargo != null) {
				appIndvCargo.setApp_num(appNumber);
				appIndvCargo.setIndv_seq_num(indvSeqNum);
				appIndvCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
			}
			abHouseHoldMemberBO.storeCitizenship(appIndvColl, appNumber, indvSeqNum);
			fwTransaction.getPageCollection().put("APP_INDV_Collection", appIndvColl);
			
		} catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.storeCitizenship()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeCitizenship", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeCitizenship() - END", fwTransaction);
	}

	/**
	 * Gets the citizenship - ABDOC
	 *
	 * @param fwTransaction
	 */
	@Transactional
	public void getCitizenship(final FwTransaction fwTransaction) throws Exception {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getCitizenship() - START", fwTransaction);
		try {
			final Map pageCollection = fwTransaction.getPageCollection();
			String appNumber = fwTransaction.getUserDetails().getAppNumber();
			APP_INDV_Collection appIndvColl = null;
			APP_INDV_Cargo appIndvCargo = null;
			appIndvColl = abHouseHoldMemberBO.getCitizenshipDetails(appNumber);

			int size = 0;
			size = appIndvColl.size();
			String prim_person_sw;
			int primary_flag = 0;

			if (size > 0) {
				// filtering individuals based on primary person switch
				for (int i = 0; i <= size - 1; i++) {
					appIndvCargo = appIndvColl.getCargo(i);
					prim_person_sw = appIndvCargo.getPrim_prsn_sw();
					if (null != prim_person_sw && HouseHoldDemoGraphicsConstants.Y.equalsIgnoreCase(prim_person_sw)) {

						APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
						appIndvCollection.add(appIndvCargo);
						pageCollection.put("APP_INDV_Collection", appIndvCollection);
						primary_flag++;
						break;

					}
				}

				// adding a member to cargo/collection if there are no primary person present
				if (HouseHoldDemoGraphicsConstants.ZERO == primary_flag) {

					appIndvCargo = appIndvColl.getCargo(0);
					APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
					appIndvCollection.add(appIndvCargo);
					pageCollection.put("APP_INDV_Collection", appIndvCollection);
				}

			}

			fwTransaction.setPageCollection(pageCollection);
			logger.info("HouseholdDemographicsInvidualRelationsService::getCitizenship() - END");

		} catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.getCitizenship()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getCitizenship", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getCitizenship() - END", fwTransaction);
	}

	/**
	 * Load household relationship details for AFB
	 *
	 * @param fwTransaction
	 */
	@Transactional
	public void getHouseHoldRelationshipDetails(final FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getCitizenship() - START", fwTransaction);
		try {
			prepareHouseHoldRelation(fwTransaction);
		} catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_CARE_TAKER_PERSON_SELECTION_ERROR, fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getHouseHoldRelationshipDetails", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getHouseHoldRelationshipDetails() - END", fwTransaction);
	}

	/**
	 * Prepare House hold relationship for AFB
	 *
	 * @param fwTransaction
	 */
	private void prepareHouseHoldRelation(final FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.prepareHouseHoldRelation() - START", fwTransaction);
		Map pageCollection = fwTransaction.getPageCollection();

		String currentPageStatus = "CurrentPageStatus";

		String appNumber = null;
		Map beforeColl = null;
		int[] driverArray = null;
		int indvSeqNumber = 1;
		short[] programKeyArray = null;
		INDIVIDUAL_Custom_Collection indvSortedCustColl = null;
		INDIVIDUAL_Custom_Collection indvSrcCustColl = null;
		INDIVIDUAL_Custom_Collection careTakerCustColl = null;
		INDIVIDUAL_Custom_Collection newBornCustColl = null;

		int relationPosition = 0;
		int pageStatus = 1;
		int indvSortSize = 0;

		APP_IN_PRFL_Collection appInPrflSessionColl = null;
		boolean detailKeyFlag = false;

		boolean snapFlag = false;
		boolean maFlag = false;
		boolean tanfFlag = false;
		boolean ccFlag = false;

		appNumber = fwTransaction.getUserDetails().getAppNumber();

		final INDIVIDUAL_Custom_Collection peopleInHome = peopleHandler.getInAndOutOfHomeIndividuals(appNumber);

		indvSortSize = peopleInHome.size();

		final String previousPageId = fwTransaction.getCurrentActionDetails().getPageId();
      try {
		
    	if (indvSortedCustColl == null) {
			indvSortedCustColl = peopleHandler.sortIndividualsByAge(peopleInHome);
		}
		indvSortSize = indvSortedCustColl.size();

		if (pageCollection.containsKey(FwConstants.DETAIL_KEY_BEAN)) {
			final IndivTypeSeqBean indvSeqBean = (IndivTypeSeqBean) pageCollection.get(FwConstants.DETAIL_KEY_BEAN);
			indvSeqNumber = Integer.parseInt(indvSeqBean.getIndivSeqNum());

			// now we are finding that position
			for (int i = 0; i < indvSortSize; i++) {
				if (indvSortedCustColl.getResult(i).getIndv_seq_num().equals(indvSeqBean.getIndivSeqNum())) {
					relationPosition = i;
					break;
				}
			}
			detailKeyFlag = true;
		} else if (pageStatus == FwConstants.DRIVER_COMPLETE) {
			INDIVIDUAL_Custom_Cargo indvSortCargo = null;
			for (int i = 0; i < indvSortSize; i++) {
				indvSortCargo = indvSortedCustColl.getResult(i);
				if (indvSortSize == (i + 1)) {
					indvSrcCustColl = new INDIVIDUAL_Custom_Collection();
					indvSrcCustColl.add(indvSortCargo);
					final boolean pregChk = abHouseHoldRelationshipBO.runPregChk(appInPrflSessionColl, indvSrcCustColl);
					final String newBornMotherSeqNumber = null;
					final APP_HSHL_RLT_Collection careTakerColl = abHouseHoldRelationshipBO
							.runCareTakerCheck(indvSrcCustColl, appNumber);
					if (!pregChk && (newBornMotherSeqNumber == null) && (careTakerColl == null)) {
						continue;
					}
					if (pregChk && (newBornMotherSeqNumber == null) && (careTakerColl == null)) {
						continue;
					}
				}
				populateRecordArray(new IndivTypeSeqBean(indvSortCargo.getIndv_seq_num(), FwConstants.EMPTY_STRING,
						FwConstants.EMPTY_STRING), fwTransaction.getPageCollection());
				relationPosition = i;
			}
		}

		pageCollection = new HashMap();

		if ((pageStatus == FwConstants.DRIVER_COMPLETE) || (pageStatus == FwConstants.DRIVER_VISIT_AGAIN)
				|| (pageStatus == FwConstants.DRIVER_REQUIRED) || detailKeyFlag) {
			final INDIVIDUAL_Custom_Collection individualCustomCollection = new INDIVIDUAL_Custom_Collection();
			final INDIVIDUAL_Custom_Collection individualReferenceCollection = new INDIVIDUAL_Custom_Collection();

			if (Objects.nonNull(indvSortedCustColl) && ArrayUtils.isNotEmpty(indvSortedCustColl.getResults())) {
				individualCustomCollection.add(indvSortedCustColl.get(relationPosition));
				indvSeqNumber = Double.valueOf(individualCustomCollection.getResult(0).getIndv_seq_num()).intValue();

				pageCollection = abHouseHoldRelationshipBO.loadHousholdRelationshipDetails(appNumber, indvSeqNumber);

				for (int index = relationPosition + 1; index < indvSortSize; index++) {
					individualReferenceCollection.add(indvSortedCustColl.getResult(index));
				}

				if (!detailKeyFlag && (pageStatus != FwConstants.DRIVER_COMPLETE)) {
					populateRecordArray(
							new IndivTypeSeqBean(individualCustomCollection.getResult(0).getIndv_seq_num(),
									FwConstants.EMPTY_STRING, FwConstants.EMPTY_STRING),
							fwTransaction.getPageCollection());
				}

				final boolean pregStatus = abHouseHoldRelationshipBO.runPregChk(appInPrflSessionColl,
						individualCustomCollection);

				List relationList = null;
				if (pageCollection.containsKey("RelationList")) {
					relationList = (ArrayList) pageCollection.get("RelationList");
				}

				final APP_HSHL_RLT_Collection careTakerColl = abHouseHoldRelationshipBO
						.runCareTakerCheck(individualCustomCollection, appNumber);
				NO_ONE_Collection pageNoOneColl = null;
				if ((careTakerColl != null) && (!careTakerColl.isEmpty())) {
					final int careTakerSize = careTakerColl.size();
					final Map careTakerMap = new HashMap();
					// now i am making map and the collection
					careTakerCustColl = new INDIVIDUAL_Custom_Collection();
					APP_HSHL_RLT_Cargo careTakerCargo = null;
					boolean foundFlag = false;
					for (int i = 0; i < careTakerSize; i++) {
						careTakerCargo = careTakerColl.getCargo(i);
						// now i am checking that person exit in the people
						// handler.
						if (peopleHandler.getIndividual(String.valueOf(careTakerCargo.getSrc_indv_seq_num())) != null) {
							careTakerCustColl.add(
									peopleHandler.getIndividual(String.valueOf(careTakerCargo.getSrc_indv_seq_num())));
							if (FwConstants.YES.equals(careTakerCargo.getCare_resp())) {
								careTakerMap.put(careTakerCargo.getSrc_indv_seq_num(), "R");
							} else {
								careTakerMap.put(careTakerCargo.getSrc_indv_seq_num(), FwConstants.SPACE);
							}
							foundFlag = true;
						}
					}
					if (foundFlag) {
						pageCollection.put("INDIVIDUAL_CareTaker_Collection", careTakerCustColl);
						pageCollection.put(APP_HSHL_RLT_CARETAKER_COLLECTION, careTakerColl);
						pageCollection.put("CareTakerMap", careTakerMap);
					}

					if (((pageStatus == FwConstants.DRIVER_VISIT_AGAIN) || (pageStatus == FwConstants.DRIVER_COMPLETE))
							&& (careTakerMap != null) && !careTakerMap.containsValue("R")) {
						pageNoOneColl = new NO_ONE_Collection();
						final NO_ONE_Cargo noOneCargo = new NO_ONE_Cargo();
						noOneCargo.setNo_one_name(FwConstants.EMPTY_STRING);
						pageNoOneColl.add(new NO_ONE_Cargo());
						pageCollection.put("NO_ONE_Collection", pageNoOneColl);
					}
				}

				pageCollection.put("INDV_SRC_CUST_Collection", individualCustomCollection);
				pageCollection.put("INDV_REF_CUST_Collection", individualReferenceCollection);
				pageCollection.put("SortedColl", indvSortedCustColl);
				pageCollection.put("PregPrflStatus", Boolean.valueOf(pregStatus));
				pageCollection.put("snapFlag", snapFlag);
				pageCollection.put("maFlag", maFlag);
				pageCollection.put("tanfFlag", tanfFlag);
				pageCollection.put("ccFlag", ccFlag);
				pageCollection.put(AppConstants.INDV_SEQUENCE_NUMBERS, String.valueOf(indvSeqNumber));
			}
		}
		pageCollection.put(currentPageStatus, String.valueOf(pageStatus));
		fwTransaction.setPageCollection(pageCollection);
		if (beforeColl == null) {
			beforeColl = new HashMap();
		}
		// vgundlap
		pageCollection.put("detailKeyFlag", detailKeyFlag);
		beforeColl.putAll(pageCollection);
		// EDSP CP starts: Program specific logic
		pageCollection = displayProgramSpecificInfo(pageCollection);
		// EDSP CP ends: Program specific logic
      }catch(Exception e) {
    	  FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.prepareHouseHoldRelation()", fwTransaction);
    	  throw e;
      }
      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.prepareHouseHoldRelation() - END", fwTransaction);
	}

	/**
	 * EDSP CP: added new method.
	 *
	 * @param session        the session
	 * @param pageCollection the page collection
	 * @return the map
	 */
	private Map displayProgramSpecificInfo(final Map pageCollection) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.prepareHouseHoldRelation() - START");

		boolean isFMARequestedFlag = false;
		boolean isCCRequestedFlag = false;
		boolean isSNAPRequestedFlag = false;
		boolean isTANFRequestedFlag = false;
		boolean isEARequestedFlag = false;
		final List cmpList = (ArrayList) pageCollection.get("PAGE_COMPONENT_LIST");

		pageCollection.put("PROGRAM_SPECIFIC_FLAG", true);
		pageCollection.put("PAGE_COMPONENT_LIST", cmpList);

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.prepareHouseHoldRelation() - END");
		return pageCollection;
	}

	/**
	 * Store house hold relationship details. AFB
	 *
	 * @param fwTransaction the txn bean @
	 */
	@Transactional
	public void storeHouseHoldRelationshipDetails(final FwTransaction fwTransaction) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldRelationshipDetails() - START", fwTransaction);
		final Map pageCollection = fwTransaction.getPageCollection();
		int[] driverArray = null;
		short[] programKeyArray = null;
		String appNumber = null;
		String pageId = null;
		int currentPageStatus = 0;
		Map beforeColl = null;
		APP_HSHL_RLT_Collection appHshlRltBeforeColl = null;
		APP_HSHL_RLT_Cargo appHshlRltCargo = null;
		APP_HSHL_RLT_Cargo appHshlRltBeforeCargo = null;

		APP_HSHL_RLT_Cargo appCareTakerHshlCargo = null;
		APP_HSHL_RLT_Cargo appCareTakerHshlBeforeCargo = null;
		APP_HSHL_RLT_Collection appCareTakerHshlColl = null;
		APP_HSHL_RLT_Collection appCareTakerHshlBeforeColl = null;

		INDIVIDUAL_Custom_Collection sortedColl = null;
		NO_ONE_Collection pageNoOneColl = null;
		APP_IN_PREG_Collection appPregColl = null;
		APP_IN_PREG_Collection appPregBeforeColl = null;
		APP_IN_PREG_Cargo appPregCargo = null;
		APP_IN_PREG_Cargo appPregBeforeCargo = null;
		boolean snapFlag = false;
		boolean maFlag = false;
		boolean tanfFlag = false;
		boolean ccFlag = false;
		boolean wicFlag = false;
		String validationPregnancy = "N";

		FwMessageList validateInfo = null;
		int indvSeqNumber = 1;
		int sortedCollSize = 0;
		String language = null;
		boolean validateCareTaker = false;
		try {
			appNumber = fwTransaction.getUserDetails().getAppNumber();
			pageId = fwTransaction.getCurrentActionDetails().getPageId();
			boolean scheduleABHMS = false;

			beforeColl = fwTransaction.getPageCollection();
			CASE_PROGRAMS_Collection programsCollection = (CASE_PROGRAMS_Collection) fwTransaction.getPageCollection()
					.get("CASE_PROGRAMS_Collection");

			if (Objects.nonNull(programsCollection) && ArrayUtils.isNotEmpty(programsCollection.getResults())) {
				CASE_PROGRAMS_Cargo caseProgramsCargo = (CASE_PROGRAMS_Cargo) programsCollection.get(0);
				snapFlag = Boolean.valueOf(String.valueOf(caseProgramsCargo.getSnapFlag()));
				maFlag = Boolean.valueOf(String.valueOf(caseProgramsCargo.getMaFlag()));
				tanfFlag = Boolean.valueOf(String.valueOf(caseProgramsCargo.getTanfFlag()));
			}

			final boolean[] checkProgramsRequested = { ccFlag, maFlag, snapFlag, tanfFlag, wicFlag };

			if (beforeColl != null) {
				if (beforeColl.containsKey("SortedColl")) {
					sortedColl = (INDIVIDUAL_Custom_Collection) beforeColl.get("SortedColl");
				}
				if (beforeColl.containsKey("APP_HSHL_RLT_Collection")) {
					appHshlRltBeforeColl = (APP_HSHL_RLT_Collection) beforeColl.get("APP_HSHL_RLT_Collection");
				}

				// VACMS start - dont need this questions

				if (beforeColl.containsKey("APP_IN_PREG_Collection")) {
					appPregBeforeColl = (APP_IN_PREG_Collection) beforeColl.get("APP_IN_PREG_Collection");
				}

				if (beforeColl.containsKey(APP_HSHL_RLT_CARETAKER_COLLECTION)) {
					appCareTakerHshlBeforeColl = (APP_HSHL_RLT_Collection) beforeColl
							.get(APP_HSHL_RLT_CARETAKER_COLLECTION);
				}
				if (beforeColl.containsKey(AppConstants.INDV_SEQUENCE_NUMBERS)) {
					indvSeqNumber = Integer.parseInt((String) beforeColl.get(AppConstants.INDV_SEQUENCE_NUMBERS));
				}
			}
			if (sortedColl != null) {
				sortedCollSize = sortedColl.size();
			}
			APP_HSHL_RLT_Collection appHshlRltColl = (APP_HSHL_RLT_Collection) pageCollection
					.get("APP_HSHL_RLT_Collection");
			if (pageCollection != null) {
				if (pageCollection.containsKey("APP_HSHL_RLT_Collection")) {

					pageNoOneColl = (NO_ONE_Collection) pageCollection.get("NO_ONE_Collection");

					int appHshlSize = appHshlRltColl.size();
					appCareTakerHshlColl = new APP_HSHL_RLT_Collection();
					for (int i = 0; i < appHshlSize; i++) {
						appHshlRltCargo = appHshlRltColl.getCargo(i);
						if (appHshlRltCargo.getRlt_cd() == null) {
							appHshlRltColl.remove(i);
							i--;
							appHshlSize--;
							appCareTakerHshlColl.add(appHshlRltCargo);
						}

						if (appHshlRltCargo.getPhy_boe_sep_sw() == null) {
							appHshlRltCargo.setPhy_boe_sep_sw(FwConstants.SPACE);
						} else if (FwConstants.EMPTY_STRING
								.equalsIgnoreCase(appHshlRltCargo.getPhy_boe_sep_sw().trim())) {
							appHshlRltCargo.setPhy_boe_sep_sw(FwConstants.SPACE);
						}
					}
				}
				if (pageCollection.containsKey("APP_IN_PREG_Collection")) {
					appPregColl = (APP_IN_PREG_Collection) pageCollection.get("APP_IN_PREG_Collection");
				}
			}
			abHouseHoldRelationshipBO.setProgramKey(programKeyArray);
			if ((appHshlRltCargo != null) && ((appHshlRltCargo.getPhy_boe_sep_sw() == null)
					|| FwConstants.EMPTY_STRING.equalsIgnoreCase(appHshlRltCargo.getPhy_boe_sep_sw().trim()))) {
				appHshlRltCargo.setPhy_boe_sep_sw(FwConstants.SPACE);
			}

			if (maFlag || tanfFlag || ccFlag) {
				validateCareTaker = true;
			}

			// TODO: Validation performed at UI, Modify at backend if required.

			boolean completeCareFlg = true;
			final List componentList = (ArrayList) beforeColl.get(FwConstants.PAGE_COMPONENT_LIST);
			if (Objects.nonNull(appCareTakerHshlBeforeColl)
					&& !ArrayUtils.isEmpty(appCareTakerHshlBeforeColl.getResults())) {
				if (componentList.contains("32")) {
					completeCareFlg = false;
				}

				if ((appCareTakerHshlColl != null) && (!appCareTakerHshlColl.isEmpty())) {
					appCareTakerHshlCargo = appCareTakerHshlColl.getCargo(0);
					completeCareFlg = true;
				}

				APP_HSHL_RLT_Collection updatedCareTakerColl = null;
				final int careTakerSize = appCareTakerHshlBeforeColl.size();
				for (int i = 0; i < careTakerSize; i++) {
					appCareTakerHshlBeforeCargo = appCareTakerHshlBeforeColl.getCargo(i);

					boolean careTaker = false;
					for (int j = 0; (appCareTakerHshlColl != null) && (appCareTakerHshlColl.size() > j); j++) {
						appCareTakerHshlCargo = appCareTakerHshlColl.getCargo(j);
						if ((appCareTakerHshlCargo != null) && appCareTakerHshlBeforeCargo.getSrc_indv_seq_num()
								.equals(appCareTakerHshlCargo.getRef_indv_seq_num())) {
							careTaker = true;
							break;
						}
					}
					if (careTaker) {
						if (!FwConstants.YES.equals(appCareTakerHshlBeforeCargo.getCare_resp())) {
							// we need to update this record.
							if (updatedCareTakerColl == null) {
								updatedCareTakerColl = new APP_HSHL_RLT_Collection();
							}
							appCareTakerHshlBeforeCargo.setCare_resp(FwConstants.YES);
							appCareTakerHshlBeforeCargo.setChg_eff_dt(AppConstants.HIGH_DATE);
							if (appCareTakerHshlBeforeCargo.getSrc_app_ind() == null) {
								appCareTakerHshlBeforeCargo.setChg_eff_dt(FwConstants.SPACE);
							}
							if (appCareTakerHshlBeforeCargo.getPhy_boe_sep_sw() == null) {
								appCareTakerHshlBeforeCargo.setPhy_boe_sep_sw(FwConstants.SPACE);
							} else if (FwConstants.EMPTY_STRING
									.equalsIgnoreCase(appCareTakerHshlBeforeCargo.getPhy_boe_sep_sw().trim())) {
								appCareTakerHshlBeforeCargo.setPhy_boe_sep_sw(FwConstants.SPACE);
							}
							updatedCareTakerColl.add(appCareTakerHshlBeforeCargo);
						}
					} else
					// response
					// if any one of those is YES make it as NO
					if (FwConstants.YES.equals(appCareTakerHshlBeforeCargo.getCare_resp())) {
						// we need to update
						if (updatedCareTakerColl == null) {
							updatedCareTakerColl = new APP_HSHL_RLT_Collection();
						}
						appCareTakerHshlBeforeCargo.setCare_resp(FwConstants.NO);
						appCareTakerHshlBeforeCargo.setChg_eff_dt(AppConstants.HIGH_DATE);

						if (appCareTakerHshlBeforeCargo.getSrc_app_ind() == null) {
							appCareTakerHshlBeforeCargo.setChg_eff_dt(FwConstants.SPACE);
						}

						if (appCareTakerHshlBeforeCargo.getPhy_boe_sep_sw() == null) {
							appCareTakerHshlBeforeCargo.setPhy_boe_sep_sw(FwConstants.SPACE);
						} else if (FwConstants.EMPTY_STRING
								.equalsIgnoreCase(appCareTakerHshlBeforeCargo.getPhy_boe_sep_sw().trim())) {
							appCareTakerHshlBeforeCargo.setPhy_boe_sep_sw(FwConstants.SPACE);
						}

						updatedCareTakerColl.add(appCareTakerHshlBeforeCargo);
					}

					if (updatedCareTakerColl != null) {
						abHouseHoldRelationshipBO.storeHousholdRelationshipDetails(updatedCareTakerColl, null, null,
								FwConstants.ROWACTION_UPDATE);
					}

				}
			}
			// for the relation ship cargo
			if (Objects.nonNull(appHshlRltColl) && ArrayUtils.isNotEmpty(appHshlRltColl.getResults())) {
				final int appHshlRltCollSize = appHshlRltColl.size();
				APP_HSHL_RLT_Collection appHshlRltDataColl = null;
				boolean foundFlag = false;
				Integer srcSeqNum = null;
				Integer refSeqNum = null;
				boolean completeRltFlag = true;
				for (int i = 0; i < appHshlRltCollSize; i++) {
					completeRltFlag = true;
					appHshlRltCargo = appHshlRltColl.getCargo(i);
					appHshlRltCargo.setApp_num(appNumber);
					// Source app indicator and change effective date default
					// values population PCR # 29768
					appHshlRltCargo.setChg_eff_dt(AppConstants.HIGH_DATE);
					appHshlRltCargo.setSrc_app_ind(FwConstants.SPACE);
					if (appHshlRltCargo.getCare_resp() == null) {
						// VACMS start - converting radio to check box

						// VACMS end - converting radio to check box
						// VACMS start - converting radio to check box
						appHshlRltCargo.setCare_resp(FwConstants.NO);
						// VACMS end - converting radio to check box

					}

					if (appHshlRltCargo.getPhy_boe_sep_sw() == null) {
						appHshlRltCargo.setPhy_boe_sep_sw(FwConstants.SPACE);

					} else if (FwConstants.EMPTY_STRING.equalsIgnoreCase(appHshlRltCargo.getPhy_boe_sep_sw().trim())) {
						appHshlRltCargo.setPhy_boe_sep_sw(FwConstants.SPACE);

					}

					if (!CollectionUtils.isEmpty(componentList) && componentList.contains("31")) {
						final INDIVIDUAL_Custom_Collection tempIndvCustColl = peopleHandler
								.getInAndOutOfHomeIndividuals(appNumber);
						final Integer tempSrcSeqNum = appHshlRltCargo.getSrc_indv_seq_num();
						final Integer tempRefSeqNum = appHshlRltCargo.getRef_indv_seq_num();
						// call method to get all out side home children
						// indev seq num list
						final List outHomeIndvSeqNumList = abHouseHoldMemberBO
								.getOutSideHomeIndvSeqNum(tempIndvCustColl);
						if (outHomeIndvSeqNumList != null && (outHomeIndvSeqNumList.contains(tempSrcSeqNum)
								|| outHomeIndvSeqNumList.contains(tempRefSeqNum))) {
							completeRltFlag = true;
						}

					}

					if (completeRltFlag && completeCareFlg) {
						appHshlRltCargo.setRec_cplt_ind(FwConstants.ONE);
					} else {
						appHshlRltCargo.setRec_cplt_ind(FwConstants.ZERO);
					}
					foundFlag = false;
					srcSeqNum = appHshlRltCargo.getSrc_indv_seq_num();
					refSeqNum = appHshlRltCargo.getRef_indv_seq_num();

					// now we are comparing the data
					if ((appHshlRltBeforeColl != null) && (!appHshlRltBeforeColl.isEmpty())) {
						final int appHshlRltBeforeCollSize = appHshlRltBeforeColl.size();
						for (int j = 0; j < appHshlRltBeforeCollSize; j++) {
							appHshlRltBeforeCargo = appHshlRltBeforeColl.getCargo(j);
							if (appHshlRltBeforeCargo.getSrc_indv_seq_num().equals(srcSeqNum)
									&& appHshlRltBeforeCargo.getRef_indv_seq_num().equals(refSeqNum)) {
								appHshlRltCargo.setCare_resp(appHshlRltBeforeCargo.getCare_resp());
								appHshlRltCargo.setChg_eff_dt(appHshlRltBeforeCargo.getChg_eff_dt());
								appHshlRltCargo.setSrc_app_ind(appHshlRltBeforeCargo.getSrc_app_ind());

								foundFlag = true;
								break;
							}
						}
					}
					if (!foundFlag) {
						if (appHshlRltDataColl == null) {
							appHshlRltDataColl = new APP_HSHL_RLT_Collection();
						}
						appHshlRltDataColl.add(appHshlRltCargo);
					}
					// now i am updating the people handler
					if (null != refSeqNum && FwConstants.ONE.equals(refSeqNum.toString().trim())) {
						// now i need to update people handler
						peopleHandler.setRelationshipCode(srcSeqNum, appHshlRltCargo.getRlt_cd(), appNumber);
					} else if (null != srcSeqNum
							&& FwConstants.ONE.toString().trim().equals(srcSeqNum.toString().trim())) {
						// now i need to get reverse relation ,first i need to get the srcSeqNum gender
						INDIVIDUAL_Custom_Cargo individual = peopleHandler.getIndividual(String.valueOf(srcSeqNum));

						if (Objects.isNull(individual)) {
							// Refreshing peopleHandler cache map to verify
							peopleHandler.loadPeopleHandler(appNumber);
							individual = peopleHandler.getIndividual(String.valueOf(srcSeqNum));
						}

						String gender = individual.getSex_ind();
						final String relation = appHshlRltCargo.getRlt_cd();
						if (AppConstants.SEX_IND_MALE.equals(gender)) {
							// i need to get reverse relation for the male
							peopleHandler.setRelationshipCode(refSeqNum,
									referenceTableManager.getColumnValue("TREL", 69, relation, FwConstants.ENGLISH),
									appNumber);
						} else {
							// i need to get reverse relation for the female
							peopleHandler.setRelationshipCode(refSeqNum,
									referenceTableManager.getColumnValue("TREL", 70, relation, FwConstants.ENGLISH),
									appNumber);
						}
					}
				}
				if (Objects.nonNull(appHshlRltBeforeColl) && !ArrayUtils.isEmpty(appHshlRltBeforeColl.getResults())) {
					final int appHshlRltBeforeCollSize = appHshlRltBeforeColl.size();
					for (int i = 0; i < appHshlRltBeforeCollSize; i++) {
						appHshlRltBeforeCargo = appHshlRltBeforeColl.getCargo(i);
						if (appHshlRltDataColl == null) {
							appHshlRltDataColl = new APP_HSHL_RLT_Collection();
						}
						appHshlRltDataColl.add(appHshlRltBeforeCargo);
					}
				}

				// Change the effective date format
				if (appHshlRltDataColl != null) {
					final int appHshlSize = appHshlRltDataColl.size();
					for (int i = 0; i < appHshlSize; i++) {
						final APP_HSHL_RLT_Cargo appHshlRltDataCargo = appHshlRltDataColl.getCargo(i);
						appHshlRltDataCargo.setChg_eff_dt(AppConstants.HIGH_DATE);
					}
				}

				if (Objects.nonNull(appHshlRltDataColl) && !ArrayUtils.isEmpty(appHshlRltDataColl.getResults())) {
					// now we need to persist the collection
					abHouseHoldRelationshipBO.storeHousholdRelationshipDetails(appHshlRltDataColl, null, null,
							FwConstants.ROWACTION_UPDATE);

				}
			} else if (null!=appHshlRltBeforeColl
					&& !ArrayUtils.isEmpty(appHshlRltBeforeColl.getResults())) {
				final int appHshlRltBeforeCollSize = appHshlRltBeforeColl.size();
				for (int i = 0; i < appHshlRltBeforeCollSize; i++) {
					appHshlRltBeforeCargo = appHshlRltBeforeColl.getCargo(i);
				}
				// now we need to call the persist method
				abHouseHoldRelationshipBO.storeHousholdRelationshipDetails(appHshlRltBeforeColl, null, null,
						FwConstants.ROWACTION_DELETE);
			}
			/** removing the last indv (youngest) relationship */
			try {
				INDIVIDUAL_Custom_Collection indvSortedCustColl = peopleHandler
						.sortIndividualsByAge(peopleHandler.getInAndOutOfHomeIndividuals(appNumber));
				if (indvSortedCustColl != null && !indvSortedCustColl.isEmpty()) {
					int size = indvSortedCustColl.size();
					INDIVIDUAL_Custom_Cargo individualCustomCargo = (INDIVIDUAL_Custom_Cargo) indvSortedCustColl
							.get(size - 1);
					final APP_HSHL_RLT_Collection appHSHLRLTCollection = new APP_HSHL_RLT_Collection();
					APP_HSHL_RLT_Cargo appHSHLRLTCargo = new APP_HSHL_RLT_Cargo();
					appHSHLRLTCargo.setApp_num(appNumber);
					int indvSeqNumcheck = Integer.parseInt(individualCustomCargo.getIndv_seq_num());
					appHSHLRLTCargo.setSrc_indv_seq_num(indvSeqNumcheck);
					appHSHLRLTCollection.add(appHSHLRLTCargo);
					APP_HSHL_RLT_Cargo[] appHSHLRLTCargos = abHouseHoldRelationshipBO
							.findRelationsByIndvSeqNum(appHSHLRLTCollection);
					if (appHSHLRLTCargos != null && appHSHLRLTCargos.length != 0) {

						appHSHLRLTCollection.clear();
						appHSHLRLTCollection.setResults(appHSHLRLTCargos);
					}

				}
			} catch (Exception exception) {
				FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_HOUSEHOLD_RELATIONSHIP_DETAILS, fwTransaction);
				throw exception;
			}

			// for the preg cargo
			// VACMS start - dont need this

			if ((null!=appPregColl && ArrayUtils.isNotEmpty(appPregColl.getResults()))
					&& ((appPregColl.getCargo(0).getFetus_ct() != null)
							|| (appPregColl.getCargo(0).getPreg_due_dt() != null)
							|| (appPregColl.getCargo(0).getConception_dt() != null))) {
				appPregCargo = appPregColl.getCargo(0);
				appPregCargo.setApp_num(appNumber);
				// Source app indicator and change effective date default values
				// population PCR # 29768
				appPregCargo.setSrc_app_ind(FwConstants.SPACE);
				appPregCargo.setChg_eff_dt(AppConstants.HIGH_TIMESTAMP);
				appPregCargo.setIndv_seq_num(String.valueOf(indvSeqNumber));
				if ((appPregCargo.getPreg_due_dt() != null) && (appPregCargo.getPreg_due_dt().trim().length() > 0)) {
					final StringBuilder dateConverter = new StringBuilder();
					final String sAppDate = appPregCargo.getPreg_due_dt();
					dateConverter.append(sAppDate, 6, 10).append("-").append(sAppDate.substring(0, 2)).append("-")
							.append(sAppDate.substring(3, 5));
					appPregCargo.setPreg_due_dt(dateConverter.toString());
				}
				if ((appPregCargo.getConception_dt() == null)
						|| (appPregCargo.getConception_dt().trim().length() == 0)) {
					appPregCargo.setConception_dt(AppConstants.LOW_DATE);
				} else {
					final StringBuilder dateConverter = new StringBuilder();
					final String sAppDate = appPregCargo.getConception_dt();
					dateConverter.append(sAppDate, 6, 10).append("-").append(sAppDate.substring(0, 2)).append("-")
							.append(sAppDate.substring(3, 5));
					appPregCargo.setConception_dt(dateConverter.toString());
				}
				if ((appPregCargo.getFetus_ct() == null)
						|| FwConstants.EMPTY_STRING.equals(appPregCargo.getFetus_ct().trim())) {
					appPregCargo.setFetus_ct(FwConstants.ZERO);
				}

				appPregCargo.setRec_cplt_ind(FwConstants.ONE);

				/*
				 * VG SONAR Cleanup - 08/26/2015 Deleted 1 lines Commented Code in this block
				 */

				if ((appPregBeforeColl != null) && (!appPregBeforeColl.isEmpty())) {
					appPregBeforeCargo = appPregBeforeColl.getCargo(0);
					// Setting Default values if the before cargo values are null PCR # 29768
					if (appPregBeforeCargo.getSrc_app_ind() == null) {
						appPregBeforeCargo.setSrc_app_ind(FwConstants.SPACE);
					}
					if (appPregBeforeCargo.getChg_eff_dt() == null) {
						appPregBeforeCargo.setChg_eff_dt(AppConstants.HIGH_TIMESTAMP);
					}
					abHouseHoldRelationshipBO.storeHousholdRelationshipDetails(null, appPregColl, null,
							FwConstants.ROWACTION_INSERT);
				} else {
					abHouseHoldRelationshipBO.storeHousholdRelationshipDetails(null, appPregColl, null,
							FwConstants.ROWACTION_INSERT);
				}
			} else if ((beforeColl.get("detailKeyFlag") != null) && (Boolean) beforeColl.get("detailKeyFlag")
					&& tanfFlag) {
				final APP_IN_PREG_Collection coll = new APP_IN_PREG_Collection();
				final APP_IN_PREG_Cargo cargo = new APP_IN_PREG_Cargo();
				cargo.setApp_num(appNumber);
				cargo.setSrc_app_ind(FwConstants.SPACE);
				cargo.setIndv_seq_num(String.valueOf(indvSeqNumber));
				cargo.setRec_cplt_ind(FwConstants.ONE);
				coll.add(cargo);
				final APP_IN_PREG_Cargo[] cargoArray = abHouseHoldRelationshipBO.findByKey(coll, "AB");
				if ((cargoArray != null) && (cargoArray.length == 0)) {
					abHouseHoldRelationshipBO.storeHousholdRelationshipDetails(null, coll, null,
							FwConstants.ROWACTION_INSERT);
				}
			}

			final INDIVIDUAL_Custom_Collection sortedIndvCustColl = peopleHandler
					.sortIndividuals(peopleHandler.getInHomeIndividuals(appNumber));
			if ((sortedIndvCustColl != null) && (!sortedIndvCustColl.isEmpty())) {
				final APP_IN_PRFL_Collection appPrflColl = (APP_IN_PRFL_Collection) fwTransaction.getPageCollection()
						.get(AppConstants.APP_IN_PRFL_MASTER);
				final int indvCustCollSize = sortedIndvCustColl.size();
				INDIVIDUAL_Custom_Cargo sortedIndvCustCargo = null;
				final APP_IN_PRFL_Collection newAppPrflColl = new APP_IN_PRFL_Collection();
				for (int i = 0; i < indvCustCollSize; i++) {
					sortedIndvCustCargo = sortedIndvCustColl.getResult(i);
				}
				fwTransaction.getPageCollection().put(AppConstants.APP_IN_PRFL_MASTER, newAppPrflColl);
			}

			boolean pageComplete = false;
			boolean lastRecord = false;

			if ((currentPageStatus == FwConstants.DRIVER_REQUIRED)
					|| (currentPageStatus == FwConstants.DRIVER_VISIT_AGAIN)) {

				// now i am checking is they any persons we have to display
				final int currentArrayIndex = Integer
						.parseInt((String) beforeColl.get(FwConstants.CURRENT_RECORD_INDEX));

				if ((currentArrayIndex + 1) == sortedCollSize) {
					pageComplete = true;
				}
				if ((currentArrayIndex + 2) == sortedCollSize) {
					lastRecord = true;

					// Added by EDSP
					final INDIVIDUAL_Custom_Collection indvSrcCustColl = new INDIVIDUAL_Custom_Collection();
					if (sortedColl != null) {
						indvSrcCustColl.add(sortedColl.get(sortedCollSize - 1));
					}
					// now we need to run the rules
					// first we need to run the preg check
					final boolean pregChk = abHouseHoldRelationshipBO.runPregChk((APP_IN_PRFL_Collection) fwTransaction
							.getPageCollection().get(AppConstants.APP_IN_PRFL_MASTER), indvSrcCustColl);

					if (!pregChk) {
						final APP_HSHL_RLT_Collection careTakerColl = abHouseHoldRelationshipBO
								.runCareTakerCheck(indvSrcCustColl, appNumber);

						if ((careTakerColl == null) || (careTakerColl.isEmpty())) {
							pageComplete = true;
						}
					}
				}

			}

			// if the driver status is addnew and driver status is complete
			if ((currentPageStatus == FwConstants.DRIVER_ADD_NEW)
					|| (currentPageStatus == FwConstants.DRIVER_COMPLETE)) {
				pageComplete = true;
			}
			// if page complete true last record is false
			if (pageComplete) {
				lastRecord = false;
			}

			// this is last record flag
			pageCollection.put("LastRecordFlag", Boolean.valueOf(lastRecord));
			// this is page complete flag
			pageCollection.put("PageCompleteFlag", Boolean.valueOf(pageComplete));

			fwTransaction.setPageCollection(pageCollection);

		} catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_HOUSEHOLD_RELATIONSHIP_DETAILS, fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			STORE_HOUSEHOLD_REL_DET, fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldRelationshipDetails() - END", fwTransaction);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeFixMealsPersonSelection(FwTransaction fwTransaction) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldRelationshipDetails() - START", fwTransaction);
		try {

			UserDetails userDetails = fwTransaction.getUserDetails();
			String appNum = userDetails.getAppNumber();

			Map beforeColl = null;
			ArrayList<Integer> indvCheckArray;
			APP_INDV_Cargo appIndvCarg = null;
			beforeColl = fwTransaction.getPageCollection();
			OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection;
			OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo = null;

			if (beforeColl != null && beforeColl.containsKey("fixMealArray")) {

				validateFixMealColl(appNum, beforeColl);
			}
		} catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_HOUSEHOLD_RELATIONSHIP_DETAILS, fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeFixMealsPersonSelection", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.storeHouseHoldRelationshipDetails() - END", fwTransaction);

	}

	private void validateFixMealColl(String appNum, Map beforeColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.validateFixMealColl() - START");
		ArrayList<Integer> indvCheckArray;
		OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection;
		OTHER_HOUSEHOLD_DETAILS_Cargo otherHouseholdDetailsCargo;
		indvCheckArray = (ArrayList<Integer>) beforeColl.get("fixMealArray");
		caretakerSelectionBO.updateFixMealsAsEmptyByAppNum(appNum);
		for (int i = 0; i < indvCheckArray.size(); i++) {
			String cast = String.valueOf(indvCheckArray.get(i));
			if (!FALSE.equals(cast)) {
				int indvSeqNum = Integer.parseInt(cast);
				otherHouseholdDetailsCollection = (OTHER_HOUSEHOLD_DETAILS_Collection) caretakerSelectionBO
						.loadCaretakerExisitingDetail(appNum, indvSeqNum);
				if (null != otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty()) {
					otherHouseholdDetailsCargo = otherHouseholdDetailsCollection.getCargo(0);
					otherHouseholdDetailsCargo.setFix_meal_personselection_resp("Y");

				} else {
					otherHouseholdDetailsCargo = new OTHER_HOUSEHOLD_DETAILS_Cargo();
					otherHouseholdDetailsCargo.setFix_meal_personselection_resp("Y");
					otherHouseholdDetailsCargo.setIndv_seq_num(indvSeqNum);
					otherHouseholdDetailsCargo.setApp_num(appNum);
				}
				if (null != otherHouseholdDetailsCollection) {
					otherHouseholdDetailsCollection.clear();
					otherHouseholdDetailsCollection.addCargo(otherHouseholdDetailsCargo);
				}
				if (null != otherHouseholdDetailsCollection && !otherHouseholdDetailsCollection.isEmpty()
						&& Objects.nonNull(otherHouseholdDetailsCollection)
						&& !ArrayUtils.isEmpty(otherHouseholdDetailsCollection.getResults())) {
					caretakerSelectionBO.saveCaretakerPersonDetail(otherHouseholdDetailsCollection);
				}
			}

		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.validateFixMealColl() - END");
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getFixMealsPersonSelection(FwTransaction fwTransaction) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getFixMealsPersonSelection() - START", fwTransaction);
		try {

			Map<Object, Object> pageCollection = fwTransaction.getPageCollection();

			UserDetails userDetails = fwTransaction.getUserDetails();
			String appNum = userDetails.getAppNumber();

			APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
			List<APP_INDV_Cargo> appIndvCargoList = fixMealsPersonSelectionBO.getAllAPPIndividuals(appNum);
			if (appIndvCargoList != null && !appIndvCargoList.isEmpty()) {
				validateFixMealPrsnSel(appIndvCollection, appIndvCargoList);
			}
			pageCollection.put("APP_INDV_Collection", appIndvCollection);
		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.getFixMealsPersonSelection()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getFixMealsPersonSelection", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getFixMealsPersonSelection() - END", fwTransaction);
	}

	private void validateFixMealPrsnSel(APP_INDV_Collection appIndvCollection, List<APP_INDV_Cargo> appIndvCargoList) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.validateFixMealPrsnSel() - START");
		appIndvCargoList.forEach(appIndvCargo -> {
			if (appIndvCargo != null && appIndvCargo.getApp_num() != null
					&& appIndvCargo.getIndv_seq_num() != null) {
				APP_INDV_Cargo appCargo = new APP_INDV_Cargo();
				appCargo.setApp_num(appIndvCargo.getApp_num());
				appCargo.setIndv_seq_num(appIndvCargo.getIndv_seq_num());
				appCargo.setFst_nam(appIndvCargo.getFst_nam());
				appCargo.setLast_nam(appIndvCargo.getLast_nam());
				if (appIndvCargo.getSrc_app_ind() != null) {
					appCargo.setSrc_app_ind(appIndvCargo.getSrc_app_ind());
				} else {
					appCargo.setSrc_app_ind("AB");
				}
				if (appIndvCargo.getUnable_meal_dabl_sw() != null) {
					appCargo.setUnable_meal_dabl_sw(appIndvCargo.getUnable_meal_dabl_sw());
				}
				appIndvCollection.add(appCargo);
			}
		});
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.validateFixMealPrsnSel() - END");
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getRelationshipandBuyPrepareFoodDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getRelationshipandBuyPrepareFoodDetails() - START", fwTxn);
		try {

			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			CP_APP_HSHL_RLT_Collection cpAppHshlRltCollReqbeforeColl = null;
			CP_APP_HSHL_RLT_Collection newcoll = new CP_APP_HSHL_RLT_Collection();
			CP_APP_HSHL_RLT_Cargo cpapphshlcargo = new CP_APP_HSHL_RLT_Cargo();
			Map beforeColl = null;
			beforeColl = fwTxn.getPageCollection();
			if (beforeColl != null) {
				cpAppHshlRltCollReqbeforeColl = (CP_APP_HSHL_RLT_Collection) beforeColl.get(CP_APP_HSHL_RLT);
			}
			if (null != cpAppHshlRltCollReqbeforeColl && !cpAppHshlRltCollReqbeforeColl.isEmpty()) {
				cpapphshlcargo = cpAppHshlRltCollReqbeforeColl.getCargo(0);
			}

			String app_num = userDetails.getAppNumber();

			Integer src_indv_seq_num = cpapphshlcargo.getSrcIndvSeqNum();
			Integer ref_indv_seq_num = cpapphshlcargo.getRefIndvSeqNum();
			CP_APP_HSHL_RLT_Collection cpAppHshlRltColl = abHouseHoldRelationshipBO.loadRelationshipDetails(app_num);
			CP_APP_HSHL_RLT_Cargo cargoSes = null;
			if (cpAppHshlRltColl != null && cpAppHshlRltColl.size() > 0) {
				cargoSes = cpAppHshlRltColl.getCargo(0);
			} else {
				cargoSes = new CP_APP_HSHL_RLT_Cargo();
				cargoSes.setApp_num(app_num);
				cargoSes.setRefIndvSeqNum(ref_indv_seq_num);
				cargoSes.setSrcIndvSeqNum(src_indv_seq_num);
			}
			newcoll.addCargo(cargoSes);
			pageCollection.put(CP_APP_HSHL_RLT, newcoll);

		} catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.getRelationshipandBuyPrepareFoodDetails()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getRelationshipandBuyPrepareFoodDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsInvidualRelationsServiceImpl.getRelationshipandBuyPrepareFoodDetails() - END", fwTxn);
	}

	@Transactional
	public void deletePeopleSummary(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsIndividualRelationsService.deletePeopleSummary() - START", fwTxn);
		try {
		String appNum = fwTxn.getUserDetails().getAppNumber();
		Integer indivSeqNum = Integer.parseInt(
				fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
		abAbsentParentBo.deletePeopleSummary(appNum, indivSeqNum);
		getPeopleSummaryDetails(fwTxn);
		}catch(Exception exception) { 
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDemographicsInvidualRelationsServiceImpl.deletePeopleSummary()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"deletePeopleSummary", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDemographicsIndividualRelationsService.deletePeopleSummary() - END", fwTxn);
	}

}
