package gov.state.nextgen.householddemographics.responsewrappers;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.references.IReferenceConstants;
import gov.state.nextgen.access.management.references.IReferenceTableData;
import gov.state.nextgen.access.management.references.ReferenceTableManager;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.householddemographics.business.rules.PeopleHandler;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.HowAreYouRelated;
import gov.state.nextgen.householddemographics.model.IndividualDtls;
import gov.state.nextgen.householddemographics.model.PageResponse;
import gov.state.nextgen.householddemographics.model.RelationshipDtls;

@Component("ARHRL")
@Scope("prototype")
public class HowAreYouRelatedView extends PageResponse implements Serializable {

    private static final long serialVersionUID = 7047935070633342645L;

    private static final String PAGE_ID = "ARHRL";

    private static final String CODE_COLUMN_ID = "-999";

    private static final String DEFAULT_DROPDOWN_SEL = "SEL";

    @Autowired
    protected PeopleHandler peopleHandler;

    @Autowired
    private ReferenceTableManager referenceTableManager;

    /**
     * Construct Page Response.
     * @param fwTransaction
     * @return
     */
    public PageResponse constructPageResponse(FwTransaction fwTransaction) {
        DriverPageResponse driverPageResponse = new DriverPageResponse();
        Map<Object,Object> pageCollection = fwTransaction.getPageCollection();
        String appNum = String.valueOf(fwTransaction.getSession().get(FwConstants.APP_NUMBER));
        peopleHandler.getHouseholdIndividuals(appNum);

        List<HowAreYouRelated> howAreYouRelatedList = new ArrayList<>();
        HowAreYouRelated howAreYouRelated = new HowAreYouRelated();

        INDIVIDUAL_Custom_Collection INDV_REF_CUST_Collection = (INDIVIDUAL_Custom_Collection) pageCollection.get("INDV_REF_CUST_Collection");
        int refCustCollSize = INDV_REF_CUST_Collection.size();
        String dispText = null;
        if (null != INDV_REF_CUST_Collection) {
            if (INDV_REF_CUST_Collection.size() > 0) {
                dispText = "800000327";
            } else {
                dispText = "3018656";
            }
        }

        String originalSelected = null;
        String originalSrcIndvFirstName = null;
        String originalRefIndvFirstName = null;

        List relationList = (List) pageCollection.get("RelationList");
        if (relationList == null) {
            dispText = "800000960";
        }
        INDIVIDUAL_Custom_Collection INDV_SRC_CUST_Collection = (INDIVIDUAL_Custom_Collection) pageCollection.get("INDV_SRC_CUST_Collection");
        String chgDate = StringUtils.EMPTY;
        INDIVIDUAL_Custom_Cargo srcCustCargo = null;

        if (Objects.nonNull(INDV_SRC_CUST_Collection)) {
            srcCustCargo = INDV_SRC_CUST_Collection.getResult(0);
        }
        String[] sub = new String[2];
        String[] sub1 = new String[1];
        if (Objects.nonNull(srcCustCargo)) {
            sub[0] = srcCustCargo.getFst_nam();
            sub[1] = " ";
            sub1[0] = srcCustCargo.getFst_nam();
        }
        StringBuilder suffix = null;
        String selectedRel = null;
        int hshlRltCollSize = 0;
        String refIndvSeqNum = null;
        String srcIndvSeqNum = null;
		if (srcCustCargo != null) {
			srcIndvSeqNum = srcCustCargo.getIndv_seq_num();
		}

        APP_HSHL_RLT_Cargo appHshlRltCargo = null;
        String originalTogether = null;
        String originalTogetherDesc = null;
        String physicallyBuy = null;
        APP_HSHL_RLT_Collection relationCollection = null;

        if (pageCollection.get("RelationCollection") != null) {
            relationCollection = (APP_HSHL_RLT_Collection) pageCollection.get("RelationCollection");
        }

        APP_HSHL_RLT_Collection APP_HSHL_RLT_Collection = (APP_HSHL_RLT_Collection) pageCollection.get("APP_HSHL_RLT_Collection");

        if (APP_HSHL_RLT_Collection != null && APP_HSHL_RLT_Collection.size() > 0) {
            hshlRltCollSize = APP_HSHL_RLT_Collection.size();
            for (int j = 0; j < hshlRltCollSize; j++) {
                appHshlRltCargo = APP_HSHL_RLT_Collection.getCargo(j);
				if (null!= appHshlRltCargo.getSrc_indv_seq_num() && appHshlRltCargo.getSrc_indv_seq_num().toString().trim()
						.equals(srcIndvSeqNum) /* && appHshlRltCargo.getRef_indv_seq_num().equals(refIndvSeqNum) */) {
                    if ("RN".equals(appHshlRltCargo.getSrc_app_ind()) || "RM".equals(appHshlRltCargo.getSrc_app_ind())) {
                        selectedRel = appHshlRltCargo.getRlt_cd();
                        physicallyBuy = appHshlRltCargo.getPhy_boe_sep_sw();
                    } else if ("CW".equals(appHshlRltCargo.getSrc_app_ind())) {
                        originalSelected = appHshlRltCargo.getRlt_cd();
                        originalSrcIndvFirstName = peopleHandler.getFirstName(String.valueOf(appHshlRltCargo.getSrc_indv_seq_num()),appNum);
                        originalRefIndvFirstName = peopleHandler.getFirstName(String.valueOf(appHshlRltCargo.getRef_indv_seq_num()),appNum);
                        originalTogether = appHshlRltCargo.getPhy_boe_sep_sw();
                        originalTogetherDesc = referenceTableManager.getColumnValue("TYAN", 26, originalTogether, "EN");
                        //break
                    }
                }
            }
        }

        // setting values which are displayed on screen
        howAreYouRelated.setDispText(dispText);
        if (null != originalSelected) {
            howAreYouRelated.setOriginalSelectedYesNo(true);
        } else {
            howAreYouRelated.setOriginalSelectedYesNo(false);
        }
        howAreYouRelated.setSub(sub);
        howAreYouRelated.setSub1(sub1);

        List filteredList = new ArrayList();
        int filterSize = 0;
        int[] filterColumnId = null;
        String[] filterValue = null;
        int addSize = 0;
        String addFilter = null;
        List<RelationshipDtls> relationshipDtlsList = new ArrayList<RelationshipDtls>();
        for (int i = 0; i < refCustCollSize; i++) {
            RelationshipDtls relationshipDtls = new RelationshipDtls();
            INDIVIDUAL_Custom_Cargo refCustCargo = INDV_REF_CUST_Collection.getResult(i);
            refIndvSeqNum = refCustCargo.getIndv_seq_num();
            selectedRel = "";
            originalTogether = "";
            physicallyBuy = "";
            addSize = 0;
            addFilter = null;
            originalSelected = null;

            if (relationCollection != null) {
                //PCR 30937 - Corrected the filter logic for relations
                filteredList = filteredListRMC(relationCollection, srcIndvSeqNum, refIndvSeqNum);
            }

            filterSize = filteredList.size();

            filterColumnId = new int[filterSize + 1 + addSize];
            filterValue = new String[filterSize + 1 + addSize];

            filterColumnId[0] = 66;
            if (srcCustCargo.getSex_ind().equals(AppConstants.SEX_IND_FEMALE)) {
                filterValue[0] = AppConstants.SEX_IND_MALE;
            } else {
                filterValue[0] = AppConstants.SEX_IND_FEMALE;
            }

            for (int j = 1; j < filterSize + 1; j++) {
                filterColumnId[j] = IReferenceConstants.CODE_COLUMN_ID;
                filterValue[j] = (String) filteredList.get(j - 1);
            }
            if (addSize == 1) {
                filterColumnId[filterColumnId.length - 1] = IReferenceConstants.CODE_COLUMN_ID;
                filterValue[filterValue.length - 1] = addFilter;
            }

            sub[1] = refCustCargo.getFst_nam();
            suffix = new StringBuilder();
            suffix.append(FwConstants.FORM_PROPERTY_DYNAFORM_DELIMITER);
            suffix.append(srcCustCargo.getIndv_seq_num());
            suffix.append(FwConstants.FORM_PROPERTY_DYNAFORM_DELIMITER);
            suffix.append(refCustCargo.getIndv_seq_num());

	 		/* if (appInLqdAstFstCargo != null && appInLqdAstFstCargo.getSrc_indv_seq_num().equals(srcIndvSeqNum)
	 		        && appInLqdAstFstCargo.getRef_indv_seq_num().equals(refIndvSeqNum)) {
	 			appHshlRltCargo = appInLqdAstFstCargo
	 			selectedRel = appHshlRltCargo.getRlt_cd()
	 		    physicallyBuy = appHshlRltCargo.getPhy_boe_sep_sw()
	 		}
	 		else */

            if (APP_HSHL_RLT_Collection != null && APP_HSHL_RLT_Collection.size() > 0) {
                hshlRltCollSize = APP_HSHL_RLT_Collection.size();
                for (int j = 0; j < hshlRltCollSize; j++) {
                    appHshlRltCargo = APP_HSHL_RLT_Collection.getCargo(j);
                    if (null!=srcIndvSeqNum && null!=appHshlRltCargo.getSrc_indv_seq_num() && appHshlRltCargo.getSrc_indv_seq_num().toString().trim().equals(srcIndvSeqNum)
                            && null!=refIndvSeqNum && null!=appHshlRltCargo.getRef_indv_seq_num() && appHshlRltCargo.getRef_indv_seq_num().toString().trim().equals(refIndvSeqNum)) {
                        if ("CW".equals(appHshlRltCargo.getSrc_app_ind())) {
                            originalSelected = appHshlRltCargo.getRlt_cd();
                            originalSrcIndvFirstName = peopleHandler.getFirstName(String.valueOf(appHshlRltCargo.getSrc_indv_seq_num()),appNum);
                            originalRefIndvFirstName = peopleHandler.getFirstName(String.valueOf(appHshlRltCargo.getRef_indv_seq_num()),appNum);
                            originalTogether = appHshlRltCargo.getPhy_boe_sep_sw();
                            originalTogetherDesc = referenceTableManager.getColumnValue("TYAN", 26, originalTogether, "EN");
                            //break
                        } else {
                            selectedRel = appHshlRltCargo.getRlt_cd();
                            physicallyBuy = appHshlRltCargo.getPhy_boe_sep_sw();
                            chgDate = appHshlRltCargo.getChg_dt();
                        }
                    }
                }
            }

            if ((selectedRel == null || selectedRel.equals("")) && originalSelected != null)
                selectedRel = originalSelected;

            if ((null == physicallyBuy || ("").equals(physicallyBuy))
                    && (originalTogether != null && !originalTogether.equals("")))
                physicallyBuy = originalTogether;
		 		/* if (null != appInLqdAstSecCargo && appInLqdAstSecCargo.getSrc_indv_seq_num().equals(srcIndvSeqNum)
		 		        && appInLqdAstSecCargo.getRef_indv_seq_num().equals(refIndvSeqNum)) {
		 			originalSelected = appInLqdAstSecCargo.getRlt_cd()
		 		} */

            // Setting values to display on screen
            relationshipDtls.setOriginalSelected(originalSelected);
            relationshipDtls.setSub(sub);
            relationshipDtls.setSuffix(suffix.toString());
            relationshipDtls.setSelectedRel(selectedRel);
            relationshipDtls.setFilterColumnId(filterColumnId);
            relationshipDtls.setFilterValue(filterValue);
            relationshipDtls.setApplicableRelationShipCodes(getRelaventRelationshipCodes(filterColumnId, filterValue, "EN"));
            relationshipDtls.setPhysicallyBuy(physicallyBuy);

            relationshipDtls.setSourceIndividual(getIndividualFromCustomCargoDtls(srcCustCargo));
            relationshipDtls.setReferenceIndividual(getIndividualFromCustomCargoDtls(refCustCargo));

            if (originalSelected != null) {
                String relationship = referenceTableManager.getColumnValue("TREL", 65, originalSelected, "EN");
                relationshipDtls.setRelationship(relationship);
                relationshipDtls.setOriginalSrcIndvFirstName(originalSrcIndvFirstName);
                relationshipDtls.setOriginalRefIndvFirstName(originalRefIndvFirstName);
                relationshipDtls.setOriginalTogetherDesc(originalTogetherDesc);
            }
            relationshipDtlsList.add(relationshipDtls);
        }
        howAreYouRelated.setRelationshipDtlsList(relationshipDtlsList);
        if (refCustCollSize == 1) {
            if (null != chgDate) {
                if (!chgDate.trim().equals("")
                        && chgDate.length() >= 10) {
                    chgDate = chgDate.substring(0, 10);
                }
                if (chgDate.equals(AppConstants.HIGH_DATE)) {
                    chgDate = "";
                } else if (chgDate.length() == 10
                        && chgDate.charAt(4) == '-') {
                    chgDate = getMMDDYYYYDate(chgDate);
                }
            }
            howAreYouRelated.setSuffix(suffix.toString());
            howAreYouRelated.setChgDate(chgDate);
            howAreYouRelated.setChgDt(chgDate);
        }
        howAreYouRelatedList.add(howAreYouRelated);

        driverPageResponse.setCurrentPageID(PAGE_ID);
        driverPageResponse.setNextPageAction(String.valueOf(fwTransaction.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
        driverPageResponse.setNextPageID(String.valueOf(fwTransaction.getRequest().get(FwConstants.NEXT_PAGE_ID)));
        driverPageResponse.setPreviousPageID(String.valueOf(fwTransaction.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
        return driverPageResponse;
    }

    /**
     * getIndividualFromCustomCargoDtls
     * @param customIndividual
     * @return
     */
    private IndividualDtls getIndividualFromCustomCargoDtls(INDIVIDUAL_Custom_Cargo customIndividual) {
        IndividualDtls individual = new IndividualDtls();
        if (null != customIndividual) {
            individual.setFirstName(customIndividual.getFst_nam());
            individual.setGender(customIndividual.getSex_ind());
            individual.setAge(customIndividual.getIndv_age().getYears());
            individual.setIndvSeqNumber(customIndividual.getIndv_seq_num());
        }

        return individual;

    }

    /**
     * filteredListRMC
     * @param rltColl
     * @param srcSeqNumber
     * @param refSeqNumber
     * @return
     */
    public List filteredListRMC(final APP_HSHL_RLT_Collection rltColl, final String srcSeqNumber, final String refSeqNumber) {
        final int resSize = rltColl.size();
        APP_HSHL_RLT_Cargo rltCargo = null;
        Integer srcNumber = null;
        Integer refNumber = null;
        String rltCd = null;
        int parentSize=0;
        final List filterValues = new ArrayList();
        for (int i = 0; i < resSize; i++) {
            rltCargo = rltColl.getCargo(i);
            srcNumber = rltCargo.getSrc_indv_seq_num();
            refNumber = rltCargo.getRef_indv_seq_num();
            rltCd = rltCargo.getRlt_cd();
            if (null!=refNumber && refNumber.toString().trim().equals(srcSeqNumber)) {
                if ("FTR".equals(rltCd) && !isRefSeqNumberRelatedToOther(String.valueOf(refNumber), rltCd, rltColl)) {
                    filterValues.add("SON");
                } else if ("MTR".equals(rltCd) && !isRefSeqNumberRelatedToOther(String.valueOf(refNumber), rltCd, rltColl)) {
                    filterValues.add("DAU");
                } else if ("WIF".equals(rltCd) && !isRefSeqNumberRelatedToOther(String.valueOf(refNumber), rltCd, rltColl)) {
                    filterValues.add("HUS");
                } else if ("HUS".equals(rltCd) && !isRefSeqNumberRelatedToOther(String.valueOf(refNumber), rltCd, rltColl)) {
                    filterValues.add("WIF");
                }
            }

			/*if (refNumber.equals(refSeqNumber) && !srcSeqNumber.equals(srcNumber)) {
				if ("FTR".equals(rltCd) && !isRefSeqNumberRelatedToOther(refNumber, rltCd, rltColl)) {
					filterValues.add("FTR");
				} else if ("MTR".equals(rltCd) && !isRefSeqNumberRelatedToOther(refNumber, rltCd, rltColl)) {
					filterValues.add("MTR");
				}
			}*/

            if (null!=refNumber && null!=srcNumber && refNumber.toString().trim().equals(refSeqNumber) && !srcSeqNumber.equals(srcNumber.toString().trim())) {
                if("FTR".equals(rltCd) || "MTR".equals(rltCd)){
                    parentSize=parentSize+1;
                }
                if(parentSize>=2){
                    filterValues.add("FTR");
                    filterValues.add("MTR");
                }
            }
        }
        return filterValues;
    }

    /**
     * isRefSeqNumberRelatedToOther
     * @param aRefSeqNumber
     * @param aRltCd
     * @param rltColl
     * @return
     */
    private boolean isRefSeqNumberRelatedToOther(final String aRefSeqNumber, final String aRltCd, final APP_HSHL_RLT_Collection rltColl) {
        boolean flag = false;
        int rltCollSize = 0;
        if (rltColl != null) {
            rltCollSize = rltColl.size();
        }
        APP_HSHL_RLT_Cargo rltCargo = null;
        String rltCode = null;
        Integer refIndvSeqNumber = null;
        if(rltColl !=null && !rltColl.isEmpty() && rltColl.size()>0){
            for (int i = 0; i < rltCollSize; i++) {
                rltCargo = rltColl.getCargo(i);
                rltCode = rltCargo.getRlt_cd();
                refIndvSeqNumber = rltCargo.getRef_indv_seq_num();
                if (null!=refIndvSeqNumber && aRefSeqNumber.equals(refIndvSeqNumber.toString().trim()) && aRltCd.equals(rltCode)) {
                    flag = true;
                    break;
                }

            }
        }
        return flag;
    }

    /**
     * getRelaventRelationshipCodes
     * @param filterColumnId
     * @param filterValue
     * @param language
     * @return
     */
    private List<String> getRelaventRelationshipCodes(int[] filterColumnId, String[] filterValue, String language) {
        IReferenceTableData refData = null;

        List<String> relaventRelationShipCodes = new ArrayList<>();

        if (filterColumnId != null) {
            if (filterColumnId.length == 1) {
                refData = referenceTableManager.filterDataOnSingleColumn("TREL", language, filterColumnId[0],IReferenceConstants.FILTER_EXCLUDE_MATCH_ONE, filterValue);

            } else {
                refData = referenceTableManager.filterDataOnMultipleColumns("TREL", language, filterColumnId,IReferenceConstants.FILTER_EXCLUDE_MATCH_ONE, filterValue);
            }

        } else {
            refData = referenceTableManager.getReferenceTableData("TREL", language);
        }

        List<Map<Integer, String>> referenceTableData = refData.getData();

        for (int i = 0; i < referenceTableData.size(); i++) {
            Map<Integer, String> referenceTableEntry = referenceTableData.get(i);
            for (Map.Entry<Integer, String> entry : referenceTableEntry.entrySet()) {
                StringBuilder key = new StringBuilder().append(entry.getKey()); //"Typecasting issue" in converting response data, Will later remove StringBuilder.
                String value = entry.getValue().toString();
                if (key.toString().equals(CODE_COLUMN_ID) ) {
                    if (!DEFAULT_DROPDOWN_SEL.equalsIgnoreCase(value)) {
                        relaventRelationShipCodes.add(value);
                    }
                }
            }
        }
        return relaventRelationShipCodes;
    }

    /**
     * getMMDDYYYYDate
     * @param yyyyMmDd
     * @return
     */
    public String getMMDDYYYYDate(String yyyyMmDd) {
        String result = "";
        // Get the values for the date, month and year from the given sql date
        yyyyMmDd = yyyyMmDd.substring(0, 10);
        final String yyyy = yyyyMmDd.substring(0, 4);
        final String mm = yyyyMmDd.substring(5, 7);
        final String dd = yyyyMmDd.substring(8, 10);

        result = new StringBuilder(mm).append("/").append(dd).append("/").append(yyyy).toString();
        return result;
    }
}
