package gov.state.nextgen.householddemographics.data.db2;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_CargoKey;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Pregnancy Information repo
 */
@Repository
public interface PregnancyInformationRepo extends CrudRepository<CP_APP_IN_PREG_Cargo,CP_APP_IN_PREG_CargoKey> {

	@Query("select c from CP_APP_IN_PREG_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
    List<CP_APP_IN_PREG_Cargo> findAllByAppNumAndIndvSeqNum(Integer appNumber, Double indvSeqNum);
    
	/*
	 * @Query(value
	 * ="select cargo from CP_APP_IN_PREG_Cargo cargo where appNum = :appNumber and indvSeqNum = :indvSeqNum"
	 * ) List<CP_APP_IN_PREG_Cargo>
	 * findAllByAppNumAndIndvSeqNumWithTypeDouble(@Param(value = "appNumber") String
	 * appNumber, @Param(value = "indvSeqNum")Double indvSeqNum);
	 */
}
