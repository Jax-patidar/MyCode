package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

public class WIC_CLINIC_INFO_Key implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8937873543796683731L;
	
	private String clinic_cd;



	protected WIC_CLINIC_INFO_Key() {
	}

	protected WIC_CLINIC_INFO_Key(String clinic_cd) {
		super();
		this.clinic_cd = clinic_cd;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((clinic_cd == null) ? 0 : clinic_cd.hashCode());
		return result;
	}

	

}
