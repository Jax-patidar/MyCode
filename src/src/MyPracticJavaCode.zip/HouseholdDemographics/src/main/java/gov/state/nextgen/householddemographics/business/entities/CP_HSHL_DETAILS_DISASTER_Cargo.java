package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name="CP_HSHL_DETAILS_DISASTER")
@IdClass(CP_HSHL_DETAILS_DISASTER_Key.class)
public class CP_HSHL_DETAILS_DISASTER_Cargo extends AbstractCargo  implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	@Id
	private int indv_seq_num;
	
	private String src_app_ind;
	
	private String lived_ind;
	private String worked_ind;
	private String no_income_ind;
	private String delayed_stop_income;
	private String bought_prepared_meal;
	private String employed_county_ssd;
	
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getLived_ind() {
		return lived_ind;
	}
	public void setLived_ind(String lived_ind) {
		this.lived_ind = lived_ind;
	}
	public String getWorked_ind() {
		return worked_ind;
	}
	public void setWorked_ind(String worked_ind) {
		this.worked_ind = worked_ind;
	}
	public String getNo_income_ind() {
		return no_income_ind;
	}
	public void setNo_income_ind(String no_income_ind) {
		this.no_income_ind = no_income_ind;
	}
	public String getDelayed_stop_income() {
		return delayed_stop_income;
	}
	public void setDelayed_stop_income(String delayed_stop_income) {
		this.delayed_stop_income = delayed_stop_income;
	}
	public String getBought_prepared_meal() {
		return bought_prepared_meal;
	}
	public void setBought_prepared_meal(String bought_prepared_meal) {
		this.bought_prepared_meal = bought_prepared_meal;
	}
	public String getEmployed_county_ssd() {
		return employed_county_ssd;
	}
	public void setEmployed_county_ssd(String employed_county_ssd) {
		this.employed_county_ssd = employed_county_ssd;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
