package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABPCL")
@Scope("prototype")
public class ABPCLViewWrapper implements LogicResponseInterface {

    private static final String PAGE_ID = "ABPCL";
    
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

    	DriverPageResponse driverPageResponse = new DriverPageResponse();
    	List<CP_APP_RGST_Cargo> AuthRepList = new ArrayList<CP_APP_RGST_Cargo>();
    	CP_APP_RGST_Cargo authRepCargo = new CP_APP_RGST_Cargo();
        Map<Object,Object> pageCollection = fwTxn.getPageCollection();

        CP_APP_RGST_Collection appAuthRep = (CP_APP_RGST_Collection) pageCollection.get("CP_APP_RGST_Collection");
        
        
        
    	if(appAuthRep != null) {
    		authRepCargo = (CP_APP_RGST_Cargo) appAuthRep.get(0);
		}
    	AuthRepList.add(authRepCargo);
		driverPageResponse.getPageCollection().put("CP_APP_RGST_Collection", AuthRepList);
		
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

        return driverPageResponse;

    }

}
