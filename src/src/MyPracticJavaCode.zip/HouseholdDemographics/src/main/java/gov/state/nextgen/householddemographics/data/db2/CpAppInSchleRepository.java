package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Key;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_Teen_Parent_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;

@Repository
public interface CpAppInSchleRepository extends CrudRepository<APP_IN_SCHLE_Cargo, APP_IN_SCHLE_Key>{

	@Query("select c from APP_IN_SCHLE_Cargo c where app_number = ?1 and c.indv_seq_num IN ?2")
	public APP_IN_SCHLE_Cargo[] loadCollegeTradeSchool(Integer appnum, List<Integer> indvIds);
	
	@Query("select c from APP_IN_SCHLE_Cargo c where c.app_number = ?1 and c.indv_seq_num IN ?2")
	public APP_IN_SCHLE_Cargo[] getAllClgDetails(Integer appNum, List<Integer> indvIds);
	
	@Query("select c from APP_IN_SCHLE_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public APP_IN_SCHLE_Collection getAllDtls(Integer appNum, Integer indv_seq_num);

	@Transactional
	@Modifying
	@Query("delete from APP_IN_SCHLE_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2 and c.seq_num = ?3")
	public void deleteSchoolEnrollment(Integer appNum, Integer indvSeqNumber, Integer seq_num);

	@Query("select c from APP_IN_SCHLE_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2 and c.src_app_ind = ?3 and c.seq_num = ?4")
	public APP_IN_SCHLE_Cargo[] getAllDetails(Integer appNum, Integer indv_seq_num, String src_app_ind, Integer seq_num);
	
	@Query("select c from APP_IN_SCHLE_Cargo c where app_number = ?1 and c.indv_seq_num IN ?2")
	public APP_IN_SCHLE_Cargo[] loadTeenParentDetails(Integer appNum, List<Integer> indvIds);
	
	@Query("select c from APP_IN_SCHLE_Cargo c where c.app_number = ?1 and c.school_type_cd= ?2 and c.indv_seq_num IN ?3")
	public APP_IN_SCHLE_Cargo[] getAllSchoolDetails(Integer appNum, String schoolTypeCd, List<Integer> indvIds);

	@Transactional
	@Modifying
	@Query("delete from APP_IN_SCHLE_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2 and c.seq_num = ?3 and c.school_type_cd = ?4")
	public void deleteSchoolDetails(Integer appNum, Integer indvSeqNumber, Integer seq_num, String schooltType);
	
	@Query("select c from APP_IN_SCHLE_Cargo c where app_number = ?1")
	public APP_IN_SCHLE_Cargo[] loadCollegeTradeSchoolDetails(Integer appnum);

}
