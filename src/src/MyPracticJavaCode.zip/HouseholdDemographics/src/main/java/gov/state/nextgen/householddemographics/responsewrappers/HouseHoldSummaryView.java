package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_SHLTC_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_SHLTC_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABRGS")
@Scope("prototype")
public class HouseHoldSummaryView implements LogicResponseInterface {

	private static final String PAGE_ID = "ABRGS";
	
	private static final String APP_IN_DABL_COLL = "APP_IN_DABL_Collection";
	
	private static final String APP_IN_OUT_ST_BNFT_COLL = "APP_IN_OUT_ST_BNFT_Collection";
	
	private static final String APP_IN_PRIMARY_CARE_COLL = "APP_IN_Primary_Caretaker_Collection";
	
	private static final String APP_IN_ARMED_FORCES_COLL = "APP_IN_Armed_Forces_Collection";
	
	private static final String APP_IN_MEALS_COLL = "APP_IN_Meals_Collection";
	
	private static final String APP_IN_CHILDCARE_COLL = "APP_IN_Childcare_Collection";
	
	private static final String APP_IN_FOSTERCARE_COLL = "APP_IN_FosterCare_Collection";
	
	private static final String APP_IN_FOSTERCHILD_COLL = "APP_IN_FosterChild_Collection";
	
	private static final String APP_IN_LEAVING_COLL = "APP_IN_LeavingCA_Collection";
	
	private static final String APP_IN_PREG_COLL = "APP_IN_PREG_Collection";
	
	private static final String APP_IN_SHLTC_COLL = "APP_IN_SHLTC_Collection";
	
	private static final String CP_APP_IN_TAX_RETURN_COLL = "CP_APP_IN_TAX_RETURN_Collection";
	
	private static final String APP_IN_SCHLE_COLL = "APP_IN_SCHLE_Collection";
	
	private static final String APP_IN_BREASTFEED_COLL = "APP_IN_BreastFeeding_Collection";
	
	private static final String APP_IN_TEEN_PARENT_COLL = "APP_IN_Teen_Parent_Collection";
	
	private static final String APP_IMMIGRATION_COLL="APP_IN_IMMIGRATION_Collection";
	

	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTxn.getPageCollection();
		
		validateDablBnftColl(driverPageResponse, pageCollection);
		
		validatePrimCareFoodPrgmColl(driverPageResponse, pageCollection);
		
		validateArmForInMeals(driverPageResponse, pageCollection);
		
		validateChildFosterCare(driverPageResponse, pageCollection);
		
		
		validateFosterChildInLeave(driverPageResponse, pageCollection);
		
		validatePregShltCargo(driverPageResponse, pageCollection);
		
		
		
		validateTaxSchleCargo(driverPageResponse, pageCollection);
		
		List<CP_APP_IN_PREG_Cargo> appInBreastFeedingCargoList = new ArrayList<>();
		CP_APP_IN_PREG_Cargo breastfeedingcargo;
		CP_APP_IN_PREG_Collection breastfeedingColl = pageCollection.get(APP_IN_BREASTFEED_COLL) != null
				? (CP_APP_IN_PREG_Collection) pageCollection.get(APP_IN_BREASTFEED_COLL)
				: null;

		if (breastfeedingColl != null && !breastfeedingColl.isEmpty()) {
			for (int i = 0; i < breastfeedingColl.size(); i++) {
				breastfeedingcargo = (CP_APP_IN_PREG_Cargo) breastfeedingColl.get(i);
				appInBreastFeedingCargoList.add(breastfeedingcargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_BREASTFEED_COLL, appInBreastFeedingCargoList);
		
		List<APP_IN_SCHLE_Cargo> appInTeenParentCargoList = new ArrayList<>();
		APP_IN_SCHLE_Cargo teenParentcargo;
		APP_IN_SCHLE_Collection teenParentColl = pageCollection.get(APP_IN_TEEN_PARENT_COLL) != null
				? (APP_IN_SCHLE_Collection) pageCollection.get(APP_IN_TEEN_PARENT_COLL)
				: null;

		if (teenParentColl != null && !teenParentColl.isEmpty()) {
			for (int i = 0; i < teenParentColl.size(); i++) {
				teenParentcargo = (APP_IN_SCHLE_Cargo) teenParentColl.get(i);
				appInTeenParentCargoList.add(teenParentcargo);
			}

		}
		
		driverPageResponse.getPageCollection().put(APP_IN_TEEN_PARENT_COLL, appInTeenParentCargoList);
		
		List<APP_INDV_Cargo> appInImigrationList = new ArrayList<APP_INDV_Cargo>();
		APP_INDV_Collection immigrationColl = pageCollection.get(APP_IMMIGRATION_COLL) != null
				? (APP_INDV_Collection) pageCollection.get(APP_IMMIGRATION_COLL)
				: null;

		if (immigrationColl != null && !immigrationColl.isEmpty()) {
			for (int i = 0; i < immigrationColl.size(); i++) {
				APP_INDV_Cargo immigrationcargo = (APP_INDV_Cargo) immigrationColl.get(i);
				appInImigrationList.add(immigrationcargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IMMIGRATION_COLL, appInImigrationList);
		
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

		return driverPageResponse;
	}

	private void validateTaxSchleCargo(DriverPageResponse driverPageResponse, Map pageCollection) {
		List<CP_APP_IN_TAX_RETURN_Cargo> appInTaxCargoList = new ArrayList<>();
		CP_APP_IN_TAX_RETURN_Cargo taxcargo;
		CP_APP_IN_TAX_RETURN_Collection taxColl = pageCollection.get(CP_APP_IN_TAX_RETURN_COLL) != null
				? (CP_APP_IN_TAX_RETURN_Collection) pageCollection.get(CP_APP_IN_TAX_RETURN_COLL)
				: null;

		if (taxColl != null && !taxColl.isEmpty()) {
			for (int i = 0; i < taxColl.size(); i++) {
				taxcargo = (CP_APP_IN_TAX_RETURN_Cargo) taxColl.get(i);
				appInTaxCargoList.add(taxcargo);
			}

		}
		driverPageResponse.getPageCollection().put(CP_APP_IN_TAX_RETURN_COLL, appInTaxCargoList);
		
		List<APP_IN_SCHLE_Cargo> appInSchleCargoList = new ArrayList<>();
		APP_IN_SCHLE_Cargo schlecargo;
		APP_IN_SCHLE_Collection schleColl = pageCollection.get(APP_IN_SCHLE_COLL) != null
				? (APP_IN_SCHLE_Collection) pageCollection.get(APP_IN_SCHLE_COLL)
				: null;

		if (schleColl != null && !schleColl.isEmpty()) {
			for (int i = 0; i < schleColl.size(); i++) {
				schlecargo = (APP_IN_SCHLE_Cargo) schleColl.get(i);
				appInSchleCargoList.add(schlecargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_SCHLE_COLL, appInSchleCargoList);
	}

	private void validatePregShltCargo(DriverPageResponse driverPageResponse, Map pageCollection) {
		List<CP_APP_IN_PREG_Cargo> appInPregCargoList = new ArrayList<>();
		CP_APP_IN_PREG_Cargo pregcargo;
		CP_APP_IN_PREG_Collection pregColl = pageCollection.get(APP_IN_PREG_COLL) != null
				? (CP_APP_IN_PREG_Collection) pageCollection.get(APP_IN_PREG_COLL)
				: null;

		if (pregColl != null && !pregColl.isEmpty()) {
			for (int i = 0; i < pregColl.size(); i++) {
				pregcargo = (CP_APP_IN_PREG_Cargo) pregColl.get(i);
				appInPregCargoList.add(pregcargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_PREG_COLL, appInPregCargoList);
		
		List<CP_APP_IN_SHLTC_Cargo> appInShltcCargoList = new ArrayList<>();
		CP_APP_IN_SHLTC_Cargo shltccargo;
		CP_APP_IN_SHLTC_Collection shltcColl = pageCollection.get(APP_IN_SHLTC_COLL) != null
				? (CP_APP_IN_SHLTC_Collection) pageCollection.get(APP_IN_SHLTC_COLL)
				: null;

		if (shltcColl != null && !shltcColl.isEmpty()) {
			for (int i = 0; i < shltcColl.size(); i++) {
				shltccargo = (CP_APP_IN_SHLTC_Cargo) shltcColl.get(i);
				appInShltcCargoList.add(shltccargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_SHLTC_COLL, appInShltcCargoList);
	}

	private void validateFosterChildInLeave(DriverPageResponse driverPageResponse, Map pageCollection) {
		List<APP_INDV_Cargo> appInFosterchildCargoList = new ArrayList<>();
		APP_INDV_Cargo fosterchildcargo;
		APP_INDV_Collection fosterchildColl = pageCollection.get(APP_IN_FOSTERCHILD_COLL) != null
				? (APP_INDV_Collection) pageCollection.get(APP_IN_FOSTERCHILD_COLL)
				: null;

		if (fosterchildColl != null && !fosterchildColl.isEmpty()) {
			for (int i = 0; i < fosterchildColl.size(); i++) {
				fosterchildcargo = (APP_INDV_Cargo) fosterchildColl.get(i);
				appInFosterchildCargoList.add(fosterchildcargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_FOSTERCHILD_COLL, appInFosterchildCargoList);
		
		List<APP_INDV_Cargo> appInLeavingCACargoList = new ArrayList<>();
		APP_INDV_Cargo leavingCAcargo;
		APP_INDV_Collection leavingCAColl = pageCollection.get(APP_IN_LEAVING_COLL) != null
				? (APP_INDV_Collection) pageCollection.get(APP_IN_LEAVING_COLL)
				: null;

		if (leavingCAColl != null && !leavingCAColl.isEmpty()) {
			for (int i = 0; i < leavingCAColl.size(); i++) {
				leavingCAcargo = (APP_INDV_Cargo) leavingCAColl.get(i);
				appInLeavingCACargoList.add(leavingCAcargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_LEAVING_COLL, appInLeavingCACargoList);
	}

	private void validateChildFosterCare(DriverPageResponse driverPageResponse, Map pageCollection) {
		List<APP_INDV_Cargo> appInChildcareCargoList = new ArrayList<>();
		APP_INDV_Cargo childcarecargo;
		APP_INDV_Collection childcareColl = pageCollection.get(APP_IN_CHILDCARE_COLL) != null
				? (APP_INDV_Collection) pageCollection.get(APP_IN_CHILDCARE_COLL)
				: null;

		if (childcareColl != null && !childcareColl.isEmpty()) {
			for (int i = 0; i < childcareColl.size(); i++) {
				childcarecargo = (APP_INDV_Cargo) childcareColl.get(i);
				appInChildcareCargoList.add(childcarecargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_CHILDCARE_COLL, appInChildcareCargoList);
		
		List<APP_INDV_Cargo> appInFostercareCargoList = new ArrayList<>();
		APP_INDV_Cargo fostercarecargo;
		APP_INDV_Collection fostercareColl = pageCollection.get(APP_IN_FOSTERCARE_COLL) != null
				? (APP_INDV_Collection) pageCollection.get(APP_IN_FOSTERCARE_COLL)
				: null;

		if (fostercareColl != null && !fostercareColl.isEmpty()) {
			for (int i = 0; i < fostercareColl.size(); i++) {
				fostercarecargo = (APP_INDV_Cargo) fostercareColl.get(i);
				appInFostercareCargoList.add(fostercarecargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_FOSTERCARE_COLL, appInFostercareCargoList);
	}

	private void validateArmForInMeals(DriverPageResponse driverPageResponse, Map pageCollection) {
		List<APP_INDV_Cargo> appInArmedForcesCargoList = new ArrayList<>();
		APP_INDV_Cargo armedForcescargo;
		APP_INDV_Collection armedForcesColl = pageCollection.get(APP_IN_ARMED_FORCES_COLL) != null
				? (APP_INDV_Collection) pageCollection.get(APP_IN_ARMED_FORCES_COLL)
				: null;

		if (armedForcesColl != null && !armedForcesColl.isEmpty()) {
			for (int i = 0; i < armedForcesColl.size(); i++) {
				armedForcescargo = (APP_INDV_Cargo) armedForcesColl.get(i);
				appInArmedForcesCargoList.add(armedForcescargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_ARMED_FORCES_COLL, appInArmedForcesCargoList);
		
		
		List<APP_INDV_Cargo> appInMealsCargoList = new ArrayList<>();
		APP_INDV_Cargo mealscargo;
		APP_INDV_Collection mealsColl = pageCollection.get(APP_IN_MEALS_COLL) != null
				? (APP_INDV_Collection) pageCollection.get(APP_IN_MEALS_COLL)
				: null;

		if (mealsColl != null && !mealsColl.isEmpty()) {
			for (int i = 0; i < mealsColl.size(); i++) {
				mealscargo = (APP_INDV_Cargo) mealsColl.get(i);
				appInMealsCargoList.add(mealscargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_MEALS_COLL, appInMealsCargoList);
	}

	private void validatePrimCareFoodPrgmColl(DriverPageResponse driverPageResponse, Map pageCollection) {
		List<APP_INDV_Cargo> appInPrimaryCaretakerCargoList = new ArrayList<>();
		APP_INDV_Cargo caretakercargo;
		APP_INDV_Collection caretakerColl = pageCollection.get(APP_IN_PRIMARY_CARE_COLL) != null
				? (APP_INDV_Collection) pageCollection.get(APP_IN_PRIMARY_CARE_COLL)
				: null;

		if (caretakerColl != null && !caretakerColl.isEmpty()) {
			for (int i = 0; i < caretakerColl.size(); i++) {
				caretakercargo = (APP_INDV_Cargo) caretakerColl.get(i);
				appInPrimaryCaretakerCargoList.add(caretakercargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_PRIMARY_CARE_COLL, appInPrimaryCaretakerCargoList);
		
		List<APP_INDV_Cargo> appInFoodProgramCargoList = new ArrayList<>();
		APP_INDV_Cargo foodProgramcargo;
		APP_INDV_Collection foodProgramColl = pageCollection.get("APP_IN_Food_Program_Collection") != null
				? (APP_INDV_Collection) pageCollection.get("APP_IN_Food_Program_Collection")
				: null;

		if (foodProgramColl != null && !foodProgramColl.isEmpty()) {
			for (int i = 0; i < foodProgramColl.size(); i++) {
				foodProgramcargo = (APP_INDV_Cargo) foodProgramColl.get(i);
				appInFoodProgramCargoList.add(foodProgramcargo);
			}

		}

		
		driverPageResponse.getPageCollection().put("APP_INDV_FOOD_PRGM_Collection", appInFoodProgramCargoList);
		
		

		
		
		List<APP_INDV_Cargo> appInImigrationList = new ArrayList<APP_INDV_Cargo>();
		APP_INDV_Collection immigrationColl = pageCollection.get(APP_IMMIGRATION_COLL) != null
				? (APP_INDV_Collection) pageCollection.get(APP_IMMIGRATION_COLL)
				: null;

		if (immigrationColl != null && !immigrationColl.isEmpty()) {
			for (int i = 0; i < immigrationColl.size(); i++) {
				APP_INDV_Cargo immigrationcargo = (APP_INDV_Cargo) immigrationColl.get(i);
				appInImigrationList.add(immigrationcargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IMMIGRATION_COLL, appInImigrationList);
		
	}


	private void validateDablBnftColl(DriverPageResponse driverPageResponse, Map pageCollection) {
		List<APP_IN_DABL_Cargo> appInDablCargoList = new ArrayList<>();
		APP_IN_DABL_Cargo dablcargo;
		APP_IN_DABL_Collection dablColl = pageCollection.get(APP_IN_DABL_COLL) != null
				? (APP_IN_DABL_Collection) pageCollection.get(APP_IN_DABL_COLL)
				: null;

		if (dablColl != null && !dablColl.isEmpty()) {
			for (int i = 0; i < dablColl.size(); i++) {
				dablcargo = (APP_IN_DABL_Cargo) dablColl.get(i);
				appInDablCargoList.add(dablcargo);
			}
		}
		driverPageResponse.getPageCollection().put(APP_IN_DABL_COLL, appInDablCargoList);

		List<APP_IN_OUT_ST_BNFT_Cargo> appInBnftCargoList = new ArrayList<>();
		APP_IN_OUT_ST_BNFT_Cargo bnftcargo;
		APP_IN_OUT_ST_BNFT_Collection bnftColl = pageCollection.get(APP_IN_OUT_ST_BNFT_COLL) != null
				? (APP_IN_OUT_ST_BNFT_Collection) pageCollection.get(APP_IN_OUT_ST_BNFT_COLL)
				: null;

		if (bnftColl != null && !bnftColl.isEmpty()) {
			for (int i = 0; i < bnftColl.size(); i++) {
				bnftcargo = (APP_IN_OUT_ST_BNFT_Cargo) bnftColl.get(i);
				appInBnftCargoList.add(bnftcargo);
			}

		}
		driverPageResponse.getPageCollection().put(APP_IN_OUT_ST_BNFT_COLL, appInBnftCargoList);
	}

}