package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseIndividualDetailsTaxStatus  implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6099733740219696919L;
	private boolean marriedFilingJointlyInd;
	private boolean marriedFilingSeperatelyInd;
	private boolean singleInd;
	private boolean headOfHouseholdInd;
	private boolean claimedAsOfDependentInd;
	private boolean nonTaxFilerInd;
	private String claimedAsDependentName;
	private String someoneElseFirstName;
	private String someoneElseMiddleName;
	private String someoneElseLastName;
	private String jointFillFirstName;
	private String jointFillMiddleName;
	private String jointFillLastName;
	@JsonProperty("JointFilerPersonId")
	private BigDecimal jointFilerPersonId;
	@JsonProperty("TaxFilerPersonId")
	private BigDecimal taxFilerPersonId;
	
	public boolean isMarriedFilingJointlyInd() {
		return marriedFilingJointlyInd;
	}
	public void setMarriedFilingJointlyInd(boolean marriedFilingJointlyInd) {
		this.marriedFilingJointlyInd = marriedFilingJointlyInd;
	}
	public boolean isMarriedFilingSeperatelyInd() {
		return marriedFilingSeperatelyInd;
	}
	public void setMarriedFilingSeperatelyInd(boolean marriedFilingSeperatelyInd) {
		this.marriedFilingSeperatelyInd = marriedFilingSeperatelyInd;
	}
	public boolean isSingleInd() {
		return singleInd;
	}
	public void setSingleInd(boolean singleInd) {
		this.singleInd = singleInd;
	}
	public boolean isHeadOfHouseholdInd() {
		return headOfHouseholdInd;
	}
	public void setHeadOfHouseholdInd(boolean headOfHouseholdInd) {
		this.headOfHouseholdInd = headOfHouseholdInd;
	}
	public boolean isClaimedAsOfDependentInd() {
		return claimedAsOfDependentInd;
	}
	public void setClaimedAsOfDependentInd(boolean claimedAsOfDependentInd) {
		this.claimedAsOfDependentInd = claimedAsOfDependentInd;
	}
	public boolean isNonTaxFilerInd() {
		return nonTaxFilerInd;
	}
	public void setNonTaxFilerInd(boolean nonTaxFilerInd) {
		this.nonTaxFilerInd = nonTaxFilerInd;
	}
	public String getClaimedAsDependentName() {
		return claimedAsDependentName;
	}
	public void setClaimedAsDependentName(String claimedAsDependentName) {
		this.claimedAsDependentName = claimedAsDependentName;
	}
	public String getSomeoneElseFirstName() {
		return someoneElseFirstName;
	}
	public void setSomeoneElseFirstName(String someoneElseFirstName) {
		this.someoneElseFirstName = someoneElseFirstName;
	}
	public String getSomeoneElseMiddleName() {
		return someoneElseMiddleName;
	}
	public void setSomeoneElseMiddleName(String someoneElseMiddleName) {
		this.someoneElseMiddleName = someoneElseMiddleName;
	}
	public String getSomeoneElseLastName() {
		return someoneElseLastName;
	}
	public void setSomeoneElseLastName(String someoneElseLastName) {
		this.someoneElseLastName = someoneElseLastName;
	}
	public String getJointFillFirstName() {
		return jointFillFirstName;
	}
	public void setJointFillFirstName(String jointFillFirstName) {
		this.jointFillFirstName = jointFillFirstName;
	}
	public String getJointFillMiddleName() {
		return jointFillMiddleName;
	}
	public void setJointFillMiddleName(String jointFillMiddleName) {
		this.jointFillMiddleName = jointFillMiddleName;
	}
	public String getJointFillLastName() {
		return jointFillLastName;
	}
	public void setJointFillLastName(String jointFillLastName) {
		this.jointFillLastName = jointFillLastName;
	}
	public BigDecimal getJointFilerPersonId() {
		return jointFilerPersonId;
	}
	public void setJointFilerPersonId(BigDecimal jointFilerPersonId) {
		this.jointFilerPersonId = jointFilerPersonId;
	}
	public BigDecimal getTaxFilerPersonId() {
		return taxFilerPersonId;
	}
	public void setTaxFilerPersonId(BigDecimal taxFilerPersonId) {
		this.taxFilerPersonId = taxFilerPersonId;
	}
}
