/**
 * 
 */
package gov.state.nextgen.householddemographics.business.rules;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_TAX_RETURNS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_TAX_RETURNS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_DEPENDENTS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_DEPENDENTS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Collection;
import gov.state.nextgen.householddemographics.data.db2.AppInTaxReturnsRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInTaxDependentsRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInTaxReturnRepository;

/**
 * @author KumariK
 *
 */
@Service("TaxInformationBO")
public class TaxInformationBO extends AbstractBO{
	
	@Autowired
	private CpAppInTaxReturnRepository taxRepo;
	
	@Autowired
	private CpAppInTaxDependentsRepository taxDepRepo;
	
	@Autowired
	private AppInTaxReturnsRepository taxReturnsRepo;
	
	/**
	 * store tax information in CP_APP_IN_TAX_RETURN table
	 * @param taxCargo
	 */
	public void storeTaxInfo(CP_APP_IN_TAX_RETURN_Cargo taxCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.storeTaxInfo) - START");
		try{
			if(taxCargo != null) {
				taxRepo.save(taxCargo);
			}		
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.storeTaxInfo - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) );	
	}
	
	/**
	 * store tax information in APP_IN_TAX_RETURNS_Cargo table
	 * @param taxReturnsCargo
	 */
	public void storeTaxReturnsInfo(APP_IN_TAX_RETURNS_Cargo taxReturnsCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.storeTaxReturnsInfo) - START");
		try{
			if(taxReturnsCargo != null) {
				taxReturnsRepo.save(taxReturnsCargo);
			}		
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.storeTaxReturnsInfo - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) );	
	}
	
	/**
	 * store data in CP_APP_IN_TAX_DEPENDENTS table
	 * @param newDepColl
	 */
	public void storeTaxDepInfo(CP_APP_IN_TAX_DEPENDENTS_Collection newDepColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.storeTaxDepInfo) - START");
		try{
			if(newDepColl != null && !newDepColl.isEmpty()) {
				for(int i=0; i<newDepColl.size();i++) {
					CP_APP_IN_TAX_DEPENDENTS_Cargo depCargo = newDepColl.getCargo(i);
					if(null == depCargo.getSeq_num()) {
						CP_APP_IN_TAX_DEPENDENTS_Collection taxDetails = taxDepRepo.loadTaxInfoByAppNum(Integer.parseInt(depCargo.getApp_num()));
						Long maxSeqNum = taxDetails.stream().count()+1;
						depCargo.setSeq_num(maxSeqNum.intValue());
					}
					taxDepRepo.save(depCargo);
				}
			}		
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.storeTaxDepInfo - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) );
		
	}

	public CP_APP_IN_TAX_RETURN_Collection loadTaxInfo(String appNumber, String src_ind, List<Integer> indvIds) {
		return taxRepo.loadTaxInfo(Integer.parseInt(appNumber), src_ind, indvIds);
	}

	public CP_APP_IN_TAX_DEPENDENTS_Collection loadTaxDepInfo(String appNumber, String src_ind) {
		return taxDepRepo.loadTaxInfo(Integer.parseInt(appNumber),src_ind);
	}

	public CP_APP_IN_TAX_DEPENDENTS_Collection loadTaxDepIndvInfo(String appNumber, String src_ind,
			Integer indv_seq_num) {
		return taxDepRepo.loadTaxDepIndvInfo(Integer.parseInt(appNumber), src_ind, indv_seq_num);
	}
	
	public APP_IN_TAX_RETURNS_Collection loadTaxReturnsInfo(String appNumber, String src_ind, List<Integer> indvIds) {
		return taxReturnsRepo.loadTaxReturnsInfo(Integer.parseInt(appNumber), src_ind, indvIds);
	}
	
	
	public CP_APP_IN_TAX_DEPENDENTS_Collection loadTaxDepInfoByAppNum(String appNumber) {
		return taxDepRepo.loadTaxInfoByAppNum(Integer.parseInt(appNumber));
	}

	public CP_APP_IN_TAX_RETURN_Collection loadTaxRetInfo(String appNum, String src_ind, Integer indv_seq_num) {
		return taxRepo.loadTaxRetInfo(Integer.parseInt(appNum),src_ind,indv_seq_num);
	}

	public APP_IN_TAX_RETURNS_Collection fetchTaxReturnsDetails(String appNum, String src_ind, Integer indv_seq_num) {
		return taxReturnsRepo.fetchTaxReturnsDetails(Integer.parseInt(appNum),src_ind,indv_seq_num);
	}

	public void deleteTaxRetData(String appNum, String src_ind, Integer indv_seq_num) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.deleteTaxRetData() - START");
		try{
			if(appNum != null && src_ind != null && indv_seq_num != null) {
				taxRepo.deleteTaxRetData(Integer.parseInt(appNum),indv_seq_num,src_ind);
			}		
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.deleteTaxRetData - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) );
	}
	
	public void deleteTaxReturnsData(String appNum, String src_ind, Integer indv_seq_num) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.deleteTaxReturnsData() - START");
		try{
			if(appNum != null && src_ind != null && indv_seq_num != null) {
				taxReturnsRepo.deleteTaxReturnsData(Integer.parseInt(appNum),indv_seq_num,src_ind);
			}		
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.deleteTaxReturnsData - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) );
	}

	public void deleteTaxDepData(String appNum, Integer indv_seq_num, String src_ind) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.deleteTaxDepData() - START");
		try{
				
			if(appNum != null && src_ind != null && indv_seq_num != null) {
				taxDepRepo.deleteTaxDepData(Integer.parseInt(appNum),indv_seq_num,src_ind);
			}
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInformationBO.deleteTaxDepData - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) );
	}

}
