package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.CPAppInCareProvId;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_CARE_PROV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_CARE_PROV_Collection;

@NoRepositoryBean
public interface CpAppInCareProvRepository extends CrudRepository<CP_APP_IN_CARE_PROV_Cargo, CPAppInCareProvId> {

	
	@Query("select c from CP_APP_IN_CARE_PROV_Cargo c where c.app_num = ?1 and c.indv_seq_num = ?2 and c.seq_num = ?3")
	public CP_APP_IN_CARE_PROV_Collection getAppInCareProvDtl(String appnum, Integer indv_seq_num, Integer seq_num);
	
}
