package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

public class HouseholdSummarySectionRow extends SummarySectionRow implements Serializable {

    private static final long serialVersionUID = 2859474379869137456L;

    private String fst_nam;
    private String last_nam;
    private String mid_init;
    private String sex_ind;
    private String brth_dt;
    private String ssn_num;
    private String ss_num_app_dt;
    private String mrtl_stat_cd;
    private String lang_cd;
    private String trb_mbr_resp;
    private String chld_trb_mbr_resp;
    private String us_ctzn_sw;
    private String aln_immigr_stat_cd;
    private String aln_stat_grnted_dt;
    private String has_spon_resp;
    private String spon_typ;
    private String spon_indv_seq_num;
    private String aln_sponser_sw;
    private String res_wi_sw;
    private String intn_res_resp;
    private String mig_farm_wrkr_sw;
    private String ma_ind;
    private String cc_ind;
    private String wic_ind;
    private String snap_ind;
    private String tanf_ind;
    private String chld_out_home_resp;
    private String dt_leave_facty;
    private String exp_back_at_home_dt;
    private String absence_reason_cd;
    private String live_arng_typ;
    private String race_ethnicity;

    private String indvSeqNo;
    private String SeqNum;

    public String getFst_nam() {
        return fst_nam;
    }
    public void setFst_nam(String fst_nam) {
        this.fst_nam = fst_nam;
    }
    public String getLast_nam() {
        return last_nam;
    }
    public void setLast_nam(String last_nam) {
        this.last_nam = last_nam;
    }
    public String getMid_init() {
        return mid_init;
    }
    public void setMid_init(String mid_init) {
        this.mid_init = mid_init;
    }
    public String getSex_ind() {
        return sex_ind;
    }
    public void setSex_ind(String sex_ind) {
        this.sex_ind = sex_ind;
    }
    public String getBrth_dt() {
        return brth_dt;
    }
    public void setBrth_dt(String brth_dt) {
        this.brth_dt = brth_dt;
    }
    public String getSsn_num() {
        return ssn_num;
    }
    public void setSsn_num(String ssn_num) {
        this.ssn_num = ssn_num;
    }
    public String getSs_num_app_dt() {
        return ss_num_app_dt;
    }
    public void setSs_num_app_dt(String ss_num_app_dt) {
        this.ss_num_app_dt = ss_num_app_dt;
    }
    public String getMrtl_stat_cd() {
        return mrtl_stat_cd;
    }
    public void setMrtl_stat_cd(String mrtl_stat_cd) {
        this.mrtl_stat_cd = mrtl_stat_cd;
    }
    public String getLang_cd() {
        return lang_cd;
    }
    public void setLang_cd(String lang_cd) {
        this.lang_cd = lang_cd;
    }
    public String getTrb_mbr_resp() {
        return trb_mbr_resp;
    }
    public void setTrb_mbr_resp(String trb_mbr_resp) {
        this.trb_mbr_resp = trb_mbr_resp;
    }
    public String getChld_trb_mbr_resp() {
        return chld_trb_mbr_resp;
    }
    public void setChld_trb_mbr_resp(String chld_trb_mbr_resp) {
        this.chld_trb_mbr_resp = chld_trb_mbr_resp;
    }
    public String getUs_ctzn_sw() {
        return us_ctzn_sw;
    }
    public void setUs_ctzn_sw(String us_ctzn_sw) {
        this.us_ctzn_sw = us_ctzn_sw;
    }
    public String getAln_immigr_stat_cd() {
        return aln_immigr_stat_cd;
    }
    public void setAln_immigr_stat_cd(String aln_immigr_stat_cd) {
        this.aln_immigr_stat_cd = aln_immigr_stat_cd;
    }
    public String getAln_stat_grnted_dt() {
        return aln_stat_grnted_dt;
    }
    public void setAln_stat_grnted_dt(String aln_stat_grnted_dt) {
        this.aln_stat_grnted_dt = aln_stat_grnted_dt;
    }
    public String getHas_spon_resp() {
        return has_spon_resp;
    }
    public void setHas_spon_resp(String has_spon_resp) {
        this.has_spon_resp = has_spon_resp;
    }
    public String getSpon_typ() {
        return spon_typ;
    }
    public void setSpon_typ(String spon_typ) {
        this.spon_typ = spon_typ;
    }
    public String getSpon_indv_seq_num() {
        return spon_indv_seq_num;
    }
    public void setSpon_indv_seq_num(String spon_indv_seq_num) {
        this.spon_indv_seq_num = spon_indv_seq_num;
    }
    public String getAln_sponser_sw() {
        return aln_sponser_sw;
    }
    public void setAln_sponser_sw(String aln_sponser_sw) {
        this.aln_sponser_sw = aln_sponser_sw;
    }
    public String getRes_wi_sw() {
        return res_wi_sw;
    }
    public void setRes_wi_sw(String res_wi_sw) {
        this.res_wi_sw = res_wi_sw;
    }
    public String getIntn_res_resp() {
        return intn_res_resp;
    }
    public void setIntn_res_resp(String intn_res_resp) {
        this.intn_res_resp = intn_res_resp;
    }
    public String getMig_farm_wrkr_sw() {
        return mig_farm_wrkr_sw;
    }
    public void setMig_farm_wrkr_sw(String mig_farm_wrkr_sw) {
        this.mig_farm_wrkr_sw = mig_farm_wrkr_sw;
    }
    public String getMa_ind() {
        return ma_ind;
    }
    public void setMa_ind(String ma_ind) {
        this.ma_ind = ma_ind;
    }
    public String getCc_ind() {
        return cc_ind;
    }
    public void setCc_ind(String cc_ind) {
        this.cc_ind = cc_ind;
    }
    public String getWic_ind() {
        return wic_ind;
    }
    public void setWic_ind(String wic_ind) {
        this.wic_ind = wic_ind;
    }
    public String getSnap_ind() {
        return snap_ind;
    }
    public void setSnap_ind(String snap_ind) {
        this.snap_ind = snap_ind;
    }
    public String getTanf_ind() {
        return tanf_ind;
    }
    public void setTanf_ind(String tanf_ind) {
        this.tanf_ind = tanf_ind;
    }
    public String getChld_out_home_resp() {
        return chld_out_home_resp;
    }
    public void setChld_out_home_resp(String chld_out_home_resp) {
        this.chld_out_home_resp = chld_out_home_resp;
    }
    public String getDt_leave_facty() {
        return dt_leave_facty;
    }
    public void setDt_leave_facty(String dt_leave_facty) {
        this.dt_leave_facty = dt_leave_facty;
    }
    public String getExp_back_at_home_dt() {
        return exp_back_at_home_dt;
    }
    public void setExp_back_at_home_dt(String exp_back_at_home_dt) {
        this.exp_back_at_home_dt = exp_back_at_home_dt;
    }
    public String getAbsence_reason_cd() {
        return absence_reason_cd;
    }
    public void setAbsence_reason_cd(String absence_reason_cd) {
        this.absence_reason_cd = absence_reason_cd;
    }
    public String getIndvSeqNo() {
        return indvSeqNo;
    }
    public void setIndvSeqNo(String indvSeqNo) {
        this.indvSeqNo = indvSeqNo;
    }
    public String getSeqNum() {
        return SeqNum;
    }
    public void setSeqNum(String seqNum) {
        SeqNum = seqNum;
    }
    public String getLive_arng_typ() {
        return live_arng_typ;
    }
    public void setLive_arng_typ(String live_arng_typ) {
        this.live_arng_typ = live_arng_typ;
    }
    public String getRace_ethnicity() {
        return race_ethnicity;
    }
    public void setRace_ethnicity(String race_ethnicity) {
        this.race_ethnicity = race_ethnicity;
    }

}
