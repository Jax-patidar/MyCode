package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

/***
 * AWS SQS Message reponse after being placed in SQS queue.
 * @author  spoloju
 */
public class SQSResponse implements Serializable {


    private static final long serialVersionUID = 6507160279271169854L;
    private String messageQueueId;

    private String statusCode;

    public String getMessageQueueId() {
        return messageQueueId;
    }

    public void setMessageQueueId(String messageQueueId) {
        this.messageQueueId = messageQueueId;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
}
