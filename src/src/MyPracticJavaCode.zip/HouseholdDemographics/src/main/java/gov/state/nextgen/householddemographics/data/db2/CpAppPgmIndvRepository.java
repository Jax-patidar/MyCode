package gov.state.nextgen.householddemographics.data.db2;

import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


public interface CpAppPgmIndvRepository extends CrudRepository<CP_APP_PGM_INDV_Cargo,CP_APP_PGM_INDV_Cargo.CP_APP_PGM_INDV_Key> {

    @Query("select c from CP_APP_PGM_INDV_Cargo c where c.app_number = ?1")
    public CP_APP_PGM_INDV_Collection getDetails(Integer appNum);
}
