package gov.state.nextgen.householddemographics.data.db2;


import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB_Collection;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 *
 */
@Repository
public interface NewBornChildInformationRepo extends CrudRepository<APP_IN_NEWB_Cargo,Integer> {

	@Query("select c from APP_IN_NEWB_Cargo c where c.app_number = ?1")
	List<APP_IN_NEWB_Cargo> findAllByAppNumAndIndvSeqNum(Integer app_number, Double indvSeqNum);
	
	@Query("select c from APP_IN_NEWB_Cargo c where c.app_number = ?1")
	public APP_IN_NEWB_Collection getByAppNum(Integer appNum);
	
	@Query("select c from APP_IN_NEWB_Cargo c where c.app_number = ?1 and c.indvSeqNum = ?2")
	public APP_IN_NEWB_Cargo findByAppNumIndvSeqNum(Integer appNum, Integer indvSeqNum);
	
	@Query("select c from APP_IN_NEWB_Cargo c where c.app_number = ?1 and c.newBornInfoId = ?2")
	public APP_IN_NEWB_Cargo findByAppNumnewBornInfoId(Integer appNum, String newBornInfoId);


}
