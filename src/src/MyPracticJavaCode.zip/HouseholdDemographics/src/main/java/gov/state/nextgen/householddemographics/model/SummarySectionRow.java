package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

public class SummarySectionRow implements Serializable {

    private static final long serialVersionUID = 21684986756750972L;

    private Individual indiv;
    private String rowName;
    private String rowValue;
    private String rowEndsWith;
    private boolean showEdit;
    private boolean showDelete;
    private String editAction;
    private String deleteAction;
    private String srcAppInd;
    private String information;


    public Individual getIndiv() {
        return indiv;
    }
    public void setIndiv(Individual indiv) {
        this.indiv = indiv;
    }
    public String getRowName() {
        return rowName;
    }
    public void setRowName(String rowName) {
        this.rowName = rowName;
    }
    public String getRowValue() {
        return rowValue;
    }
    public void setRowValue(String rowValue) {
        this.rowValue = rowValue;
    }
    public String getRowEndsWith() {
        return rowEndsWith;
    }
    public void setRowEndsWith(String rowEndsWith) {
        this.rowEndsWith = rowEndsWith;
    }
    public boolean getShowEdit() {
        return showEdit;
    }
    public void setShowEdit(boolean showEdit) {
        this.showEdit = showEdit;
    }
    public boolean getShowDelete() {
        return showDelete;
    }
    public void setShowDelete(boolean showDelete) {
        this.showDelete = showDelete;
    }
    public String getEditAction() {
        return editAction;
    }
    public void setEditAction(String editAction) {
        this.editAction = editAction;
    }
    public String getDeleteAction() {
        return deleteAction;
    }
    public void setDeleteAction(String deleteAction) {
        this.deleteAction = deleteAction;
    }
    public String getSrcAppInd() {
        return srcAppInd;
    }
    public void setSrcAppInd(String srcAppInd) {
        this.srcAppInd = srcAppInd;
    }
    public String getInformation() {
        return information;
    }
    public void setInformation(String information) {
        this.information = information;
    }

}
