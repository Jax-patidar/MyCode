package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.BenefitsRenew;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;



@Component("ARRLD")
@Scope("prototype")
public class BenefitsRenewalView implements LogicResponseInterface {

	private static final String BENEFITSRENEWAL = "Benefitsrenewal";
	private static final String APP_PGM_RQST_Collection = "APP_PGM_RQST_Collection";
	private static final String PAGE_ID = "ARRLD";

	@Override
	public PageResponse constructPageResponse(FwTransaction txBean) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();

		@SuppressWarnings("rawtypes")
		Map pageCollection = txBean.getPageCollection();
		Map<Object, Object> session = txBean.getSession();
		Map request = txBean.getRequest();

		APP_PGM_RQST_Collection appPgmRqstCollection = (APP_PGM_RQST_Collection) pageCollection.get(APP_PGM_RQST_Collection);
		Map rmbPrgmDetMap = (Map) pageCollection.get("RMB_PRGM_DET_MAP");
		
		String jsEnabled = FwConstants.YES;
		
		boolean hcPrgmReq = false;
		boolean fsPrgmReq = false;
		boolean ccPrgmReq = false;
		boolean bclaPrgmReq = false;
		boolean taPrgmReq = false;
		boolean snPrgmReq = false;
		boolean mcPrgmReq = false;
		boolean pcPrgmReq = false;
		boolean wcPrgmReq = false;
		
		boolean hcRevPending = false;
		boolean fsRevPending = false;
		boolean ccRevPending = false;
		boolean bclaRevPending = false;
		boolean taRevPending = false;
		boolean snRevPending = false;
		boolean mcRevPending = false;
		boolean pcRevPending = false;
		boolean wcRevPending = false;
		
		boolean addHiddenField = false;

		Map hcReviewDetMap = new HashMap();
		Map fsReviewDetMap = new HashMap();
		Map ccReviewDetMap = new HashMap();
		Map bclaReviewDetMap = new HashMap();
		Map taReviewDetMap = new HashMap();
		Map snReviewDetMap = new HashMap();
		Map mcReviewDetMap = new HashMap();
		Map pcReviewDetMap = new HashMap();
		Map wcReviewDetMap = new HashMap();

		String hcStatus = "N";
		String fsStatus = "N";
		String ccStatus = "N";
		String bclaStatus = "N";
		String taStatus = "N";
		String snStatus = "N";
		String mcStatus = "N";
		String pcStatus = "N";
		String wcStatus = "N";

		hcReviewDetMap = (Map) rmbPrgmDetMap.get("HC");
		fsReviewDetMap = (Map) rmbPrgmDetMap.get("FS");
		ccReviewDetMap = (Map) rmbPrgmDetMap.get("CC");
		bclaReviewDetMap = (Map) rmbPrgmDetMap.get("BCLA");
		taReviewDetMap = (Map) rmbPrgmDetMap.get("TA");
		snReviewDetMap = (Map) rmbPrgmDetMap.get("SN");
		mcReviewDetMap = (Map) rmbPrgmDetMap.get("MC");
		pcReviewDetMap = (Map) rmbPrgmDetMap.get("PC");
		wcReviewDetMap = (Map) rmbPrgmDetMap.get("WC");

		//check is open for program
		if (hcReviewDetMap.get("HC_REQUIRED").equals(FwConstants.YES)) {
	hcPrgmReq = true;
		}
		if (fsReviewDetMap.get("FS_REQUIRED").equals(FwConstants.YES)) {
	fsPrgmReq = true;
		}
		if (ccReviewDetMap.get("CC_REQUIRED").equals(FwConstants.YES)) {
	ccPrgmReq = true;
		}
		if (taReviewDetMap.containsKey("TA_REQUIRED")
		&& taReviewDetMap.get("TA_REQUIRED")
				.equals(FwConstants.YES)) {
	taPrgmReq = true;
		}
		if (snReviewDetMap.containsKey("SN_REQUIRED")
		&& snReviewDetMap.get("SN_REQUIRED")
				.equals(FwConstants.YES)) {
	snPrgmReq = true;
		}
		if (mcReviewDetMap.containsKey("MC_REQUIRED")
		&& mcReviewDetMap.get("MC_REQUIRED")
				.equals(FwConstants.YES)) {
	mcPrgmReq = true;
		}
		if (pcReviewDetMap.containsKey("PC_REQUIRED")
		&& pcReviewDetMap.get("PC_REQUIRED")
				.equals(FwConstants.YES)) {
	pcPrgmReq = true;
		}
		if (wcReviewDetMap.containsKey("WC_REQUIRED")
		&& wcReviewDetMap.get("WC_REQUIRED")
				.equals(FwConstants.YES)) {
	wcPrgmReq = true;
		}

		//find is review pending
		if (hcPrgmReq) {
	if (hcReviewDetMap.get("HC_REVIEW_PENDING").equals(
			FwConstants.YES)) {
		hcRevPending = true;
	}
		}
		if (fsPrgmReq) {
	if (fsReviewDetMap.get("FS_REVIEW_PENDING").equals(
			FwConstants.YES)) {
		fsRevPending = true;
	}
		}
		if (ccPrgmReq) {
	if (ccReviewDetMap.get("CC_REVIEW_PENDING").equals(
			FwConstants.YES)) {
		ccRevPending = true;
	}
		}
		if (taPrgmReq) {
	if (taReviewDetMap.get("TA_REVIEW_PENDING").equals(
			FwConstants.YES)) {
		taRevPending = true;
	}
		}
		if (snPrgmReq) {
	if (snReviewDetMap.get("SN_REVIEW_PENDING").equals(
			FwConstants.YES)) {
		snRevPending = true;
	}
		}
		if (mcPrgmReq) {
	if (mcReviewDetMap.get("MC_REVIEW_PENDING").equals(
			FwConstants.YES)) {
		mcRevPending = true;
	}
		}
		
		if (wcPrgmReq) {
	if (wcReviewDetMap.get("WC_REVIEW_PENDING").equals(
			FwConstants.YES)) {
		wcRevPending = true;
	}
		}
		if (pcPrgmReq) {
	if (pcReviewDetMap.get("PC_REVIEW_PENDING").equals(
			FwConstants.YES)) {
		pcRevPending = true;
	}
		}
		
		//display logic
		if (hcPrgmReq && (hcRevPending || fsRevPending || ccRevPending)) {
	hcStatus = "C";
		}
		if (fsPrgmReq && fsRevPending) {
	fsStatus = "C";
		}
		if (ccPrgmReq && (ccRevPending || fsRevPending)) {
	ccStatus = "C";
		}
		if (taPrgmReq && taRevPending) {
	taStatus = "C";
		}
		
	APP_PGM_RQST_Cargo appPgmRqstCargo = appPgmRqstCollection.getCargo(0);
		
		if(appPgmRqstCargo!=null && appPgmRqstCargo.getTanf_rqst_ind()!=null && appPgmRqstCargo.getTanf_rqst_ind().equals(1))
		taStatus="R";
		
		if (snPrgmReq && snRevPending) {
	snStatus = "C";
		}
		if(appPgmRqstCargo!=null && appPgmRqstCargo.getFs_rqst_ind()!=null && appPgmRqstCargo.getFs_rqst_ind().equals(1))
		snStatus="R";
		if (mcPrgmReq && mcRevPending) {
	mcStatus = "C";
		}
		
		if(appPgmRqstCargo!=null && appPgmRqstCargo.getFma_rqst_ind()!=null && appPgmRqstCargo.getFma_rqst_ind().equals(1))
			mcStatus="R";
		if(appPgmRqstCargo!=null && appPgmRqstCargo.getPeach_rqst_ind()!=null && appPgmRqstCargo.getPeach_rqst_ind().equals(1))
			pcStatus="R";
		if(appPgmRqstCargo!=null && appPgmRqstCargo.getWic_rqst_ind()!=null && appPgmRqstCargo.getWic_rqst_ind().equals(1))
			wcStatus="R";
		
		
		//BCLA logic - PCR# 43100
		String isAllIndvRRP = FwConstants.NO;
		String anyIndvRRP = FwConstants.NO;
		String hideNextButton = FwConstants.NO;
		boolean isBCLACheckBoxRequired = true;
		if (bclaReviewDetMap.get("BCLA_REQUIRED").equals(FwConstants.YES)) {
	bclaPrgmReq = true;
		}
		if (bclaReviewDetMap.get("BCLA_REVIEW_PENDING") != null
		&& bclaReviewDetMap.get("BCLA_REVIEW_PENDING").equals(
				FwConstants.YES)) {
	bclaRevPending = true;

	if (bclaReviewDetMap.get("ALL_INDV_RRP") != null
			&& bclaReviewDetMap.get("ALL_INDV_RRP").equals(
					FwConstants.YES))
		isAllIndvRRP = FwConstants.YES;

	if (bclaReviewDetMap.get("ANY_INDV_RRP") != null
			&& bclaReviewDetMap.get("ANY_INDV_RRP").equals(
					FwConstants.YES))
		anyIndvRRP = FwConstants.YES;

	if (bclaReviewDetMap.get("OTHER_PRGM_OPEN") != null
			&& bclaReviewDetMap.get("OTHER_PRGM_OPEN").equals(
					FwConstants.NO)
			&& isAllIndvRRP.equals(FwConstants.YES))
		hideNextButton = FwConstants.YES;
		}

		if (bclaPrgmReq && bclaRevPending) {
	bclaStatus = "C";
		}
		if (isAllIndvRRP.equals(FwConstants.YES))
	isBCLACheckBoxRequired = false;

		//If the user?s Health Care (CLA and non-CLA) benefits are within the review window 
		//and the user is also opened for FoodShare but the FoodShare benefits are not within the review window,
		// pre-check FoodShare and protect it.
		if (bclaPrgmReq && bclaRevPending && fsPrgmReq) {
	fsStatus = "C";
		}
		if (bclaPrgmReq && bclaRevPending && hcPrgmReq) {
	hcStatus = "C";
		}

		if (!jsEnabled.equals(FwConstants.YES)
		&& (hcStatus.equals("C") || fsStatus.equals("C")
				|| ccStatus.equals("C") || bclaStatus.equals("C")
				|| taStatus.equals("C") || snStatus.equals("C") || mcStatus
				.equals("C"))) {
	addHiddenField = true;
		}

		boolean disFlag = false;
		
		if (hcPrgmReq && ccPrgmReq) {
	disFlag = true;
		} else if (hcPrgmReq && !ccPrgmReq && fsPrgmReq) {
	disFlag = true;
		} else if (!hcPrgmReq && ccPrgmReq && fsPrgmReq) {
	disFlag = true;
		}
		String stat = "R";
		if (appPgmRqstCargo != null) {

			List<BenefitsRenew> benefitsRenewList = new ArrayList<>();
			BenefitsRenew benefitsRenew = new BenefitsRenew();
			
			
			if(hcPrgmReq) {
				if(stat.equalsIgnoreCase(String.valueOf(hcStatus))) {
					hcStatus="1";
					} 
				benefitsRenew.setShowHc(hcPrgmReq);
				benefitsRenew.setRequestMedicaidForFamilies(hcStatus);
			}
			
			if(fsPrgmReq) {
				if(stat.equalsIgnoreCase(String.valueOf(fsStatus))) {
					fsStatus="1";
					} 
				benefitsRenew.setShowFs(fsPrgmReq);
				benefitsRenew.setRequestFoodShare(fsStatus);
			}
			
			if (ccPrgmReq) {
				if(stat.equalsIgnoreCase(String.valueOf(ccStatus))) {
					ccStatus="1";
					} 
				benefitsRenew.setShowCC(ccPrgmReq);
				benefitsRenew.setRequestChildCare(ccStatus);
			}
			
			if (taPrgmReq) {
				if(stat.equalsIgnoreCase(String.valueOf(taStatus))) {
					taStatus="1";
					} 
				benefitsRenew.setShowTANF(taPrgmReq);
				benefitsRenew.setRequestCashAssistance(taStatus);
			}
			
			if (snPrgmReq) {
				if(stat.equalsIgnoreCase(String.valueOf(snStatus))) {
					snStatus="1";
					} 
				benefitsRenew.setShowSNAP(snPrgmReq);
				benefitsRenew.setRequestFoodAssistance(snStatus);
			}
			
			if (mcPrgmReq) {
				if(stat.equalsIgnoreCase(String.valueOf(mcStatus))) {
					mcStatus="1";
					} 
				benefitsRenew.setShowMc(mcPrgmReq);
				benefitsRenew.setRequestMedicalAssistance(mcStatus);
			}
			
			if (pcPrgmReq) {
				if(stat.equalsIgnoreCase(String.valueOf(pcStatus))) {
					pcStatus="1";
					} 
				benefitsRenew.setShowPc(pcPrgmReq);
				benefitsRenew.setRequestPeachCare(pcStatus);
			}
			
			if (wcPrgmReq) {
				if(stat.equalsIgnoreCase(String.valueOf(wcPrgmReq))) {
					wcStatus="1";
					} 
				benefitsRenew.setShowWc(wcPrgmReq);
				benefitsRenew.setRequestWIC(wcStatus);
			}
			
			if (bclaPrgmReq) {
				if(stat.equalsIgnoreCase(String.valueOf(bclaStatus))) {
					bclaStatus="1";
					} 
				if (isBCLACheckBoxRequired) {
				benefitsRenew.setShowBCLA(bclaPrgmReq);
				benefitsRenew.setRequestFamilyPlanningWaiver(bclaStatus);
				}
				else
				{	
					benefitsRenew.setShowBCLA(bclaPrgmReq);
					benefitsRenew.setRequestFamilyPlanningWaiver("P");
				}
			}
			

			benefitsRenewList.add(benefitsRenew);
			driverPageResponse.getPageMap().put(BENEFITSRENEWAL, benefitsRenewList);
		}

		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(txBean.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(txBean.getRequest().get(FwConstants.NEXT_PAGE_ID)));

		return driverPageResponse;

	}



}

