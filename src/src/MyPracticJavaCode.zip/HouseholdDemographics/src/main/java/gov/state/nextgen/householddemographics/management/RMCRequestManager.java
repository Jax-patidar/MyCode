package gov.state.nextgen.householddemographics.management;


import gov.state.nextgen.householddemographics.business.entities.RMC_RQST_Cargo;

public class RMCRequestManager {
    public RMC_RQST_Cargo loadRMCRequest(String appNum) {
        return null;
    }
}
