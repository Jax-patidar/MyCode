package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;



/**
 * @author ransahu
 *
 */
public class Tnb4FormSpecificCargo extends AbstractCargo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6370478095941884269L;
	private String caseNum;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date tnbDueDate;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date tnbLastCertificationDate;
	private String caseName;
	private String countyCode;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private java.time.LocalDate formDueDate;

	/**
	 * @return the caseNum
	 */
	public String getCaseNum() {
		return caseNum;
	}

	/**
	 * @param caseNum the caseNum to set
	 */
	public void setCaseNum(String caseNum) {
		this.caseNum = caseNum;
	}

	/**
	 * @return the tnbDueDate
	 */
	public Date getTnbDueDate() {
		return tnbDueDate;
	}

	/**
	 * @param tnbDueDate the tnbDueDate to set
	 */
	public void setTnbDueDate(Date tnbDueDate) {
		this.tnbDueDate = tnbDueDate;
	}

	/**
	 * @return the tnbLastCertificationDate
	 */
	public Date getTnbLastCertificationDate() {
		return tnbLastCertificationDate;
	}

	/**
	 * @param tnbLastCertificationDate the tnbLastCertificationDate to set
	 */
	public void setTnbLastCertificationDate(Date tnbLastCertificationDate) {
		this.tnbLastCertificationDate = tnbLastCertificationDate;
	}

	/**
	 * @return the caseName
	 */
	public String getCaseName() {
		return caseName;
	}

	/**
	 * @param caseName the caseName to set
	 */
	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}

	/**
	 * @return the countyCode
	 */
	public String getCountyCode() {
		return countyCode;
	}

	/**
	 * @param countyCode the countyCode to set
	 */
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	public java.time.LocalDate getFormDueDate() {
		return formDueDate;
	}

	public void setFormDueDate(java.time.LocalDate formDueDate) {
		this.formDueDate = formDueDate;
	}
	
	

}
