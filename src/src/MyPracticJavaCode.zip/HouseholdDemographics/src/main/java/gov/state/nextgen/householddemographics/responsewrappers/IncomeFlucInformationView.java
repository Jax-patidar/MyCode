package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("MCIFI")
@Scope("prototype")
public class IncomeFlucInformationView implements LogicResponseInterface {
	private static final String PAGE_ID = "MCIFI";
	private static final String APP_INDV_COLL = "APP_INDV_Collection";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTrxn.getPageCollection();
		List<APP_INDV_Cargo> appIndvCargoList  = new ArrayList<APP_INDV_Cargo>();
		APP_INDV_Collection appIndvCollection = (APP_INDV_Collection) pageCollection
				  .get(APP_INDV_COLL);
		APP_INDV_Cargo appIndvCargo = (APP_INDV_Cargo) appIndvCollection.get(0);
		appIndvCargoList.add(appIndvCargo);
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		return driverPageResponse;
	}

}
