package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class CASE_PROGRAMS_Collection extends AbstractCollection {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private static final String PACKAGE = "gov.state.nextgen.householdemographics.business.entities.CASE_PROGRAM_Cargo";

    public void addCargo(final CASE_PROGRAMS_Cargo newCargo) {
        add(newCargo);
    }

    public CASE_PROGRAMS_Collection() {
    }

    @Override
    public String getPACKAGE() {
        return null;
    }

    /**
     * Sets cargo array into collection.
     *
     * Creation Date Mon Feb 06 09:53:47 CST 2006
     * @param cbArray
     *            The cbArray to set
     */

    public void setResults(final APP_USER_Cargo[] cbArray) {
        clear();
        for (int i = 0; i < cbArray.length; i++) {
            add(cbArray[i]);
        }
    }

    /**
     * Sets a cargo into particular index of the collection
     *
     * Creation Date Mon Feb 06 09:53:47 CST 2006
     * @param cb
     *            The cbarray to set
     * @param idx
     *            The idx to set
     */

    public void setResults(final int idx, final CASE_PROGRAMS_Cargo cb) {
        set(idx, cb);
    }

    /**
     * Sets a cargo into particular index of the collection
     *
     * Creation Date Mon Feb 06 09:53:47 CST 2006
     * @param obj
     *            The cbarray to set
     */

    @Override
    public void setGenericResults(final Object obj) {
        if (obj instanceof CASE_PROGRAMS_Cargo[]) {
            final CASE_PROGRAMS_Cargo[] cbArray = (CASE_PROGRAMS_Cargo[]) obj;
            for (int i = 0; i < cbArray.length; i++) {
                add(cbArray[i]);
            }
        }
    }

    /**
     * Returns cargo array.
     *
     * Creation Date Mon Feb 06 09:53:47 CST 2006
     * @return gov.state.nextgen.access.business.entities.APP_USER_Collection[]
     */
    public CASE_PROGRAMS_Cargo[] getResults() {
        final CASE_PROGRAMS_Cargo[] cbArray = new CASE_PROGRAMS_Cargo[size()];
        toArray(cbArray);
        return cbArray;
    }

    /**
     * Returns a particular cargo.
     *
     * Creation Date Mon Feb 06 09:53:47 CST 2006
     * @return gov.state.nextgen.access.business.entities.APP_USER_Collection
     */
    public CASE_PROGRAMS_Cargo getResult(final int idx) {
        return (CASE_PROGRAMS_Cargo) get(idx);
    }

    /**
     * Returns size of a collection.
     *
     * Creation Date Mon Feb 06 09:53:47 CST 2006
     * @return int
     */
    public int getResultsSize() {
        return size();
    }
}
