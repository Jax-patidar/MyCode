package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.CP_RMC_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_RMC_IN_PRFL_Key;

@NoRepositoryBean
public interface RMCProfileRepo extends CrudRepository<CP_RMC_IN_PRFL_Cargo, CP_RMC_IN_PRFL_Key> {

    public List<CP_RMC_IN_PRFL_Cargo> findAllByAppNum(String appNumber);

    public Optional<CP_RMC_IN_PRFL_Cargo> findByAppNumAndIndvSeqNum(String appNum, String indv_seq_num);

}
