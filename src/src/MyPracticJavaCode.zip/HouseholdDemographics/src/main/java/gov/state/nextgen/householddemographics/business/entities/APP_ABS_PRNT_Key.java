package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class APP_ABS_PRNT_Key implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2065507664858581664L;
	
	@Column(name = "app_num")
	private Integer app_number;
	@Column(name = "ap_seq_num")
	private double apSeqNum;
	@Column(name = "indv_seq_num")
	private Integer indv_seq_num;
	
	
	public APP_ABS_PRNT_Key() {
	}
	
	public APP_ABS_PRNT_Key(Integer app_number, double apSeqNum, Integer indv_seq_num) {
		super();
		this.app_number = app_number;
		this.apSeqNum = apSeqNum;
		this.indv_seq_num = indv_seq_num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(apSeqNum);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		return result;
	}

	
	
	
}
