package gov.state.nextgen.householddemographics.factory;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Class for View wrapper configuration.
 * 
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

@Configuration
@ComponentScan(value = "gov.state.nextgen.householddemographics.responsewrappers")
public class LogicWrapperConfig {

}
