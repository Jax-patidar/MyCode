package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABDOC")
@Scope("prototype")
public class CitizenshipConfirmationView implements LogicResponseInterface {


    private static final String PAGE_ID = "ABDOC";

    @SuppressWarnings("unchecked")
    @Override
    public PageResponse constructPageResponse(FwTransaction fwTransaction) {

    	DriverPageResponse driverPageResponse = new DriverPageResponse();
    	List<APP_INDV_Cargo> IndvList = new ArrayList<APP_INDV_Cargo>();
    	APP_INDV_Cargo IndvCargo = new APP_INDV_Cargo();
        Map<Object,Object> pageCollection = fwTransaction.getPageCollection();

        APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection");
        
        
    	if(appIndvColl != null) {
    		IndvCargo = (APP_INDV_Cargo) appIndvColl.get(0);
		}
    	IndvList.add(IndvCargo);
		driverPageResponse.getPageCollection().put("APP_INDV_Collection", IndvList);
			
		
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTransaction.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTransaction.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTransaction.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTransaction.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

        return driverPageResponse;

    }
}
