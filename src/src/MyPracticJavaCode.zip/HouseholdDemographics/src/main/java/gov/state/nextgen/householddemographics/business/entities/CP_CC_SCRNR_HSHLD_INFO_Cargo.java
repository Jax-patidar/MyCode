package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;


import javax.persistence.*;

import gov.state.nextgen.access.business.entities.AbstractCargo;


public class CP_CC_SCRNR_HSHLD_INFO_Cargo extends AbstractCargo implements Serializable{


	private static final long serialVersionUID = -4216380737303425565L;
	
	@Id
	private String app_num;
	
	private String ga_resident;
	private String cc_renewal;
	private String caps_id;
	private String dom_violence;
	private String hmless;
	private String ss_case_mgr;
	private String rcv_tanf;
	private String nat_disaster;
	private String scrnr_seq;
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getGa_resident() {
		return ga_resident;
	}
	public void setGa_resident(String ga_resident) {
		this.ga_resident = ga_resident;
	}
	public String getCc_renewal() {
		return cc_renewal;
	}
	public void setCc_renewal(String cc_renewal) {
		this.cc_renewal = cc_renewal;
	}
	public String getCaps_id() {
		return caps_id;
	}
	public void setCaps_id(String caps_id) {
		this.caps_id = caps_id;
	}
	public String getDom_violence() {
		return dom_violence;
	}
	public void setDom_violence(String dom_violence) {
		this.dom_violence = dom_violence;
	}
	public String getHmless() {
		return hmless;
	}
	public void setHmless(String hmless) {
		this.hmless = hmless;
	}
	public String getSs_case_mgr() {
		return ss_case_mgr;
	}
	public void setSs_case_mgr(String ss_case_mgr) {
		this.ss_case_mgr = ss_case_mgr;
	}
	public String getRcv_tanf() {
		return rcv_tanf;
	}
	public void setRcv_tanf(String rcv_tanf) {
		this.rcv_tanf = rcv_tanf;
	}
	public String getNat_disaster() {
		return nat_disaster;
	}
	public void setNat_disaster(String nat_disaster) {
		this.nat_disaster = nat_disaster;
	}
	public String getScrnr_seq() {
		return scrnr_seq;
	}
	public void setScrnr_seq(String scrnr_seq) {
		this.scrnr_seq = scrnr_seq;
	}
	
}
