package gov.state.nextgen.householddemographics.business.entities;


import java.io.Serializable;



public class APP_IN_SPS_IMPOV_Key implements Serializable{
	
	private static final long serialVersionUID = 6856287527520922386L;

	private String app_num;

	private Integer indv_seq_num;

	private String src_app_ind;

	public APP_IN_SPS_IMPOV_Key(String app_num, Integer indv_seq_num, String src_app_ind) {
		super();
		this.app_num = app_num;
		this.indv_seq_num = indv_seq_num;
		this.src_app_ind = src_app_ind;
	}

	public APP_IN_SPS_IMPOV_Key() {

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}

	
	
}
