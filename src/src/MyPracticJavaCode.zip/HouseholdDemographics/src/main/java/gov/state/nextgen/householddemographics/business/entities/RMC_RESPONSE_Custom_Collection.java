package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class RMC_RESPONSE_Custom_Collection extends AbstractCollection {

    private static final String PACKAGE = "gov.state.nextgen.access.business.entities.APP_INDV";

    public RMC_RESPONSE_Custom_Collection() {
    }

    public void addCargo(final RMC_RESPONSE_Custom_Cargo newCargo) {
        add(newCargo);
    }

    /**
     * Returns cargo.
     *
     * @return java.lang.String
     */
    public RMC_RESPONSE_Custom_Cargo getCargo(final int idx) {
        return (RMC_RESPONSE_Custom_Cargo) get(idx);
    }

    /**
     * Sets cargo values.
     *
     * @param newCargo
     *            The newCargo to set
     */

    public void setCargo(final RMC_RESPONSE_Custom_Cargo newCargo) {
        if (size() == 0) {
            add(newCargo);
        } else {
            set(0, newCargo);
        }
    }

    /**
     * Sets cargo array into collection.
     *
     * @param cbArray
     *            The cbArray to set
     */

    public void setResults(final RMC_RESPONSE_Custom_Cargo[] cbArray) {
        clear();
        for (int i = 0; i < cbArray.length; i++) {
            add(cbArray[i]);
        }
    }

    /**
     * Sets a cargo into particular index of the collection
     *
     * @param cb
     *            The cbarray to set
     * @param idx
     *            The idx to set
     */

    public void setResult(final int idx, final RMC_RESPONSE_Custom_Cargo cb) {
        set(idx, cb);
    }

    /**
     * Sets a cargo into particular index of the collection
     *
     * @param obj
     *            The cbarray to set
     */

    @Override
    public void setGenericResults(final Object obj) {
        if (obj instanceof RMC_RESPONSE_Custom_Cargo[]) {
            final RMC_RESPONSE_Custom_Cargo[] cbArray = (RMC_RESPONSE_Custom_Cargo[]) obj;
            for (int i = 0; i < cbArray.length; i++) {
                add(cbArray[i]);
            }
        }
    }

    @Override
    public String getPACKAGE() {
        return null;
    }

    /**
     * Returns cargo array.
     *
     * @return gov.state.nextgen.access.business.entities.APP_INDV_Collection[]
     */
    public RMC_RESPONSE_Custom_Cargo[] getResults() {
        final RMC_RESPONSE_Custom_Cargo[] cbArray = new RMC_RESPONSE_Custom_Cargo[size()];
        toArray(cbArray);
        return cbArray;
    }

    /**
     * Returns a particular cargo.
     *
     * @return gov.state.nextgen.access.business.entities.APP_INDV_Collection
     */
    public RMC_RESPONSE_Custom_Cargo getResult(final int idx) {
        return (RMC_RESPONSE_Custom_Cargo) get(idx);
    }

    /**
     * Returns size of a collection.
     *
     * @return int
     */
    public int getResultsSize() {
        return size();
    }


}
