package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("MCFSR")
@Scope("prototype")
public class MCFSRResponse implements LogicResponseInterface {

	private static final String PAGE_ID = "MCFSR";

	/*
	 * Constructing pageResponse and returning driverPageResponse.
	 */
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();

		Map<Object, Object> pageCollection = fwTxn.getPageCollection();

		CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = (CpRmbRequestDetails_Collection) pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION);
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "constructPageResponse cpRmbRequestDetailsCollection: " + cpRmbRequestDetailsCollection);
		
		CpRmbRequestDetails_Cargo cpRmbRequestDetailsCargo = (CpRmbRequestDetails_Cargo) cpRmbRequestDetailsCollection
				.get(0);
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "constructPageResponse cpRmbRequestDetailsCargo: " + cpRmbRequestDetailsCargo);

		List<CpRmbRequestDetails_Cargo> cpRmbRequestDetailsCargoList = new ArrayList<>();
		cpRmbRequestDetailsCargoList.add(cpRmbRequestDetailsCargo);

		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION,
				cpRmbRequestDetailsCargoList);

		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

		return driverPageResponse;
	}
}
