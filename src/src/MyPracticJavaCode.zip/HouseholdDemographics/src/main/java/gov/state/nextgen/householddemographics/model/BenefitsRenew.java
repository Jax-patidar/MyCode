package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;


public class BenefitsRenew extends BaseDomainObject implements Serializable {

	private static final long serialVersionUID = 6514967740902644419L;

	private String requestChildCare;
	private String requestMedicaidForFamilies;
	private String requestCashAssistance;
	private String requestFoodAssistance;
	private String requestWIC;
	private String requestPeachCare;
	private String requestFoodShare;
	private String requestFamilyPlanningWaiver;
	private String requestMedicalAssistance;
	private boolean showCC;
	private boolean showHc;
	private boolean showFs;
	private boolean showBCLA;
	private boolean showTANF;
	private boolean showSNAP;
	private boolean showMc;
	private boolean showPc;
	private boolean showWc;

	public boolean isShowCC() {
		return showCC;
	}

	public void setShowCC(boolean showCC) {
		this.showCC = showCC;
	}

	public boolean isShowTANF() {
		return showTANF;
	}

	public void setShowTANF(boolean showTANF) {
		this.showTANF = showTANF;
	}

	public boolean isShowSNAP() {
		return showSNAP;
	}

	public void setShowSNAP(boolean showSNAP) {
		this.showSNAP = showSNAP;
	}

	public boolean isShowMc() {
		return showMc;
	}

	public void setShowMc(boolean showMc) {
		this.showMc = showMc;
	}

	public boolean isShowPc() {
		return showPc;
	}

	public void setShowPc(boolean showPc) {
		this.showPc = showPc;
	}

	public boolean isShowWc() {
		return showWc;
	}

	public void setShowWc(boolean showWc) {
		this.showWc = showWc;
	}


	public String getRequestChildCare() {
		return requestChildCare;
	}

	public void setRequestChildCare(String requestChildCare) {
		this.requestChildCare = requestChildCare;
	}

	public String getRequestMedicaidForFamilies() {
		return requestMedicaidForFamilies;
	}

	public void setRequestMedicaidForFamilies(String requestMedicaidForFamilies) {
		this.requestMedicaidForFamilies = requestMedicaidForFamilies;
	}
	

	public String getRequestCashAssistance() {
		return requestCashAssistance;
	}

	public void setRequestCashAssistance(String requestCashAssistance) {
		this.requestCashAssistance = requestCashAssistance;
	}

	public String getRequestFoodAssistance() {
		return requestFoodAssistance;
	}

	public void setRequestFoodAssistance(String requestFoodAssistance) {
		this.requestFoodAssistance = requestFoodAssistance;
	}


	public String getRequestWIC() {
		return requestWIC;
	}

	public void setRequestWIC(String requestWIC) {
		this.requestWIC = requestWIC;
	}

	public String getRequestPeachCare() {
		return requestPeachCare;
	}

	public void setRequestPeachCare(String requestPeachCare) {
		this.requestPeachCare = requestPeachCare;
	}

	public String getRequestFoodShare() {
		return requestFoodShare;
	}

	public void setRequestFoodShare(String requestFoodShare) {
		this.requestFoodShare = requestFoodShare;
	}

	public String getRequestFamilyPlanningWaiver() {
		return requestFamilyPlanningWaiver;
	}

	public void setRequestFamilyPlanningWaiver(String requestFamilyPlanningWaiver) {
		this.requestFamilyPlanningWaiver = requestFamilyPlanningWaiver;
	}

	public String getRequestMedicalAssistance() {
		return requestMedicalAssistance;
	}

	public void setRequestMedicalAssistance(String requestMedicalAssistance) {
		this.requestMedicalAssistance = requestMedicalAssistance;
	}

	public boolean isShowHc() {
		return showHc;
	}

	public void setShowHc(boolean showHc) {
		this.showHc = showHc;
	}

	public boolean isShowFs() {
		return showFs;
	}

	public void setShowFs(boolean showFs) {
		this.showFs = showFs;
	}

	public boolean isShowBCLA() {
		return showBCLA;
	}

	public void setShowBCLA(boolean showBCLA) {
		this.showBCLA = showBCLA;
	}

}
