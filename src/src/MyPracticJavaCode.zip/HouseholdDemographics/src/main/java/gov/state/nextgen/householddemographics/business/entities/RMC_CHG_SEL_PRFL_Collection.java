package gov.state.nextgen.householddemographics.business.entities;

public class RMC_CHG_SEL_PRFL_Collection {
}
