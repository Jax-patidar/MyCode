package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.*;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * This class contains the entities of CP_APP_FILE_HELP
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

public class APP_FILE_HELP_Cargo extends AbstractCargo implements Serializable{
	
	private static final long serialVersionUID = 1346424609373604777L;

	@Id
	private String app_num;
	
	private Integer agcy_num;
	private Integer help_indv_ind;
	private String help_individual_cd;
	
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public Integer getAgcy_num() {
		return agcy_num;
	}
	public void setAgcy_num(Integer agcy_num) {
		this.agcy_num = agcy_num;
	}
	public Integer getHelp_indv_ind() {
		return help_indv_ind;
	}
	public void setHelp_indv_ind(Integer help_indv_ind) {
		this.help_indv_ind = help_indv_ind;
	}
	public String getHelp_individual_cd() {
		return help_individual_cd;
	}
	public void setHelp_individual_cd(String help_individual_cd) {
		this.help_individual_cd = help_individual_cd;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((agcy_num == null) ? 0 : agcy_num.hashCode());
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((help_individual_cd == null) ? 0 : help_individual_cd.hashCode());
		result = prime * result + ((help_indv_ind == null) ? 0 : help_indv_ind.hashCode());
		return result;
	}
	
	
	
	@Override
	public String toString() {
		return "APP_FILE_HELP_Cargo [app_num=" + app_num + ", agcy_num=" + agcy_num + ", help_indv_ind=" + help_indv_ind
				+ ", help_individual_cd=" + help_individual_cd + "]";
	}
	
	

}
