package gov.state.nextgen.householddemographics.business.rules;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_INST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_INST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SPS_IMPOV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SPS_IMPOV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_HSHLD_INFO_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_HSHLD_INFO_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_INDV_INFO_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_INDV_INFO_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_RESULTS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_RESULTS_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppRgstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppSpsImpovRepository;
import gov.state.nextgen.householddemographics.data.db2.CpCcScrnrHshldInfoRepository;
import gov.state.nextgen.householddemographics.data.db2.CpCcScrnrIndvInfoRepository;
import gov.state.nextgen.householddemographics.data.db2.CpCcScrnrResultsRepository;
import gov.state.nextgen.householddemographics.data.db2.WicClinicInfoRepository;

@Service("ABRegistrationBO")
public class ABRegistrationBO extends AbstractBO {
	
	private CpAppIndvRepository cpAppIndvRepository;
	
	private CpAppInstRepository cpAppInstRepository;
	
	@Autowired
	private CpAppRgstRepository cpAppRgstRepository;
	
	private CpAppSpsImpovRepository cpAppSpsImpovRepository;
	
	@Autowired
	CpAppPgmRqstRepository cpAppPgmRqstRepository;
	
	@Autowired
	private PeopleHandler peopleHandler;
	
	@Autowired
	private IReferenceTableManager iref;
	
	private CpCcScrnrHshldInfoRepository cpCcScrnrHshldInfoRepository;
	
	private CpCcScrnrIndvInfoRepository cpCcScrnrIndvInfoRepository;
	
	private CpCcScrnrResultsRepository cpCcScrnrResultsRepository;
	
	private WicClinicInfoRepository wicClinicInfoRepository;
	
	DateFormat utilDateFormatter = new SimpleDateFormat("dd-MM-yyyy");
	
	public java.util.Date sqlDateToutilDate(final java.sql.Date sDate)
			throws ParseException {
		return utilDateFormatter.parse(utilDateFormatter.format(sDate));
	}
	
	
	
	public FwMessageList validateRegistrationInformation(
			final APP_RGST_Cargo appRgstCargo,
			final APP_INDV_Cargo appIndvCargo, 
			final APP_IN_INST_Cargo appInInstCargo,
			final APP_IN_SPS_IMPOV_Cargo appInSpsImpovCargo,
			final String childCareFunds, final boolean ccFlag) throws Exception {
		
		 final long startTime = System.currentTimeMillis();
	        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABRegistrationBO.validateRegistrationInformation) - START");
		try {
			
			FwMessageList  messageList= new FwMessageList();
			
			final char[] specialChars = { '-', ' ' };
			final char[] specialCharsForAddress1 = { '-', ' '};
			
			// Set Homeless flag
			boolean homelessflag = false;
			
			if ("HML".equals(appIndvCargo.getLiving_arrangement_cd())) {
				homelessflag = true;
			}

			// For First Name & Last Name mandatory check
			if (appMgr.isFieldEmpty(appIndvCargo.getFst_nam())) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_79000));
			
			}

			if (appMgr.isFieldEmpty(appIndvCargo.getLast_nam())) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_79001));
			}

			// Please enter only letters, numbers and these characters . - ' for
			// First Name/Last Name.
			if (!appMgr.isFieldEmpty(appIndvCargo.getFst_nam())
					&& (!appMgr.isInvalidFirstChar(appIndvCargo.getFst_nam()) || !appMgr
							.isSpecialAlphaNumeric(appIndvCargo.getFst_nam(),
									specialChars))) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_79002));
			}

			if (!appMgr.isFieldEmpty(appIndvCargo.getLast_nam())
					&& (!appMgr.isInvalidFirstChar(appIndvCargo.getLast_nam()) || !appMgr
							.isSpecialAlphaNumeric(appIndvCargo.getLast_nam(),
									specialChars))) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_79003));
			}
			// First Name/Last Name cannot start with a zero.
			if (!appMgr.isFieldEmpty(appIndvCargo.getFst_nam())
					&& "0".equals(String.valueOf(appIndvCargo.getFst_nam()
							.charAt(0)))
					|| !appMgr.isFieldEmpty(appIndvCargo.getLast_nam())
					&& "0".equals(String.valueOf(appIndvCargo.getLast_nam().charAt(0)))) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00008));
			}
			// Please enter one letter for Middle Initial.

			if (!appMgr.isFieldEmpty(appIndvCargo.getMid_init())
					&& appIndvCargo.getMid_init() != null
					&& !appIndvCargo.getMid_init().matches("[a-zA-Z]{1}")) {
				if (!homelessflag) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10240));
				}
			}

			if (null!=appIndvCargo.getBrth_dt() && appMgr.validateDate(appIndvCargo.getBrth_dt().toString())
					&& !appMgr.validateDate(appIndvCargo.getBrth_dt())) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00031)); // Date of Birth is invalid.
			} else if (null!=appIndvCargo.getBrth_dt() && !appMgr.validateDate(appIndvCargo.getBrth_dt().toString())
					&& !appMgr.futureDate(appIndvCargo.getBrth_dt())) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00029)); // Date of Birth cannot be greater
				// than today.
			}
			// Date of Birth cannot be more than 120 years in the past.
			if (null!=appIndvCargo.getBrth_dt() && !appMgr.validateDate(appIndvCargo.getBrth_dt().toString())) {
				final Calendar cal = Calendar.getInstance();
				final int month = cal.get(Calendar.MONTH) + 1;
				final int year = cal.get(Calendar.YEAR);
				final int day = cal.get(Calendar.DAY_OF_MONTH);
				final String before120Years = FwConstants.EMPTY_STRING
						+ (year - 120) + "-" + month + "-" + day;
				final java.util.Date utilDate = sqlDateToutilDate(fwDate
						.getDate(before120Years));
				if (appMgr
						.isDateBeforeDate(appIndvCargo.getBrth_dt(), utilDate)) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10251));
				}
			}
			// Please select the Georgia county your household is in.
			/* 48315 - If not living in GA, skip county validation */
			if (AppConstants.YES.equals(appIndvCargo.getRes_ga_ind()) &&
					"000".equals(appRgstCargo.getCnty_num())) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00611));
			}

			
			/* Commenting the below check as its specific to Georgia state, Check for warning messages to be
			 * added in the validation call before uncommenting the below check.
			 *
			 * Child Care Funds 
			 * 
			 * if (ccFlag && FwConstants.NO.equals(childCareFunds)) {
			 * messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.
			 * MSG_99287)); }
			 */
			
			// Please enter Address Line 1/2.
			// Please enter only letters, numbers and these characters # . - '
			// for Address Line 1/2.
			if (appMgr.isFieldEmpty(appRgstCargo.getHshl_l1_adr())) {
				if (!homelessflag) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10402));
				}
			}
			// changed special char for CR 507224 defect 82061
			if (!appMgr.isFieldEmpty(appRgstCargo.getHshl_l1_adr())
					|| !appMgr.isFieldEmpty(appRgstCargo.getHshl_l2_adr())) {
				if (!appMgr.isSpecialAlphaNumeric(
						appRgstCargo.getHshl_l1_adr(), specialCharsForAddress1)
						|| !appMgr.isSpecialAlphaNumeric(
								appRgstCargo.getHshl_l2_adr(),
								specialCharsForAddress1)) {
				    messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99476));
				}
			}
			
			
			// Added as part of defect 82203
			
			if (!appMgr.isFieldEmpty(appRgstCargo.getHshl_l1_adr())
					|| !appMgr.isFieldEmpty(appRgstCargo.getHshl_l2_adr())) {
				
                 if (appMgr.valSeriesofNums(appRgstCargo.getHshl_l1_adr()) || appMgr.valSeriesofNums(appRgstCargo.getHshl_l2_adr())){
				    messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99488));
                 }
			}

			// Please enter City.
			if (appMgr.isFieldEmpty(appRgstCargo.getHshl_city_adr())) {
				if (!homelessflag) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00027));
				}
			}
			// Please enter only letters, numbers and these characters . - ' for
			// City.
			if (!appMgr.isFieldEmpty(appRgstCargo.getHshl_city_adr())
					&& !appMgr
					.isAlphaWithSpace(appRgstCargo.getHshl_city_adr())) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99276));
			}
			// Please select State.
			if (appMgr.isFieldEmpty(appRgstCargo.getHshl_sta_adr())
					|| "AA".equalsIgnoreCase(appRgstCargo.getHshl_sta_adr())
					|| FwConstants.DEFAULT_DROPDOWN_SEL
					.equalsIgnoreCase(appRgstCargo.getHshl_sta_adr())) {
				if (!homelessflag) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00028));
				}
			}
			// Please enter numeric Zip Code & Zip Code cannot be all zeros.
			if (appMgr.isFieldEmpty(appRgstCargo.getHshl_zip_adr())) {
				if (!homelessflag) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00019));
				}
			} else {
				if (!appMgr.isInteger(appRgstCargo.getHshl_zip_adr())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00019));
				} else if (!(appRgstCargo.getHshl_zip_adr().length() == 5)) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_90489));
				} else if (HouseHoldDemoGraphicsConstants.MSG_00000.equals(appRgstCargo.getHshl_zip_adr())
						|| HouseHoldDemoGraphicsConstants.MSG_000000000.equals(appRgstCargo.getHshl_zip_adr())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00022));
				}
			}
			if (!messageList.containsMessage(HouseHoldDemoGraphicsConstants.MSG_00019)
					&& appRgstCargo.getHshl_addr_zip4() != null
					&& !"".equals(appRgstCargo.getHshl_addr_zip4().trim())
					&& !appRgstCargo.getHshl_addr_zip4().matches("\\d+")) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00019));
			}
			
			
			//new validations per defect 75973
			if(homelessflag){
				if(!FwConstants.DEFAULT_DROPDOWN_SEL.equals(appRgstCargo.getHshl_sta_adr())) {
				if(!appMgr.isFieldEmpty(appRgstCargo.getHshl_l2_adr())
						|| !appMgr.isFieldEmpty(appRgstCargo.getHshl_city_adr())
						|| !appMgr.isFieldEmpty(appRgstCargo.getHshl_l1_adr())					
						|| !appMgr.isFieldEmpty(appRgstCargo.getHshl_zip_adr())
						|| !appMgr.isFieldEmpty(appRgstCargo.getHshl_addr_zip4())){
					
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99467));
				}
			}
			} else {
				if(null==appIndvCargo.getRes_ga_ind() || AppConstants.NO.equals(appIndvCargo.getRes_ga_ind())){
					if(AppConstants.GA_STATE_CODE.equals(appRgstCargo.getHshl_sta_adr())){
						messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99465));
					}										
				}
			}
			
			if(null==appIndvCargo.getRes_ga_ind() || AppConstants.NO.equals(appIndvCargo.getRes_ga_ind())){
				if(AppConstants.GA_STATE_CODE.equals(appRgstCargo.getAlt_sta_adr())){
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99466));
				}
			}
			if (!messageList.containsMessage(HouseHoldDemoGraphicsConstants.MSG_00019)
					&& appRgstCargo.getAlt_addr_zip4() != null
					&& !"".equals(appRgstCargo.getAlt_addr_zip4().trim())
					&& !appRgstCargo.getAlt_addr_zip4().matches("\\d+")) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00019));
			}
			
			if (null != appRgstCargo.getHome_addr_chg_begin_dt() && !appMgr.validateDate(appRgstCargo.getHome_addr_chg_begin_dt().toString())) { 
				if (!appMgr.validateDate(appRgstCargo
						.getHome_addr_chg_begin_dt())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00032));// Start date is invalid.-
				} else if (!appMgr.futureDate(appRgstCargo
						.getHome_addr_chg_begin_dt())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00033)); // Start date cannot be greater
					// than today's Date.
				}
			}
			// changed special char for CR 507224 defect 82061
			// for the alternate address line one and two
			if (!appMgr.isFieldEmpty(appRgstCargo.getAlt_st_adr())
					|| !appMgr.isFieldEmpty(appRgstCargo.getAlt_l2_adr())) {
				if (!appMgr.isSpecialAlphaNumeric(appRgstCargo.getAlt_st_adr(),
						specialCharsForAddress1)
						|| !appMgr.isSpecialAlphaNumeric(
								appRgstCargo.getAlt_l2_adr(),
								specialCharsForAddress1)) {
					final Object[] error = new Object[] { new FwMessageTextLabel(
							HouseHoldDemoGraphicsConstants.MSG_3017360) };
					messageList.addMessageToList(addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_99477, error));
				}
			}
			
			
			
			// Added as part of defect 82203
			
						if (!appMgr.isFieldEmpty(appRgstCargo.getAlt_st_adr())
								|| !appMgr.isFieldEmpty(appRgstCargo.getAlt_l2_adr())) {
							
			                 if (appMgr.valSeriesofNums(appRgstCargo.getAlt_st_adr()) || appMgr.valSeriesofNums(appRgstCargo.getAlt_l2_adr())){
			                	 
			                	 final Object[] error = new Object[] { new FwMessageTextLabel(
			                			 HouseHoldDemoGraphicsConstants.MSG_3017360) };
			                	 messageList.addMessageToList(addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_99488, error));
			                 }
						}

			if (!appMgr.isFieldEmpty(appRgstCargo.getAlt_city_adr())) {
				if (!appMgr.isAlphaWithSpace(appRgstCargo.getAlt_city_adr())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_98005));
				}
			}
			// for the alternate state
			if (FwConstants.DEFAULT_DROPDOWN_SEL.equals(appRgstCargo
					.getAlt_sta_adr())) {
				appRgstCargo.setAlt_sta_adr(FwConstants.SPACE);
			}

			if (!appMgr.isFieldEmpty(appRgstCargo.getAlt_zip_adr())) {
				if (!appMgr.isInteger(appRgstCargo.getAlt_zip_adr())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10448));
				} else if (!(appRgstCargo.getAlt_zip_adr().length() == 5)) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10506));
				} else if (HouseHoldDemoGraphicsConstants.MSG_00000.equals(appRgstCargo.getAlt_zip_adr())
						|| HouseHoldDemoGraphicsConstants.MSG_000000000.equals(appRgstCargo.getAlt_zip_adr())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10259));
				}
			}
			// alternate address end

			// If Mailing Address Line 1 is entered verify City, State, Zip Code
			// have been entered also.
			if (StringUtils.isNotBlank(appRgstCargo.getAlt_st_adr())
					&& (StringUtils.isBlank(appRgstCargo.getAlt_city_adr())
					|| StringUtils.isBlank(appRgstCargo
							.getAlt_sta_adr())
							|| StringUtils
							.isBlank(appRgstCargo.getAlt_zip_adr())
					)){
				final Object[] error = new Object[] {  new FwMessageTextLabel(
						HouseHoldDemoGraphicsConstants.MSG_3117361),new FwMessageTextLabel(
								HouseHoldDemoGraphicsConstants.MSG_820100996) };
				messageList.addMessageToList(addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_99423, error));
			}
			// If Mailing City is entered verify Addr Line1, State, Zip Code
						// have been entered also.
			else if (StringUtils.isNotBlank(appRgstCargo.getAlt_city_adr())
								&& (StringUtils.isBlank(appRgstCargo.getAlt_st_adr())
								|| StringUtils.isBlank(appRgstCargo
										.getAlt_sta_adr())
										|| StringUtils
										.isBlank(appRgstCargo.getAlt_zip_adr())
								)){
							final Object[] error = new Object[] { new FwMessageTextLabel(
									HouseHoldDemoGraphicsConstants.MSG_3117361),new FwMessageTextLabel(
											HouseHoldDemoGraphicsConstants.MSG_3018189) };
							messageList.addMessageToList(addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_99423, error));
						}
				// If Mailing State is entered verify Addr Line1, City, Zip Code
				// have been entered also.
			else if (StringUtils.isNotBlank(appRgstCargo.getAlt_sta_adr())
								&& (StringUtils.isBlank(appRgstCargo.getAlt_st_adr())
								|| StringUtils.isBlank(appRgstCargo.getAlt_city_adr())
										|| StringUtils
										.isBlank(appRgstCargo.getAlt_zip_adr())
								)){
							final Object[] error = new Object[] { new FwMessageTextLabel(
									HouseHoldDemoGraphicsConstants.MSG_3117361),new FwMessageTextLabel(
											HouseHoldDemoGraphicsConstants.MSG_3018190) };
							messageList.addMessageToList(addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_99423, error));
						}
				// If Mailing Zip Code is entered verify Addr Line1, City,State
				// have been entered also.
			else if (StringUtils.isNotBlank(appRgstCargo.getAlt_zip_adr())
								&& (StringUtils.isBlank(appRgstCargo.getAlt_st_adr())
								|| StringUtils.isBlank(appRgstCargo.getAlt_city_adr())
										|| StringUtils
										.isBlank(appRgstCargo.getAlt_sta_adr())
								)){
							final Object[] error = new Object[] { new FwMessageTextLabel(
									HouseHoldDemoGraphicsConstants.MSG_3117361),new FwMessageTextLabel(HouseHoldDemoGraphicsConstants.MSG_800100266) };
							messageList.addMessageToList(addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_99423, error));
						}

			// For home phone number
			if (!appMgr.isFieldEmpty(appRgstCargo.getHshl_home_phn_num())) {
				if (!appMgr.isInteger(appRgstCargo.getHshl_home_phn_num())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10465));
				} else if (!appMgr.validatePhone(appRgstCargo
						.getHshl_home_phn_num())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10465)); // Please enter 10 numbers for
					// Home Phone.
				} else if (appRgstCargo.getHshl_home_phn_num().charAt(0) == '0') {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_98006)); // Home Phone cannot start
					// with a zero.
				}
			}
			// For work phone number
			if (!appMgr.isFieldEmpty(appRgstCargo.getHshl_work_phn_num())) {
				if (!appMgr.isInteger(appRgstCargo.getHshl_work_phn_num())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00034));
				} else if (!appMgr.validatePhone(appRgstCargo
						.getHshl_work_phn_num())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00034)); // Please enter 10 numbers for
					// Work Phone.
				} else if (appRgstCargo.getHshl_work_phn_num().charAt(0) == HouseHoldDemoGraphicsConstants.MSG_0) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00038)); // Work Phone cannot start
					// with a zero.
				}
			}
			// For cell phone number
			if (!appMgr.isFieldEmpty(appRgstCargo.getHshl_cell_phn_num())) {
				if (!appMgr.isInteger(appRgstCargo.getHshl_cell_phn_num())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00035));
				} else if (!appMgr.validatePhone(appRgstCargo
						.getHshl_cell_phn_num())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00035)); // Please enter 10 numbers for
					// Cell/Message Phone.
				} else if (appRgstCargo.getHshl_cell_phn_num().charAt(0) == HouseHoldDemoGraphicsConstants.MSG_0) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00039)); // Cell/Message Phone cannot
					// start with a zero.
				}
			}
			// Please enter only numbers for Work Phone Extension.
			if (!appMgr.isFieldEmpty(appRgstCargo.getWork_phn_extn_num())) {
				if (!appMgr.isInteger(appRgstCargo.getWork_phn_extn_num())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00036));
				}
			}
			// Please confirm Email Address is correct.
			if (!appMgr.isFieldEmpty(appRgstCargo.getHshl_email_adr())) {
				if (!appMgr.isEmail(appRgstCargo.getHshl_email_adr())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00040));
				}
			}

			// Please select living arrangement for spouse living away from
			// home.
			if (appInSpsImpovCargo.getSpouse_out_of_home_ind() != null
					&& FwConstants.YES.equals(appInSpsImpovCargo
							.getSpouse_out_of_home_ind())) {
				if (appMgr.isFieldEmpty(appInSpsImpovCargo.getSpouse_living_arrg_cd())
						|| HouseHoldDemoGraphicsConstants.MSG_000.equalsIgnoreCase(appInSpsImpovCargo
								.getSpouse_living_arrg_cd())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00044));
				} else {
					if (HouseHoldDemoGraphicsConstants.MSG_004.equalsIgnoreCase(appInSpsImpovCargo
							.getSpouse_living_arrg_cd())
							&& appMgr.isFieldEmpty(appInSpsImpovCargo
									.getSpouse_living_arrg_oth())) {
						messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00045)); // If other is selected
						// from the dropdown ,
						// other value needs to
						// entered in the text
						// box
					}
				}
			}
			// Please do not enter someone under age 18 as Head of Household
			// -WARNING
			if (null!=appIndvCargo.getBrth_dt() && !appMgr.validateDate(appIndvCargo.getBrth_dt().toString())) {
				final Calendar cal = Calendar.getInstance();
				final int month = cal.get(Calendar.MONTH) + 1;
				final int year = cal.get(Calendar.YEAR);
				final int day = cal.get(Calendar.DAY_OF_MONTH);
				final String before18Years = FwConstants.EMPTY_STRING
						+ (year - 18) + "-" + month + "-" + day;
				final java.util.Date utilDate = sqlDateToutilDate(fwDate
						.getDate(before18Years));
				if (appMgr.isDateAfterDate(appIndvCargo.getBrth_dt(), utilDate)) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00043));
				}
			}
			
			if (!appMgr.isFieldEmpty(appRgstCargo.getWic_clnc_cnty())
					&& !HouseHoldDemoGraphicsConstants.MSG_000.equalsIgnoreCase(appRgstCargo.getWic_clnc_cnty())
					) {
				
				if(!appMgr.isFieldEmpty(appRgstCargo.getWic_clnc_cd())
						&& AppConstants.SEL.equalsIgnoreCase(appRgstCargo.getWic_clnc_cd())){
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99407));
				}
			}

			return messageList;
		}  catch (final Exception e) {
			
			throw e;
		}

	}


	public void storeRegistrationInformation(APP_IN_INST_Cargo appInInstCargo, APP_IN_INST_Collection appInInstColl, APP_INDV_Cargo appIndvCargo, 
			APP_INDV_Collection appIndvColl, APP_RGST_Cargo appRgstCargo, APP_RGST_Collection appRgstColl, APP_IN_SPS_IMPOV_Cargo appInSpsImpovCargo, 
			APP_IN_SPS_IMPOV_Collection appInSpsImpovColl, String appNumber, Map request, Map pageCollection, FwTransaction fwTxn) throws Exception {
			
		try {
				
			FwMessageList validateInfo = null;
			
			if (null != appRgstCargo.getLang_cd()) {
				appIndvCargo.setLang_cd(appRgstCargo.getLang_cd());

			} else {
				appRgstCargo.setLang_cd(FwConstants.SPACE);
			}

			final String tempcounty = appRgstCargo.getCnty_num();
			String childCareFunds ="";
			childCareFunds = iref.getColumnValue("CCFA", 9821,
						String.valueOf(tempcounty), "EN");
			
			if ((appRgstCargo.getDays_at_address_num() == null)
					|| (appRgstCargo.getDays_at_address_num().SIZE == 0)) {
				appRgstCargo.setDays_at_address_num(0);
			} else {
				appRgstCargo.setDays_at_address_num(appRgstCargo
						.getDays_at_address_num());
			}
			
			// EDSP Ends
			if (request.get("tribalLands") != null) {
				final String tribe = (String) request.get("tribalLands");
				if (!FwConstants.DEFAULT_DROPDOWN_SEL.equals(tribe)) {
					appRgstCargo.setCnty_num(tribe);
				}
			}

			/* TODO:"CalSAWS – Service Migration: Commenting out code for PGM Key related code.
			 *  To be updated once finalized.”
			 * Hard coding ccFLag for validation method until the fix is added.
			boolean ccFlag = false;
			final short[] pgmKey = (short[]) session
					.get(FwConstants.AFB_PROGRAM_KEY);
			if (null!=pgmKey && pgmKey[8] == 1) {
				ccFlag = true;
			}
			*/
			
			//Below ccFlag code to be replaced with above.
			boolean ccFlag = true;
			
			//setting default values if null
			if ((appInSpsImpovCargo.getSps_sta_adr() == null)
					|| FwConstants.DEFAULT_DROPDOWN_SEL
							.equalsIgnoreCase(appInSpsImpovCargo
									.getSps_sta_adr())) {
				appInSpsImpovCargo.setSps_sta_adr(FwConstants.SPACE);
			}

			appInSpsImpovColl.setCargo(0, appInSpsImpovCargo);
			appInInstColl.setCargo(0, appInInstCargo);

			if ((appInInstCargo.getBefore_moving_spcl_arrgment_cd() == null)
					|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appInInstCargo
							.getBefore_moving_spcl_arrgment_cd())) {
				appInInstCargo
				.setBefore_moving_spcl_arrgment_cd(FwConstants.SPACE);
			}

			if ((appRgstCargo.getHshl_sta_adr() == null)
					|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appRgstCargo
							.getHshl_sta_adr())) {
				appRgstCargo.setHshl_sta_adr(FwConstants.SPACE);
			}

			if ((appRgstCargo.getHless_sw() == null)
					|| (appRgstCargo.getHless_sw().length() == 0)) {
				appRgstCargo.setHless_sw(FwConstants.SPACE);
			}

			if ((appIndvCargo.getMid_init() == null)
					|| (appIndvCargo.getMid_init().length() == 0)) {
				appIndvCargo.setMid_init(FwConstants.SPACE);
			}
			if ((appIndvCargo.getSex_ind() == null)
					|| (appIndvCargo.getSex_ind().length() == 0)) {
				appIndvCargo.setSex_ind(FwConstants.SPACE);
			}
		
			if ((appIndvCargo.getBrth_dt() == null)
					|| ((appIndvCargo.getBrth_dt().toString()).trim().length() == 0)) {
				appIndvCargo.setBrth_dt(HouseHoldDemoGraphicsConstants.HIGH_DATE);
			} else {
				appIndvCargo.setBrth_dt(appIndvCargo.getBrth_dt());
			}
			
			if ((appIndvCargo.getSs_num_app_dt() == null)
					|| ((appIndvCargo.getSs_num_app_dt().toString()).trim().length() == 0)) {
				appIndvCargo.setSs_num_app_dt(HouseHoldDemoGraphicsConstants.HIGH_DATE);
			} else {
				appIndvCargo.setSs_num_app_dt((appIndvCargo.getSs_num_app_dt()));
			}

			if ((appIndvCargo.getDt_leave_facty() == null)
					|| ((appIndvCargo.getDt_leave_facty().toString()).trim().length() == 0)) {
				appIndvCargo.setDt_leave_facty(HouseHoldDemoGraphicsConstants.HIGH_DATE);
			} else {
				appIndvCargo.setDt_leave_facty((appIndvCargo.getDt_leave_facty()));
			}

			if ((appIndvCargo.getVet_resp() == null)
					|| (appIndvCargo.getVet_resp().trim().length() == 0)) {
				appIndvCargo.setVet_resp(FwConstants.SPACE);
			}

			if ((appIndvCargo.getVet_act_duty_resp() == null)
					|| (appIndvCargo.getVet_act_duty_resp().trim().length() == 0)) {
				appIndvCargo.setVet_act_duty_resp(FwConstants.SPACE);
			}
			if ((appIndvCargo.getChld_pa_act_duty_resp() == null)
					|| (appIndvCargo.getChld_pa_act_duty_resp().trim().length() == 0)) {
				appIndvCargo.setChld_pa_act_duty_resp(FwConstants.SPACE);
			}

			if ((appIndvCargo.getSps_deceased_vet_resp() == null)
					|| (appIndvCargo.getSps_deceased_vet_resp().trim().length() == 0)) {
				appIndvCargo.setSps_deceased_vet_resp(FwConstants.SPACE);
			}

			if ((appIndvCargo.getChld_deceased_vet_resp() == null)
					|| (appIndvCargo.getChld_deceased_vet_resp().trim()
							.length() == 0)) {
				appIndvCargo.setChld_deceased_vet_resp(FwConstants.SPACE);
			}

			if ((appIndvCargo == null)
					|| (appIndvCargo.getChld_deceased_vet_resp().trim()
							.length() == 0)) {
				appIndvCargo.setChld_deceased_vet_resp(FwConstants.SPACE);
			}

			if ((appIndvCargo.getDisable_vet_resp() == null)
					|| (appIndvCargo.getDisable_vet_resp().trim().length() == 0)) {
				appIndvCargo.setDisable_vet_resp(FwConstants.SPACE);
			}
			
			if ((appIndvCargo.getJob_commitment_resp() == null)
					|| (appIndvCargo.getJob_commitment_resp().trim().length() == 0)) {
				appIndvCargo.setJob_commitment_resp(FwConstants.SPACE);
			}

			if ((appRgstCargo.getPref_cntc_ind() == null)
					|| "000".equals(appRgstCargo
							.getPref_cntc_ind().toString())) {
				appRgstCargo.setPref_cntc_ind(0);
			} else {
				final String indicator = appRgstCargo.getPref_cntc_ind().toString();
				if (FwConstants.ONE.equals(indicator)
						&& (appRgstCargo.getHshl_home_phn_num().trim().length() == 0)) {
				}
				if ("2".equals(indicator)
						&& (appRgstCargo.getHshl_work_phn_num().trim().length() == 0)) {
				}
				if ("3".equals(indicator)
						&& (appRgstCargo.getHshl_cell_phn_num().trim().length() == 0)) {
				}
				if ("4".equals(indicator)
						&& (appRgstCargo.getMsg_phn_num().trim().length() == 0)) {
				}
			}
			
			/* Mailing Address and contact information */
			if ((appRgstCargo.getAlt_city_adr() == null)
					|| (appRgstCargo.getAlt_city_adr().length() == 0)) {
				appRgstCargo.setAlt_city_adr(FwConstants.SPACE);
			}
			if ((appRgstCargo.getAlt_l2_adr() == null)
					|| (appRgstCargo.getAlt_l2_adr().length() == 0)) {
				appRgstCargo.setAlt_l2_adr(FwConstants.SPACE);
			}

			if ((appRgstCargo.getAlt_st_adr() == null)
					|| (appRgstCargo.getAlt_st_adr().length() == 0)) {
				appRgstCargo.setAlt_st_adr(FwConstants.SPACE);
			}

			if ((appRgstCargo.getAlt_zip_adr() == null)
					|| (appRgstCargo.getAlt_zip_adr().length() == 0)) {
				appRgstCargo.setAlt_zip_adr(FwConstants.SPACE);
			}

			if ((appRgstCargo.getHshl_city_adr() == null)
					|| (appRgstCargo.getHshl_city_adr().length() == 0)) {
				appRgstCargo.setHshl_city_adr(FwConstants.SPACE);
			}
			if ((appRgstCargo.getHshl_email_adr() == null)
					|| (appRgstCargo.getHshl_email_adr().length() == 0)) {
				appRgstCargo.setHshl_email_adr(FwConstants.SPACE);
			}
			if ((appRgstCargo.getPref_cntc_tm_txt() == null)
					|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appRgstCargo
							.getPref_cntc_tm_txt())) {
				appRgstCargo.setPref_cntc_tm_txt(FwConstants.SPACE);
			}
			if ((appRgstCargo.getHshl_zip_adr() == null)
					|| (appRgstCargo.getHshl_zip_adr().length() == 0)) {
				appRgstCargo.setHshl_zip_adr(FwConstants.SPACE);
			}
			if ((appRgstCargo.getHshl_l1_adr() == null)
					|| (appRgstCargo.getHshl_l1_adr().length() == 0)) {
				appRgstCargo.setHshl_l1_adr(FwConstants.SPACE);
			}
			if ((appRgstCargo.getHshl_l2_adr() == null)
					|| (appRgstCargo.getHshl_l2_adr().length() == 0)) {
				appRgstCargo.setHshl_l2_adr(FwConstants.SPACE);
			}
			if ((appRgstCargo.getHshl_sta_adr() == null)
					|| (appRgstCargo.getHshl_sta_adr().length() == 0)) {
				appRgstCargo.setHshl_sta_adr(FwConstants.SPACE);
			}

			if (appRgstCargo.getHome_addr_chg_begin_dt() == null) {
				appRgstCargo.setHome_addr_chg_begin_dt(HouseHoldDemoGraphicsConstants.HIGH_DATE);
			} else {
				appRgstCargo.setHome_addr_chg_begin_dt((appRgstCargo
								.getHome_addr_chg_begin_dt()));
			}

			if (appRgstCargo.getMail_addr_chg_begin_dt() == null) {
				appRgstCargo.setMail_addr_chg_begin_dt(HouseHoldDemoGraphicsConstants.HIGH_DATE);
			} else {
				appRgstCargo.setMail_addr_chg_begin_dt((appRgstCargo
								.getMail_addr_chg_begin_dt()));
			}
			
			if ((appRgstCargo.getPhn_num_typ() == null)
					|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appRgstCargo
							.getPhn_num_typ())) {
				appRgstCargo.setPhn_num_typ(FwConstants.SPACE);
			}
			if ((appRgstCargo.getMsg_phn_extn_num() == null)
					|| (appRgstCargo.getMsg_phn_extn_num().length() == 0)) {
				appRgstCargo.setMsg_phn_extn_num(FwConstants.SPACE);
			}
			if ((appRgstCargo.getHshl_home_phn_num() == null)
					|| (appRgstCargo.getHshl_home_phn_num().length() == 0)) {
				appRgstCargo.setHshl_home_phn_num(FwConstants.SPACE);
			}

			if ((appRgstCargo.getWork_phn_extn_num() == null)
					|| (appRgstCargo.getWork_phn_extn_num().length() == 0)) {
				appRgstCargo.setWork_phn_extn_num(FwConstants.SPACE);
			}
			if ((appRgstCargo.getPref_cont_method_cd() == null)
					|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appRgstCargo
							.getPref_cont_method_cd())) {
				appRgstCargo.setPref_cont_method_cd(FwConstants.SPACE);
			}
			if ((appRgstCargo.getPref_deaf_cont_method_cd() == null)
					|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appRgstCargo
							.getPref_deaf_cont_method_cd())) {
				appRgstCargo.setPref_deaf_cont_method_cd(FwConstants.SPACE);
			}
			if ((appRgstCargo.getPref_cont_time_cd() == null)
					|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appRgstCargo
							.getPref_cont_time_cd())) {
				appRgstCargo.setPref_cont_time_cd(FwConstants.SPACE);
			}

			appRgstCargo.getHless_sw();

			if (appRgstCargo.getPref_cntc_ind() != null) {

				if (FwConstants.ONE.equals((appRgstCargo.getPref_cntc_ind().toString())
						.trim())
						&& !FwConstants.EMPTY_STRING.equals(appRgstCargo
								.getHshl_home_phn_num().trim())) {
				}

				else if ("2".equals((appRgstCargo.getPref_cntc_ind().toString()).trim())
						&& !FwConstants.EMPTY_STRING.equals(appRgstCargo
								.getHshl_work_phn_num().trim())
						&& !FwConstants.EMPTY_STRING.equals(appRgstCargo
								.getWork_phn_extn_num().trim())) {
				} else if ("3".equals((appRgstCargo.getPref_cntc_ind().toString()).trim())
						&& !FwConstants.EMPTY_STRING.equals(appRgstCargo
								.getHshl_cell_phn_num().trim())) {
				} else if ("4".equals((appRgstCargo.getPref_cntc_ind().toString()).trim())
						&& !FwConstants.EMPTY_STRING.equals(appRgstCargo
								.getMsg_phn_num().trim())) {
				}

			} // end of outer if



			if ((appRgstCargo.getLiving_arrangement_cd() == null)
					|| !HouseHoldDemoGraphicsConstants.MSG_000.equalsIgnoreCase(appRgstCargo
							.getLiving_arrangement_cd())) {
				appRgstCargo.setLiving_arrangement_cd(FwConstants.SPACE);
				appRgstCargo.setRec_cplt_ind(1);
			} else {
				appRgstCargo.setRec_cplt_ind(0);
			}

			// end

			if ((appRgstCargo.getChg_eff_dt() == null)
					|| ((appRgstCargo.getChg_eff_dt().toString()).trim().length() == 0)) {
				appRgstCargo.setChg_eff_dt(HouseHoldDemoGraphicsConstants.HIGH_DATE);
			} else {
				appRgstCargo.setChg_eff_dt((appRgstCargo.getChg_eff_dt()));
			}
			if (appRgstCargo.getSrc_app_ind() == null) {
				appRgstCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
			}

			appRgstCargo.setCnty_num(tempcounty);
			
			// validating the data
			validateInfo = validateRegistrationInformation(appRgstCargo, appIndvCargo, appInInstCargo,
					appInSpsImpovCargo, childCareFunds, ccFlag);

			if ((validateInfo != null) && validateInfo.hasMessages()) {
				request.put(FwConstants.MESSAGE_LIST, validateInfo);
				return;		 
			}

			appIndvCargo = appIndvColl.getCargo(0);
			appIndvCargo.setApp_num(appNumber);
			appRgstCargo = appRgstColl.getCargo(0);
			appRgstCargo.setApp_num(appNumber);
			appRgstCargo.setSrc_app_ind("AB");
			appRgstCargo.setHshl_indv_ct(0);
		
			//Updating application type based on application context
			String aaType = "AFB";
			appRgstCargo.setApp_typ(aaType);
			
			// EDSP Starts
			appInInstCargo = appInInstColl.getCargo(0);
			appInSpsImpovCargo = appInSpsImpovColl.getCargo(0);
			appInInstCargo.setApp_num(appNumber);
			appInSpsImpovCargo.setApp_num(appNumber);
			appInInstCargo.setIndv_seq_num(1);
			appInInstCargo.setSrc_app_ind("AB");
			appInSpsImpovCargo.setSrc_app_ind("AB");
			appInSpsImpovCargo.setIndv_seq_num(1);

			


			//storing appRgstColl
            if(appRgstColl != null && !appRgstColl.isEmpty()){
            	APP_RGST_Cargo cargo = null;
                cargo = appRgstColl.getCargo(0);
                cpAppRgstRepository.save(cargo);

            }	
            
            
            //updating/storing appIndv 
            if (null == appIndvCargo.getIndv_seq_num()) {
              appIndvCargo.setIndv_seq_num(1); 
              appIndvCargo.setPrim_prsn_sw(FwConstants.YES);
              appIndvCargo.setSrc_app_ind("AB"); 
              peopleHandler.updateIndividual(appIndvCargo); 
            }
            else if (null != appIndvCargo.getIndv_seq_num()) {
            		if(HouseHoldDemoGraphicsConstants.ONE != appIndvCargo.getIndv_seq_num())
            		{
            			appIndvCargo.setSrc_app_ind("AB"); 
            			peopleHandler.updateIndividual(appIndvCargo); 
            		} 
            		else if(HouseHoldDemoGraphicsConstants.ONE == appIndvCargo.getIndv_seq_num())
            		{
            			 appIndvCargo.setPrim_prsn_sw(FwConstants.YES);
                         appIndvCargo.setSrc_app_ind("AB"); 
                         peopleHandler.updateIndividual(appIndvCargo);
            		}
            }
            
            //store Inst
            storeRegistrationWULInformation(appInInstColl);

		
			} catch (final FwException fe) {
			throw fe;
		} 

	}



	public void storeRegistrationWULInformation(APP_IN_INST_Collection appInInstColl) {

		System.currentTimeMillis();

		try {
			APP_IN_INST_Cargo appInInstCargo = null;
			// Persisting the registration information
			if (appInInstColl != null && !appInInstColl.isEmpty()) {
				for (int i = 0; i < appInInstColl.size(); i++) {
					appInInstCargo = appInInstColl.getCargo(i);

					appInInstCargo
					.setApp_num(appInInstCargo.getApp_num() != null ? appInInstCargo
							.getApp_num() : FwConstants.EMPTY_STRING);
					appInInstCargo
					.setBefore_moving_spcl_arrgment_cd(appInInstCargo
							.getBefore_moving_spcl_arrgment_cd() != null ? appInInstCargo
									.getBefore_moving_spcl_arrgment_cd()
									: FwConstants.EMPTY_STRING);
					appInInstCargo.setIndv_seq_num(appInInstCargo
							.getIndv_seq_num() != null ? appInInstCargo
									.getIndv_seq_num() : 0);
					appInInstCargo.setInst_cnty_cd(appInInstCargo
							.getInst_cnty_cd() != null ? appInInstCargo
									.getInst_cnty_cd() : 0);
					appInInstCargo
					.setInst_nam(appInInstCargo.getInst_nam() != null ? appInInstCargo
							.getInst_nam() : FwConstants.EMPTY_STRING);
					appInInstCargo
					.setInstitution_county_city_name(appInInstCargo
							.getInstitution_county_city_name() != null ? appInInstCargo
									.getInstitution_county_city_name()
									: FwConstants.EMPTY_STRING);
					appInInstCargo.setOrig_inst_dt(appInInstCargo
							.getOrig_inst_dt() != null ? appInInstCargo
									.getOrig_inst_dt() : HouseHoldDemoGraphicsConstants.HIGH_DATE);
					appInInstCargo
					.setPlaced_by_gov_agency_ind(appInInstCargo
							.getPlaced_by_gov_agency_ind() != null ? appInInstCargo
									.getPlaced_by_gov_agency_ind()
									: FwConstants.EMPTY_STRING);
					appInInstCargo.setRec_cplt_ind(appInInstCargo
							.getRec_cplt_ind() != null ? appInInstCargo
									.getRec_cplt_ind() : FwConstants.EMPTY_STRING);
					
					//storing Inst cargo.
					cpAppInstRepository.save(appInInstCargo);
					appInInstColl.set(i, appInInstCargo);
				}

			}
		} catch (final Exception fe) {
			throw fe;
		} 

	}



	public Map loadRegistrationInformation(String appNumber, Map pageCollection) {

		APP_RGST_Collection appRgstColl = null;
		APP_INDV_Collection appIndvColl = null;
		APP_IN_INST_Collection appInInstColl = null;
		APP_IN_SPS_IMPOV_Collection appInSpsImpovColl = null;
		APP_PGM_RQST_Collection appPgmRqstColl = null;

		if (appNumber != null) {
			try {
				appPgmRqstColl = new APP_PGM_RQST_Collection();
				final APP_PGM_RQST_Cargo[] appPgmRqstCargoArray = (APP_PGM_RQST_Cargo[]) 
						cpAppPgmRqstRepository.getByAppNum(Integer.parseInt(appNumber));
				
				if (appPgmRqstCargoArray != null
						&& appPgmRqstCargoArray.length > 0) {
					appPgmRqstColl.setResults(appPgmRqstCargoArray);
					pageCollection.put("APP_PGM_RQST_Collection",
							appPgmRqstColl);
				}

				appRgstColl = new APP_RGST_Collection();
				final APP_RGST_Cargo[] appRgstCargoArray = (APP_RGST_Cargo[]) 
						cpAppRgstRepository.getByAppNum(Integer.parseInt(appNumber));
				
				if (appRgstCargoArray != null && appRgstCargoArray.length > 0) {
					appRgstColl.setResults(appRgstCargoArray);
					pageCollection.put("APP_RGST_Collection", appRgstColl);
				}

				// individual information
				appIndvColl = new APP_INDV_Collection();
				final APP_INDV_Cargo[] appIndvCargoArray = (APP_INDV_Cargo[]) 
						cpAppIndvRepository.getByAppNum(Integer.parseInt(appNumber));
				
				if (appIndvCargoArray.length > 0) {
					appIndvColl.setResults(appIndvCargoArray);
					pageCollection.put("APP_INDV_Collection", appIndvColl);
				}

				appInInstColl = new APP_IN_INST_Collection();
				final APP_IN_INST_Cargo[] appInInstCargoArray = (APP_IN_INST_Cargo[]) 
						cpAppInstRepository.getByAppNum(appNumber);
				
				if (appInInstCargoArray.length > 0) {
					appInInstColl.setResults(appInInstCargoArray);
					pageCollection.put("APP_IN_INST_Collection", appInInstColl);
				}

				appInSpsImpovColl = new APP_IN_SPS_IMPOV_Collection();
				final APP_IN_SPS_IMPOV_Cargo[] appInSpsImpovCargoArray = 
						cpAppSpsImpovRepository.getByAppNum(appNumber);
				
				if (appInSpsImpovCargoArray.length > 0) {
					appInSpsImpovColl.setResults(appInSpsImpovCargoArray);
					pageCollection.put("APP_IN_SPS_IMPOV_Collection",
							appInSpsImpovColl);
				}


			} catch (final FwException fe) {
				throw fe;
			} 
		}
		return pageCollection;
	}



	public Map loadCCScreenerResults(String appNumber, Map pageCollection) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABRegistrationBO.loadCCScreenerResults() - START");

		CP_CC_SCRNR_HSHLD_INFO_Collection hshldColl = null;
		CP_CC_SCRNR_INDV_INFO_Collection indvColl = null;
		CP_CC_SCRNR_RESULTS_Collection resColl = null;		
		
		//find max screner seq for that application
		String screenerSeq = "";

		List result = cpCcScrnrHshldInfoRepository.getByAppNumMax(appNumber);
		
		int size = result.size();
		if(size>0){
			screenerSeq =  (String)result.get(0);
		}

		if (appNumber != null) {
			try {
				
				hshldColl = new CP_CC_SCRNR_HSHLD_INFO_Collection();
				final CP_CC_SCRNR_HSHLD_INFO_Cargo[] scrnerHshldCargoArray = (CP_CC_SCRNR_HSHLD_INFO_Cargo[]) 
						cpCcScrnrHshldInfoRepository.getByAppNumScrnrSeq(appNumber, screenerSeq);
				
				if (scrnerHshldCargoArray != null
						&& scrnerHshldCargoArray.length > 0) {
					hshldColl.setResults(scrnerHshldCargoArray);
					pageCollection.put("CP_CC_SCRNR_HSHLD_INFO_Collection",
							hshldColl);
				}
								
				indvColl = new CP_CC_SCRNR_INDV_INFO_Collection();
				final CP_CC_SCRNR_INDV_INFO_Cargo[] scrnrIndvCargoArray = (CP_CC_SCRNR_INDV_INFO_Cargo[]) 
						cpCcScrnrIndvInfoRepository.getByAppNumSorted(appNumber);
				
				if (scrnrIndvCargoArray != null
						&& scrnrIndvCargoArray.length > 0) {
					indvColl.setResults(scrnrIndvCargoArray);
					pageCollection.put("CP_CC_SCRNR_INDV_INFO_Collection",
							indvColl);
				}
				
				resColl = new CP_CC_SCRNR_RESULTS_Collection();
				final CP_CC_SCRNR_RESULTS_Cargo[] scrnrResultsCargoArray = (CP_CC_SCRNR_RESULTS_Cargo[]) 
						cpCcScrnrResultsRepository.getByAppNum(appNumber);
				
				if (scrnrResultsCargoArray != null
						&& scrnrResultsCargoArray.length > 0) {
					resColl.setResults(scrnrResultsCargoArray);
					pageCollection.put("CP_CC_SCRNR_RESULTS_Collection",
							resColl);
				}

			} catch (final FwException fe) {
				throw fe;
			} catch (final Exception e) {
				final FwException fe = createFwException(this.getClass()
						.getName(), "loadRegistrationInformation", e);
				throw fe;
			}
		}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABRegistrationBO.loadCCScreenerResults()- END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		
		return pageCollection;
	}



	public List loadWICClncInfo() {
		final List result = wicClinicInfoRepository.getByEffEndDt(null);
		return result;
	}


}
