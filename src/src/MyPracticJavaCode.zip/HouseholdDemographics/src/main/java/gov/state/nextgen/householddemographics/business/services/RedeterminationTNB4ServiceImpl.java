package gov.state.nextgen.householddemographics.business.services;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CaseIndividualDetails;
import gov.state.nextgen.householddemographics.business.entities.CaseIndividualDetailsAddress;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4MoveoutSsiSsp_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4Redet_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4Redet_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CP_APP_RGST_Repository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppTnb4RedetRepository;
import gov.state.nextgen.householddemographics.data.db2.CpRmbRequestDetailsRepository;
import gov.state.nextgen.householddemographics.data.db2.RMBRqstRepository;

/**
 * Redetermination TNB4 flow service
 * 
 * @author ransahu
 *
 */
@Service("RedeterminationTNB4Service")
public class RedeterminationTNB4ServiceImpl implements HouseholdDemographicsService {

	@Autowired
	CpAppTnb4RedetRepository cpAppTnb4RedetRepository;

	@Autowired
	ARTransactionManagedServImpl arTransactionManagedServImpl;

	@Autowired
	CpAppIndvRepository cpAppIndvRepository;

	@Autowired
	CpAppPgmIndvRepository cpAppPgmIndvRepository;

	@Autowired
	CP_APP_RGST_Repository cpAppRgstRepository;

	@Autowired
	CpAppPgmRqstRepository cpAppPgmRqstRepository;

	@Autowired
	RMBRqstRepository rmbRqstRepository;

	@Autowired
	CpRmbRequestDetailsRepository cpRmbRequestDetailsRepository;
	
	@Autowired
    private ExceptionUtil exceptionUtil;

	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTransaction) {
		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.LOAD_TNB4_SPECIFIC_DATES_AND_CASENUM:
			loadTNB4SpecificDatesAndCaseNum(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.GENERATE_APPLICATION_DATA_FOR_TNB4:
			generateApplicationDataForTNB4(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.SAVE_TNB4_RENEWAL_FORM_DATA:
			saveTNB4RenewalFormData(fwTransaction);
			break;
		default:
			break;
		}

	}

	/**
	 * Method to generate application data for TNB4 Redetermination flow
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadTNB4SpecificDatesAndCaseNum(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.RedeterminationTNB4ServiceImpl() - START", fwTransaction);

		try {
			getRMBFormDataAndClob(fwTransaction);

			massageTNB4specificData(fwTransaction);
		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in loadTNB4SpecificDatesAndCaseNum()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadTNB4SpecificDatesAndCaseNum", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.RedeterminationTNB4ServiceImpl() - END", fwTransaction);
	}

	/**
	 * Method to generate application data for TNB4 Redetermination flow
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void generateApplicationDataForTNB4(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.generateApplicationDataForTNB4() - START", fwTransaction);

		try {
			getRMBFormDataAndClob(fwTransaction);

			generateRMBApplicationData(fwTransaction);

			massageTNB4specificData(fwTransaction);

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in generateApplicationDataForTNB4()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"generateApplicationDataForTNB4", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.generateApplicationDataForTNB4() - END", fwTransaction);
	}

	/**
	 * Method to get data from cp_rmb_request and cp_rmb_request_detail tables
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	private void getRMBFormDataAndClob(FwTransaction fwTransaction) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.getRMBFormDataAndClob() - START", fwTransaction);

		try {
			final Map pageCollection = fwTransaction.getPageCollection();

			RMB_RQST_Collection rmbRqstCollection = (RMB_RQST_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION);

			if (Objects.nonNull(rmbRqstCollection) && !rmbRqstCollection.isEmpty()) {
				RMB_RQST_Cargo rmbRqstCargo = rmbRqstCollection.getCargo(0);
				Long cpRmbRequestId = rmbRqstCargo.getCp_rmb_request_id();

				CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = cpRmbRequestDetailsRepository
						.getCpRmbRequestId(cpRmbRequestId);
				pageCollection.put(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION,
						cpRmbRequestDetailsCollection);

				RMB_RQST_Collection existingRmbRqstCollection = rmbRqstRepository.findByCpRmbRequestId(cpRmbRequestId);
				pageCollection.put(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION, existingRmbRqstCollection);
			}

		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getRMBFormDataAndClob()", fwTransaction);
			throw fe;
		}catch(Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.getRMBFormDataAndClob() - END", fwTransaction);

	}

	/**
	 * Method to massage TNB4 specific data and set in fwTransaction
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	private void massageTNB4specificData(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.massageTNB4specificData() - START", fwTransaction);
	 try {	
		Map pageCollection = fwTransaction.getPageCollection();

		RMB_RQST_Collection existingRmbRqstCollection = Objects
				.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION))
						? (RMB_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION)
						: null;
		if (Objects.nonNull(existingRmbRqstCollection) && !existingRmbRqstCollection.isEmpty()) {
			RMB_RQST_Cargo rmbRqstCargo = existingRmbRqstCollection.getCargo(0);

			pageCollection.put(HouseHoldDemoGraphicsConstants.CASE_NUM, rmbRqstCargo.getCase_num());
			pageCollection.put(HouseHoldDemoGraphicsConstants.TNB_DUE_DATE, rmbRqstCargo.getTnbDueDate());
			pageCollection.put(HouseHoldDemoGraphicsConstants.TNB_LAST_CERTIFICATION_DATE,
					rmbRqstCargo.getTnbLastCertificationDate());
		}

		fwTransaction.setPageCollection(pageCollection);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.massageTNB4specificData() - END", fwTransaction);
	 }catch(Exception e) {
		 FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in RedeterminationTNB4ServiceImpl.massageTNB4specificData()", e);
		 throw e;
	 }
	}

	/**
	 * Method to store App Number, case name and form report type in CP_APP_REQUEST
	 * table
	 * 
	 * @param fwTransaction, formReportType
	 * @return String
	 * @author ransahu
	 */
	private String storeAppNumInCpAppRequest(FwTransaction fwTransaction, String formReportType) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.storeAppNumInCpAppRequest() - START", fwTransaction);
		FwTransaction actualfwTransaction = fwTransaction;
		final Map pageCollection = actualfwTransaction.getPageCollection();

		/* Setting Case Number and TNB4 Form Type */
		RMB_RQST_Collection existingRmbRqstCollection = Objects
				.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION))
						? (RMB_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION)
						: null;
		if (Objects.nonNull(existingRmbRqstCollection) && !existingRmbRqstCollection.isEmpty()) {
			RMB_RQST_Cargo rmbRqstCargo = existingRmbRqstCollection.getCargo(0);
			APP_RQST_Collection appRqstCollection = new APP_RQST_Collection();
			APP_RQST_Cargo appRqstCargo = new APP_RQST_Cargo();
			appRqstCargo.setCaseNum(rmbRqstCargo.getCase_num());
			appRqstCargo.setFormRptType(formReportType);
			appRqstCollection.add(appRqstCargo);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, appRqstCollection);
		}

		/* Generating App Number and storing in CP_APP_REQUEST table */
		arTransactionManagedServImpl.loadRMBLanding(actualfwTransaction);
		final Map appNumPageCollection = fwTransaction.getPageCollection();
		String appNum = Objects.nonNull(appNumPageCollection.get(HouseHoldDemoGraphicsConstants.APP_NUM))
				? appNumPageCollection.get(HouseHoldDemoGraphicsConstants.APP_NUM).toString()
				: null;
		pageCollection.put(HouseHoldDemoGraphicsConstants.APP_NUM, appNum);
		fwTransaction.setPageCollection(pageCollection);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.storeAppNumInCpAppRequest() - END", fwTransaction);
		return appNum;
		
	}

	/**
	 * Method to generate RMB Application data
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	private void generateRMBApplicationData(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.generateRMBApplicationData() - START", fwTransaction);

		try {
			final Map pageCollection = fwTransaction.getPageCollection();

			CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = Objects
					.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION))
							? (CpRmbRequestDetails_Collection) pageCollection
									.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION)
							: null;

			if (Objects.nonNull(cpRmbRequestDetailsCollection) && !cpRmbRequestDetailsCollection.isEmpty()) {

				CpRmbRequestDetails_Cargo cpRmbRequestDetailsCargo = (CpRmbRequestDetails_Cargo) cpRmbRequestDetailsCollection
						.get(0);

				Map formStatusReqJson = (Map) new ObjectMapper()
						.readValue(cpRmbRequestDetailsCargo.getForm_status_req(), Object.class);

				/* Getting countyCode from the FormStatus Request Json Clob */
				String countyCode = Objects.nonNull(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.COUNTY_CODE))
						? (String) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.COUNTY_CODE)
						: null;
				pageCollection.put(HouseHoldDemoGraphicsConstants.COUNTY_CODE, countyCode);
				
				/* Getting caseName from the FormStatus Request Json Clob */
				String caseName = Objects.nonNull(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.CASE_NAME))
						? (String) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.CASE_NAME)
						: null;
				pageCollection.put(HouseHoldDemoGraphicsConstants.CASE_NAME, caseName);

				generateAppNumAndStoreRMBApplicationData(fwTransaction, pageCollection, formStatusReqJson);
			}
		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in generateRMBApplicationData()", fwTransaction);
			throw fe;
		} catch (JsonProcessingException jpe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, jpe.getMessage());
		}catch(Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.generateRMBApplicationData() - END", fwTransaction);

	}

	/**
	 * Method to generate App num and massage data from cp_rmb_request and
	 * cp_rmb_request_detail tables and store/update the massaged data in
	 * CP_APP_INDV, CP_APP_PGM_INDV, CP_APP_PGM_REQUEST, CP_APP_RGST and
	 * CP_RMB_REQUEST tables
	 * 
	 * @param fwTransaction, pageCollection, formStatusReqJson
	 * @return void
	 * @author ransahu
	 */
	@SuppressWarnings("squid:S3776")
	private void generateAppNumAndStoreRMBApplicationData(FwTransaction fwTransaction, final Map pageCollection,
			Map formStatusReqJson) throws JsonProcessingException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.generateAppNumAndStoreRMBApplicationData() - START", fwTransaction);
		/* Getting formReportType from the FormStatus Request Json Clob */
		Map form = (Map) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.FORM);
		String formReportType = (String) form.get(HouseHoldDemoGraphicsConstants.FORM_REPORT_TYPE);

		String appNum = storeAppNumInCpAppRequest(fwTransaction, formReportType);

		/* Setting src app indicator based on form type */
		String srcAppInd = setSrcAppIndBasedOnFormType(formReportType);

		/* Getting CaseIndividuals array from the Form Status Request Json Clob */

		APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
		CP_APP_RGST_Collection appRgstCollection = new CP_APP_RGST_Collection();
		CP_APP_PGM_INDV_Collection appPgmIndvCollection = new CP_APP_PGM_INDV_Collection();
		APP_PGM_RQST_Collection appPgmRqstCollection = new APP_PGM_RQST_Collection();

		
		List caseIndividuals = Objects.nonNull(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.CASE_INDIVIDUALS))
				? (List) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.CASE_INDIVIDUALS)
				: null;

		Integer indvSeqNum = 1;

		if (null != caseIndividuals && !caseIndividuals.isEmpty()) {
			/* Converting CaseIndividual JSON String to Java POJO */
			
			String caseIndividualString = new ObjectMapper().writeValueAsString(caseIndividuals);
			CaseIndividualDetails[] caseIndividualsDetailArray = new ObjectMapper().readValue(caseIndividualString,
					CaseIndividualDetails[].class);
			
			CaseIndividualDetails[] filteredPrimaryCaseIndividual = Stream.of(caseIndividualsDetailArray)
			.filter(caseIndividual -> Objects.nonNull(caseIndividual.getPrimaryApplicant()) 
					&& caseIndividual.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y))
			.toArray(CaseIndividualDetails[]::new);
			
			Boolean isprimaryApplicantPresent = filteredPrimaryCaseIndividual.length > 0;
			
			for (CaseIndividualDetails caseIndv : caseIndividualsDetailArray) {
				
				if(!isprimaryApplicantPresent && indvSeqNum.equals(1)) {
					caseIndv.setPrimaryApplicant(HouseHoldDemoGraphicsConstants.Y);
				}
				
				if(Objects.isNull(caseIndv.getPrimaryApplicant()) && !indvSeqNum.equals(1)) {
					caseIndv.setPrimaryApplicant(HouseHoldDemoGraphicsConstants.N);
				}
				
				APP_INDV_Cargo appIndvCargo = setAppIndvDetails(appNum, indvSeqNum, caseIndv, srcAppInd);
				appIndvCollection.add(appIndvCargo);

				CP_APP_PGM_INDV_Cargo appPgmIndvCargo = setAppPgmIndvDetails(appNum, indvSeqNum, caseIndv);
				if (Objects.nonNull(appPgmIndvCargo)) {
					appPgmIndvCollection.add(appPgmIndvCargo);
				}

				APP_PGM_RQST_Cargo appPgmRqstCargo = setAppPgmRqstDetails(appNum, caseIndv);
				if (Objects.nonNull(appPgmRqstCargo)) {
					appPgmRqstCollection.add(appPgmRqstCargo);
				}

				CP_APP_RGST_Cargo appRgstCargo;
				setAppRgstCargo(formStatusReqJson, formReportType, appNum, srcAppInd, appRgstCollection, indvSeqNum,
						caseIndv);

				indvSeqNum++;
			}
		}
		/*
		 * Storing individuals, program details and mailing/contact address in
		 * CP_APP_INDV, CP_APP_PGM_INDV, CP_APP_PGM_REQUEST and CP_APP_RGST tables
		 */
		cpAppIndvRepository.saveAll(appIndvCollection);
		cpAppPgmIndvRepository.saveAll(appPgmIndvCollection);
		cpAppPgmRqstRepository.saveAll(appPgmRqstCollection);
		cpAppRgstRepository.saveAll(appRgstCollection);

		/*
		 * Updating new App Number in CP_RMB_REQUEST table
		 */
		updateAppNumInCpRmbRequest(pageCollection, appNum);

		pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
		pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_PGM_INDV_Collection, appPgmIndvCollection);
		pageCollection.put(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL, appPgmRqstCollection);
		pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION, appRgstCollection);
		pageCollection.put(HouseHoldDemoGraphicsConstants.APP_NUM, appNum);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.generateAppNumAndStoreRMBApplicationData() - END", fwTransaction);
	}

	private void setAppRgstCargo(Map formStatusReqJson, String formReportType, String appNum, String srcAppInd,
			CP_APP_RGST_Collection appRgstCollection, Integer indvSeqNum, CaseIndividualDetails caseIndv)
			throws JsonProcessingException {
		CP_APP_RGST_Cargo appRgstCargo;
		if (formReportType.equals(HouseHoldDemoGraphicsConstants.TNB4_TN)) {
			appRgstCargo = setPrimaryIndividualAddress(appNum, indvSeqNum, caseIndv, srcAppInd,
					formStatusReqJson);
			if (Objects.nonNull(appRgstCargo)) {
				//set update date
				Timestamp currentTimeStamp = new Timestamp(new Date().getTime());
				appRgstCargo.setUpdate_dt(currentTimeStamp);
				appRgstCollection.add(appRgstCargo);
			}
		} else {
			appRgstCargo = setCaseIndividualAddressAndContactDetails(appNum, indvSeqNum, caseIndv, srcAppInd);
			if(appRgstCargo != null ) {
				//set update date
				Timestamp currentTimeStamp = new Timestamp(new Date().getTime());
				appRgstCargo.setUpdate_dt(currentTimeStamp);
			}
			appRgstCollection.add(appRgstCargo);
		}
	}

	/**
	 * Method to set src app indicator based on formReportType coming from form
	 * status api clob
	 * 
	 * @param formReportType
	 * @return String
	 * @author ransahu
	 */
	private String setSrcAppIndBasedOnFormType(String formReportType) {
		String srcAppInd = HouseHoldDemoGraphicsConstants.EMPTY;
		if (formReportType.equals(HouseHoldDemoGraphicsConstants.TNB4_TN)) {
			srcAppInd = HouseHoldDemoGraphicsConstants.TNB4_TN;
		}
		return srcAppInd;
	}

	/**
	 * Method to set Case Name from Primary Individual First name and Last name
	 * 
	 * @param pageCollection, caseIndv
	 * @return void
	 * @author ransahu
	 * @param pageCollection
	 */
	private void setCaseNameAsPrimaryIndividual(Map pageCollection, CaseIndividualDetails caseIndv) {
		if (caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			String caseName = caseIndv.getFirstName().concat(HouseHoldDemoGraphicsConstants.ONE_SPACE)
					.concat(caseIndv.getLastName());
			pageCollection.put(HouseHoldDemoGraphicsConstants.CASE_NAME, caseName);
		}
	}

	/**
	 * Method to set details into APP_PGM_RQST_Cargo
	 * 
	 * @param appNum, caseIndv
	 * @return APP_PGM_RQST_Cargo
	 * @author ransahu
	 */
	private APP_PGM_RQST_Cargo setAppPgmRqstDetails(String appNum, CaseIndividualDetails caseIndv) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationTNB4ServiceImpl.setAppPgmRqstDetails() - settting details into APP_PGM_RQST_Cargo");
		if (caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			APP_PGM_RQST_Cargo appPgmRqstCargo = new APP_PGM_RQST_Cargo();
			appPgmRqstCargo.setApp_num(appNum);
			appPgmRqstCargo.setFs_rqst_ind(1);
			appPgmRqstCargo.setFma_rqst_ind(0);
			appPgmRqstCargo.setTanf_rqst_ind(0);
			return appPgmRqstCargo;
		}
		return null;
	}

	/**
	 * Method to set details into CP_APP_PGM_INDV_Cargo
	 * 
	 * @param appNum, indvSeqNum, caseIndv
	 * @return CP_APP_PGM_INDV_Cargo
	 * @author ransahu
	 */
	private CP_APP_PGM_INDV_Cargo setAppPgmIndvDetails(String appNum, Integer indvSeqNum,
			CaseIndividualDetails caseIndv) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationTNB4ServiceImpl.setAppPgmIndvDetails() - setting details into CP_APP_PGM_INDV_Cargo");
		if (!caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			CP_APP_PGM_INDV_Cargo appPgmIndvCargo = new CP_APP_PGM_INDV_Cargo();
			appPgmIndvCargo.setApp_num(appNum);
			appPgmIndvCargo.setApp_pgm_indv_id(indvSeqNum.toString());
			appPgmIndvCargo.setIndv_seq_num(Double.valueOf(indvSeqNum));
			appPgmIndvCargo.setFs_rqst_ind(HouseHoldDemoGraphicsConstants.ONE_STRING);
			appPgmIndvCargo.setTanf_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO_STRING);
			appPgmIndvCargo.setFma_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO_STRING);
			return appPgmIndvCargo;
		}
		return null;
	}

	/**
	 * Method to set details into APP_INDV_Cargo
	 * 
	 * @param appNum, indvSeqNum, caseIndv, srcAppInd
	 * @return APP_INDV_Cargo
	 * @author ransahu
	 */
	private APP_INDV_Cargo setAppIndvDetails(String appNum, Integer indvSeqNum, CaseIndividualDetails caseIndv,
			String srcAppInd) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationTNB4ServiceImpl.setAppIndvDetails() - settting details into APP_INDV_Cargo");
		APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
		appIndvCargo.setApp_num(appNum);
		appIndvCargo.setIndv_seq_num(indvSeqNum);
		appIndvCargo.setFst_nam(caseIndv.getFirstName());
		appIndvCargo.setLast_nam(caseIndv.getLastName());
		appIndvCargo.setMid_init(caseIndv.getMiddleName());
		appIndvCargo.setSuffix_name(caseIndv.getSuffix());
		appIndvCargo.setCinNumber(caseIndv.getCin());
		appIndvCargo.setBrth_dt(caseIndv.getDob());
		appIndvCargo.setAge(caseIndv.getAge());
		appIndvCargo.setSex_ind(caseIndv.getGenderCode());
		appIndvCargo.setSrc_app_ind(srcAppInd);
		if (caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			appIndvCargo.setPrim_prsn_sw(HouseHoldDemoGraphicsConstants.Y);
		}
		return appIndvCargo;
	}

	/**
	 * Method to set Primary Individual Address to CP_APP_RGST_Cargo
	 * 
	 * @param appNum, indvSeqNum, caseIndv, srcAppInd, formStatusReqJson
	 * @return CP_APP_RGST_Cargo
	 * @author ransahu
	 * @throws JsonProcessingException
	 */
	private CP_APP_RGST_Cargo setPrimaryIndividualAddress(String appNum, Integer indvSeqNum,
			CaseIndividualDetails caseIndv, String srcAppInd, Map formStatusReqJson) throws JsonProcessingException {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationTNB4ServiceImpl.setPrimaryIndividualAddress() "
						+ "- settting Primary Individual Address to CP_APP_RGST_Cargo");

		/*
		 * Getting MailingAddress and MailbackAddressOffice from the FormStatus Request
		 * Json Clob
		 */
		String mailingAddressString = new ObjectMapper()
				.writeValueAsString(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.MAILING_ADDRESS));
		CaseIndividualDetailsAddress mailingAddress = new ObjectMapper().readValue(mailingAddressString,
				CaseIndividualDetailsAddress.class);
		String mailbackAddressOfficeString = new ObjectMapper()
				.writeValueAsString(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.MAILBACK_ADDRESS_OFFICE));
		CaseIndividualDetailsAddress mailbackAddressOffice = new ObjectMapper().readValue(mailbackAddressOfficeString,
				CaseIndividualDetailsAddress.class);

		if (Objects.nonNull(mailingAddress) && Objects.nonNull(mailbackAddressOffice)
				&& caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			CP_APP_RGST_Cargo appRgstCargo = new CP_APP_RGST_Cargo();
			appRgstCargo.setApp_num(appNum);
			appRgstCargo.setSrc_app_ind(srcAppInd);
			appRgstCargo.setIndv_seq_num(indvSeqNum);
			if (Objects.nonNull(mailingAddress)) {
				appRgstCargo.setHshl_l1_adr(mailingAddress.getAddressLine());
				appRgstCargo.setHshl_city_adr(mailingAddress.getCity());
				appRgstCargo.setHshl_sta_adr(mailingAddress.getState());
				appRgstCargo.setHshl_zip_adr(mailingAddress.getZipcode());
				appRgstCargo.setHshl_apt_num(mailingAddress.getApt());
			}
			if (Objects.nonNull(mailbackAddressOffice)) {
				appRgstCargo.setAlt_l1_adr(mailbackAddressOffice.getAddressLine());
				appRgstCargo.setAlt_city_adr(mailbackAddressOffice.getCity());
				appRgstCargo.setAlt_sta_adr(mailbackAddressOffice.getState());
				appRgstCargo.setAlt_zip_adr(mailbackAddressOffice.getZipcode());
				appRgstCargo.setAlt_apt_num(mailbackAddressOffice.getApt());
			}
			return appRgstCargo;
		}
		return null;
	}

	/**
	 * Method to set Case Individual Address and Contact details to
	 * CP_APP_RGST_Cargo
	 * 
	 * @param appNum, indvSeqNum, caseIndv, srcAppInd
	 * @return CP_APP_RGST_Cargo
	 * @author ransahu
	 */
	private CP_APP_RGST_Cargo setCaseIndividualAddressAndContactDetails(String appNum, Integer indvSeqNum,
			CaseIndividualDetails caseIndv, String srcAppInd) {
		CP_APP_RGST_Cargo appRgstCargo = new CP_APP_RGST_Cargo();
		appRgstCargo.setApp_num(appNum);
		appRgstCargo.setSrc_app_ind(srcAppInd);
		appRgstCargo.setIndv_seq_num(indvSeqNum);
		appRgstCargo.setHshl_email_adr(caseIndv.getEmailAddress());
		appRgstCargo.setEmail_receipt(caseIndv.getEmailAddress());
		if (Objects.nonNull(caseIndv.getHomePhoneNumber())) {
			appRgstCargo.setHshl_home_phn_num(
					caseIndv.getHomePhoneNumber().getExtension() + caseIndv.getHomePhoneNumber().getNumber());
		}
		if (Objects.nonNull(caseIndv.getCellPhoneNumber())) {
			appRgstCargo.setHshl_work_phn_num(
					caseIndv.getCellPhoneNumber().getExtension() + caseIndv.getCellPhoneNumber().getNumber());
			appRgstCargo.setPhonenum_receipt(
					caseIndv.getCellPhoneNumber().getExtension() + caseIndv.getCellPhoneNumber().getNumber());
		}
		if (Objects.nonNull(caseIndv.getHomeAddress())) {
			appRgstCargo.setHshl_l1_adr(caseIndv.getHomeAddress().getAddressLine());
			appRgstCargo.setHshl_city_adr(caseIndv.getHomeAddress().getCity());
			appRgstCargo.setHshl_sta_adr(caseIndv.getHomeAddress().getState());
			appRgstCargo.setHshl_zip_adr(caseIndv.getHomeAddress().getZipcode());
			appRgstCargo.setHshl_apt_num(caseIndv.getHomeAddress().getApt());
		}
		if (Objects.nonNull(caseIndv.getMailingAddressIfDifferent())) {
			appRgstCargo.setAlt_l1_adr(caseIndv.getHomeAddress().getAddressLine());
			appRgstCargo.setAlt_city_adr(caseIndv.getHomeAddress().getCity());
			appRgstCargo.setAlt_sta_adr(caseIndv.getHomeAddress().getState());
			appRgstCargo.setAlt_zip_adr(caseIndv.getHomeAddress().getZipcode());
			appRgstCargo.setAlt_apt_num(caseIndv.getHomeAddress().getApt());
		}
		return appRgstCargo;
	}

	/**
	 * Method to Update new App Number in CP_RMB_REQUEST table
	 * 
	 * @param pageCollection, appNum
	 * @return void
	 * @author ransahu
	 */
	private void updateAppNumInCpRmbRequest(final Map pageCollection, String appNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationTNB4ServiceImpl.updateAppNumInCpRmbRequest() "
						+ "- updating App Number in CP_RMB_REQUEST table");
		RMB_RQST_Collection existingRmbRqstCollection = Objects
				.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION))
						? (RMB_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION)
						: null;
		if (Objects.nonNull(existingRmbRqstCollection) && !existingRmbRqstCollection.isEmpty()) {
			RMB_RQST_Cargo rmbRqstCargo = existingRmbRqstCollection.getCargo(0);
			rmbRqstCargo.setSsp_app_num(Integer.parseInt(appNum));
			rmbRqstRepository.save(rmbRqstCargo);
			pageCollection.put(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION, existingRmbRqstCollection);
		}
	}

	/**
	 * Method to store data from Move in, Move out, SSI SSP and Change in income
	 * screen of Redetermination TNB4 flow
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void saveTNB4RenewalFormData(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.saveTNB4RenewalFormData() - START", fwTransaction);

		try {
			final Map pageCollection = fwTransaction.getPageCollection();
			String appNum = fwTransaction.getUserDetails().getAppNumber();

			CpAppTnb4Redet_Collection cpAppTnb4RedetCollection = (CpAppTnb4Redet_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_APP_TNB4_REDET_COLLECTION);
			CpAppTnb4Redet_Cargo cpAppTnb4RedetCargo = cpAppTnb4RedetCollection.getCargo(0);

			cpAppTnb4RedetCargo.setAppNum(appNum);
			cpAppTnb4RedetCargo.setSrcAppInd(HouseHoldDemoGraphicsConstants.TNB4_TN);
			cpAppTnb4RedetCargo.setFormType(HouseHoldDemoGraphicsConstants.TNB4_TN);

			List<CpAppTnb4MoveoutSsiSsp_Cargo> moveOutSsiSspCargoList = new ArrayList<>();

			String[] moveOut = cpAppTnb4RedetCargo.getMoveOut();
			String[] ssiSsp = cpAppTnb4RedetCargo.getSsiSsp();

			setMoveOutSsiSspData(appNum, moveOut, HouseHoldDemoGraphicsConstants.MOVE_OUT, moveOutSsiSspCargoList);
			setMoveOutSsiSspData(appNum, ssiSsp, HouseHoldDemoGraphicsConstants.SSI_SSP, moveOutSsiSspCargoList);

			cpAppTnb4RedetCargo.setTnb4MoveoutssiSspList(moveOutSsiSspCargoList);

			cpAppTnb4RedetRepository.save(cpAppTnb4RedetCargo);

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in saveTNB4RenewalFormData()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"saveTNB4RenewalFormData", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationTNB4ServiceImpl.saveTNB4RenewalFormData() - END", fwTransaction);
	}

	/**
	 * Method to add data from moveOut/ssiSsp array to moveOutSsiSspCargoList
	 * 
	 * @param appNum, moveOutSsiSsp, indvType, moveOutSsiSspCargoList
	 * @return void
	 * @author ransahu
	 */
	private void setMoveOutSsiSspData(String appNum, String[] moveOutSsiSsp, String indvType,
			List<CpAppTnb4MoveoutSsiSsp_Cargo> moveOutSsiSspCargoList) {
		if (moveOutSsiSsp.length > 0) {
			for (String indvSeqNum : moveOutSsiSsp) {
				CpAppTnb4MoveoutSsiSsp_Cargo moveOutSsiSspCargo = new CpAppTnb4MoveoutSsiSsp_Cargo();
				Double moveOutIndvSeqNum = Double.parseDouble(indvSeqNum);
				moveOutSsiSspCargo.setIndvSeqNum(moveOutIndvSeqNum);
				moveOutSsiSspCargo.setAppNum(appNum);
				moveOutSsiSspCargo.setIndvType(indvType);
				moveOutSsiSspCargo.setSrcAppInd(HouseHoldDemoGraphicsConstants.TNB4_TN);
				moveOutSsiSspCargoList.add(moveOutSsiSspCargo);
			}
		}
	}

}
