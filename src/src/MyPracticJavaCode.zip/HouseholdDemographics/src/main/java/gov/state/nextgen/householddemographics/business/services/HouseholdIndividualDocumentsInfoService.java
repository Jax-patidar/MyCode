package gov.state.nextgen.householddemographics.business.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_OTHER_SITUATIONS_Collection;
import gov.state.nextgen.householddemographics.business.rules.ABDisabilityBO;
import gov.state.nextgen.householddemographics.business.rules.ABHouseholdMembersSummaryBO;
import gov.state.nextgen.householddemographics.business.rules.ABProgramInformationBO;
import gov.state.nextgen.householddemographics.business.rules.HouseHoldSummaryBO;
import gov.state.nextgen.householddemographics.business.rules.PROtherSituationsBO;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;

@Service("HouseholdIndividualInfoService")
public class HouseholdIndividualDocumentsInfoService  implements HouseholdDemographicsService {

	@Autowired
	private ABDisabilityBO abDisabilityBO;

	@Autowired
	private ABHouseholdMembersSummaryBO abHouseholdMembersSummaryBO;

	@Autowired
	private ABProgramInformationBO programInfoBo;
	
	@Autowired
	private HouseHoldSummaryBO houseHoldSummaryBO;
	
	@Autowired
	private PROtherSituationsBO pROtherSituationsBO;
	
	@Autowired
    private ExceptionUtil exceptionUtil;
	
	ArrayList<Integer> indvList = null;

	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {

		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.HOUSEHOLD_INDIVIDUAL_INFO:
			getHouseholdIndividualInfo(txnBean);
			break;
		case HouseHoldDemoGraphicsConstants.HOUSEHOLD_CONFIRMATION_INFO:
			getConfirmationInfo(txnBean);
			break;
		default:
		}
	}


	private void getHouseholdIndividualInfo(FwTransaction txnBean) {
		
		final long startTime = System.currentTimeMillis();
		
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdIndividualInfoService.getHouseholdIndividualInfo() - START", txnBean);
			
			getAppIndvInfo(txnBean);
			getDisabilityInfo(txnBean);			
			getAppCaseInfo(txnBean);
			//commented as part of enhancement CSPM-35846(Should not display at all on Recommended Documents)- START
			//getSchoolVerficationInfo(txnBean);
			//commented as part of enhancement CSPM-35846(Should not display at all on Recommended Documents)- END
			getOtherSituationsInfo(txnBean);
		} catch(Exception exception) {
			FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getHouseholdIndividualInfo", txnBean.getUserDetails().getAppNumber(),
        			txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdIndividualInfoService.getHouseholdIndividualInfo() - END", txnBean);
	}
	
	private void getConfirmationInfo(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdIndividualInfoService.getConfirmationInfo() - START", txnBean);
			
			getAppCaseInfo(txnBean);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdIndividualInfoService.getConfirmationInfo() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + " milliseconds", txnBean);

		} catch(Exception exception) { 
			FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getConfirmationInfo", txnBean.getUserDetails().getAppNumber(),
        			txnBean.getUserDetails().getLoginUserId(), true);
		}

	}

	private void getDisabilityInfo(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdIndividualInfoService.getDisabilityInfo() - START", txnBean);
     try {
		UserDetails userDetails = txnBean.getUserDetails();
		String appNum = userDetails.getAppNumber();
		APP_IN_DABL_Collection appInDablColl;
		
		appInDablColl = abDisabilityBO.loadDisabilityDetails(appNum, indvList);
		if(Objects.nonNull(appInDablColl) && !(appInDablColl.isEmpty())) {
			txnBean.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_IN_DABL_COLL, appInDablColl);
		}
     }catch(Exception e) {
    	throw e;
	 }
     FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdIndividualInfoService.getDisabilityInfo() - END", txnBean);
	}

	private void getAppIndvInfo(FwTransaction txnBean) {
     try {
		UserDetails userDetails = txnBean.getUserDetails();
		String appNum = userDetails.getAppNumber();
		APP_INDV_Collection appIndvColl;
		appIndvColl = abHouseholdMembersSummaryBO.loadPersonDetailsByAppNum(appNum);		
		indvList = getIndvList(appIndvColl);
		if(Objects.nonNull(appIndvColl) && !(appIndvColl.isEmpty())) {
			txnBean.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvColl);
		}
     }catch(Exception e) {
    	 throw e;
     }
	}

	private void getAppCaseInfo(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsServiceImpl.getAppCaseInfo() - START", txnBean);
      try {
		UserDetails userDetails = txnBean.getUserDetails();
		String appNum = userDetails.getAppNumber();
		APP_RQST_Collection appRqstColl = programInfoBo.loadAllDetails(appNum);
		if(Objects.nonNull(appRqstColl) && !(appRqstColl.isEmpty())) {
			txnBean.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, appRqstColl);
		}
      }catch(Exception e) {
    	  throw e;
      }
      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDemographicsServiceImpl.getAppCaseInfo() - END", txnBean);
	}

	private ArrayList<Integer> getIndvList(APP_INDV_Collection appIndvColl){
		ArrayList<Integer> indvidualList = new ArrayList<>();
		if(appIndvColl!=null && !appIndvColl.isEmpty()) {
			for(int i=0; i<appIndvColl.size(); i++) {
				indvidualList.add(appIndvColl.getCargo(i).getIndv_seq_num());
			}
		}
		return indvidualList;
	}
	private void getSchoolVerficationInfo(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdIndividualInfoService.getSchoolVerficationInfo() - START", txnBean);
     try {
		UserDetails userDetails = txnBean.getUserDetails();
		String appNum = userDetails.getAppNumber();
		APP_IN_SCHLE_Collection appInSchool;
		appInSchool = houseHoldSummaryBO.loadCollegeTradeSchool(appNum, indvList);
		if(Objects.nonNull(appInSchool) && !(appInSchool.isEmpty())) {
			txnBean.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION, appInSchool);
		}
     }catch(Exception exception) {
    	 FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in HouseholdDemographics.getSchoolVerficationInfo()", txnBean);

			FwExceptionManager.handleException(exception, this.getClass().getName(), "getSchoolVerficationInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
	 }
     FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdIndividualInfoService.getDisabilityInfo() - END", txnBean);
		
	}
	
	private void getOtherSituationsInfo(FwTransaction txnBean)
	{
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdIndividualInfoService.getOtherSituationsInfo() - START", txnBean);
		try {
				UserDetails userDetails = txnBean.getUserDetails();
				String appNum = userDetails.getAppNumber();
				CP_APP_OTHER_SITUATIONS_Collection otherSituationsColl = pROtherSituationsBO.getByAppNum(appNum);
				if(Objects.nonNull(otherSituationsColl) && !(otherSituationsColl.isEmpty())) {
					txnBean.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_OTHER_SITUATIONS_COLLECTION, otherSituationsColl);
				}
		  }
		catch(Exception exception) {
	    	 FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
						"Error occured in HouseholdDemographics.getOtherSituationsInfo()", txnBean);
				FwExceptionManager.handleException(exception, this.getClass().getName(), "getOtherSituationsInfo",
						txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		 }
		 FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdIndividualInfoService.getOtherSituationsInfo() - END", txnBean);
	}


}
