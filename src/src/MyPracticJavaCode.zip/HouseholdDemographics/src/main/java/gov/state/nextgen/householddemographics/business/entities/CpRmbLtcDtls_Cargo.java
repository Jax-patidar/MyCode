/**
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * @author swabehera
 *
 */
@Entity
@Table(name = "CP_RMB_LTC_DTLS")
@IdClass(CpRmbLtcDtls_Key.class)
public class CpRmbLtcDtls_Cargo extends AbstractCargo implements Serializable {

	private static final long serialVersionUID = 2277840338874245092L;
	
	@Transient
	private String appNum;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	@Column(name = "indv_seq_num")
	@JsonProperty("indv_seq_num")
	private Integer indvSeqNum;
	
	@Id
	@Column(name = "seq_num")
	private Integer seqNum;
	
	@Column(name = "facility_name")
	private String facilityName;
	
	@Column(name = "facility_l1_address")
	private String facilityAddressLine1;
	
	@Column(name = "facility_l2_address")
	private String facilityAddressLine2;
	
	@Column(name = "facility_city_address")
	private String facilityAddressCity;
	
	@Column(name = "facility_state_address")
	private String facilityAddressState;
	
	@Column(name = "facility_zip_address")
	private String facilityAddressZip;
	
	@Column(name = "spouse_first_name")
	private String spouseFirstName;
	
	@Column(name = "spouse_mid_name")
	private String spouseMidName;
	
	@Column(name = "spouse_last_name")
	private String spouseLastName;
	
	@Column(name = "spouse_l1_address")
	private String spouseAddressLine1;
	
	@Column(name = "spouse_l2_address")
	private String spouseAddressLine2;
	
	@Column(name = "spouse_city_address")
	private String spouseAddressCity;
	
	@Column(name = "spouse_state_address")
	private String spouseAddressState;
	
	@Column(name = "spouse_zip_address")
	private String spouseAddressZip;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "entrance_dt")
	private Date entanceDate;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "discharge_dt")
	private Date dischargeDate;
	
	@Column(name   = "ltc_calsaws_object")
	private String ltcCalsawsObject;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "change_dt")
	private Date changeDate;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name = "end_dt")
	private Date endDate;
	
	@Transient
	private String facilityAddress;
	
	private String is_spouse;

	/* 
	 * Getters and Setters
	 */

	
	public String getFacilityAddress() {
		return facilityAddress;
	}

	

	public String getIs_spouse() {
		return is_spouse;
	}



	public void setIs_spouse(String is_spouse) {
		this.is_spouse = is_spouse;
	}



	public void setFacilityAddress(String facilityAddress) {
		this.facilityAddress = facilityAddress;
	}

	public String getAppNum() {
		return String.valueOf(app_number);
	}
	public void setAppNum(String appNum) {
		this.app_number = Integer.parseInt(appNum);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.appNum = String.valueOf(app_number);
	}
	
	public Integer getIndvSeqNum() {
		return indvSeqNum;
	}

	public void setIndvSeqNum(Integer indvSeqNum) {
		this.indvSeqNum = indvSeqNum;
	}

	public Integer getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}
	
	public String getFacilityName() {
		return facilityName;
	}

	public void setFacilityName(String facilityName) {
		this.facilityName = facilityName;
	}

	public String getFacilityAddressLine1() {
		return facilityAddressLine1;
	}

	public void setFacilityAddressLine1(String facilityAddressLine1) {
		this.facilityAddressLine1 = facilityAddressLine1;
	}

	public String getFacilityAddressLine2() {
		return facilityAddressLine2;
	}

	public void setFacilityAddressLine2(String facilityAddressLine2) {
		this.facilityAddressLine2 = facilityAddressLine2;
	}

	public String getFacilityAddressCity() {
		return facilityAddressCity;
	}

	public void setFacilityAddressCity(String facilityAddressCity) {
		this.facilityAddressCity = facilityAddressCity;
	}

	public String getFacilityAddressState() {
		return facilityAddressState;
	}

	public void setFacilityAddressState(String facilityAddressState) {
		this.facilityAddressState = facilityAddressState;
	}

	public String getFacilityAddressZip() {
		return facilityAddressZip;
	}

	public void setFacilityAddressZip(String facilityAddressZip) {
		this.facilityAddressZip = facilityAddressZip;
	}

	public String getSpouseFirstName() {
		return spouseFirstName;
	}

	public void setSpouseFirstName(String spouseFirstName) {
		this.spouseFirstName = spouseFirstName;
	}

	public String getSpouseMidName() {
		return spouseMidName;
	}

	public void setSpouseMidName(String spouseMidName) {
		this.spouseMidName = spouseMidName;
	}

	public String getSpouseLastName() {
		return spouseLastName;
	}

	public void setSpouseLastName(String spouseLastName) {
		this.spouseLastName = spouseLastName;
	}

	public String getSpouseAddressLine1() {
		return spouseAddressLine1;
	}

	public void setSpouseAddressLine1(String spouseAddressLine1) {
		this.spouseAddressLine1 = spouseAddressLine1;
	}

	public String getSpouseAddressLine2() {
		return spouseAddressLine2;
	}

	public void setSpouseAddressLine2(String spouseAddressLine2) {
		this.spouseAddressLine2 = spouseAddressLine2;
	}

	public String getSpouseAddressCity() {
		return spouseAddressCity;
	}

	public void setSpouseAddressCity(String spouseAddressCity) {
		this.spouseAddressCity = spouseAddressCity;
	}

	public String getSpouseAddressState() {
		return spouseAddressState;
	}

	public void setSpouseAddressState(String spouseAddressState) {
		this.spouseAddressState = spouseAddressState;
	}

	public String getSpouseAddressZip() {
		return spouseAddressZip;
	}

	public void setSpouseAddressZip(String spouseAddressZip) {
		this.spouseAddressZip = spouseAddressZip;
	}

	public Date getEntanceDate() {
		return entanceDate;
	}

	public void setEntanceDate(Date entanceDate) {
		this.entanceDate = entanceDate;
	}

	public Date getDischargeDate() {
		return dischargeDate;
	}

	public void setDischargeDate(Date dischargeDate) {
		this.dischargeDate = dischargeDate;
	}
	public String getLtcCalsawsObject() {
		return ltcCalsawsObject;
	}

	public void setLtcCalsawsObject(String ltcCalsawsObject) {
		this.ltcCalsawsObject = ltcCalsawsObject;
	}

	public Date getChangeDate() {
		return changeDate;
	}

	public void setChangeDate(Date changeDate) {
		this.changeDate = changeDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
}


