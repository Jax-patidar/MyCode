package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4MoveoutSsiSsp_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4Redet_Cargo;

@Repository
public interface Tnb4RedetRepository extends CrudRepository<CpAppTnb4Redet_Cargo, Long>{

	
	
	@Query("SELECT T FROM CpAppTnb4Redet_Cargo T where T.app_number= :appNum")
	public CpAppTnb4Redet_Cargo[] findByAppNum(@Param("appNum") Integer appNum);
}
