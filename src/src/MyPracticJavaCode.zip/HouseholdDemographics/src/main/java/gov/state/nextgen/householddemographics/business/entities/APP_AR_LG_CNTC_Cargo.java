package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;


import javax.persistence.*;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * This class contains the entities of CP_APP_AR_LG_CNTC
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

public class APP_AR_LG_CNTC_Cargo extends AbstractCargo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6552916706967662890L;
	
	@Id
	private String app_num;
	
	@Id
	private Integer auth_rep_seq_num;
	
	@Id
	private String src_app_ind;
	
	private String agency_name;
	private String city_adr;
	private String line1_adr;
	private String phone_num;
	private Integer rec_cplt_ind;
	private String state_adr;
	private String zip_adr;
	private String line2_adr;
	private String ar_rlt_with_app_cd; 
	private String con_name;
	private String addrZip4;
	
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getAgency_name() {
		return agency_name;
	}
	public void setAgency_name(String agency_name) {
		this.agency_name = agency_name;
	}
	public Integer getAuth_rep_seq_num() {
		return auth_rep_seq_num;
	}
	public void setAuth_rep_seq_num(Integer auth_rep_seq_num) {
		this.auth_rep_seq_num = auth_rep_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getCity_adr() {
		return city_adr;
	}
	public void setCity_adr(String city_adr) {
		this.city_adr = city_adr;
	}
	public String getLine1_adr() {
		return line1_adr;
	}
	public void setLine1_adr(String line1_adr) {
		this.line1_adr = line1_adr;
	}
	public String getPhone_num() {
		return phone_num;
	}
	public void setPhone_num(String phone_num) {
		this.phone_num = phone_num;
	}
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getState_adr() {
		return state_adr;
	}
	public void setState_adr(String state_adr) {
		this.state_adr = state_adr;
	}
	public String getZip_adr() {
		return zip_adr;
	}
	public void setZip_adr(String zip_adr) {
		this.zip_adr = zip_adr;
	}
	public String getLine2_adr() {
		return line2_adr;
	}
	public void setLine2_adr(String line2_adr) {
		this.line2_adr = line2_adr;
	}
	public String getAr_rlt_with_app_cd() {
		return ar_rlt_with_app_cd;
	}
	public void setAr_rlt_with_app_cd(String ar_rlt_with_app_cd) {
		this.ar_rlt_with_app_cd = ar_rlt_with_app_cd;
	}
	public String getCon_name() {
		return con_name;
	}
	public void setCon_name(String con_name) {
		this.con_name = con_name;
	}
	public String getAddrZip4() {
		return addrZip4;
	}
	public void setAddrZip4(String addrZip4) {
		this.addrZip4 = addrZip4;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((addrZip4 == null) ? 0 : addrZip4.hashCode());
		result = prime * result + ((agency_name == null) ? 0 : agency_name.hashCode());
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((ar_rlt_with_app_cd == null) ? 0 : ar_rlt_with_app_cd.hashCode());
		result = prime * result + ((auth_rep_seq_num == null) ? 0 : auth_rep_seq_num.hashCode());
		result = prime * result + ((city_adr == null) ? 0 : city_adr.hashCode());
		result = prime * result + ((con_name == null) ? 0 : con_name.hashCode());
		result = prime * result + ((line1_adr == null) ? 0 : line1_adr.hashCode());
		result = prime * result + ((line2_adr == null) ? 0 : line2_adr.hashCode());
		result = prime * result + ((phone_num == null) ? 0 : phone_num.hashCode());
		result = prime * result + ((rec_cplt_ind == null) ? 0 : rec_cplt_ind.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		result = prime * result + ((state_adr == null) ? 0 : state_adr.hashCode());
		result = prime * result + ((zip_adr == null) ? 0 : zip_adr.hashCode());
		return result;
	}
	
	@Override
	public String toString() {
		return "APP_AR_LG_CNTC_Cargo [app_num=" + app_num + ", agency_name=" + agency_name + ", auth_rep_seq_num="
				+ auth_rep_seq_num + ", src_app_ind=" + src_app_ind + ", city_adr=" + city_adr + ", line1_adr="
				+ line1_adr + ", phone_num=" + phone_num + ", rec_cplt_ind=" + rec_cplt_ind + ", state_adr=" + state_adr
				+ ", zip_adr=" + zip_adr + ", line2_adr=" + line2_adr + ", ar_rlt_with_app_cd=" + ar_rlt_with_app_cd
				+ ", con_name=" + con_name + ", addrZip4=" + addrZip4 + "]";
	}
	
	
	
	
	
	
	

	
	
}
