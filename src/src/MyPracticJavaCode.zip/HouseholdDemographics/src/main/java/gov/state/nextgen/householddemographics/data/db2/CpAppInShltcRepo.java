package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.APP_IN_SHLTC_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SHLTC_Id;

@NoRepositoryBean
public interface CpAppInShltcRepo extends CrudRepository<APP_IN_SHLTC_Cargo, APP_IN_SHLTC_Id> {
	
	@Query(value="select * from ie_ssp_owner_fin.cp_app_in_shltc where app_num = ?1",nativeQuery=true)
	public APP_IN_SHLTC_Cargo[] loadFacilityShelterDtls(String appNum);
	
}