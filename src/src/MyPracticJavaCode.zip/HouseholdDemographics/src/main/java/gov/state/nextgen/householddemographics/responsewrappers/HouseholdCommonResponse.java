package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_HSHL_DETAILS_DISASTER_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_HSHL_DETAILS_DISASTER_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;

public class HouseholdCommonResponse {

	DriverPageResponse driverPageResponse = new DriverPageResponse();

	public HouseholdCommonResponse(String appNumber,String pageID,String nextPageAction,String nextPageID,String previousPageID) {
		super();
		driverPageResponse.setCurrentPageID(pageID);
		driverPageResponse.setAppNum(String.valueOf(appNumber));
		driverPageResponse.setNextPageAction(nextPageAction);
		driverPageResponse.setNextPageID(nextPageID);
		driverPageResponse.setPreviousPageID(previousPageID);
	}

	void generateIndividualDriverResponse(Map<String, Object> pageCollection) {
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_INDV_Collection Started");

		List<APP_INDV_Cargo> indvList = new ArrayList<>();
		APP_INDV_Cargo cargo = null;
		APP_INDV_Collection appCollection = pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) != null
						? (APP_INDV_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION)
						: null;
		if (appCollection != null && !appCollection.isEmpty()) {
			for (int i = 0; i < appCollection.size(); i++) {
				cargo = appCollection.getCargo(i);
				indvList.add(cargo);
			}

		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, indvList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_INDV_Collection completed");
	}

	void generateContactDriverResponse(Map<String, Object> pageCollection) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_RGST_Collection started");

		List<CP_APP_RGST_Cargo> rgstList = new ArrayList<>();
		CP_APP_RGST_Collection rgstColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION) != null
						? (CP_APP_RGST_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION)
						: null;
		if (rgstColl != null && !rgstColl.isEmpty()) {
			for (int i = 0; i < rgstColl.size(); i++) {
				CP_APP_RGST_Cargo rgstCargo = rgstColl.getCargo(i);
				rgstList.add(rgstCargo);
			}

		}

		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION, rgstList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_RGST_Collection completed");
	}

	void generateAuthDriverResponse(Map<String, Object> pageCollection) {
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_AUTH_REP_Collection started");
		
		List<CP_APP_AUTH_REP_Cargo> repList = new ArrayList<>();

		CP_APP_AUTH_REP_Collection repColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_APP_AUTH_REP_COLLECTION) != null
						? (CP_APP_AUTH_REP_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_APP_AUTH_REP_COLLECTION)
						: null;
		if (repColl != null && !repColl.isEmpty()) {
			for (int i = 0; i < repColl.size(); i++) {
				CP_APP_AUTH_REP_Cargo repCargo = repColl.getCargo(i);
				repList.add(repCargo);
			}

		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_AUTH_REP_COLLECTION, repList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_AUTH_REP_Collection completed");
	}

	void generateProgramDriverResponse(Map<String, Object> pageCollection) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_PGM_RQST_Collection started");
		
		List<APP_PGM_RQST_Cargo> progList = new ArrayList<>();
		APP_PGM_RQST_Collection programColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_APP_PGM_RQST_COLLECTION) != null
						? (APP_PGM_RQST_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_APP_PGM_RQST_COLLECTION)
						: null;

		if (programColl != null && !programColl.isEmpty()) {
			for (Iterator<?> iterator = programColl.iterator(); iterator.hasNext();) {
				APP_PGM_RQST_Cargo pgmCargo = (APP_PGM_RQST_Cargo) iterator.next();
				progList.add(pgmCargo);
			}

		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_PGM_RQST_COLLECTION, progList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_PGM_RQST_Collection completed");
	}

	void generateRelationDriverResponse(Map<String, Object> pageCollection) {
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_HSHL_RLT_Collection started");

		List<CP_APP_HSHL_RLT_Cargo> rltList = new ArrayList<>();
		CP_APP_HSHL_RLT_Collection rltColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION) != null
						? (CP_APP_HSHL_RLT_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION)
						: null;
		if (rltColl != null && !rltColl.isEmpty()) {
			for (Iterator<?> iterator = rltColl.iterator(); iterator.hasNext();) {
				CP_APP_HSHL_RLT_Cargo rltCargo = (CP_APP_HSHL_RLT_Cargo) iterator.next();
				rltList.add(rltCargo);
			}

		}
		driverPageResponse.getPageCollection().put((String) HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION,
				rltList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_APP_HSHL_RLT_Collection completed");  
	}

	void generateHHDetailsDriverResponse(Map<String, Object> pageCollection) {
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_HSHL_DETAILS_DISASTER_Collection started");

		List<CP_HSHL_DETAILS_DISASTER_Cargo> hshlDtlsList = new ArrayList<>();
		CP_HSHL_DETAILS_DISASTER_Collection hshlDtlsColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_HSHL_DETAILS_DISASTER_COLLECTION) != null
						? (CP_HSHL_DETAILS_DISASTER_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_HSHL_DETAILS_DISASTER_COLLECTION)
						: null;
		if (hshlDtlsColl != null && !hshlDtlsColl.isEmpty()) {
			for (Iterator<?> iterator = hshlDtlsColl.iterator(); iterator.hasNext();) {
				CP_HSHL_DETAILS_DISASTER_Cargo hshlDtlsCargo = (CP_HSHL_DETAILS_DISASTER_Cargo) iterator.next();
				hshlDtlsList.add(hshlDtlsCargo);
			}

		}

		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_HSHL_DETAILS_DISASTER_COLLECTION,
				hshlDtlsList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CP_HSHL_DETAILS_DISASTER_Collection completed");
	}

	void generateSubmitDriverResponse(Map<String, Object> pageCollection) {
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_SBMS_Collection started");
		
		List<APP_SBMS_Cargo> sbmsDtlsList = new ArrayList<>();
		APP_SBMS_Collection sbmsDtlsColl = pageCollection
				.get(HouseHoldDemoGraphicsConstants.APP_SBMS_COLLECTION) != null
						? (APP_SBMS_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_SBMS_COLLECTION)
						: null;
		if (sbmsDtlsColl != null && !sbmsDtlsColl.isEmpty()) {
			for (Iterator<?> iterator = sbmsDtlsColl.iterator(); iterator.hasNext();) {
				APP_SBMS_Cargo sbmsDtlsCargo = (APP_SBMS_Cargo) iterator.next();
				sbmsDtlsList.add(sbmsDtlsCargo);
			}

		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_SBMS_COLLECTION, sbmsDtlsList);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "APP_SBMS_Collection completed");
	}
	
    
    void generateLTCDetailsDriverResponse(Map<String, Object> pageCollection) {
        
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CpRmbLtcDtls_Collection started");
        
        List<CpRmbLtcDtls_Cargo> cpRmbLtcDtlsList = new ArrayList<>();
        
        CpRmbLtcDtls_Collection cpRmbLtcDtlsColl = pageCollection
                .get(HouseHoldDemoGraphicsConstants.CP_RMBLTCDTLSCOLL) != null
                        ? (CpRmbLtcDtls_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.CP_RMBLTCDTLSCOLL)
                        : null;
        if (cpRmbLtcDtlsColl != null && !cpRmbLtcDtlsColl.isEmpty()) {
            for (Iterator<?> iterator = cpRmbLtcDtlsColl.iterator(); iterator.hasNext();) {
                CpRmbLtcDtls_Cargo cpRmbLtcDtlsCargo = (CpRmbLtcDtls_Cargo) iterator.next();
                cpRmbLtcDtlsList.add(cpRmbLtcDtlsCargo);
            }

        }else {
            generateIndividualDriverResponse(pageCollection);
        }
        
        driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_RMBLTCDTLSCOLL,
                cpRmbLtcDtlsList);
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CpRmbLtcDtls_Collection completed");
    }

	public DriverPageResponse getDriverPageResponse() {
		return driverPageResponse;
	}

	public void setDriverPageResponse(DriverPageResponse driverPageResponse) {
		this.driverPageResponse = driverPageResponse;
	}

}
