package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;
@Embeddable
public class CpRmbLtcDtls_Key implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7540653547965610805L;
	
	private Integer app_number; 
	private Integer indvSeqNum;
	private Integer seqNum;
	
	//default constructor
	public CpRmbLtcDtls_Key() {
		
	}

	/**
	 * @param appNum
	 * @param indvSeqNum
	 * @param seqNum
	 */
	public CpRmbLtcDtls_Key(Integer app_number, Integer indvSeqNum, Integer seqNum) {
		super();
		this.app_number = app_number;
		this.indvSeqNum = indvSeqNum;
		this.seqNum = seqNum;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indvSeqNum == null) ? 0 : indvSeqNum.hashCode());
		result = prime * result + ((seqNum == null) ? 0 : seqNum.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CpRmbLtcDtls_Key other = (CpRmbLtcDtls_Key) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (indvSeqNum == null) {
			if (other.indvSeqNum != null)
				return false;
		} else if (!indvSeqNum.equals(other.indvSeqNum))
			return false;
		if (seqNum == null) {
			if (other.seqNum != null)
				return false;
		} else if (!seqNum.equals(other.seqNum))
			return false;
		return true;
	}

	
}
