/**
 * 
 */
package gov.state.nextgen.householddemographics.business.rules;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_CARE_PROV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_CARE_PROV_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CpAppInCareProvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInDablRepository;
/**
 * @author shtony
 *
 */
@Service("ABDisabilityBO")
public class ABDisabilityBO extends AbstractBO {

	@Autowired
	private CpAppInDablRepository cpAppInDablRepository;
	
	private CpAppInCareProvRepository cpAppInCareProvRepository;

	
	
	
	
	public APP_IN_DABL_Collection loadDisabilityDetails(String appnum, Integer indvseqnum, Integer seqnum) {

		return cpAppInDablRepository.getDisabilityDtl(Integer.parseInt(appnum), indvseqnum, seqnum);
	}

	/**
	 * Method description here Validate Disability page
	 */
	public FwMessageList validateDisablityDetail(final APP_IN_DABL_Cargo appDablCargo,
			final String showLoopingQuestion) {
		System.currentTimeMillis();
		FwMessageList messageList = new FwMessageList();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DisabilityBO.validateDisablityDetail() - START");
		try {
			appDablCargo.getSsa_dbal_bnft_rcv_ind();
			final String disablityTypeOther = appDablCargo.getDabl_type_oth_dsc();
			if ((!HouseHoldDemoGraphicsConstants.ONE_STRING.equalsIgnoreCase(appDablCargo.getEstb_blnd_resp()))
					&& (!HouseHoldDemoGraphicsConstants.ONE_STRING.equalsIgnoreCase(appDablCargo.getEstb_dabl_resp()))
					&& (!HouseHoldDemoGraphicsConstants.ONE_STRING.equalsIgnoreCase(appDablCargo.getEstb_phy_resp()))) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00076));
			}

			if (HouseHoldDemoGraphicsConstants.DBLTY_TYPE_OTH_CD.equalsIgnoreCase(appDablCargo.getDabl_type_cd())) {
				if ((disablityTypeOther != null)
						&& (HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(disablityTypeOther.trim()))) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.DBLTY_TYPE_OTH_MSG_CD));
				}
			}

			if (appMgr.isFieldEmpty(appDablCargo.getDabl_type_cd())
					|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appDablCargo.getDabl_type_cd())
					|| "000".equalsIgnoreCase(appDablCargo.getDabl_type_cd())) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10332));
			}

			/*
			 * if (request.containsKey("showLoopingQuestion") ||
			 * (beforePageColl.containsKey("showLoopingQuestion") &&
			 * FwConstants.YES.equals(beforePageColl.get("showLoopingQuestion")))) { if
			 * (((null != request.get("loopingQuestion")) &&
			 * FwConstants.EMPTY_STRING.equals(((String)
			 * request.get("loopingQuestion")).trim())) || (null ==
			 * request.get("loopingQuestion"))) { addMessageCode("00327");
			 * 
			 * }
			 */

			if (showLoopingQuestion != null && FwConstants.YES.equals(showLoopingQuestion)) {
				if (appDablCargo.getLoopingQuestion() == null) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00327));
				}

			}

			return messageList;
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(), "validateHouseholdMemberDetail", e);
		}
	}

	public void storeDisabilityDetails(APP_IN_DABL_Collection appInDisColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABDisabilityBO.storeDisabilityDetails() - START");

		/*
		 * try { if (appInDisColl != null) { appInDisColl.persist(FwConstants.DAO); } }
		 */
		try {
			APP_IN_DABL_Cargo cargo = null;
			if (appInDisColl != null && !appInDisColl.isEmpty()) {
				cargo = appInDisColl.getCargo(0);
				cpAppInDablRepository.save(cargo);

			}
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO, "DisabilityBO.storeDisabilityDetails() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime) + " milliseconds");

	}

	public APP_IN_DABL_Collection loadIndividualDisabilityDetails(String appnum, Integer indvseqnum, Integer seqnum) {
		
		return cpAppInDablRepository.getDisabilityDtl(Integer.parseInt(appnum), indvseqnum, seqnum);		
		
	}

	public APP_IN_DABL_Cargo splitDisabilityColl(APP_IN_DABL_Collection dablColl, String sourceAppIndicator) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"DisabilityBO.splitDisabilityColl- START");
		try {
			if ((dablColl != null) && (!dablColl.isEmpty())) {
				final int dablCollSize = dablColl.size();
				APP_IN_DABL_Cargo dablCargo = null;
				for (int i = 0; i < dablCollSize; i++) {
					dablCargo = dablColl.getCargo(i);
					if (dablCargo.getSrc_app_ind().equals(sourceAppIndicator)) {
						return dablColl.getCargo(i);
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO,
					"DisabilityBO.splitDisabilityColl - END , Time Taken : " + (System.currentTimeMillis() - startTime) + " milliseconds");
			FwLogger.log(this.getClass(), Level.INFO,
					"DisabilityBO.:splitDisabilityColl:End");
			return null;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		

	
	}
	public FwMessageList validateDisablityDetail1(
			final APP_IN_DABL_Cargo appDablCargo,
			final String showLoopingQuestion) {
		System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"DisabilityBO.validateDisablityDetail() - START");
		FwMessageList messageList = new FwMessageList();
		try {
			final String disablityTypeCD = appDablCargo.getDabl_type_cd();
			appDablCargo.getSsa_dbal_appr_src_cd();
			/*
			 * if (!ONE.equals(appDablCargo.getEstb_blnd_resp()) &&
			 * !ONE.equals(appDablCargo.getEstb_dabl_resp()) &&
			 * !ONE.equals(appDablCargo.getEstb_phy_resp())) {
			 * addMessageCode(DISABILITY_STATUS_MSG_CODE); }
			 */
			if ((!HouseHoldDemoGraphicsConstants.ONE_STRING.equalsIgnoreCase(appDablCargo.getEstb_blnd_resp()))
					&& (!HouseHoldDemoGraphicsConstants.ONE_STRING.equalsIgnoreCase(appDablCargo.getEstb_dabl_resp()))
					&& (!HouseHoldDemoGraphicsConstants.ONE_STRING.equalsIgnoreCase(appDablCargo.getEstb_phy_resp()))) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00076));
			}

			/*
			 * if (DISABILITY_TYPE_DEFAULT_CD.equals(disablityTypeCD)) {
			 * addMessageCode(DISABILITY_TYPE_MSG_CD); 
			 * }
			 */
			
			if(HouseHoldDemoGraphicsConstants.DISABILITY_TYPE_DEFAULT_CD.equals(disablityTypeCD)) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.DISABILITY_TYPE_MSG_CD));
			}
			
			/*
			 * if (request.containsKey("showLoopingQuestion") ||
			 * beforePageColl.containsKey("showLoopingQuestion") &&
			 * FwConstants.YES.equals(beforePageColl .get("showLoopingQuestion"))) { if
			 * (null != request.get("loopingQuestion") &&
			 * FwConstants.EMPTY_STRING.equals(((String) request
			 * .get("loopingQuestion")).trim()) || null == request.get("loopingQuestion")) {
			 * addMessageCode(DBLTY_YES_OR_NO);
			 * 
			 * } }
			 */
			if (showLoopingQuestion != null && FwConstants.YES.equals(showLoopingQuestion)) {
				if (appDablCargo.getLoopingQuestion() == null) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00327));
				}

			}
			
			/*
			 * if(appDablCargo.getChg_dt() != null){
			 * if(appMgr.isFieldEmpty(appDablCargo.getChg_dt().toString())){
			 * messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.
			 * MSG_99368)); }
			 * 
			 * if(!appMgr.isFieldEmpty(appDablCargo.getChg_dt().toString()) &&
			 * !appMgr.validateDate(appDablCargo.getChg_dt())){
			 * messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.
			 * MSG_99365)); }
			 * if(appMgr.isDateBeforeDate(appDablCargo.getChg_dt().toString(),
			 * "01/01/1880")){
			 * messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.
			 * MSG_99366)); } Date nxtMnthLastDt = getNxtMnthlastDt();
			 * 
			 * if(appMgr.isDateAfterDate(appDablCargo.getChg_dt(), nxtMnthLastDt)){
			 * messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.
			 * MSG_99367));; } }
			 */
			
			if(appDablCargo.getChg_dt() == null) {
    			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99368));
    		}else {

    			if(!appMgr.validateDate(appDablCargo.getChg_dt())){
    				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99365));
				}
				if(appMgr.isDateBeforeDate(appDablCargo.getChg_dt().toString(), "01/01/1880")){
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99366));
				}
				java.util.Date nxtMnthLastDt = getNxtMnthlastDt();

				if(appMgr.isDateAfterDate(appDablCargo.getChg_dt(), nxtMnthLastDt)){
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99367));
				}
    		
    		}
			
			return messageList;
		 
		}catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}

	}

	public Integer getMaxDisabilitySeqNumber(String appNumber, Integer indvSeqNumber) {
		final long startTime = System.currentTimeMillis();
		Integer maxSeqNum = 0;
		try {
			
			if(appNumber != null && !appNumber.isEmpty() && indvSeqNumber != null) {
				
			maxSeqNum = cpAppInDablRepository.getMxDisabilitySeqNumber(Integer.parseInt(appNumber), indvSeqNumber);
				if(maxSeqNum == null)
					maxSeqNum = 0;
			} 
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABDisabilityBO.getMaxDisabilitySeqNumber() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
			return maxSeqNum;
		}catch (final Exception e) {
			throw e;
		}

	}

	public void storeDisabilitySummary(APP_IN_DABL_Collection appInDablColl) {
		final long startTime = System.currentTimeMillis();
	    FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABDisabilityBO.storeDisabilitySummary() - START");
	    try {  	
	    	if ((appInDablColl != null) && (!appInDablColl.isEmpty()) && (appInDablColl.size() > 0)){
	    		APP_IN_DABL_Cargo dablCargo = appInDablColl.getCargo(0);
	    		cpAppInDablRepository.save(dablCargo);
	        }
	    	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABDisabilityBO.storeDisabilitySummary() - END , Time Taken : "
	                + (System.currentTimeMillis() - startTime)
	                + " milliseconds");
	    }catch (final Exception e) {
	        FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	        throw createFwException(getClass().getName(),
	                "storeDisabilitySummary", e);
	    }
	}

	public APP_IN_DABL_Collection loadDisabilityDetails(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABDisabilityBO.loadDisability() - START");
        
        try {
        	APP_IN_DABL_Collection appInDablColl = new APP_IN_DABL_Collection();
        	if(appNum != null) {
        		
        		APP_IN_DABL_Cargo[] appInDablCargoArray  = cpAppInDablRepository.getAllDetails(Integer.parseInt(appNum), indvIds);
        		if (appInDablCargoArray.length > 0) {
        			appInDablColl.setResults(appInDablCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABDisabilityBO.loadDisability() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    + " milliseconds");
        	
    		return appInDablColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}

	public APP_IN_DABL_Collection loadDisabilityDtls(String appNum, Integer indv_seq_num) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABDisabilityBO.loadDisabilityDtls() - START");
        try {
        	APP_IN_DABL_Collection appInDablColl = new APP_IN_DABL_Collection();
        	if(appNum != null && indv_seq_num != null) {
        		appInDablColl = cpAppInDablRepository.loadDisabilityDtls(Integer.parseInt(appNum), indv_seq_num);
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABDisabilityBO.loadDisabilityDtls() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    + " milliseconds");
        	
    		return appInDablColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(getClass().getName(),
                    "loadDisabilityDtls", e);
        }
	}

	public void storeAppInCareProv(CP_APP_IN_CARE_PROV_Collection provcoll) {
		final long startTime = System.currentTimeMillis();
	    FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABDisabilityBO.storeAppInCareProv() - START");
	    try {  	
	    	if ((provcoll != null) && (!provcoll.isEmpty()) && (provcoll.size() > 0)){
	    		CP_APP_IN_CARE_PROV_Cargo provcargo = provcoll.getCargo(0);
	    		cpAppInCareProvRepository.save(provcargo);
	        }
	    	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABDisabilityBO.storeAppInCareProv() - END , Time Taken : "
	                + (System.currentTimeMillis() - startTime)
	                + " milliseconds");
	    }catch (final Exception e) {
	        FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	        throw createFwException(getClass().getName(),
	                "storeAppInCareProv", e);
	    }
	}

	public CP_APP_IN_CARE_PROV_Collection loadAppInCareProv(String appnum, Integer indv_seq_num, Integer seq_num) {

		return cpAppInCareProvRepository.getAppInCareProvDtl(appnum, indv_seq_num, seq_num);
	}
	
	public APP_IN_DABL_Collection loadDisabilityDetailsByAppNum(String appNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABDisabilityBO.loadDisabilityDetailsByAppNum() - START");
		try {
			APP_IN_DABL_Collection appInDablColl = new APP_IN_DABL_Collection();
			if (appNum != null) {
				appInDablColl = cpAppInDablRepository.loadDisabilityDetailsByAppNum(Integer.parseInt(appNum));
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABDisabilityBO.loadDisabilityDetailsByAppNum() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + " milliseconds");
			return appInDablColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw createFwException(getClass().getName(), "loadDisabilityDetailsByAppNum", e);
		}
	}
	
}
	
