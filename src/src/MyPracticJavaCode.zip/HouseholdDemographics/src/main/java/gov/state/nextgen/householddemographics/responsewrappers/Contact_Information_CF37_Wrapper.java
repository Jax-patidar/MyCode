package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("CFCON")
@Scope("prototype")
public class Contact_Information_CF37_Wrapper implements LogicResponseInterface {
	private static final String PAGE_ID = "CFCON";
	
	private static final String CP_APP_RGST_COLL = "CP_APP_RGST_Collection";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTrxn.getPageCollection();
		List<APP_INDV_Cargo> appIndvCargolist = new ArrayList<>();
		List<CP_APP_RGST_Cargo> appIndvRgstCargoList = new ArrayList<>();
		
		APP_INDV_Collection appIndvCollection = pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) != null ? (APP_INDV_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION) : null;
		CP_APP_RGST_Collection appIndvRgstColl = pageCollection.get(CP_APP_RGST_COLL) != null ? (CP_APP_RGST_Collection) pageCollection.get(CP_APP_RGST_COLL) : null;
		if(null!=appIndvCollection && appIndvCollection.size()>0) {
			appIndvCargolist.add(appIndvCollection.getCargo(0));
		}
		if(null!=appIndvRgstColl && appIndvRgstColl.size()>0) {
			appIndvRgstCargoList.add(appIndvRgstColl.getCargo(0));
		}
		
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCargolist);
		driverPageResponse.getPageCollection().put(CP_APP_RGST_COLL, appIndvRgstCargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		return driverPageResponse;
	}
}