package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

public class ChildSeekingBenefit implements Serializable {

    private static final long serialVersionUID = 1L;
    private String firstName;
    private String usCitizenSwitch;
    private String alienStatusCd;
    private String dateOfEntryToUS;
    private String appNum;
    private String indvSeqNum;
    private String sexInd;

    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getUsCitizenSwitch() {
        return usCitizenSwitch;
    }
    public void setUsCitizenSwitch(String usCitizenSwitch) {
        this.usCitizenSwitch = usCitizenSwitch;
    }
    public String getAlienStatusCd() {
        return alienStatusCd;
    }
    public void setAlienStatusCd(String alienStatusCd) {
        this.alienStatusCd = alienStatusCd;
    }
    public String getDateOfEntryToUS() {
        return dateOfEntryToUS;
    }
    public void setDateOfEntryToUS(String dateOfEntryToUS) {
        this.dateOfEntryToUS = dateOfEntryToUS;
    }
    public String getAppNum() {
        return appNum;
    }
    public void setAppNum(String appNum) {
        this.appNum = appNum;
    }
    public String getIndvSeqNum() {
        return indvSeqNum;
    }
    public void setIndvSeqNum(String indvSeqNum) {
        this.indvSeqNum = indvSeqNum;
    }
    public String getSexInd() {
        return sexInd;
    }
    public void setSexInd(String sexInd) {
        this.sexInd = sexInd;
    }

}
