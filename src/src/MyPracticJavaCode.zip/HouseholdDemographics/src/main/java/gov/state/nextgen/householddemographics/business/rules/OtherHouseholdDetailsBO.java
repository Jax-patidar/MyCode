package gov.state.nextgen.householddemographics.business.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Collection;
import gov.state.nextgen.householddemographics.data.db2.OtherHouseholdDetailsRepo;

@Service("OtherHouseholdDetailsBO")
public class OtherHouseholdDetailsBO {
	@Autowired
	private OtherHouseholdDetailsRepo otherHHDetailRepo;
	
	public OTHER_HOUSEHOLD_DETAILS_Collection loadOtherHHDetail(String app_num, Integer indv_seq_num) {
		return otherHHDetailRepo.loadCaretakerExisitingDetail(Integer.parseInt(app_num),indv_seq_num);
	}

	

	public void saveOtherHHDetail(OTHER_HOUSEHOLD_DETAILS_Collection otherHouseholdDetailsCollection) {
		try {
			OTHER_HOUSEHOLD_DETAILS_Cargo cargo = null;
			if (otherHouseholdDetailsCollection != null && !otherHouseholdDetailsCollection.isEmpty()) {
				cargo =  otherHouseholdDetailsCollection.getCargo(0);
				otherHHDetailRepo.save(cargo);
			}
		}catch (final Exception exception) {
            throw exception;
        }
	}
	
	public OTHER_HOUSEHOLD_DETAILS_Collection loadOtherHouseholdDetails(String appNumber) {
		try {
			return otherHHDetailRepo.getDetailsByAppNum(Integer.parseInt(appNumber));
		}catch (final Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "loadOtherHouseholdDetails error", exception);
            throw exception;
            
        }
	}

}
