package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class CASE_PROGRAMS_Cargo extends AbstractCargo {

    private Boolean snapFlag;
    private Boolean maFlag;
    private Boolean tanfFlag;

    public Boolean getSnapFlag() {
        return snapFlag;
    }
    public void setSnapFlag(Boolean snapFlag) {
        this.snapFlag = snapFlag;
    }
    public Boolean getMaFlag() {
        return maFlag;
    }
    public void setMaFlag(Boolean maFlag) {
        this.maFlag = maFlag;
    }
    public Boolean getTanfFlag() {
        return tanfFlag;
    }
    public void setTanfFlag(Boolean tanfFlag) {
        this.tanfFlag = tanfFlag;
    }

}
