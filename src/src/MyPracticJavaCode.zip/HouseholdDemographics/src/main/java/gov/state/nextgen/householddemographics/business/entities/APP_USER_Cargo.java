/*
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;



/**
 * This java bean contains the entities for the given table
 *
 * @author Architecture Team
 * Creation Date Mon Feb 06 09:53:46 CST 2006 Modified By: Modified on: PCR#
 */
@Entity
@Table(name="CP_APP_USER")
@IdClass(AppUserIdentity.class)
public class APP_USER_Cargo extends AbstractCargo  {

	@Id
	private String acs_id;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	

	private String sbmt_acs_id;
	
	public APP_USER_Cargo() {
		
	}

	
	

	/**
	 * @return the sbmt_acs_id
	 */
	public String getSbmt_acs_id() {
		return sbmt_acs_id;
	}

	/**
	 * @param sbmt_acs_id the sbmt_acs_id to set
	 */
	public void setSbmt_acs_id(String sbmt_acs_id) {
		this.sbmt_acs_id = sbmt_acs_id;
	}
	
	public String getAcs_id() {
		return acs_id;
	}


	public void setAcs_id(String acs_id) {
		this.acs_id = acs_id;
	}


	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acs_id == null) ? 0 : acs_id.hashCode());
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((sbmt_acs_id == null) ? 0 : sbmt_acs_id.hashCode());
		return result;
	}


	
	public APP_USER_Cargo(String acs_id, Integer app_num, String sbmt_acs_id) {
		super();
		this.acs_id = acs_id;
		this.app_number = app_num;
		this.sbmt_acs_id = sbmt_acs_id;
	}

	

}