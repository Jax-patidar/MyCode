package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "CP_APP_IN_TAX_DEPENDENT")
@IdClass(CP_APP_IN_TAX_DEPENDENTS_Key.class)
public class CP_APP_IN_TAX_DEPENDENTS_Cargo extends AbstractCargo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Transient
	private boolean isDirty = false;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	@Id
	private Integer indv_seq_num;

	private String src_app_ind;
	@Id
	private Integer seq_num;
	private Integer dependent_indv_seq_num;
	@Transient
	private Integer ecp_id;
	private String first_name;
	private String last_name;
	private String relationship;
	private String tax_dependent_out;
	private Integer rec_cplt_ind;
	
	private String middle_name;

	/**
	 * @return the middle_name
	 */
	public String getMiddle_name() {
		return middle_name;
	}

	/**
	 * @param middle_name the middle_name to set
	 */
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}

	/**
	 *returns the app_num value.
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	
	/**
	 *returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 *returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 *returns the dependent_indv_seq_num value.
	 */
	public Integer getDependent_indv_seq_num() {
		return dependent_indv_seq_num;
	}

	/**
	 *returns the ecp_id value.
	 */
	public Integer getEcp_id() {
		return ecp_id;
	}

	/**
	 *sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 *sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 *sets the dependent_indv_seq_num value.
	 */
	public void setDependent_indv_seq_num(final Integer dependent_indv_seq_num) {
		this.dependent_indv_seq_num = dependent_indv_seq_num;
	}

	/**
	 *sets the ecp_id value.
	 */
	public void setEcp_id(final Integer ecp_id) {
		this.ecp_id = ecp_id;
	}

	/**
	 * @return the first_name
	 */
	public String getFirst_name() {
		return first_name;
	}

	/**
	 * @param first_name the first_name to set
	 */
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	/**
	 * @return the last_name
	 */
	public String getLast_name() {
		return last_name;
	}

	/**
	 * @param last_name the last_name to set
	 */
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	/**
	 * @return the relationship
	 */
	public String getRelationship() {
		return relationship;
	}

	/**
	 * @param relationship the relationship to set
	 */
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	/**
	 * @return the tax_dependent_out
	 */
	public String getTax_dependent_out() {
		return tax_dependent_out;
	}

	/**
	 * @param tax_dependent_out the tax_dependent_out to set
	 */
	public void setTax_dependent_out(String tax_dependent_out) {
		this.tax_dependent_out = tax_dependent_out;
	}

	/**
	 * @return the rec_cplt_ind
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * @param rec_cplt_ind the rec_cplt_ind to set
	 */
	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * @return the seq_num
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * @param seq_num the seq_num to set
	 */
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((dependent_indv_seq_num == null) ? 0 : dependent_indv_seq_num.hashCode());
		result = prime * result + ((ecp_id == null) ? 0 : ecp_id.hashCode());
		result = prime * result + ((first_name == null) ? 0 : first_name.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + (isDirty ? 1231 : 1237);
		result = prime * result + ((last_name == null) ? 0 : last_name.hashCode());
		result = prime * result + ((middle_name == null) ? 0 : middle_name.hashCode());
		result = prime * result + ((rec_cplt_ind == null) ? 0 : rec_cplt_ind.hashCode());
		result = prime * result + ((relationship == null) ? 0 : relationship.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		result = prime * result + ((tax_dependent_out == null) ? 0 : tax_dependent_out.hashCode());
		return result;
	}

	
	

}
