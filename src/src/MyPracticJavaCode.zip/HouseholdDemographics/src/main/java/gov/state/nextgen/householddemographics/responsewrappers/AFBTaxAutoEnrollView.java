package gov.state.nextgen.householddemographics.responsewrappers;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABTAE")
@Scope("prototype")
public class AFBTaxAutoEnrollView implements LogicResponseInterface{

	private static final String PAGE_ID = "ABTAE";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getRequest().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		return driverPageResponse;
	}
}
