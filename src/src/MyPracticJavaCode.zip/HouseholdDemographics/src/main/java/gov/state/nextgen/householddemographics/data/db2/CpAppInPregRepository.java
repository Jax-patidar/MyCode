package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_BreastFeeding_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_CargoKey;

@Repository
public interface CpAppInPregRepository extends CrudRepository<CP_APP_IN_PREG_Cargo, CP_APP_IN_PREG_CargoKey>{

	@Query("select c from CP_APP_IN_PREG_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.indv_seq_num = ?3")
	public CP_APP_IN_PREG_Collection getPregCollection(Integer appNumber, String srcAppInd, int indvSeqNum);
	
	@Query("select c from CP_APP_IN_PREG_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.indv_seq_num IN ?3 and c.is_pregnant = ?4")
    public CP_APP_IN_PREG_Collection getAllDetails(Integer appNum, String srcAppInd, List<Integer> indvIds, String isPregnant);

	@Query("select c from CP_APP_IN_PREG_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
    List<CP_APP_IN_PREG_Cargo> findByAppNumAndIndvSeqNum(Integer appNum, Double indvSeqNum);
    
	@Query("select c from CP_APP_IN_PREG_Cargo c where app_number = ?1")
	public CP_APP_IN_PREG_Collection loadPregDetailsByAppNum(Integer appNum);

	@Transactional
	@Modifying
	@Query("update CP_APP_IN_PREG_Cargo c set c.birth_in_twelv_mnths = null, c.is_breast_feeding = null where c.app_number = ?1 and c.indv_seq_num = ?2")
	public void updateBreastFeedingDetail(Integer appNumber, int indvSeqNum);
	
	@Query("select c from CP_APP_IN_PREG_Cargo c where c.app_number = ?1 and c.src_app_ind = ?2 and c.indv_seq_num IN ?3 and is_breast_feeding = ?4")
	public CP_APP_IN_PREG_Collection getBreastFeedingDetails(Integer appNum, String srcAppInd, List<Integer> indvIds, String isBreastFeeding);
	
	@Query("select c from CP_APP_IN_PREG_Cargo c where app_number = ?1 and c.indv_seq_num IN ?2")
	public CP_APP_IN_PREG_Cargo[] loadPregnancy(Integer appNum, List<Integer> indvIds);
	
	@Query("select c from CP_APP_IN_PREG_Cargo c where app_number = ?1")
	public CP_APP_IN_PREG_Cargo[] loadBreastFeedingDetails(Integer appNum);

}
