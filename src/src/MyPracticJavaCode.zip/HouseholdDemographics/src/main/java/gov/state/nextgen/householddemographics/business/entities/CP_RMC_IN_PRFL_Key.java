package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CP_RMC_IN_PRFL_Key implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String appNum;
	private String indvSeqNum;
	
	public CP_RMC_IN_PRFL_Key() {
	}
	
	public CP_RMC_IN_PRFL_Key(String appNum, String indvSeqNum) {
		this.appNum = appNum;
		this.indvSeqNum = indvSeqNum;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((appNum == null) ? 0 : appNum.hashCode());
		result = prime * result + ((indvSeqNum == null) ? 0 : indvSeqNum.hashCode());
		return result;
	}
	
}
