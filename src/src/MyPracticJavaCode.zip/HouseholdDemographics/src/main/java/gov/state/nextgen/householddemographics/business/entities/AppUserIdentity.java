package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class AppUserIdentity implements Serializable{
	
	private String acs_id;
	private Integer app_number;
	
	public AppUserIdentity() {
		
	}

	public AppUserIdentity(String acs_id, Integer app_num) {
		super();
		this.acs_id = acs_id;
		this.app_number = app_num;
	}

	public String getAcs_id() {
		return acs_id;
	}

	public void setAcs_id(String acs_id) {
		this.acs_id = acs_id;
	}

	public Integer getApp_number() {
		return app_number;
	}

	public void setApp_number(Integer app_number) {
		this.app_number = app_number;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acs_id == null) ? 0 : acs_id.hashCode());
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		return result;
	}

	
	


}
