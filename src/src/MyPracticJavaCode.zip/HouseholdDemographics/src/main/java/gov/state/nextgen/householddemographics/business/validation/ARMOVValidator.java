package gov.state.nextgen.householddemographics.business.validation;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.householddemographics.business.entities.NO_ONE_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMC_IN_PRFL_Collection;

import java.util.Map;

public class ARMOVValidator extends AbstractBO {

    /**
     *
     * @param pageAppInPrflCollection  gov.state.nextgen.access.business.entities.RMC_IN_PRFL_Collection
     * @param noOneCollection
     * @param noOneCheckedMap
     * @param numofPplInHome
     * @param movedInFlag
     * @return messages
     */
    public FwMessageList validateMovedOut(final RMC_IN_PRFL_Collection pageAppInPrflCollection, final NO_ONE_Collection noOneCollection,
                                          final Map noOneCheckedMap, final int numofPplInHome, final boolean movedInFlag) {
        try {
            FwMessageList messageList = new FwMessageList();
            boolean noOneSelected = false;
            boolean indPresent = false;

            if ((pageAppInPrflCollection != null) && (!pageAppInPrflCollection.isEmpty())) {
                indPresent = true;
            }

            if ((noOneCollection != null) && (!noOneCollection.isEmpty())) {
                noOneSelected = true;
            }

            if ((numofPplInHome == 1) && !movedInFlag) {
                if ((!indPresent) && (!noOneSelected)) {
                    addMessageCode("00002");
                } else if ((indPresent) && (noOneSelected)) {
                    addMessageCode("99258");
                }

            } else {
                if ((!indPresent) && (!noOneSelected)) {
                    addMessageCode("00002");
                } else if ((indPresent) && (noOneSelected)) {
                    addMessageCode("00068");
                }
            }

            return messageList;
        } catch(Exception exception){
            throw exception;
        }
    }

}
