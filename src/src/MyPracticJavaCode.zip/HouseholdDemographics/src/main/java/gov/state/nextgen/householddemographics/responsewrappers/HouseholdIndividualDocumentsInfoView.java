package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_OTHER_SITUATIONS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_OTHER_SITUATIONS_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DocumentsRequired;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;
import gov.state.nextgen.householddemographics.model.RequiredDocumentModel;
import gov.state.nextgen.householddemographics.utilities.AgeUtil;

@Component("ABHIS")
@Scope("prototype")
public class HouseholdIndividualDocumentsInfoView implements LogicResponseInterface{	

	@Override
	@SuppressWarnings("squid:S3776")
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
		
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		
		Map pageCollection = fwTxn.getPageCollection();
		
		UserDetails userDetails = fwTxn.getUserDetails();
		
		String appNum = userDetails.getAppNumber();
		
		String flowMode = getMode(fwTxn);
		
		RequiredDocumentModel hhInfo = new RequiredDocumentModel();
		
		List<RequiredDocumentModel> hhInforList = new ArrayList<>();		
		
		APP_IN_DABL_Collection disabilityCollection = (APP_IN_DABL_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_IN_DABL_COLL);		
        //commented as part of enhancement CSPM-35846(Should not display at all on Recommended Documents)- START
		//APP_IN_SCHLE_Collection schoolVerficationCollection = (APP_IN_SCHLE_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION);	
        //commented as part of enhancement CSPM-35846(Should not display at all on Recommended Documents)- END
		hhInfo.setApp_num(appNum);
		hhInfo.setMode(flowMode);
		if(disabilityCollection!=null && !disabilityCollection.isEmpty() && flowMode != null && !(HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(flowMode))) {
			DocumentsRequired documentsRequired = addDisabilityInfo(disabilityCollection);
			if(documentsRequired.getIndv_seq_num()!=null && documentsRequired.getDocument_type()!=null) {
				hhInfo.getDocuments_required().add(documentsRequired);	
			}
		}
		//commented as part of enhancement CSPM-35846(Should not display at all on Recommended Documents)- START
		/*
		 * if(schoolVerficationCollection!=null &&
		 * !schoolVerficationCollection.isEmpty()) { DocumentsRequired documentsRequired
		 * = addSchoolVerification(schoolVerficationCollection,flowMode);
		 * if(documentsRequired.getIndv_seq_num()!=null &&
		 * documentsRequired.getDocument_type()!=null) {
		 * hhInfo.getDocuments_required().add(documentsRequired); } }
		 */
		//commented as part of enhancement CSPM-35846(Should not display at all on Recommended Documents)- END
		
		APP_INDV_Collection appIndvCol = (APP_INDV_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
		
		if(appIndvCol!=null && !appIndvCol.isEmpty()) {
			validateIndvColl(hhInfo, appIndvCol,flowMode);
			List<Integer> childCareIndivIdList = getchildCareIndivIds(appIndvCol);
			if(!childCareIndivIdList.isEmpty())
			{
				hhInfo.setChildCareIndivs(childCareIndivIdList);
			}
		}
		
		if(null != flowMode && HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING.equalsIgnoreCase(flowMode))
		{
		Integer primaryIndivId = getPrimaryIndivId(appIndvCol);
		CP_APP_OTHER_SITUATIONS_Collection otherSituations = (CP_APP_OTHER_SITUATIONS_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_APP_OTHER_SITUATIONS_COLLECTION);	
		if(otherSituations!=null && !otherSituations.isEmpty() ) {
			CP_APP_OTHER_SITUATIONS_Cargo otherSitutionCargo = otherSituations.getCargo(0);
			if(Objects.nonNull(otherSitutionCargo))
			{
				if(Objects.nonNull(otherSitutionCargo.getDisability()) &&
						HouseHoldDemoGraphicsConstants.Y.equalsIgnoreCase(otherSitutionCargo.getDisability()))
				{
					APP_IN_DABL_Cargo disabilityinfo = new APP_IN_DABL_Cargo();
					disabilityinfo.setIndv_seq_num(primaryIndivId);
					APP_IN_DABL_Collection disablityCollection = new APP_IN_DABL_Collection();
					disablityCollection.addCargo(disabilityinfo);
					DocumentsRequired documentsRequired = addDisabilityInfo(disablityCollection);
					if(documentsRequired.getIndv_seq_num()!=null && documentsRequired.getDocument_type()!=null) {
						hhInfo.getDocuments_required().add(documentsRequired);	
					}
					
				}
				if(Objects.nonNull(otherSitutionCargo.getSchool_attendance()) 
						&& HouseHoldDemoGraphicsConstants.Y.equalsIgnoreCase(otherSitutionCargo.getSchool_attendance())) 
				{
					APP_IN_SCHLE_Cargo schoolInfo = new APP_IN_SCHLE_Cargo();
					schoolInfo.setIndv_seq_num(primaryIndivId);
					APP_IN_SCHLE_Collection schoolCollection = new APP_IN_SCHLE_Collection();
					schoolCollection.addCargo(schoolInfo);
					DocumentsRequired documentsRequired = addSchoolVerification(schoolCollection,flowMode);
					if(documentsRequired.getIndv_seq_num()!=null && documentsRequired.getDocument_type()!=null) {
						hhInfo.getDocuments_required().add(documentsRequired);	
					}
				}
			}
			
		}
		}
		APP_RQST_Collection appRqstCol = (APP_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_RQST_COLL);
		
		if(appRqstCol!=null && !appRqstCol.isEmpty()) {	
			addAppRqstDetails(appRqstCol, hhInfo);
		}
		hhInforList.add(hhInfo);
		
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.HOUSEHOLD_MODULE, hhInforList);		
				
		return driverPageResponse;
	}


	private void validateIndvColl(RequiredDocumentModel hhInfo, APP_INDV_Collection appIndvCol,String mode) {
		hhInfo.setActive_individuals(getActiveIndivIds(appIndvCol));
		hhInfo.setActive_benefitsCalIndividuals(getBenefitsCalIndivIdsMap(appIndvCol, mode));
		DocumentsRequired documentsRequired = addSSNInfo(appIndvCol,mode);
		if(documentsRequired.getIndv_seq_num()!=null && documentsRequired.getDocument_type()!=null) {
			hhInfo.getDocuments_required().add(documentsRequired);	
		}
		
		if (null != appIndvCol && !appIndvCol.isEmpty() && mode != null && !(HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(mode))) {
			DocumentsRequired docsRequired = addOtherInfo(appIndvCol);
			FwLogger.log(this.getClass(), Level.INFO,"docsRequired for other info:" +docsRequired);
			if (null != docsRequired.getIndv_seq_num() && null != docsRequired.getDocument_type()) {
				hhInfo.getDocuments_required().add(docsRequired);
			}
		}
		//commented as part of enhancement CSPM-35846(Should not display at all on Recommended Documents)- START
		/*
		 * DocumentsRequired docsRequired = addCitizenshipInfo(appIndvCol,mode);
		 * if(docsRequired.getIndv_seq_num()!=null &&
		 * docsRequired.getDocument_type()!=null) {
		 * hhInfo.getDocuments_required().add(docsRequired); }
		 */
		/*
		 * DocumentsRequired immunizationDocs = getImmunizationInfo(appIndvCol);
		 * if(immunizationDocs.getIndv_seq_num()!=null &&
		 * immunizationDocs.getDocument_type()!=null) {
		 * hhInfo.getDocuments_required().add(immunizationDocs); }
		 */
        //commented as part of enhancement CSPM-35846(Should not display at all on Recommended Documents)- END
	}
	
	private DocumentsRequired addOtherInfo(APP_INDV_Collection appIndvCol) {
		List<Integer> indvList= new ArrayList<>();
		indvList.addAll(getActiveIndivIds(appIndvCol));
		return getDocumentRequiredType(indvList,HouseHoldDemoGraphicsConstants.OTHER_TYPE_DOCUMENTS_REQUIRED);
	}
	
	private DocumentsRequired addDisabilityInfo(APP_IN_DABL_Collection disabilityCollection){

		List<Integer> indvList= null;
		DocumentsRequired documentsRequired = new DocumentsRequired();

		if(disabilityCollection!=null && !disabilityCollection.isEmpty() ) {
			indvList= new ArrayList<>();
			for(int i=0;i < disabilityCollection.size(); i++) {
				if(!indvList.contains(disabilityCollection.getCargo(i).getIndv_seq_num())) {
					indvList.add(disabilityCollection.getCargo(i).getIndv_seq_num());
				}
			}			
			if(!indvList.isEmpty()){
				documentsRequired.setIndv_seq_num(indvList);
				documentsRequired.setDocument_type(HouseHoldDemoGraphicsConstants.DISABILITY_TYPE_DOCUMENTS_REQUIRED);
			}
		}
		return documentsRequired;		
	}
	
	private DocumentsRequired addSchoolVerification(APP_IN_SCHLE_Collection schoolVerficationCollection,String mode){
		List<Integer> indvList=  new ArrayList<>();
		if(schoolVerficationCollection!=null && !schoolVerficationCollection.isEmpty() ) {
			for(int i=0;i < schoolVerficationCollection.size(); i++) {
				if(!indvList.contains(schoolVerficationCollection.getCargo(i).getIndv_seq_num())) {
					indvList.add(schoolVerficationCollection.getCargo(i).getIndv_seq_num());
				}
			}			
		}
		return getDocumentRequiredType(indvList,HouseHoldDemoGraphicsConstants.SCHOOL_VERIFICATION_DOCUMENTS_REQUIRED);		
	}
	
	private DocumentsRequired addCitizenshipInfo(APP_INDV_Collection appIndvCol,String flowMode){
		List<Integer> indvList= new ArrayList<>();
		if(null != flowMode && (HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING.equalsIgnoreCase(flowMode) || 
				HouseHoldDemoGraphicsConstants.CALFRESH_F37.equalsIgnoreCase(flowMode)))
		{
			List<APP_INDV_Cargo> newBornList = setNewBornInfo(appIndvCol);
			for(APP_INDV_Cargo eachNewBorn :newBornList)
			{
				if(!indvList.contains(eachNewBorn.getIndv_seq_num())) {
					indvList.add(eachNewBorn.getIndv_seq_num());					
				}
			}	
		}
		else
		{
			indvList.addAll(getActiveIndivIds(appIndvCol));
		}
		return getDocumentRequiredType(indvList,HouseHoldDemoGraphicsConstants.IDENTITY_TYPE_DOCUMENTS_REQUIRED);		
	}
	
	private DocumentsRequired getImmunizationInfo(APP_INDV_Collection appIndvCol){
		List<Integer> indvList= null;
		DocumentsRequired documentsRequired = new DocumentsRequired();
		if(appIndvCol!=null && !appIndvCol.isEmpty()) {
			validateIndvList(appIndvCol, documentsRequired);			
		}
		return documentsRequired;		
	}


	private void validateIndvList(APP_INDV_Collection appIndvCol, DocumentsRequired documentsRequired){
		List<Integer> indvList;
		indvList= new ArrayList<>();
		for(int i=0;i < appIndvCol.size(); i++) {
			if(!indvList.contains(appIndvCol.getCargo(i).getIndv_seq_num()) && Objects.nonNull(appIndvCol.getCargo(i).getBrth_dt())) {
					try {
							int age = AgeUtil.calculateAge(appIndvCol.getCargo(i).getBrth_dt().toString());
							if(age<HouseHoldDemoGraphicsConstants.IMMUNIZATIONAGELIMIT)
							{
								indvList.add(appIndvCol.getCargo(i).getIndv_seq_num());	
							}
						} 
					catch (Exception e) {
						FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in AccountManagementApplication.dataSource()",e);
						
					}
					
				}
		}			
		if(!indvList.isEmpty()){
			Collections.sort(indvList);
			documentsRequired.setIndv_seq_num(indvList);
			documentsRequired.setDocument_type(HouseHoldDemoGraphicsConstants.IMMUNIZATIONINFORMATION);
		}
	}
	
	private DocumentsRequired addSSNInfo(APP_INDV_Collection appIndvCol, String flowMode){

		List<Integer> indvList= new ArrayList<>();
		if(null != flowMode && (HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING.equalsIgnoreCase(flowMode) || 
				HouseHoldDemoGraphicsConstants.CALFRESH_F37.equalsIgnoreCase(flowMode)))
		{
			List<APP_INDV_Cargo> moveInOrNewBornList = setMoveInOrNewBornInfo(appIndvCol);
			for(APP_INDV_Cargo eachRecord : moveInOrNewBornList)
			{
				if(!indvList.contains(eachRecord.getIndv_seq_num())) {
					indvList.add(eachRecord.getIndv_seq_num());					
				}
			}
		}
		else {
			if(null != flowMode && !(HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(flowMode))){
				indvList.addAll(getActiveIndivIds(appIndvCol));
			}
		}
		return getDocumentRequiredType(indvList,HouseHoldDemoGraphicsConstants.SSN_DOCUMENTS_REQUIRED);		
	}
	
	private List<Integer> getActiveIndivIds(APP_INDV_Collection appIndvCol)
	{
		List<Integer> indvList= new ArrayList<>();
		if(appIndvCol!=null && !appIndvCol.isEmpty()) {
			for(int i=0;i < appIndvCol.size(); i++) {
				if(!indvList.contains(appIndvCol.getCargo(i).getIndv_seq_num())) {
					indvList.add(appIndvCol.getCargo(i).getIndv_seq_num());					
				}
			}		
		}
		return indvList;
	}
	
	private Map<Integer, String> getBenefitsCalIndivIdsMap(APP_INDV_Collection appIndvCol, String flowMode) {
		Map<Integer, String> benefitsCalMap = new HashMap<Integer, String>();
		if (appIndvCol != null && !appIndvCol.isEmpty()) {
			for (int i = 0; i < appIndvCol.size(); i++) {
				if (null != appIndvCol.getCargo(i).getCinNumber()
						&& !StringUtils.isEmpty(appIndvCol.getCargo(i).getCinNumber())) {
					benefitsCalMap.put(appIndvCol.getCargo(i).getIndv_seq_num(), appIndvCol.getCargo(i).getCinNumber());
				} else {
					benefitsCalMap.put(appIndvCol.getCargo(i).getIndv_seq_num(),
							appIndvCol.getCargo(i).getBenefitsCalIndividualId().toString());
				}
			}
		}
		return benefitsCalMap;
	}
	private  RequiredDocumentModel addAppRqstDetails(APP_RQST_Collection appRqstCol, RequiredDocumentModel hhInfo){

		String caseNum = null;
		String formRptType = null;

		if(appRqstCol!=null && !appRqstCol.isEmpty()) {
			for(int i=0;i < appRqstCol.size(); i++) {
				if(appRqstCol.getCargo(i).getCaseNum()!=null) {
					caseNum = appRqstCol.getCargo(i).getCaseNum();
					hhInfo.setCase_num(caseNum);
				}
				if(appRqstCol.getCargo(i).getFormRptType()!=null) {
					formRptType = appRqstCol.getCargo(i).getFormRptType();
					hhInfo.setForm_rpt_type(formRptType);
				}
			}
		}		
		return hhInfo;		
	}

	private String getMode(FwTransaction txnBean)
	{
		String mode = "";
		if(txnBean.getPageCollection().containsKey(HouseHoldDemoGraphicsConstants.MODE))
		{
			mode = (String) txnBean.getPageCollection().get(HouseHoldDemoGraphicsConstants.MODE);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, 
				"HouseholdIndividualDocumentsInfoView.getMode() flowMode "+mode);
		return mode;
	}
	
	private DocumentsRequired getDocumentRequiredType(List<Integer> indivIdList,String docType)
	{
		DocumentsRequired documentsRequired = new DocumentsRequired();
		if(!indivIdList.isEmpty()){
		Collections.sort(indivIdList);	
		documentsRequired.setIndv_seq_num(indivIdList);
		documentsRequired.setDocument_type(docType);
		}
		return documentsRequired;
	}
	
	private List<APP_INDV_Cargo> setMoveInOrNewBornInfo(APP_INDV_Collection appIndvCol)
	{
		List<APP_INDV_Cargo> moveInOrNewBornList = new ArrayList<>();
		if(appIndvCol!=null && !appIndvCol.isEmpty())
		{
			for(int i=0;i < appIndvCol.size(); i++) {
				String newBorn = appIndvCol.getCargo(i).getNew_born_ind();
				String movedIn = appIndvCol.getCargo(i).getMove_in_ind();
				if(newBorn != null 
				  || movedIn != null 
				  && (HouseHoldDemoGraphicsConstants.Y.equalsIgnoreCase(newBorn) 
				  || HouseHoldDemoGraphicsConstants.Y.equalsIgnoreCase(movedIn)))
				{
					moveInOrNewBornList.add(appIndvCol.getCargo(i));
				}
			}
		}
		return moveInOrNewBornList;
		
	}
	
	private List<APP_INDV_Cargo> setNewBornInfo(APP_INDV_Collection appIndvCol)
	{
		List<APP_INDV_Cargo> newbornInfo = new ArrayList<>();
		if(appIndvCol!=null && !appIndvCol.isEmpty())
		{
			for(int i=0;i < appIndvCol.size(); i++) {
				if(null != appIndvCol.getCargo(i).getNew_born_ind() && 
						HouseHoldDemoGraphicsConstants.Y.equalsIgnoreCase(appIndvCol.getCargo(i).getNew_born_ind()))
				{
					newbornInfo.add(appIndvCol.getCargo(i));
				}
			}
			
		}
		return newbornInfo;
		
	}
	@SuppressWarnings("squid:S3776")
	private List<Integer> getchildCareIndivIds(APP_INDV_Collection appIndvCol)
	{
		List<Integer> childCareIdivs = new ArrayList<>();
		if(appIndvCol!=null && !appIndvCol.isEmpty()) {
			for(int appIndivIndex=0;appIndivIndex < appIndvCol.size(); appIndivIndex++) {
				if(null != appIndvCol.getCargo(appIndivIndex).getBrth_dt())
				{
					try {
						int age = AgeUtil.calculateAge(appIndvCol.getCargo(appIndivIndex).getBrth_dt().toString());
						if(age<HouseHoldDemoGraphicsConstants.CHILDCAREAGELIMIT &&
								!childCareIdivs.contains(appIndvCol.getCargo(appIndivIndex).getIndv_seq_num()))
						{
							childCareIdivs.add(appIndvCol.getCargo(appIndivIndex).getIndv_seq_num());	
						}
					} catch (Exception e) {
						FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in"
								+ " HouseholdIndividualDocumentsInfoView.getchildCareIndivIds()>>> "+e.getMessage());
					}
					
				}
			}					
		}
		return childCareIdivs;
	}
	private Integer getPrimaryIndivId(APP_INDV_Collection appIndivCollection)
	{
		Integer primaryIndivId = null;
		if(appIndivCollection!=null && !appIndivCollection.isEmpty())
		{
			for(APP_INDV_Cargo eachAppIndiv : appIndivCollection.getResults())
			{
				if(Objects.nonNull(eachAppIndiv.getPrim_prsn_sw()) 
						&& HouseHoldDemoGraphicsConstants.Y.equals(eachAppIndiv.getPrim_prsn_sw()))
				{
					primaryIndivId  = eachAppIndiv.getIndv_seq_num();
					break;
				}
			}
		}
		return primaryIndivId;
	}
}
