package gov.state.nextgen.householddemographics.business.rules;

import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvAddiInfoRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.IndividualInformationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@Component
public class ABHouseholdMembersSummaryBO extends HouseHoldBaseBO {

    @Autowired
    protected JdbcTemplate jdbcTemplate;

    protected IndividualInformationRepo individualInformationRepo;
    
    @Autowired
    private CpAppIndvRepository cpAppIndvRepository;
    
    @Autowired
    private CpAppIndvAddiInfoRepository cpAppIndvAddiInfoRepository;

    public static final String SQL_PROG01 = "SELECT FMA_RQST_IND FROM CP_APP_PGM_RQST where app_num = ?";
    public static final String SQL_PROG02 =  "UPDATE CP_APP_PGM_RQST set MAGI_RQST_IND = '1' WHERE app_num = ?";

    /**
     * Load medical AID program flag.
     * @param appNumber
     * @return
     */
    public Boolean loadMedicaidProgram(String appNumber) {
        List<Map<String, Object>> rows =  jdbcTemplate.queryForList(SQL_PROG01,appNumber);
        if(!CollectionUtils.isEmpty(rows)){
            for(Map<String,Object> row:rows){
                if(Objects.nonNull(row.get("FMA_RQST_IND")) && row.get("FMA_RQST_IND").toString().equalsIgnoreCase(FwConstants.ONE)){
                    return true;
                }
            }
        }
        return true;
    }

    /**
     * Update medical AID program flag.
     * @param app_num
     * @throws FwWrappedException
     */
    public void updateMagiProgram(String app_num) throws FwWrappedException{
         try{
             jdbcTemplate.update(SQL_PROG02,app_num);
         }catch(FwWrappedException fe){
             throw fe;
         }
    }

    /**
     * Load Household members
     * @param appNumber
     * @return
     */
    public APP_INDV_Collection loadHouseholdMembers(String appNumber) {
        APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
        List<APP_INDV_Cargo> cpAppIndvCargos = getAppIndvCargos(individualInformationRepo.findByAppNum(Integer.parseInt(appNumber)));
        appIndvCollection.setResults(cpAppIndvCargos.toArray(new APP_INDV_Cargo[cpAppIndvCargos.size()]));
        return appIndvCollection;
    }

    public APP_INDV_Collection loadPersonDetails(String appNumber, int indv_seq_num) {
        APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
        List<APP_INDV_Cargo> indvCargoList  = cpAppIndvRepository.findByAppNumIndvSeqNum(Integer.parseInt(appNumber), Integer.valueOf(indv_seq_num));
        appIndvCollection.setResults(indvCargoList.toArray(new APP_INDV_Cargo[indvCargoList.size()]));
		return appIndvCollection;
    }
    
    
    public CP_APP_INDV_ADDI_INFO_Collection loadAdditionalInfoDetails(String appNumber) {
    	CP_APP_INDV_ADDI_INFO_Collection appIndvCollection;
        appIndvCollection = cpAppIndvAddiInfoRepository.getByAppNum(Integer.parseInt(appNumber));
		return appIndvCollection;
    }
    
    public APP_INDV_Collection loadPersonDetailsByAppNum(String appNumber) {
     try {	
        APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
        APP_INDV_Cargo[] indvCargoList  = cpAppIndvRepository.getByAppNum(Integer.parseInt(appNumber));
        appIndvCollection.setResults(indvCargoList);
		return appIndvCollection;
     }catch (Exception e) {
    	 throw e;
     }
    }
    public APP_INDV_Collection loadPersonDetailsSubMC(String appNumber) {
        try {	
           APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
           APP_INDV_Cargo[] indvCargoList  = cpAppIndvRepository.getByAppNumSubMC(Integer.parseInt(appNumber));
           appIndvCollection.setResults(indvCargoList);
   		return appIndvCollection;
        }catch (Exception e) {
       	 throw e;
        }
       }
}
