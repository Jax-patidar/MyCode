package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB;

@NoRepositoryBean
public interface HouseholdRelationshipAppInputRepo extends CrudRepository<APP_IN_NEWB,Integer> {

    APP_IN_NEWB findByAppNumAndIndvSeqNum(Integer appNum,Double indvSeqNum);

}
