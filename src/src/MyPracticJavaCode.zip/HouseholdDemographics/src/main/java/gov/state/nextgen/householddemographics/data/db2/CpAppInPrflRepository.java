package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Key;

@NoRepositoryBean
public interface CpAppInPrflRepository extends CrudRepository<APP_IN_PRFL_Cargo, APP_IN_PRFL_Key>{

	@Query(value ="select c from APP_IN_PRFL_Cargo c where c.app_num = ?1")
	public List<APP_IN_PRFL_Cargo> findByAppNum(String appNum);
	
	@Query(value ="select c from APP_IN_PRFL_Cargo c where c.app_num = ?1 and c.indv_seq_num = ?2")
	public APP_IN_PRFL_Cargo[] findByAppIdnvNum(String appNum, int indvSeqNum);
	
	@Query(value ="select c from APP_IN_PRFL_Cargo c where c.app_num = ?1 and c.indv_seq_num = ?2")
	public APP_IN_PRFL_Collection findCollByAppIdnvNum(String appNum, int indvSeqNum);

	
	@Query(value ="select c from APP_IN_PRFL_Cargo c where c.app_num = ?1")
	public APP_IN_PRFL_Cargo[] getAllData(String appNum);
	
	
	@Query(value="select * from ie_ssp_owner_comm.cp_app_in_prfl where app_num = ?1",nativeQuery=true)
	public APP_IN_PRFL_Cargo[] getPrflData(String appNum);
	

		
}
