package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

/**
 * Base class for all the domain objects.
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 */

public abstract class BaseDomainObject implements Serializable {

	private static final long serialVersionUID = 363073808879805652L;

	protected BaseDomainObject() {
		
	}

	
}
