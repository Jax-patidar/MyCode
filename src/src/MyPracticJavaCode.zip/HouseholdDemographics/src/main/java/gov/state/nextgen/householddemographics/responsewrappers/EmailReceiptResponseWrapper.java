package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

/*
 * EmailReceiptResponseWrapper - A response container for ABEMR
 * 
 * Created by @DeloitteUSI team
 * @author @arunkuj
 * */

@Component("ABEMR")
@Scope("prototype")
public class EmailReceiptResponseWrapper implements LogicResponseInterface{

	private static final String PAGE_ID = "ABEMR";
	
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {
DriverPageResponse driverPageResponse = new DriverPageResponse();
		
		Map pageCollection = fwTxn.getPageCollection();
		List<CP_APP_RGST_Cargo> cargoList = new ArrayList<CP_APP_RGST_Cargo>();
		CP_APP_RGST_Cargo cargo;
		CP_APP_RGST_Collection appCollection = pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION) != null ? 
				(CP_APP_RGST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION) : null;
		if(appCollection != null && !appCollection.isEmpty() && appCollection.size() > 0) {
			for(int i=0; i< appCollection.size();i++) {
				cargo = appCollection.getCargo(i);
				cargoList.add(cargo);
			}
			
		}
		
		List<APP_RQST_Cargo> rqstCargoList = new ArrayList<APP_RQST_Cargo>();
		APP_RQST_Collection rqstAppCollection = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.APP_RQST_COLL)) ? 
				(APP_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.APP_RQST_COLL) : null;
		if(Objects.nonNull(rqstAppCollection) && !rqstAppCollection.isEmpty()) {
			rqstCargoList.add(rqstAppCollection.getCargo(0));			
		}
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, rqstCargoList);
		
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION, cargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getRequest().get(FwConstants.APP_NUMBER)));
		return driverPageResponse;
	}

}
