package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_TAX_RETURNS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_TAX_RETURNS_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_TAX_RETURNS_Key;

@Repository
public interface AppInTaxReturnsRepository extends CrudRepository<APP_IN_TAX_RETURNS_Cargo, APP_IN_TAX_RETURNS_Key>{

	@Query("select c from APP_IN_TAX_RETURNS_Cargo c where c.app_number =?1 and c.src_app_ind = ?2 and c.indv_seq_num IN ?3")
	public APP_IN_TAX_RETURNS_Collection loadTaxReturnsInfo(Integer appNumber, String src_ind, List<Integer> indvIds);
	
	@Query("select c from APP_IN_TAX_RETURNS_Cargo c where c.app_number =?1 and c.src_app_ind = ?2 and c.indv_seq_num = ?3")
	public APP_IN_TAX_RETURNS_Collection fetchTaxReturnsDetails(Integer appNum, String src_ind, Integer indv_seq_num);
	
	@Transactional
	@Modifying
	@Query("DELETE from APP_IN_TAX_RETURNS_Cargo where app_number =?1 and indv_seq_num = ?2 and src_app_ind = ?3")
	public void deleteTaxReturnsData(Integer appNum, Integer indv_seq_num, String src_ind);
}
