package gov.state.nextgen.householddemographics.business.rules;

import java.util.List;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppInPregRepository;

@Service
public class AFBHouseholdPregnancyBO extends AbstractBO{
	
	@Autowired
	private CpAppInPregRepository pregRepo;
	
	public void storePregnancyDetailsInDb(CP_APP_IN_PREG_Cargo appInPregCargo, String appNum, int indvSeqNo,
			String srcAppInd, String pageId) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AFBHouseholdPregnancyBO.storePregnancyDetails() - START");
		try {

			CP_APP_IN_PREG_Collection appInPregBeforeColl = pregRepo.getPregCollection(Integer.parseInt(appNum), srcAppInd, indvSeqNo);
			CP_APP_IN_PREG_Cargo appInPregBeforeCargo = null;

			if (null != appInPregBeforeColl && appInPregBeforeColl.size() > 0) {

				appInPregBeforeCargo = appInPregBeforeColl.getCargo(0);
				if ("ABBRI".equals(pageId)) {
					appInPregBeforeCargo.setIs_breast_feeding("Y");
					appInPregBeforeCargo.setBirth_in_twelv_mnths(appInPregCargo.getBirth_in_twelv_mnths());
				} else {
					appInPregBeforeCargo.setIs_pregnant("Y");
					appInPregBeforeCargo.setPreg_due_dt(appInPregCargo.getPreg_due_dt());
					appInPregBeforeCargo.setBaby_ct(appInPregCargo.getBaby_ct());
					appInPregBeforeCargo.setPresump_elig_card_ind(appInPregCargo.getPresump_elig_card_ind());
					appInPregBeforeCargo.setEnrl_stat_cd(appInPregCargo.getEnrl_stat_cd());
					appInPregBeforeCargo.setNt_enrl_stat_desc(appInPregCargo.getNt_enrl_stat_desc());
					appInPregBeforeCargo.setChg_eff_dt(appInPregCargo.getChg_eff_dt());
				}
				pregRepo.save(appInPregBeforeCargo);
			} else {
				if ("ABBRI".equals(pageId)) {
					appInPregCargo.setIs_breast_feeding("Y");
				} else {
					appInPregCargo.setIs_pregnant("Y");
				}
				pregRepo.save(appInPregCargo);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"AFBHouseholdPregnancyBO.storePregnancyDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + " milliseconds");
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}
	
	public CP_APP_IN_PREG_Collection getAllPregnantList(String appNumber, String srcAppInd, List<Integer> indvIds) {
		String isPregnant = "Y";
		return pregRepo.getAllDetails(Integer.parseInt(appNumber), srcAppInd, indvIds, isPregnant);
	}
	
	public void savePregData(CP_APP_IN_PREG_Cargo appInPregCargo) {
	 try {	
		pregRepo.save(appInPregCargo);
	 }catch(Exception e) {
		 throw e;
	 }
	}
	
	public CP_APP_IN_PREG_Collection getPregnantDetails(String appNum, String srcAppInd, Integer indvSeqNo) {
		return pregRepo.getPregCollection(Integer.parseInt(appNum), srcAppInd, indvSeqNo);
	}
	
	public void deleteBreastFeedingDetails(String appNumber, Integer indvSeqNumber) {
		pregRepo.updateBreastFeedingDetail(Integer.parseInt(appNumber), indvSeqNumber);
	}
	
	public CP_APP_IN_PREG_Collection getNonNullBreastFeedingDetails(String appNum, String srcAppIndAfb,
			List<Integer> indvIds) {
		String isBreastFeeding = "Y";
		return pregRepo.getBreastFeedingDetails(Integer.parseInt(appNum), srcAppIndAfb, indvIds, isBreastFeeding);
	}
	
	public CP_APP_IN_PREG_Collection loadPregDetailsByAppNum(String appNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AFBHouseholdPregnancyBO.loadPregDetailsByAppNum() - START");
		try {
			CP_APP_IN_PREG_Collection appInPregColl = pregRepo.loadPregDetailsByAppNum(Integer.parseInt(appNum));
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"AFBHouseholdPregnancyBO.loadPregDetailsByAppNum() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime));
			return appInPregColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}

}
