package gov.state.nextgen.householddemographics.business.rules;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.references.IReferenceConstants;
import gov.state.nextgen.access.management.references.IReferenceTableData;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.access.management.util.DateRoutine;
import gov.state.nextgen.access.management.util.IndividualAge;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;
import gov.state.nextgen.householddemographics.data.db2.IndividualInformationRepo;

/**
 * PeopleHandler
 *
 * @author prabhat/prasannakumar
 */
@Service
public class PeopleHandler extends HouseHoldBaseBO {

    private static String DEFAULT_VALUE_SPACE = " ";
    private static String DEFAULT_VALUE_ZERO = "0";
    private static String DEFAULT_VALUE_ONE = "1";
    private static String PRIMARY_PERSON = "PP";
    private static String SPOUSE = "SPOUSE";
    private static String DEFAULT_OOH_IND = "N"; // out of home indicator
    public static final String SPACE = " ";


    @Autowired
    private DateRoutine dateRoutine;

    @Autowired
    private CpAppIndvRepository cpAppIndvRepository;

    @Autowired
    private IReferenceTableManager iref;

    @Autowired
    HouseholdRelationshipRepo householdRelationshipRepo;

	protected IndividualInformationRepo individualInformationRepo;

    private static Logger logger = LoggerFactory.getLogger(PeopleHandler.class);


    private final Map<Object, Object> dropdownMap = new HashMap<Object, Object>();
    private final Map<Object, Object> relevantDropDownMap = new HashMap<Object, Object>();
    private  Map individualMap = new HashMap();

    /**
     * Returns the number of Individuals in the Map
     */
    public Integer getNumberOfIndividuals(Map individualMap) {
        return individualMap.size();
    }

    /**
     * Loads the Individuals information for the given APP_NUM
     */
    public void loadPeopleHandler(final String aAppNum) {

        try {
            // Update indv map
            final INDIVIDUAL_Custom_Cargo[] individualCustomCargoArray = getAllIndividuals(aAppNum);
            if (!(individualMap.isEmpty())) {
            	 individualMap = new HashMap();
            } 
            if(individualCustomCargoArray != null) {
            for (int i = 0; i < individualCustomCargoArray.length; i++) { 	
                individualMap.put(
                        individualCustomCargoArray[i].getIndv_seq_num(),
                        individualCustomCargoArray[i]);
            }
            }
            // Update dropdown map
            sortIndivAndUpdateDropDown();

        } catch (final Exception fe) {
            throw fe;
        }
    }
    
	public void updateChildCareValue(String appNum, Integer indvSeqNumber, String src_app_ind,
			String other_hhm_care_desc, String isChildCare) {
		cpAppIndvRepository.updateChildCareValue(Integer.parseInt(appNum), indvSeqNumber, src_app_ind, other_hhm_care_desc, isChildCare);
	}
	@SuppressWarnings("squid:S3776")
    private INDIVIDUAL_Custom_Cargo[] getAllIndividuals(String aAppNum) {
        try {
            //get the RLT_CD information for the app_num
            final APP_HSHL_RLT_Collection appHSHLCollection = new APP_HSHL_RLT_Collection();
            final APP_HSHL_RLT_Cargo appHSHLCargo = new APP_HSHL_RLT_Cargo();
            appHSHLCargo.setApp_num(aAppNum);
            appHSHLCollection.addCargo(appHSHLCargo);
            List<APP_HSHL_RLT_Cargo> appHouseHoldRelationshipCargos = getAppHouseHoldRelationshipCargos(aAppNum);
            // get the app_indv information for the app_num
            final APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
            final APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
            appIndvCargo.setApp_num(aAppNum);
            appIndvCollection.addCargo(appIndvCargo);
            int rlvn = 2;
            final APP_INDV_Cargo[] appIndvCargoArray = cpAppIndvRepository.getNonDelIndv(Integer.parseInt(aAppNum), rlvn);
            // Getting individuals in home only
            int noOfndividuals = 0;
            INDIVIDUAL_Custom_Cargo[] individualCustomCargoArray = null ;
            if(appIndvCargoArray != null && appIndvCargoArray.length > 0) {
             noOfndividuals = appIndvCargoArray.length;
             individualCustomCargoArray = new INDIVIDUAL_Custom_Cargo[noOfndividuals];
            }
            for (int i = 0; i < noOfndividuals; i++) {
                // PCR # 32248 adding individuals who are not out of home
                // EDSCP CP - Need both in and out of home individuals.
            	if(individualCustomCargoArray != null) {
                individualCustomCargoArray[i] = new INDIVIDUAL_Custom_Cargo();
                individualCustomCargoArray[i]
                        .setIndv_seq_num(appIndvCargoArray[i].getIndv_seq_num().toString());
                if(Objects.nonNull(appIndvCargoArray[i].getBrth_dt())) {
                	individualCustomCargoArray[i].setBrth_dt(appIndvCargoArray[i]
                            .getBrth_dt().toString());
                }
                individualCustomCargoArray[i].setFst_nam(appIndvCargoArray[i]
                        .getFst_nam().trim());
                individualCustomCargoArray[i].setLast_nam(appIndvCargoArray[i]
                        .getLast_nam());
                individualCustomCargoArray[i].setMid_init(appIndvCargoArray[i]
                        .getMid_init());
                individualCustomCargoArray[i].setRlvn_ind(appIndvCargoArray[i]
                        .getRlvn_ind().toString());
                individualCustomCargoArray[i]
                        .setLive_arng_typ(appIndvCargoArray[i]
                                .getLive_arng_typ());
                individualCustomCargoArray[i].setSex_ind(appIndvCargoArray[i]
                        .getSex_ind());
                if(Objects.nonNull(appIndvCargoArray[i].getBrth_dt())) {
                	individualCustomCargoArray[i].setIndv_age(dateRoutine.getAge((appIndvCargoArray[i].getBrth_dt()), new java.sql.Date(new java.util.Date().getTime())));
                }
                individualCustomCargoArray[i]
                        .setOut_of_home_ind(appIndvCargoArray[i]
                                .getChld_out_home_resp());
                individualCustomCargoArray[i]
                        .setChld_trb_mbr_resp(appIndvCargoArray[i]
                                .getChld_trb_mbr_resp());
                individualCustomCargoArray[i]
                        .setTrb_mbr_resp(appIndvCargoArray[i].getTrb_mbr_resp());
                individualCustomCargoArray[i]
                        .setSuffix_name(appIndvCargoArray[i].getSuffix_name());
                individualCustomCargoArray[i]
                        .setSrc_app_ind(appIndvCargoArray[i].getSrc_app_ind());

//			TODO: To be uncommented once APP_HSHL_RLT_Cargo is used.
                if (!FwConstants.YES.equals(appIndvCargoArray[i].getPrim_prsn_sw())) {
                    individualCustomCargoArray[i].setRlt_cd(
                            getRelationCDForNonPP(appHouseHoldRelationshipCargos, individualCustomCargoArray[i].getIndv_seq_num(),
                                    individualCustomCargoArray[i].getSex_ind()));
                } else {
                    individualCustomCargoArray[i].setRlt_cd(PRIMARY_PERSON);
                }
                individualCustomCargoArray[i]
                        .setIndv_pin_num(appIndvCargoArray[i].getIndv_seq_num().toString());
                // EDSCP CP - Need both in and out of home individuals.
			}
		}
            return individualCustomCargoArray;
        } catch (final FwException fe) {
            throw fe;
        }
    }

    public void updateIndividual(APP_INDV_Cargo appIndvCargo) {

        try {
            APP_INDV_Collection appIndvColl = new APP_INDV_Collection();
            appIndvColl.addCargo(appIndvCargo);
            
            if(null == appIndvCargo.getRlvn_ind()) {
            	appIndvCargo.setRlvn_ind(1);
            }
          //set update date
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			appIndvCargo.setUpdate_dt(currentTimeStamp);
            cpAppIndvRepository.save(appIndvCargo);
            
            loadPeopleHandler(appIndvCargo.getApp_num());
            // getting the old data from the Individual Map
            String seqNum = appIndvCargo.getIndv_seq_num().toString();
            INDIVIDUAL_Custom_Cargo indivCustomCargo = (INDIVIDUAL_Custom_Cargo) individualMap.get(seqNum);
            
            if(indivCustomCargo == null) {
            	indivCustomCargo = new INDIVIDUAL_Custom_Cargo();
            }

            // setting the new values
            if(Objects.nonNull(appIndvCargo.getBrth_dt())){
                indivCustomCargo.setBrth_dt(appIndvCargo.getBrth_dt().toString());
            }
            indivCustomCargo.setFst_nam(appIndvCargo.getFst_nam());
            if(Objects.nonNull(appIndvCargo.getBrth_dt())) {
            	indivCustomCargo.setIndv_age(dateRoutine.getAge((appIndvCargo
                        .getBrth_dt()), new java.sql.Date(new java.util.Date().getTime())));
            }
            indivCustomCargo.setIndv_seq_num(appIndvCargo.getIndv_seq_num().toString());
            indivCustomCargo.setLast_nam(appIndvCargo.getLast_nam());
            indivCustomCargo.setMid_init(appIndvCargo.getMid_init());
            indivCustomCargo.setRlvn_ind(appIndvCargo.getRlvn_ind().toString());
            indivCustomCargo.setLive_arng_typ(appIndvCargo.getLive_arng_typ());
            indivCustomCargo.setSex_ind(appIndvCargo.getSex_ind());
            indivCustomCargo.setOut_of_home_ind(appIndvCargo
                    .getChld_out_home_resp());
            indivCustomCargo.setChld_trb_mbr_resp(appIndvCargo
                    .getChld_trb_mbr_resp());
            indivCustomCargo.setTrb_mbr_resp(appIndvCargo.getTrb_mbr_resp());
            // EDSP Starts
            indivCustomCargo.setSuffix_name(appIndvCargo.getSuffix_name());
            indivCustomCargo.setRes_va_sw(appIndvCargo.getRes_va_sw());
            indivCustomCargo.setRes_ga_ind(appIndvCargo.getRes_ga_ind());
            indivCustomCargo.setLiving_arrangement_cd(appIndvCargo
                    .getLiving_arrangement_cd());
            // EDSP Ends
            individualMap
                    .put(appIndvCargo.getIndv_seq_num(), indivCustomCargo);

            // update dropdown map
            sortIndivAndUpdateDropDown();
        } catch (final Exception fe) {
            throw fe;
        }
    }

    /**
     * Adds the given Individual with RLT_CD as Space
     */
    public void addNewIndividual(final APP_INDV_Cargo aAppIndvCargo, String appNum) {
        try {


            Map individualMap = getHouseholdIndividuals(appNum);

            // Update indv map
            final INDIVIDUAL_Custom_Cargo indivCustomCargo = new INDIVIDUAL_Custom_Cargo();
            if(Objects.nonNull(aAppIndvCargo.getBrth_dt())){
                String brthDate = aAppIndvCargo.getBrth_dt().toString();
                indivCustomCargo.setBrth_dt(brthDate);
                indivCustomCargo.setIndv_age(dateRoutine.getAge(dateRoutine.getDateFromTimeStamp(brthDate), new java.sql.Date(new java.util.Date().getTime())));
            }

            indivCustomCargo.setFst_nam(aAppIndvCargo.getFst_nam());
            if(Objects.nonNull(aAppIndvCargo.getIndv_seq_num())){
                indivCustomCargo.setIndv_seq_num(aAppIndvCargo.getIndv_seq_num().toString());
            }
            indivCustomCargo.setLast_nam(aAppIndvCargo.getLast_nam());
            indivCustomCargo.setMid_init(aAppIndvCargo.getMid_init());
            indivCustomCargo.setRlt_cd(StringUtils.EMPTY);

            if(Objects.nonNull(aAppIndvCargo.getRlvn_ind())){
                indivCustomCargo.setRlvn_ind(aAppIndvCargo.getRlvn_ind().toString());
            }

            indivCustomCargo.setLive_arng_typ(aAppIndvCargo.getLive_arng_typ());
            indivCustomCargo.setSex_ind(aAppIndvCargo.getSex_ind());
            indivCustomCargo.setOut_of_home_ind(aAppIndvCargo.getChld_out_home_resp()); // Out of home ind
            indivCustomCargo.setChld_trb_mbr_resp(aAppIndvCargo.getChld_trb_mbr_resp());
            indivCustomCargo.setTrb_mbr_resp(aAppIndvCargo.getTrb_mbr_resp());
            indivCustomCargo.setSrc_app_ind(aAppIndvCargo.getSrc_app_ind());
            // EDSP Starts
            indivCustomCargo.setSuffix_name(aAppIndvCargo.getSuffix_name());
            indivCustomCargo.setRes_va_sw(aAppIndvCargo.getRes_va_sw());
            indivCustomCargo.setDabl_resp(aAppIndvCargo.getDisabled_resp());
            // EDSP Ends
            individualMap.put(aAppIndvCargo.getIndv_seq_num(), indivCustomCargo);

            // Update dropdown map
            sortIndivAndUpdateDropDown(individualMap);
        } catch (Exception exception) {
            throw exception;
        }
    }

    private void sortIndivAndUpdateDropDown() {
     try {	
        INDIVIDUAL_Custom_Collection individualCustomCollection = new INDIVIDUAL_Custom_Collection();
        final Iterator iter = individualMap.keySet().iterator();
        while (iter.hasNext()) {
            individualCustomCollection
                    .addCargo((INDIVIDUAL_Custom_Cargo) individualMap.get(iter
                            .next()));
        }

        individualCustomCollection = sortIndividuals(individualCustomCollection);

        // update dropdown map
        updateDropDown(individualCustomCollection);
     }catch(Exception e) {
    	 throw e;
     }
    }

    private void updateDropDown(INDIVIDUAL_Custom_Collection individualCustomCollection) {

        final List codeList = new ArrayList();
        final List descList = new ArrayList();
        final List relevantCodeList = new ArrayList();
        final List relevantDescList = new ArrayList();

        try {

            final int size = individualCustomCollection.size();
            for (int i = 0; i < size; i++) {
                final INDIVIDUAL_Custom_Cargo indivCustomCargo = (INDIVIDUAL_Custom_Cargo) individualCustomCollection
                        .get(i);

                // Add code and desc for all individuals
                codeList.add(indivCustomCargo.getIndv_seq_num());
                descList.add(indivCustomCargo.getFst_nam());

                // Add code and desc for all relevant individuals
                if (Integer.parseInt(indivCustomCargo.getRlvn_ind()) == 1) {
                    relevantCodeList.add(indivCustomCargo.getIndv_seq_num());
                    relevantDescList.add(indivCustomCargo.getFst_nam());
                }
            }
            // Add code and desc for all individuals in dropdownMap
            dropdownMap.put(AppConstants.INDV_SEQUENCE_NUMBERS, codeList);
            dropdownMap.put(AppConstants.INDV_DESCRIPTIONS, descList);
            // Add code and desc for all relevant individuals in
            // relevantDropDownMap
            relevantDropDownMap.put(AppConstants.INDV_SEQUENCE_NUMBERS,
                    relevantCodeList);
            relevantDropDownMap.put(AppConstants.INDV_DESCRIPTIONS,
                    relevantDescList);
        } catch (final Exception fe) {
            throw fe;
        }
    }

    /**
     * Returns all the individuals
     */
    public INDIVIDUAL_Custom_Collection getAllIndvCustomCollectionFromAppNum(String appNum) {
        Map individualMap = getHouseholdIndividuals(appNum);
        final INDIVIDUAL_Custom_Collection indvCustomCollection = new INDIVIDUAL_Custom_Collection();
        final Iterator iter = individualMap.keySet().iterator();
        while (iter.hasNext()) {
            indvCustomCollection.add(individualMap.get(iter.next()));
        }
        return indvCustomCollection;
    }

    public INDIVIDUAL_Custom_Collection sortIndividuals(INDIVIDUAL_Custom_Collection aIndividualCustomCollection) {

        try {

            final INDIVIDUAL_Custom_Collection indvCustomCollection = new INDIVIDUAL_Custom_Collection();
            INDIVIDUAL_Custom_Cargo indvCustomCargo = null;
            String seqNum = "";
            String rltnCd = "";

            final List indvList = new ArrayList();
            final Map primaryAndSpouse = new HashMap();

            final List primaryPersonList = new ArrayList();
            primaryAndSpouse.put(PRIMARY_PERSON, primaryPersonList);

            final List spouseList = new ArrayList();
            primaryAndSpouse.put(SPOUSE, spouseList);

            SortIndividualByAge sortChildrenByAge = null;
            SortIndividualByAge sortOtherByAge = null;
            SortIndividualByAge sortByAge = null;

            final List sortedChildrenColl = new ArrayList();
            final List sortedOtherColl = new ArrayList();
            final List sortedColl = new ArrayList();

            final IReferenceTableData irefDataSpouse = iref
                    .filterDataOnSingleColumn("TREL", FwConstants.ENGLISH, 67,
                            IReferenceConstants.FILTER_INCLUDE_MATCH_ONE,
                            new String[]{"SPREL"});
            final IReferenceTableData irefDataChild = iref
                    .filterDataOnSingleColumn("TREL", FwConstants.ENGLISH, 67,
                            IReferenceConstants.FILTER_INCLUDE_MATCH_ONE,
                            new String[]{"CHREL"});
            final IReferenceTableData irefDataOther = iref
                    .filterDataOnSingleColumn("TREL", FwConstants.ENGLISH, 67,
                            IReferenceConstants.FILTER_INCLUDE_MATCH_ONE,
                            new String[]{"OTREL"});
            int size = 0;
            if (aIndividualCustomCollection != null) {
                size = aIndividualCustomCollection.size();
            }

            for (int i = 0; i < size; i++) {
                indvCustomCargo = (INDIVIDUAL_Custom_Cargo) aIndividualCustomCollection
                        .get(i);
                seqNum = indvCustomCargo.getIndv_seq_num();
                rltnCd = indvCustomCargo.getRlt_cd();

                if ("1".equals(seqNum)) {
                    ((List) primaryAndSpouse.get(PRIMARY_PERSON))
                            .add(indvCustomCargo);
                } else if (irefDataSpouse.containsCode(rltnCd)) {
                    ((List) primaryAndSpouse.get(SPOUSE)).add(indvCustomCargo);
                } else if (irefDataChild.containsCode(rltnCd)) {
                    sortChildrenByAge = new SortIndividualByAge();
                    sortChildrenByAge.setIndividualCustomCargo(indvCustomCargo);
                    sortedChildrenColl.add(sortChildrenByAge);
                } else if (irefDataOther.containsCode(rltnCd)) {
                    sortOtherByAge = new SortIndividualByAge();
                    sortOtherByAge.setIndividualCustomCargo(indvCustomCargo);
                    sortedOtherColl.add(sortOtherByAge);
                } else {
                    sortByAge = new SortIndividualByAge();
                    sortByAge.setIndividualCustomCargo(indvCustomCargo);
                    sortedColl.add(sortByAge);
                }
            }

            if (primaryAndSpouse.get(PRIMARY_PERSON) != null) {
                indvList.addAll((List) primaryAndSpouse.get(PRIMARY_PERSON));
            }

            if (primaryAndSpouse.get(SPOUSE) != null) {
                indvList.addAll((List) primaryAndSpouse.get(SPOUSE));
            }

            // Sort children - oldest to youngest
            Collections.sort(sortedChildrenColl, Collections.reverseOrder());
            final int size1 = sortedChildrenColl.size();
            for (int i = 0; i < size1; i++) {
                final SortIndividualByAge srtChildren = (SortIndividualByAge) sortedChildrenColl
                        .get(i);
                indvList.add(srtChildren.getIndividualCustomCargo());
            }

            // Sort others - oldest to youngest
            Collections.sort(sortedOtherColl, Collections.reverseOrder());
            final int size2 = sortedOtherColl.size();
            for (int i = 0; i < size2; i++) {
                final SortIndividualByAge srtOther = (SortIndividualByAge) sortedOtherColl
                        .get(i);
                indvList.add(srtOther.getIndividualCustomCargo());
            }

            // Sort individuals without relationships - oldest to youngest
            Collections.sort(sortedColl, Collections.reverseOrder());
            final int size3 = sortedColl.size();
            for (int i = 0; i < size3; i++) {
                final SortIndividualByAge srt = (SortIndividualByAge) sortedColl
                        .get(i);
                indvList.add(srt.getIndividualCustomCargo());
            }

            final int listSize = indvList.size();
            for (int k = 0; k < listSize; k++) {
                final INDIVIDUAL_Custom_Cargo indvCargo = (INDIVIDUAL_Custom_Cargo) indvList
                        .get(k);
                indvCustomCollection.addCargo(indvCargo);
            }
            return indvCustomCollection;

        } catch (final Exception fe) {
            throw fe;
        }

    }

    /**
     * Returns all the individuals
     */
    public INDIVIDUAL_Custom_Collection getAllIndividuals() {
        final INDIVIDUAL_Custom_Collection indvCustomCollection = new INDIVIDUAL_Custom_Collection();
        final Iterator iter = individualMap.keySet().iterator();
        while (iter.hasNext()) {
            indvCustomCollection.add(individualMap.get(iter.next()));
        }
        return indvCustomCollection;
    }

    public APP_INDV_Cargo createIndividual() throws ParseException {

        final APP_INDV_Cargo aAppIndvCargo = new APP_INDV_Cargo();
        aAppIndvCargo.setAln_sponser_sw(StringUtils.EMPTY);

        //TODO: Refactor below block
        java.sql.Date highDate = new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(AppConstants.HIGH_DATE).getTime());
        aAppIndvCargo.setBrth_dt(highDate);

        aAppIndvCargo.setIntn_res_resp(StringUtils.EMPTY);
        aAppIndvCargo.setLang_cd(StringUtils.EMPTY);
        aAppIndvCargo.setLive_arng_typ(StringUtils.EMPTY);
        aAppIndvCargo.setMig_farm_wrkr_sw(StringUtils.EMPTY);
        aAppIndvCargo.setMrtl_stat_cd(StringUtils.EMPTY);
        aAppIndvCargo.setPreg_resp(StringUtils.EMPTY);
        aAppIndvCargo.setPrim_prsn_sw(StringUtils.EMPTY);
        aAppIndvCargo.setRec_cplt_ind(0);
        aAppIndvCargo.setRes_wi_sw(StringUtils.EMPTY);
        aAppIndvCargo.setRlvn_ind(1);
        aAppIndvCargo.setSex_ind(StringUtils.EMPTY);
        aAppIndvCargo.setSs_num_app_dt(highDate);
        aAppIndvCargo.setSsn_num(String.valueOf("0"));
        aAppIndvCargo.setUs_ctzn_sw(StringUtils.EMPTY);
        aAppIndvCargo.setChld_trb_mbr_resp(StringUtils.EMPTY);
        aAppIndvCargo.setTrb_mbr_resp(StringUtils.EMPTY);
        aAppIndvCargo.setAi_ind(String.valueOf("0"));
        aAppIndvCargo.setAsia_ind(String.valueOf("0"));
        aAppIndvCargo.setBlk_ind(String.valueOf("0"));
        aAppIndvCargo.setHspc_ind(String.valueOf("0"));
        aAppIndvCargo.setPac_isl_ind(String.valueOf("0"));
        aAppIndvCargo.setWht_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_oth_asian_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_samoan_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_filipino_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_chinese_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_vie_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_korean_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_guam_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_nhpi_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_oth_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_japanese_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_persian_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_eastasian_ind(String.valueOf("0"));
        aAppIndvCargo.setRace_unknown_ind(String.valueOf("0"));
        aAppIndvCargo.setChld_out_home_resp(DEFAULT_OOH_IND);
        return aAppIndvCargo;
    }

    public INDIVIDUAL_Custom_Collection sortIndividualsByAge(
            final INDIVIDUAL_Custom_Collection individualCustomCollection) {

        final INDIVIDUAL_Custom_Collection indvCustomCollection = new INDIVIDUAL_Custom_Collection();

        try {

            SortIndividualByAge sortIndividualsByAge = null;
            final List sortedIndividualsColl = new ArrayList();
            final int individualCustomCollectionSize = individualCustomCollection
                    .size();
            for (int i = 0; i < individualCustomCollectionSize; i++) {
                sortIndividualsByAge = new SortIndividualByAge();
                sortIndividualsByAge
                        .setIndividualCustomCargo((INDIVIDUAL_Custom_Cargo) individualCustomCollection
                                .get(i));
                sortedIndividualsColl.add(sortIndividualsByAge);
            }

            Collections.sort(sortedIndividualsColl, Collections.reverseOrder());

            final int listSize = sortedIndividualsColl.size();
            for (int k = 0; k < listSize; k++) {
                final INDIVIDUAL_Custom_Cargo indvCargo = ((SortIndividualByAge) sortedIndividualsColl
                        .get(k)).getIndividualCustomCargo();
                indvCustomCollection.addCargo(indvCargo);
            }
            return indvCustomCollection;

        } catch (final FwException fe) {
            throw fe;
        } catch (final Exception e) {

            throw new RuntimeException("sortIndividualsByAge" + e);
        }
    }

    /**
     * Returns individuals other that 'Moved out of home' or 'Some one Died'
     */
    public INDIVIDUAL_Custom_Collection getInHomeIndividuals(String appNum) {
        try {
            final INDIVIDUAL_Custom_Collection indvCustomCollection = new INDIVIDUAL_Custom_Collection();
            Map<Object,Object> inHomeIndividualsMap = new HashMap();
            final Iterator iter = getHouseholdIndividuals(appNum).keySet().iterator();
            INDIVIDUAL_Custom_Cargo indvCargo = null;
            while (iter.hasNext()) {
                indvCargo = (INDIVIDUAL_Custom_Cargo) getHouseholdIndividuals(appNum).get(iter.next());
                if(Objects.nonNull(indvCargo)){
                    indvCustomCollection.add(indvCargo);
                    inHomeIndividualsMap.put(indvCargo.getIndv_seq_num(), indvCargo);
                }
            }
            return indvCustomCollection;
        } catch (Exception exception) {
            throw exception;
        }
    }

    /**
     * Returns an Individual for the given IndvSeqNum
     */
    public INDIVIDUAL_Custom_Cargo getIndividual(final String aIndvSeqNum) {
        return (INDIVIDUAL_Custom_Cargo) individualMap.get(aIndvSeqNum);
    }

    public Map sortIndividualsForDropdown(
            final INDIVIDUAL_Custom_Collection aIndividualCustomCollection) {

        try {
            final Map returnMap = new HashMap();
            final List codeList = new ArrayList();
            final List descList = new ArrayList();
            final int collSize = aIndividualCustomCollection.size();

            for (int k = 0; k < collSize; k++) {
                final INDIVIDUAL_Custom_Cargo indvCargo = (INDIVIDUAL_Custom_Cargo) aIndividualCustomCollection.get(k);
                codeList.add(indvCargo.getIndv_seq_num());
                String name = "";
                if ((indvCargo.getFst_nam() != null)
                        && !"".equals(indvCargo.getFst_nam().trim())) {
                    name = name + " " + indvCargo.getFst_nam();
                }
                if ((indvCargo.getMid_init() != null)
                        && !"".equals(indvCargo.getMid_init().trim())) {
                    name = name + " " + indvCargo.getMid_init();
                }
                if ((indvCargo.getLast_nam() != null)
                        && !"".equals(indvCargo.getLast_nam().trim())) {
                    name = name + " " + indvCargo.getLast_nam();
                }
                if ((indvCargo.getSuffix_name() != null)
                        && !"".equals(indvCargo.getSuffix_name().trim())) {
                    name = name + " " + indvCargo.getSuffix_name();
                }
                descList.add(name);
            }
            // Add code and desc for all individuals in the map
            returnMap.put(AppConstants.INDV_SEQUENCE_NUMBERS, codeList);
            returnMap.put(AppConstants.INDV_DESCRIPTIONS, descList);
            return returnMap;
        } catch (final FwException fe) {
            throw fe;
        }
    }

    /**
     * @param appNumber
     * @return
     */
    public INDIVIDUAL_Custom_Collection getInAndOutOfHomeIndividuals(String appNumber) {
        try {

            final INDIVIDUAL_Custom_Collection indvCustomCollection = new INDIVIDUAL_Custom_Collection();
            // get the RLT_CD information for the app_num
            final APP_HSHL_RLT_Collection appHSHLCollection = new APP_HSHL_RLT_Collection();
            final APP_HSHL_RLT_Cargo appHSHLCargo = new APP_HSHL_RLT_Cargo();
            appHSHLCargo.setApp_num(appNumber);
            appHSHLCollection.addCargo(appHSHLCargo);
            List<APP_HSHL_RLT_Cargo> appHouseHoldRelationshipCargos = getAppHouseHoldRelationshipCargos(appNumber);

            // get the app_indv information for the app_num
            final APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
            final APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
            appIndvCargo.setApp_num(appNumber);
            appIndvCollection.addCargo(appIndvCargo);

            List<APP_INDV_Cargo> appIndividualCargos = getAppIndividualCargo(appNumber);

            List<INDIVIDUAL_Custom_Cargo> individual_custom_cargos = new ArrayList<INDIVIDUAL_Custom_Cargo>();
            for (APP_INDV_Cargo appIndividualCargo : appIndividualCargos) {
                INDIVIDUAL_Custom_Cargo individualCustomCargo = new INDIVIDUAL_Custom_Cargo();
                individualCustomCargo.setIndv_seq_num(String.valueOf(appIndividualCargo.getIndv_seq_num()));
                individualCustomCargo.setBrth_dt(String.valueOf(appIndividualCargo.getBrth_dt()));
                individualCustomCargo.setFst_nam(appIndividualCargo.getFst_nam().trim());
                individualCustomCargo.setLast_nam(appIndividualCargo.getLast_nam());
                individualCustomCargo.setMid_init(appIndividualCargo.getMid_init());
                individualCustomCargo.setRlvn_ind(String.valueOf(appIndividualCargo.getRlvn_ind()));
                individualCustomCargo.setLiving_arrangement_cd(appIndividualCargo.getLiving_arrangement_cd());
                individualCustomCargo.setSex_ind(appIndividualCargo.getSex_ind());
                individualCustomCargo.setIndv_age(dateRoutine.getAge(dateRoutine.getDateFromTimeStamp(String.valueOf(appIndividualCargo.getBrth_dt())), new java.sql.Date(new java.util.Date().getTime())));
                individualCustomCargo.setOut_of_home_ind(appIndividualCargo.getChld_out_home_resp());
                individualCustomCargo.setChld_trb_mbr_resp(appIndividualCargo.getChld_trb_mbr_resp());
                individualCustomCargo.setTrb_mbr_resp(appIndividualCargo.getTrb_mbr_resp());

                if (!FwConstants.YES.equals(appIndividualCargo.getPrim_prsn_sw())) {
                    individualCustomCargo.setRlt_cd(getRelationCDForNonPP(appHouseHoldRelationshipCargos, individualCustomCargo.getIndv_seq_num(), individualCustomCargo.getSex_ind()));
                } else {
                    individualCustomCargo.setRlt_cd(PRIMARY_PERSON);
                }
                individual_custom_cargos.add(individualCustomCargo);
            }
            indvCustomCollection.setResults(individual_custom_cargos.toArray(new INDIVIDUAL_Custom_Cargo[individual_custom_cargos.size()]));
            for (INDIVIDUAL_Custom_Cargo individual_custom_cargo : individual_custom_cargos) {
                individualMap.put(individual_custom_cargo.getIndv_seq_num(), individual_custom_cargo);
            }
            return indvCustomCollection;
        } catch (final Exception fe) {
            throw fe;
        }
    }


    @Cacheable(value = "individuals", key = "appNum")
    public Map getHouseholdIndividuals(final String appNum) {
        try {
            // Update indv map
			final List<INDIVIDUAL_Custom_Cargo> individualCustomCargoArray = getIndivCargoList(appNum);
			if (individualCustomCargoArray != null) {
				for (INDIVIDUAL_Custom_Cargo individual_custom_cargo : individualCustomCargoArray) {
					individualMap.put(individual_custom_cargo.getIndv_seq_num(), individual_custom_cargo);
				}
			}
            // Update dropdown map
            sortIndivAndUpdateDropDown(individualMap);
        } catch (final Exception fe) {
            logger.error(" Loading People Handler Failed ", fe.fillInStackTrace());
        }
        return individualMap;
    }

    /**
     * Sorts Individuals and updates the dropdown map from the IndividualMap
     */
    private void sortIndivAndUpdateDropDown(Map individualMap) {
     try {	
        INDIVIDUAL_Custom_Collection individualCustomCollection = new INDIVIDUAL_Custom_Collection();
        final Iterator iter = individualMap.keySet().iterator();
        while (iter.hasNext()) {
            individualCustomCollection.addCargo((INDIVIDUAL_Custom_Cargo) individualMap.get(iter.next()));
        }


        // update dropdown map
        updateDropDown(individualCustomCollection);
     }catch(Exception e) {
    	 throw e;
     }
    }

    /**
     * Get App Household relationship cargos.
     *
     * @param appNum - Application number picked up based on userId.
     * @return APP_HSHL_RLT_Cargo[] - List of cargos
     */
    private List<APP_HSHL_RLT_Cargo> getAppHouseHoldRelationshipCargos(String appNum) {
        logger.info("PeopleHandler::getAppHouseHoldRelationshipCargos currentThread-" + Thread.currentThread());
        List<CP_APP_HSHL_RLT_Cargo> householdRelationShip = new ArrayList<>();
        Iterator<CP_APP_HSHL_RLT_Cargo> iterator = householdRelationshipRepo.findByAppNum(Integer.parseInt(appNum)).iterator();
        iterator.forEachRemaining(householdRelationShip::add);
        return getAppHouseholdRelationCargos(householdRelationShip);
    }

    private List<APP_INDV_Cargo> getAppIndividualCargo(String appNum) {
        List<APP_INDV_Cargo> app_indv_cargos = new ArrayList<APP_INDV_Cargo>();
        List<APP_INDV_Cargo> cpAppIndvCargos = new ArrayList<>();
        Iterator<APP_INDV_Cargo> iterator = cpAppIndvRepository.findByAppNumAndRlvnIndNot(Integer.parseInt(appNum), Integer.valueOf(2)).iterator();
        iterator.forEachRemaining(cpAppIndvCargos::add);
        return prepareAppIndividualCargos(cpAppIndvCargos);
    }

    private List<APP_INDV_Cargo> prepareAppIndividualCargos(List<APP_INDV_Cargo> cpAppIndvCargos) {
        List<APP_INDV_Cargo> app_indv_cargos = new ArrayList<>();
        cpAppIndvCargos.forEach(cp_app_indv_cargo -> {
            APP_INDV_Cargo app_indv_cargo = new APP_INDV_Cargo();
            app_indv_cargo.setIndv_seq_num(Integer.valueOf(cp_app_indv_cargo.getIndv_seq_num()));

            if (Objects.nonNull(cp_app_indv_cargo.getBrth_dt())) {
                app_indv_cargo.setBrth_dt(Date.valueOf(cp_app_indv_cargo.getBrth_dt().toString()));
            }

            app_indv_cargo.setFst_nam(cp_app_indv_cargo.getFst_nam());
            app_indv_cargo.setLast_nam(cp_app_indv_cargo.getLast_nam());
            app_indv_cargo.setMid_init(cp_app_indv_cargo.getMid_init());

            if (Objects.nonNull(cp_app_indv_cargo.getRlvn_ind())) {
                app_indv_cargo.setRlvn_ind(cp_app_indv_cargo.getRlvn_ind());
            }
            if (Objects.nonNull(cp_app_indv_cargo.getPrim_prsn_sw())) {
                app_indv_cargo.setSex_ind(String.valueOf(cp_app_indv_cargo.getSex_ind()));
            }
            if (Objects.nonNull(cp_app_indv_cargo.getPrim_prsn_sw())) {
                app_indv_cargo.setPrim_prsn_sw(String.valueOf(cp_app_indv_cargo.getPrim_prsn_sw()));
            }

            app_indv_cargo.setLive_arng_typ(cp_app_indv_cargo.getLive_arng_typ());
            app_indv_cargo.setChld_out_home_resp(cp_app_indv_cargo.getChld_out_home_resp());
            app_indv_cargo.setSuffix_name(cp_app_indv_cargo.getSuffix_name());
            app_indv_cargo.setSrc_app_ind(cp_app_indv_cargo.getSrc_app_ind());
            app_indv_cargo.setCitizenVerifyInd(cp_app_indv_cargo.getCitizenVerifyInd());
            app_indv_cargo.setBlnd_dabl_ind(cp_app_indv_cargo.getBlnd_dabl_ind());
            app_indv_cargos.add(app_indv_cargo);
        });
        return app_indv_cargos;
    }


    private String getRelationCDForNonPP(final List<APP_HSHL_RLT_Cargo> appHshlRltCargos, final String aIndvSeqNum, final String aGender) {

        try {
            for (APP_HSHL_RLT_Cargo app_hshl_rlt_cargo : appHshlRltCargos) {
                if (null!=app_hshl_rlt_cargo.getRef_indv_seq_num() && app_hshl_rlt_cargo.getRef_indv_seq_num().toString().trim().equals(aIndvSeqNum)) {
                    if (AppConstants.SEX_IND_MALE.equals(aGender)) {
                        // get reverse relation for the male
                        return iref.getColumnValue("TREL", 69, app_hshl_rlt_cargo.getRlt_cd(),
                                FwConstants.ENGLISH);
                    } else {
                        // get reverse relation for the female
                        return iref.getColumnValue("TREL", 70, app_hshl_rlt_cargo.getRlt_cd(), FwConstants.ENGLISH);
                    }
                } else if (null!=app_hshl_rlt_cargo.getSrc_indv_seq_num() && app_hshl_rlt_cargo.getSrc_indv_seq_num().toString().trim().equals(aIndvSeqNum)) {
                    return app_hshl_rlt_cargo.getRlt_cd();
                }
            }
            return SPACE;

        } catch (final Exception fe) {
            throw fe;
        }
    }

    /**
     * Get App Household cargos.
     *
     * @param householdRelationShip
     * @return
     */
    protected List<APP_HSHL_RLT_Cargo> getAppHouseholdRelationCargos(List<CP_APP_HSHL_RLT_Cargo> householdRelationShip) {
        List<APP_HSHL_RLT_Cargo> app_hshl_rlt_cargos = new ArrayList<>();
        householdRelationShip.forEach(cp_app_hshl_rlt_cargo -> {
            APP_HSHL_RLT_Cargo cargo = new APP_HSHL_RLT_Cargo();
            cargo.setApp_num(cp_app_hshl_rlt_cargo.getApp_num());
            if (Objects.nonNull(cp_app_hshl_rlt_cargo.getChange_dt())) {
                cargo.setChg_dt(cp_app_hshl_rlt_cargo.getChange_dt().toString());
            }
            cargo.setRef_indv_seq_num(cp_app_hshl_rlt_cargo.getRefIndvSeqNum());
            cargo.setRlt_cd(cp_app_hshl_rlt_cargo.getRltCd());
            cargo.setSrc_indv_seq_num(cp_app_hshl_rlt_cargo.getSrcIndvSeqNum());
            app_hshl_rlt_cargos.add(cargo);

        });

        return app_hshl_rlt_cargos;
    }

    public IndividualAge getIndividualAge(Integer indvSeqNumber) {
        IndividualAge indvAge = null;

        indvAge = ((INDIVIDUAL_Custom_Cargo) individualMap.get(indvSeqNumber))
                .getIndv_age();

        return indvAge;
    }

    /**
     * Set Relationship Code
     * @param refSeqNum
     * @param trel
     */
    public void setRelationshipCode(Integer refSeqNum, String trel,String appNum) {
     try {	
        // getting the old data from the Individual Map
        Map individualMap = getHouseholdIndividuals(appNum);
        final INDIVIDUAL_Custom_Cargo indivCustomCargo = (INDIVIDUAL_Custom_Cargo) individualMap.get(refSeqNum);
        // setting the new values
        if(Objects.nonNull(indivCustomCargo)){
            indivCustomCargo.setRlt_cd(trel);
        }
        individualMap.put(refSeqNum, indivCustomCargo);
        sortIndivAndUpdateDropDown(individualMap);
     }catch(Exception e) {
    	 throw e;
     }

    }

    public INDIVIDUAL_Custom_Collection getRelevantIndividuals() {
     try {	
        final INDIVIDUAL_Custom_Collection indvCustomCollection = new INDIVIDUAL_Custom_Collection();
        final Iterator iter = individualMap.keySet().iterator();
        while (iter.hasNext()) {
            final INDIVIDUAL_Custom_Cargo indvCargo = (INDIVIDUAL_Custom_Cargo) individualMap
                    .get(iter.next());
            if (Integer.parseInt(indvCargo.getRlvn_ind()) == 1) {
                indvCustomCollection.add(indvCargo);
            }
        }
        return indvCustomCollection;
     }catch(Exception e) {
    	 throw e;
     }
    }

//TODO: Below blocks will be refactored

    /**
     * @param indvSeqNum
     * @param appNum
     * @return
     */
    public String getFirstName(final String indvSeqNum, String appNum) {
      try {	
        final INDIVIDUAL_Custom_Cargo indivCustomCargo = (INDIVIDUAL_Custom_Cargo) getHouseholdIndividuals(appNum).get(indvSeqNum);
        if (indivCustomCargo == null) return StringUtils.EMPTY;
        else return indivCustomCargo.getFst_nam();
      }catch(Exception e) {
    	  throw e;
      }
    }

    /**
     *
     * @param indvSeqNum
     * @param appNum
     * @return
     */
    public String getLastName(final String indvSeqNum,String appNum) {
        final INDIVIDUAL_Custom_Cargo indivCustomCargo = (INDIVIDUAL_Custom_Cargo) getHouseholdIndividuals(appNum).get(indvSeqNum);
        return indivCustomCargo.getLast_nam();
    }

    /**
     *
     * @param indvSeqNum
     * @param appNum
     * @return
     */
    public String getBirthDt(final String indvSeqNum,String appNum) {
        final INDIVIDUAL_Custom_Cargo indivCustomCargo = (INDIVIDUAL_Custom_Cargo) getHouseholdIndividuals(appNum).get(indvSeqNum);
        return indivCustomCargo.getBrth_dt();
    }

    /**
     * Returns the INDIVIDUAL_Custom_Cargo[] contains individual information for
     * the given APP_NUM PCR # 32248 We modified this method for BC+ get get
     * only the individuals whos out side hope response is not 'Y'
     */
    private List<INDIVIDUAL_Custom_Cargo> getIndivCargoList(String appNum) {
        try {

            List<APP_HSHL_RLT_Cargo> appHouseHoldRelationshipCargos = getAppHouseHoldRelationshipCargos(appNum);
            setDateRoutine(DateRoutine.getInstance());

            List<INDIVIDUAL_Custom_Cargo> individual_custom_cargos = getIndividualCustomCargos(appHouseHoldRelationshipCargos, appNum);

            return individual_custom_cargos;
        } catch (final Exception exception) {
            throw exception;
        }
    }



    //TODO: Will refactor and remove it - temporary
    private java.sql.Date getSqlDate() {
        return new java.sql.Date(new java.util.Date().getTime());
    }

    public DateRoutine getDateRoutine() {
        return dateRoutine;
    }

    public void setDateRoutine(DateRoutine dateRoutine) {
        this.dateRoutine = dateRoutine;
    }

    public void deleteOutOfHomeIndividual(short indvSeqNum) {
    }

    public INDIVIDUAL_Custom_Collection getSortedIndividualsByIndvSeqNum() {
        return null;
    }

    /**
     * Get all individual custom cargos associated with household relationship cargos.
     * @param appHouseHoldRelationshipCargos
     * @return
     */
    private List<INDIVIDUAL_Custom_Cargo> getIndividualCustomCargos(List<APP_HSHL_RLT_Cargo> appHouseHoldRelationshipCargos,String appNum) {
        List<APP_INDV_Cargo> appIndvCargoArray = getAppIndividualCargo(appNum);
        List<INDIVIDUAL_Custom_Cargo> individual_custom_cargos = new ArrayList<>();
        //TODO: Convert to Java8 Streams and populate the below logic.
        for (APP_INDV_Cargo app_indv_cargo:appIndvCargoArray) {
            // PCR # 32248 adding individuals who are not out of home
            // EDSCP CP - Need both in and out of home individuals.
            INDIVIDUAL_Custom_Cargo individual_custom_cargo = new INDIVIDUAL_Custom_Cargo();
            if(Objects.nonNull(app_indv_cargo.getIndv_seq_num())) {
                //casting precision & non precision values to an Integer string to handle Prostgre column types doulbe/float
                String indvSeqNum = Integer.valueOf(Double.valueOf(app_indv_cargo.getIndv_seq_num()).intValue()).toString();
                individual_custom_cargo.setIndv_seq_num(indvSeqNum); }
            if(Objects.nonNull(app_indv_cargo.getBrth_dt())){
                individual_custom_cargo.setBrth_dt(String.valueOf(app_indv_cargo.getBrth_dt()));
            }
            individual_custom_cargo.setFst_nam(app_indv_cargo.getFst_nam().trim());
            individual_custom_cargo.setLast_nam(app_indv_cargo.getLast_nam());
            individual_custom_cargo.setMid_init(app_indv_cargo.getMid_init());
            if(Objects.nonNull(app_indv_cargo.getRlvn_ind())){
                individual_custom_cargo.setRlvn_ind(String.valueOf(app_indv_cargo.getRlvn_ind()));
            }
            individual_custom_cargo.setLive_arng_typ(app_indv_cargo.getLive_arng_typ());
            individual_custom_cargo.setSex_ind(app_indv_cargo.getSex_ind());
            if(Objects.nonNull(app_indv_cargo.getBrth_dt())){
                String brthDate = String.valueOf(app_indv_cargo.getBrth_dt());
                individual_custom_cargo.setIndv_age(getDateRoutine().getAge(getDateRoutine().getDateFromTimeStamp(brthDate), getSqlDate()));
            }
            individual_custom_cargo.setOut_of_home_ind(app_indv_cargo.getChld_out_home_resp());
            individual_custom_cargo.setChld_trb_mbr_resp(app_indv_cargo.getChld_trb_mbr_resp());
            individual_custom_cargo.setTrb_mbr_resp(app_indv_cargo.getTrb_mbr_resp());

            individual_custom_cargo.setSuffix_name(app_indv_cargo.getSuffix_name());
            individual_custom_cargo.setSrc_app_ind(app_indv_cargo.getSrc_app_ind());

            if (!FwConstants.YES.equals(app_indv_cargo.getPrim_prsn_sw())) {
                individual_custom_cargo.setRlt_cd(getRelationCDForNonPP(appHouseHoldRelationshipCargos,individual_custom_cargo.getIndv_seq_num(),individual_custom_cargo.getSex_ind()));
            } else {
                individual_custom_cargo.setRlt_cd(PRIMARY_PERSON);
            }
            if(Objects.nonNull(app_indv_cargo.getIndv_seq_num())){
                individual_custom_cargo.setIndv_pin_num(String.valueOf(app_indv_cargo.getIndv_seq_num()));
            }
            individual_custom_cargo.setDabl_resp(app_indv_cargo.getDisabled_resp());
            // EDSCP CP - Need both in and out of home individuals.
            individual_custom_cargos.add(individual_custom_cargo);
        }
        return individual_custom_cargos;
    }
    //Start:Added as part of CSPM-2627 changes 
    public Integer getAge (Date birthdt) {
    	IndividualAge individualAge=dateRoutine.getAge(birthdt, new java.sql.Date(new java.util.Date().getTime()));
    	return individualAge.getYears(); 	
    }  
  //End:Added as part of CSPM-2627 changes 
}
