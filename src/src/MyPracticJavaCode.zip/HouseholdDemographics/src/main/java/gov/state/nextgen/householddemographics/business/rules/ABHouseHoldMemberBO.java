
package gov.state.nextgen.householddemographics.business.rules;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_IMG_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_ESGIN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO_Collection;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.householddemographics.business.entities.WIC_CLINIC_INFO_Cargo;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CitizenshipRepo;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvAddiInfoRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.WicClinicInfoRepository;

@Service("ABHouseHoldMemberBO")
public class ABHouseHoldMemberBO extends AbstractBO{
	
	@Autowired
	private CpAppIndvRepository cpAppIndvRepository;
	
	@Autowired 
	private CpAppRqstRepository cpAppRqstRepository;
	
	@Autowired
	private CpAppPgmRqstRepository cpAppPgmRqstRepository;
	
	private WicClinicInfoRepository wicClinics;

	protected CitizenshipRepo citizenshipRepo;
	
	@Autowired
	private CpAppIndvAddiInfoRepository cpAppIndvAddiInfoRepository;

	private static Logger logger = LoggerFactory.getLogger(ABHouseHoldMemberBO.class);
	
	/** The Constant INDV_SEQ_NUM. */
	private static final String INDV_SEQ_NUM = "indv_seq_num";
	
	/** The Constant HSHL_INDV_CT. */
	private static final String HSHL_INDV_CT = "hshl_indv_ct";

	private static final Object CHLD_OUT_HOME_CT = "chld_out_home_ct";
	
	DateFormat utilDateFormatter = new SimpleDateFormat("dd-MM-yyyy");
	
	public java.util.Date sqlDateToutilDate(final java.sql.Date sDate)
			throws ParseException {
		return utilDateFormatter.parse(utilDateFormatter.format(sDate));
	}
	
	public APP_INDV_Collection loadAppIndvCollection(String appNum) {
		return cpAppIndvRepository.loadAppIndvData(Integer.parseInt(appNum));
	}

	public FwMessageList validateImmigrationDetails(APP_INDV_Collection appIndvColl, Integer[] pgmKey,
			 boolean indvFMAFlag, boolean indvFSFlag, boolean indvTANFFlag, boolean indvCClag) {
		 final long startTime = System.currentTimeMillis();
	     FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABHouseHoldMemberBO.validateImmigrationDetails() - START");

	     final char[] specialChars = { '.', '-', '\'', ' ', ',','&','/','#' };
	     StringBuilder oneHundred20yearsAgo = null;
	     final Calendar now = Calendar.getInstance();
	     final int thisYear = now.get(Calendar.YEAR);
	     oneHundred20yearsAgo = new StringBuilder(String.valueOf(thisYear - 120));
	     oneHundred20yearsAgo = oneHundred20yearsAgo.append("-01-01");
	     try{
	    	FwMessageList messageList = new FwMessageList();
	    	APP_INDV_Cargo appIndvCargo = null;
			boolean maFlag = false;
			boolean tanfFlag = false;
			boolean snapFlag = false;
				
			if (pgmKey[0] == 1) {
				maFlag = true;
			}
			if (pgmKey[9] == 1) {
				tanfFlag = true;
			}
			if (pgmKey[2] == 1) {
				snapFlag = true;
			}
			if (appIndvColl != null && !appIndvColl.isEmpty()) {
				for (int i = 0; i < appIndvColl.size(); i++) {
					appIndvCargo = (APP_INDV_Cargo) appIndvColl.get(i);
					final Date dob = getDateOfBirth(appIndvCargo.getApp_num(), appIndvCargo.getIndv_seq_num());
					validateProgFlag(indvFMAFlag, indvFSFlag, indvTANFFlag, indvCClag, specialChars,
							oneHundred20yearsAgo, messageList, appIndvCargo, maFlag, tanfFlag, snapFlag, dob);
					if ((indvFMAFlag)
							&& appMgr
									.isFieldEmpty(appIndvCargo.getVld_immgrtn_sts()) && !appMgr.isFieldEmpty(appIndvCargo.getUs_ctzn_sw())
									&& FwConstants.NO.equals(appIndvCargo
											.getUs_ctzn_sw())) {
						messageList.addMessageToList(addMessageCode("99361"));
					}
				
					//validateWicClnc
					validateWicClncCity(messageList, appIndvCargo);
					
				}
			}
				
	    	 
	    	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABHouseHoldMemberBO.validateImmigrationDetails() - END , Time Taken : "
	                   + (System.currentTimeMillis() - startTime)
	                    + " milliseconds");
	        return messageList;
	      }catch(FwException fe){
	           FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
	            throw fe;
	      }catch(Exception e) {
	    	  throw e;
	      }
	}

	private void validateWicClncCity(FwMessageList messageList, APP_INDV_Cargo appIndvCargo) {
		if (!appMgr.isFieldEmpty(appIndvCargo.getWic_clnc_cnty())
				&& !"000".equalsIgnoreCase(appIndvCargo.getWic_clnc_cnty())
				) {
			if(!appMgr.isFieldEmpty(appIndvCargo.getWic_clnc_cd())
					&& AppConstants.SEL.equalsIgnoreCase(appIndvCargo.getWic_clnc_cd())){
				messageList.addMessageToList(addMessageCode("99407"));
			}
		}
	}

	@SuppressWarnings("squid:S107")
	private void validateProgFlag(boolean indvFMAFlag, boolean indvFSFlag, boolean indvTANFFlag, boolean indvCClag,
			final char[] specialChars, StringBuilder oneHundred20yearsAgo, FwMessageList messageList,
			APP_INDV_Cargo appIndvCargo, boolean maFlag, boolean tanfFlag, boolean snapFlag, final Date dob) {
		if ((indvFMAFlag ||indvFSFlag||indvTANFFlag||indvCClag)
				&& appMgr
						.isFieldEmpty(appIndvCargo.getUs_ctzn_sw())) {
			messageList.addMessageToList(addMessageCode("00062"));
		}
		if (tanfFlag || snapFlag || maFlag) {
			if (!appMgr.isFieldEmpty(appIndvCargo.getUs_ctzn_sw())
					&& FwConstants.YES.equals(appIndvCargo
							.getUs_ctzn_sw())) {
				validateUsCtzn(messageList, appIndvCargo);	
			}
			
			if (!appMgr.isFieldEmpty(appIndvCargo.getUs_ctzn_sw())
					&& FwConstants.NO.equals(appIndvCargo
							.getUs_ctzn_sw())
					&& !(appIndvCargo.getEntry_into_us_dt() == null)) {
				validateNotUsCtzn(specialChars, oneHundred20yearsAgo, messageList, appIndvCargo, dob);
				
			}
			
		}
	}

	private void validateNotUsCtzn(final char[] specialChars, StringBuilder oneHundred20yearsAgo,
			FwMessageList messageList, APP_INDV_Cargo appIndvCargo, final Date dob) {
		if (!appMgr.validateDate(appIndvCargo
				.getEntry_into_us_dt())) {
			messageList.addMessageToList(addMessageCode("00635"));

		} else if (dob != null
				&& appMgr.isDateBeforeDate(
						appIndvCargo.getEntry_into_us_dt().toString(),
						java.sql.Date.valueOf((dob.toString()).substring(0, 10)))) {
			messageList.addMessageToList(addMessageCode("80000"));

		} else if (dob != null
				&& appMgr.isDateBeforeDate(appIndvCargo
						.getEntry_into_us_dt().toString(), java.sql.Date
						.valueOf(oneHundred20yearsAgo
								.toString()))) {
			messageList.addMessageToList(addMessageCode("00634"));

		} else if (!appMgr.futureDate(appIndvCargo
				.getEntry_into_us_dt().toString())) {
			messageList.addMessageToList(addMessageCode("00633"));
		}
		// Non Citizen Alien Alien Registration Number
		// Validations
		if (!(null != appIndvCargo.getAlien_status_cd() && AppConstants.UNDOCUMENTED_ALIEN
				.equalsIgnoreCase(appIndvCargo
						.getAlien_status_cd()))
						&& null != appIndvCargo.getAlien_num()
						&& (appIndvCargo.getAlien_num().length() != 9 || !appIndvCargo
						.getAlien_num().matches("[0-9]+"))) {
			messageList.addMessageToList(addMessageCode("00638"));
		}
		if (!(null != appIndvCargo.getAlien_status_cd() && AppConstants.UNDOCUMENTED_ALIEN
				.equalsIgnoreCase(appIndvCargo
						.getAlien_status_cd()))
						&& null != appIndvCargo.getAlien_num()
						&& (!appMgr.isInteger(appIndvCargo
						.getAlien_num()) || !appMgr								
								.isAlphaNumeric(appIndvCargo
										.getAlien_num())) && (!appMgr.isSpecialAlpha(appIndvCargo.getAlien_num(),specialChars))) {
			messageList.addMessageToList(addMessageCode("80600"));
		}
	}

	private void validateUsCtzn(FwMessageList messageList, APP_INDV_Cargo appIndvCargo) {
		if (!appMgr.isFieldEmpty(appIndvCargo
				.getAlien_status_cd())
				&& !"000".equals(appIndvCargo
						.getAlien_status_cd())) {
			messageList.addMessageToList(addMessageCode("80090"));
		}
		
		if (appIndvCargo.getEntry_into_us_dt() != null) {
			messageList.addMessageToList(addMessageCode("80100"));
		}
		if (!appMgr.isFieldEmpty(appIndvCargo
				.getAlien_doc_cd())
				&& !"000".equals(appIndvCargo
						.getAlien_doc_cd())) {
			messageList.addMessageToList(addMessageCode("80140"));
		}
		if (!appMgr.isFieldEmpty(appIndvCargo
				.getAlien_num())
				&& (!FwConstants.EMPTY_STRING
						.equals(appIndvCargo.getAlien_num())
						|| !FwConstants.SPACE
								.equals(appIndvCargo
								.getAlien_num()) || appIndvCargo
								.getAlien_num() != null && !"0".equals(appIndvCargo
								.getAlien_num().trim()))) {
			messageList.addMessageToList(addMessageCode("80170"));
		}
	}
	/**
     * Queries the database for this household member indicated by
     * <code>appNumber</code> and <code>indvSeqNumber</code> and retrieves the
     * date of birth entered for this person.
     *
     * @param appNumber
     * @param indvSeqNumber
     * @return dateOfBirth
     */
    public java.sql.Date getDateOfBirth(final String appNumber,
                                         final Integer indvSeqNumber) {
        final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABHouseHoldMemberBO.getDateOfBirth) - START");
        try {
        	java.sql.Date dateOfBirth = null;
        	if(appNumber != null && indvSeqNumber != null) {
        		dateOfBirth = cpAppIndvRepository.getByAppNum(Integer.parseInt(appNumber), indvSeqNumber);
        	}

        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABHouseHoldMemberBO.getDateOfBirth - END , Time Taken : "
                + (System.currentTimeMillis() - startTime) + " milliseconds");

        	return dateOfBirth;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(getClass().getName(),
                    "getDateOfBirth", e);
        }
    }
    /**
     * store data in table
     * 
     * @param appInImmCargo
     */
	public void storeImmigrationDetail(APP_INDV_Cargo appInImmCargo) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABHouseHoldMemberBO.storeImmigrationDetail() - START");
        try {
            if (null !=appInImmCargo) {
            	 //set update date
    			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
    			appInImmCargo.setUpdate_dt(currentTimeStamp);
                cpAppIndvRepository.save(appInImmCargo);
            }
        } catch (final Exception e) {
        	FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABHouseHoldMemberBO.storeImmigrationDetail() - END , Time Taken :" + (System.currentTimeMillis() - startTime) + " milliseconds");
	}
	
	/**
     * store data in table
     * 
     * @param appInImmCargo
     */
	public void removeImmigrationInfo(APP_INDV_Cargo appInImmCargo) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABHouseHoldMemberBO.removeImmigrationInfo() - START");
        try {
            if (null !=appInImmCargo) {
                cpAppIndvRepository.delete(appInImmCargo);
            }
        } catch (final Exception e) {
        	FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw createFwException(this.getClass().getName(), "storeImmigrationDetail", e);
        }
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABHouseHoldMemberBO.removeImmigrationInfo() - END , Time Taken :" + (System.currentTimeMillis() - startTime) + " milliseconds");
	}
	/**
	 * Find all people.
	 *
	 * @param peopleHandler
	 *            the people handler
	 * @return the list
	 */
	public List findAllPeople(final PeopleHandler peopleHandler) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABHouseHoldMemberBO.findAllPeople() - START");
		List individualsList = null;
		INDIVIDUAL_Custom_Collection relColl = peopleHandler
				.getRelevantIndividuals();
		relColl = peopleHandler.sortIndividuals(relColl);
		INDIVIDUAL_Custom_Cargo relCargo = null;
		final int relCollSize = relColl.size();
		try {
			for (int i = 0; i < relCollSize; i++) {
				relCargo = relColl.getResult(i);
				if (individualsList == null) {
					individualsList = new ArrayList();
				}
				individualsList.add(relCargo.getIndv_seq_num());

			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, 
					"ABHouseHoldMemberBO.findAllPeople() - END , Time Taken :" + (System.currentTimeMillis() - startTime) + " milliseconds");
			return individualsList;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}

	public List loadWICClncInfo() {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABHouseHoldMemberBO.loadWICClncInfo() - START");
		try {
			List result = wicClinics.loadWICClncInformation();
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, 
					"ABHouseHoldMemberBO.loadWICClncInfo() - END , Time Taken :" + (System.currentTimeMillis() - startTime) + " milliseconds");
			return result;
		}catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}

	public String loadWICClncName(String wic_clnc_cd) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABHouseHoldMemberBO.loadWICClncName() - START");
		try {
			String  wicClncName = "";
			WIC_CLINIC_INFO_Cargo cargo = wicClinics.loadWICClncName(wic_clnc_cd);
			if(cargo != null) {
				wicClncName = cargo.getClinic_name();
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, 
					"ABHouseHoldMemberBO.loadWICClncName() - END , Time Taken :" + (System.currentTimeMillis() - startTime) + " milliseconds");
			return wicClncName;
		}catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}

	public int loadMaxSeqNum(String appNumber) {
		
		System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.getHouseholdMemberDetail() - START");
		
		int maxSeqNum = 0;
		try {
			final int res = cpAppIndvRepository.getByAppNumMax(Integer.parseInt(appNumber));
			maxSeqNum = res;
			return maxSeqNum;
		}catch (final Exception e) {
			throw createFwException(getClass().getName(),
					"loadMaxSeqNum", e);
		}

	}

	public APP_INDV_Collection loadHouseholdMemberDetail(String appNumber, int indvSeqNumber) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - START");

		APP_INDV_Collection appIndvColl = new APP_INDV_Collection();
		
		try {
			// here i am getting the individual information

			final APP_INDV_Cargo[] appIndvCargoArray = cpAppIndvRepository.findByAppNumIndvSeqNumArray(Integer.parseInt(appNumber), Integer.valueOf(indvSeqNumber));
	
			if (appIndvCargoArray.length > 0) {
				appIndvColl.setResults(appIndvCargoArray);
				// now we need to padding the number
				final APP_INDV_Cargo appIndvCargo = appIndvColl.getCargo(0);
				if (null != appIndvCargo.getSsn_num() && (!"0".equals(appIndvCargo.getSsn_num()))) {
					appIndvCargo.setSsn_num(paddingNumbers(
							appIndvCargo.getSsn_num(), 9));
				}

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - END , Time Taken : "
								+ (System.currentTimeMillis() - startTime)
								+ " milliseconds");

				return appIndvColl;
			}
			return null;
		} catch (final Exception e) {
			throw createFwException(getClass().getName(),
					"loadHouseholdMemberDetail", e);
		}
	}

	private String paddingNumbers(String number, int length) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - START");

		final int caseLength = number.length();
		StringBuilder paddedCase = null;
		// Zero pading(Leading)
		if (caseLength < length) {
			paddedCase = new StringBuilder();
			for (int m = 0; m < length - caseLength; m++) {
				paddedCase.append("0");
			}
			number = paddedCase.append(number).toString();
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		return number;
	}

	public int loadHouseholdCount(String appNumber) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - START");

		int peopleCount = 0;
		try {
			// then we are loading people from the prg rqst
			
			final List res = cpAppRqstRepository.findHshlIndvCnt(Integer.parseInt(appNumber));
			if (null!=res && !res.isEmpty()) {
				final Map temp = (Map) res.get(0);
				peopleCount = Integer.parseInt((String) temp.get(HSHL_INDV_CT));
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");
			return peopleCount;
		} catch (final FwException fe) {
			throw fe;
		} 
	}

	public int loadChildOutOfHomeCount(String appNumber) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - START");

		int childCount = 0;
		try {
			// then we are loading people from the prg rqst
			
			final List res = cpAppRqstRepository.findChildOHCnt(Integer.parseInt(appNumber));
			if (null!=res && !res.isEmpty()) {
				final Map temp = (Map) res.get(0);
				childCount = Integer.parseInt((String) temp
						.get(CHLD_OUT_HOME_CT));
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");

			return childCount;
		} catch (final Exception e) {
			throw createFwException(getClass().getName(),
					"loadChildOutOfHomeCount", e);
		}
	}

	public FwMessageList validateHouseholdMemberDetail(APP_INDV_Cargo appIndvCargo, String childOutofYourhome,
			int currentPageStatus, Integer indvSeqNumber, APP_INDV_Collection appIndvBeforeColl, 
			boolean ccFlag, boolean eaFlag, boolean validatePOBFlag, boolean ccFlagOnly, boolean wicFlag,
			boolean maFlag) throws ParseException {
		// EDSP CP commented
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - START");
		final char[] specialChars = {'-', ' '};

		try {
			
			FwMessageList  messageList= new FwMessageList();
			int peopleCount = 0;

			
			
			
			/* Validation the fields, First Name & Last Name */
			validateEmpName(appIndvCargo, specialChars, messageList);

			validateEmpOtherDet(appIndvCargo, messageList);

			if (HouseHoldDemoGraphicsConstants.ONE == (indvSeqNumber)) {

				if (appMgr.isFieldEmpty(appIndvCargo.getLang_cd())
						|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appIndvCargo
								.getLang_cd())) {
					final Object[] error = new Object[] { new FwMessageTextLabel(
							"30510") };
					messageList.addMessageToList(addMessageWithFieldValues("10059", error));
				}

				if ("1002".equals(appIndvCargo.getLang_cd())
						&& appMgr.isFieldEmpty(appIndvCargo.getLang_oth_dsc())) {
					messageList.addMessageToList(addMessageCode("70003"));
				}

				if ((appIndvCargo.getLang_cd() != null)
						&& !"1002".equals(appIndvCargo.getLang_cd())
						&& !appMgr.isFieldEmpty(appIndvCargo.getLang_oth_dsc())) {
					messageList.addMessageToList(addMessageCode("70004"));
				}

				if ((appMgr.isFieldEmpty(appIndvCargo.getComm_asst_none_ind()) || "0"
						.equals(appIndvCargo.getComm_asst_none_ind()))
						&& !appMgr
								.isFieldEmpty(appIndvCargo.getInter_oth_dsc())) {
					messageList.addMessageToList(addMessageCode("70012"));
				}
				if (!appMgr.isFieldEmpty(appIndvCargo.getComm_asst_none_ind())
						&& HouseHoldDemoGraphicsConstants.ONE_STRING.equals(appIndvCargo.getComm_asst_none_ind())
						&& appMgr.isFieldEmpty(appIndvCargo.getInter_oth_dsc())) {
					messageList.addMessageToList(addMessageCode("70011"));
				}

			}
			if ("000".equals(appIndvCargo.getLiving_arrangement_cd())) {
				messageList.addMessageToList(addMessageCode("00060"));
			} else {

				if ("HO".equals(appIndvCargo.getLiving_arrangement_cd())
						&& null != appIndvCargo.getIf_out_arrangement() && !FwConstants.SPACE.contentEquals(appIndvCargo.getIf_out_arrangement()) && !FwConstants.DEFAULT_DROPDOWN_SEL
								.equals(appIndvCargo.getIf_out_arrangement())) {
					messageList.addMessageToList(addMessageCode("70009"));
				}
				if (!"HO".equals(appIndvCargo.getLiving_arrangement_cd())
						&& !"000".equals(appIndvCargo
								.getLiving_arrangement_cd())
						&& FwConstants.DEFAULT_DROPDOWN_SEL.equals(appIndvCargo
								.getIf_out_arrangement())) {
					messageList.addMessageToList(addMessageCode("70005"));
				}
			}
			if (AppConstants.YES.equals(appIndvCargo.getTax_joint_file_ind())
					&& AppConstants.YES.equals(appIndvCargo
							.getTax_dp_outside_home_ind())) {
				messageList.addMessageToList(addMessageCode("70043"));
			}
			if (maFlag) {
				if (appMgr.isFieldEmpty(appIndvCargo
								.getTax_joint_file_ind())) {
					final Object[] error = new Object[] { appIndvCargo.getFst_nam() };
					messageList.addMessageToList(addMessageWithFieldValues("70006", error));
				}

				if (appMgr.isFieldEmpty(appIndvCargo
								.getTax_dp_outside_home_ind())) {
					messageList.addMessageToList(addMessageCode("70007"));
				}
			}

			/* Validating Alternative Name Information section contents */
			if (!appMgr.isFieldEmpty(appIndvCargo.getSsn_num())) {
				String ssnNumber = appIndvCargo.getSsn_num();
				ssnNumber = ssnNumber.trim();
				if (!appMgr.isInteger(ssnNumber)) {
					messageList.addMessageToList(addMessageCode("10294"));
				} else if (appIndvCargo.getSsn_num().charAt(0) == '9') {
					final Object[] error = new Object[] { new FwMessageTextLabel(
							"30023") };
					messageList.addMessageToList(addMessageWithFieldValues("10294", error));
				} else if ("666".equals(appIndvCargo.getSsn_num().substring(0,
						3)) ) {
					messageList.addMessageToList(addMessageCode("10294"));
				}

			}
			if (!appMgr.isFieldEmpty(appIndvCargo.getAlias_ind())
					&& FwConstants.YES.equals(appIndvCargo.getAlias_ind())) {

				if (appMgr.isFieldEmpty(appIndvCargo.getAlias_fst_nam())) {
					messageList.addMessageToList(addMessageCode("80512"));
				}

				if (appMgr.isFieldEmpty(appIndvCargo.getAlias_last_nam())) {

					messageList.addMessageToList(addMessageCode("80513"));
				}

				if (!appMgr.isFieldEmpty(appIndvCargo.getAlias_fst_nam())
						&& (!appMgr.isInvalidFirstChar(appIndvCargo
								.getAlias_fst_nam()) || !appMgr.isSpecialAlpha(
								appIndvCargo.getAlias_fst_nam(), specialChars))) {

					messageList.addMessageToList(addMessageCode("80500"));

				}

				if (!appMgr.isFieldEmpty(appIndvCargo.getAlias_mid_init())
						&& !appMgr.isAlpha(appIndvCargo.getAlias_mid_init())) {

					messageList.addMessageToList(addMessageCode("80540"));
				}

				if (!appMgr.isFieldEmpty(appIndvCargo.getAlias_last_nam())
						&& (!appMgr.isInvalidFirstChar(appIndvCargo
								.getAlias_last_nam()) || !appMgr
								.isSpecialAlpha(
										appIndvCargo.getAlias_last_nam(),
										specialChars))) {

					messageList.addMessageToList(addMessageCode("80505"));
				}
			}
			/*
			 * Validation for entering First/Last Name/Middle Initial but not
			 * answering Yes/No for alias name
			 */
			if (appMgr.isFieldEmpty(appIndvCargo.getAlias_ind())) {
				if (!appMgr.isFieldEmpty(appIndvCargo.getAlias_fst_nam())
						|| !appMgr.isFieldEmpty(appIndvCargo
								.getAlias_last_nam())) {
					messageList.addMessageToList(addMessageCode("80509"));
				}
				if (!appMgr.isFieldEmpty(appIndvCargo.getAlias_mid_init())
						&& appMgr.isFieldEmpty(appIndvCargo.getAlias_fst_nam())
						&& appMgr
								.isFieldEmpty(appIndvCargo.getAlias_last_nam())) {

					messageList.addMessageToList(addMessageCode("80509"));

					if (!appMgr.isAlpha(appIndvCargo.getAlias_mid_init())) {
						messageList.addMessageToList(addMessageCode("80540"));
					}

				}

			}

			if (!appMgr.isFieldEmpty(appIndvCargo.getAlias_ind())
					&& FwConstants.YES.equals(appIndvCargo.getAlias_ind())
					&& !appMgr.isFieldEmpty(appIndvCargo.getAlias_mid_init())
					&& !appMgr.isAlpha(appIndvCargo.getAlias_mid_init())) {
				messageList.addMessageToList(addMessageCode("80540"));
			}

			if (!appMgr.isFieldEmpty(appIndvCargo.getAlias_ind())
					&& FwConstants.NO.equals(appIndvCargo.getAlias_ind())
					&& (!appMgr.isFieldEmpty(appIndvCargo.getAlias_fst_nam())
							|| !appMgr.isFieldEmpty(appIndvCargo
									.getAlias_mid_init()) || !appMgr
								.isFieldEmpty(appIndvCargo.getAlias_last_nam()))
					&& (!appMgr.isFieldEmpty(appIndvCargo.getAlias_fst_nam())
							|| !appMgr.isFieldEmpty(appIndvCargo
									.getAlias_mid_init())
							|| !appMgr.isFieldEmpty(appIndvCargo
									.getAlias_last_nam()) || !appMgr
								.isFieldEmpty(appIndvCargo
										.getAlias_suffix_name()))) {

				messageList.addMessageToList(addMessageCode("70008"));
			}
			if (null != (appIndvCargo.getSs_num_app_dt())
					&& !appMgr.validateDate(appIndvCargo.getSs_num_app_dt())) {

				messageList.addMessageToList(addMessageCode("00307"));
			}
		

			if (appIndvCargo.getSsn_info_ack_ind() == null
					|| "0".equals(appIndvCargo.getSsn_info_ack_ind())) {
				messageList.addMessageToList(addMessageCode("00057"));
			}

			if (appMgr.isFieldEmpty(appIndvCargo.getSsn_num()) 
					&& appMgr.isFieldEmpty(appIndvCargo.getSs_num_app_dt().toString())) {
				messageList.addMessageToList(addMessageCode("99001"));
			}
			
			if(null != appIndvCargo.getRace_memb_fed_rec_trb_ind() 
					&& (FwConstants.YES).equals(appIndvCargo.getRace_memb_fed_rec_trb_ind())) {
				if(appMgr.isFieldEmpty(appIndvCargo.getTribe_name())) {
					messageList.addMessageToList(addMessageCode("00059"));
				} else {
					if(!appMgr.isSpecialAlpha(appIndvCargo.getTribe_name(),specialChars)){
						messageList.addMessageToList(addMessageCode("10512"));
					}
				}
			}

			if(null != appIndvCargo.getSs_num_app_dt() ) {
			if (!appMgr.isFieldEmpty(appIndvCargo.getSs_num_app_dt().toString())
					&& !appMgr.futureDate(appIndvCargo.getSs_num_app_dt())) {
				messageList.addMessageToList(addMessageCode("99273"));
			}
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");
			return messageList;

		} catch (final FwException fe) {
			throw fe;
		} 
	}

	private void validateEmpOtherDet(APP_INDV_Cargo appIndvCargo, FwMessageList messageList) throws ParseException {
		if (appMgr.isFieldEmpty(appIndvCargo.getSex_ind())) {

			messageList.addMessageToList(addMessageCode("10225"));
		}
		if (appMgr.isFieldEmpty(appIndvCargo.getBrth_dt().toString())) {
			final Object[] error = new Object[] { new FwMessageTextLabel(
					"30020") };
			messageList.addMessageToList(addMessageWithFieldValues("20006", error));
		} else if (!appMgr.validateDate(appIndvCargo.getBrth_dt())) {

			messageList.addMessageToList(addMessageCode("40017"));
		} else if (!appMgr.futureDate(appIndvCargo.getBrth_dt())) {

			messageList.addMessageToList(addMessageCode("10252"));
		} else if (!appMgr.isFieldEmpty(appIndvCargo.getBrth_dt().toString())) {

			final Calendar cal = Calendar.getInstance();
			final int month = cal.get(Calendar.MONTH) + 1;
			final int year = cal.get(Calendar.YEAR);
			final int day = cal.get(Calendar.DAY_OF_MONTH);
			final String before120Years = FwConstants.EMPTY_STRING
					+ (year - 120) + "-" + month + "-" + day;
			final java.util.Date utilDate = sqlDateToutilDate(fwDate.getDate(before120Years));
			if (appMgr
					.isDateBeforeDate(appIndvCargo.getBrth_dt(), utilDate)) {
				messageList.addMessageToList(addMessageCode("10251"));
			}
		}
	}

	private void validateEmpName(APP_INDV_Cargo appIndvCargo, final char[] specialChars, FwMessageList messageList) {
		if (appMgr.isFieldEmpty(appIndvCargo.getFst_nam())) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_79000));
		}

		if (appMgr.isFieldEmpty(appIndvCargo.getLast_nam())) {
			messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_79001));
		}

		// EDSP CP starts: uncommented
		if (!appMgr.isFieldEmpty(appIndvCargo.getFst_nam())
				&& (!appMgr.isInvalidFirstChar(appIndvCargo.getFst_nam()) || !appMgr
						.isSpecialAlpha(appIndvCargo.getFst_nam(),
								specialChars))) {
			final Object[] error = new Object[] { new FwMessageTextLabel(
					"3018181") };
			messageList.addMessageToList(addMessageWithFieldValues("10239",error));

		}
		if (!appMgr.isFieldEmpty(appIndvCargo.getMid_init())
				&& !appMgr.isAlpha(appIndvCargo.getMid_init())) {

			messageList.addMessageToList(addMessageCode("10240"));
		}

		if (!appMgr.isFieldEmpty(appIndvCargo.getLast_nam())
				&& (!appMgr.isInvalidFirstChar(appIndvCargo.getLast_nam()) || !appMgr
						.isSpecialAlpha(appIndvCargo.getLast_nam(),
								specialChars))) {

			messageList.addMessageToList(addMessageCode("98001"));
		}
	}

	public FwMessageList validateProgramsForIndividuals(APP_IN_PRFL_Collection tempAppInPrflSessionColl,
			Integer[] programKeyArray) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - START");
		boolean snapFlag = false;
		boolean tanfFlag = false;
		boolean maFlag = false;
		boolean ccFlag = false;
		boolean wicFlag = false;
		
		try {
			
			FwMessageList  messageList= new FwMessageList();

			validateFMAIndex(tempAppInPrflSessionColl, programKeyArray, maFlag, messageList);

			validateTanfIndex(tempAppInPrflSessionColl, programKeyArray, tanfFlag, messageList);
			validateFSIndex(tempAppInPrflSessionColl, programKeyArray, snapFlag, messageList);
			validaetCCINdex(tempAppInPrflSessionColl, programKeyArray, ccFlag, messageList);
			if (isThisProgramRequested(programKeyArray,
					FwConstants.WIC_INDEX)) {
				for (int i = 0; i < tempAppInPrflSessionColl.size(); i++) {
					final APP_IN_PRFL_Cargo tempCargo = (APP_IN_PRFL_Cargo) tempAppInPrflSessionColl
							.get(i);
					if (HouseHoldDemoGraphicsConstants.ONE
							==(tempCargo.getIndv_wic_rqst_ind())) {
						wicFlag = true;
						break;
					}
				}
				if (!wicFlag) {
					messageList.addMessageToList(addMessageCode("MSG_70002"));
				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABHouseHoldMemberBO.storeHouseholdMemberDetail() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");

			return messageList;
		} catch (final Exception fe) {
			throw fe;
		} 
	}

	private void validaetCCINdex(APP_IN_PRFL_Collection tempAppInPrflSessionColl, Integer[] programKeyArray,
			boolean ccFlag, FwMessageList messageList) {
		if (isThisProgramRequested(programKeyArray,
				FwConstants.CC_INDEX)) {
			for (int i = 0; i < tempAppInPrflSessionColl.size(); i++) {
				final APP_IN_PRFL_Cargo tempCargo = (APP_IN_PRFL_Cargo) tempAppInPrflSessionColl
						.get(i);
				if (HouseHoldDemoGraphicsConstants.ONE
						==(tempCargo.getIndv_cc_rqst_ind())) {
					ccFlag = true;
					break;
				}
			}
			if (!ccFlag) {
				messageList.addMessageToList(addMessageCode("MSG_90946"));
			}
		}
	 
	}

	private void validateFSIndex(APP_IN_PRFL_Collection tempAppInPrflSessionColl, Integer[] programKeyArray,
			boolean snapFlag, FwMessageList messageList) {
		if (isThisProgramRequested(programKeyArray,
				FwConstants.FS_INDEX)) {
			for (int i = 0; i < tempAppInPrflSessionColl.size(); i++) {
				final APP_IN_PRFL_Cargo tempCargo = (APP_IN_PRFL_Cargo) tempAppInPrflSessionColl
						.get(i);
				if (HouseHoldDemoGraphicsConstants.ONE
						==(tempCargo.getIndv_fs_rqst_ind())) {
					snapFlag = true;
					break;
				}
			}
			if (!snapFlag) {
				messageList.addMessageToList(addMessageCode("MSG_10297"));
			}
		}
	 
	}

	private void validateTanfIndex(APP_IN_PRFL_Collection tempAppInPrflSessionColl, Integer[] programKeyArray,
			boolean tanfFlag, FwMessageList messageList) {
		if (isThisProgramRequested(programKeyArray,
				FwConstants.TANF_INDEX)) {
			for (int i = 0; i < tempAppInPrflSessionColl.size(); i++) {
				final APP_IN_PRFL_Cargo tempCargo = (APP_IN_PRFL_Cargo) tempAppInPrflSessionColl
						.get(i);
				if (HouseHoldDemoGraphicsConstants.ONE
						== (tempCargo
						.getIndv_tanf_rqst_ind())) {
					tanfFlag = true;
					break;
				}
			}
			if (!tanfFlag) {
				messageList.addMessageToList(addMessageCode("MSG_10298"));
			}
		}
		
	}

	private void validateFMAIndex(APP_IN_PRFL_Collection tempAppInPrflSessionColl, Integer[] programKeyArray,
			boolean maFlag, FwMessageList messageList) {
	 try {	
		if (isThisProgramRequested(programKeyArray,
				FwConstants.FMA_INDEX)) {
			for (int i = 0; i < tempAppInPrflSessionColl.size(); i++) {
				final APP_IN_PRFL_Cargo tempCargo = (APP_IN_PRFL_Cargo) tempAppInPrflSessionColl
						.get(i);
				if (HouseHoldDemoGraphicsConstants.ONE
						== (tempCargo.getIndv_fma_rqst_ind())) {
					maFlag = true;
					break;
				}
			}
			if (!maFlag) {

				messageList.addMessageToList(addMessageCode("MSG_98011"));
			}
		}
	 }catch(Exception e) {
		 throw e;
	 }
	}
	
	
	private boolean isThisProgramRequested(Integer[] prgKey, short progInd) {
	 try {	
		boolean programRequested = false;
		if (prgKey[progInd] == 1) {
			programRequested = true;
		}
		return programRequested;
	 }catch(Exception e) {
		 throw e;
	 }
	}


	public APP_PGM_RQST_Collection loadProgramDetail(String appNum) {
		
		APP_PGM_RQST_Collection appPgmRqstColl = cpAppPgmRqstRepository.getDetails(Integer.parseInt(appNum));
		
		
		return appPgmRqstColl;
		}

	public Integer[] getProgKeyArray(String appNumber) {
	 try {	
	Integer[] programKeyArray = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
	
	APP_PGM_RQST_Cargo appPgmRqstCargo = cpAppPgmRqstRepository.getCargoByAppNum(Integer.parseInt(appNumber));
	
	/**
	 * When program codes are absent for a given appNumber
	 * SAFETY NULL check 
	 */
	if(Objects.nonNull(appPgmRqstCargo)) {
		programKeyArray[0] = appPgmRqstCargo.getFma_rqst_ind() != null ? appPgmRqstCargo.getFma_rqst_ind():0;
		programKeyArray[1] = appPgmRqstCargo.getFpw_rqst_ind() != null? appPgmRqstCargo.getFpw_rqst_ind():0;
		programKeyArray[2] = appPgmRqstCargo.getFs_rqst_ind() != null? appPgmRqstCargo.getFs_rqst_ind():0;
		programKeyArray[3] = (Integer) 0;
		programKeyArray[4] = appPgmRqstCargo.getEbd_rqst_ind() != null? appPgmRqstCargo.getEbd_rqst_ind():0;
		programKeyArray[5] = appPgmRqstCargo.getSer_rqst_ind() != null? appPgmRqstCargo.getSer_rqst_ind():0;
		programKeyArray[6] = (Integer) 0;
		programKeyArray[7] = (Integer) 0;
		programKeyArray[8] = appPgmRqstCargo.getCc_rqst_ind() != null? appPgmRqstCargo.getCc_rqst_ind():0;
		validateProgKey(programKeyArray, appPgmRqstCargo);
	}

	return programKeyArray;
	 }catch(Exception e) {
		 throw e;
	 }
	}

	private void validateProgKey(Integer[] programKeyArray, APP_PGM_RQST_Cargo appPgmRqstCargo) {
		programKeyArray[9] = appPgmRqstCargo.getTanf_rqst_ind() != null? appPgmRqstCargo.getTanf_rqst_ind():0;
		programKeyArray[10] = appPgmRqstCargo.getCooling_assistance_rqst_ind() != null? appPgmRqstCargo.getCooling_assistance_rqst_ind():0;
		programKeyArray[11] = appPgmRqstCargo.getCrisis_assistance_rqst_ind() != null? appPgmRqstCargo.getCrisis_assistance_rqst_ind():0;
		programKeyArray[12] = appPgmRqstCargo.getFuel_assistance_rqst_ind() != null? appPgmRqstCargo.getFuel_assistance_rqst_ind():0;
		programKeyArray[13] = appPgmRqstCargo.getNo_snap_rqst_ind() != null? appPgmRqstCargo.getNo_snap_rqst_ind():0;
		programKeyArray[14] = appPgmRqstCargo.getWic_rqst_ind() != null? appPgmRqstCargo.getWic_rqst_ind():0;
		programKeyArray[15] = appPgmRqstCargo.getLiheap_rqst_ind() != null? appPgmRqstCargo.getLiheap_rqst_ind():0;
		programKeyArray[16] = appPgmRqstCargo.getMagi_rqst_ind() != null? appPgmRqstCargo.getMagi_rqst_ind():0;
		programKeyArray[17] = appPgmRqstCargo.getPeach_rqst_ind() != null? appPgmRqstCargo.getPeach_rqst_ind():0;
	 
	 }

	public void deleteAbsentParent(Integer ref_indv_seq_num, String appNumber) {
		
		throw new UnsupportedOperationException();
	}


	/**
	 * Store citizenShip information.
	 * @param appIndvColl
	 * @param appNumber
	 * @param indvSeqNum
	 */
	public void storeCitizenship(APP_INDV_Collection appIndvColl, String appNumber, Integer indvSeqNum) {
		final long startTime = System.currentTimeMillis();
		logger.info("ABHouseHoldMemberBO.storeCitizenship() - START");
	 try {	
		int size = 0;
		int beforeFlag = 0;
		APP_INDV_Cargo appIndvCargoBefore = null;
		APP_INDV_Cargo cargo = null;
		
		//getting details for indv
		APP_INDV_Collection appIndvCollBefore = cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNumber),indvSeqNum);
		size = appIndvCollBefore.size();
		if(size >0) {
			appIndvCargoBefore = appIndvCollBefore.getCargo(0);
			beforeFlag++;
		}
		
		if(Objects.nonNull(appIndvColl) && Objects.nonNull(appIndvColl.getResults())) {
			cargo = appIndvColl.getCargo(0);
		}
		
		//adding only required fields to existing to make sure not to override
		if(beforeFlag > 0) {
			citizenShipDetails(appIndvCargoBefore, cargo);
			 //set update date
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
			appIndvCargoBefore.setUpdate_dt(currentTimeStamp);
			cpAppIndvRepository.save(appIndvCargoBefore);
		}else {
			if(Objects.nonNull(appIndvColl) && Objects.nonNull(appIndvColl.getResults())){
				for(APP_INDV_Cargo Indvcargo:appIndvColl.getResults()){
					 //set update date
					Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
					Indvcargo.setUpdate_dt(currentTimeStamp);
					cpAppIndvRepository.save(Indvcargo);
				}
			}
		}
	 }catch(Exception e) {
		 throw e;
	 }

	}

	public void citizenShipDetails(APP_INDV_Cargo appIndvCargoBefore, APP_INDV_Cargo cargo) {
		//details from ABDOC
		try {
		if (cargo != null) {
		validateDet(appIndvCargoBefore, cargo);
		appIndvCargoBefore.setSpnsr_food_sw(null == cargo.getSpnsr_food_sw() || (cargo.getSpnsr_food_sw().isEmpty()  ) ? null : cargo.getSpnsr_food_sw());
		appIndvCargoBefore.setSpnsr_clothes_sw(null == cargo.getSpnsr_clothes_sw() || (cargo.getSpnsr_clothes_sw().isEmpty() ) ? null : cargo.getSpnsr_clothes_sw());
		appIndvCargoBefore.setSpnsr_other_sw(null == cargo.getSpnsr_other_sw() || (cargo.getSpnsr_other_sw().isEmpty() ) ? null : cargo.getSpnsr_other_sw());
		appIndvCargoBefore.setSpnsr_other_explanation(null == cargo.getSpnsr_other_explanation() || (cargo.getSpnsr_other_explanation().isEmpty() ) ? null : cargo.getSpnsr_other_explanation());

		//details from ABDSM
		validateABDSM(appIndvCargoBefore, cargo);
		}
		}catch(Exception e) {
			throw e;
		}
	}

	private void validateDet(APP_INDV_Cargo appIndvCargoBefore, APP_INDV_Cargo cargo) {
		validateABDOC(appIndvCargoBefore, cargo);
		//details from ABDSC
		appIndvCargoBefore.setSpnsr_ctzn_ind((null == cargo.getSpnsr_ctzn_ind() || cargo.getSpnsr_ctzn_ind().isEmpty() ) ? null : cargo.getSpnsr_ctzn_ind());
		//details from ABDSI
		appIndvCargoBefore.setSpnsr_i134_sign_sw(null == cargo.getSpnsr_i134_sign_sw() || (cargo.getSpnsr_i134_sign_sw().isEmpty() ) ? null : cargo.getSpnsr_i134_sign_sw());
		//details from ABDSJ
		validateABDSJ(appIndvCargoBefore, cargo);
	}

	private void validateABDOC(APP_INDV_Cargo appIndvCargoBefore, APP_INDV_Cargo cargo) {
		appIndvCargoBefore.setUs_ctzn_sw(null == cargo.getUs_ctzn_sw() || (cargo.getUs_ctzn_sw().isEmpty()  ) ? null : cargo.getUs_ctzn_sw());
		appIndvCargoBefore.setDt_entry_into_us(null == cargo.getEntry_into_us_dt() || (cargo.getEntry_into_us_dt().toString().isEmpty()  ) ? null : cargo.getEntry_into_us_dt());
		appIndvCargoBefore.setVld_immgrtn_sts(null == cargo.getVld_immgrtn_sts() || (cargo.getVld_immgrtn_sts().isEmpty() ) ? null : cargo.getVld_immgrtn_sts());
		appIndvCargoBefore.setAlien_doc_type_cd(null == cargo.getAlien_doc_type_cd() || (cargo.getAlien_doc_type_cd().isEmpty()  ) ? null : cargo.getAlien_doc_type_cd());
		appIndvCargoBefore.setAlien_doc_num(null == cargo.getAlien_doc_num() || (cargo.getAlien_doc_num().isEmpty()  ) ? null : cargo.getAlien_doc_num());
		appIndvCargoBefore.setLived_in_us_con_sw(null == cargo.getLived_in_us_con_sw() || (cargo.getLived_in_us_con_sw().isEmpty() ) ? null : cargo.getLived_in_us_con_sw());
		appIndvCargoBefore.setNaturalized_ctzn_ind(null == cargo.getNaturalized_ctzn_ind() || (cargo.getNaturalized_ctzn_ind().isEmpty() ) ? null : cargo.getNaturalized_ctzn_ind());
	}

	private void validateABDSM(APP_INDV_Cargo appIndvCargoBefore, APP_INDV_Cargo cargo) {
		appIndvCargoBefore.setImm_wrk_hist_ind(null == cargo.getImm_wrk_hist_ind() || (cargo.getImm_wrk_hist_ind().isEmpty() ) ? null : cargo.getImm_wrk_hist_ind());
		appIndvCargoBefore.setImm_plan_ind(null == cargo.getImm_plan_ind() || (cargo.getImm_plan_ind().isEmpty()  ) ? null : cargo.getImm_plan_ind());
		appIndvCargoBefore.setAlien_status_cd(null == cargo.getAlien_status_cd() || (cargo.getAlien_status_cd().isEmpty()  ) ? null : cargo.getAlien_status_cd());
		appIndvCargoBefore.setImm_status_value(null == cargo.getImm_status_value() || (cargo.getImm_status_value().isEmpty() ) ? null : cargo.getImm_status_value());
		appIndvCargoBefore.setImm_status_chg_dt(null == cargo.getImm_status_chg_dt() || (cargo.getImm_status_chg_dt().toString().isEmpty()  ) ? null : cargo.getImm_status_chg_dt());
		appIndvCargoBefore.setAlien_num(null == cargo.getAlien_num() ||(cargo.getAlien_num().isEmpty()  ) ? null : cargo.getAlien_num());
	}

	private void validateABDSJ(APP_INDV_Cargo appIndvCargoBefore, APP_INDV_Cargo cargo) {
		appIndvCargoBefore.setSpnsr_i864_sign_sw(null == cargo.getSpnsr_i864_sign_sw() || (cargo.getSpnsr_i864_sign_sw().isEmpty() ) ? null : cargo.getSpnsr_i864_sign_sw());
		appIndvCargoBefore.setSpnsr_first_name(null == cargo.getSpnsr_first_name() || (cargo.getSpnsr_first_name().isEmpty()) ? null : cargo.getSpnsr_first_name());
		appIndvCargoBefore.setSpnsr_last_name(null == cargo.getSpnsr_last_name() || (cargo.getSpnsr_last_name().isEmpty()) ? null : cargo.getSpnsr_last_name());
		appIndvCargoBefore.setSpnsr_phn_num(null == cargo.getSpnsr_phn_num() || (cargo.getSpnsr_phn_num().isEmpty() ) ? null : cargo.getSpnsr_phn_num());
		appIndvCargoBefore.setSpnsr_help_sw(null == cargo.getSpnsr_help_sw()|| (cargo.getSpnsr_help_sw().isEmpty() ) ? null : cargo.getSpnsr_help_sw());
		appIndvCargoBefore.setSpnsr_amt(null == cargo.getSpnsr_amt() || (cargo.getSpnsr_amt().toString().isEmpty()  ) ? null : cargo.getSpnsr_amt());
		appIndvCargoBefore.setSpnsr_rent_sw(null == cargo.getSpnsr_rent_sw() || (cargo.getSpnsr_rent_sw().isEmpty() ) ? null : cargo.getSpnsr_rent_sw());
		
	}

	/**
	 * Get citizenShip details.
	 * @param appNumber
	 * @return
	 */
	public APP_INDV_Collection getCitizenshipDetails(String appNumber) {

		
		logger.info("ABHouseHoldMemberBO.getCitizenshipDetails() - START");
		APP_INDV_Collection appIndvColl = cpAppIndvRepository.loadAppIndvData(Integer.parseInt(appNumber));
		
		return appIndvColl;
	}

	/**
	 * Save children details.
	 * @param indvCollection
	 * @param persistAction
	 */
	public void saveChildrenDetails(APP_INDV_Collection indvCollection) {

		/**
		 * Save will update the existing records if they EXIST.
		 * TODO: Modify this logic to only update the specific columns later.
		 */
		for(APP_INDV_Cargo cargo:indvCollection.getResults()) {
			citizenshipRepo.save(getDBEntity(cargo));

		}

	}

	/**
	 * Get DB Entity.
	 * @param cargo
	 * @return
	 */
	private CP_APP_ESGIN_Cargo getDBEntity(APP_INDV_Cargo cargo) {
		CP_APP_ESGIN_Cargo cpAppEsginCargo = new CP_APP_ESGIN_Cargo();
		cpAppEsginCargo.setSrcAppInd(cargo.getSrc_app_ind());
		cpAppEsginCargo.setSeqNum(Integer.valueOf(cargo.getIndv_seq_num()));
		cpAppEsginCargo.setAppNum(cargo.getApp_num());
		cpAppEsginCargo.setAppl_citz_decl_fst_nam(cargo.getAlias_fst_nam());
		cpAppEsginCargo.setAppl_citz_decl_last_nam(cargo.getLast_nam());
		cpAppEsginCargo.setAppl_citz_decl_suffix_name(cargo.getSuffix_name());
		return cpAppEsginCargo;
	}

	public List getOutSideHomeIndvSeqNum(INDIVIDUAL_Custom_Collection tempIndvCustColl) {
		return null;
	}

	public CP_APP_INDV_ADDI_INFO_Collection loadExpeditedAssistanceInfo(
			final String appNumber) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.loadExpeditedAssistanceInfo() - START, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");

		try {
			CP_APP_INDV_ADDI_INFO_Collection appInColl;
			appInColl = cpAppIndvAddiInfoRepository.getByAppNum(Integer.parseInt(appNumber));
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABHouseHoldMemberBO.loadExpeditedAssistanceInfo() - END, Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");
			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public void storeExpeditedAssistanceInfo(
			final CP_APP_INDV_ADDI_INFO_Collection appIndvAdInfoColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.storeExpeditedAssistanceInfo() - START, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		try {
			if (appIndvAdInfoColl != null && !appIndvAdInfoColl.isEmpty()) {
				CP_APP_INDV_ADDI_INFO_Cargo cargo;
				cargo = appIndvAdInfoColl.getCargo(0);
				cpAppIndvAddiInfoRepository.save(cargo);
			}
		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.storeExpeditedAssistanceInfo() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
	}
	
	public APP_INDV_Cargo getIndividual(String appNum, int indvSeqNum) {
		return cpAppIndvRepository.getAppIndvCargoByAppNumIndvSeq(Integer.parseInt(appNum), indvSeqNum);
	}
	
	public APP_INDV_Collection loadIndvDataCollection(String appNum, Integer indv_seq_num) {
		return cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNum),indv_seq_num);
	}
	
	public APP_INDV_IMG_Collection loadImmigrationInfo(String appnum, String statusCd) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABHouseHoldMemberBO.loadImmigrationInfo() - START");
		APP_INDV_IMG_Collection res = null;
		try {
			 res = cpAppIndvRepository.loadImmigrationInfo(Integer.parseInt(appnum), statusCd);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABHouseHoldMemberBO.loadImmigrationInfo() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");
			
		} catch (final Exception e) {
			throw createFwException(getClass().getName(),
					"loadImmigrationInfo", e);
		}
		return res;
	}

}
