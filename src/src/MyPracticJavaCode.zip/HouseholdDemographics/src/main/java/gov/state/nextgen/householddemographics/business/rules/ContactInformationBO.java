package gov.state.nextgen.householddemographics.business.rules;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.householddemographics.business.entities.APP_AR_LG_CNTC_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_AR_LG_CNTC_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CP_APP_RGST_Repository;
import gov.state.nextgen.householddemographics.data.db2.CpAppArLgCntcRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;

/**
 * This class contains rules and/or validations related to ABCON.
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

@Service("ContactInformationBO")
public class ContactInformationBO extends AbstractBO{
	
	private CpAppArLgCntcRepository cpAppArLgCntcRepository;
	
	@Autowired
	private CP_APP_RGST_Repository cp_app_rgst_repo;
	
	@Autowired
	private CpAppIndvRepository cpAppIndvRepo;
	
	/**
	 * Method moved from ABCONValidator.
	 * Validates the APP_AR_LG_CNTC_Cargo for ABCON - Contact Information
	 * 
	 * @param valdateLGCargo
	 * @return messageList with validation messages if any.
	 */
	
	public FwMessageList validateLGContactInfo(final APP_AR_LG_CNTC_Cargo valdateLGCargo) {
		
		try {
			final char[] specialChars = { '.', '\'', '-', ' ' };
			final char[] specialCharsForContact = { '.', '\'', '-', ' ', '&' };
			final char[] specialCharsForAddress = { '-', '\'', '.', '#', '/', ',' , '&', ' '};
			
			FwMessageList  messageList= new FwMessageList();
			
			/* ----- Validations for contact information START----- */
			
			// Agency Validation
			if (!appMgr.isFieldEmpty(valdateLGCargo.getAgency_name())) {
				if (!appMgr.isSpecialAlphaNumeric(valdateLGCargo.getAgency_name(), specialCharsForContact)) {
					final Object[] error = new Object[] { new FwMessageTextLabel(HouseHoldDemoGraphicsConstants.MSG_50008) };
					messageList.addMessageToList(addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_09014, error));
				} else if (valdateLGCargo.getAgency_name().charAt(0) == HouseHoldDemoGraphicsConstants.MSG_0) {
					final Object[] error = new Object[] { new FwMessageTextLabel(HouseHoldDemoGraphicsConstants.MSG_50008) };
					messageList.addMessageToList(addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_09016, error));
				}
			}

			// Name Validation
			if (appMgr.isFieldEmpty(valdateLGCargo.getCon_name())) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_09015));
			} else {
				if (!appMgr.isSpecialAlphaNumeric(valdateLGCargo.getCon_name(), specialCharsForContact)) {
					final Object[] error = new Object[] { new FwMessageTextLabel(HouseHoldDemoGraphicsConstants.MSG_50082) };
					messageList.addMessageToList(addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_09014, error));
				} else if (valdateLGCargo.getCon_name().charAt(0) == HouseHoldDemoGraphicsConstants.MSG_0) {
					final Object[] error = new Object[] { new FwMessageTextLabel(HouseHoldDemoGraphicsConstants.MSG_50082) };
					messageList.addMessageToList(addMessageWithFieldValues(HouseHoldDemoGraphicsConstants.MSG_09016, error));
				}
			}

			// Address Validation
			if (!appMgr.isFieldEmpty(valdateLGCargo.getLine1_adr()) || !appMgr.isFieldEmpty(valdateLGCargo.getLine2_adr())) {
				if (!appMgr.isSpecialAlphaNumeric(valdateLGCargo.getLine1_adr(), specialCharsForAddress)
						|| !appMgr.isSpecialAlphaNumeric(valdateLGCargo.getLine2_adr(), specialCharsForAddress)) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00017));
				}
			}

			// City Validation
			if (!appMgr.isFieldEmpty(valdateLGCargo.getCity_adr())) {
				if (!appMgr.isSpecialAlphaNumeric(valdateLGCargo.getCity_adr(), specialChars)) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_99062));
				}
			}

			// Zip Code Validation
			if (!appMgr.isFieldEmpty(valdateLGCargo.getZip_adr())) {
				if (!appMgr.isInteger(valdateLGCargo.getZip_adr())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00019));
				} else if (!(valdateLGCargo.getZip_adr().length() == 5)) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10503));
				} else if (HouseHoldDemoGraphicsConstants.MSG_00000.equals(valdateLGCargo.getZip_adr()) || HouseHoldDemoGraphicsConstants.MSG_000000000.equals(valdateLGCargo.getZip_adr())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00022));
				}
			}

			if (!messageList.containsMessage(HouseHoldDemoGraphicsConstants.MSG_00019)
					&& valdateLGCargo.getAddrZip4() != null
					&& !"".equals(valdateLGCargo.getAddrZip4().trim())
					&& !valdateLGCargo.getAddrZip4().matches("\\d+")) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00019));

			}	
			// PhoneNumber Validation
			if (!appMgr.isFieldEmpty(valdateLGCargo.getPhone_num())) {
				if (!appMgr.isInteger(valdateLGCargo.getPhone_num())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10231));
				} else if (!appMgr.validatePhone(valdateLGCargo.getPhone_num())) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10231));
				} else if ((valdateLGCargo.getPhone_num().charAt(0)) == HouseHoldDemoGraphicsConstants.MSG_0) {
					messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10238));
				}
			}

			if (FwConstants.DEFAULT_DROPDOWN_SEL.equals(valdateLGCargo.getState_adr())) {
				valdateLGCargo.setState_adr(FwConstants.SPACE);
			}

			/* ----- Validations for contact information END----- */
			
			return messageList;
		}  catch (final Exception e) {
			
			throw e;
		}
		
	}
	
	/**
	 * Performs persist action on the table CP_APP_AR_LG_CNTC 
	 * 
	 * @param appARColl
	 * 
	 * */
	
	public void storeContactInfo(final APP_AR_LG_CNTC_Collection appARColl) {
		
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ContactInformationBO.storeContactInfo- START");
		
		try {
			APP_AR_LG_CNTC_Cargo cargo = null;
	            if(appARColl != null && !appARColl.isEmpty()){
	                cargo = appARColl.getCargo(0);
	      			cpAppArLgCntcRepository.save(cargo);

	            }
	   } catch (final Exception fe) {
			throw fe;
		} 
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ContactInformationBO.storeContactInfo - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
	}
	
	/**
	 * Performs select action on the table CP_APP_AR_LG_CNTC 
	 * 
	 * @param appNum
	 * @return APP_AR_LG_CNTC_Collection object
	 * */
	
	public APP_AR_LG_CNTC_Collection getLGContactInfo(String appNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ContactInformationBO.getLGContactInfo- START");
		APP_AR_LG_CNTC_Collection lgColl = null;
		try {

			lgColl = cpAppArLgCntcRepository.getByAppNum(appNum);

		} catch (final Exception fe) {
			throw fe;
		} 
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ContactInformationBO.getLGContactInfo - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
		return lgColl;
	}
	
	/**
	 * fetch the contact related information for the given appNum and src_app_ind
	 * @param appNum
	 * @param src_app_ind
	 * @param indv_seq_num 
	 * @return
	 */
	public CP_APP_RGST_Cargo loadContactInformationforAppNum(String appNum, String src_app_ind, Integer indv_seq_num) {
		/*
		 * added by swabehera@deloitte.com
		 * try and catch block implemented. General exception will be set in framework exception and throw
		 */
		
		try {
			return cp_app_rgst_repo.loadContactInfoforAppnum(Integer.parseInt(appNum), src_app_ind, indv_seq_num);
		} catch(Exception ex) {
			FwException fe = new FwException();
        	fe = FwExceptionManager.createFwException(this.getClass().getName(), fe.getStackTrace()[0].getMethodName(), ex);
        	throw fe;
		}
		
	}
	
	/**
	 * store contact information
	 * @param contactCargo 
	 */
	public void storeContactInformation(CP_APP_RGST_Cargo contactCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ContactInformationBO.storeContactInformation- START");
		try {
	            if(contactCargo != null){
	            	//Set update date
	            	Timestamp currentTimeStamp = new Timestamp(new Date().getTime());
	            	contactCargo.setUpdate_dt(currentTimeStamp);
	            	cp_app_rgst_repo.save(contactCargo);
	            }
	   } catch (final Exception fe) {
		   FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		} 
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ContactInformationBO.storeContactInformation - END , Time Taken : " + (System.currentTimeMillis() - startTime) );	
	}

	public APP_INDV_Collection loadIndvdtl(String appNum, Integer indv_seq_num) {
		// TODO Auto-generated method stub
		try {
			return cpAppIndvRepo.getCollByAppNumIndvSeq(Integer.parseInt(appNum),indv_seq_num);
		} catch(Exception exception) {
			FwException fe = new FwException();
        	fe = FwExceptionManager.createFwException(this.getClass().getName(), fe.getStackTrace()[0].getMethodName(), exception);
        	throw fe;
		}
	}
	
	/******************************************************************************************************************
	 * 
	 * 
	 * This method will get Email Receipt info from RGST table(CSPM - 2083)
	 * @param appNum,srcAppInd,indvSeqNum
	 * 
	 * 
	 ********************************************************************************************************************
	 */
	public CP_APP_RGST_Collection getEmailReceiptInfo(String appNum, String srcAppInd, Integer indvSeqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ContactInformationBO.getEmailReceiptInfo() - START");
		CP_APP_RGST_Collection cpAppRGSTColl = new CP_APP_RGST_Collection();
		if(indvSeqNum == 0) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ContactInformationBO.getEmailReceiptInfo() - END, Time Taken : "
							+ (System.currentTimeMillis() - startTime) );
			return cpAppRGSTColl;
		}
		try {
			CP_APP_RGST_Cargo cpAPPRGSTCargo = (CP_APP_RGST_Cargo) cp_app_rgst_repo.loadContactInfoforAppnum(Integer.parseInt(appNum), srcAppInd,indvSeqNum);
			if(Objects.nonNull(cpAPPRGSTCargo)) {
				cpAppRGSTColl.addCargo(cpAPPRGSTCargo);
			}
		}catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ContactInformationBO.getEmailReceiptInfo() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) );
		return cpAppRGSTColl;
		
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * This method will return Email APP_INDV_Collection
	 * @param appNum 
	 * 
	 * 
	 ********************************************************************************************************************
	 */
	public APP_INDV_Collection getAllIndividuals(String appNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ContactInformationBO.getAllIndividuals() - START");
		APP_INDV_Collection appIndvColl = new APP_INDV_Collection();
		try {
		appIndvColl = cpAppIndvRepo.loadCpAppIndvDetails(Integer.parseInt(appNum));
		}catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ContactInformationBO.getAllIndividuals() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime) );
		return appIndvColl;
	}
	/**
     * fetch the contact related information for the given appNum and src_app_ind
     * @param appNum
     * @param src_app_ind
     * @param indv_seq_num 
      * @return
     */
     public CP_APP_RGST_Collection loadContactforAppNum(String appNum, String src_app_ind) {
           
           try {
                  CP_APP_RGST_Collection coll = new CP_APP_RGST_Collection();
                  List<CP_APP_RGST_Cargo> cpAppRgstList =  cp_app_rgst_repo.loadContactForAppnum(Integer.parseInt(appNum), src_app_ind);
                  if(cpAppRgstList != null && cpAppRgstList.size()>0) {
                        for (Iterator iterator = cpAppRgstList.iterator(); iterator.hasNext();) {
                               CP_APP_RGST_Cargo cp_APP_RGST_Cargo = (CP_APP_RGST_Cargo) iterator.next();
                               coll.add(cp_APP_RGST_Cargo);
                               
                        }
                  }
                  return coll;
           } catch(Exception ex) {
                  throw ex;
           }
           
     }

	
	/**
	 * fetch the contact related information for the given appNum and src_app_ind
	 * @param appNum
	 * @param indvSeqNum 
	 * @param src_app_ind
	 * @param indv_seq_num 
	 * @return
	 */
	public CP_APP_RGST_Cargo loadDataInerPerfforAppNumAndSrcAppInd(String appNum, Integer indvSeqNum, String src_app_ind) {
		return cp_app_rgst_repo.loadDataInerPerfforAppNumAndSrcAppInd(Integer.parseInt(appNum), indvSeqNum, src_app_ind);
	}
	
	public APP_INDV_Collection loadActiveIndvdtl(String appNum) {
		// TODO Auto-generated method stub
		try {
			return cpAppIndvRepo.getAppActiveIndvCargoByAppNum(Integer.parseInt(appNum));
		} catch(Exception exception) {
			throw exception;
		}
	}
	
	
	/**
	 * fetch the contact related information for the given appNum and indv
	 * @param appNum
	 * @param src_app_ind
	 * @return
	 */
	public List<CP_APP_RGST_Cargo> loadContactSummaryforActiveIndv(String appNum, List<Integer> indvs) {
	
		try {
			return cp_app_rgst_repo.getContactInfoActiveIndv(Integer.parseInt(appNum), indvs);
		} catch(Exception ex) {
			throw ex;
		}
		
	}
	
	/**
	 * fetch the contact related information for the given appNum and indv
	 * @param appNum
	 * @param src_app_ind
	 * @return
	 */
	public CP_APP_RGST_Cargo loadContactInfoAppIndv(String appNum, Integer indv) {
	
		try {
			return cp_app_rgst_repo.getCpAppRgstDetails(Integer.parseInt(appNum), indv);
		} catch(Exception ex) {
			throw ex;
		}
		

	}
	
    public CP_APP_RGST_Collection loadCpRgstCollection(String appNum) {
        
        try {
               CP_APP_RGST_Collection coll = new CP_APP_RGST_Collection();
               List<CP_APP_RGST_Cargo> cpAppRgstList =  cp_app_rgst_repo.getRgstListByAppNum(Integer.parseInt(appNum));
               if(cpAppRgstList != null && cpAppRgstList.size()>0) {
                     for (Iterator iterator = cpAppRgstList.iterator(); iterator.hasNext();) {
                            CP_APP_RGST_Cargo cp_APP_RGST_Cargo = (CP_APP_RGST_Cargo) iterator.next();
                            coll.add(cp_APP_RGST_Cargo);
                            
                     }
               }
               return coll;
        } catch(Exception ex) {
               FwException fe = new FwException();
        fe = FwExceptionManager.createFwException(this.getClass().getName(), fe.getStackTrace()[0].getMethodName(), ex);
        throw fe;
        }
        
  }
}
