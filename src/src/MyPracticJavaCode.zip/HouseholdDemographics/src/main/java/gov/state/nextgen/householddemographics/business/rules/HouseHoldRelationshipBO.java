package gov.state.nextgen.householddemographics.business.rules;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.*;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipAppInputRepo;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
public class HouseHoldRelationshipBO extends HouseHoldBaseBO  {

    protected static final String APP_HSHL_RLT_COLLECTION = "APP_HSHL_RLT_Collection";

    private static final Logger logger = LoggerFactory.getLogger(HouseHoldRelationshipBO.class);

    @Autowired
    private HouseholdRelationshipRepo householdRelationshipRepo;
    
    private HouseholdRelationshipAppInputRepo householdRelationshipAppInputRepo;

    /**
     * checkExitingRelations
     * @param appNumber
     * @return
     */
    public APP_HSHL_RLT_Collection checkExistingRelations(String appNumber) {
     try {	
        APP_HSHL_RLT_Collection appHouseholdRelationCollection = new APP_HSHL_RLT_Collection();
        List<APP_HSHL_RLT_Cargo> appHouseHoldRelationCargos = getAppHouseholdRelationCargos(householdRelationshipRepo.findByAppNumAndSrcAppIndivAndRltCdIn(Integer.parseInt(appNumber),"RN", Arrays.asList(new String[]{"HUS","WIF","FTR","MTR"})));
        if (!CollectionUtils.isEmpty(appHouseHoldRelationCargos)) {
            appHouseholdRelationCollection.setResults(appHouseHoldRelationCargos.toArray(new APP_HSHL_RLT_Cargo[appHouseHoldRelationCargos.size()]));
        }
        return appHouseholdRelationCollection;
     }catch(Exception e) {
    	 throw e;
     }
    }

    /**
     * Load household relationship details from appNumber and indvSeqNumber
     * @param appNumber
     * @param indvSeqNumber
     * @param fwTransaction
     * @return
     */
    public Map<Object,Object> loadHousholdRelationshipDetails(String appNumber, Integer indvSeqNumber, FwTransaction fwTransaction) {
       try {
    	APP_HSHL_RLT_Collection appHouseholdRelationCollection = new APP_HSHL_RLT_Collection();
        List<APP_HSHL_RLT_Cargo> appHouseHoldRelationCargos = getAppHouseholdRelationCargos(householdRelationshipRepo.findByAppNumAndSrcIndvSeqNum(Integer.parseInt(appNumber), String.valueOf(indvSeqNumber)));
        if (!CollectionUtils.isEmpty(appHouseHoldRelationCargos)) {
            appHouseholdRelationCollection.setResults(appHouseHoldRelationCargos.toArray(new APP_HSHL_RLT_Cargo[appHouseHoldRelationCargos.size()]));
            fwTransaction.getPageCollection().put(APP_HSHL_RLT_COLLECTION, appHouseholdRelationCollection);
            final int appHshlRltCollSize = appHouseholdRelationCollection.size();
            if(Objects.nonNull(appHouseholdRelationCollection.getResults())){
                List<String> relationList = Arrays.stream(appHouseholdRelationCollection.getResults()).map(APP_HSHL_RLT_Cargo::getRlt_cd).collect(Collectors.toList());
                fwTransaction.getPageCollection().put("RelationList", relationList);
            }
        }
        return fwTransaction.getPageCollection();
       }catch(Exception e) {
    	   throw e;
       }
    }
       

    /**
     * Split Relation with record indvSeqNum.
     * @param hshlRltColl
     * @param recordIndicator
     * @param srcSeqNum
     * @param refSeqNum
     * @return
     */
    public APP_HSHL_RLT_Cargo splitRelationWithRecIndSeqNum(final APP_HSHL_RLT_Collection hshlRltColl,final String recordIndicator, final Integer srcSeqNum,final Integer refSeqNum) {
        final long startTime = System.currentTimeMillis();
        logger.info("HouseHoldRelationshipBO.splitRelationWithRecIndSeqNum() - START");
        try {
            if ((hshlRltColl != null) && (!hshlRltColl.isEmpty())) {
                final int hshlRltCollSize = hshlRltColl.size();
                APP_HSHL_RLT_Cargo hshlRltCargo = null;
                for (int i = 0; i < hshlRltCollSize; i++) {
                    hshlRltCargo = hshlRltColl.getCargo(i);
                    if (hshlRltCargo.getSrc_app_ind().equals(recordIndicator) && hshlRltCargo.getSrc_indv_seq_num().equals(srcSeqNum) && hshlRltCargo.getRef_indv_seq_num().equals(refSeqNum)) {
                        return hshlRltCargo;
                    }
                }
            }
            logger.info("HouseHoldRelationshipBO.splitRelationWithRecIndSeqNum() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + " milliseconds");
            return null;
        } catch (Exception exception) {
            throw exception; 
        }
    }

    /**
     * Updates the DB data for the given cargos.
     * @param appHshlRltColl
     * @param appNewBornColl
     * @param persistAction
     */
    public void storeHousholdRelationshipDetails(final APP_HSHL_RLT_Collection appHshlRltColl, APP_IN_NEWB_Collection appNewBornColl, String persistAction) {
        try{
        	if(StringUtils.isNotBlank(persistAction)){
            switch (persistAction){
                case FwConstants.ROWACTION_INSERT:
                    for(APP_IN_NEWB_Cargo app_in_newb_cargo:appNewBornColl.getResults()){
                        householdRelationshipAppInputRepo.save(getAppEntityNewBCargo(app_in_newb_cargo));
                    }
                    break;
                case FwConstants.ROWACTION_DELETE:
                    for(APP_IN_NEWB_Cargo app_in_newb_cargo:appNewBornColl.getResults()){
                        householdRelationshipAppInputRepo.delete(getAppEntityNewBCargo(app_in_newb_cargo));
                    }
                    break;
                case FwConstants.ROWACTION_UPDATE:
                    for(APP_IN_NEWB_Cargo app_in_newb_cargo:appNewBornColl.getResults()){
                        APP_IN_NEWB app_in_newb = householdRelationshipAppInputRepo.findByAppNumAndIndvSeqNum(Integer.parseInt(app_in_newb_cargo.getAppNum()),Double.valueOf(app_in_newb_cargo.getIndvSeqNum()));
                        app_in_newb.setLiveWithMomResp(app_in_newb_cargo.getLive_with_mom_resp());
                        if(Objects.nonNull(app_in_newb_cargo.getRec_cplt_ind())){app_in_newb.setRecCpltInd(Long.valueOf(app_in_newb_cargo.getRec_cplt_ind()));}
                        householdRelationshipAppInputRepo.save(app_in_newb);
                    }
                    break;
            }
        }
        persistAction = StringUtils.EMPTY;
        //Resetting the persistAction to empty, Thereby Initializing for other operation.
        }catch(Exception e) {
        	throw e;
        }
    }

    /**
     * Get App Entity APP_IN_NEWB cargo.
     * @param app_in_newb_cargo
     * @return
     */
    private APP_IN_NEWB getAppEntityNewBCargo(APP_IN_NEWB_Cargo app_in_newb_cargo) {
        APP_IN_NEWB app_in_newb = new APP_IN_NEWB();
        app_in_newb.setAppNum(app_in_newb.getAppNum());
        app_in_newb.setIndvSeqNum(app_in_newb.getIndvSeqNum());
        app_in_newb.setLiveWithMomResp(app_in_newb.getLiveWithMomResp());
        app_in_newb.setRecCpltInd(app_in_newb.getRecCpltInd());
        return app_in_newb;
    }
}
