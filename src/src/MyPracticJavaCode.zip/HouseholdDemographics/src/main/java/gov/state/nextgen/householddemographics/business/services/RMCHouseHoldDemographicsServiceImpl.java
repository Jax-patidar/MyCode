/**
 * 
 */
package gov.state.nextgen.householddemographics.business.services;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.util.CollectionUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessage;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.access.management.util.FwDate;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_NEWB_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CaseIndividualDetails;
import gov.state.nextgen.householddemographics.business.entities.CpAppUserCargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppUserCargoKey;
import gov.state.nextgen.householddemographics.business.rules.ABDisabilityBO;
import gov.state.nextgen.householddemographics.business.rules.AbsentParentBO;
import gov.state.nextgen.householddemographics.business.rules.ContactInformationBO;
import gov.state.nextgen.householddemographics.business.rules.ReportMyChangeBO;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.constants.HouseholdApplicationConstants;
import gov.state.nextgen.householddemographics.data.db2.AppRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInSchleRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppUserRepository;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;

/**
 * @author spoloju
 *
 */
@SuppressWarnings("squid:S2229")
@Service("RMCHouseholdDemographicsService")
public class RMCHouseHoldDemographicsServiceImpl implements HouseholdDemographicsService {

	@Autowired
	private ABDisabilityBO disabilityBo;

	@Autowired
	private ExceptionUtil exceptionUtil;

	@Autowired
	CpAppIndvRepository cpAppIndvRepository;

	@Autowired
	private HouseholdRelationshipRepo appHshlRltRepository;

	@Autowired
	CpAppPgmIndvRepository cpAppPgmIndvRepository;

	@Autowired
	CpAppPgmRqstRepository cpAppPgmRqstRepository;

	@Autowired
	AppRqstRepository appRqstRepository;

	@Autowired
	private CpAppUserRepository cpAppUserRepository;

	@Autowired
	ARTransactionManagedServImpl arTransactionManagedServImpl;
	@Autowired
	private ReportMyChangeBO reportMyChangeBO;
	@Autowired
	HouseHoldInfoServImpl houseHoldInfoServImpl;
	@Autowired
	HouseholdDemographicsServiceImpl householdDemographicsServiceImpl;
	@Autowired
	BenefitsServImpl benefitsServImpl;
	@Autowired
	CpAppInSchleRepository appinschleRepository;
	@Autowired
	private ContactInformationBO contInfoBO;
	@Autowired
	AbsentParentBO absentParentBo;

	private static final String CPAPPHSHLRLTCOLL = "CP_APP_HSHL_RLT_Collection";
	private static final String CPAPPRGSTCOLL = "CP_APP_RGST_Collection";
	private static final String RMCHSHLDDEMOGRAHICSSERVICE = "RMCHouseholdDemographicsService";
	private static final String COLLECT_STUDENT_ARRAY = "collegeStudentArray";

	private static final String STORE_RMC_HELP_QUESTION_DATA = "storeRMCHelpQuestionData";
	private static final String INDV_ID = "indvId";
	private static final String MILLISECONDS = " milliseconds";
	
	@Override
	public void callBusinessLogic(String methodName, FwTransaction FwTxn) {

		switch (methodName) {

		case HouseHoldDemoGraphicsConstants.LOAD_HH_INFO_DET:
			this.loadHouseHoldInfoDisabilityDetails(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.STORE_FACILITY_INFO:
			this.storeHouseHoldInfoDisabilityDetails(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.GENERATE_APPLICATION_DATA_FOR_RMC:
			this.generateApplicationDataForRMC(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.FETCH_MOVEDOUT_INDV_DETAILS:
			this.fetchMovedOutIndvDetails(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.STORE_MOVEDOUT_INDV_DETAILS:
			this.storeMovedOutIndvDetails(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.REMOVE_MOVEDOUT_INDV_DETAILS:
			this.removeMovedOutIndvDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_SAVE_PASSED_AWAY_INFO:
			this.rmcSavePassedAwayInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_LOAD_PASSED_AWAY_INFO:
			this.rmcLoadPassedAwayInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_REMOVE_PASSED_AWAY_INFO:
			this.rmcRemovePassedAwayInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_SAVE_HOME_OR_MAILING_ADDR_INFO:
			this.rmcSaveHomeOrMailingAddrInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_CLEAR_HOME_OR_MAILING_ADDR_INFO:
			this.rmcClearHomeOrMailingAddrInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_LOAD_HOME_OR_MAILING_ADDR_INFO:
			this.rmcLoadMailingOrHomeAddrInfo(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.FETCH_BABY_INFO_DETAILS:
			this.loadNewBornIndvDetails(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.STORE_BABY_INFO_DETAILS:
			this.storeBabyInfoDetails(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.REMOVE_BABY_INFO_DETAILS:
			this.removeBabyInfoDetails(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.RMC_MRTL_DELETE:
			this.deleteMrtlDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_MRTL_LOAD:
			this.getMaritalStatusDetail(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_SAVE_PERSONAL_INFO:
			this.rmcSavePersonalChangeInfo(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.RMC_LOAD_PERSONAL_INFO:
			this.rmcLoadPersonalChangeInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_CLEAR_PERSONAL_INFO:
			this.rmcRemovePersonalChangeInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.GETSUMMARYDATA:
			this.getSummaryData(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.RMC_SAVE_HOMELESS_INFO:
			this.rmcSaveHomelessAddrInfo(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.RMC_LOAD_HOMELESS_INFO:
			this.rmcLoadHomelessAddrInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_CLEAR_HOMELESS_INFO:
			this.rmcClearHomelessAddrInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_SAVE_OTHER_PERSONAL_INFO:
			this.rmcSaveOtherPersonalInfo(FwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.RMC_LOAD_OTHER_PERSONAL_INFO:
			this.rmcLoadOtherPersonalInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_CLEAR_OTHER_PERSONAL_INFO:
			this.rmcClearOtherPersonalInfo(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.UPDATE_HHINDV_AND_RELATION_DETAILS:
			this.updateHHIndvAndRelationDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.ADD_NEW_INDV:
			this.addNewIndvAndRelationDetails(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_FULL_TIME_STUDENT:
			this.storeFullTimeStudent(FwTxn);
			break;
		case STORE_RMC_HELP_QUESTION_DATA:
			this.storeRMCHelpQuestionData(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_KIDNEY_DIALYSIS_INDICATOR:
			this.storeKidneyDialysisIndicator(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_ORGAN_TRANSPLANT_INDICATOR:
			this.storeOrganTransplantIndicator(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.RMC_SAVE_MARITAL_STATUS:
			this.rmcSaveMaritalStatus(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_IN_KIND_SUPPORT_INDICATOR:
			this.storeInKindSupportIndicator(FwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_INCOME_FLUCTUATION_INDICATOR:
			storeIncomeFluctuationInd(FwTxn);
			break;
		default:
			break;
		}

	}

	/**
	 * Method to generate App num and massage data from cp_rmc_request and
	 * cp_rmb_request_detail tables and store/update the massaged data in
	 * CP_APP_INDV, CP_APP_PGM_INDV, CP_APP_PGM_REQUEST, CP_APP_RGST and
	 * CP_RMB_REQUEST tables
	 * 
	 * @param fwTransaction, pageCollection, formStatusReqJson
	 * @return void
	 * @author ransahu
	 * @throws ParseException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void generateAppNumAndStoreRMCApplicationData(FwTransaction fwTransaction, final Map myJson) {
		try {
			final Map pageColl = fwTransaction.getPageCollection();
			Map pageCollection = (LinkedHashMap) myJson.get("pageCollection");
			APP_PGM_RQST_Collection appPrgRqstColl = new APP_PGM_RQST_Collection();
			APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
			CP_APP_PGM_INDV_Collection cpAppPgmIndvColl = new CP_APP_PGM_INDV_Collection();
			APP_RQST_Collection appRqstColl = new APP_RQST_Collection();

			String appNum = "";

			if (pageColl.containsKey("CASE_NUM")) {
				String caseNum = (String) pageColl.get("CASE_NUM");
				appNum = storeAppNumInCpAppRequest(fwTransaction, caseNum);
			}

			APP_RQST_Collection appRqstCollection = (APP_RQST_Collection) fwTransaction.getPageCollection()
					.get(HouseHoldDemoGraphicsConstants.APP_RQST_COLL);
			for (int k = 0; k < appRqstCollection.size(); k++) {
				APP_RQST_Cargo appRqstCargo = appRqstCollection.getCargo(k);
				appRqstCargo.setApp_num(appNum);
				appRqstColl.add(appRqstCargo);
			}

			/* Setting src app indicator based on form type */
			String srcAppInd = HouseHoldDemoGraphicsConstants.APP_IND_AFB;

			for (int i = 0; i < pageCollection.size(); i++) {
				List<List<String>> l = new ArrayList(pageCollection.values());
				LinkedHashMap getAlletails = (LinkedHashMap) l.get(i);
				Integer indvSeqNum = (Integer) getAlletails.get(INDV_ID);
				String isPrimIndv = "false";
				// Setting APP_INDV Details
				Map appProgIndv = (LinkedHashMap) getAlletails.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
				if (appProgIndv.containsKey("PRIM_SW") && appProgIndv.get("PRIM_SW").equals("Y")) {
					isPrimIndv = "true";
				}

				APP_INDV_Cargo appIndvNewCargo = setAppIndvDetails(appNum, indvSeqNum, appProgIndv, srcAppInd,
						isPrimIndv);
				appIndvCollection.add(appIndvNewCargo);

				// Setting APP_PGM_RQST Details
				Map appPgmRqst = (LinkedHashMap) getAlletails.get("APP_PGM_RQST_Collection");
				if (isPrimIndv.equals(HouseHoldDemoGraphicsConstants.TRUE)) {
					APP_PGM_RQST_Cargo appPgmRqstCargo = setAppPgmRqstDetails(appNum, appPgmRqst);
					appPrgRqstColl.add(appPgmRqstCargo);
				}

				// Setting CP_APP_PGM_INDV
				Map cpAppPgm = (LinkedHashMap) getAlletails.get("CP_APP_PGM_INDV_Collection");
				if (!isPrimIndv.equals(HouseHoldDemoGraphicsConstants.TRUE)) {
					CP_APP_PGM_INDV_Cargo appPgmIndvNewCargo = setAppPgmIndvDetails(appNum, indvSeqNum, cpAppPgm);
					cpAppPgmIndvColl.add(appPgmIndvNewCargo);
				}

			}

			cpAppPgmRqstRepository.saveAll(appPrgRqstColl);
			cpAppPgmIndvRepository.saveAll(cpAppPgmIndvColl);
			cpAppIndvRepository.saveAll(appIndvCollection);

			pageColl.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
			pageColl.put(HouseHoldDemoGraphicsConstants.CP_APP_PGM_INDV_Collection, cpAppPgmIndvColl);
			pageColl.put(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL, appPrgRqstColl);
			pageColl.put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, appRqstColl);
			pageColl.put(HouseHoldDemoGraphicsConstants.APP_NUM, appNum);
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * Method to set details into APP_PGM_RQST_Cargo
	 * 
	 * @param appNum, caseIndv
	 * @return APP_PGM_RQST_Cargo
	 * @author ransahu
	 */
	private APP_PGM_RQST_Cargo setAppPgmRqstDetails(String appNum, Map<String, String> appPrgInd) {

		APP_PGM_RQST_Cargo appPgmRqstCargo = new APP_PGM_RQST_Cargo();
		appPgmRqstCargo.setApp_num(appNum);
		if (!appPrgInd.get(HouseholdApplicationConstants.FS_RQST_IND).equals("")) {
			appPgmRqstCargo.setFs_rqst_ind(Integer.valueOf(appPrgInd.get("fs_rqst_ind")));
		}
		if (!appPrgInd.get(HouseholdApplicationConstants.FMA_RQST_IND).equals("")) {
			appPgmRqstCargo.setFma_rqst_ind(Integer.valueOf(appPrgInd.get("fma_rqst_ind")));
		}
		if (!appPrgInd.get(HouseholdApplicationConstants.TANF_RQST_IND).equals("")) {
			appPgmRqstCargo.setTanf_rqst_ind(Integer.valueOf(appPrgInd.get("tanf_rqst_ind")));
		}
		return appPgmRqstCargo;
	}

	/**
	 * Method to set details into APP_INDV_Cargo
	 * 
	 * @param appNum, indvSeqNum, caseIndv, srcAppInd
	 * @return APP_INDV_Cargo
	 * @author ransahu
	 * @throws ParseException
	 */
	private APP_INDV_Cargo setAppIndvDetails(String appNum, Integer indvSeqNum, Map<String, String> caseIndv,
			String srcAppInd, String isprimIndv) {
		APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
		appIndvCargo.setApp_num(appNum);
		appIndvCargo.setIndv_seq_num(indvSeqNum);
		if (caseIndv.containsKey("firstName")) {
			appIndvCargo.setFst_nam(caseIndv.get("firstName"));
		}
		if (caseIndv.containsKey("lastName")) {
			appIndvCargo.setLast_nam(caseIndv.get("lastName"));
		}
		if (caseIndv.containsKey("middleInitial")) {
			appIndvCargo.setMid_init(caseIndv.get("middleInitial"));
		}
		if (caseIndv.containsKey("sufxName")) {
			appIndvCargo.setSuffix_name(caseIndv.get("sufxName"));
		}
		if (caseIndv.containsKey("cinNumber")) {
			appIndvCargo.setCinNumber(caseIndv.get("cinNumber"));
		}
		if (caseIndv.containsKey("dob")) {
			String dateOFBirth = String.valueOf(caseIndv.get("dob"));
			Date date = Date.valueOf(dateOFBirth);
			appIndvCargo.setBrth_dt(date);
		}
		if (caseIndv.containsKey("age")) {
			appIndvCargo.setAge(caseIndv.get("age"));
		}
		if (caseIndv.containsKey("gender")) {
			appIndvCargo.setSex_ind(caseIndv.get("gender"));
		}
		appIndvCargo.setSrc_app_ind(srcAppInd);
		if (isprimIndv.equals("true")) {
			appIndvCargo.setPrim_prsn_sw(HouseHoldDemoGraphicsConstants.Y);
		} else {
			appIndvCargo.setPrim_prsn_sw(HouseHoldDemoGraphicsConstants.N);
		}
		return appIndvCargo;
	}

	/**
	 * Method to set details into CP_APP_PGM_INDV_Cargo
	 * 
	 * @param appNum, indvSeqNum, caseIndv
	 * @return CP_APP_PGM_INDV_Cargo
	 * @author ransahu
	 */
	private CP_APP_PGM_INDV_Cargo setAppPgmIndvDetails(String appNum, Integer indvSeqNum,
			Map<String, String> appPrgInd) {

		CP_APP_PGM_INDV_Cargo appPgmIndvCargo = new CP_APP_PGM_INDV_Cargo();
		appPgmIndvCargo.setApp_num(appNum);
		appPgmIndvCargo.setApp_pgm_indv_id(indvSeqNum.toString());
		appPgmIndvCargo.setIndv_seq_num(Double.valueOf(indvSeqNum));
		appPgmIndvCargo.setFs_rqst_ind(appPrgInd.get("fs_rqst_ind"));
		appPgmIndvCargo.setFma_rqst_ind(appPrgInd.get("fma_rqst_ind"));
		appPgmIndvCargo.setTanf_rqst_ind(appPrgInd.get("tanf_rqst_ind"));
		return appPgmIndvCargo;
	}

	/**
	 * Method to generate RMC Application data
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 * @throws ParseException
	 */

	private void generateApplicationDataForRMC(FwTransaction fwTransaction) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ReportChangeCenterServiceImpl.generateRMCApplicationData() - START");

		try {
			final Map pageCollection = fwTransaction.getPageCollection();
			generateAppNumAndStoreRMCApplicationData(fwTransaction, pageCollection);

		} catch (Exception exception) {			
			FwExceptionManager.handleException(exception, this.getClass().getName(), "generateRMCApplicationData",
					fwTransaction.getUserDetails().getAppNumber(), fwTransaction.getUserDetails().getLoginUserId(),
					true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ReportChangeCenterServiceImpl.generateRMCApplicationData() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

	}

	/**
	 * Method to store App Number, case name and form report type in CP_APP_REQUEST
	 * table
	 * 
	 * @param fwTransaction, formReportType
	 * @return String
	 * @author ransahu
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String storeAppNumInCpAppRequest(FwTransaction fwTransaction, String caseNum) {
		try {
			FwTransaction actualfwTransaction = fwTransaction;
			final Map pageCollection = actualfwTransaction.getPageCollection();
			String userID = "";
			if (Objects.nonNull(caseNum) && !caseNum.equals("")) {
				APP_RQST_Cargo appRqstCargo = new APP_RQST_Cargo();
				APP_RQST_Collection appRqstCollection = new APP_RQST_Collection();
				appRqstCargo.setCaseNum(caseNum);
				appRqstCargo.setFormRptType("RAC");
				appRqstCollection.add(appRqstCargo);
				pageCollection.put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, appRqstCollection);
			}

			/* Generating App Number and storing in CP_APP_REQUEST table */
			arTransactionManagedServImpl.loadRMBLanding(actualfwTransaction);
			final Map appNumPageCollection = fwTransaction.getPageCollection();
			String appNum = Objects.nonNull(appNumPageCollection.get(HouseHoldDemoGraphicsConstants.APP_NUM))
					? appNumPageCollection.get(HouseHoldDemoGraphicsConstants.APP_NUM).toString()
					: null;
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_NUM, appNum);
			fwTransaction.setPageCollection(pageCollection);

			UserDetails userDetail = fwTransaction.getUserDetails();
			if (userDetail.getLoginUserId() != null) {
				userID = userDetail.getLoginUserId();
				storeAppUserDetails(fwTransaction, appNum, userID);
			}
			return appNum;
		} catch (Exception e) {
			throw e;
		}
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadHouseHoldInfoDisabilityDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseHoldDemographicsServiceImpl.loadHouseHoldInfoDisabilityDetails() - START", fwTxn);

		try {

			final Map request = fwTxn.getRequest();
			final Map pageCollection = fwTxn.getPageCollection();
			String srcAppInd = HouseHoldDemoGraphicsConstants.EMPTY;
			String pageMode = null;
			Map beforeColl = new HashMap();
			Integer indvSeqNumber = null;
			String appNumber = null;
			Integer seqNum = null;
			/*
			 * final String appNumber = (String) session .get(AppConstants.APP_NUMBER);
			 */
			appNumber = fwTxn.getUserDetails().getAppNumber();
			indvSeqNumber = Integer.parseInt(
					fwTxn.getNextActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			seqNum = Integer.parseInt(
					fwTxn.getNextActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			Integer userEndInd = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getUserEndSelectionInd());
			request.put("loopingQuestion", FwConstants.NO);
			String fstName = fwTxn.getUserDetails().getFirstName();
			final String pageId = (String) request.get(FwConstants.CURRENT_PAGE_ID);
			final String previousPageId = (String) request.get(FwConstants.PREVIOUS_PAGE_ID);
			pageMode = (String) request.get(HouseHoldDemoGraphicsConstants.PAGE_MODE);

			// From app constants or hhdconstants create and add?

			// final String codeValues = AppConstants.DISABLED_BLIND;
			final Map disabilityTypeMap = new HashMap();
			// disabilityTypeMap.put(codeValues, codeValues);

			APP_IN_DABL_Collection rmcInDisColl = disabilityBo.loadIndividualDisabilityDetails(appNumber, indvSeqNumber,
					seqNum);

			String sourceAppIndicator = null;
			APP_IN_DABL_Cargo cargo = null;
			APP_IN_DABL_Collection coll = new APP_IN_DABL_Collection();
			if (rmcInDisColl != null && !rmcInDisColl.isEmpty() && rmcInDisColl.size() > 0) {
				int size = rmcInDisColl.size();
				if (size > 1) {
					sourceAppIndicator = AppConstants.RMC_MODIFIED_RECORD_IND;
					cargo = disabilityBo.splitDisabilityColl(rmcInDisColl, sourceAppIndicator);
				} else {
					sourceAppIndicator = AppConstants.CWW_RECORD_IND;
					cargo = disabilityBo.splitDisabilityColl(rmcInDisColl, sourceAppIndicator);

					if (cargo == null) {
						if (userEndInd == 1) {
							sourceAppIndicator = AppConstants.RMC_END_RECORD_IND;
							cargo = disabilityBo.splitDisabilityColl(rmcInDisColl, sourceAppIndicator);
						}
						if (cargo == null) {
							sourceAppIndicator = AppConstants.RMC_MODIFIED_RECORD_IND;
							cargo = disabilityBo.splitDisabilityColl(rmcInDisColl, sourceAppIndicator);
						}
						if (cargo == null) {
							sourceAppIndicator = AppConstants.RMC_NEW_RECORD_IND;
							cargo = disabilityBo.splitDisabilityColl(rmcInDisColl, sourceAppIndicator);
						}
					}
				}
				if (cargo != null) {
					cargo.setFts_nam(fstName);
				}
				coll.addCargo(cargo);

			} else {
				cargo = new APP_IN_DABL_Cargo();
				cargo.setFts_nam(fstName);
				coll.addCargo(cargo);

			}
			pageCollection.put("APP_IN_DABL_Collection", coll);

			if (coll != null && !coll.isEmpty()) {
				final APP_IN_DABL_Cargo appInDisCargo = coll.getCargo(0);
				if (appInDisCargo != null) {
					srcAppInd = appInDisCargo.getSrc_app_ind();
				}
			}
			if (("CW".equalsIgnoreCase(srcAppInd) || "RM".equalsIgnoreCase(srcAppInd)) && userEndInd == 0) {
				pageMode = "C";
			}

			if (cargo != null && "RE".equalsIgnoreCase(cargo.getSrc_app_ind())) {
				pageMode = "E";

			}
			if (userEndInd == 1 || "RE".equalsIgnoreCase(srcAppInd)) {
				pageMode = "E";
			} else if (!("C".equals(pageMode) || "E".equals(pageMode))) {
				pageMode = FwConstants.NO;
			}

			pageCollection.put("PAGE_MODE", pageMode);
			pageCollection.put(AppConstants.FIRST_NAME, fstName);
			pageCollection.put("DISABILITY_TYPE", seqNum);

			final APP_IN_DABL_Collection dablColl = (APP_IN_DABL_Collection) pageCollection
					.get("APP_IN_DABL_Collection");
			String showLoopingQuestionFlag = FwConstants.YES;
			pageCollection.put("showLoopingQuestion", showLoopingQuestionFlag);

			pageCollection.put(AppConstants.INDV_SEQUENCE_NUMBERS, indvSeqNumber);
			pageCollection.put(AppConstants.CURRENT_INDIV_SEQ_NUM, indvSeqNumber);
			String addnewPerson = HouseHoldDemoGraphicsConstants.EMPTY;

			fwTxn.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(),
					"loadHouseHoldInfoDisabilityDetails", fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseHoldDemographicsServiceImpl.loadHouseHoldInfoDisabilityDetails() - END", fwTxn);
	}

	public boolean checkBackToMyAccessSelected(final Map request) {
		try {
			if (request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON) == null) {
				return false;
			}
			final String reqWarningMsgs = (String) request.get(FwConstants.WARNING_MSG_DETAILS);
			if ((reqWarningMsgs != null) && (reqWarningMsgs.trim().length() > 0)) {
				// Tokenizing the request warrning message and putting into a
				// list
				final StringTokenizer tokenizer = new StringTokenizer(reqWarningMsgs,
						HouseHoldDemoGraphicsConstants.TILDE);
				final List reqMsgList = new ArrayList();
				while (tokenizer.hasMoreElements()) {
					reqMsgList.add(tokenizer.nextElement());
				}
				return true;
			}

			final FwMessageList messageList = new FwMessageList();
			final FwMessage message = new FwMessage();
			message.addMessageCode(HouseHoldDemoGraphicsConstants.MSG_30075);
			messageList.addMessageToList(message);
			request.put(FwConstants.MESSAGE_LIST, messageList);
			return true;
		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessageText());
			throw fe;
		}
	}

	/**
	 * fetchMovedOutIndvDetails method is used to store screen data of RMC applicant
	 * in APP_INDV table. After storing into DB table this method will send the
	 * APP_INDV Screen data back in the response.
	 * 
	 * @param txnBean
	 */
	@Transactional
	public void fetchMovedOutIndvDetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.fetchMovedOutIndvDetails() - START");
		try {
			APP_INDV_Collection finaAppIndvColl = new APP_INDV_Collection();
			APP_INDV_Collection appIndvColl = new APP_INDV_Collection();
			CP_APP_HSHL_RLT_Collection resRltHshlColl = null;
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();

			// Below block of code will retrieve the APP_INDV data for appnum so as to send
			// the data back in
			// the response. Setting the APP_INDV collection into pageCollection and front
			// code will access the pageCollection
			APP_INDV_Cargo[] appIndvArr = cpAppIndvRepository.loadIndvsLeftHome(Integer.parseInt(appNumber));
			APP_INDV_Cargo[] loadSummaryCargoArr = reportMyChangeBO.getAppIndvArrByAppNum(appNumber);
			if (null != appIndvArr && appIndvArr.length > 0) {
				for (APP_INDV_Cargo cargo : appIndvArr) {
					finaAppIndvColl.add(cargo);
				}
			}
			if (null != loadSummaryCargoArr && loadSummaryCargoArr.length > 0) {
				for (APP_INDV_Cargo cargo : loadSummaryCargoArr) {
					appIndvColl.add(cargo);
				}
			}

			resRltHshlColl = appHshlRltRepository.getByAppNum(Integer.parseInt(appNumber));
			if (null != resRltHshlColl && !resRltHshlColl.isEmpty()) {
				pageCollection.put(CPAPPHSHLRLTCOLL, resRltHshlColl);
			}
			if (!finaAppIndvColl.isEmpty()) {
				pageCollection.put(HouseHoldDemoGraphicsConstants.MOVED_OUT_COLLECTION, finaAppIndvColl);
			}
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvColl);
			txnBean.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "fetchMovedOutIndvDetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.fetchMovedOutIndvDetails() - END");
	}

	/**
	 * storeMovedOutIndvDetails method is used to store screen data of RMC applicant
	 * in APP_INDV table. After storing into DB table this method will send the
	 * APP_INDV Screen data back in the response.
	 * 
	 * @param txnBean
	 */
	@SuppressWarnings("squid:S3776")
	public void storeMovedOutIndvDetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.storeMovedOutIndvDetails() - START");
		try {
			String srcAppInd = HouseHoldDemoGraphicsConstants.APP_IND_AFB;
			final Map pageCollection = txnBean.getPageCollection();
			String appNumber = txnBean.getUserDetails().getAppNumber();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			CP_APP_HSHL_RLT_Collection rltColl = (CP_APP_HSHL_RLT_Collection) pageCollection.get(CPAPPHSHLRLTCOLL);
			CP_APP_HSHL_RLT_Cargo receivedHshlCargo = null;
			// Below block of code will populate the APP_INDV table with Screen data
			// received in txnbean.
			if (null != appIndvColl && !appIndvColl.isEmpty() && null != appIndvColl.getCargo(0)) {

				APP_INDV_Cargo receivedCargo = appIndvColl.getCargo(0);
				//String appNumber = receivedCargo.getApp_num();
				int indvSeqNum = receivedCargo.getIndv_seq_num();

				if (null != rltColl && !rltColl.isEmpty() && null != rltColl.getCargo(0)
						&& null != rltColl.getCargo(0).getApp_num()) {
					receivedHshlCargo = rltColl.getCargo(0);

				}

				if (null != receivedCargo.getMovedout_other_ind()
						&& receivedCargo.getMovedout_other_ind().equalsIgnoreCase("Y")) {

					if (null != receivedCargo) {
						receivedCargo.setApp_num(appNumber);
						receivedCargo.setSrc_app_ind(srcAppInd);
						//set update date
						Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
						receivedCargo.setUpdate_dt(currentTimeStamp);
						cpAppIndvRepository.save(receivedCargo);

					}
					if (null != receivedHshlCargo) {
						receivedHshlCargo.setSrcAppIndiv(srcAppInd);
						if (receivedHshlCargo.getRltCd() == null
								|| FwConstants.EMPTY_STRING.equalsIgnoreCase(receivedHshlCargo.getRltCd())) {
							receivedHshlCargo.setRltCd(FwConstants.SPACE);
						}
						appHshlRltRepository.save(receivedHshlCargo);
					}

				} else {

					APP_INDV_Cargo appIndvcargo = cpAppIndvRepository
							.getAppIndvCargoByAppNumIndvSeqSrcAppInd(Integer.parseInt(appNumber), indvSeqNum);
					if (null != appIndvcargo) {
						if (null != receivedCargo.getLeft_home_dt()) {
							appIndvcargo.setLeft_home_dt(receivedCargo.getLeft_home_dt());
						}
						if (null != receivedCargo.getMovedout_other_ind()) {
							appIndvcargo.setMovedout_other_ind(receivedCargo.getMovedout_other_ind());
						}

						if (null != receivedCargo.getMove_out_ind()) {
							appIndvcargo.setMove_out_ind(receivedCargo.getMove_out_ind());
						}
						//set update date
						Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
						appIndvcargo.setUpdate_dt(currentTimeStamp);
						cpAppIndvRepository.save(appIndvcargo);

						if (null != receivedHshlCargo) {
							List<CP_APP_HSHL_RLT_Cargo> list = appHshlRltRepository.findByAppNumSrcRefIndvSeqNum(
									Integer.parseInt(receivedHshlCargo.getApp_num()), receivedHshlCargo.getSrcIndvSeqNum(),
									receivedHshlCargo.getRefIndvSeqNum());

							if (null != list && !list.isEmpty()) {
								CP_APP_HSHL_RLT_Cargo dBHshlcargo = list.get(0);
								if (null != receivedHshlCargo.getPnp_tghr_sw()) {
									dBHshlcargo.setPnp_tghr_sw(receivedHshlCargo.getPnp_tghr_sw());
									dBHshlcargo.setSrcAppIndiv(srcAppInd);
									appHshlRltRepository.save(dBHshlcargo);
								}

							}else {
								receivedHshlCargo.setApp_num(appNumber);	
								receivedHshlCargo.setSrcAppIndiv(srcAppInd);
								if (receivedHshlCargo.getRltCd() == null
										|| FwConstants.EMPTY_STRING.equalsIgnoreCase(receivedHshlCargo.getRltCd())) {
									receivedHshlCargo.setRltCd(FwConstants.SPACE);
								}
								appHshlRltRepository.save(receivedHshlCargo);
							}
						}

					}
				}

			}

		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeMovedOutIndvDetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.storeMovedOutIndvDetails() - END");
	}
	@SuppressWarnings("squid:S3776")
	public void removeMovedOutIndvDetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.removeMovedOutIndvDetails() - START");
		try {
			final Map pageCollection = txnBean.getPageCollection();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			CP_APP_HSHL_RLT_Collection rltColl = null;
			Integer indvId = (Integer) pageCollection.get(INDV_ID);
			if (pageCollection.get(CPAPPHSHLRLTCOLL) instanceof CP_APP_HSHL_RLT_Collection) {
				rltColl = (CP_APP_HSHL_RLT_Collection) pageCollection.get(CPAPPHSHLRLTCOLL);
			}
			CP_APP_HSHL_RLT_Cargo receivedHshlCargo = null;
			APP_INDV_Cargo receivedCargo = new APP_INDV_Cargo();
			if (null != appIndvColl && !appIndvColl.isEmpty()) {
				for (int i = 0; i < appIndvColl.size(); i++) {
					if (appIndvColl.getCargo(i).getIndv_seq_num().equals(indvId)) {
						receivedCargo = appIndvColl.getCargo(i);
						break;
					}
				}
				if (null != rltColl && !rltColl.isEmpty()) {
					for (int j = 0; j < rltColl.size(); j++) {
						if (rltColl.getCargo(j).getRefIndvSeqNum().equals(indvId)) {
							receivedHshlCargo = rltColl.getCargo(j);
							break;
						}
					}
				}

				reportMyChangeBO.removeMovedOutIndvDetails(receivedCargo, receivedHshlCargo);

			}

		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "removeMovedOutIndvDetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.removeMovedOutIndvDetails() - END");
	}
	@SuppressWarnings("squid:S3776")
	public void storeHouseHoldInfoDisabilityDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseHoldDemographicsServiceImpl.storeHouseHoldInfoDisabilityDetails() - START", fwTxn);
		final long startTime = System.currentTimeMillis();
		String appNumber = fwTxn.getUserDetails().getAppNumber();
		Integer indvSeqNumber = Integer.parseInt(
				fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
		Integer seqNum = Integer
				.parseInt(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
		final Map request = fwTxn.getRequest();
		final Map pageCollection = fwTxn.getPageCollection();
		APP_IN_DABL_Collection beforeAppInDablCollection = null;
		APP_IN_DABL_Collection appInDablCollection = null;
		final APP_IN_DABL_Cargo beforeAppInDablCargo = null;
		APP_IN_DABL_Cargo beforeDablCargo = null;
		FwMessageList validateInfo = new FwMessageList();
		String pageMode = (String) request.get(HouseHoldDemoGraphicsConstants.PAGE_MODE);
		try {
			final String currentPageID = (String) request.get(FwConstants.CURRENT_PAGE_ID);

			beforeAppInDablCollection = disabilityBo.loadDisabilityDetails(appNumber, indvSeqNumber, seqNum);

			final APP_IN_DABL_Collection dablColl = (APP_IN_DABL_Collection) pageCollection
					.get("APP_IN_DABL_Collection");
			APP_IN_DABL_Cargo appInDablCargo = new APP_IN_DABL_Cargo();

			if (dablColl != null && !dablColl.isEmpty()) {
				appInDablCargo = dablColl.getResult(0);
			}
			String showLoopingQuestion = (String) request.get("showLoopingQuestion");
			final String backToMyAccess = (String) request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON);
			validateInfo = disabilityBo.validateDisablityDetail1(appInDablCargo, showLoopingQuestion);

			if (checkBackToMyAccessSelected(request) || validateInfo != null && validateInfo.hasMessages()) {

				if (backToMyAccess == null) {
					request.put(FwConstants.MESSAGE_LIST, validateInfo);
				}
				return;
			}

			String recordInd = null;
			String sourceAppIndicator = null;
			// Boolean disabilityDetailsUpdate = false;

			appInDablCargo.setApp_num(appNumber);
			appInDablCargo.setIndv_seq_num(indvSeqNumber);
			appInDablCargo.setSeq_num(seqNum);

			if (beforeAppInDablCollection != null && !beforeAppInDablCollection.isEmpty()) {
				final int size = beforeAppInDablCollection.size();

				if ("C".equalsIgnoreCase(pageMode)) {
					sourceAppIndicator = AppConstants.RMC_MODIFIED_RECORD_IND;
				} else if ("E".equalsIgnoreCase(pageMode)) {
					sourceAppIndicator = AppConstants.RMC_END_RECORD_IND;
				} else {
					sourceAppIndicator = AppConstants.RMC_NEW_RECORD_IND;
				}

				beforeDablCargo = disabilityBo.splitDisabilityColl(beforeAppInDablCollection, sourceAppIndicator);

				if (beforeDablCargo == null && (AppConstants.RMC_MODIFIED_RECORD_IND.equals(sourceAppIndicator)
						|| AppConstants.RMC_END_RECORD_IND.equals(sourceAppIndicator))) {
					beforeDablCargo = disabilityBo.splitDisabilityColl(beforeAppInDablCollection,
							AppConstants.CWW_RECORD_IND);
				}

				if (size > 1) {
					// if we have two records means cw and rm or cw and re
					// now we are getting RM/RE record to compare
					// now we need to update the data base if it dirty
					recordInd = FwConstants.ROWACTION_UPDATE;
				} else {
					// now we are checking this record is CW or RN
					recordInd = FwConstants.ROWACTION_INSERT;
					if (AppConstants.RMC_NEW_RECORD_IND.equals(sourceAppIndicator) && beforeDablCargo != null) {
						recordInd = FwConstants.ROWACTION_UPDATE;
					} else if (AppConstants.RMC_END_RECORD_IND.equals(sourceAppIndicator) && beforeDablCargo != null
							&& !beforeDablCargo.getSrc_app_ind().equals(AppConstants.CWW_RECORD_IND)) {
						recordInd = FwConstants.ROWACTION_UPDATE;
					}
				}

				if (beforeDablCargo != null) {

					appInDablCargo.setEcp_id(beforeDablCargo.getEcp_id());
					appInDablCargo.setSeq_num(beforeDablCargo.getSeq_num());

					if (beforeDablCargo.getNo_long_caring_disabled_resp() != null) {
						appInDablCargo
								.setNo_long_caring_disabled_resp(beforeDablCargo.getNo_long_caring_disabled_resp());
					} else {
						appInDablCargo.setNo_long_caring_disabled_resp(AppConstants.PROGRAM_NOT_SELECTED);
					}

					if (beforeDablCargo.getIrwe_sw() != null && beforeDablCargo.getIrwe_sw().trim().length() > 0) {
						appInDablCargo.setIrwe_sw(beforeDablCargo.getIrwe_sw());
					} else {
						appInDablCargo.setIrwe_sw(FwConstants.SPACE);
					}

				} else {
					final APP_IN_DABL_Cargo beforeCargo = beforeAppInDablCollection.getCargo(0);
					appInDablCargo.setEcp_id(beforeCargo.getEcp_id());
				}

				appInDablCargo.setSrc_app_ind(sourceAppIndicator);

			} else {
				if ("C".equalsIgnoreCase(pageMode)) {
					appInDablCargo.setSrc_app_ind(AppConstants.RMC_MODIFIED_RECORD_IND);
				} else if ("E".equalsIgnoreCase(pageMode)) {
					appInDablCargo.setSrc_app_ind(AppConstants.RMC_END_RECORD_IND);
				} else {
					appInDablCargo.setSrc_app_ind(AppConstants.RMC_NEW_RECORD_IND);
				}
				appInDablCargo.setIndv_seq_num(indvSeqNumber);
				appInDablCargo.setApp_num(appNumber);
				seqNum = disabilityBo.getMaxDisabilitySeqNumber(appNumber, indvSeqNumber);
				seqNum = seqNum + 1;
				appInDablCargo.setSeq_num(seqNum);
				recordInd = FwConstants.ROWACTION_INSERT;
				appInDablCargo.setRowAction(recordInd);

			}
			if (!"RN".equals(appInDablCargo.getSrc_app_ind()) && !"RE".equals(appInDablCargo.getSrc_app_ind())) {
				appInDablCargo.setSrc_app_ind("RM");
			}

			disabilityBo.storeDisabilityDetails(dablColl);
			boolean loopingQuestion = false;

		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(),
					"storeHouseHoldInfoDisabilityDetails", fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.storeHouseHoldInfoDisabilityDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void storeAppUserDetails(FwTransaction fwTransaction, String applicationNum, String userId) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseHoldDemographicsServiceImpl.storeAppUserDetails() - START");
		FwTransaction actualfwTransaction = fwTransaction;
		final Map pageCollection = actualfwTransaction.getPageCollection();
		try {
			String appNum = applicationNum;
			String gUID = userId;
			CpAppUserCargo cpAppUserCargo;
			CpAppUserCargoKey cpAppUserCargoKey;

			if (appNum != null && !appNum.isEmpty() && gUID != null && !gUID.isEmpty()) {
				cpAppUserCargo = new CpAppUserCargo();
				cpAppUserCargoKey = new CpAppUserCargoKey();
				cpAppUserCargoKey.setAcsId(gUID);
				cpAppUserCargoKey.setAppNum(Integer.parseInt(appNum));
				cpAppUserCargo.setId(cpAppUserCargoKey);
				cpAppUserRepository.save(cpAppUserCargo);
				pageCollection.put("CP_APP_USER", cpAppUserCargo);
				fwTransaction.setPageCollection(pageCollection);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RMCHouseHoldDemographicsServiceImpl.storeAppUserDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessageText());
			throw fe;
		} catch (Exception e) {
			throw e;
		}

	}

	/**
	 * rmcSavePassedAwayInfo method is used to store passed away data of RMC
	 * applicant in APP_INDV table. After storing into DB table this method will
	 * send the APP_INDV data back in the response to display passws away
	 * individuals on Passed Away Summary screen.
	 * 
	 * @param txnBean
	 */
	@SuppressWarnings("squid:S3776")
	public void rmcSavePassedAwayInfo(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcSavePassedAwayInfo() - START");
		try {
			APP_INDV_Cargo appIndvCargo = null;
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			CP_APP_HSHL_RLT_Cargo receivedHshlCargo = null;
			CP_APP_HSHL_RLT_Collection rltColl = null;
			if (pageCollection.get(CPAPPHSHLRLTCOLL) instanceof CP_APP_HSHL_RLT_Collection) {
				rltColl = (CP_APP_HSHL_RLT_Collection) pageCollection.get(CPAPPHSHLRLTCOLL);
			}

			// Below block of code will populate the APP_INDV table with passed away data
			// received in txnbean.
			if (null != appIndvColl && !appIndvColl.isEmpty()) {
				appIndvCargo = reportMyChangeBO.getAppIndvByAppNumIndvSeqNum(String.valueOf(appNumber),
						appIndvColl.getCargo(0).getIndv_seq_num());
				int indvSeqNum = appIndvColl.getCargo(0).getIndv_seq_num();
				if (null == appIndvCargo) {
					appIndvCargo = appIndvColl.getCargo(0);
					appIndvCargo.setApp_num(appNumber);
					appIndvCargo.setIndv_seq_num(appIndvColl.getCargo(0).getIndv_seq_num());
					appIndvCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
				}
				appIndvCargo.setDecease_dt(appIndvColl.getCargo(0).getDecease_dt());
				appIndvCargo.setDeceased_ind(FwConstants.YES);
				reportMyChangeBO.saveAppIndvCargo(appIndvCargo);
				if (null != rltColl && !rltColl.isEmpty() && null != rltColl.getCargo(0)) {
					receivedHshlCargo = rltColl.getCargo(0);
					List<CP_APP_HSHL_RLT_Cargo> list = appHshlRltRepository.findByAppNumRefIndvSeqNum(Integer.parseInt(appNumber),
							indvSeqNum);

					if (null != list && !list.isEmpty()) {
						CP_APP_HSHL_RLT_Cargo dBHshlcargo = list.get(0);
						if (receivedHshlCargo.getRltCd() != null)
							dBHshlcargo.setRltCd(receivedHshlCargo.getRltCd());
						else
							dBHshlcargo.setRltCd(FwConstants.SPACE);
						appHshlRltRepository.save(dBHshlcargo);
					} else {
						receivedHshlCargo.setApp_num(appNumber);
						receivedHshlCargo.setRefIndvSeqNum(indvSeqNum);
						receivedHshlCargo.setSrcIndvSeqNum(1);
						receivedHshlCargo.setSrcAppIndiv(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
						if (receivedHshlCargo.getRltCd() == null
								|| FwConstants.EMPTY_STRING.equalsIgnoreCase(receivedHshlCargo.getRltCd()))
							receivedHshlCargo.setRltCd(FwConstants.SPACE);
						appHshlRltRepository.save(receivedHshlCargo);
					}
				}
			}
			// Below block of code will retrieve the APP_INDV data for appnum so as to send
			// the list of passed away data back in
			// the response. Setting the APP_INDV collection into pageCollection and passed
			// away list will be displayed on Passed Away Summary screen
			rmcLoadPassedAwayInfo(txnBean);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcSavePassedAwayInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcSavePassedAwayInfo() - END");
	}

	public void rmcRemovePassedAwayInfo(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcRemovePassedAwayInfo() - START");
		Integer indvSeqNumber = null;
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();
			final Map pageCollection = fwTxn.getPageCollection();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			indvSeqNumber = reportMyChangeBO.getIntValue(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			if (null != appIndvColl && !appIndvColl.isEmpty()) {
				if (reportMyChangeBO.isStringEmptyOrNull(appNum)) {
					appNum = appIndvColl.getCargo(0).getApp_num();
				}
				if (null == indvSeqNumber) {
					indvSeqNumber = appIndvColl.getCargo(0).getIndv_seq_num();
				}
			}
			reportMyChangeBO.removePassedAwayInfo(appNum, indvSeqNumber);
			rmcLoadPassedAwayInfo(fwTxn);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcRemovePassedAwayInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcRemovePassedAwayInfo() - END");
	}

	private void rmcLoadPassedAwayInfo(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.rmcLoadPassedAwayInfo() - Start");
		try {
			APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
			APP_INDV_Collection deceasedColl = new APP_INDV_Collection();
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();

			APP_INDV_Cargo[] updatedAppIndvArr = reportMyChangeBO.getAppIndvArrByAppNum(String.valueOf(appNumber));
			String pageId = fwTxn.getCurrentActionDetails().getPageId();
			if ("MCDCS".equals(pageId)) {
				processMCPassawayDetails(appIndvCollection, pageCollection, updatedAppIndvArr);
			} else {
				processRMCPassedAwayDetails(appIndvCollection, deceasedColl, pageCollection, appNumber,
						updatedAppIndvArr);
			}
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcLoadPassedAwayInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.rmcLoadPassedAwayInfo() - END");

	}

	private void processRMCPassedAwayDetails(APP_INDV_Collection appIndvCollection, APP_INDV_Collection deceasedColl,
			Map pageCollection, String appNumber, APP_INDV_Cargo[] updatedAppIndvArr) {
		// Below block of code will retrieve the APP_INDV data for appnum so as to send
		// the list of passed away data back in
		// the response. Setting the APP_INDV collection into pageCollection and passed
		// away list will be displayed on Passed Away Summary screen
		if (null != updatedAppIndvArr && updatedAppIndvArr.length > 0) {
			for (APP_INDV_Cargo cargo : updatedAppIndvArr) {
				if (null != cargo.getDeceased_ind()
						&& cargo.getDeceased_ind().equalsIgnoreCase(FwConstants.YES)) {
					int age = LocalDate.now().minus(Period.of(cargo.getBrth_dt().getYear(),
							cargo.getBrth_dt().getMonth(), cargo.getBrth_dt().getDate())).getYear() - 1900;
					if (age < 0) {
						age = 0;
					}
					cargo.setDescription_passedaway(
							cargo.getFst_nam() + " " + cargo.getLast_nam() + " (" + age + ")");
					deceasedColl.add(cargo);
				}
				appIndvCollection.add(cargo);
			}
		}
		CP_APP_HSHL_RLT_Collection resRltHshlColl = null;
		resRltHshlColl = appHshlRltRepository.getByAppNum(Integer.parseInt(appNumber));
		if (null != resRltHshlColl && !resRltHshlColl.isEmpty()) {
			pageCollection.put(CPAPPHSHLRLTCOLL, resRltHshlColl);
		}
		if (!appIndvCollection.isEmpty()) {

			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
		}
		pageCollection.put("PASSED_AWAY_Collection", deceasedColl);
	}

	private void processMCPassawayDetails(APP_INDV_Collection appIndvCollection, Map pageCollection,
			APP_INDV_Cargo[] updatedAppIndvArr) throws JsonProcessingException, JsonMappingException {
		if (Objects.nonNull(updatedAppIndvArr) && updatedAppIndvArr.length > 0) {
			for (APP_INDV_Cargo existingAppIndvCargo : Arrays.asList(updatedAppIndvArr)) {
				String calsawsObject = existingAppIndvCargo.getCalsawsObject();
				if (Objects.nonNull(calsawsObject)) {
					CaseIndividualDetails caseIndividual = new ObjectMapper().readValue(calsawsObject,
							CaseIndividualDetails.class);
					if (Objects.nonNull(caseIndividual.getPassedAwayDetail())
							&& caseIndividual.getPassedAwayDetail().isDeceasedInd()) {
						appIndvCollection.add(existingAppIndvCargo);
					}
				}
			}
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
		}
	}

	public void rmcSaveHomeOrMailingAddrInfo(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.rmcSaveHomeOrMailingAddrInfo() - START");
		CP_APP_RGST_Cargo receivedRgstCargo = null;
		CP_APP_RGST_Collection appRgstCollToSave = null;
		Integer indvSeqNumOnPersonSelScreen = 0;
		List<Integer> indvSeqListSelectedinBscreen = new ArrayList<>();
		try {
			final Map pageCollection = txnBean.getPageCollection();
			String appNumber = txnBean.getUserDetails().getAppNumber();
			final String pageId = txnBean.getCurrentActionDetails().getPageId();
			CP_APP_RGST_Collection appRgstColl = (CP_APP_RGST_Collection) pageCollection.get(CPAPPRGSTCOLL);

			if (null != appRgstColl && !appRgstColl.isEmpty()) {
				receivedRgstCargo = appRgstColl.getCargo(0);
				indvSeqNumOnPersonSelScreen = receivedRgstCargo.getIndv_seq_num();
				indvSeqListSelectedinBscreen = receivedRgstCargo.getIndvSeqList();
				indvSeqListSelectedinBscreen = null != indvSeqListSelectedinBscreen ? indvSeqListSelectedinBscreen
						: new ArrayList<>();
				if (null != indvSeqNumOnPersonSelScreen) {
					indvSeqListSelectedinBscreen.add(indvSeqNumOnPersonSelScreen);
				}
			}

			if (null != receivedRgstCargo && !indvSeqListSelectedinBscreen.isEmpty()) {
				appRgstCollToSave = new CP_APP_RGST_Collection();
				for (int indvSeqNum : indvSeqListSelectedinBscreen) {
					if (indvSeqNum > 0) {
						
						//set update date
						Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
						receivedRgstCargo.setUpdate_dt(currentTimeStamp);
						
						appRgstCollToSave.add(reportMyChangeBO.populateHomeOrMailingDtls(appNumber, pageId, indvSeqNum,
								receivedRgstCargo));
					}
				}

				reportMyChangeBO.saveAllRgstCargos(appRgstCollToSave);

			}

			// Below block of code will retrieve the CP_APP_RGST data for appnum so as to
			// send the list of home, mailing address details back in
			// the response. Setting the APP_RGST collection into pageCollection and home
			// ,mailing address details list will be displayed on
			// Home address, Mailing address Summary screens respectively

			rmcLoadMailingOrHomeAddrInfo(txnBean);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcSaveHomeOrMailingAddrInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.rmcSaveHomeOrMailingAddrInfo() - END");
	}

	/*
	 * This method loads the New Born Baby details from
	 * CP_APP_INDV,CP_APP_HSHL_RLT_Cargo tables
	 */
	public void loadNewBornIndvDetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.loadNewBornIndvDetails() - START");
		try {
			APP_INDV_Collection finaSummaryAppIndvColl = new APP_INDV_Collection();
			APP_IN_NEWB_Collection finalNewBornColl = new APP_IN_NEWB_Collection();
			APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();

			APP_INDV_Cargo[] loadSummaryCargoArr = reportMyChangeBO.getAppIndvArrByAppNum(appNumber);
			if (null != loadSummaryCargoArr && loadSummaryCargoArr.length > 0) {
				for (APP_INDV_Cargo cargo : loadSummaryCargoArr) {
					if (null != cargo.getNew_born_ind() && cargo.getNew_born_ind().equalsIgnoreCase("Y")) {
						Date fwDate = FwDate.getInstance().getDate();
						LocalDate today = fwDate.toLocalDate();
						java.util.Date utilDate = new java.util.Date(cargo.getBrth_dt().getTime());
						long months = ChronoUnit.MONTHS
								.between(utilDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate(), today);
						cargo.setBornBabyMonths(months);
						finaSummaryAppIndvColl.add(cargo);
						// get details by appNum and baby indvSeqNum
					}
					appIndvCollection.add(cargo);
				}
				finalNewBornColl = reportMyChangeBO.getNewBornInfoByAppNum(appNumber);
			}
			
			if (!appIndvCollection.isEmpty()) {
				pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
			}
			pageCollection.put("APP_INDV_NEW_BORN_Collection", finaSummaryAppIndvColl);
			pageCollection.put("APP_IN_NEWB_Collection", finalNewBornColl);
			txnBean.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadNewBornIndvDetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.loadNewBornIndvDetails() - END");
	}
	@SuppressWarnings({"squid:S3776","squid:S117"})
	public void storeBabyInfoDetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.storeBabyInfoDetails() - START");
		try {

			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			Integer seq_num = null;

			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);

			List<Integer> parent_indvs = (ArrayList) pageCollection.get("parent_seq_num");

			CP_APP_HSHL_RLT_Collection rltColl = (CP_APP_HSHL_RLT_Collection) pageCollection.get(CPAPPHSHLRLTCOLL);
			APP_IN_NEWB_Collection babyBornColl = (APP_IN_NEWB_Collection) pageCollection.get("APP_IN_NEWB_Collection");

			APP_IN_NEWB_Collection finalNewBornColl = new APP_IN_NEWB_Collection();
			APP_INDV_Cargo appIndvCargo = null;

			for (APP_INDV_Cargo cargo : appIndvColl.getResults()) {

				seq_num = cargo.getIndv_seq_num();

				appIndvCargo = reportMyChangeBO.getAppIndvByAppNumIndvSeqSrcAppInd(String.valueOf(appNumber),
						cargo.getIndv_seq_num());
				if (null == appIndvCargo) {
					appIndvCargo = cargo;
				} else {
					APP_INDV_Cargo recvdCargo = cargo;
					appIndvCargo.setFst_nam(recvdCargo.getFst_nam());
					appIndvCargo.setMid_init(recvdCargo.getMid_init());
					appIndvCargo.setLast_nam(recvdCargo.getLast_nam());
					appIndvCargo.setSuffix_name(recvdCargo.getSuffix_name());
					appIndvCargo.setAlias_oth_nam(recvdCargo.getAlias_oth_nam());
					appIndvCargo.setBrth_dt(recvdCargo.getBrth_dt());

				}
				appIndvCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
				appIndvCargo.setNew_born_ind("Y");
				reportMyChangeBO.saveAppIndvCargo(appIndvCargo);

			}

			if (null != rltColl && !rltColl.isEmpty()) {
				if (null == rltColl.getCargo(0).getApp_num() || rltColl.getCargo(0).getApp_num().isEmpty()) {
					rltColl.getCargo(0).setApp_num(appNumber);
				}
				rltColl.getCargo(0).setRefIndvSeqNum(seq_num);
				storeRelationDetails(rltColl.getCargo(0));
			}

			APP_IN_NEWB_Cargo babyBornRecvdCargo = new APP_IN_NEWB_Cargo();
			if (null != babyBornColl && !babyBornColl.isEmpty()) {
				babyBornRecvdCargo = babyBornColl.getCargo();

			}

			babyBornRecvdCargo.setAppNum(appNumber);
			babyBornRecvdCargo.setIndvSeqNum(seq_num);
			if (null != parent_indvs && !parent_indvs.isEmpty()) {
				if (!String.valueOf(parent_indvs.get(0)).equalsIgnoreCase("-1")) {
					babyBornRecvdCargo.setParentOneIndvSeqNum(Integer.valueOf(String.valueOf(parent_indvs.get(0))));

				}
				if (parent_indvs.size() > 1 && !(String.valueOf(parent_indvs.get(1)).equalsIgnoreCase("-1"))) {
					babyBornRecvdCargo.setParentTwoIndvSeqNum(Integer.valueOf(String.valueOf(parent_indvs.get(1))));

				}

			}

			APP_IN_NEWB_Cargo babyBornDbCargo = null;
			babyBornDbCargo = reportMyChangeBO.getNewBornInfoByAppNumInfoId(babyBornRecvdCargo.getAppNum(),
					seq_num.toString());
			if (null != babyBornDbCargo) {
				babyBornDbCargo.setParentOneIndvSeqNum(babyBornRecvdCargo.getParentOneIndvSeqNum());
				babyBornDbCargo.setParentTwoIndvSeqNum(babyBornRecvdCargo.getParentTwoIndvSeqNum());
				babyBornDbCargo.setSomeoneElseParFrstName(babyBornRecvdCargo.getSomeoneElseParFrstName());
				babyBornDbCargo.setSomeoneElseParLstName(babyBornRecvdCargo.getSomeoneElseParLstName());
				babyBornDbCargo.setSomeoneElseParTwoFrstName(babyBornRecvdCargo.getSomeoneElseParTwoFrstName());
				babyBornDbCargo.setSomeoneElseParTwoLstName(babyBornRecvdCargo.getSomeoneElseParTwoLstName());
				babyBornDbCargo = reportMyChangeBO.saveNewBornInfo(babyBornDbCargo);
				finalNewBornColl.add(babyBornDbCargo);
			} else {
				babyBornRecvdCargo.setNewBornInfoId(seq_num.toString());
				babyBornRecvdCargo = reportMyChangeBO.saveNewBornInfo(babyBornRecvdCargo);
				finalNewBornColl.add(babyBornRecvdCargo);
			}

			txnBean.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeBabyInfoDetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.storeBabyInfoDetails() - END");
	}

	public void removeBabyInfoDetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.removeBabyInfoDetails() - START");
		try {

			final Map pageCollection = txnBean.getPageCollection();

			APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
			APP_IN_NEWB_Cargo babyBornDbCargo = null;
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			Integer indvSeqNum = (Integer) pageCollection.get(INDV_ID);
			appIndvCargo.setApp_num(appNumber);
			appIndvCargo.setIndv_seq_num(indvSeqNum);
			appIndvCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
			babyBornDbCargo = reportMyChangeBO.getNewBornInfoByAppNumIndvSeqNum(appNumber, indvSeqNum);
			if (null != babyBornDbCargo) {
				reportMyChangeBO.deleteNewBornDetails(babyBornDbCargo);
			}

			List<CP_APP_HSHL_RLT_Cargo> list = reportMyChangeBO.getHshlRltArrByAppNumRefIndv(appNumber, indvSeqNum);
			if (null != list && !list.isEmpty()) {
				reportMyChangeBO.deleteAppHshlRltCargo(list.get(0));
			}
			reportMyChangeBO.deleteAppIndvCargo(appIndvCargo);

			txnBean.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "removeBabyInfoDetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.removeBabyInfoDetails() - END");
	}

	public CP_APP_HSHL_RLT_Cargo fetchRelationDetails(String appNum, Integer refIndvSeqnum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "fetchRelationDetails() - START");
		CP_APP_HSHL_RLT_Cargo dBHshlcargo = null;
		try {
			// get details by appnum and childseqnum
			List<CP_APP_HSHL_RLT_Cargo> list = reportMyChangeBO.getHshlRltArrByAppNumRefIndv(appNum, refIndvSeqnum);
			if (null != list && !list.isEmpty()) {
				dBHshlcargo = list.get(0);
			}

		} catch (FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "fetchRelationDetails() - END");
		return dBHshlcargo;
	}

	public CP_APP_HSHL_RLT_Cargo storeRelationDetails(CP_APP_HSHL_RLT_Cargo cargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "storeRelationDetails() - START");

		String srcAppInd = HouseHoldDemoGraphicsConstants.RMC_SRC_APP_IND;
		CP_APP_HSHL_RLT_Cargo dBHshlcargo = null;
		try {
			List<CP_APP_HSHL_RLT_Cargo> list = reportMyChangeBO.getHshlRltArrByAppSrcRefIndv(cargo);
			if (null != list && !list.isEmpty()) {
				dBHshlcargo = list.get(0);
			}

			if (null == dBHshlcargo) {
				dBHshlcargo = cargo;
			}
			dBHshlcargo.setRltCd(cargo.getRltCd());
			dBHshlcargo.setSrcAppIndiv(srcAppInd);
			reportMyChangeBO.saveAppHshlRltCargo(dBHshlcargo);

		} catch (FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "storeRelationDetails() - END");
		return dBHshlcargo;
	}

	public void getMaritalStatusDetail(final FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.getMaritalStatusDetail() - START");
		try {
			final Map<String, Object> pageColl = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
			APP_INDV_Collection appIndvMrtlCollection = new APP_INDV_Collection();
			APP_INDV_Collection updatedAppIndvArr = reportMyChangeBO.loadActiveIndvdtl(String.valueOf(appNum));
			if (null != updatedAppIndvArr) {
				for (Iterator iterator = updatedAppIndvArr.iterator(); iterator.hasNext();) {
					APP_INDV_Cargo cargo = (APP_INDV_Cargo) iterator.next();
					if (null != cargo.getMrtl_stat_cd()
							&& (null == cargo.getNew_born_ind() || !(cargo.getNew_born_ind().equalsIgnoreCase("Y")))
							&& (null == cargo.getMove_in_ind() || !(cargo.getMove_in_ind().equalsIgnoreCase("Y")))) {
						appIndvMrtlCollection.add(cargo);
					}
					appIndvCollection.add(cargo);
				}
			}

			pageColl.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);

			if (!appIndvMrtlCollection.isEmpty()) {
				pageColl.put(HouseHoldDemoGraphicsConstants.MARITAL_COLLECTION, appIndvMrtlCollection);
			}

			fwTxn.setPageCollection(pageColl);

		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getMaritalStatusDetail",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.getMaritalStatusDetail() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);
	}

	public void deleteMrtlDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.deleteMrtlDetails() - START");
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer indivSeqNumInt = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			APP_INDV_Cargo appIndvCargo = reportMyChangeBO.getAppIndvByAppNumIndvSeqSrcAppInd(appNum, indivSeqNumInt);
			if (Objects.nonNull(appIndvCargo) && appIndvCargo.getMrtl_stat_cd() != null
					&& !appIndvCargo.getMrtl_stat_cd().equals("")) {
				appIndvCargo.setMrtl_stat_cd(FwConstants.EMPTY_STRING);
				appIndvCargo.setMrtl_eff_dt(null);
				reportMyChangeBO.saveAppIndvCargo(appIndvCargo);
			}
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteMrtlDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.deleteMrtlDetails() - END");
	}

	public void rmcClearHomeOrMailingAddrInfo(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.rmcClearHomeOrMailingAddrInfo() - START");
		Integer indvSeqNumber = null;
		try {
			final Map pageCollection = txnBean.getPageCollection();
			String appNumber = txnBean.getUserDetails().getAppNumber();
			String pageId = txnBean.getCurrentActionDetails().getPageId();
			if (null == pageId || pageId.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.RCHAS)) {
				pageId = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			}
			CP_APP_RGST_Collection appRgstColl = (CP_APP_RGST_Collection) pageCollection.get(CPAPPRGSTCOLL);
			indvSeqNumber = reportMyChangeBO.getIntValue(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			// Below if block will loop through indv seq nums received from FE when remove
			// button is clicked on summary screen.
			// Will update Mailing addr details to empty when remove button is clicked on
			// Mailing summary screen and
			// Home address details to empty when remove button is clicked on Home address
			// summary screen
			if (null != appRgstColl && !appRgstColl.isEmpty()) {
				if (reportMyChangeBO.isStringEmptyOrNull(appNumber)) {
					appNumber = appRgstColl.getCargo(0).getApp_num();
				}
				if (null == indvSeqNumber) {
					indvSeqNumber = appRgstColl.getCargo(0).getIndv_seq_num();
				}
			}

			reportMyChangeBO.clearRmcHomeOrMailingAddress(appNumber, pageId, indvSeqNumber);

			// Below block of code will retrieve the CP_APP_RGST data for appnum so as to
			// send the list of home, mailing address details back in
			// the response. Setting the APP_RGST collection into pageCollection and home
			// ,mailing address details list will be displayed on
			// Home address, Mailing address Summary screens respectively

			rmcLoadMailingOrHomeAddrInfo(txnBean);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcClearHomeOrMailingAddrInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.rmcClearHomeOrMailingAddrInfo() - END");
	}

	private void rmcLoadMailingOrHomeAddrInfo(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.rmcLoadMailingOrHomeAddrInfo() - Start");
		List<Integer> indvSeqList = new ArrayList<>();
		try {
			CP_APP_RGST_Collection appRgstCollection = new CP_APP_RGST_Collection();
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			final String pageId = fwTxn.getCurrentActionDetails().getPageId();
			String appNumber = userDetails.getAppNumber();
			List<CP_APP_RGST_Cargo> appRgstList = reportMyChangeBO.getAppRgstByAppNum(String.valueOf(appNumber));
			if (null != appRgstList && !appRgstList.isEmpty()) {
				appRgstList = reportMyChangeBO.sendOnlyValidAddrDtls(appRgstList, pageId);
				if (null != appRgstList && !appRgstList.isEmpty()) {
					for (CP_APP_RGST_Cargo appRgstCargo : appRgstList) {
						indvSeqList.add(appRgstCargo.getIndv_seq_num());
					}
					appRgstList.get(0).setIndvSeqList(indvSeqList);
					Collections.addAll(appRgstCollection, appRgstList.toArray());
				}
			}

			pageCollection.put(CPAPPRGSTCOLL, appRgstCollection);
			CP_APP_RGST_Collection contactCargoColl = contInfoBO.loadContactforAppNum(appNumber,
					HouseHoldDemoGraphicsConstants.APP_IND_AFB);
			pageCollection.put("MOVED_IN_APP_RGST_Collection", contactCargoColl);
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcLoadMailingOrHomeAddrInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.rmcLoadMailingOrHomeAddrInfo() - END");

	}

	/**
	 * rmcSavePersonalChangeInfo method is used to store personal data of RMC
	 * applicant in APP_INDV table. After storing into DB table this method will
	 * send the APP_INDV data back in the response to display personal info changed
	 * individuals on personal Info Summary screen.
	 * 
	 * @param txnBean
	 */
	public void rmcSavePersonalChangeInfo(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.rmcSavePersonalChangeInfo() - START");
		try {
			APP_INDV_Cargo existingAppIndvCargo = null;
			APP_INDV_Cargo receivedAppIndvCargo = null;
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);

			// Below block of code will populate the APP_INDV table with personal change
			// received in txnbean.
			if (null != appIndvColl && !appIndvColl.isEmpty()) {
				receivedAppIndvCargo = appIndvColl.getCargo(0);
				existingAppIndvCargo = reportMyChangeBO.getAppIndvByAppNumIndvSeqNum(String.valueOf(appNumber),
						appIndvColl.getCargo(0).getIndv_seq_num());
				if (null == existingAppIndvCargo) {
					existingAppIndvCargo = new APP_INDV_Cargo();
					existingAppIndvCargo.setApp_num(appNumber);
					existingAppIndvCargo.setIndv_seq_num(receivedAppIndvCargo.getIndv_seq_num());
					existingAppIndvCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
					existingAppIndvCargo = reportMyChangeBO.populatePersonalInfo(existingAppIndvCargo,
							receivedAppIndvCargo, true);
				} else {
					existingAppIndvCargo = reportMyChangeBO.populatePersonalInfo(existingAppIndvCargo,
							receivedAppIndvCargo, false);
				}

				reportMyChangeBO.saveAppIndvCargo(existingAppIndvCargo);
			}

			// Below block of code will retrieve the APP_INDV data for appnum so as to send
			// the list of personal changed data back in
			// the response. Setting the APP_INDV collection into pageCollection and
			// personal info changed list will be displayed on Personal Change Summary
			// screen
			rmcLoadPersonalChangeInfo(txnBean);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcSavePersonalChangeInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcSavePersonalChangeInfo() - END");
	}

	public void rmcRemovePersonalChangeInfo(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.rmcRemovePersonalChangeInfo() - START");
		Integer indvSeqNumber = null;
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();
			final Map pageCollection = fwTxn.getPageCollection();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			indvSeqNumber = reportMyChangeBO.getIntValue(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			if (null != appIndvColl && !appIndvColl.isEmpty()) {
				if (reportMyChangeBO.isStringEmptyOrNull(appNum)) {
					appNum = appIndvColl.getCargo(0).getApp_num();
				}
				if (null == indvSeqNumber) {
					indvSeqNumber = appIndvColl.getCargo(0).getIndv_seq_num();
				}
			}
			reportMyChangeBO.removePersonalInfo(appNum, indvSeqNumber);
			rmcLoadPersonalChangeInfo(fwTxn);
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcRemovePersonalChangeInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.rmcRemovePersonalChangeInfo() - END");
	}

	private void rmcLoadPersonalChangeInfo(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.rmcLoadPersonalChangeInfo() - Start");
		try {
			APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
			APP_INDV_Collection infoChangedCollection = new APP_INDV_Collection();
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			String[] splitPersInfoDesc = null;
			// Below block of code will retrieve the APP_INDV data for appnum so as to send
			// the list of personal changed data back in
			// the response. Setting the APP_INDV collection into pageCollection and
			// personal changed list will be displayed on personal change Summary screen
			APP_INDV_Cargo[] updatedAppIndvArr = reportMyChangeBO.getAppIndvArrByAppNum(String.valueOf(appNumber));
			if (null != updatedAppIndvArr && updatedAppIndvArr.length > 0) {
				for (APP_INDV_Cargo cargo : updatedAppIndvArr) {
					if (!reportMyChangeBO.isStringEmptyOrNull(cargo.getChange_description())
							&& cargo.getChange_description().contains(FwConstants.COMMA)) {
						setInfoChangedDesc(cargo);
						if (!cargo.getInfoChangeDesc().isEmpty()) {
							infoChangedCollection.add(cargo);
						}

					}

					appIndvCollection.add(cargo);
				}
			}
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
			pageCollection.put("INFO_CHANGED_COLL", infoChangedCollection);
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcLoadPersonalChangeInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.rmcLoadPersonalChangeInfo() - END");

	}

	public void getSummaryData(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RMCHouseholdDemographicsService.getSummaryData() - START");

		try {
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			fwTxn.getPageCollection().put("indvIds", getIndvArray(appNumber));			
			reportMyChangeBO.getSBMSData(fwTxn);
			reportMyChangeBO.getAppPgmData(fwTxn);
			fetchMovedOutIndvDetails(fwTxn);
			rmcLoadPassedAwayInfo(fwTxn);
			loadNewBornIndvDetails(fwTxn);
			rmcLoadMailingOrHomeAddrInfo(fwTxn);
			rmcLoadPersonalChangeInfo(fwTxn);
			getMaritalStatusDetail(fwTxn);
			householdDemographicsServiceImpl.getContactInformationActiveIndv(fwTxn);
			houseHoldInfoServImpl.getHouseHoldPregnancyDetails(fwTxn);
			benefitsServImpl.getTeenParentDetails(fwTxn);
			rmcLoadHomelessAddrInfo(fwTxn);
			getUpdatedAppIndv(fwTxn);
			rmcLoadOtherPersonalInfo(fwTxn);	
			APP_ABS_PRNT_Collection existingappAbsColl = absentParentBo.loadParentSituationAbsentDetails(appNumber);			
			fwTxn.getPageCollection().put("APP_ABS_PRNT_Collection", existingappAbsColl);
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "getSummaryData",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RMCHouseholdDemographicsService.getSummaryData() - END");
	}

	private void setInfoChangedDesc(APP_INDV_Cargo cargo) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.setInfoChangedDesc() - START");
		String[] infoChanged = cargo.getChange_description().split(HouseHoldDemoGraphicsConstants.COMMA);
		StringBuilder infoChangedText = new StringBuilder();
		cargo.setMid_init(null == cargo.getMid_init() ? HouseHoldDemoGraphicsConstants.EMPTY : cargo.getMid_init());
		cargo.setSuffix_name(
				null == cargo.getSuffix_name() ? HouseHoldDemoGraphicsConstants.EMPTY : cargo.getSuffix_name());
		cargo.setSex_ind(null == cargo.getSex_ind() ? HouseHoldDemoGraphicsConstants.EMPTY : cargo.getSex_ind());
		try {
			if (!infoChanged[0].equals(cargo.getFst_nam())) {

				infoChangedText.append("firstName,");

			}
			if (!infoChanged[1].equals(cargo.getLast_nam())) {

				infoChangedText.append("lastName,");

			}
			if (!infoChanged[2].equals(cargo.getMid_init())) {

				infoChangedText.append("middleName,");

			}
			if (!infoChanged[3].equals(cargo.getSuffix_name())) {

				infoChangedText.append("suffix,");

			}
			if (!infoChanged[4].equals(cargo.getSex_ind())) {

				infoChangedText.append("gender,");

			}
			cargo.setInfoChangeDesc(infoChangedText.toString());

		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessageText());
			throw fe;
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.setInfoChangedDesc() - END");

	}

	public void rmcSaveHomelessAddrInfo(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcSaveHomelessAddrInfo() - START");
		CP_APP_RGST_Cargo receivedRgstCargo = null;
		CP_APP_RGST_Collection appRgstCollToSave = null;
		Integer indvSeqNum = 0;
		try {
			final Map pageCollection = txnBean.getPageCollection();
			String appNumber = txnBean.getUserDetails().getAppNumber();

			CP_APP_RGST_Collection appRgstColl = (CP_APP_RGST_Collection) pageCollection.get(CPAPPRGSTCOLL);
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);

			if (null != appRgstColl && !appRgstColl.isEmpty()) {
				receivedRgstCargo = appRgstColl.getCargo(0);
			}
			if (null != appIndvColl && !appIndvColl.isEmpty()) {
				indvSeqNum = appIndvColl.getCargo(0).getIndv_seq_num();
			}

			if (null != receivedRgstCargo && indvSeqNum > 0) {
				appRgstCollToSave = new CP_APP_RGST_Collection();
				appRgstCollToSave.add(reportMyChangeBO.populateHomeLessDtls(appNumber, indvSeqNum, receivedRgstCargo));
				reportMyChangeBO.saveAllRgstCargos(appRgstCollToSave);

			}

			// Below block of code will retrieve the CP_APP_RGST data for appnum so as to
			// send the list of home, mailing address details back in
			// the response. Setting the APP_RGST collection into pageCollection and home
			// ,mailing address details list will be displayed on
			// Home address, Mailing address Summary screens respectively

			rmcLoadHomelessAddrInfo(txnBean);
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcSaveHomelessAddrInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcSaveHomelessAddrInfo() - END");
	}

	private void rmcLoadHomelessAddrInfo(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.rmcLoadHomelessAddrInfo() - Start");
		try {
			CP_APP_RGST_Collection homelessCollection = new CP_APP_RGST_Collection();
			CP_APP_RGST_Collection appRgstCollection = new CP_APP_RGST_Collection();
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			List<CP_APP_RGST_Cargo> appRgstList = reportMyChangeBO.getAppRgstByAppNum(String.valueOf(appNumber));
			if (null != appRgstList && !appRgstList.isEmpty()) {

				for (CP_APP_RGST_Cargo appRgstCargo : appRgstList) {
					if (HouseHoldDemoGraphicsConstants.Y.equalsIgnoreCase(appRgstCargo.getHless_sw())) {
						homelessCollection.add(appRgstCargo);
					}
					appRgstCollection.add(appRgstCargo);
				}
			}

			if (!homelessCollection.isEmpty()) {
				pageCollection.put(HouseHoldDemoGraphicsConstants.HOMELESS_COLLECTION, homelessCollection);
			}

			pageCollection.put(CPAPPRGSTCOLL, appRgstCollection);
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcLoadHomelessAddrInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.rmcLoadHomelessAddrInfo() - END");

	}

	public void rmcClearHomelessAddrInfo(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcClearHomelessAddrInfo() - START");
		Integer indvSeqNumber = null;
		try {
			final Map pageCollection = txnBean.getPageCollection();
			String appNumber = txnBean.getUserDetails().getAppNumber();
			String pageId = txnBean.getCurrentActionDetails().getPageId();
			if (null == pageId || pageId.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.RCHAS)) {
				pageId = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			}
			CP_APP_RGST_Collection appRgstColl = (CP_APP_RGST_Collection) pageCollection.get(CPAPPRGSTCOLL);
			indvSeqNumber = reportMyChangeBO.getIntValue(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			// Below if block will loop through indv seq nums received from FE when remove
			// button is clicked on summary screen.
			// Will update Mailing addr details to empty when remove button is clicked on
			// Mailing summary screen and
			// Home address details to empty when remove button is clicked on Home address
			// summary screen
			if (null != appRgstColl && !appRgstColl.isEmpty()) {
				if (reportMyChangeBO.isStringEmptyOrNull(appNumber)) {
					appNumber = appRgstColl.getCargo(0).getApp_num();
				}
				if (null == indvSeqNumber) {
					indvSeqNumber = appRgstColl.getCargo(0).getIndv_seq_num();
				}
			}

			reportMyChangeBO.clearRmcHomelessAddress(appNumber, indvSeqNumber);

			// Below block of code will retrieve the CP_APP_RGST data for appnum so as to
			// send the list of home, mailing address details back in
			// the response. Setting the APP_RGST collection into pageCollection and home
			// ,mailing address details list will be displayed on
			// Home address, Mailing address Summary screens respectively

			rmcLoadHomelessAddrInfo(txnBean);
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcClearHomelessAddrInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.() - END");
	}

	public void rmcSaveOtherPersonalInfo(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcSaveOtherPersonalInfo() - START");
		try {
			APP_INDV_Cargo existingAppIndvCargo = null;
			APP_INDV_Cargo receivedAppIndvCargo = null;
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);

			// Below block of code will populate the APP_INDV table with other personal
			// change
			// received in txnbean.
			if (null != appIndvColl && !appIndvColl.isEmpty()) {
				receivedAppIndvCargo = appIndvColl.getCargo(0);
				existingAppIndvCargo = reportMyChangeBO.getAppIndvByAppNumIndvSeqNum(String.valueOf(appNumber),
						appIndvColl.getCargo(0).getIndv_seq_num());
				if (null == existingAppIndvCargo) {
					existingAppIndvCargo = new APP_INDV_Cargo();
					existingAppIndvCargo.setApp_num(appNumber);
					existingAppIndvCargo.setIndv_seq_num(receivedAppIndvCargo.getIndv_seq_num());
					existingAppIndvCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);					
				}
				existingAppIndvCargo.setPers_info_change_desc(receivedAppIndvCargo.getPers_info_change_desc());
				existingAppIndvCargo.setOth_info_change_dt(receivedAppIndvCargo.getOth_info_change_dt());
				reportMyChangeBO.saveAppIndvCargo(existingAppIndvCargo);
			}
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcSaveOtherPersonalInfo",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcSaveOtherPersonalInfo() - END");
	}

	public void rmcClearOtherPersonalInfo(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.rmcClearOtherPersonalInfo() - START");
		Integer indvSeqNumber = null;
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();
			final Map pageCollection = fwTxn.getPageCollection();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			indvSeqNumber = reportMyChangeBO.getIntValue(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			if (null != appIndvColl && !appIndvColl.isEmpty()) {
				if (reportMyChangeBO.isStringEmptyOrNull(appNum)) {
					appNum = appIndvColl.getCargo(0).getApp_num();
				}
				if (null == indvSeqNumber) {
					indvSeqNumber = appIndvColl.getCargo(0).getIndv_seq_num();
				}
			}
			reportMyChangeBO.removeOtherPersonalInfo(appNum, indvSeqNumber);
			rmcLoadOtherPersonalInfo(fwTxn);
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcClearOtherPersonalInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.() - END");
	}

	private void rmcLoadOtherPersonalInfo(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.rmcLoadOtherPersonalInfo() - Start");
		try {
			APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
			APP_INDV_Collection otherChangeColl = new APP_INDV_Collection();
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			// Below block of code will retrieve the APP_INDV data for appnum so as to send
			// the list of other personal changed data back in
			// the response. Setting the APP_INDV collection into pageCollection and
			// other personal changed list will be displayed on other personal change
			// Summary screen
			APP_INDV_Cargo[] updatedAppIndvArr = reportMyChangeBO.getAppIndvArrByAppNum(String.valueOf(appNumber));
			if (null != updatedAppIndvArr && updatedAppIndvArr.length > 0) {
				for (APP_INDV_Cargo cargo : updatedAppIndvArr) {
					if (!reportMyChangeBO.isStringEmptyOrNull(cargo.getPers_info_change_desc())) {
						otherChangeColl.add(cargo);
					}
					appIndvCollection.add(cargo);
				}
			}
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
			pageCollection.put(HouseHoldDemoGraphicsConstants.OTHER_PERSONAL_CHANGE_COLL, otherChangeColl);
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcLoadOtherPersonalInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RMCHouseholdDemographicsService.rmcLoadOtherPersonalInfo() - END");

	}

	public void getUpdatedAppIndv(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.getUpdatedAppIndv() - START");
		try {
			APP_INDV_Collection appIndvColl = new APP_INDV_Collection();
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();

			APP_INDV_Cargo[] loadSummaryCargoArr = reportMyChangeBO.getAppIndvArrByAppNum(appNumber);

			if (null != loadSummaryCargoArr && loadSummaryCargoArr.length > 0) {
				for (APP_INDV_Cargo cargo : loadSummaryCargoArr) {
					appIndvColl.add(cargo);
				}
			}

			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvColl);
			txnBean.setPageCollection(pageCollection);
		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessageText());
			throw fe;
		} catch (Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.getUpdatedAppIndv() - END");
	}

	/**
	 * Method to update details into APP_INDV_Cargo and CP_APP_HSHL_RLT_Cargo
	 * 
	 * @param txnBean
	 * @author sumaharana
	 */
	@SuppressWarnings("squid:S3776")
	public void updateHHIndvAndRelationDetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.updateHHIndvAndRelationDetails() - START");
		try {
			final Map pageCollection = txnBean.getPageCollection();
			String appNumber = txnBean.getUserDetails().getAppNumber();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);
			CP_APP_HSHL_RLT_Collection rltColl = (CP_APP_HSHL_RLT_Collection) pageCollection.get(CPAPPHSHLRLTCOLL);
			CP_APP_HSHL_RLT_Cargo receivedHshlCargo = null;
			// Below block of code will populate the APP_INDV table with Screen data
			if (null != appIndvColl && !appIndvColl.isEmpty() && null != appIndvColl.getCargo(0)) {

				APP_INDV_Cargo receivedCargo = appIndvColl.getCargo(0);
				int indvSeqNum = receivedCargo.getIndv_seq_num();

				if (null != rltColl && !rltColl.isEmpty() && null != rltColl.getCargo(0)
						&& null != rltColl.getCargo(0).getApp_num()) {
					receivedHshlCargo = rltColl.getCargo(0);

				}

				APP_INDV_Cargo appIndvcargo = cpAppIndvRepository
						.getAppIndvCargoByAppNumIndvSeqSrcAppInd(Integer.parseInt(appNumber), indvSeqNum);
				if (null != appIndvcargo) {
					appIndvcargo.setWhat_is_the_change(receivedCargo.getWhat_is_the_change());
					if ("MO".equalsIgnoreCase(receivedCargo.getWhat_is_the_change())) {
						appIndvcargo.setMove_out_ind("Y");
					}
					if ("PA".equalsIgnoreCase(receivedCargo.getWhat_is_the_change())) {
						appIndvcargo.setDeceased_ind("Y");
					}
					appIndvcargo.setChg_dt(new Date(System.currentTimeMillis()));
					appIndvcargo.setChange_description(receivedCargo.getChange_description());
					//set update date
					Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
					appIndvcargo.setUpdate_dt(currentTimeStamp);
					cpAppIndvRepository.save(appIndvcargo);

					if (null != receivedHshlCargo) {
						List<CP_APP_HSHL_RLT_Cargo> list = appHshlRltRepository.findByAppNumSrcRefIndvSeqNum(
								Integer.parseInt(receivedHshlCargo.getApp_num()), receivedHshlCargo.getSrcIndvSeqNum(),
								receivedHshlCargo.getRefIndvSeqNum());

						if (null != list && !list.isEmpty()) {
							CP_APP_HSHL_RLT_Cargo dBHshlcargo = list.get(0);
							if (null != receivedHshlCargo.getRltCd()) {
								dBHshlcargo.setRltCd(receivedHshlCargo.getRltCd());
								appHshlRltRepository.save(dBHshlcargo);
							}

						}
					}

				}

			}

		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "updateHHIndvAndRelationDetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.updateHHIndvAndRelationDetails() - END");
	}
	@SuppressWarnings("squid:S3776")
	public void addNewIndvAndRelationDetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.updateHHIndvAndRelationDetails() - START");
		try {
			final Map pageCollection = txnBean.getPageCollection();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);

			if (null != appIndvColl && !appIndvColl.isEmpty() && null != appIndvColl.getCargo(0)) {

				APP_INDV_Cargo receivedCargo = appIndvColl.getCargo(0);
				String appNumber = txnBean.getUserDetails().getAppNumber();
				int indvSeqNum = receivedCargo.getIndv_seq_num();
				receivedCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				receivedCargo.setApp_num(appNumber);
				//set update date
				Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());
				receivedCargo.setUpdate_dt(currentTimeStamp);
				//default what changed to other --CSPM-30907
				receivedCargo.setWhat_is_the_change("OT");
				cpAppIndvRepository.save(receivedCargo);
				pageCollection.replace(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvColl);

				CP_APP_HSHL_RLT_Collection rltColl = (CP_APP_HSHL_RLT_Collection) pageCollection.get(CPAPPHSHLRLTCOLL);
				CP_APP_HSHL_RLT_Cargo receivedHshlCargo = null;

				if (null != rltColl && !rltColl.isEmpty() && null != rltColl.getCargo(0)){
					receivedHshlCargo = rltColl.getCargo(0);
					receivedHshlCargo.setRefIndvSeqNum(indvSeqNum);
					receivedHshlCargo.setApp_num(appNumber);
				}

				if (null != receivedHshlCargo) {
					List<CP_APP_HSHL_RLT_Cargo> list = appHshlRltRepository.findByAppNumSrcRefIndvSeqNum(
							Integer.parseInt(receivedHshlCargo.getApp_num()), receivedHshlCargo.getSrcIndvSeqNum(),
							receivedHshlCargo.getRefIndvSeqNum());

					if (null != list && !list.isEmpty()) {
						CP_APP_HSHL_RLT_Cargo dBHshlcargo = list.get(0);
						if (null != receivedHshlCargo.getRltCd()) {
							dBHshlcargo.setRltCd(receivedHshlCargo.getRltCd());
							appHshlRltRepository.save(dBHshlcargo);
						}
					}else {
						receivedHshlCargo.setSrcAppIndiv(AppConstants.SRC_APP_IND_AFB);
						appHshlRltRepository.save(receivedHshlCargo);
					}
				}
			}
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "addNewIndvAndRelationDetails",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.addNewIndvAndRelationDetails() - END");
	}
	@SuppressWarnings("squid:S3776")
	public void storeFullTimeStudent(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.storeFullTimeSchoolStudent() - START");
		try {
			APP_IN_SCHLE_Collection appIndvschoolColl = new APP_IN_SCHLE_Collection();
			APP_IN_SCHLE_Collection insertIndvschoolColl = new APP_IN_SCHLE_Collection();
			APP_IN_SCHLE_Collection deleteSchoolIndvColl = new APP_IN_SCHLE_Collection();
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();

			if (pageCollection.containsKey(COLLECT_STUDENT_ARRAY)) {
				ArrayList<Integer> indvCheckArrayPageColl = (ArrayList<Integer>) pageCollection
						.get(COLLECT_STUDENT_ARRAY);
				ArrayList<Integer> indvCheckArray = new ArrayList<Integer>();
				for (int i = 0; i < indvCheckArrayPageColl.size(); i++) {
					if (!"True".equalsIgnoreCase(String.valueOf(indvCheckArrayPageColl.get(i)))
							&& !"False".equalsIgnoreCase(String.valueOf(indvCheckArrayPageColl.get(i)))) {
						indvCheckArray.add(Integer.parseInt(String.valueOf(indvCheckArrayPageColl.get(i))));
					}
				}
				if (indvCheckArray != null && !indvCheckArray.isEmpty()) {
					ArrayList<Integer> indvCheckArrayClone = indvCheckArray;
					APP_IN_SCHLE_Cargo[] appIndvSchollCargoArr = appinschleRepository
							.loadCollegeTradeSchoolDetails(Integer.parseInt(appNumber));
					for (int i = 0; i < indvCheckArray.size(); i++) {
						boolean indvFound = false;
						if (null != appIndvSchollCargoArr && appIndvSchollCargoArr.length > 0) {
							for (APP_IN_SCHLE_Cargo cargo : appIndvSchollCargoArr) {
								if (Integer.parseInt(String.valueOf(indvCheckArray.get(i))) == cargo
										.getIndv_seq_num()) {
									indvFound = true;
									appIndvschoolColl.add(cargo);
								}
								if (!indvCheckArrayClone.contains(cargo.getIndv_seq_num())) {
									deleteSchoolIndvColl.add(cargo);
								}
							}
						}
						if (!indvFound) {
							APP_IN_SCHLE_Cargo cargo = new APP_IN_SCHLE_Cargo();
							cargo.setApp_num(appNumber);
							cargo.setIndv_seq_num(Integer.parseInt(String.valueOf(indvCheckArray.get(i))));
							cargo.setSeq_num(1);
							cargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
							cargo.setSchool_type_cd("CL");
							cargo.setEnrl_stat_cd(FwConstants.SPACE);
							insertIndvschoolColl.add(cargo);
							appIndvschoolColl.add(cargo);
						}
					}
				}
			}
			if (!deleteSchoolIndvColl.isEmpty()) {
				appinschleRepository.deleteAll(deleteSchoolIndvColl);
			}
			if (!insertIndvschoolColl.isEmpty()) {
				appinschleRepository.saveAll(insertIndvschoolColl);
			}
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION, appIndvschoolColl);
			txnBean.setPageCollection(pageCollection);
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeFullTimeSchoolStudent",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.storeFullTimeSchoolStudent() - END");
	}

	/**
	 * storeRMCHelpQuestionData method is used save the Help Question Person
	 * Selection values to CP_APP_INDV cargo
	 * 
	 * @param txnBean
	 */
	@Transactional
	public void storeRMCHelpQuestionData(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.storeRMCHelpQuestionData() - START");
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());

			List<Integer> indvIdList = new ArrayList<>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("needHelpIndividualList");
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			String needHelpInd = (String)pageCollection.get("need_help_ind");
			if("N".equalsIgnoreCase(needHelpInd)) {
				APP_INDV_Cargo[] appIndvArr = cpAppIndvRepository.getByAppNum(Integer.valueOf(appNum));
				indvIdList = Arrays.asList(appIndvArr).stream().map(APP_INDV_Cargo::getIndv_seq_num)
						.collect(Collectors.toList());
				cpAppIndvRepository.updateCommutingBasedServices(needHelpInd, currentTimeStamp, Integer.parseInt(appNum),
						indvIdList);
			}else {
				cpAppIndvRepository.clearCommutingBasedServicesValue(Integer.parseInt(appNum), currentTimeStamp);
				cpAppIndvRepository.updateCommutingBasedServices("Y", currentTimeStamp,Integer.parseInt(appNum), indvIdList);
			}


		} catch (final FwException fe) {
			FwExceptionManager.handleException(fe, this.getClass().getName(), STORE_RMC_HELP_QUESTION_DATA,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(), STORE_RMC_HELP_QUESTION_DATA,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService::storeRMCHelpQuestionData() - End , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}
	
	/**
	 * Storing income fluctuation ind indicator in to CP_APP_INDV table
	 * 
	 * @param txnBean
	 */
	@Transactional
	public void storeIncomeFluctuationInd(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.storeIncomeFluctuationInd() - START");
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());

			APP_INDV_Cargo[] appIndvArr = cpAppIndvRepository.getByAppNum(Integer.valueOf(appNum));
			List<Integer> indvIdList = Arrays.asList(appIndvArr).stream().filter(x -> x.getAnticipatedAmt() == null)
					.map(APP_INDV_Cargo::getIndv_seq_num).collect(Collectors.toList());

			String incomeFluctuationInd = (String) pageCollection.get("income_fluctuation_ind");

			if ("N".equalsIgnoreCase(incomeFluctuationInd)) {
				cpAppIndvRepository.updateIncomeFluctuationInd(incomeFluctuationInd, currentTimeStamp,
						Integer.parseInt(appNum), indvIdList);
			} else {
				cpAppIndvRepository.clearIncomeFluctuationInd(Integer.parseInt(appNum), currentTimeStamp);
			}
		} catch (final FwException fe) {
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					HouseHoldDemoGraphicsConstants.STORE_INCOME_FLUCTUATION_INDICATOR,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(),
					HouseHoldDemoGraphicsConstants.STORE_INCOME_FLUCTUATION_INDICATOR,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService::storeIncomeFluctuationInd() - End , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}
	
	/**
	 * Storing In kind Support indicator in to CP_APP_INDV table
	 * 
	 * @param txnBean
	 */
	@Transactional
	public void storeInKindSupportIndicator(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.storeInKindSupportIndicator() - START");
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());

			List<Integer> indvIdList = null;

			APP_INDV_Cargo[] appIndvArr = cpAppIndvRepository.getByAppNum(Integer.valueOf(appNum));
			indvIdList = Arrays.asList(appIndvArr).stream().map(APP_INDV_Cargo::getIndv_seq_num)
					.collect(Collectors.toList());

			cpAppIndvRepository.updateInKindSupportInd((String) pageCollection.get("IN_KIND_SUPPORT"), currentTimeStamp, Integer.parseInt(appNum),
					indvIdList);

		} catch (final FwException fe) {
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					HouseHoldDemoGraphicsConstants.STORE_IN_KIND_SUPPORT_INDICATOR,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(),
					HouseHoldDemoGraphicsConstants.STORE_IN_KIND_SUPPORT_INDICATOR,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService::storeInKindSupportIndicator() - End , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}

	/**
	 * Storing Kidney dialysis indicator in to CP_APP_INDV table
	 * 
	 * @param txnBean
	 */
	@Transactional
	public void storeKidneyDialysisIndicator(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.storeKidneyDialysisIndicator() - START");
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());

			List<Integer> indvIdList = new ArrayList<>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("kidneyDialysisIndividualList");
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			
			String dialysisInd = (String)pageCollection.get("dialysis_ind");
			if ("N".equalsIgnoreCase(dialysisInd)) {

				APP_INDV_Cargo[] appIndvArr = cpAppIndvRepository.getByAppNum(Integer.valueOf(appNum));
				indvIdList = Arrays.asList(appIndvArr).stream().map(APP_INDV_Cargo::getIndv_seq_num)
						.collect(Collectors.toList());
				cpAppIndvRepository.updateIndvDataKidneyInd(dialysisInd, currentTimeStamp, Integer.parseInt(appNum),
						indvIdList);

			} else {
				cpAppIndvRepository.clearKidneyInd(Integer.parseInt(appNum), currentTimeStamp);
				cpAppIndvRepository.updateIndvDataKidneyInd("Y", currentTimeStamp, Integer.parseInt(appNum),
						indvIdList);
			}
		} catch (final FwException fe) {
			FwExceptionManager.handleException(fe, this.getClass().getName(), HouseHoldDemoGraphicsConstants.STORE_KIDNEY_DIALYSIS_INDICATOR,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(), HouseHoldDemoGraphicsConstants.STORE_KIDNEY_DIALYSIS_INDICATOR,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService::storeKidneyDialysisIndicator() - End , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}
	
	/**
	 * Storing Organ Transplant indicator in to CP_APP_INDV table
	 * 
	 * @param txnBean
	 */
	@Transactional
	public void storeOrganTransplantIndicator(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService.storeOrganTransplantIndicator() - START");
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			Timestamp currentTimeStamp = new Timestamp(new java.util.Date().getTime());

			List<Integer> indvIdList = new ArrayList<>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("organTransplantIndividualList");
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			
			String organTransplantInd = (String)pageCollection.get("organ_transplant_ind");
			if ("N".equalsIgnoreCase(organTransplantInd)) {

				APP_INDV_Cargo[] appIndvArr = cpAppIndvRepository.getByAppNum(Integer.valueOf(appNum));
				indvIdList = Arrays.asList(appIndvArr).stream().map(APP_INDV_Cargo::getIndv_seq_num)
						.collect(Collectors.toList());
				cpAppIndvRepository.updateOrganTransplantInd(organTransplantInd, currentTimeStamp,
						Integer.parseInt(appNum), indvIdList);

			} else {
				cpAppIndvRepository.clearOrganTransplantInd(Integer.parseInt(appNum), currentTimeStamp);
				cpAppIndvRepository.updateOrganTransplantInd("Y", currentTimeStamp, Integer.parseInt(appNum),
						indvIdList);
			}

		} catch (final FwException fe) {
			FwExceptionManager.handleException(fe, this.getClass().getName(), HouseHoldDemoGraphicsConstants.STORE_ORGAN_TRANSPLANT_INDICATOR,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(), HouseHoldDemoGraphicsConstants.STORE_ORGAN_TRANSPLANT_INDICATOR,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RMCHouseholdDemographicsService::storeOrganTransplantIndicator() - End , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}
	
	public void rmcSaveMaritalStatus(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcSaveMaritalStatus() - START");
		try {
			APP_INDV_Cargo existingAppIndvCargo = null;
			APP_INDV_Cargo receivedAppIndvCargo = null;
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION);

			// Below block of code will populate the APP_INDV table with marital status
			// change
			// received in txnbean.
			if (null != appIndvColl && !appIndvColl.isEmpty()) {
				receivedAppIndvCargo = appIndvColl.getCargo(0);
				existingAppIndvCargo = reportMyChangeBO.getAppIndvByAppNumIndvSeqNum(String.valueOf(appNumber),
						appIndvColl.getCargo(0).getIndv_seq_num());
				if (null == existingAppIndvCargo) {
					existingAppIndvCargo = new APP_INDV_Cargo();
					existingAppIndvCargo.setApp_num(appNumber);
					existingAppIndvCargo.setIndv_seq_num(receivedAppIndvCargo.getIndv_seq_num());
					existingAppIndvCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);					
				}
				existingAppIndvCargo.setMrtl_eff_dt(receivedAppIndvCargo.getMrtl_eff_dt());
				existingAppIndvCargo.setMrtl_stat_cd(receivedAppIndvCargo.getMrtl_stat_cd());
				reportMyChangeBO.saveAppIndvCargo(existingAppIndvCargo);
			}
		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "rmcSaveMaritalStatus",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RMCHouseholdDemographicsService.rmcSaveMaritalStatus() - END");
	}
	private List<String> getIndvArray(String appNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RMCHouseholdDemographicsService.getIndvArray() - START");
		List<String> indvIdList = new ArrayList<>();
		try {
			APP_INDV_Cargo[] updatedAppIndvArr = reportMyChangeBO.getAppIndvArrByAppNum(String.valueOf(appNum));
			if (null != updatedAppIndvArr && updatedAppIndvArr.length > 0) {
				for (APP_INDV_Cargo cargo : updatedAppIndvArr) {
					indvIdList.add(cargo.getIndv_seq_num().toString());
				}
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, "getIndvArray", e);
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RMCHouseholdDemographicsService.getIndvArray() - END");
		return indvIdList;
	}
}
