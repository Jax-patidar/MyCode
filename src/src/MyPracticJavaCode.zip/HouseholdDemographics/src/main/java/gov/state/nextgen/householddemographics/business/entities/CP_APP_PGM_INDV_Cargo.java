package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.io.Serializable;
import java.sql.Timestamp;

@Entity
@Table(name="CP_APP_PGM_INDV",schema = "IE_SSP_OWNER_HH")
@IdClass(CP_APP_PGM_INDV_Cargo.CP_APP_PGM_INDV_Key.class)
public class CP_APP_PGM_INDV_Cargo extends AbstractCargo implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;

    @Id
    private Double indv_seq_num;

    private String app_pgm_indv_id;

    @Column(name="ta_request_ind")
    private String tanf_rqst_ind;
    @Column(name="fs_request_ind")
    private String fs_rqst_ind;
    @Column(name="ma_request_ind")
    private String fma_rqst_ind;
 // Added as a part of PR Stop Benefits question
 	private String stop_fs_rqst_ind;
 	private String stop_tanf_rqst_ind;
 	private String stop_fma_rqst_ind;
 	private String ggr_ind;
 	
 	public String getGgr_ind() {
		return ggr_ind;
	}
	public void setGgr_ind(String ggr_ind) {
		this.ggr_ind = ggr_ind;
	}
	@CreationTimestamp
 	@Column(name = "create_dt", updatable = false)
	private Timestamp create_dt;
	
 	@UpdateTimestamp
	private Timestamp update_dt;
 	
 	
 	public String getStop_fs_rqst_ind() {
 		return stop_fs_rqst_ind;
 	}
 	public void setStop_fs_rqst_ind(String stop_fs_rqst_ind) {
 		this.stop_fs_rqst_ind = stop_fs_rqst_ind;
 	}
 	public String getStop_tanf_rqst_ind() {
 		return stop_tanf_rqst_ind;
 	}
 	public void setStop_tanf_rqst_ind(String stop_tanf_rqst_ind) {
 		this.stop_tanf_rqst_ind = stop_tanf_rqst_ind;
 	}
 	public String getStop_fma_rqst_ind() {
 		return stop_fma_rqst_ind;
 	}
 	public void setStop_fma_rqst_ind(String stop_fma_rqst_ind) {
 		this.stop_fma_rqst_ind = stop_fma_rqst_ind;
 	}


  
    
    public static class CP_APP_PGM_INDV_Key implements Serializable {
    	
    	private static final long serialVersionUID = 1;
        private Integer app_number;
        private Double indv_seq_num;

        public CP_APP_PGM_INDV_Key(Integer app_number, Double indv_seq_num) {
            this.app_number = app_number;
            this.indv_seq_num = indv_seq_num;
        }

        public CP_APP_PGM_INDV_Key() {
        }

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
			result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			CP_APP_PGM_INDV_Key other = (CP_APP_PGM_INDV_Key) obj;
			if (app_number == null) {
				if (other.app_number != null)
					return false;
			} else if (!app_number.equals(other.app_number))
				return false;
			if (indv_seq_num == null) {
				if (other.indv_seq_num != null)
					return false;
			} else if (!indv_seq_num.equals(other.indv_seq_num))
				return false;
			return true;
		}
        
        
    }

    public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	
    public String getTanf_rqst_ind() {
        return tanf_rqst_ind;
    }

    public void setTanf_rqst_ind(String tanf_rqst_ind) {
        this.tanf_rqst_ind = tanf_rqst_ind;
    }

    public String getFs_rqst_ind() {
        return fs_rqst_ind;
    }

    public void setFs_rqst_ind(String fs_rqst_ind) {
        this.fs_rqst_ind = fs_rqst_ind;
    }

    public String getFma_rqst_ind() {
        return fma_rqst_ind;
    }

    public void setFma_rqst_ind(String fma_rqst_ind) {
        this.fma_rqst_ind = fma_rqst_ind;
    }

    public Double getIndv_seq_num() {
        return indv_seq_num;
    }

    public void setIndv_seq_num(Double indv_seq_num) {
        this.indv_seq_num = indv_seq_num;
    }

    public String getApp_pgm_indv_id() {
        return app_pgm_indv_id;
    }

    public void setApp_pgm_indv_id(String app_pgm_indv_id) {
        this.app_pgm_indv_id = app_pgm_indv_id;
    }
	public Timestamp getCreate_dt() {
		return create_dt;
	}
	public void setCreate_dt(Timestamp create_dt) {
		this.create_dt = create_dt;
	}
	public Timestamp getUpdate_dt() {
		return update_dt;
	}
	public void setUpdate_dt(Timestamp update_dt) {
		this.update_dt = update_dt;
	}
    
   

}
