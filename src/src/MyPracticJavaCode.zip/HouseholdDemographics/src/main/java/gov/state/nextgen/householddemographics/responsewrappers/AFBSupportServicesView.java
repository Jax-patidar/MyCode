package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_SUPPORT_SERVICES_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_SUPPORT_SERVICES_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("ABOSS")
@Scope("prototype")
public class AFBSupportServicesView implements LogicResponseInterface {

	private static final String PAGE_ID = "ABOSS";

	public PageResponse constructPageResponse(FwTransaction fwTrxn) {
		DriverPageResponse driverPageResponse = new DriverPageResponse();
		Map pageCollection = fwTrxn.getPageCollection();
		List<CP_APP_SUPPORT_SERVICES_Cargo> supportServicesList = new ArrayList<CP_APP_SUPPORT_SERVICES_Cargo>();
		CP_APP_SUPPORT_SERVICES_Cargo supportServicesCargo = new CP_APP_SUPPORT_SERVICES_Cargo();

		CP_APP_SUPPORT_SERVICES_Collection cpSprtServCollection = pageCollection
				.get(HouseHoldDemoGraphicsConstants.CP_APP_SUPPORT_SERVICES_COLL) != null
						? (CP_APP_SUPPORT_SERVICES_Collection) pageCollection
								.get(HouseHoldDemoGraphicsConstants.CP_APP_SUPPORT_SERVICES_COLL)
						: null;

		if (cpSprtServCollection != null && !cpSprtServCollection.isEmpty() && cpSprtServCollection.size() > 0) {
			for (int i = 0; i < cpSprtServCollection.size(); i++) {
				supportServicesCargo = (CP_APP_SUPPORT_SERVICES_Cargo) cpSprtServCollection.get(i);

			}
		}
		supportServicesList.add(supportServicesCargo);
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_SUPPORT_SERVICES_COLL,
				supportServicesList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTrxn.getRequest().get(FwConstants.APP_NUM)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTrxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));
		return driverPageResponse;
	}

}