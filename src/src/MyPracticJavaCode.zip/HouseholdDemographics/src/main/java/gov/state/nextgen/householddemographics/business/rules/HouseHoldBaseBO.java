package gov.state.nextgen.householddemographics.business.rules;

import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.householddemographics.business.entities.*;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Base Business Object for all BO's under household demographics.
 * @author srprasannakumar
 */
public class HouseHoldBaseBO {

    /**
     *
     * @param cp_app_indv_cargos
     * @return
     */
    protected List<APP_INDV_Cargo> getAppIndvCargos(List<CP_APP_INDV_Cargo> cp_app_indv_cargos) {
        List<APP_INDV_Cargo> app_indv_cargoList = new ArrayList<>();
        if(Objects.nonNull(cp_app_indv_cargos)){
            for(CP_APP_INDV_Cargo cp_app_indv_cargo:cp_app_indv_cargos){
                APP_INDV_Cargo cargo = getAppIndvCargo(cp_app_indv_cargo);
                app_indv_cargoList.add(cargo);
            }
        }
        return app_indv_cargoList;
    }

    /**
     * Convert APP_INDV_Cargo from CP_APP_INDV_Cargo
     * @param cp_app_indv_cargo
     * @return
     */
    protected APP_INDV_Cargo getAppIndvCargo(CP_APP_INDV_Cargo cp_app_indv_cargo){
        APP_INDV_Cargo cargo = new APP_INDV_Cargo();
        cargo.setApp_num(cp_app_indv_cargo.getAppNum());
        cargo.setFst_nam(cp_app_indv_cargo.getFst_nam());
        cargo.setLast_nam(cp_app_indv_cargo.getLast_nam());
        if(Objects.nonNull(cp_app_indv_cargo.getIndvSeqNum())){
            cargo.setIndv_seq_num(Double.valueOf(cp_app_indv_cargo.getIndvSeqNum()).intValue()); //After migrating data from Oracle type INT/NUMBER is mapped to FLOAT8 of Postgres
        }
        Date leftHomeDt = null;
        cargo.setCitizenVerifyInd(cp_app_indv_cargo.getCitizen_verify_ind());
        if(Objects.nonNull(cp_app_indv_cargo.getLeft_home_dt())) {
            leftHomeDt = new java.sql.Date(cp_app_indv_cargo.getLeft_home_dt().getTime());
            cargo.setLeft_home_dt(leftHomeDt);
        }
        cargo.setLeft_home_reason_cd(cp_app_indv_cargo.getLeftHomeReasonCd());
        cargo.setSrc_app_ind(cp_app_indv_cargo.getSrc_app_ind());
        cargo.setLive_arng_typ(cp_app_indv_cargo.getLive_arng_typ());

        if(Objects.nonNull(cp_app_indv_cargo.getBrth_dt())) {
            cargo.setBrth_dt(new java.sql.Date(cp_app_indv_cargo.getBrth_dt().getTime()));
        }

        if(Objects.nonNull(cp_app_indv_cargo.getPrim_prsn_sw())){ cargo.setPrim_prsn_sw(cp_app_indv_cargo.getPrim_prsn_sw().toString()); }
        return cargo;
    }

    /**
     * Get App Household cargos.
     * @param householdRelationShip
     * @return
     */
    protected List<APP_HSHL_RLT_Cargo> getAppHouseholdRelationCargos(List<CP_APP_HSHL_RLT_Cargo> householdRelationShip) {
        List<APP_HSHL_RLT_Cargo> app_hshl_rlt_cargos = new ArrayList<>();
        householdRelationShip.forEach(cp_app_hshl_rlt_cargo -> {
            APP_HSHL_RLT_Cargo cargo = new APP_HSHL_RLT_Cargo();
            cargo.setApp_num(cp_app_hshl_rlt_cargo.getApp_num());
            if(Objects.nonNull(cp_app_hshl_rlt_cargo.getChange_dt())){
                cargo.setChg_dt(cp_app_hshl_rlt_cargo.getChange_dt().toString());
            }
            cargo.setRef_indv_seq_num(cp_app_hshl_rlt_cargo.getRefIndvSeqNum());
            cargo.setRlt_cd(cp_app_hshl_rlt_cargo.getRltCd());
            cargo.setSrc_indv_seq_num(cp_app_hshl_rlt_cargo.getSrcIndvSeqNum());
            app_hshl_rlt_cargos.add(cargo);

        });

        return app_hshl_rlt_cargos;
    }

    /**
     *
     * @param cpAppInPregCargos
     * @return
     */
    protected List<APP_IN_PREG_Cargo> getAppPregnancyCargos(List<CP_APP_IN_PREG_Cargo> cpAppInPregCargos) {
        List<APP_IN_PREG_Cargo> appInPregCargos = new ArrayList<>();
        for(CP_APP_IN_PREG_Cargo cpAppInPregCargo:cpAppInPregCargos){
            APP_IN_PREG_Cargo appInPregCargo = getAppInPregCargo(cpAppInPregCargo);
            appInPregCargos.add(appInPregCargo);
        }
        return appInPregCargos;
    }

    protected APP_IN_PREG_Cargo getAppInPregCargo(CP_APP_IN_PREG_Cargo cpAppInPregCargo) {
        APP_IN_PREG_Cargo appInPregCargo = new APP_IN_PREG_Cargo();
        appInPregCargo.setApp_num(cpAppInPregCargo.getApp_num());
        if(Objects.nonNull(cpAppInPregCargo.getBaby_ct())) { appInPregCargo.setBaby_ct(cpAppInPregCargo.getBaby_ct().toString()); }
        appInPregCargo.setBaby_reside_hshld_ind(cpAppInPregCargo.getBaby_reside_hshld_ind());
        appInPregCargo.setBf_infant(cpAppInPregCargo.getBf_infant());
        if(Objects.nonNull(cpAppInPregCargo.getBaby_ct())){appInPregCargo.setBaby_ct(cpAppInPregCargo.getBaby_ct().toString());}
        if(Objects.nonNull(cpAppInPregCargo.getChg_eff_dt())){appInPregCargo.setChg_eff_dt(cpAppInPregCargo.getChg_eff_dt().toString());}
        if(Objects.nonNull(cpAppInPregCargo.getConception_dt())){appInPregCargo.setConception_dt(cpAppInPregCargo.getConception_dt().toString());}
        appInPregCargo.setCur_in_post_partum(cpAppInPregCargo.getCur_in_post_partum());
        appInPregCargo.setCur_preg(cpAppInPregCargo.getCur_preg());
        appInPregCargo.setEcp_id(cpAppInPregCargo.getEcp_id());
        if(Objects.nonNull(cpAppInPregCargo.getPp_babies_ct())){appInPregCargo.setPp_babies_ct(cpAppInPregCargo.getPp_babies_ct().toString());}
        if(Objects.nonNull(cpAppInPregCargo.getPreg_due_dt())){appInPregCargo.setPreg_due_dt(cpAppInPregCargo.getPreg_due_dt().toString());}
        appInPregCargo.setSrc_app_ind(cpAppInPregCargo.getSrc_app_ind());
        if(Objects.nonNull(cpAppInPregCargo.getFetus_ct())){appInPregCargo.setFetus_ct(cpAppInPregCargo.getFetus_ct().toString());}
        return appInPregCargo;
    }

    /**
     *
     * @param results
     * @return
     */
    protected List<CP_APP_IN_PREG_Cargo> getCpAppPregCargos(APP_IN_PREG_Cargo[] results) {
        List<CP_APP_IN_PREG_Cargo> cpAppInPregCargos = new ArrayList<>();
        for(APP_IN_PREG_Cargo appInPregCargo:results){
            CP_APP_IN_PREG_Cargo cpAppInPregCargo = getCpAppInPregCargo(appInPregCargo);
            cpAppInPregCargos.add(cpAppInPregCargo);
        }
        return cpAppInPregCargos;
    }

    protected CP_APP_IN_PREG_Cargo getCpAppInPregCargo(APP_IN_PREG_Cargo appInPregCargo) {
        CP_APP_IN_PREG_Cargo cpAppInPregCargo = new CP_APP_IN_PREG_Cargo();

        cpAppInPregCargo.setApp_num(appInPregCargo.getApp_num());

        if(Objects.nonNull(appInPregCargo.getBaby_ct())) {
            cpAppInPregCargo.setBaby_ct(Integer.parseInt(appInPregCargo.getBaby_ct()));
        }
        cpAppInPregCargo.setEcp_id(appInPregCargo.getEcp_id());
        if(null != appInPregCargo.getChg_eff_dt()) {
        	cpAppInPregCargo.setChg_eff_dt(Timestamp.valueOf(appInPregCargo.getChg_eff_dt()));
        }else {
        	cpAppInPregCargo.setChg_eff_dt(Timestamp.valueOf(AppConstants.HIGH_TIMESTAMP));
        }
        
        if(Objects.nonNull(appInPregCargo.getFetus_ct())) {
        	cpAppInPregCargo.setFetus_ct(Integer.parseInt(appInPregCargo.getFetus_ct()));
        }
        
        if(Objects.nonNull(appInPregCargo.getPreg_due_dt()) && appInPregCargo.getPreg_due_dt().isEmpty()) {
        	cpAppInPregCargo.setPreg_due_dt(Timestamp.valueOf(appInPregCargo.getPreg_due_dt()));
        }
        if(Objects.nonNull(appInPregCargo.getRec_cplt_ind())) {
        	cpAppInPregCargo.setRec_cplt_ind(Integer.parseInt(appInPregCargo.getRec_cplt_ind()));
        }
        cpAppInPregCargo.setBaby_reside_hshld_ind(appInPregCargo.getBaby_reside_hshld_ind());
        cpAppInPregCargo.setCur_preg(appInPregCargo.getCur_preg());
        cpAppInPregCargo.setCur_in_post_partum(appInPregCargo.getCur_in_post_partum());
        if(Objects.nonNull(appInPregCargo.getPreg_term_dt()) && appInPregCargo.getPreg_term_dt().isEmpty()) {
        	cpAppInPregCargo.setPreg_term_dt(Timestamp.valueOf(appInPregCargo.getPreg_term_dt()));
        }
        if(Objects.nonNull(appInPregCargo.getPp_babies_ct())) {
        	cpAppInPregCargo.setPp_babies_ct(Integer.parseInt(appInPregCargo.getPp_babies_ct()));
        }
        cpAppInPregCargo.setBf_infant(appInPregCargo.getBf_infant());
        if(Objects.nonNull(appInPregCargo.getPreg_dlvry_dt()) && appInPregCargo.getPreg_dlvry_dt().isEmpty()) {
        	cpAppInPregCargo.setPreg_dlvry_dt(Timestamp.valueOf(appInPregCargo.getPreg_dlvry_dt()));
        }
        if(Objects.nonNull(appInPregCargo.getConception_dt())) {
            cpAppInPregCargo.setConception_dt(null);
        }
        cpAppInPregCargo.setIndv_seq_num(Integer.parseInt(appInPregCargo.getIndv_seq_num()));
        cpAppInPregCargo.setSrc_app_ind(appInPregCargo.getSrc_app_ind());
        return cpAppInPregCargo;
    }

    /**
     *
     * @param results
     * @return
     */
    protected  List<CP_APP_HSHL_RLT_Cargo> getCpAppIndvCargos(APP_HSHL_RLT_Cargo[] results) {
        List<CP_APP_HSHL_RLT_Cargo> cp_app_indv_cargos = new ArrayList<CP_APP_HSHL_RLT_Cargo>();
        for(APP_HSHL_RLT_Cargo app_hshl_rlt_cargo : results){
            CP_APP_HSHL_RLT_Cargo cpAppHshlRltCargo = getCpAppHshlRltCargo(app_hshl_rlt_cargo);
            cp_app_indv_cargos.add(cpAppHshlRltCargo);
        }
        return cp_app_indv_cargos;
    }

    protected CP_APP_HSHL_RLT_Cargo getCpAppHshlRltCargo(APP_HSHL_RLT_Cargo app_hshl_rlt_cargo) {
        CP_APP_HSHL_RLT_Cargo cpAppHshlRltCargo = new CP_APP_HSHL_RLT_Cargo();
        cpAppHshlRltCargo.setApp_num(app_hshl_rlt_cargo.getApp_num());
        cpAppHshlRltCargo.setCare_resp(app_hshl_rlt_cargo.getCare_resp());
        if(Objects.nonNull(app_hshl_rlt_cargo.getChg_eff_dt())) { cpAppHshlRltCargo.setChange_dt(null); }
        cpAppHshlRltCargo.setRec_cplt_ind(Integer.parseInt(app_hshl_rlt_cargo.getRec_cplt_ind()));
        cpAppHshlRltCargo.setSrcIndvSeqNum(app_hshl_rlt_cargo.getSrc_indv_seq_num());
        cpAppHshlRltCargo.setRefIndvSeqNum(app_hshl_rlt_cargo.getRef_indv_seq_num());
        cpAppHshlRltCargo.setSrcAppIndiv(app_hshl_rlt_cargo.getSrc_app_ind());
        cpAppHshlRltCargo.setRltCd(app_hshl_rlt_cargo.getRlt_cd());
        return cpAppHshlRltCargo;
    }
}

