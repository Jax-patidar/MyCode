package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class AppDetail implements Serializable {

	private static final long serialVersionUID = 1L;
	private String appNum;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.MS")
	private Date submissionDate;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.MS")
	private Date applicationDate;
	private String casenum;
	private String status;
	private String formType;
	private String changedDetails;
	
	public String getChangedDetails() {
		return changedDetails;
	}
	public void setChangedDetails(String changedDetails) {
		this.changedDetails = changedDetails;
	}
	public String getAppNum() {
		return appNum;
	}
	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}
	
	public Date getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}

	public Date getApplicationDate() {
		return applicationDate;
	}
	public void setApplicationDate(Date applicationDate) {
		this.applicationDate = applicationDate;
	}
	public String getCasenum() {
		return casenum;
	}
	public void setCasenum(String casenum) {
		this.casenum = casenum;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFormType() {
		return formType;
	}
	public void setFormType(String formType) {
		this.formType = formType;
	}
	

}
