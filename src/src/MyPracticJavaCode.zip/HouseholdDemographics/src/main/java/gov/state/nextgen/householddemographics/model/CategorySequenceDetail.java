package gov.state.nextgen.householddemographics.model;

public class CategorySequenceDetail {
    private static final long serialVersionUID = 1L;
    private short individualSequence;
    private long categorySequence;
    private char status;
    private boolean newRecord;
    private String categoryType;
    private boolean currentRecord;
    private String rowAction;
    private String changeSelectionCategoryCd;
    private short userEndSelectionInd;

    public short getIndividualSequence() {
        return individualSequence;
    }

    public void setIndividualSequence(short individualSequence) {
        this.individualSequence = individualSequence;
    }

    public long getCategorySequence() {
        return categorySequence;
    }

    public void setCategorySequence(long categorySequence) {
        this.categorySequence = categorySequence;
    }

    public char getStatus() {
        return status;
    }

    public void setStatus(char status) {
        this.status = status;
    }

    public boolean isNewRecord() {
        return newRecord;
    }

    public void setNewRecord(boolean newRecord) {
        this.newRecord = newRecord;
    }

    public String getCategoryType() {
        return categoryType;
    }

    public void setCategoryType(String categoryType) {
        this.categoryType = categoryType;
    }

    public boolean isCurrentRecord() {
        return currentRecord;
    }

    public void setCurrentRecord(boolean currentRecord) {
        this.currentRecord = currentRecord;
    }

    public String getRowAction() {
        return rowAction;
    }

    public void setRowAction(String rowAction) {
        this.rowAction = rowAction;
    }

    public String getChangeSelectionCategoryCd() {
        return changeSelectionCategoryCd;
    }

    public void setChangeSelectionCategoryCd(String changeSelectionCategoryCd) {
        this.changeSelectionCategoryCd = changeSelectionCategoryCd;
    }

    public short getUserEndSelectionInd() {
        return userEndSelectionInd;
    }

    public void setUserEndSelectionInd(short userEndSelectionInd) {
        this.userEndSelectionInd = userEndSelectionInd;
    }
}
