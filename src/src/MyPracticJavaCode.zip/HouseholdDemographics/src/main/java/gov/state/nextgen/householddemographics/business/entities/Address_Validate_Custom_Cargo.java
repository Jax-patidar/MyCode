package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;
import java.util.List;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class Address_Validate_Custom_Cargo extends AbstractCargo implements Serializable {

    private static final long serialVersionUID = -4235924843859488416L;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String country;
    private String stateProvince;
    private String postalCode;
    private String firmName;
    private String outputCasing;
    private String blockAddress;
    private String postalCodeBase;
    private String postalCodeAddOn;
    private List<String> userFields;
    private int exceptionCode;
    private String exceptionDescription;
    
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getStateProvince() {
		return stateProvince;
	}
	public void setStateProvince(String stateProvince) {
		this.stateProvince = stateProvince;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getFirmName() {
		return firmName;
	}
	public void setFirmName(String firmName) {
		this.firmName = firmName;
	}
	public String getOutputCasing() {
		return outputCasing;
	}
	public void setOutputCasing(String outputCasing) {
		this.outputCasing = outputCasing;
	}
	public String getBlockAddress() {
		return blockAddress;
	}
	public void setBlockAddress(String blockAddress) {
		this.blockAddress = blockAddress;
	}
	public String getPostalCodeBase() {
		return postalCodeBase;
	}
	public void setPostalCodeBase(String postalCodeBase) {
		this.postalCodeBase = postalCodeBase;
	}
	public String getPostalCodeAddOn() {
		return postalCodeAddOn;
	}
	public void setPostalCodeAddOn(String postalCodeAddOn) {
		this.postalCodeAddOn = postalCodeAddOn;
	}
	public List<String> getUserFields() {
		return userFields;
	}
	public void setUserFields(List<String> userFields) {
		this.userFields = userFields;
	}
	public int getExceptionCode() {
		return exceptionCode;
	}
	public void setExceptionCode(int exceptionCode) {
		this.exceptionCode = exceptionCode;
	}
	public String getExceptionDescription() {
		return exceptionDescription;
	}
	public void setExceptionDescription(String exceptionDescription) {
		this.exceptionDescription = exceptionDescription;
	}
}