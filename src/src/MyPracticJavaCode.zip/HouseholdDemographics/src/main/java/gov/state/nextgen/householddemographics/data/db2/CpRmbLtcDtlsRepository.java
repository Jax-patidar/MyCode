/**
 * 
 */
package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Key;


@Repository
public interface CpRmbLtcDtlsRepository extends CrudRepository<CpRmbLtcDtls_Cargo, CpRmbLtcDtls_Key> {	
	
	@Query("select c from CpRmbLtcDtls_Cargo c where c.app_number = ?1 and endDate is NULL")
	public CpRmbLtcDtls_Collection getLtcDtlsByAppNum(Integer appNumber);

	@Query("select c from CpRmbLtcDtls_Cargo c where c.app_number = ?1 and c.indvSeqNum = ?2 and c.seqNum = ?3")
	public CpRmbLtcDtls_Collection getLtcDetails(Integer appNumber, Integer indvSeqNum, Integer seqNum);
	
	@Query("select c from CpRmbLtcDtls_Cargo c where c.app_number = ?1 and c.indvSeqNum IN ?2 and endDate is NULL")
	public CpRmbLtcDtls_Collection getLtcDtlsByAppNumActive(Integer appNumber, List<Integer> indvIds);


}
