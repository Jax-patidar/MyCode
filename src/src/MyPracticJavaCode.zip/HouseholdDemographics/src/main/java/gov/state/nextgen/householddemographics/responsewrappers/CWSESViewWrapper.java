package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;
@Component("CWSES")
@Scope("prototype")
public class CWSESViewWrapper implements LogicResponseInterface{


    private static final String PAGE_ID = "CWSES";
    private static final String APP_SBMS_COLLECTION = "APP_SBMS_Collection";
    
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

    	DriverPageResponse driverPageResponse = new DriverPageResponse();
    	
        Map<Object,Object> pageCollection = fwTxn.getPageCollection();
        List<APP_SBMS_Cargo> cpAppAuthRepCargoList = new ArrayList<APP_SBMS_Cargo>();
        APP_SBMS_Cargo cpAppAuthRepCargo = new APP_SBMS_Cargo();
        APP_SBMS_Collection cpAppAuthRepColl = pageCollection.get(APP_SBMS_COLLECTION) != null ? (APP_SBMS_Collection)pageCollection.get(APP_SBMS_COLLECTION) : null;
		if(cpAppAuthRepColl != null && cpAppAuthRepColl.size() > 0) {
			cpAppAuthRepCargo = (APP_SBMS_Cargo) cpAppAuthRepColl.get(0);
		}
		cpAppAuthRepCargoList.add(cpAppAuthRepCargo);
        
		driverPageResponse.getPageCollection().put(APP_SBMS_COLLECTION, cpAppAuthRepCargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(String.valueOf(fwTxn.getSession().get(FwConstants.APP_NUMBER)));
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

        return driverPageResponse;

    }


}
