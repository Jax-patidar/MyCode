package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_INDV_INFO_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_CC_SCRNR_INDV_INFO_Key;

@NoRepositoryBean
public interface CpCcScrnrIndvInfoRepository extends CrudRepository<CP_CC_SCRNR_INDV_INFO_Cargo,CP_CC_SCRNR_INDV_INFO_Key>{
	
	@Query("select c from CP_CC_SCRNR_INDV_INFO_Cargo c where c.app_num = ?1 order by indv_seq_num")
	public CP_CC_SCRNR_INDV_INFO_Cargo[] getByAppNumSorted(String appNum);

}
