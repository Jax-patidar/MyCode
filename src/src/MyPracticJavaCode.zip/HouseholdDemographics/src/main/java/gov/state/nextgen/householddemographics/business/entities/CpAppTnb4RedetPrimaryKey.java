package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CpAppTnb4RedetPrimaryKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8342948204615761985L;
	private Integer app_number;

	public CpAppTnb4RedetPrimaryKey() {
	}

	public CpAppTnb4RedetPrimaryKey(Integer appNum) {
		super();
		this.app_number = appNum;
	}

	/**
	 * @return the appNum
	 */
	public Integer getAppNum() {
		return app_number;
	}

	public void setAppNum(Integer appNum) {
		this.app_number = appNum;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		return result;
	}

	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CpAppTnb4RedetPrimaryKey other = (CpAppTnb4RedetPrimaryKey) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		return true;
	}
	
	

}
