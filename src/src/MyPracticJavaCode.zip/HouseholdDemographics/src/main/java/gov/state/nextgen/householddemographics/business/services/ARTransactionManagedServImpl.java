
package gov.state.nextgen.householddemographics.business.services;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.entityurl.UrlPermission;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.access.management.util.FwDate;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_SBMS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_AUTOMATED_SMS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.business.rules.ABCreateAppNumBO;
import gov.state.nextgen.householddemographics.business.rules.GenerateNextCntlNumBO;
import gov.state.nextgen.householddemographics.business.rules.PeopleHandler;
import gov.state.nextgen.householddemographics.business.rules.RMBRequestBO;
import gov.state.nextgen.householddemographics.business.rules.ReportMyChangeBO;
import gov.state.nextgen.householddemographics.business.rules.ReviewMyBenefitsBO;
import gov.state.nextgen.householddemographics.configuration.AWSProperties;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.AppSbmsRepository;
import gov.state.nextgen.householddemographics.data.db2.AutomatedSMSRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.RMBRqstRepository;
import gov.state.nextgen.householddemographics.model.AppSummaryDtlsModel;
import gov.state.nextgen.householddemographics.model.NotificationModel;

/**
 * Transaction Managed Service
 * 
 * @author Deloitte
 *
 */
@SuppressWarnings("squid:S2229")
@Service("ARTransactionManagedService")
public class ARTransactionManagedServImpl implements HouseholdDemographicsService {

	@Autowired
	ABCreateAppNumBO createAppNumBo;

	@Autowired
	CpAppPgmRqstRepository appPrgmRqstRepo;

	@Autowired
	RMBRequestBO rmbRqstBo;

	@Autowired
	RMBRqstRepository rmbRqstRepo;

	@Autowired
	ReviewMyBenefitsBO reviewBenfBO;

	@Autowired
	FwDate date;

	@Autowired
	GenerateNextCntlNumBO generateCntlNum;

	@Autowired
	CpAppRqstRepository appRqstRepository;

	@Autowired
	AppSbmsRepository appsbms;

//	@Autowired
//	AWSSQSService sqsService;

	@Autowired
	AWSProperties awsProperties;

	@Autowired
	private ExceptionUtil exceptionUtil;

	@Autowired 
	UserCredentialServImpl userCredService;
	@Autowired 
	RMCHouseHoldDemographicsServiceImpl rmcHouseholdDemoServ;
	@Autowired
	protected LambdaInvokerServiceImpl lambdaService;
	@Autowired
	private ReportMyChangeBO reportMyChangeBO;
	
	@Autowired
	AutomatedSMSRepository autoSMSRepo;

	private static final String APP_SBMS_COLL = "APP_SBMS_Collection";
	private static final String APPNUM = "appNum";


	/**
	 * To call specific business method of the same bean
	 */
	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {

		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.STORERMBLANDINGPAGE:
			this.storeRMBLandingPage(fwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.LOADRMBLANDING:
			this.loadRMBLanding(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_SIGN_YOUR_APPL:
			this.storeSigningYourApplication(fwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.STORE_SIGN_APPL_1:
			this.storeSigningYourApplication1(fwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.UPDATE_APPLN_SUB_DIVIDER:
			this.updateApplicationSubmissionDivider(fwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.GETOFFICESELECTION:
			getOfficeSelection(fwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.STOREOFFICESELECTION:
			storeOfficeSelection(fwTxn);
			break;

		case HouseHoldDemoGraphicsConstants.GET_SBMS_DATA:
			getSBMSData(fwTxn);
			break;
		default:
		}
	}

	private void getSBMSData(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.getSBMSData() - START", fwTxn);
		Map<Object, Object> pageCollection = fwTxn.getPageCollection();
		try {
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			APP_SBMS_Collection appSbmsCollection = appsbms.findAllByAppNum(Integer.parseInt(appNumber));
			pageCollection.put(APP_SBMS_COLL, appSbmsCollection);
			fwTxn.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ARTransactionManagedServImpl.getSBMSData()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getSBMSData",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.getSBMSData() - END", fwTxn);

	}

	@SuppressWarnings({"squid:S2230","squid:S3776"})
	@Transactional
	public void updateApplicationSubmissionDivider(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ARTransactionManagedServImpl.updateApplicationSubmissionDivider() - START", fwTxn);
		try {

			final Map pageCollection = fwTxn.getPageCollection();
			// RQST Coll form request for saving changes reported in RAC flow
			APP_RQST_Collection appRqstColl = (APP_RQST_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_RQST_COLL);
			
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			APP_RQST_Collection rqstCollection = appRqstRepository.getByAppNum(Integer.parseInt(appNum));
			APP_RQST_Cargo rqstCargo = rqstCollection.getCargo(0);

			Date fwDate = FwDate.getInstance().getDate();
			rqstCargo.setAppSbmtTms(fwDate);
			rqstCargo.setApp_stat_cd(HouseHoldDemoGraphicsConstants.APP_STATUS_CODE);
			// Setting changes reported column to save changes reported in RAC flow. for
			// displaying changes on RAC COnf receipt screen.
			if (null != appRqstColl && !appRqstColl.isEmpty()) {
				rqstCargo.setChanges_reported(appRqstColl.getCargo(0).getChanges_reported());
				rqstCargo.setLangCode(appRqstColl.getCargo(0).getLangCode());
			}
			rqstCollection.setCargo(0, rqstCargo);
			String caseNumber = rqstCargo.getCaseNum();
			appRqstRepository.save(rqstCargo);

			// call method to store sbms_dt
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"Call storeApplicationSubmissionDate() to store sbms_dt");
			
			storeApplicationSubmissionDate(fwTxn, caseNumber);

			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, rqstCollection);
			fwTxn.setPageCollection(pageCollection);

			// Application Submission async call to App Submisison lambda

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"*****Code changes committed with removing submitApplication() call*****");
			if(pageCollection.get(AppConstants.FLOW_MODE) != null && (AppConstants.CF37_FLOW.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
			|| AppConstants.AFB.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString()))
			&& pageCollection.get(HouseHoldDemoGraphicsConstants.SMS_NOTIFICATION_DATA) != null)
			{
				Map smsNOtificationMap=(Map) pageCollection.get(HouseHoldDemoGraphicsConstants.SMS_NOTIFICATION_DATA);
				if(smsNOtificationMap != null)
				{
					ObjectMapper objectMapper = new ObjectMapper();
					FwLogger.log(this.getClass(), FwLogger.Level.INFO," smsNOtificationMap :: "+smsNOtificationMap);
					NotificationModel smsPayLoadModel=objectMapper.convertValue(smsNOtificationMap, NotificationModel.class);
					if(smsPayLoadModel != null)
					{
						Map params=smsPayLoadModel.getParams();
						if(smsPayLoadModel.getSmsInfo() != null && smsPayLoadModel.getSmsInfo().getTo() != null && smsPayLoadModel.getSmsInfo().getFrom() != null
						&& params != null && params.get(HouseHoldDemoGraphicsConstants.SEND_NEXT_DAY) != null 
						&& HouseHoldDemoGraphicsConstants.Y.equalsIgnoreCase(params.get(HouseHoldDemoGraphicsConstants.SEND_NEXT_DAY).toString()))
						{
							CP_AUTOMATED_SMS_Cargo smsObj=new CP_AUTOMATED_SMS_Cargo();
							smsObj.setFrom_number(smsPayLoadModel.getSmsInfo().getFrom());
							smsObj.setTo_number(smsPayLoadModel.getSmsInfo().getTo());
							smsObj.setFlow_name(pageCollection.get(AppConstants.FLOW_MODE).toString());
							smsObj.setNotification_status(HouseHoldDemoGraphicsConstants.OPEN_STATUS);
							if(caseNumber != null && !HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(caseNumber.trim()))
							{
								smsObj.setApp_case_num(caseNumber);
							}else if(appNum != null && !HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(appNum.trim()))
							{
								smsObj.setApp_case_num(appNum);
							}
						
							if(params.get(HouseHoldDemoGraphicsConstants.RECV_FLOW_TEXT) != null
							&& params.get(HouseHoldDemoGraphicsConstants.TEXT_FLOW_TYPE) != null
							&& params.get(HouseHoldDemoGraphicsConstants.RECV_FLOW_COM_TEXT) != null
							&& params.get(HouseHoldDemoGraphicsConstants.TEXT_PHONE_NUM) != null
							&& params.get(HouseHoldDemoGraphicsConstants.TEXT_DATE) != null
							)
							{
								String message="BenefitsCal: "+params.get(HouseHoldDemoGraphicsConstants.RECV_FLOW_TEXT)+" "+
										params.get(HouseHoldDemoGraphicsConstants.TEXT_FLOW_TYPE)+
										params.get(HouseHoldDemoGraphicsConstants.RECV_FLOW_COM_TEXT)+" "+
										params.get(HouseHoldDemoGraphicsConstants.TEXT_PHONE_NUM);
								smsObj.setText_message(message);
								SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
								smsObj.setText_sent_date(format.parse(params.get(HouseHoldDemoGraphicsConstants.TEXT_DATE).toString()));
								if(params.get(HouseHoldDemoGraphicsConstants.TEXT_HOURS) != null
								&& params.get(HouseHoldDemoGraphicsConstants.TEXT_HOURS_VALUE) != null)
								{
									String messageN=params.get(HouseHoldDemoGraphicsConstants.TEXT_HOURS)+" "+
												params.get(HouseHoldDemoGraphicsConstants.TEXT_HOURS_VALUE);
									smsObj.setText_message(smsObj.getText_message()+messageN);
									String textHours=params.get(HouseHoldDemoGraphicsConstants.TEXT_HOURS_VALUE).toString();
									String startHourVal="";
									if(textHours != null && !HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(textHours.trim()))
									{
										startHourVal=textHours.split("-")[0];
										if(startHourVal != null && !HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(startHourVal.trim()))
										{
											String startTimeVal=startHourVal.split(":")[0];
											if(startTimeVal != null && !HouseHoldDemoGraphicsConstants.EMPTY.equalsIgnoreCase(startTimeVal.trim())
											&& startTimeVal.length() == 1)
											{
												startTimeVal="0"+startTimeVal;
											}
											String finalHour=startTimeVal;
											if(startHourVal.split(":").length > 1)
											{
												finalHour=finalHour+":"+startHourVal.split(":")[1];
											}
											smsObj.setStart_hour(finalHour.trim());
										}
									}
									autoSMSRepo.save(smsObj);
								}
							}
						}
					}
				}
			}

			// report change
			if ((AppConstants.RAC_FLOW).equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())) {
				ObjectMapper objectMapper = new ObjectMapper();
				APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
				APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);
				Map<String, String> mapPayLoad = new HashMap<>();
				Map<String, String> summaryMapPayLoad = new HashMap<>();
				summaryMapPayLoad.put("caseNumber", rqstCargo.getCaseNum());	
				summaryMapPayLoad.put("countyCode", appSbmsCargo.getCase_county_cd());
				AppSummaryDtlsModel appSummaryPayLoad = new AppSummaryDtlsModel();
				if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_CASE_ID))
				{
					String caseID = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_CASE_ID);
					appSummaryPayLoad.setCaseId(caseID);
				}
				if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_CASE_NAME))
				{
					String caseName = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_CASE_NAME);
					appSummaryPayLoad.setCaseName(caseName);
				}
				final UserDetails userDet = fwTxn.getUserDetails();
				String gUID = userDet.getLoginUserId();
				appSummaryPayLoad.setGuid(gUID);
				
				summaryMapPayLoad.put("changeReportSummary", appSbmsCargo.getChange_summary());
				mapPayLoad.put(APPNUM, appNum);
				mapPayLoad.put(HouseHoldDemoGraphicsConstants.FORM_TYPE,
						HouseHoldDemoGraphicsConstants.REPORTACHANGE);
				mapPayLoad.put("payload", objectMapper.writeValueAsString(summaryMapPayLoad));

//				String payLoad = sqsService.getResponseBody(mapPayLoad);
//				sqsService.sendMessage(payLoad, awsProperties.getReportAChangeQueueName());
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"Successfully sent message APP Transfer message  to"
								+ awsProperties.getReportAChangeQueueName());
				//App Summary invocation queue logic
				pushMsgToAppSummaryQueue(appNum, rqstCargo, appSbmsCargo, HouseHoldDemoGraphicsConstants.FORM_TYPE_RAC,appSummaryPayLoad);
				/*
				 * try { AppSummaryDtlsModel model = new AppSummaryDtlsModel();
				 * model.setAppNum(appNum); model.setCaseNumber(rqstCargo.getCaseNum());
				 * model.setCountyCode(appSbmsCargo.getCase_county_cd());
				 * model.setFormType(HouseHoldDemoGraphicsConstants.FORM_TYPE_RAC);
				 * model.setIndvIds(getIndvArray(appNum));
				 * model.setLangCode(rqstCargo.getLangCode()); String appSumPayLoad =
				 * sqsService.getResponseBody(model); sqsService.sendMessage(appSumPayLoad,
				 * awsProperties.getAppSummaryInvocationQueue()); FwLogger.log(this.getClass(),
				 * FwLogger.Level.INFO, "Successfully sent APP Summary invocation message  to" +
				 * awsProperties.getAppSummaryInvocationQueue() +
				 * " with payload : "+appSumPayLoad); }catch(Exception fe) {
				 * FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
				 * "Error occured in while populating app summary queue", fwTxn); }
				 */
			} else if ((AppConstants.CF37_FLOW)
					.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())) {
				Map<String, String> mapPayLoad = new HashMap<>();
				mapPayLoad.put(APPNUM, appNum);
				mapPayLoad.put(HouseHoldDemoGraphicsConstants.FORM_TYPE, HouseHoldDemoGraphicsConstants.CFFORMTYPE);
//				String payLoad = sqsService.getResponseBody(mapPayLoad);
//				sqsService.sendMessage(payLoad, awsProperties.getCf37QueueName());
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"Successfully sent message CF37 message  to" + awsProperties.getCf37QueueName());
				/* App Summary invocation queue logic */
				APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
				APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);				
				AppSummaryDtlsModel appSummaryPayLoad = new AppSummaryDtlsModel();
				if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_CASE_ID))
				{
					String caseID = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_CASE_ID);
					appSummaryPayLoad.setCaseId(caseID);
				}
				if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_CASE_NAME))
				{
					String caseName = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_CASE_NAME);
					appSummaryPayLoad.setCaseName(caseName);
				}
				final UserDetails userDet = fwTxn.getUserDetails();
				String gUID = userDet.getLoginUserId();
				appSummaryPayLoad.setGuid(gUID);
				if((null == appSbmsCargo.getCase_county_cd() || appSbmsCargo.getCase_county_cd().isEmpty()) && pageCollection.containsKey("countyCode")) {					
						appSbmsCargo.setCase_county_cd((String)pageCollection.get("countyCode"));					
				}
				pushMsgToAppSummaryQueue(appNum, rqstCargo, appSbmsCargo, AppConstants.CF37_FLOW,appSummaryPayLoad);
				

			} else if ((AppConstants.PR_FLOW).equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())) {
				Map<String, String> mapPayLoad = new HashMap<>();
				mapPayLoad.put(APPNUM, appNum);
				mapPayLoad.put(HouseHoldDemoGraphicsConstants.FORM_TYPE, HouseHoldDemoGraphicsConstants.SAR7FORMTYPE);
//				String payLoad = sqsService.getResponseBody(mapPayLoad);
//				sqsService.sendMessage(payLoad, awsProperties.getPeriodicReportQueueName());
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"Successfully sent message PR message  to" + awsProperties.getPeriodicReportQueueName());
				/* App Summary invocation queue logic */
				APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
				APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);				
				AppSummaryDtlsModel appSummaryPayLoad = new AppSummaryDtlsModel();
				if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_CASE_ID))
				{
					String caseID = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_CASE_ID);
					appSummaryPayLoad.setCaseId(caseID);
				}
				if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_CASE_NAME))
				{
					String caseName = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_CASE_NAME);
					appSummaryPayLoad.setCaseName(caseName);
				}
				final UserDetails userDet = fwTxn.getUserDetails();
				String gUID = userDet.getLoginUserId();
				appSummaryPayLoad.setGuid(gUID);
				if((null == appSbmsCargo.getCase_county_cd() || appSbmsCargo.getCase_county_cd().isEmpty()) && pageCollection.containsKey("case_county_cd")) {					
						appSbmsCargo.setCase_county_cd((String)pageCollection.get("case_county_cd"));					
				}
				pushMsgToAppSummaryQueue(appNum, rqstCargo, appSbmsCargo, AppConstants.PR_FLOW,appSummaryPayLoad);
				

			} else if ((AppConstants.MCR_FLOW).equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())) {
				
				Map<String, String> mapPayLoad = new HashMap<>();
				mapPayLoad.put(APPNUM, appNum);
				APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
				APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);			
				AppSummaryDtlsModel appSummaryPayLoad = new AppSummaryDtlsModel();	
				if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_CASE_ID))
				{
					String caseID = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_CASE_ID);
					appSummaryPayLoad.setCaseId(caseID);
				}
				if(pageCollection.containsKey(HouseHoldDemoGraphicsConstants.AS_CASE_NAME))
				{
					String caseName = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.AS_CASE_NAME);
					appSummaryPayLoad.setCaseName(caseName);
				}
				final UserDetails userDet = fwTxn.getUserDetails();
				String gUID = userDet.getLoginUserId();
				appSummaryPayLoad.setGuid(gUID);
				if((null == appSbmsCargo.getCase_county_cd() || appSbmsCargo.getCase_county_cd().isEmpty()) && pageCollection.containsKey("countyCode")) {					
						appSbmsCargo.setCase_county_cd((String)pageCollection.get("countyCode"));				
				}
				if (AppConstants.RMB_MC_210_FORM_TYPE.equalsIgnoreCase(rqstCargo.getFormRptType())) {
					mapPayLoad.put(HouseHoldDemoGraphicsConstants.FORM_TYPE, AppConstants.MC_210_FORM_TYPE);
					pushMsgToAppSummaryQueue(appNum, rqstCargo, appSbmsCargo, AppConstants.MC_210_FORM_TYPE,appSummaryPayLoad);
				}
				else if (AppConstants.RMB_MC_216_FORM_TYPE.equalsIgnoreCase(rqstCargo.getFormRptType())) {
					mapPayLoad.put(HouseHoldDemoGraphicsConstants.FORM_TYPE, AppConstants.MC_216_FORM_TYPE);
					pushMsgToAppSummaryQueue(appNum, rqstCargo, appSbmsCargo, AppConstants.MC_216_FORM_TYPE,appSummaryPayLoad);
				}
				else if (AppConstants.RMB_MC_217_FORM_TYPE.equalsIgnoreCase(rqstCargo.getFormRptType())) {
					mapPayLoad.put(HouseHoldDemoGraphicsConstants.FORM_TYPE, AppConstants.MC_217_FORM_TYPE);
					pushMsgToAppSummaryQueue(appNum, rqstCargo, appSbmsCargo, AppConstants.MC_217_FORM_TYPE,appSummaryPayLoad);
				}
				
//         		APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
//				APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);
				pushMsgToAppSummaryQueue(appNum, rqstCargo, appSbmsCargo, AppConstants.MCR_FLOW,new AppSummaryDtlsModel());
//				String payLoad = sqsService.getResponseBody(mapPayLoad);
//				sqsService.sendMessage(payLoad, awsProperties.getMedicalQueueName());

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"Successfully sent message PR message  to" + awsProperties.getMedicalQueueName());

			} else {
				// THIS IS FOR apptransfer and app summary
				try {
					Map<String, String> mapPayLoad = new HashMap<>();
					mapPayLoad.put(APPNUM, appNum);
					if ((AppConstants.DCF_FLOW)
							.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())) {
						
						//App Summary invocation queue logic
						APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
						APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);
						pushMsgToAppSummaryQueue(appNum, rqstCargo, appSbmsCargo, AppConstants.DCF_FLOW,new AppSummaryDtlsModel());
						
						//App Transfer Initialization
						mapPayLoad.put(HouseHoldDemoGraphicsConstants.FORM_TYPE,
								HouseHoldDemoGraphicsConstants.DISASTERAPPTRANSFER);
						
					} 
					else if(AppConstants.AFB_FLOW.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString()))
						{
							AppSummaryDtlsModel appSummaryDetails = new AppSummaryDtlsModel();
							String languageCode = "EN";
							appSummaryDetails.setAppNum(appNum);
							if(pageCollection.containsKey("LANGUAGE"))
							{
								String langcode = (String) pageCollection.get("LANGUAGE");
								if(null != langcode && !langcode.trim().isEmpty())
								{
									languageCode = langcode;
								}
							}
							if(pageCollection.containsKey("countyCode"))
							{
								String countyCode = (String) pageCollection.get("countyCode");
								appSummaryDetails.setCountyCode(countyCode);
							}
							appSummaryDetails.setLangCode(languageCode);
							appSummaryDetails.setFormType(AppConstants.AFB_FLOW);	
							addMessageToQueue(appSummaryDetails);
							mapPayLoad.put(HouseHoldDemoGraphicsConstants.FORM_TYPE, HouseHoldDemoGraphicsConstants.APPTRANSFER);// add constant
					}
//					String payLoad = sqsService.getResponseBody(mapPayLoad);
//					sqsService.sendMessage(payLoad, awsProperties.getAppTransferQueueName());
					FwLogger.log(this.getClass(), FwLogger.Level.INFO,
							"Successfully sent message APP Transfer message  to"
									+ awsProperties.getAppTransferQueueName());
					
					
					
					} catch (Exception e) {
						throw e;
					}
								
				// for SAWS2Plus
				if (!((AppConstants.DCF_FLOW).equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
						|| (AppConstants.CF37_FLOW)
								.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
						|| (AppConstants.PR_FLOW)
								.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
						|| (AppConstants.MCR_FLOW)
								.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString()))) {
					Map<String, String> mapPayLoad = new HashMap<>();
					mapPayLoad.put(APPNUM, appNum);
					mapPayLoad.put("formType", HouseHoldDemoGraphicsConstants.SAWS2PLUS);
//					String payLoad = sqsService.getResponseBody(mapPayLoad);
//					sqsService.sendMessage(payLoad, awsProperties.getSaws2PlusQueueName());
					FwLogger.log(this.getClass(), FwLogger.Level.INFO,
							"Successfully sent message SAWS2Plus message to"
									+ awsProperties.getSaws2PlusQueueName());
					

				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ARTransactionManagedServImpl.updateApplicationSubmissionDivider() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime), fwTxn);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ARTransactionManagedServImpl.updateApplicationSubmissionDivider()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(),
					"updateApplicationSubmissionDivider", fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}

	}
	
	public void pushMsgToAppSummaryQueue(String appNum, APP_RQST_Cargo rqstCargo,APP_SBMS_Cargo appSbmsCargo, String mode,AppSummaryDtlsModel model) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.pushMsgToAppSummaryQueue() - START");
			
			model.setAppNum(appNum);
			model.setCaseNumber(rqstCargo.getCaseNum());			
			model.setCountyCode(appSbmsCargo.getCase_county_cd());			
			model.setFormType(mode);	
			model.setIndvIds(getIndvArray(appNum));
			model.setLangCode(rqstCargo.getLangCode());				
			addMessageToQueue(model);
	}

	public void addMessageToQueue(AppSummaryDtlsModel appSummaryDetails)
	{
		try {
//			String appSumPayLoad = sqsService.getResponseBody(appSummaryDetails);
//			sqsService.sendMessage(appSumPayLoad, awsProperties.getAppSummaryInvocationQueue());
//			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
//					"Successfully sent APP Summary invocation message  to"
//							+ awsProperties.getAppSummaryInvocationQueue() + " with payload : "+appSumPayLoad);
		}catch(Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in while populating app summary queue");
		}
	}
	// new method added for WPIntegration
	public void storeSigningYourApplication(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.storeSigningYourApplication() - START", txnBean);
		try {
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();
			APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
			APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);
			((APP_SBMS_Cargo) appSbmsCargo).setApp_num(String.valueOf(appNumber));
			if (null != appSbmsCargo.getE_sign_ind1()) {
				appSbmsCargo.setE_sign_ind(appSbmsCargo.getE_sign_ind1()[0]);
			}
			appsbms.save(appSbmsCargo);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ARTransactionManagedServImpl.storeSigningYourApplication()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeSigningYourApplication",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.storeSigningYourApplication() - END", txnBean);
	}

	@Transactional
	public void storeSigningYourApplication1(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ARTransactionManagedServImpl.storeSigningYourApplication1() - START", txnBean);
		try {
			final Map pageCollection = txnBean.getPageCollection();
			final String appNumber = txnBean.getUserDetails().getAppNumber();

			APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
			APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);
			((APP_SBMS_Cargo) appSbmsCargo).setApp_num(String.valueOf(appNumber));
			if (null != appSbmsCargo.getSps_esign_ind1()) {
				appSbmsCargo.setSps_esign_ind(appSbmsCargo.getSps_esign_ind1()[0]);
			}
			appsbms.save(appSbmsCargo);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ARTransactionManagedServImpl.storeSigningYourApplication1()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeSigningYourApplication1",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.storeSigningYourApplication1() - END", txnBean);
	}

	// new method to store sbms_dt
	public void storeApplicationSubmissionDate(final FwTransaction txnBean, String caseNumber) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.storeApplicationSubmissionDate() - START", txnBean);
		final Map pageCollection = txnBean.getPageCollection();
		final String appNumber = txnBean.getUserDetails().getAppNumber();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Inside storeApplicationSubmissionDate method");
		APP_SBMS_Collection appSbmsColl = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
		APP_SBMS_Cargo appSbmsCargo = appSbmsColl.getCargo(0);
		((APP_SBMS_Cargo) appSbmsCargo).setApp_num(String.valueOf(appNumber));
		if (((AppConstants.DCF_FLOW).equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
				|| (AppConstants.MCR_FLOW).equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString()))
				&& null != appSbmsCargo.getE_sign_ind1()) {
			appSbmsCargo.setE_sign_ind(appSbmsCargo.getE_sign_ind1()[0]);
		}
		if (AppConstants.MCR_FLOW.equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())) {
			appSbmsCargo.setCase_num(caseNumber);
		}
		Date date = new Date();
		appSbmsCargo.setSbms_dt(date);
		appsbms.save(appSbmsCargo);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.storeApplicationSubmissionDate() - END", txnBean);
	}

	@Transactional
	public void storeRMBLandingPage(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ARTransactionManagedEJBBean.storeRMBLandingPage() - START", txnBean);
		try {
			// Getting the session
			final Map request = txnBean.getRequest();
			final Map pageCollection = txnBean.getPageCollection();
			final UserDetails userDet = txnBean.getUserDetails();
			/*
			 * final Map beforeColl = (Map) session .get(FwConstants.BEFORE_COLLECTION);
			 */
			final PeopleHandler peopleHandler = new PeopleHandler();
			String appNumber = null;
			/*
			 * final Map httpSessionMap = (Map) session .get(FwConstants.HTTP_SESSION);
			 * httpSessionMap.get(FwConstants.SECURED_SESSION);
			 */

			String languageCd = (String) request.get(AppConstants.LANGUAGE);
			if ((languageCd == null) || (languageCd.trim().length() == 0)) {
				languageCd = "EN";
			}
			// validation

			final RMB_RQST_Collection rmbRqstColl = new RMB_RQST_Collection();

			FwMessageList validateInfo = null;
			// validation
			final APP_PGM_RQST_Collection appPgmRqstColl = (APP_PGM_RQST_Collection) pageCollection
					.get("APP_PGM_RQST_Collection");
			APP_PGM_RQST_Cargo appPgmRqstCargo = null;
			if (appPgmRqstColl != null) {
				appPgmRqstCargo = appPgmRqstColl.getCargo(0);
			}

			final String backToMyAccess = (String) request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON);

			if (backToMyAccess == null) {
				validateInfo = reviewBenfBO.validateRMBLandingPage(appPgmRqstColl, languageCd);
			}

			// Below code is commented out for warning message. This will be handled at UI
			// level
			/*
			 * if (checkBackToMyAccessSelected(request) || validateInfo != null &&
			 * validateInfo.hasMessages()) { final String reqWarningMsgs = (String) request
			 * .get(FwConstants.WARNING_MSG_DETAILS); if
			 * (!checkForWarningMesgs(reqWarningMsgs, reviewBenfBO.getMessageList())) { if
			 * (backToMyAccess == null) { request.put(FwConstants.MESSAGE_LIST,
			 * reviewBenfBO.getMessageList()); } request.put("RMB_PRGM_DET_MAP",
			 * beforeColl.get("RMB_PRGM_DET_MAP")); pageCollection.putAll(beforeColl);
			 * pageCollection.put("APP_PGM_RQST_Collection",appPgmRqstColl);
			 * txnBean.setPageCollection(pageCollection); txnBean.setRequest(request);
			 * return; } }
			 */
			String caseNumber = null;
			if (request.containsKey(AppConstants.REVIEW_CASE_NUM)) {
				caseNumber = (String) request.get(AppConstants.REVIEW_CASE_NUM);
			} else if (userDet.getCaseNumber() != null) {
				caseNumber = userDet.getCaseNumber();
			}

			if (caseNumber != null) {
				if (userDet.getAppNumber() != null) {
					appNumber = userDet.getAppNumber();
				}

				String acsId = FwConstants.EMPTY_STRING;
				acsId = userDet.getLoginUserId();

				createAppNumBo.storeAcsIdAndAppNum(acsId, appNumber);

				if (appPgmRqstColl != null && !appPgmRqstColl.isEmpty()) {

					appPgmRqstCargo = appPgmRqstColl.getCargo(0);

					appPgmRqstCargo.setApp_num(appNumber);
					appPrgmRqstRepo.save(appPgmRqstCargo);

				}

				// call createCaseNumber on RMB Request Manager
				final RMB_RQST_Cargo rmbRqstCargo = rmbRqstBo.createRMBRequest(appNumber, caseNumber);
				rmbRqstColl.addCargo(rmbRqstCargo);

				// find the earlieast review daue date
				final Map rmbDetMap = (Map) request.get("RMB_PRGM_DET_MAP");

				final RMB_RQST_Cargo rmbRqstUpdateCargo = rmbRqstColl.getCargo(0);

				// PCR# 43100 - RMB-CLA Renewals changes
				rmbRqstUpdateCargo.setCla_due_dt(
						new java.sql.Timestamp(reviewBenfBO.findBCLADueDate(rmbDetMap).getTime()).toLocalDateTime());
				// if its only CLA renewals than we have to set CLA_DUE_DT as
				// DUE_DT

				if (rmbRqstUpdateCargo.getDue_dt() != null
						&& rmbRqstUpdateCargo.getDue_dt().equals(HouseHoldDemoGraphicsConstants.HIGH_DATE_VALUE)) {
					rmbRqstUpdateCargo.setDue_dt(rmbRqstUpdateCargo.getCla_due_dt());
				}
				rmbRqstRepo.save(rmbRqstUpdateCargo);

				reviewBenfBO.updateAppType("RMB", appNumber);

			}

			FwLogger.log(this.getClass(), Level.INFO, "ARTransactionManagedEJBBean::storeRMBLandingPage:End", txnBean);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ARTransactionManagedServImpl.storeRMBLandingPage:End()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeRMBLandingPage",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO,
				"ARTransactionManagedEJBBean.storeRMBLandingPage() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}

	/**
	 * Load rmb landing.
	 *
	 * 
	 */
	@Transactional
	@SuppressWarnings("squid:S3776")
	public void loadRMBLanding(final FwTransaction fwTrxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.loadRMBLanding() - START",
				fwTrxn);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadRMBLanding() inside try *****// - START " +fwTrxn);
		try {
			FwDate fwDate = FwDate.getInstance();

			/* Added to get CaseNum and Form Type values */
			final Map actualPageCollection = fwTrxn.getPageCollection();
			APP_RQST_Collection appRqstCollection = Objects.nonNull(actualPageCollection)
					&& Objects.nonNull(actualPageCollection.get(HouseHoldDemoGraphicsConstants.APP_RQST_COLL))
							? (APP_RQST_Collection) actualPageCollection
									.get(HouseHoldDemoGraphicsConstants.APP_RQST_COLL)
							: null;
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
											"RedeterminationServiceImpl.loadRMBLanding() inside try *****// - START " +appRqstCollection);
			APP_RQST_Cargo actualRqstCargo = null;
			if (Objects.nonNull(appRqstCollection) && !appRqstCollection.isEmpty()) {
				actualRqstCargo = appRqstCollection.getCargo(0);
			}

			final UserDetails userDet = fwTrxn.getUserDetails();
			String gUID = userDet.getLoginUserId();
			String nextCntlNum = null;
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.loadRMBLanding() inside before calling  generateCntlNum.getNextCntlNum()*****// - START " +appRqstCollection);
			nextCntlNum = generateCntlNum.getNextCntlNum();
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.loadRMBLanding() inside after calling  generateCntlNum.getNextCntlNum()*****// - START " +nextCntlNum);

			if (gUID == null || gUID.isEmpty()) {
				UrlPermission urlObj = new UrlPermission();
				String tokenA = urlObj.generateToken(nextCntlNum);
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Token generated :" + tokenA, fwTrxn);
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.loadRMBLanding() UrlPermission token*****// - START " +nextCntlNum);
				userDet.setTokenA(tokenA);
				fwTrxn.setUserDetails(userDet);
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.loadRMBLanding() settinguserdetails*****// - START " +nextCntlNum);
			}

			Map pageCollection = new HashMap();
			pageCollection.put("APP_NUM", nextCntlNum);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.loadRMBLanding() setting appnum into pagecollection*****// - START " +nextCntlNum);
			fwTrxn.setPageCollection(pageCollection);
			APP_RQST_Cargo rqstCargo = new APP_RQST_Cargo();
			rqstCargo.setApp_num(nextCntlNum);
			rqstCargo.setHshl_indv_ct(0);
			Date date = new Date();

			rqstCargo.setApp_cplt_tms(fwDate.getTimestamp());
			rqstCargo.setApp_strt_tms(fwDate.getTimestamp());
			rqstCargo.setUpdt_dt(fwDate.getTimestamp());
			rqstCargo.setApp_stat_cd(HouseHoldDemoGraphicsConstants.IN_PROGRESS);

			/* Added to set CaseNum and Form Type values */
			if (Objects.nonNull(actualRqstCargo)) {
				rqstCargo.setCaseNum(actualRqstCargo.getCaseNum());
				rqstCargo.setFormRptType(actualRqstCargo.getFormRptType());
			}

			/*
			 * Updating RMB_RQST_Cargo.SSP_APP_NUM using generated app_num for
			 * rmb_request_id for renewals
			 */
			String mode = Objects.nonNull(actualPageCollection) ? (String) actualPageCollection.get("Mode")
					: StringUtils.EMPTY;
			if (StringUtils.isNotEmpty(mode) && HouseHoldDemoGraphicsConstants.CW_REDET_MODE.equals(mode)
					&& null != actualRqstCargo
					&& actualRqstCargo.getFormRptType().contains(HouseHoldDemoGraphicsConstants.CALWORKS_REDET)) {
				RMB_RQST_Collection rmbRqstCollection = (RMB_RQST_Collection) actualPageCollection
						.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION);

				if (Objects.nonNull(rmbRqstCollection) && !rmbRqstCollection.isEmpty()) {
					RMB_RQST_Cargo rmbRqstCargo = rmbRqstCollection.getCargo(0);
					Long cpRmbRequestId = rmbRqstCargo.getCp_rmb_request_id();
					Timestamp update_dt = new Timestamp(new Date().getTime());
					rmbRqstRepo.updateSspAppNum(Integer.parseInt(nextCntlNum), cpRmbRequestId, update_dt);
				}
			}
			if (actualPageCollection != null && actualPageCollection.get(HouseHoldDemoGraphicsConstants.MODE) != null
					&& HouseHoldDemoGraphicsConstants.MC_MODE
							.equals(actualPageCollection.get(HouseHoldDemoGraphicsConstants.MODE))) {
				RMB_RQST_Collection rmbRqstCollection = (RMB_RQST_Collection) actualPageCollection
						.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION);

				if (Objects.nonNull(rmbRqstCollection) && !rmbRqstCollection.isEmpty()) {
					RMB_RQST_Cargo rmbRqstCargo = rmbRqstCollection.getCargo(0);
					Long cpRmbRequestId = rmbRqstCargo.getCp_rmb_request_id();
					Timestamp update_dt = new Timestamp(new Date().getTime());
					rmbRqstRepo.updateSspAppNum(Integer.parseInt(nextCntlNum), cpRmbRequestId, update_dt);
				}
			}
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.loadRMBLanding() saving into apprgstcollection*****// - START " +rqstCargo);

			appRqstRepository.save(rqstCargo);
			if ((Objects.nonNull(gUID)) && !gUID.trim().isEmpty()) {
				createAppNumBo.storeAcsIdAndAppNum(gUID, nextCntlNum);
				userCredService.addNewApplicationToUser(nextCntlNum, gUID);
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.loadRMBLanding() saving into apprgstcollectiongUID*****// - START " +gUID);
			} else {
				 userCredService.addNewApplicationToUser(nextCntlNum, userDet.getTokenA());
				 FwLogger.log(this.getClass(), FwLogger.Level.INFO,
							"RedeterminationServiceImpl.loadRMBLanding() saving into addNewApplicationToUser userDet.getTokenA*****// - START " +gUID);
				}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in loadRMBLanding()", fwTrxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadRMBLanding",
					fwTrxn.getUserDetails().getAppNumber(), fwTrxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.loadRMBLanding() - END",
				fwTrxn);
	}

	@Transactional
	public void getOfficeSelection(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.getOfficeSelection() - START", txnBean);
		Map<Object, Object> pageCollection = txnBean.getPageCollection();
		try {
			String appNumber = txnBean.getUserDetails().getAppNumber();
			APP_SBMS_Collection appSbmsCollection = appsbms.findAllByAppNum(Integer.parseInt(appNumber));
			pageCollection.put(APP_SBMS_COLL, appSbmsCollection);
			txnBean.setPageCollection(pageCollection);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ARTransactionManagedServImpl.getOfficeSelection()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getOfficeSelection",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.getOfficeSelection() - END", txnBean);
	}

	@Transactional
	public void storeOfficeSelection(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.storeOfficeSelection() - START", txnBean);
		final Map<Object, Object> pageCollection = txnBean.getPageCollection();
		String appNumber = txnBean.getUserDetails().getAppNumber();
		try {
			APP_SBMS_Collection appSbmsCollRequest = (APP_SBMS_Collection) pageCollection.get(APP_SBMS_COLL);
			if (null != appSbmsCollRequest && !appSbmsCollRequest.isEmpty()
					&& (null != appSbmsCollRequest.getCargo(0))) {
				APP_SBMS_Cargo appSbmsRequest = appSbmsCollRequest.getCargo(0);
				APP_SBMS_Collection appSbmsCollection = appsbms.findAllByAppNum(Integer.parseInt(appNumber));
				APP_SBMS_Cargo appSbmsCargo = null;
				if ((appSbmsCollection != null) && (!appSbmsCollection.isEmpty())) {
					appSbmsCargo = appSbmsCollection.getCargo(0);
					appSbmsCargo.setApplicant_first_name(appSbmsRequest.getApplicant_first_name());
					appSbmsCargo.setApplicant_last_name(appSbmsRequest.getApplicant_last_name());
					appSbmsCargo.setSign_dt(appSbmsRequest.getSign_dt());
					appSbmsCargo.setSps_fst_nam(appSbmsRequest.getSps_fst_nam());
					appSbmsCargo.setSps_last_nam(appSbmsRequest.getSps_last_nam());
					appSbmsCargo.setSps_sign_dt(appSbmsRequest.getSps_sign_dt());
					appSbmsCargo.setOffice_id(appSbmsRequest.getOffice_id());
					appsbms.save(appSbmsCargo);
				} else {
					appsbms.save(appSbmsRequest);
				}
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ARTransactionManagedServImpl.storeOfficeSelection()", txnBean);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeOfficeSelection",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.storeOfficeSelection() - END", txnBean);
	}
  @SuppressWarnings("squid:S1751")
	private Map<String, String> getAppPgmData(FwTransaction fwTxn, Map<String, String> appSummPayload) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.getAppPgmData() - START",
				fwTxn);
		Map<Object, Object> pageCollection = fwTxn.getPageCollection();
		try {
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			APP_PGM_RQST_Collection programColl = appPrgmRqstRepo.getDetails(Integer.parseInt(appNumber));
			if (null != programColl && !programColl.isEmpty()) {

				for (APP_PGM_RQST_Cargo cargo : programColl.getResults()) {

					if (cargo.getFs_rqst_ind() == 1) {
						appSummPayload.put("calFresh", "1");
					}
					if (cargo.getTanf_rqst_ind() == 1) {
						appSummPayload.put("calWorks", "1");
					}
					if (cargo.getFma_rqst_ind() == 1) {
						appSummPayload.put("mediCal", "1");
					}

					break;
				}
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in ARTransactionManagedServImpl.getAppPgmData()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "getAppPgmData",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.getAppPgmData() - END", fwTxn);
		return appSummPayload;
	}


		private List<String> getIndvArray(String appNum) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.getIndvArray() - START");
			List<String> indvIdList = new ArrayList<>();
			try {
				APP_INDV_Cargo[] updatedAppIndvArr = reportMyChangeBO.getAppIndvArrByAppNum(String.valueOf(appNum));
				if (null != updatedAppIndvArr && updatedAppIndvArr.length > 0) {
					for (APP_INDV_Cargo cargo : updatedAppIndvArr) {
						indvIdList.add(cargo.getIndv_seq_num().toString());
					}
				}
			} catch (Exception e) {
				FwLogger.log(this.getClass(), Level.ERROR, "getIndvArray", e);
				throw e;
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ARTransactionManagedServImpl.getIndvArray() - END");
			return indvIdList;
		}
}
