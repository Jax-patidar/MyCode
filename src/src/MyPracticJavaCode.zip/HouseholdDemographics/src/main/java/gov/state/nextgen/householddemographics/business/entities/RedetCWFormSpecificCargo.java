package gov.state.nextgen.householddemographics.business.entities;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

public class RedetCWFormSpecificCargo{
	
	private String case_num;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private LocalDate form_due_date;
	
	private String form_rpt_type ;

	public String getCase_num() {
		return case_num;
	}

	public void setCase_num(String case_num) {
		this.case_num = case_num;
	}

	public LocalDate getForm_due_date() {
		return form_due_date;
	}

	public void setForm_due_date(LocalDate form_due_date) {
		this.form_due_date = form_due_date;
	}

	public String getForm_rpt_type() {
		return form_rpt_type;
	}

	public void setForm_rpt_type(String form_rpt_type) {
		this.form_rpt_type = form_rpt_type;
	}

	
}
