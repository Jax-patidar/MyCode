package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_KEY;
import gov.state.nextgen.householddemographics.business.entities.OTHER_HOUSEHOLD_DETAILS_Collection;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
@Repository
public interface OtherHouseholdDetailsRepo extends CrudRepository<OTHER_HOUSEHOLD_DETAILS_Cargo,OTHER_HOUSEHOLD_DETAILS_KEY>{
	@Query("select c from OTHER_HOUSEHOLD_DETAILS_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public OTHER_HOUSEHOLD_DETAILS_Collection loadCaretakerExisitingDetail(Integer app_num, Integer indv_seq_num);
	
	@Query("select c from OTHER_HOUSEHOLD_DETAILS_Cargo c where c.app_number = ?1 and c.indv_seq_num IN ?2")
	public OTHER_HOUSEHOLD_DETAILS_Collection getDetailsByAppNumAndIndvIds(Integer app_num, List<Integer> indvIds);
	
	@Modifying
	@Transactional
	@Query("UPDATE OTHER_HOUSEHOLD_DETAILS_Cargo c SET c.fix_meal_personselection_resp = '' where c.app_number = ?1")
	public void updateFixMealsAsEmptyByAppNum(Integer app_num);
	
	@Modifying
	@Transactional
	@Query("UPDATE OTHER_HOUSEHOLD_DETAILS_Cargo c SET c.care_taker_resp = '' where c.app_number = ?1")
	public void updateCareTakerAsEmptyByAppNum(Integer app_num);
	
	
	@Query("select c from OTHER_HOUSEHOLD_DETAILS_Cargo c where c.app_number = ?1")
	public OTHER_HOUSEHOLD_DETAILS_Collection getDetailsByAppNum(Integer app_num);
}
