package gov.state.nextgen.householddemographics.business.entities;

import java.rmi.RemoteException;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * @author ransahu
 *
 */
public class CpUserSurveys_Collection extends AbstractCollection {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8468440306720937071L;
	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.CpUserSurveys";

	/**
	 * Gets the class Package.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CpUserSurveys_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CpUserSurveys_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CpUserSurveys_Cargo[] getResults() {
		final CpUserSurveys_Cargo[] cbArray = new CpUserSurveys_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CpUserSurveys_Cargo getCargo(final int idx) {
		return (CpUserSurveys_Cargo) get(idx);
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CpUserSurveys_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(Object obj) throws RemoteException {
		if (obj instanceof CpUserSurveys_Cargo[]) {
			final CpUserSurveys_Cargo[] cbArray = (CpUserSurveys_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
