package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class CP_CC_SCRNR_INDV_INFO_Collection  extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.CP_CC_SCRNR_INDV_INFO";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 *
	 * @param aNewCargo
	 */
	public void addCargo(final CP_CC_SCRNR_INDV_INFO_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 *
	 * @param cbArray
	 *
	 */
	public void setResults(final CP_CC_SCRNR_INDV_INFO_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 * 
	 * @param idx index
	 * @param aCargo cargo to be add
	 */
	public void setCargo(final int idx, final CP_CC_SCRNR_INDV_INFO_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 *
	 * @return CP_CC_SCRNR_INDV_INFO_Cargo[]
	 */
	public CP_CC_SCRNR_INDV_INFO_Cargo[] getResults() {
		final CP_CC_SCRNR_INDV_INFO_Cargo[] cbArray = new CP_CC_SCRNR_INDV_INFO_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 *
	 * @param idx
	 * @return CP_CC_SCRNR_INDV_INFO_Cargo
	 */
	public CP_CC_SCRNR_INDV_INFO_Cargo getCargo(final int idx) {
		return (CP_CC_SCRNR_INDV_INFO_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 *
	 * @return CP_CC_SCRNR_INDV_INFO_Cargo[]
	 */
	public CP_CC_SCRNR_INDV_INFO_Cargo[] cloneResults() {
		final CP_CC_SCRNR_INDV_INFO_Cargo[] rescargo = new CP_CC_SCRNR_INDV_INFO_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_CC_SCRNR_INDV_INFO_Cargo cargo = getCargo(i);
			rescargo[i] = new CP_CC_SCRNR_INDV_INFO_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setFst_nam(cargo.getFst_nam());
			rescargo[i].setLast_nam(cargo.getLast_nam());
			rescargo[i].setDob(cargo.getDob());
			rescargo[i].setCaretaker(cargo.getCaretaker());
			rescargo[i].setCourt_ordr_suprvsn(cargo.getCourt_ordr_suprvsn());
			rescargo[i].setMinor_parent(cargo.getMinor_parent());
			rescargo[i].setSpcl_needs(cargo.getSpcl_needs());
			rescargo[i].setSchl_attendance(cargo.getSchl_attendance());
			rescargo[i].setAvg_wkly_inc(cargo.getAvg_wkly_inc());
			rescargo[i].setAvg_wkly_hrs_wrk(cargo.getAvg_wkly_hrs_wrk());
			rescargo[i].setScrnr_seq(cargo.getScrnr_seq());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 *
	 * @param obj
	 *
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_CC_SCRNR_INDV_INFO_Cargo[]) {
			final CP_CC_SCRNR_INDV_INFO_Cargo[] cbArray = (CP_CC_SCRNR_INDV_INFO_Cargo[]) obj;
			setResults(cbArray);
		}
	}
	
	
}
