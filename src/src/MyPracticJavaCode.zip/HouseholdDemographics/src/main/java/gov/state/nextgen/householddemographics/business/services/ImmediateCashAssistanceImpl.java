package gov.state.nextgen.householddemographics.business.services;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sun.xml.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;

import gov.state.nextgen.access.business.entities.AbstractCollection;
import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IMMED_CASH_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IMMED_CASH_Collection;
import gov.state.nextgen.householddemographics.business.rules.ImmediateCashAssistanceBO;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.constants.HouseholdApplicationConstants;
import gov.state.nextgen.householddemographics.data.db2.CP_APP_IMMED_CASH_Repository;

@Service("ImmediateCashAssistanceService")
public class ImmediateCashAssistanceImpl implements HouseholdDemographicsService{
	
	@Autowired
	ImmediateCashAssistanceBO immedCashBO; 
	
	@Autowired
	CP_APP_IMMED_CASH_Repository immedCashRepo;
	
	@Autowired
    private ExceptionUtil exceptionUtil;
	
	private static final String CP_APP_IMMED_CASH_COLL = "CP_APP_IMMED_CASH_Collection";
	

	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {
		// TODO Auto-generated method stub
		
		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.STORE_IMMED_CASH_ASSIT:
			this.storeImmediateCashAssistance(txnBean);
			break;
		case HouseHoldDemoGraphicsConstants.LOAD_IMMED_CASH_ASSIT:
			this.loadImmediateCashAssistance(txnBean);
			break;
		default:
		}
		
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadImmediateCashAssistance(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ImmediateCashAssistanceImpl.loadImmediateCashAssistance() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appnum = userDetails.getAppNumber();
			Integer indv_seq_num = Integer.parseInt(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			
			CP_APP_IMMED_CASH_Collection immedCashColl = immedCashBO.loadImmediateCashAssistance(appnum,indv_seq_num);
			
				
				pageCollection.put(CP_APP_IMMED_CASH_COLL, immedCashColl);
			

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in loadImmediateCashAssistance()", txnBean);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadImmediateCashAssistance", txnBean.getUserDetails().getAppNumber(),
        			txnBean.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ImmediateCashAssistanceImpl.loadImmediateCashAssistance() - END", txnBean);
	}

	@SuppressWarnings({"squid:S2230","squid:S3776"})
	@Transactional
	private void storeImmediateCashAssistance(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ImmediateCashAssistanceImpl.storeImmediateCashAssistance() - START", txnBean);
			try {
				final Map pageCollection = txnBean.getPageCollection();
				final String appNum = txnBean.getUserDetails().getAppNumber();
				final CP_APP_IMMED_CASH_Collection ImmedCashColl = new CP_APP_IMMED_CASH_Collection();
				List<String> immedAry;
				CP_APP_IMMED_CASH_Collection appImmedCash1 = immedCashBO.getByAppNum(appNum);
				CP_APP_IMMED_CASH_Cargo appImmedCash = null;
				if(appImmedCash1.isEmpty())
				{
					appImmedCash = new CP_APP_IMMED_CASH_Cargo();
				}
				else {
					 appImmedCash = appImmedCash1.getCargo(0);
					 appImmedCash.setUtil_shut_off(null);
					 appImmedCash.setFood_run_out(null);
					 appImmedCash.setEssential_clothing(null);
					 appImmedCash.setTransport_help(null);
					 appImmedCash.setEviction_notice(null);
					 appImmedCash.setMedical_leave(null);
					 appImmedCash.setChild_abuse(null);
					 appImmedCash.setDomestic_abuse(null);
					 appImmedCash.setElser_abuse(null);
					 appImmedCash.setPreg(null);
					 appImmedCash.setOther_emergency(null);	 
				}
				
				if (pageCollection.get("ImmediateCashAssistanceListCheckBox") != null) {
					immedAry = (List<String>) pageCollection.get("ImmediateCashAssistanceListCheckBox");
					for(int i=0; i<immedAry.size(); i++)
					{
						if (immedAry.get(i).equals("US")) {
							appImmedCash.setUtil_shut_off("Y");
					    } 
						else if(immedAry.get(i).equals("NF"))
						{
							appImmedCash.setFood_run_out("Y");
						}
						else if(immedAry.get(i).equals("EC"))
						{
							appImmedCash.setEssential_clothing("Y");
						}
						else if(immedAry.get(i).equals("NR"))
						{
							appImmedCash.setTransport_help("Y");
						}
						else if(immedAry.get(i).equals("NP"))
						{
							appImmedCash.setEviction_notice("Y");
						}
						else if(immedAry.get(i).equals("MN"))
						{
							appImmedCash.setMedical_leave("Y");
						}
						else if(immedAry.get(i).equals("VC"))
						{
							appImmedCash.setChild_abuse("Y");
						}
						else if(immedAry.get(i).equals("VD"))
						{
							appImmedCash.setDomestic_abuse("Y");
						}
						else if(immedAry.get(i).equals("VE"))
						{
							appImmedCash.setElser_abuse("Y");
						}
						else if(immedAry.get(i).equals("PR"))
						{
							appImmedCash.setPreg("Y");
						}
						else if(immedAry.get(i).equals("OE"))
						{
							appImmedCash.setOther_emergency("Y");
						}
					}
				}
				
				if (pageCollection.get(CP_APP_IMMED_CASH_COLL) != null) {
					CP_APP_IMMED_CASH_Collection exp = (CP_APP_IMMED_CASH_Collection) pageCollection.get(CP_APP_IMMED_CASH_COLL);
					appImmedCash.setOther_emergency_explain(exp.getCargo(0).getOther_emergency_explain());
				}
				
				appImmedCash.setApp_num(appNum);
				appImmedCash.setIndv_seq_num(HouseholdApplicationConstants.ONE);
				ImmedCashColl.addCargo(appImmedCash);
				immedCashBO.storeImmediateCashAssistance(ImmedCashColl);


			} catch(Exception exception) {
				FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeImmediateCashAssistance()", txnBean);
	        	FwExceptionManager.handleException(exception,this.getClass().getName(),
	        			"storeImmediateCashAssistance", txnBean.getUserDetails().getAppNumber(),
	        			txnBean.getUserDetails().getLoginUserId(), true);
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ImmediateCashAssistanceImpl.storeImmediateCashAssistance() - END", txnBean);
		
	}

}
