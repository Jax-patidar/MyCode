package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

public class IndivTypeSeqBean implements Serializable {


    private static final long serialVersionUID = 1470515092363829283L;

    public IndivTypeSeqBean(final String aIndivSeqNum, final String aType, final String aSeqNum) {
        indivSeqNum = aIndivSeqNum;
        type = aType;
        seqNum = aSeqNum;
    }
    
    IndivTypeSeqBean() {
    	
    }

    private String indivSeqNum;
    private String type;
    private String seqNum;
    private String userEndInd;

    public String getIndivSeqNum() {
        return indivSeqNum;
    }

    public void setIndivSeqNum(String indivSeqNum) {
        this.indivSeqNum = indivSeqNum;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSeqNum() {
        return seqNum;
    }

    public void setSeqNum(String seqNum) {
        this.seqNum = seqNum;
    }

    public String getUserEndInd() {
        return userEndInd;
    }

    public void setUserEndInd(String userEndInd) {
        this.userEndInd = userEndInd;
    }
}
