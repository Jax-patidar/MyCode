package gov.state.nextgen.householddemographics.business.rules;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaUpdate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.driver.FwPageManager;
import gov.state.nextgen.access.driver.IPage;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.references.IReferenceTableData;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppRgstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppRqstRepository;

@Service("ABProgramInformationBO")
public class ABProgramInformationBO extends AbstractBO {
	@PersistenceContext
	EntityManager entityManager ;
	private FwMessageList messageList = new FwMessageList();
	@Autowired
	private CpAppRqstRepository cpAppRqstRepository;
	@Autowired
	private CpAppRgstRepository cpAppRgstRepository;
	@Autowired
	private CpAppPgmRqstRepository cpAppPgmRqstRepository;
	@Autowired 
	private CpAppPgmIndvRepository cpAppPgmIndvRepository;
	/**
	 * Constructor
	 */
	public ABProgramInformationBO() {
	}
	/**
	 * Load Program information
	 *
	 * @param appNumber
	 * @return APP_RQST_Collection
	 */
	public APP_RQST_Collection loadProgramInformation(final String appNumber) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABProgramInformationBO.loadProgramInformation() - START");

		try {
			APP_RQST_Cargo resultCargo = new APP_RQST_Cargo();
			APP_RQST_Collection helpColl ;

			helpColl = cpAppRqstRepository.getByAppNum(Integer.parseInt(appNumber));

			if ((helpColl != null) && !helpColl.isEmpty()) {
				resultCargo = helpColl.getCargo(0);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABProgramInformationBO.loadProgramInformation()() - END, Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds"); 
			return helpColl;
		} catch (final FwException fe) {
			throw fe;
		 
			
		} catch (final Exception e) {
			throw e;
		}
	}
	/**
	 * Gets error messages
	 * @return List of error messages.
	 * Creation Date Apr 1, 2004
	 */
	public FwMessageList getMessageList() {

		return messageList;
	}
	/**
	 * Store Program Information
	 *
	 * @param appRqstColl
	 */
	public void storeProgramInformation(final APP_RQST_Collection appRqstColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABProgramInformationBO.storeProgramInformation() - START, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		try {
			if(appRqstColl != null && !appRqstColl.isEmpty() && appRqstColl.size()>0) {
				APP_RQST_Cargo cargo = new APP_RQST_Cargo();
					cargo = appRqstColl.getCargo(0);
					//Set update date
					if(cargo != null) {
					 Timestamp currentTimeStamp = new Timestamp(new Date().getTime());
					 cargo.setUpdt_dt(currentTimeStamp);
					}
					cpAppRqstRepository.save(cargo);
			}
		} catch (final FwException fe) {
			throw fe;
		 
			
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABProgramInformationBO.storeProgramInformation() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");

	}
	
	/**
	 * This method adds the requested Program to the Database. All the Programs
	 * of Assistance that can be requested are. FMA_RQST FS_RQST FPW_RQST
	 *
	 * @param appNumber
	 * @param programId
	 * @param programKeyArray.
	 */

	public void addProgram(final String appNumber, final short programId, final Integer[] programKeyArray) {
		try {
			programKeyArray[programId] = 1;
			final short[] prgKeyAry = { programId };
			updateAppPgmRqstTable(appNumber, prgKeyAry, true);
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

	}
	
	/**
	 * This method removes the requested Program from the Database. All the
	 * Programs of Assistance that can be requested are. FMA_RQST FS_RQST
	 * FPW_RQST
	 *
	 * @param appNumber
	 * @param programId
	 * @param programKeyArray
	 */

	public void removeProgram(final String appNumber, final short programId, final Integer[] programKeyArray) {

		try {
			programKeyArray[programId] = 0;
			final short[] prgKeyAry = { programId };
			updateAppPgmRqstTable(appNumber, prgKeyAry, false);
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	
	/**
	 * This method updates based on a appNumber all the programs of assistance
	 * to the Database . This is done only once for a Case number. The Programs
	 * of Assistance that are updated. FMA_RQST FS_RQST FPW_RQST
	 *
	 * @param appNumber
	 * @param programIds
	 * @param addProgramFlag
	 */
	private void updateAppPgmRqstTable(final String appNumber, final short[] programIds, final boolean addProgramFlag) {
		try {

			final String[] values = new String[programIds.length];
			for (int i = 0; i < programIds.length; i++) {
				if (addProgramFlag) {
					values[i] = "1";
				} else {
					values[i] = "0";
				}
			}
			
			String columnname = null;
			if(programIds[0]==0) {
				 columnname="fma_rqst_ind";
			}else if(programIds[0]==2) {
				 columnname="fs_rqst_ind";
			}else if(programIds[0]==9) {
				 columnname="tanf_rqst_ind";
			}else if(programIds[0]==18) {
				 columnname="ggr_ind";
			}
			CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
			CriteriaUpdate<APP_PGM_RQST_Cargo> criteriaUpdate = criteriaBuilder.createCriteriaUpdate(APP_PGM_RQST_Cargo.class);
			 Root<APP_PGM_RQST_Cargo> appPgmRqstRoot = criteriaUpdate.from(APP_PGM_RQST_Cargo.class);
			 criteriaUpdate.set(columnname,values[0])
		                    .where(criteriaBuilder.equal(appPgmRqstRoot.get("app_number"), appNumber));
			
		}catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
		
	}
	public FwMessageList validateProgramSelection(
			final APP_PGM_RQST_Cargo appPrgRqstCargo, final boolean addPgmFlag,
			final APP_RQST_Cargo appRqstCargo,
			final APP_RGST_Cargo appRgstCargo, final String lang,
			final Boolean isHideFma, Map pgmMap, Map pgmDplyMap, boolean showWarn) {

		final long startTime = System.currentTimeMillis();

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABProgramInformationBO.validateProgramSelection() - START");

		try {
			// VACMS start - converting FS to CC
			// IF USER DID'T SELECT Child Care PROGRAM

			// EDSP Start - Validating New Programs
			
			FwMessageList messageList = new FwMessageList();

			int i = 0;

			final List warning = new ArrayList();
			final IPage ipage = FwPageManager.createInstance();
			if (appPrgRqstCargo.getCc_rqst_ind().equals(
					HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED)) {

				warning.add(ipage.getDisplayText(500000228, lang));
				i++;

			}
			if ((appPrgRqstCargo.getFma_rqst_ind()).equals(HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED)) {

				warning.add(ipage.getDisplayText(500000175, lang));
				i++;
			}
			if ((appPrgRqstCargo.getFs_rqst_ind()).equals(HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED)) {

				warning.add(ipage.getDisplayText(500000452, lang));
				i++;

			}
			if ((appPrgRqstCargo.getGgr_ind()).equals(HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED)) {

				warning.add(ipage.getDisplayText(500000360, lang));
				i++;

			}
			if ((appPrgRqstCargo.getTanf_rqst_ind()).equals(HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED)) {

				warning.add(ipage.getDisplayText(500000360, lang));
				i++;

			}

			if (appPrgRqstCargo.getWic_rqst_ind().equals(HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED)) {

				warning.add(ipage.getDisplayText(500000453, lang));				
				i++;

			}
			
			
			if (appPrgRqstCargo.getDcalfresh_request_ind()!=null && HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED.equals(appPrgRqstCargo.getDcalfresh_request_ind())) {

				i++;

			}

			Object warnMsg = null;

			for (int j = 0; j < warning.size(); j++) {

				if (j == 0) {
					warnMsg = warning.get(j);
				} else if (j == warning.size() - 1) {

					warnMsg = warnMsg!=null?warnMsg:"" + ", and " + warning.get(j);
				} else {

					warnMsg = warnMsg!=null?warnMsg:"" + ", " + warning.get(j);
				}
			}

			if (i == 0) {
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_10235));
			}
			
			int pgmAvailable = 0;
			java.util.Iterator it =  pgmDplyMap.keySet().iterator();
			while(it.hasNext()){
				if((boolean) pgmDplyMap.get(it.next())){
					pgmAvailable+=1;
				}
			}
			final Object[] warn = new Object[] { warnMsg };
			/*
			 * VY commenting out program validation 
			 * if(i!=0 && i<pgmAvailable && showWarn){
			 * this.addMessageWithFieldValues("00023", warn); }
			 */

			
			
			if( pgmMap!= null && isPgmOnCase(appPrgRqstCargo,pgmMap)){
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_00061));
			}
			if((appPrgRqstCargo.getWic_rqst_ind()).equals(HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED)
			        && !appMgr.isAlpha(appRgstCargo.getWic_dsclsr())){
			    
				messageList.addMessageToList(addMessageCode(HouseHoldDemoGraphicsConstants.MSG_90947));;
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABProgramInformationBO.validateProgramSelection() - END");

			return messageList;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	private boolean isPgmOnCase(APP_PGM_RQST_Cargo appPrgRqstCargo, Map pgmMap) {
	    boolean pgmOnCase = false;
	    
        if (appPrgRqstCargo.getCc_rqst_ind().equals(
                HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED) && pgmMap.containsValue("CD")) {
            return true;
        }
        if (appPrgRqstCargo.getFma_rqst_ind().equals(
        		HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED) && pgmMap.containsValue("MC")) {
            return true;
        }
        if (appPrgRqstCargo.getFs_rqst_ind().equals(
        		HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED) && pgmMap.containsValue("SN")) {
            return true;
        }
        if (appPrgRqstCargo.getTanf_rqst_ind().equals(
        		HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED) && pgmMap.containsValue("TA")) {
            return true;
        }
        if (appPrgRqstCargo.getWic_rqst_ind().equals(
        		HouseHoldDemoGraphicsConstants.PROGRAM_SELECTED) && pgmMap.containsValue("WC")) {
            return true;
        }
	    
        return pgmOnCase;
    }
	
	public APP_RQST_Collection loadAllDetails(String appNum) {
		final long startTime = System.currentTimeMillis();

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABProgramInformationBO.loadAllDetails() - START");
		try {
			APP_RQST_Collection appRequestColl = new APP_RQST_Collection();
			if(appNum != null) {
				appRequestColl = cpAppRqstRepository.getAllDetails(Integer.parseInt(appNum));
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABProgramInformationBO.loadAllDetails() - END");
			return appRequestColl;

		}catch (final Exception e) {
			throw e;
		}
	}
	public APP_PGM_RQST_Collection loadDetails(String appNum) {
		final long startTime = System.currentTimeMillis();

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABProgramInformationBO.loadDetails() - START");
		try {
			APP_PGM_RQST_Collection appPgmRequestColl = new APP_PGM_RQST_Collection();
			if(appNum != null) {
				appPgmRequestColl = cpAppPgmRqstRepository.getDetails(Integer.parseInt(appNum));
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABProgramInformationBO.loadAllDetails() - END");
			return appPgmRequestColl;

		}catch (final Exception e) {
			throw e;
		}
	}
	
	/*
	 * Used to persist data in the DB
	 */
	public void storeDBData(APP_RGST_Collection appRgstStoreColl)  {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABProgramInformationBO.storeDBData() - START, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");
		try {
			if(appRgstStoreColl != null && !appRgstStoreColl.isEmpty() && appRgstStoreColl.size()>0) {
				APP_RGST_Cargo cargo = new APP_RGST_Cargo();
				
					cargo = appRgstStoreColl.getCargo(0);
					cpAppRgstRepository.save(cargo);
				
			}
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABProgramInformationBO.storeDBData() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds");

	}
	public Map getPgmDplyMap(IReferenceTableManager iref) {
		Map pgmDplyMap = new HashMap<>();
		IReferenceTableData refData = iref.getReferenceTableData("OLPG", "EN");
		boolean onlineAppl = false; 
		int size = refData.getNumberOfRows();
		String[] cds = refData.getCodeValues();

		// restrict programs
		for(int i = 0; i<size; i++){

			if("R".equalsIgnoreCase(refData.getDesc(i, 9830)))
				pgmDplyMap.put(cds[i], false);
			else
				pgmDplyMap.put(cds[i], true);
		}
		return pgmDplyMap;
	}
	

	//ADDED AS PART OF CSPM-2161 to fetch data from DB
	public APP_PGM_RQST_Collection loadProgramRqstColl(String appNumber) {
		return cpAppPgmRqstRepository.loadProgramRqstColl(Integer.parseInt(appNumber));
		
	}
	//ADDED AS PART OF CSPM-2161 to fetch data from DB
	public void saveAdditionalCountyDetails(APP_PGM_RQST_Collection updatedCollection) {
		try {
			APP_PGM_RQST_Cargo cargo = null;
			if (updatedCollection != null && !updatedCollection.isEmpty()) {
				cargo = updatedCollection.getCargo(0);
				cpAppPgmRqstRepository.save(cargo);
			}
		}catch (final FwException fe) {
           throw fe;
        } catch (final Exception exception) {
            throw exception;
        }	
		
	}
	public APP_RGST_Collection loadCpAppRgstDetails(String appNumber,Integer indv_seq_num) {
		return cpAppRgstRepository.loadCpAppRgstDetails(Integer.parseInt(appNumber),indv_seq_num);
	}
	
	/*
	 * Created as part of CSPM 2161- To compare the County with the list of Counties providing CMSP
	 */
	public Integer compareCountyProvidingMedical(String countyNum) {
	 try {	
		Integer flag = 0;
		List<String> list=new ArrayList<String>();
		list.add("AXA");
		list.add("MAA");
		list.add("SFS");
		list.add("CAL");
		if(list.contains(countyNum)) {
			flag=1;
			return flag;
		}
		
		return flag;
	 }catch(Exception e) {
		 throw e;
	 }
	}

	public void storeStopBenefitsProgramInfo(APP_PGM_RQST_Collection coll) {
		try {
			APP_PGM_RQST_Cargo cargo = new APP_PGM_RQST_Cargo();
			if (coll != null && !coll.isEmpty()) {
				cargo = coll.getCargo(0);
				cpAppPgmRqstRepository.save(cargo);
			}
		} catch (final Exception exception) {
            throw exception;
        }	
		
	}
	public void storeStopBenefitsProgramIndvInfo(CP_APP_PGM_INDV_Cargo indvcargo) {
		try {
				cpAppPgmIndvRepository.save(indvcargo);
		}catch (final FwException fe) {
	           throw fe;
	        } catch (final Exception exception) {
	            throw exception;
	        }	
			
		
	}
	
	public CP_APP_PGM_INDV_Collection loadIndvProgrammeSelection(String appNumber) {
		return cpAppPgmIndvRepository.getDetails(Integer.parseInt(appNumber));
	}

}
