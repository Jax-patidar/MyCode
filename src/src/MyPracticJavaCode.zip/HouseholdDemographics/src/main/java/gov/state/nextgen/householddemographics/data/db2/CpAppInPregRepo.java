package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import gov.state.nextgen.householddemographics.business.entities.APP_IN_BreastFeeding_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PREG_Key;


@Repository
public interface CpAppInPregRepo extends CrudRepository<APP_IN_PREG_Cargo, APP_IN_PREG_Key>{

	
	@Query(value="select * from ie_ssp_owner_nfin.cp_app_in_preg where app_number = ?1",nativeQuery=true)
	public APP_IN_PREG_Cargo[] loadPregnancy(Integer appNum);
	
	@Query(value ="select c from APP_IN_PREG_Cargo c where c.app_number = ?1 and c.indv_seq_num = ?2")
	public APP_IN_PREG_Cargo[] loadPregnancyDetails(Integer appNum, String indvSeqNum);

	
	@Query(value="select * from ie_ssp_owner_nfin.cp_app_in_preg where app_number = ?1",nativeQuery=true)
	public APP_IN_BreastFeeding_Cargo[] loadBreastFeedingDetails(Integer appNum);

}

