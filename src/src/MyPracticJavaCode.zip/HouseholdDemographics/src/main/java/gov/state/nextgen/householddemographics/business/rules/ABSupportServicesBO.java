package gov.state.nextgen.householddemographics.business.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_SUPPORT_SERVICES_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_SUPPORT_SERVICES_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppSupportServicesRepo;

//Added as part of CSPM-1881

@Service("ABSupportServicesBO")
public class ABSupportServicesBO extends AbstractBO {

	@Autowired
	private CpAppSupportServicesRepo cpAppSupportServicesRepo;

	public void saveSupportServicesDetails(CP_APP_SUPPORT_SERVICES_Collection supportServicesColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSupportServicesBO.saveSupportServicesDetails() - START");
		try {
			CP_APP_SUPPORT_SERVICES_Cargo cargo = null;
			if (supportServicesColl != null && !supportServicesColl.isEmpty()) {
				cargo = supportServicesColl.getCargo(0);
				cpAppSupportServicesRepo.save(cargo);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABSupportServicesBO.saveSupportServicesDetails() - END , Time Taken :"
						+ (System.currentTimeMillis() - startTime) + " milliseconds");

	}

	public CP_APP_SUPPORT_SERVICES_Collection fetchSupportServicesDetails(String appnum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABSupportServicesBO.fetchSupportServicesDetails() - START");
		try {
			CP_APP_SUPPORT_SERVICES_Collection supportServiceColl = new CP_APP_SUPPORT_SERVICES_Collection();
			if (appnum != null) {
				CP_APP_SUPPORT_SERVICES_Cargo[] supportServiceCargo = cpAppSupportServicesRepo.getByAppNum(Integer.parseInt(appnum));
				if (supportServiceCargo.length > 0) {
					supportServiceColl.setResults(supportServiceCargo);
				}
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABSupportServicesBO.fetchSupportServicesDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + " milliseconds");

			return supportServiceColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}
}
