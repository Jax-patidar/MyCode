package gov.state.nextgen.householddemographics.business.rules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;

/**
 * Business Object for Foster Care in HouseHoldDemographicsService.
 * @author arunkuj
 */

@Component("FosterCareBO")
public class FosterCareBO {
	
	@Autowired
	private CpAppIndvRepository cpAppIndvRepository;
	
	private static Logger logger = LoggerFactory.getLogger(FosterCareBO.class);
	
	public APP_INDV_Collection getAllAPPIndividuals(String appNum, List<Integer> indvIds) {
		logger.info("FosterCareBO.getAllAPPIndividuals() - START");
		try {
		APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
        List<APP_INDV_Cargo> cpAppIndvCargos;
        APP_INDV_Cargo[] appIndvCargoArray =  cpAppIndvRepository.loadIndvDataByIndvIds(Integer.parseInt(appNum), indvIds);
        cpAppIndvCargos = Arrays.asList(appIndvCargoArray);
        if(!(cpAppIndvCargos.isEmpty()) && cpAppIndvCargos.size()>0 ) {
        		for(APP_INDV_Cargo cargo : cpAppIndvCargos) {
            	if(Objects.nonNull(cargo) && StringUtils.isNotEmpty(cargo.getIs_foster_care())) {
            		
            			appIndvCollection.addCargo(cargo);
            		
            	}
            }
        }
        logger.info("FosterCareBO.getAllAPPIndividuals() - END");
		return appIndvCollection;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception exception) {
			throw exception;
		}
	}
	
	public APP_INDV_Collection getAppIndvByAppNumIndvSeqNum(String appNum, Integer indvSeqNum) {
		try {
		logger.info("FosterCareBO.getAppIndvByAppNumIndvSeqNum() - START");
		APP_INDV_Collection appIndvCollection =  cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNum), indvSeqNum);
        logger.info("FosterCareBO.getAppIndvByAppNumIndvSeqNum() - END");
		return appIndvCollection;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception exception) {
			throw exception;
		}
	}

	public void saveFosterCareDetails(APP_INDV_Cargo appIndvCargo) {
		try {
		logger.info("FosterCareBO.saveFixMealsPersonSelection() - START");
		cpAppIndvRepository.save(appIndvCargo);
		logger.info("FosterCareBO.saveFixMealsPersonSelection() - END");
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception exception) {
			throw exception;
		}
	}
	
	public void deleteFosterCareDetails(String appNum, Integer indvSeqNum) {
        try {
              logger.info("FosterCareBO.deleteFosterCareDetails() - START");
              APP_INDV_Collection appIndvColl = getAppIndvByAppNumIndvSeqNum( appNum, indvSeqNum);
              if(Objects.nonNull(appIndvColl) && !(appIndvColl.isEmpty())
                                       && appIndvColl.size()>0) {
                    APP_INDV_Cargo appIndvCargo = appIndvColl.getCargo(0);
                    if(!appIndvCargo.getIs_foster_care().isEmpty())
                    {
                    deleteFosterCareFields(appIndvCargo);
                    saveFosterCareDetails(appIndvCargo); 
                    }
              }
        } catch (final FwException fe) {
              throw fe;
        } catch (final Exception exception) {
              throw exception;
        }
        logger.info("FosterCareBO.deleteFosterCareDetails() - END");
	  }
	
	  private void deleteFosterCareFields(APP_INDV_Cargo appIndvCargo) {
	        appIndvCargo.setFormer_foster_from_dt(null);
	        appIndvCargo.setFormer_foster_to_dt(null);
	        appIndvCargo.setFormer_foster_state("");
	        appIndvCargo.setIn_foster_eighteenth_brth_ind("");
	        appIndvCargo.setIs_foster_care(null);
	  }

}
