package gov.state.nextgen.householddemographics.business.services;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.amazonaws.util.CollectionUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CaseIndividualDetails;
import gov.state.nextgen.householddemographics.business.entities.CaseIndividualDetailsAddress;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4MoveoutSsiSsp_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4Redet_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpAppTnb4Redet_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.RedetCWFormSpecificCargo;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CP_APP_RGST_Repository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInTaxReturnRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppPgmRqstRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppTnb4RedetRepository;
import gov.state.nextgen.householddemographics.data.db2.CpRmbLtcDtlsRepository;
import gov.state.nextgen.householddemographics.data.db2.CpRmbRequestDetailsRepository;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;
import gov.state.nextgen.householddemographics.data.db2.RMBRqstRepository;
import gov.state.nextgen.householddemographics.model.CaseIndividualDetailsTaxReview;
import gov.state.nextgen.householddemographics.model.CaseIndividualDetailsTaxStatus;
import gov.state.nextgen.householddemographics.model.LtcNewPersonDetailAddress;
import gov.state.nextgen.householddemographics.model.RequestObjRelationship;
import gov.state.nextgen.householddemographics.utilities.DateUtility;

/**
 * Redetermination flow service
 * 
 * @author ransahu
 *
 */
@Service("RedeterminationService")
public class RedeterminationServiceImpl implements HouseholdDemographicsService {

	@Autowired
	CpAppTnb4RedetRepository cpAppTnb4RedetRepository;

	@Autowired
	ARTransactionManagedServImpl arTransactionManagedServImpl;

	@Autowired
	CpAppIndvRepository cpAppIndvRepository;

	@Autowired
	CpAppPgmIndvRepository cpAppPgmIndvRepository;

	@Autowired
	CP_APP_RGST_Repository cpAppRgstRepository;

	@Autowired
	CpAppPgmRqstRepository cpAppPgmRqstRepository;

	@Autowired
	RMBRqstRepository rmbRqstRepository;

	@Autowired
	CpRmbLtcDtlsRepository cpRmbLtcDtlsRepository;

	@Autowired
	CpRmbRequestDetailsRepository cpRmbRequestDetailsRepository;

	@Autowired
	CpAppInTaxReturnRepository cpAppInTaxReturnRepository;
	
	@Autowired
	private RMBRequestServiceBO rmbRequestServiceBO;
	
	/*
	 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
	 */
	@Autowired
	HouseholdRelationshipRepo householdRelationshipRepo;
	
	private static final String INDV_ID = "indvIds";
	private String ext;
	private String phnNum;

	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTransaction) {
		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.LOAD_TNB4_SPECIFIC_DATES_AND_CASENUM:
			loadTNB4SpecificDatesAndCaseNum(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.GENERATE_APPLICATION_DATA_FOR_TNB4:
			generateApplicationDataForTNB4(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.SAVE_TNB4_RENEWAL_FORM_DATA:
			saveTNB4RenewalFormData(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.LOAD_REDET_CALWORKS_DATA:
			loadRedetCalWorksSpecificData(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.LOAD_MC_SPECIFIC_DATES_AND_CASENUM:
			loadMCSpecificDatesAndCaseNum(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.GENERATE_APPLICATION_DATA_FOR_MC:
			generateApplicationDataForMC(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.GENERATE_FORM_STATUS_REQ:
			generateFormStatusReq(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.LOAD_LTC_DETAILS_REQ:
			loadLtcDetails(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.SAVE_LTC_DETAILS_REQ:
			saveLTCDetails(fwTransaction);
			break;
		case HouseHoldDemoGraphicsConstants.REMOVE_LTC_DETAILS_REQ:
			removeLTCDetails(fwTransaction);
			break;
		default:
			break;
		}

	}

	private void removeLTCDetails(FwTransaction fwTransaction) {
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.removeLTCDetails() - START", fwTransaction);

		Map<String, Object> pageCollection = null;
		Integer indvSeqNum = null;
		Integer seqNum = null;

		try {
			pageCollection = fwTransaction.getPageCollection();
			String appNum = fwTransaction.getUserDetails().getAppNumber();
			
			if (Objects.nonNull(fwTransaction.getCurrentActionDetails())
					&& Objects.nonNull(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.getIndividualSequence());
			}
			if (Objects.nonNull(fwTransaction.getCurrentActionDetails())
					&& Objects.nonNull(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}
				CpRmbLtcDtls_Collection existingLtcColl = cpRmbLtcDtlsRepository.getLtcDetails(Integer.parseInt(appNum),
						indvSeqNum, seqNum);
				
				if (Objects.nonNull(existingLtcColl) && !existingLtcColl.isEmpty()) {
					CpRmbLtcDtls_Cargo existingCargo = existingLtcColl.getCargo(0);
					if (Objects.nonNull(existingCargo)) {
						existingCargo.setEndDate(new Date());
						cpRmbLtcDtlsRepository.save(existingCargo);
						cpAppIndvRepository.clearIndvDataLtcInd(Integer.parseInt(appNum),indvSeqNum);
						APP_INDV_Collection indvColl = cpAppIndvRepository.getCollByAppNumIndvSeq(Integer.parseInt(appNum),indvSeqNum);
						pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, indvColl);
					}
				}
			
			

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in RedeterminationServiceImpl.removeLTCDetails()", fwTransaction);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					HouseHoldDemoGraphicsConstants.REMOVE_LTC_DETAILS_REQ, fwTransaction.getUserDetails().getAppNumber(),
					fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "RedeterminationServiceImpl.removeLTCDetails() - END", fwTransaction);
	
		
	}

	@Transactional
	private void saveLTCDetails(FwTransaction fwTransaction) {
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.saveLtcDetails() - START", fwTransaction);
		
		Map<String, Object> pageCollection = null;
		CpRmbLtcDtls_Collection cpRmbLtcDtlsCollection = null;
		CpRmbLtcDtls_Collection cpRmbLtcDtlsDBColl = null;
		CpRmbLtcDtls_Cargo cpRmbLtcDtlsCargo = null;
		Integer seqNum = null;
		Integer indvSeqNum = null;
		String appNumber = HouseHoldDemoGraphicsConstants.EMPTY;
		
		try {
			pageCollection = fwTransaction.getPageCollection();
			appNumber = fwTransaction.getUserDetails().getAppNumber();
			
			if(Objects.nonNull(fwTransaction.getCurrentActionDetails()) && Objects.nonNull(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			if(Objects.nonNull(fwTransaction.getCurrentActionDetails()) && Objects.nonNull(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence())) {
				seqNum = Integer.parseInt(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}
			
			
			if (pageCollection.get(HouseHoldDemoGraphicsConstants.CP_RMBLTCDTLSCOLL) != null) {
				cpRmbLtcDtlsCollection = (CpRmbLtcDtls_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.CP_RMBLTCDTLSCOLL);		
				cpRmbLtcDtlsCargo = cpRmbLtcDtlsCollection.getCargo(0);
				cpRmbLtcDtlsDBColl = cpRmbLtcDtlsRepository.getLtcDetails(Integer.parseInt(appNumber),indvSeqNum,seqNum);
				if(cpRmbLtcDtlsDBColl != null && !cpRmbLtcDtlsDBColl.isEmpty()) {
					cpRmbLtcDtlsCargo.setChangeDate(new Date());
				}
				cpRmbLtcDtlsCargo.setAppNum(appNumber);
				cpRmbLtcDtlsCargo.setIndvSeqNum(indvSeqNum);
				cpRmbLtcDtlsCargo.setSeqNum(seqNum);
				cpRmbLtcDtlsRepository.save(cpRmbLtcDtlsCargo);
				cpAppIndvRepository.updateIndvDataLtcInd(Integer.parseInt(appNumber),indvSeqNum);
			}  			
		}catch (final Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in RedeterminationServiceImpl.saveLtcDetails()", fwTransaction);
			FwExceptionManager.handleException(exception,this.getClass().getName(),
					HouseHoldDemoGraphicsConstants.SAVE_LTC_DETAILS_REQ, fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}finally {
			fwTransaction.setPageCollection(pageCollection);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.saveLtcDetails() - END", fwTransaction);
		
	}

	private void loadLtcDetails(FwTransaction fwTransaction) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.loadLtcDetails() - START");
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadLtcDetails() - ***loadLtcDetails START***");
		CpRmbLtcDtls_Collection cpRmbLtcDtlsCollection = null;
		String appNum = HouseHoldDemoGraphicsConstants.EMPTY;
		try {
			Map<Object, Object> pageCollection = fwTransaction.getPageCollection();
			appNum = fwTransaction.getUserDetails().getAppNumber();

			List<Integer> indvIdList = new ArrayList<>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			
			if (null != appNum) {
				cpRmbLtcDtlsCollection = cpRmbLtcDtlsRepository.getLtcDtlsByAppNumActive(Integer.parseInt(appNum), indvIdList);
			}

			pageCollection.put(HouseHoldDemoGraphicsConstants.CpRmbLtcDtlsCollection, cpRmbLtcDtlsCollection);
			fwTransaction.setPageCollection(pageCollection);

		} catch(Exception exception) {
			 
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadLtcDetails", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadLtcDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);

	}

	/**
	 * Method to generate application data for TNB4 Redetermination flow
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	private void loadTNB4SpecificDatesAndCaseNum(FwTransaction fwTransaction) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadTNB4SpecificDatesAndCaseNum() - START");

		try {
			getRMBFormDataAndClob(fwTransaction);
			massageTNB4specificData(fwTransaction);

		}  catch(Exception exception) {
			 
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadTNB4SpecificDatesAndCaseNum", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadTNB4SpecificDatesAndCaseNum() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);
	}

	/**
	 * Method to generate and form application data for CalWorks Redetermination
	 * flow
	 * 
	 * @param fwTransaction
	 * @return void
	 */
	private void loadRedetCalWorksSpecificData(FwTransaction fwTransaction) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadRedetCalWorksSpecificData() - START");

		try {
			getRMBFormDataAndClob(fwTransaction);
			formRedetCalWorksSpecificData(fwTransaction);

		} catch(Exception exception) {
			 
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadRedetCalWorksSpecificData", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadRedetCalWorksSpecificData() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);
	}

	/**
	 * Method to form application data for CalWorks Redetermination flow
	 * 
	 * @param fwTransaction
	 * @return void
	 */
	private void formRedetCalWorksSpecificData(FwTransaction fwTransaction) {
		Map pageCollection = fwTransaction.getPageCollection();

		RMB_RQST_Collection existingRmbRqstCollection = Objects
				.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION))
						? (RMB_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION)
						: null;
		if (null != existingRmbRqstCollection && !existingRmbRqstCollection.isEmpty()) {
			RMB_RQST_Cargo rmbRqstCargo = existingRmbRqstCollection.getCargo(0);
			RedetCWFormSpecificCargo redetCWFormSpecificCargo = new RedetCWFormSpecificCargo();
			redetCWFormSpecificCargo.setCase_num(rmbRqstCargo.getCase_num());
			redetCWFormSpecificCargo.setForm_due_date(rmbRqstCargo.getForm_due_dt());
			redetCWFormSpecificCargo.setForm_rpt_type(rmbRqstCargo.getForm_rpt_type());
			pageCollection.put(HouseHoldDemoGraphicsConstants.REDET_CW_DATA, redetCWFormSpecificCargo);
		}

		fwTransaction.setPageCollection(pageCollection);
	}

	/**
	 * Method to generate application data for TNB4 Redetermination flow
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	private void generateApplicationDataForTNB4(FwTransaction fwTransaction) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateApplicationDataForTNB4() - START");
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateApplicationDataForTNB4() - ***generateApplicationDataForTNB4 START***");

		try {
			getRMBFormDataAndClob(fwTransaction);

			generateRMBApplicationData(fwTransaction);

			massageTNB4specificData(fwTransaction);

		} catch(Exception exception) {
			 
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"generateApplicationDataForTNB4", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateApplicationDataForTNB4() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);

	}

	/**
	 * Method to get data from cp_rmb_request and cp_rmb_request_detail tables
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 * @throws Exception 
	 */
	private void getRMBFormDataAndClob(FwTransaction fwTransaction) throws Exception {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.getRMBFormDataAndClob() - ***getRMBFormDataAndClob START***");

		try {
			final Map pageCollection = fwTransaction.getPageCollection();
			Long cpRmbRequestId;

			// Set program details from clob object to page collection only for periodic
			// reporting
			String mode = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.MODE);
			if (Objects.nonNull(mode) && (mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING)
					|| mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.CALFRESH_F37)
					|| mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.MC_MODE))) {
				String cpRmbRequestIdStr = (String) pageCollection
						.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_ID);
				if (Objects.nonNull(cpRmbRequestIdStr)) {
					populatePageCollection(pageCollection, Long.valueOf(cpRmbRequestIdStr));
					CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = (CpRmbRequestDetails_Collection) pageCollection
							.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION);
					//check we got the right case num or not start
					FwLogger.log(this.getClass(), Level.INFO,
							"Before entering into DataExchange_Lambda_Function ::::");
					boolean isCaseNumAndCountyCdCorrect = true;
					isCaseNumAndCountyCdCorrect = rmbRequestServiceBO.checkCaseNumAndCountyCdAssociatedCorrect(fwTransaction, pageCollection);
					if (!isCaseNumAndCountyCdCorrect) {
						FwLogger.log(this.getClass(), Level.INFO,
								"inside the if block of isCaseNumAndCountyCdCorrect about to throw authorized exception");
						//rmbRequestServiceBO.throwAuthorizedException(fwTransaction);
						throw new Exception("UnAuthorized");
					}
					FwLogger.log(this.getClass(), Level.INFO,
							"After entering into DataExchange_Lambda_Function ::::");
					//check we got the right case num or not end
					if (mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.CALFRESH_F37) 
							|| mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING)) {
						fetchProgramDetailsFromProgList(cpRmbRequestDetailsCollection, pageCollection);
					} else {
						fetchProgramDetails(cpRmbRequestDetailsCollection, pageCollection);
					}
				}
			} else {
				RMB_RQST_Collection rmbRqstCollection = (RMB_RQST_Collection) pageCollection
						.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION);

				if (Objects.nonNull(rmbRqstCollection) && !rmbRqstCollection.isEmpty()) {
					RMB_RQST_Cargo rmbRqstCargo = rmbRqstCollection.getCargo(0);
					cpRmbRequestId = rmbRqstCargo.getCp_rmb_request_id();
					populatePageCollection(pageCollection, cpRmbRequestId);
				}
			}

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.getRMBFormDataAndClob() - ***getRMBFormDataAndClob error***");
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.getRMBFormDataAndClob() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);

	}
	
	/**
	 * Method to get data from cp_rmb_request and cp_rmb_request_detail tables
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 * @throws Exception 
	 */
	private void getRMBFormDataAndClobForFinAndNonFin(FwTransaction fwTransaction) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.getRMBFormDataAndClob() - ***getRMBFormDataAndClob START***");

		try {
			final Map pageCollection = fwTransaction.getPageCollection();
			Long cpRmbRequestId;

			// Set program details from clob object to page collection only for periodic
			// reporting
			String mode = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.MODE);
			if (Objects.nonNull(mode) && (mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING)
					|| mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.CALFRESH_F37)
					|| mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.MC_MODE))) {
				String cpRmbRequestIdStr = (String) pageCollection
						.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_ID);
				if (Objects.nonNull(cpRmbRequestIdStr)) {
					populatePageCollection(pageCollection, Long.valueOf(cpRmbRequestIdStr));
					CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = (CpRmbRequestDetails_Collection) pageCollection
							.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION);
					if (mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.CALFRESH_F37) 
							|| mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING)) {
						fetchProgramDetailsFromProgList(cpRmbRequestDetailsCollection, pageCollection);
					} else {
						fetchProgramDetails(cpRmbRequestDetailsCollection, pageCollection);
					}
				}
			} else {
				RMB_RQST_Collection rmbRqstCollection = (RMB_RQST_Collection) pageCollection
						.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION);

				if (Objects.nonNull(rmbRqstCollection) && !rmbRqstCollection.isEmpty()) {
					RMB_RQST_Cargo rmbRqstCargo = rmbRqstCollection.getCargo(0);
					cpRmbRequestId = rmbRqstCargo.getCp_rmb_request_id();
					populatePageCollection(pageCollection, cpRmbRequestId);
				}
			}

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.getRMBFormDataAndClob() - ***getRMBFormDataAndClob error***");
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.getRMBFormDataAndClob() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);

	}

	private void populatePageCollection(final Map pageCollection, Long cpRmbRequestId) {
		CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = cpRmbRequestDetailsRepository
				.getCpRmbRequestId(cpRmbRequestId);
		pageCollection.put(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION,
				cpRmbRequestDetailsCollection);

		RMB_RQST_Collection existingRmbRqstCollection = rmbRqstRepository.findByCpRmbRequestId(cpRmbRequestId);
		pageCollection.put(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION, existingRmbRqstCollection);
	}

	private void fetchProgramDetails(CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection, Map pageCollection) {
		if (Objects.nonNull(cpRmbRequestDetailsCollection) && !cpRmbRequestDetailsCollection.isEmpty()) {

			CpRmbRequestDetails_Cargo cpRmbRequestDetailsCargo = (CpRmbRequestDetails_Cargo) cpRmbRequestDetailsCollection
					.get(0);

			Map formStatusReqJson = null;
			String mode=null;
			if (Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.MODE))) {
				mode = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.MODE);
			}
			try {
				formStatusReqJson = (Map) new ObjectMapper().readValue(cpRmbRequestDetailsCargo.getForm_status_req(),
						Object.class);
				if (Objects.nonNull(formStatusReqJson)) {
					List caseIndividuals;
					if (HouseHoldDemoGraphicsConstants.CALFRESH_F37.equalsIgnoreCase(mode)) {
						caseIndividuals = (List) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.CASE_INDIVIDUALS_LIST);
					}else {
						caseIndividuals = (List) formStatusReqJson
								.get(HouseHoldDemoGraphicsConstants.CASE_INDIVIDUALS);
					}
					for (Object caseIndividual : caseIndividuals) {
						populatePrgsToCargo(pageCollection, caseIndividual);
					}
				}
			} catch (JsonProcessingException e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in RedeterminationServiceImpl.fetchProgramDetails()", e);
			}
		}
	}
	
	private void fetchProgramDetailsFromProgList(CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection, Map pageCollection) {
		if (Objects.nonNull(cpRmbRequestDetailsCollection) && !cpRmbRequestDetailsCollection.isEmpty()) {

			CpRmbRequestDetails_Cargo cpRmbRequestDetailsCargo = (CpRmbRequestDetails_Cargo) cpRmbRequestDetailsCollection
					.get(0);

			Map formStatusReqJson = null;
			try {
				formStatusReqJson = (Map) new ObjectMapper().readValue(cpRmbRequestDetailsCargo.getForm_status_req(),
						Object.class);
				if (Objects.nonNull(formStatusReqJson)) {
				/* Getting programList from the FormStatus Request Json Clob */
				List<String> programList = Objects.nonNull(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.PROGRAM_LIST))
						? (List<String>) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.PROGRAM_LIST)
								: null;

				if (Objects.nonNull(programList)) {
					APP_PGM_RQST_Collection appPgmReqColl = new APP_PGM_RQST_Collection();
					APP_PGM_RQST_Cargo appPgmReqCargo = new APP_PGM_RQST_Cargo();
					setDataToAppPgmRqstCargo(programList, appPgmReqCargo);
					appPgmReqColl.add(appPgmReqCargo);
					pageCollection.put(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL, appPgmReqColl);

				  }
				}
			} catch (JsonProcessingException e) {
				FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in RedeterminationServiceImpl.fetchProgramDetailsFromProgList()", e);   
			}
		}
	}

	private void setDataToAppPgmRqstCargo(List<String> programList, APP_PGM_RQST_Cargo appPgmReqCargo) {

		for (String programName: programList) {
			if (programName.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.CALWORKS_PR)) {
				appPgmReqCargo.setTanf_rqst_ind(1);
			}
			if (programName.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.CALFRESH_PR_CF37)) {
				appPgmReqCargo.setFs_rqst_ind(1);
			}
			if (programName.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.MEDICAL_PR)) {
				appPgmReqCargo.setFma_rqst_ind(1);
			}
		}

	}

	private void setDataToAppPgmIndvRqstCargo(List<String> programList, CP_APP_PGM_INDV_Cargo appPgmIndvReqCargo) {
		for (String programName: programList) {
			if (programName.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.CALWORKS_PR)) {
				appPgmIndvReqCargo.setTanf_rqst_ind(HouseHoldDemoGraphicsConstants.ONE_STRING);
			}
			if (programName.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.CALFRESH_PR_CF37)) {
				appPgmIndvReqCargo.setFs_rqst_ind(HouseHoldDemoGraphicsConstants.ONE_STRING);
			}
			if (programName.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.MEDICAL_PR)) {
				appPgmIndvReqCargo.setFma_rqst_ind(HouseHoldDemoGraphicsConstants.ONE_STRING);
			}
		}
	}


	private void populatePrgsToCargo(Map pageCollection, Object caseIndividual) throws JsonProcessingException {
		String caseIndividualString = new ObjectMapper().writeValueAsString(caseIndividual);
		CaseIndividualDetails caseIndv = new ObjectMapper().readValue(caseIndividualString,
				CaseIndividualDetails.class);
		if (Objects.nonNull(caseIndv.getPrimaryApplicant())
				&& caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			APP_PGM_RQST_Collection appPgmReqColl = new APP_PGM_RQST_Collection();
			APP_PGM_RQST_Cargo appPgmReqCargo = new APP_PGM_RQST_Cargo();
			commonPrgmDta(caseIndv, appPgmReqCargo);
			appPgmReqColl.add(appPgmReqCargo);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL, appPgmReqColl);
		}
	}

	private void commonPrgmDta(CaseIndividualDetails caseIndv, APP_PGM_RQST_Cargo appPgmReqCargo) {
		if (Objects.nonNull(caseIndv.getCashAid())
				&& caseIndv.getCashAid().equals(HouseHoldDemoGraphicsConstants.TRUE)) {
			appPgmReqCargo.setTanf_rqst_ind(1);
		}
		if (Objects.nonNull(caseIndv.getCalfresh())
				&& caseIndv.getCalfresh().equals(HouseHoldDemoGraphicsConstants.TRUE)) {
			appPgmReqCargo.setFs_rqst_ind(1);
		}
		if (Objects.nonNull(caseIndv.getHealthCoverage())
				&& caseIndv.getHealthCoverage().equals(HouseHoldDemoGraphicsConstants.TRUE)) {
			appPgmReqCargo.setFma_rqst_ind(1);
		}
	}

	/**
	 * Method to massage TNB4 specific data and set in fwTransaction
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	private void massageTNB4specificData(FwTransaction fwTransaction) {
		Map pageCollection = fwTransaction.getPageCollection();

		RMB_RQST_Collection existingRmbRqstCollection = Objects
				.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION))
						? (RMB_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION)
						: null;
		if (null != existingRmbRqstCollection && !existingRmbRqstCollection.isEmpty()) {
			RMB_RQST_Cargo rmbRqstCargo = existingRmbRqstCollection.getCargo(0);

			pageCollection.put(HouseHoldDemoGraphicsConstants.CASE_NUM, rmbRqstCargo.getCase_num());
			pageCollection.put(HouseHoldDemoGraphicsConstants.TNB_DUE_DATE, rmbRqstCargo.getTnbDueDate());
			pageCollection.put(HouseHoldDemoGraphicsConstants.FORM_DUE_DT, rmbRqstCargo.getForm_due_dt());
			pageCollection.put(HouseHoldDemoGraphicsConstants.TNB_LAST_CERTIFICATION_DATE,
					rmbRqstCargo.getTnbLastCertificationDate());
		}

		fwTransaction.setPageCollection(pageCollection);
	}

	/**
	 * Method to store App Number, case name and form report type in CP_APP_REQUEST
	 * table
	 * 
	 * @param fwTransaction, formReportType
	 * @return String
	 * @author ransahu
	 */
	private String storeAppNumInCpAppRequest(FwTransaction fwTransaction, String formReportType) {
		FwTransaction actualfwTransaction = fwTransaction;
		final Map pageCollection = actualfwTransaction.getPageCollection();

		/* Setting Case Number and TNB4 Form Type */
		RMB_RQST_Collection existingRmbRqstCollection = Objects
				.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION))
						? (RMB_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION)
						: null;
		if (null != existingRmbRqstCollection && !existingRmbRqstCollection.isEmpty()) {
			RMB_RQST_Cargo rmbRqstCargo = existingRmbRqstCollection.getCargo(0);
			APP_RQST_Collection appRqstCollection = new APP_RQST_Collection();
			APP_RQST_Cargo appRqstCargo = new APP_RQST_Cargo();
			appRqstCargo.setCaseNum(rmbRqstCargo.getCase_num());
			appRqstCargo.setFormRptType(formReportType);
			appRqstCollection.add(appRqstCargo);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_RQST_COLL, appRqstCollection);
		}

		/* Generating App Number and storing in CP_APP_REQUEST table */
		arTransactionManagedServImpl.loadRMBLanding(actualfwTransaction);
		final Map appNumPageCollection = fwTransaction.getPageCollection();
		String appNum = Objects.nonNull(appNumPageCollection.get(HouseHoldDemoGraphicsConstants.APP_NUM))
				? appNumPageCollection.get(HouseHoldDemoGraphicsConstants.APP_NUM).toString()
				: null;
		pageCollection.put(HouseHoldDemoGraphicsConstants.APP_NUM, appNum);
		fwTransaction.setPageCollection(pageCollection);
		return appNum;
	}

	/**
	 * Method to generate RMB Application data
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	private void generateRMBApplicationData(FwTransaction fwTransaction) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateRMBApplicationData() - START");

		try {
			final Map pageCollection = fwTransaction.getPageCollection();

			CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = Objects
					.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION))
							? (CpRmbRequestDetails_Collection) pageCollection
									.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION)
							: null;

			if (null != cpRmbRequestDetailsCollection && !cpRmbRequestDetailsCollection.isEmpty()) {

				CpRmbRequestDetails_Cargo cpRmbRequestDetailsCargo = (CpRmbRequestDetails_Cargo) cpRmbRequestDetailsCollection
						.get(0);

				Map formStatusReqJson = (Map) new ObjectMapper()
						.readValue(cpRmbRequestDetailsCargo.getForm_status_req(), Object.class);
				

				/* Getting countyCode from the FormStatus Request Json Clob */
				String countyCode = Objects.nonNull(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.COUNTY_CODE))
						? (String) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.COUNTY_CODE)
						: null;
				pageCollection.put(HouseHoldDemoGraphicsConstants.COUNTY_CODE, countyCode);

				generateAppNumAndStoreRMBApplicationData(fwTransaction, pageCollection, formStatusReqJson);
			}
		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		} catch (JsonProcessingException jpe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, jpe.getMessage());
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateRMBApplicationData() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);

	}

	/**
	 * Method to generate App num and massage data from cp_rmb_request and
	 * cp_rmb_request_detail tables and store/update the massaged data in
	 * CP_APP_INDV, CP_APP_PGM_INDV, CP_APP_PGM_REQUEST, CP_APP_RGST and
	 * CP_RMB_REQUEST tables
	 * 
	 * @param fwTransaction, pageCollection, formStatusReqJson
	 * @return void
	 * @author ransahu
	 */
	@SuppressWarnings("squid:S3776")
	private void generateAppNumAndStoreRMBApplicationData(FwTransaction fwTransaction, final Map pageCollection,
			Map formStatusReqJson) throws JsonProcessingException {
		/* Getting formReportType from the FormStatus Request Json Clob */
		Map form = (Map) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.FORM);
		String formReportType = (String) form.get(HouseHoldDemoGraphicsConstants.FORM_REPORT_TYPE);
		String mode = HouseHoldDemoGraphicsConstants.EMPTY;
		if (Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.MODE))) {
			mode = (String) pageCollection.get(HouseHoldDemoGraphicsConstants.MODE);
		}
		
		
		List<String> programList = Objects.nonNull(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.PROGRAM_LIST))
				? (List<String>) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.PROGRAM_LIST)
						: null;

		String appNum = storeAppNumInCpAppRequest(fwTransaction, formReportType);

		/* Setting src app indicator based on form type */
		String srcAppInd = setSrcAppIndBasedOnFormType(formReportType);
		
		srcAppInd = processSrcAppInd(mode, srcAppInd);

		/* Getting CaseIndividuals array from the Form Status Request Json Clob */

		APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
		CP_APP_RGST_Collection appRgstCollection = new CP_APP_RGST_Collection();
		CP_APP_PGM_INDV_Collection appPgmIndvCollection = new CP_APP_PGM_INDV_Collection();
		APP_PGM_RQST_Collection appPgmRqstCollection = new APP_PGM_RQST_Collection();
		CpRmbLtcDtls_Collection cpRmbLtcDtlsCollection = new CpRmbLtcDtls_Collection();
		CP_APP_IN_TAX_RETURN_Collection appInTaxReturnColl = new CP_APP_IN_TAX_RETURN_Collection();
		CP_APP_HSHL_RLT_Collection appHouseholdRltCollection = new CP_APP_HSHL_RLT_Collection();

		
		List caseIndividuals=null;
		if (HouseHoldDemoGraphicsConstants.CALFRESH_F37.equalsIgnoreCase(mode) ||
				HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING.equalsIgnoreCase(mode)) {
			caseIndividuals = (List) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.CASE_INDIVIDUALS_LIST);
		}else {
			caseIndividuals = (List) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.CASE_INDIVIDUALS);
		}
		
		if (Objects.nonNull(caseIndividuals) && !caseIndividuals.isEmpty()) {
			/*
			 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
			 */
			int primaryIndvSeqNum = 0;
			BigDecimal prmyApplPersonalId = null;
			List relationships = (List) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.RELATIONSHIP);
			List<RequestObjRelationship> relationshipList = new ArrayList<>();
			List<CP_APP_HSHL_RLT_Cargo> householdRltCargoList = new ArrayList<>();
			Map<BigDecimal, Integer> personalIdIndvIdMap = new HashMap<>();

			/*
			 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
			 * retrieving the relationship array as List of RequestObjRelationship object.
			 */
			if (Objects.nonNull(relationships) && !relationships.isEmpty()) {
				for (Object relationship : relationships) {
					String requestObjRelationshipStr = new ObjectMapper().writeValueAsString(relationship);
					RequestObjRelationship requestObjRelationship = new ObjectMapper()
							.readValue(requestObjRelationshipStr, RequestObjRelationship.class);
					relationshipList.add(requestObjRelationship);
				}
			}

			/*
			 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
			 * fetching primary Appl PersonalId.
			 */
			prmyApplPersonalId = fetchPryApplIndvSeqNum(caseIndividuals, personalIdIndvIdMap);
			if (HouseHoldDemoGraphicsConstants.CALFRESH_F37.equalsIgnoreCase(mode) ||
					HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING.equalsIgnoreCase(mode)) {
				putPrimayPerAtFirstInList(caseIndividuals, fwTransaction);
			}

			Integer indvSeqNum = 1;
			for (Object caseIndividual : caseIndividuals) {
				/* Converting CaseIndividual JSON String to Java POJO */
				String caseIndividualString = new ObjectMapper().writeValueAsString(caseIndividual);
				CaseIndividualDetails caseIndv = new ObjectMapper().readValue(caseIndividualString,
						CaseIndividualDetails.class);

				/*
				 * For Redet Medical Flow (RMC):- Must be assign indvSeqNum on the basis of..
				 * caseIndividual.PersonalId.
				 */
				indvSeqNum = fetchRMCIndvSeqNum(mode, personalIdIndvIdMap, indvSeqNum, caseIndv);

				APP_INDV_Cargo appIndvCargo = setAppIndvDetails(appNum, indvSeqNum, caseIndv, srcAppInd, mode);
				appIndvCollection.add(appIndvCargo);
				
				if (HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING.equalsIgnoreCase(mode) && programList != null) {
					CP_APP_PGM_INDV_Cargo appPgmIndvCargo = setAppPgmIndvDetailsForPR(appNum, indvSeqNum, programList, caseIndv);
					if (Objects.nonNull(appPgmIndvCargo)) {
						appPgmIndvCollection.add(appPgmIndvCargo);
					}

					APP_PGM_RQST_Cargo appPgmRqstCargo = setAppPgmRqstDetailsForPR(appNum, programList, caseIndv);
					if (Objects.nonNull(appPgmRqstCargo)) {
						appPgmRqstCollection.add(appPgmRqstCargo);
					}

				} else {
					CP_APP_PGM_INDV_Cargo appPgmIndvCargo = setAppPgmIndvDetails(appNum, indvSeqNum, caseIndv, mode);
					if (Objects.nonNull(appPgmIndvCargo)) {
						appPgmIndvCollection.add(appPgmIndvCargo);
					}

					APP_PGM_RQST_Cargo appPgmRqstCargo = setAppPgmRqstDetails(appNum, caseIndv, mode);
					if (Objects.nonNull(appPgmRqstCargo)) {
						appPgmRqstCollection.add(appPgmRqstCargo);
					}
				}
				if (HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING.equalsIgnoreCase(mode) ||
						HouseHoldDemoGraphicsConstants.CALFRESH_F37.equalsIgnoreCase(mode)) {
					setAppRgstCargo(formStatusReqJson, appNum, srcAppInd, appRgstCollection, indvSeqNum,
							caseIndv, mode);
				} else {
					CP_APP_RGST_Cargo appRgstCargo = setCaseIndividualAddressAndContactDetails(appNum, indvSeqNum, caseIndv,
							srcAppInd, mode);
					if(HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(mode)) {
						if(caseIndv != null && caseIndv.getHomeless() == Boolean.TRUE) {
							appRgstCargo.setHless_sw("Y");
						}
						else if(caseIndv != null && caseIndv.getHomeless() == Boolean.FALSE){
							appRgstCargo.setHless_sw("N");
						}
						
					}
					appRgstCollection.add(appRgstCargo);
				}
				setCaseNameAsPrimaryIndividual(pageCollection, caseIndv);

				/*
				 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
				 * processing and initiating Household Rlt code cargo.
				 */
				if (HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(mode)) {
					List<String> appNumSrcAppIndLst = new ArrayList<>();
					appNumSrcAppIndLst.add(appNum);
					appNumSrcAppIndLst.add(srcAppInd);
					primaryIndvSeqNum = processHshlRltCargo(appNumSrcAppIndLst, primaryIndvSeqNum, prmyApplPersonalId,
							relationshipList, householdRltCargoList, indvSeqNum, caseIndv);

					CpRmbLtcDtls_Cargo cpLtcCargo = setHHSituationDetails(appNum, indvSeqNum, caseIndv);
					if(Objects.nonNull(cpLtcCargo)) {
						cpRmbLtcDtlsCollection.add(cpLtcCargo);
					}

					processAppInTaxRetuenCargo(appNum, indvSeqNum, srcAppInd, caseIndv, appInTaxReturnColl,
							personalIdIndvIdMap);
				}

				indvSeqNum++;
			}

			/*
			 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
			 * appending primary applicant indvSeqNum as src_app_seq_num to each
			 * householdRltCargo.
			 */
			if (Objects.nonNull(householdRltCargoList) && !householdRltCargoList.isEmpty()) {
				final int pIndvSeqNum = primaryIndvSeqNum;
				householdRltCargoList.stream().forEach(x -> {
					x.setSrcIndvSeqNum(pIndvSeqNum);
					appHouseholdRltCollection.add(x);
				});
			}
		}
		/*
		 * Storing individuals, program details and mailing/contact address in
		 * CP_APP_INDV, CP_APP_PGM_INDV, CP_APP_PGM_REQUEST and CP_APP_RGST tables
		 */
		cpAppIndvRepository.saveAll(appIndvCollection);
		cpAppPgmIndvRepository.saveAll(appPgmIndvCollection);
		cpAppPgmRqstRepository.saveAll(appPgmRqstCollection);
		cpAppRgstRepository.saveAll(appRgstCollection);
		householdRelationshipRepo.saveAll(appHouseholdRltCollection);
		cpRmbLtcDtlsRepository.saveAll(cpRmbLtcDtlsCollection);
		cpAppInTaxReturnRepository.saveAll(appInTaxReturnColl);

		/*
		 * Updating new App Number in CP_RMB_REQUEST table
		 */
		updateAppNumInCpRmbRequest(pageCollection, appNum);

		pageCollection.put(HouseHoldDemoGraphicsConstants.APP_INDV_COLLECTION, appIndvCollection);
		pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_PGM_INDV_Collection, appPgmIndvCollection);
		pageCollection.put(HouseHoldDemoGraphicsConstants.APP_PGM_RQST_COLL, appPgmRqstCollection);
		pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_RGST_COLLECTION, appRgstCollection);
		pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION, appHouseholdRltCollection);
		pageCollection.put(HouseHoldDemoGraphicsConstants.CpRmbLtcDtlsCollection, cpRmbLtcDtlsCollection);
		pageCollection.put(HouseHoldDemoGraphicsConstants.APP_NUM, appNum);
	}
	
	private void setAppRgstCargo(Map formStatusReqJson, String appNum, String srcAppInd,
			CP_APP_RGST_Collection appRgstCollection, Integer indvSeqNum, CaseIndividualDetails caseIndv, String mode)
			throws JsonProcessingException {
		CP_APP_RGST_Cargo appRgstCargo;
			appRgstCargo = setPrimaryIndividualAddress(appNum, indvSeqNum, caseIndv, srcAppInd,
					formStatusReqJson, mode);
			if (Objects.nonNull(appRgstCargo)) {
				appRgstCollection.add(appRgstCargo);
			}
	}
	
	/**
	 * Method to set Primary Individual Address to CP_APP_RGST_Cargo
	 * 
	 * @param appNum, indvSeqNum, caseIndv, srcAppInd, formStatusReqJson
	 * @return CP_APP_RGST_Cargo
	 * @author ransahu
	 * @param mode 
	 * @throws JsonProcessingException
	 */
	private CP_APP_RGST_Cargo setPrimaryIndividualAddress(String appNum, Integer indvSeqNum,
			CaseIndividualDetails caseIndv, String srcAppInd, Map formStatusReqJson, String mode) throws JsonProcessingException {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.setPrimaryIndividualAddress() "
						+ "- settting Primary Individual Address to CP_APP_RGST_Cargo");

		/*
		 * Getting MailingAddress and MailbackAddressOffice from the FormStatus Request
		 * Json Clob
		 */
		String mailingAddressString = new ObjectMapper()
				.writeValueAsString(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.MAILING_ADDRESS));
		CaseIndividualDetailsAddress mailingAddress = new ObjectMapper().readValue(mailingAddressString,
				CaseIndividualDetailsAddress.class);
		String mailbackAddressOfficeString = new ObjectMapper()
				.writeValueAsString(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.MAILBACK_ADDRESS_OFFICE));
		CaseIndividualDetailsAddress mailbackAddressOffice = new ObjectMapper().readValue(mailbackAddressOfficeString,
				CaseIndividualDetailsAddress.class);

       if (Objects.nonNull(mailingAddress) && caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			CP_APP_RGST_Cargo appRgstCargo = new CP_APP_RGST_Cargo();
			appRgstCargo.setApp_num(appNum);
			appRgstCargo.setSrc_app_ind(srcAppInd);
			appRgstCargo.setIndv_seq_num(indvSeqNum);
			if (Objects.nonNull(mailingAddress)) {
				appRgstCargo.setAlt_l1_adr(mailingAddress.getAddressLine());
				appRgstCargo.setAlt_city_adr(mailingAddress.getCity());
				appRgstCargo.setAlt_sta_adr(mailingAddress.getState());
				appRgstCargo.setAlt_zip_adr(mailingAddress.getZipcode());
				appRgstCargo.setAlt_apt_num(mailingAddress.getApt());
			}
			return appRgstCargo;
		}
		return null;
	}

	private APP_PGM_RQST_Cargo setAppPgmRqstDetailsForPR(String appNum, List<String> programList, CaseIndividualDetails caseIndv) {
		if (Objects.nonNull(caseIndv.getPrimaryApplicant())
				&& caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			APP_PGM_RQST_Cargo appPgmRqstCargo = new APP_PGM_RQST_Cargo();
			appPgmRqstCargo.setApp_num(appNum);
			setDataToAppPgmRqstCargo(programList, appPgmRqstCargo);	
			return appPgmRqstCargo;
		}
		return null;
	}

	private CP_APP_PGM_INDV_Cargo setAppPgmIndvDetailsForPR(String appNum, Integer indvSeqNum,
			List<String> programList, CaseIndividualDetails caseIndv) {
		if (!caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			CP_APP_PGM_INDV_Cargo appPgmIndvCargo = new CP_APP_PGM_INDV_Cargo();
			appPgmIndvCargo.setApp_num(appNum);
			appPgmIndvCargo.setApp_pgm_indv_id(indvSeqNum.toString());
			appPgmIndvCargo.setIndv_seq_num(Double.valueOf(indvSeqNum));
			setDataToAppPgmIndvRqstCargo(programList, appPgmIndvCargo);
			return appPgmIndvCargo;
		}
		return null;
	}

	private String processSrcAppInd(String mode, String srcAppInd) {
		if (HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(mode)) {
			return HouseHoldDemoGraphicsConstants.APP_IND_AFB;
		} else {
			return srcAppInd;
		}
	}

	private Integer fetchRMCIndvSeqNum(String mode, Map<BigDecimal, Integer> personalIdIndvIdMap, Integer indvSeqNum,
			CaseIndividualDetails caseIndv) {
		if (HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(mode)) {
			indvSeqNum = personalIdIndvIdMap.get(caseIndv.getPersonalId());
			return indvSeqNum;
		} else {
			return indvSeqNum;
		}
	}

	private void processAppInTaxRetuenCargo(String appNum, Integer indvSeqNum, String srcAppInd,
			CaseIndividualDetails caseIndv, CP_APP_IN_TAX_RETURN_Collection appInTaxReturnColl,
			Map<BigDecimal, Integer> personalIdIndvIdMap) throws JsonProcessingException {

		CaseIndividualDetailsTaxStatus taxStatus = caseIndv.getTaxStatus();
		CaseIndividualDetailsTaxReview taxReview = caseIndv.getTaxReview();

		if (Objects.nonNull(taxStatus) && Objects.nonNull(taxReview)) {

			CP_APP_IN_TAX_RETURN_Cargo appInTaxReturnCargo = new CP_APP_IN_TAX_RETURN_Cargo();

			appInTaxReturnCargo.setApp_num(appNum);
			appInTaxReturnCargo.setIndv_seq_num(indvSeqNum);
			appInTaxReturnCargo.setSrc_app_ind(srcAppInd);

			processTaxStatus(personalIdIndvIdMap, taxStatus, appInTaxReturnCargo);

			processTaxReviewDetails(taxReview, appInTaxReturnCargo);
			
			CaseIndividualDetails tempCaseIndv = new CaseIndividualDetails();
			tempCaseIndv.setTaxReview(taxReview);
			tempCaseIndv.setTaxStatus(taxStatus);
			String caseIndividualStr = toCaseIndividual(tempCaseIndv);
			appInTaxReturnCargo.setTaxCalsawsObject(caseIndividualStr);

			appInTaxReturnColl.add(appInTaxReturnCargo);
		}
	}

	private void processTaxReviewDetails(CaseIndividualDetailsTaxReview taxReview,
			CP_APP_IN_TAX_RETURN_Cargo appInTaxReturnCargo) {

		if (Objects.nonNull(taxReview.isPrimaryTaxFilerInd()) && taxReview.isPrimaryTaxFilerInd()) {
			appInTaxReturnCargo.setPrimary_filer_sw(HouseHoldDemoGraphicsConstants.Y);
		} else if (Objects.nonNull(taxReview.isPrimaryTaxFilerInd()) && !taxReview.isPrimaryTaxFilerInd()) {
			appInTaxReturnCargo.setPrimary_filer_sw(HouseHoldDemoGraphicsConstants.N);
		}

		if (Objects.nonNull(taxReview.isExpectedToFileTaxReturn()) && taxReview.isExpectedToFileTaxReturn()) {
			appInTaxReturnCargo.setTaxReturnSw(HouseHoldDemoGraphicsConstants.Y);
		} else if (Objects.nonNull(taxReview.isExpectedToFileTaxReturn()) && !taxReview.isExpectedToFileTaxReturn()) {
			appInTaxReturnCargo.setTaxReturnSw(HouseHoldDemoGraphicsConstants.N);
		}

		if (Objects.nonNull(taxReview.isPlansToFileTaxReturn()) && taxReview.isPlansToFileTaxReturn()) {
			appInTaxReturnCargo.setFederalTaxSw(HouseHoldDemoGraphicsConstants.Y);
		} else if (Objects.nonNull(taxReview.isPlansToFileTaxReturn()) && !taxReview.isPlansToFileTaxReturn()) {
			appInTaxReturnCargo.setFederalTaxSw(HouseHoldDemoGraphicsConstants.N);
		}
	}

	private void processTaxStatus(Map<BigDecimal, Integer> personalIdIndvIdMap,
			CaseIndividualDetailsTaxStatus taxStatus, CP_APP_IN_TAX_RETURN_Cargo appInTaxReturnCargo) {

		processClaimedAsOfDependent(personalIdIndvIdMap, taxStatus, appInTaxReturnCargo);

		if (Objects.nonNull(taxStatus.isHeadOfHouseholdInd()) && taxStatus.isHeadOfHouseholdInd()) {
			appInTaxReturnCargo.setStatusCd(HouseHoldDemoGraphicsConstants.TAX_HEAD_OF_HOUSEHOLD_IND);
		}

		processMarriedFilingJointly(personalIdIndvIdMap, taxStatus, appInTaxReturnCargo);

		if (Objects.nonNull(taxStatus.isMarriedFilingSeperatelyInd()) && taxStatus.isMarriedFilingSeperatelyInd()) {
			appInTaxReturnCargo.setStatusCd(HouseHoldDemoGraphicsConstants.TAX_MARRIED_FILING_SEPERATELY_IND);
		}

		if (Objects.nonNull(taxStatus.isNonTaxFilerInd()) && taxStatus.isNonTaxFilerInd()) {
			appInTaxReturnCargo.setStatusCd(HouseHoldDemoGraphicsConstants.NON_TAX_FILER_IND);
		}

		if (Objects.nonNull(taxStatus.isSingleInd()) && taxStatus.isSingleInd()) {
			appInTaxReturnCargo.setStatusCd(HouseHoldDemoGraphicsConstants.TAX_SINGLE_IND);
		}
	}

	private void processMarriedFilingJointly(Map<BigDecimal, Integer> personalIdIndvIdMap,
			CaseIndividualDetailsTaxStatus taxStatus, CP_APP_IN_TAX_RETURN_Cargo appInTaxReturnCargo) {
		if (Objects.nonNull(taxStatus.isMarriedFilingJointlyInd()) && taxStatus.isMarriedFilingJointlyInd()) {
			appInTaxReturnCargo.setStatusCd(HouseHoldDemoGraphicsConstants.TAX_MARRIED_FILING_JOINTLY_IND);

			if (Objects.nonNull(taxStatus.getJointFilerPersonId())) {
				appInTaxReturnCargo.setSpouse_indv_id(personalIdIndvIdMap.get(taxStatus.getJointFilerPersonId()));
			}
			appInTaxReturnCargo.setSpouse_first_name(taxStatus.getJointFillFirstName());
			appInTaxReturnCargo.setSpouse_mid_name(taxStatus.getJointFillMiddleName());
			appInTaxReturnCargo.setSpouse_last_name(taxStatus.getJointFillLastName());
		}
	}

	private void processClaimedAsOfDependent(Map<BigDecimal, Integer> personalIdIndvIdMap,
			CaseIndividualDetailsTaxStatus taxStatus, CP_APP_IN_TAX_RETURN_Cargo appInTaxReturnCargo) {
		if (Objects.nonNull(taxStatus.isClaimedAsOfDependentInd()) && taxStatus.isClaimedAsOfDependentInd()) {
			appInTaxReturnCargo.setStatusCd(HouseHoldDemoGraphicsConstants.CLAIMED_AS_OF_DEPENDENT_IND);

			if (Objects.nonNull(taxStatus.getTaxFilerPersonId())) {
				appInTaxReturnCargo.setMcTaxFilerId(personalIdIndvIdMap.get(taxStatus.getTaxFilerPersonId()));
			}
		}
	}

	/**
	 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
	 * retrieving primary Applicant personalId.
	 * 
	 * @param caseIndividuals
	 * @return
	 * @throws JsonProcessingException
	 */
	private BigDecimal fetchPryApplIndvSeqNum(List caseIndividuals, Map<BigDecimal, Integer> personalIdIndvmap)
			throws JsonProcessingException {
		BigDecimal pmryApplPersonalId = null;

		if (Objects.nonNull(caseIndividuals) && !caseIndividuals.isEmpty()) {
			Integer indvSeqNum = 1;
			for (Object caseIndividual : caseIndividuals) {
				String caseIndividualString = new ObjectMapper().writeValueAsString(caseIndividual);
				CaseIndividualDetails caseIndv = new ObjectMapper().readValue(caseIndividualString,
						CaseIndividualDetails.class);
				if (caseIndv.getPrimaryApplicant().equalsIgnoreCase(HouseHoldDemoGraphicsConstants.Y)) {
					pmryApplPersonalId = caseIndv.getPersonalId();
				}

				personalIdIndvmap.put(caseIndv.getPersonalId(), indvSeqNum);

				indvSeqNum++;
			}
		}

		return pmryApplPersonalId;
	}

	/**
	 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
	 * setting List of CP_APP_HSHL_RLT_Cargo object.
	 * 
	 * @param appNum
	 * @param srcAppInd
	 * @param primaryIndvSeqNum
	 * @param relationshipList
	 * @param householdRltCargoList
	 * @param indvSeqNum
	 * @param caseIndv
	 * @return
	 */
	private int processHshlRltCargo(List<String> appNumSrcAppIndLst, int primaryIndvSeqNum,
			BigDecimal pmryApplPersonalId, List<RequestObjRelationship> relationshipList,
			List<CP_APP_HSHL_RLT_Cargo> householdRltCargoList, Integer indvSeqNum, CaseIndividualDetails caseIndv) {

		/*
		 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
		 * retrieving primary applicant indvSeqNum.
		 */
		if (Objects.nonNull(caseIndv.getPrimaryApplicant())
				&& caseIndv.getPrimaryApplicant().equalsIgnoreCase(HouseHoldDemoGraphicsConstants.Y)) {
			primaryIndvSeqNum = indvSeqNum;
		}

		if (Objects.nonNull(relationshipList) && !relationshipList.isEmpty() && Objects.nonNull(pmryApplPersonalId)) {
			int tmpIndvSeqNum = indvSeqNum;
			List<CP_APP_HSHL_RLT_Cargo> householdRltCargos = relationshipList.stream()
					.filter(x -> new BigDecimal(x.getIndv2()).equals(caseIndv.getPersonalId())
							&& new BigDecimal(x.getIndv1()).equals(pmryApplPersonalId))
					.map(u -> setHouseholdRltDetail(appNumSrcAppIndLst.get(0), u, tmpIndvSeqNum,
							appNumSrcAppIndLst.get(1)))
					.collect(Collectors.toList());
			
			if (Objects.nonNull(householdRltCargos) && !householdRltCargos.isEmpty()) {
				householdRltCargoList.add(householdRltCargos.get(0));
			}
		}
		return primaryIndvSeqNum;
	}

	/**
	 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
	 * setting household relationship detail from form status type.
	 * 
	 * @param appNum    as String
	 * @param caseIndv  as CaseIndividualDetails
	 * @param srcAppInd as String
	 * @return
	 */
	public CP_APP_HSHL_RLT_Cargo setHouseholdRltDetail(String appNum, RequestObjRelationship requestObjRelationship,
			Integer indvSeqNum, String srcAppInd) {

		CP_APP_HSHL_RLT_Cargo householdRltCargo = new CP_APP_HSHL_RLT_Cargo();
		householdRltCargo.setApp_num(appNum);
		householdRltCargo.setSrcAppIndiv(srcAppInd);

		if (Objects.nonNull(requestObjRelationship)) {
			householdRltCargo.setRefIndvSeqNum(indvSeqNum);
			householdRltCargo.setRltCd(requestObjRelationship.getRelationCode());
		}
		
		try {
			RequestObjRelationship tempRstObjRel = requestObjRelationship;
			String rltObjRelStr = new ObjectMapper().writeValueAsString(tempRstObjRel);
			householdRltCargo.setRltCalsawsObject(rltObjRelStr);
		} catch (JsonProcessingException e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
		}
		
		return householdRltCargo;
	}

	/**
	 * Method to set src app indicator based on formReportType coming from form
	 * status api clob
	 * 
	 * @param formReportType
	 * @return String
	 * @author ransahu
	 */
	private String setSrcAppIndBasedOnFormType(String formReportType) {
		String srcAppInd = HouseHoldDemoGraphicsConstants.EMPTY;
		if (formReportType.equals(HouseHoldDemoGraphicsConstants.TNB4_TN)) {
			srcAppInd = HouseHoldDemoGraphicsConstants.TNB4_TN;
		}
		if (formReportType.equals(HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING)) {
			srcAppInd = HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING;
		}
		if (formReportType.equals(HouseHoldDemoGraphicsConstants.CALFRESH_F37)) {
			srcAppInd = HouseHoldDemoGraphicsConstants.CALFRESH_F37;
		}
		if (formReportType.equals(HouseHoldDemoGraphicsConstants.REDETMC_MC)) {
			srcAppInd = HouseHoldDemoGraphicsConstants.REDETMC_MC;
		}
		return srcAppInd;
	}

	/**
	 * Method to set Case Name from Primary Individual First name and Last name
	 * 
	 * @param pageCollection, caseIndv
	 * @return void
	 * @author ransahu
	 * @param pageCollection
	 */
	private void setCaseNameAsPrimaryIndividual(Map pageCollection, CaseIndividualDetails caseIndv) {
		if (Objects.nonNull(caseIndv.getPrimaryApplicant())
				&& caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			String caseName = caseIndv.getFirstName().concat(HouseHoldDemoGraphicsConstants.ONE_SPACE)
					.concat(caseIndv.getLastName());
			pageCollection.put(HouseHoldDemoGraphicsConstants.CASE_NAME, caseName);
		}
	}

	/**
	 * Method to set details into APP_PGM_RQST_Cargo
	 * 
	 * @param appNum, caseIndv
	 * @return APP_PGM_RQST_Cargo
	 * @author ransahu
	 */
	private APP_PGM_RQST_Cargo setAppPgmRqstDetails(String appNum, CaseIndividualDetails caseIndv, String mode) {
		if (Objects.nonNull(caseIndv.getPrimaryApplicant())
				&& caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			APP_PGM_RQST_Cargo appPgmRqstCargo = new APP_PGM_RQST_Cargo();
			if (Objects.nonNull(mode) && mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING)) {
				populateAppPgmRqstCargo(appNum, appPgmRqstCargo, caseIndv);
				return appPgmRqstCargo;
			} else if (Objects.nonNull(mode) && mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.MC_MODE)) {
				appPgmRqstCargo.setApp_num(appNum);
				appPgmRqstCargo.setFma_rqst_ind(1);
				return appPgmRqstCargo;
			} else if (Objects.nonNull(mode) && mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.CW_REDET_MODE)) {
				populateAppPgmRqstCargo(appNum, appPgmRqstCargo, caseIndv);
				return appPgmRqstCargo;
			} else {
				appPgmRqstCargo.setApp_num(appNum);
				appPgmRqstCargo.setFs_rqst_ind(1);
				appPgmRqstCargo.setFma_rqst_ind(0);
				appPgmRqstCargo.setTanf_rqst_ind(0);
				return appPgmRqstCargo;
			}
		}
		return null;
	}

	private void populateAppPgmRqstCargo(String appNum, APP_PGM_RQST_Cargo appPgmRqstCargo,
			CaseIndividualDetails caseIndv) {
		appPgmRqstCargo.setApp_num(appNum);
		commonPrgmDta(caseIndv, appPgmRqstCargo);
	}

	/**
	 * Method to set details into CP_APP_PGM_INDV_Cargo
	 * 
	 * @param appNum, indvSeqNum, caseIndv
	 * @return CP_APP_PGM_INDV_Cargo
	 * @author ransahu
	 */
	private CP_APP_PGM_INDV_Cargo setAppPgmIndvDetails(String appNum, Integer indvSeqNum,
			CaseIndividualDetails caseIndv, String mode) {
		if (Objects.nonNull(caseIndv.getPrimaryApplicant()) && !caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			CP_APP_PGM_INDV_Cargo appPgmIndvCargo = new CP_APP_PGM_INDV_Cargo();
			if (Objects.nonNull(mode) && mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING)) {
				populateAppPgmIndvCargo(appNum, indvSeqNum, caseIndv, appPgmIndvCargo);
				return appPgmIndvCargo;
			} else if (Objects.nonNull(mode) && mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.MC_MODE)) {
				appPgmIndvCargo.setApp_num(appNum);
				appPgmIndvCargo.setApp_pgm_indv_id(indvSeqNum.toString());
				appPgmIndvCargo.setIndv_seq_num(Double.valueOf(indvSeqNum));
				appPgmIndvCargo.setFma_rqst_ind(HouseHoldDemoGraphicsConstants.ONE_STRING);
				return appPgmIndvCargo;
			} else if (Objects.nonNull(mode) && mode.equalsIgnoreCase(HouseHoldDemoGraphicsConstants.CW_REDET_MODE)) {
				populateAppPgmIndvCargo(appNum, indvSeqNum, caseIndv, appPgmIndvCargo);
				return appPgmIndvCargo;
			} else {
				appPgmIndvCargo.setApp_num(appNum);
				appPgmIndvCargo.setApp_pgm_indv_id(indvSeqNum.toString());
				appPgmIndvCargo.setIndv_seq_num(Double.valueOf(indvSeqNum));
				appPgmIndvCargo.setFs_rqst_ind(HouseHoldDemoGraphicsConstants.ONE_STRING);
				appPgmIndvCargo.setTanf_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO_STRING);
				appPgmIndvCargo.setFma_rqst_ind(HouseHoldDemoGraphicsConstants.ZERO_STRING);
				return appPgmIndvCargo;
			}
		}
		return null;
	}

	private void populateAppPgmIndvCargo(String appNum, Integer indvSeqNum, CaseIndividualDetails caseIndv,
			CP_APP_PGM_INDV_Cargo appPgmIndvCargo) {
		appPgmIndvCargo.setApp_num(appNum);
		appPgmIndvCargo.setApp_pgm_indv_id(indvSeqNum.toString());
		appPgmIndvCargo.setIndv_seq_num(Double.valueOf(indvSeqNum));
		setAppPgmIndvData(caseIndv, appPgmIndvCargo);
	}

	private void setAppPgmIndvData(CaseIndividualDetails caseIndv, CP_APP_PGM_INDV_Cargo appPgmIndvCargo) {
		if (Objects.nonNull(caseIndv.getCashAid())
				&& caseIndv.getCashAid().equals(HouseHoldDemoGraphicsConstants.TRUE)) {
			appPgmIndvCargo.setTanf_rqst_ind(HouseHoldDemoGraphicsConstants.ONE_STRING);
		}
		if (Objects.nonNull(caseIndv.getCalfresh())
				&& caseIndv.getCalfresh().equals(HouseHoldDemoGraphicsConstants.TRUE)) {
			appPgmIndvCargo.setFs_rqst_ind(HouseHoldDemoGraphicsConstants.ONE_STRING);
		}
		if (Objects.nonNull(caseIndv.getHealthCoverage())
				&& caseIndv.getHealthCoverage().equals(HouseHoldDemoGraphicsConstants.TRUE)) {
			appPgmIndvCargo.setFma_rqst_ind(HouseHoldDemoGraphicsConstants.ONE_STRING);
		}
	}

	/**
	 * Method to set details into APP_INDV_Cargo
	 * 
	 * @param appNum, indvSeqNum, caseIndv, srcAppInd
	 * @return APP_INDV_Cargo
	 * @author ransahu
	 * @throws JsonProcessingException 
	 */
	@SuppressWarnings("squid:S3776")
	private APP_INDV_Cargo setAppIndvDetails(String appNum, Integer indvSeqNum, CaseIndividualDetails caseIndv,
			String srcAppInd, String mode) throws JsonProcessingException {
		APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
		appIndvCargo.setApp_num(appNum);
		appIndvCargo.setIndv_seq_num(indvSeqNum);
		appIndvCargo.setFst_nam(caseIndv.getFirstName());
		appIndvCargo.setLast_nam(caseIndv.getLastName());
		appIndvCargo.setMid_init(caseIndv.getMiddleName());
		appIndvCargo.setSuffix_name(caseIndv.getSuffix());
		appIndvCargo.setCinNumber(caseIndv.getCin());
		appIndvCargo.setBrth_dt(caseIndv.getDob());
		appIndvCargo.setAge(caseIndv.getAge());
		appIndvCargo.setSex_ind(caseIndv.getGenderCode());
		appIndvCargo.setSrc_app_ind(srcAppInd);

		/*
		 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
		 */
		if (Objects.nonNull(caseIndv.getLtcNewPersonDetail())) {
			if (caseIndv.getLtcNewPersonDetail().getLtcind()) {
				appIndvCargo.setLtcInd(HouseHoldDemoGraphicsConstants.Y);
			} else {
				appIndvCargo.setLtcInd(HouseHoldDemoGraphicsConstants.N);
			}
		}

		/*
		 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
		 */
		if (Objects.nonNull(caseIndv.getIncarceratedDetail())) {
			if (caseIndv.getIncarceratedDetail().isIncarceratedInd()) {
				appIndvCargo.setIncarceratedind(HouseHoldDemoGraphicsConstants.Y);
			} else {
				appIndvCargo.setIncarceratedind(HouseHoldDemoGraphicsConstants.N);
			}

			appIndvCargo.setDateOfRelease(
					DateUtility.convertToLocalDateViaSqlDate(caseIndv.getIncarceratedDetail().getDateOfRelease()));
		}

		/*
		 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
		 */
		if (Objects.nonNull(caseIndv.getPassedAwayDetail())) {
			if (caseIndv.getPassedAwayDetail().isDeceasedInd()) {
				appIndvCargo.setDeceased_ind(HouseHoldDemoGraphicsConstants.Y);
			} else {
				appIndvCargo.setDeceased_ind(HouseHoldDemoGraphicsConstants.N);
			}

			appIndvCargo.setDecease_dt(caseIndv.getPassedAwayDetail().getDateOfDeath());

			appIndvCargo.setDeceaseComments(caseIndv.getPassedAwayDetail().getDeathExpl());
		}

		if (Objects.nonNull(caseIndv.getPrimaryApplicant())
				&& caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
			appIndvCargo.setPrim_prsn_sw(HouseHoldDemoGraphicsConstants.Y);
		}
		if (Objects.nonNull(caseIndv.getPersonalId())) {
			appIndvCargo.setCalsaws_personal_id(caseIndv.getPersonalId());
		}
		
		if(HouseHoldDemoGraphicsConstants.MC_MODE.equals(mode)) {
			
			appIndvCargo.setLang_cd(caseIndv.getWrittenLanguage());
			appIndvCargo.setLang_cd_sp(caseIndv.getSpokenLanguage());
			
			CaseIndividualDetails tempCaseIndv = new CaseIndividualDetails();
			setCaseIndividualDetails(tempCaseIndv, caseIndv);
			String caseIndividualString = toCaseIndividual(tempCaseIndv);
			appIndvCargo.setCalsawsObject(caseIndividualString);
		}
		
		if (HouseHoldDemoGraphicsConstants.CALFRESH_F37.equalsIgnoreCase(mode) ||
				HouseHoldDemoGraphicsConstants.PERIODIC_REPORTING.equalsIgnoreCase(mode)) {		
			appIndvCargo.setBrth_dt(caseIndv.getDateOfBirth());
		}
		
		return appIndvCargo;
	}
	
private void setCaseIndividualDetails(CaseIndividualDetails tempCaseIndv, CaseIndividualDetails caseIndv) {
		
		tempCaseIndv.setFirstName(caseIndv.getFirstName());
		tempCaseIndv.setMiddleName(caseIndv.getMiddleName());
		tempCaseIndv.setSuffix(caseIndv.getSuffix());
		tempCaseIndv.setCin(caseIndv.getCin());
		tempCaseIndv.setGenderCode(caseIndv.getGenderCode());
		tempCaseIndv.setEmailAddress(caseIndv.getEmailAddress());
		tempCaseIndv.setPrimaryApplicant(caseIndv.getPrimaryApplicant());
		tempCaseIndv.setHomeAddress(caseIndv.getHomeAddress());
		tempCaseIndv.setMailingAddressIfDifferent(caseIndv.getMailingAddressIfDifferent());
		tempCaseIndv.setHomePhoneNumber(caseIndv.getHomePhoneNumber());
		tempCaseIndv.setCellPhoneNumber(caseIndv.getCellPhoneNumber());
		tempCaseIndv.setWorkPhoneNumber(caseIndv.getWorkPhoneNumber());
		tempCaseIndv.setSpokenLanguage(caseIndv.getSpokenLanguage());
		tempCaseIndv.setWrittenLanguage(caseIndv.getWrittenLanguage());
		tempCaseIndv.setIncarceratedDetail(caseIndv.getIncarceratedDetail());
		tempCaseIndv.setPassedAwayDetail(caseIndv.getPassedAwayDetail());
		tempCaseIndv.setHealthCoverage(caseIndv.getHealthCoverage());
		tempCaseIndv.setLastName(caseIndv.getLastName());
		tempCaseIndv.setAge(caseIndv.getAge());
		tempCaseIndv.setDob(caseIndv.getDob());
		tempCaseIndv.setLtcNewPersonDetail(caseIndv.getLtcNewPersonDetail());
		tempCaseIndv.setPersonalId(caseIndv.getPersonalId());
	}

private String toCaseIndividual(CaseIndividualDetails caseIndv) throws JsonProcessingException {
	return new ObjectMapper().writeValueAsString(caseIndv);
}

	/**
	 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
	 * 
	 * @param appNum     as String
	 * @param indvSeqNum as Integer
	 * @param caseIndv   as CaseIndividualDetails
	 * @return CpRmbLtcDtlsCargo type
	 * @throws JsonProcessingException 
	 */
	private CpRmbLtcDtls_Cargo setHHSituationDetails(String appNum, Integer indvSeqNum, CaseIndividualDetails caseIndv) throws JsonProcessingException {
		CpRmbLtcDtls_Cargo appLtcCargo = null;

		if (Objects.nonNull(caseIndv.getLtcNewPersonDetail())) {
			appLtcCargo = new CpRmbLtcDtls_Cargo();
			appLtcCargo.setAppNum(appNum);
			appLtcCargo.setIndvSeqNum(indvSeqNum);
			appLtcCargo.setSeqNum(Integer.valueOf(1));
			appLtcCargo.setFacilityName(caseIndv.getLtcNewPersonDetail().getFacilityName());
			LtcNewPersonDetailAddress facilityAddress = caseIndv.getLtcNewPersonDetail().getFacilityAddress();
			processFacilityAddress(appLtcCargo, facilityAddress);
			appLtcCargo.setSpouseFirstName(caseIndv.getLtcNewPersonDetail().getDomesticPartnerFirstName());
			appLtcCargo.setSpouseMidName(caseIndv.getLtcNewPersonDetail().getDomesticPartnerMidName());
			appLtcCargo.setSpouseLastName(caseIndv.getLtcNewPersonDetail().getDomesticPartnerLastName());
			if ((caseIndv.getLtcNewPersonDetail().getDomesticPartnerFirstName() != null)
					|| (caseIndv.getLtcNewPersonDetail().getDomesticPartnerMidName() != null)
					|| (caseIndv.getLtcNewPersonDetail().getDomesticPartnerLastName() != null)) {
				appLtcCargo.setIs_spouse("Y");
			}
			LtcNewPersonDetailAddress domesticPartnerAddress = caseIndv.getLtcNewPersonDetail()
					.getDomesticPartnerAddress();
			processDomPartnerAdd(appLtcCargo, domesticPartnerAddress);
			appLtcCargo.setEntanceDate(caseIndv.getLtcNewPersonDetail().getEntanceDate());
			appLtcCargo.setDischargeDate(caseIndv.getLtcNewPersonDetail().getDischargeDate());

			String ltcNewPersonDetailStr = new ObjectMapper().writeValueAsString(caseIndv.getLtcNewPersonDetail());
			appLtcCargo.setLtcCalsawsObject(ltcNewPersonDetailStr);
		}

		return appLtcCargo;
	}
	
	private void processDomPartnerAdd(CpRmbLtcDtls_Cargo appLtcCargo, LtcNewPersonDetailAddress domesticPartnerAddress) {
		if(Objects.nonNull(domesticPartnerAddress)) {
			appLtcCargo.setSpouseAddressLine1(domesticPartnerAddress.getAddressLine());
			appLtcCargo.setSpouseAddressLine2(domesticPartnerAddress.getApt());
			appLtcCargo.setSpouseAddressCity(domesticPartnerAddress.getCity());
			appLtcCargo.setSpouseAddressState(domesticPartnerAddress.getState());
			appLtcCargo.setSpouseAddressZip(domesticPartnerAddress.getZipcode());
		}
	}

	private void processFacilityAddress(CpRmbLtcDtls_Cargo appLtcCargo, LtcNewPersonDetailAddress facilityAddress) {
		if(Objects.nonNull(facilityAddress)) {
			appLtcCargo.setFacilityAddressLine1(facilityAddress.getAddressLine());
			appLtcCargo.setFacilityAddressLine2(facilityAddress.getApt());
			appLtcCargo.setFacilityAddressCity(facilityAddress.getCity());
			appLtcCargo.setFacilityAddressState(facilityAddress.getState());
			appLtcCargo.setFacilityAddressZip(facilityAddress.getZipcode());
		}
	}

	/**
	 * Method to set Case Individual Address and Contact details to
	 * CP_APP_RGST_Cargo
	 * 
	 * @param appNum, indvSeqNum, caseIndv, srcAppInd
	 * @return CP_APP_RGST_Cargo
	 * @author ransahu
	 */
	private CP_APP_RGST_Cargo setCaseIndividualAddressAndContactDetails(String appNum, Integer indvSeqNum,
			CaseIndividualDetails caseIndv, String srcAppInd, String mode) {
		CP_APP_RGST_Cargo appRgstCargo = new CP_APP_RGST_Cargo();
		appRgstCargo.setApp_num(appNum);
		appRgstCargo.setSrc_app_ind(srcAppInd);
		appRgstCargo.setIndv_seq_num(indvSeqNum);
		appRgstCargo.setHshl_email_adr(caseIndv.getEmailAddress());
		appRgstCargo.setEmail_receipt(caseIndv.getEmailAddress());
		//Set Update Date
		Timestamp currentTimeStamp = new Timestamp(new Date().getTime());
		appRgstCargo.setUpdate_dt(currentTimeStamp);
		if (Objects.nonNull(caseIndv.getHomePhoneNumber())) {
			ext = caseIndv.getHomePhoneNumber().getExtension() != null ? caseIndv.getHomePhoneNumber().getExtension() : HouseHoldDemoGraphicsConstants.EMPTY;
			phnNum = caseIndv.getHomePhoneNumber().getNumber() != null ? caseIndv.getHomePhoneNumber().getNumber() : HouseHoldDemoGraphicsConstants.EMPTY;
			appRgstCargo.setHshl_home_phn_num(ext + phnNum);
		}
		
		if (HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(mode)) {
			processCellWrkPhoneNum(caseIndv, appRgstCargo);
		} else {
			if (Objects.nonNull(caseIndv.getCellPhoneNumber())) {
				ext = caseIndv.getCellPhoneNumber().getExtension() != null ? caseIndv.getCellPhoneNumber().getExtension() : HouseHoldDemoGraphicsConstants.EMPTY;
				phnNum = caseIndv.getCellPhoneNumber().getNumber() != null ? caseIndv.getCellPhoneNumber().getNumber() : HouseHoldDemoGraphicsConstants.EMPTY;
				appRgstCargo.setHshl_work_phn_num(ext + phnNum);
				appRgstCargo.setPhonenum_receipt(ext + phnNum);
			}
		}
		
		if (Objects.nonNull(caseIndv.getHomeAddress())) {
			appRgstCargo.setHshl_l1_adr(caseIndv.getHomeAddress().getAddressLine());
			appRgstCargo.setHshl_city_adr(caseIndv.getHomeAddress().getCity());
			appRgstCargo.setHshl_sta_adr(caseIndv.getHomeAddress().getState());
			appRgstCargo.setHshl_zip_adr(caseIndv.getHomeAddress().getZipcode());
			if (HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(mode)) {
				appRgstCargo.setHshl_l2_adr(caseIndv.getHomeAddress().getApt());
			} else {
				appRgstCargo.setHshl_apt_num(caseIndv.getHomeAddress().getApt());
			}
		}else {
			//handling non nullable conatraint scenarios
			appRgstCargo.setHshl_city_adr(HouseHoldDemoGraphicsConstants.EMPTY);
			appRgstCargo.setHshl_sta_adr(HouseHoldDemoGraphicsConstants.EMPTY);
		}
		if (Objects.nonNull(caseIndv.getMailingAddressIfDifferent())) {
			appRgstCargo.setAlt_l1_adr(caseIndv.getMailingAddressIfDifferent().getAddressLine());
			appRgstCargo.setAlt_city_adr(caseIndv.getMailingAddressIfDifferent().getCity());
			appRgstCargo.setAlt_sta_adr(caseIndv.getMailingAddressIfDifferent().getState());
			appRgstCargo.setAlt_zip_adr(caseIndv.getMailingAddressIfDifferent().getZipcode());
			if (HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(mode)) {
				appRgstCargo.setAlt_l2_adr(caseIndv.getMailingAddressIfDifferent().getApt());
			} else {
				appRgstCargo.setAlt_apt_num(caseIndv.getMailingAddressIfDifferent().getApt());
			}
			appRgstCargo.setAlt_st_adr(caseIndv.getMailingAddressIfDifferent().getAddressLine());
		} else if (HouseHoldDemoGraphicsConstants.MC_MODE.equalsIgnoreCase(mode) && Objects.nonNull(caseIndv.getHomeAddress())) {
			appRgstCargo.setAlt_l1_adr(caseIndv.getHomeAddress().getAddressLine());
			appRgstCargo.setAlt_city_adr(caseIndv.getHomeAddress().getCity());
			appRgstCargo.setAlt_sta_adr(caseIndv.getHomeAddress().getState());
			appRgstCargo.setAlt_zip_adr(caseIndv.getHomeAddress().getZipcode());
			appRgstCargo.setAlt_l2_adr(caseIndv.getHomeAddress().getApt());
			appRgstCargo.setAlt_st_adr(caseIndv.getHomeAddress().getAddressLine());
		}
		return appRgstCargo;
	}

	private void processCellWrkPhoneNum(CaseIndividualDetails caseIndv, CP_APP_RGST_Cargo appRgstCargo) {
		if (Objects.nonNull(caseIndv.getCellPhoneNumber())) {
			ext = caseIndv.getCellPhoneNumber().getExtension() != null ? caseIndv.getCellPhoneNumber().getExtension() : HouseHoldDemoGraphicsConstants.EMPTY;
			phnNum = caseIndv.getCellPhoneNumber().getNumber() != null ? caseIndv.getCellPhoneNumber().getNumber() : HouseHoldDemoGraphicsConstants.EMPTY;
			appRgstCargo.setHshl_cell_phn_num(ext + phnNum);
			appRgstCargo.setPhonenum_receipt(ext + phnNum);
		}
		if (Objects.nonNull(caseIndv.getWorkPhoneNumber())) {
			ext = caseIndv.getWorkPhoneNumber().getExtension() != null ? caseIndv.getWorkPhoneNumber().getExtension() : HouseHoldDemoGraphicsConstants.EMPTY;
			phnNum = caseIndv.getWorkPhoneNumber().getNumber() != null ? caseIndv.getWorkPhoneNumber().getNumber() : HouseHoldDemoGraphicsConstants.EMPTY;
			appRgstCargo.setHshl_work_phn_num(ext + phnNum);
		}
	}

	/**
	 * Method to Update new App Number in CP_RMB_REQUEST table
	 * 
	 * @param pageCollection, appNum
	 * @return void
	 * @author ransahu
	 */
	private void updateAppNumInCpRmbRequest(final Map pageCollection, String appNum) {
		RMB_RQST_Collection existingRmbRqstCollection = Objects
				.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION))
						? (RMB_RQST_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION)
						: null;
		if (null != existingRmbRqstCollection && !existingRmbRqstCollection.isEmpty()) {
			RMB_RQST_Cargo rmbRqstCargo = existingRmbRqstCollection.getCargo(0);
			rmbRqstCargo.setSsp_app_num(Integer.parseInt(appNum));
			rmbRqstRepository.save(rmbRqstCargo);
			pageCollection.put(HouseHoldDemoGraphicsConstants.RMB_RQST_COLLECTION, existingRmbRqstCollection);
		}
	}

	/**
	 * Method to store data from Move in, Move out, SSI SSP and Change in income
	 * screen of Redetermination TNB4 flow
	 * 
	 * @param fwTransaction
	 * @return void
	 * @author ransahu
	 */
	private void saveTNB4RenewalFormData(FwTransaction fwTransaction) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.saveTNB4RenewalFormData() - START");

		try {
			final Map pageCollection = fwTransaction.getPageCollection();
			String appNum = fwTransaction.getUserDetails().getAppNumber();

			CpAppTnb4Redet_Collection cpAppTnb4RedetCollection = (CpAppTnb4Redet_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_APP_TNB4_REDET_COLLECTION);
			CpAppTnb4Redet_Cargo cpAppTnb4RedetCargo = cpAppTnb4RedetCollection.getCargo(0);

			cpAppTnb4RedetCargo.setAppNum(appNum);
			cpAppTnb4RedetCargo.setSrcAppInd(HouseHoldDemoGraphicsConstants.TNB4_TN);
			cpAppTnb4RedetCargo.setFormType(HouseHoldDemoGraphicsConstants.TNB4_TN);

			List<CpAppTnb4MoveoutSsiSsp_Cargo> moveOutSsiSspCargoList = new ArrayList<>();

			String[] moveOut = cpAppTnb4RedetCargo.getMoveOut();
			String[] ssiSsp = cpAppTnb4RedetCargo.getSsiSsp();

			setMoveOutSsiSspData(appNum, moveOut, HouseHoldDemoGraphicsConstants.MOVE_OUT, moveOutSsiSspCargoList);
			setMoveOutSsiSspData(appNum, ssiSsp, HouseHoldDemoGraphicsConstants.SSI_SSP, moveOutSsiSspCargoList);

			cpAppTnb4RedetCargo.setTnb4MoveoutssiSspList(moveOutSsiSspCargoList);

			cpAppTnb4RedetRepository.save(cpAppTnb4RedetCargo);

		} catch(Exception exception) {
			 
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"saveTNB4RenewalFormData", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.saveTNB4RenewalFormData() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);
	}

	/**
	 * Method to add data from moveOut/ssiSsp array to moveOutSsiSspCargoList
	 * 
	 * @param appNum, moveOutSsiSsp, indvType, moveOutSsiSspCargoList
	 * @return void
	 * @author ransahu
	 */
	private void setMoveOutSsiSspData(String appNum, String[] moveOutSsiSsp, String indvType,
			List<CpAppTnb4MoveoutSsiSsp_Cargo> moveOutSsiSspCargoList) {
		if (moveOutSsiSsp.length > 0) {
			for (String indvSeqNum : moveOutSsiSsp) {
				CpAppTnb4MoveoutSsiSsp_Cargo moveOutSsiSspCargo = new CpAppTnb4MoveoutSsiSsp_Cargo();
				Double moveOutIndvSeqNum = Double.parseDouble(indvSeqNum);
				moveOutSsiSspCargo.setIndvSeqNum(moveOutIndvSeqNum);
				moveOutSsiSspCargo.setAppNum(appNum);
				moveOutSsiSspCargo.setIndvType(indvType);
				moveOutSsiSspCargo.setSrcAppInd(HouseHoldDemoGraphicsConstants.TNB4_TN);
				moveOutSsiSspCargoList.add(moveOutSsiSspCargo);
			}
		}
	}

	/*
	 * Method for getting MC specific date to display on BWB screen in MC flow.
	 */
	private void loadMCSpecificDatesAndCaseNum(FwTransaction fwTransaction) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadMCSpecificDatesAndCaseNum() - START");

		try {
			getRMBFormDataAndClob(fwTransaction);
			getOffcTtyNum(fwTransaction);
		}  catch(Exception exception) {
			 
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadMCSpecificDatesAndCaseNum", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadMCSpecificDatesAndCaseNum() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);
	}

	/*
	 * Generating application data for MC flow.
	 */
	private void generateApplicationDataForMC(FwTransaction fwTransaction) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateApplicationDataForMC() - START");
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateApplicationDataForMC() - ***generateApplicationDataForMC START***");

		try {
			getRMBFormDataAndClob(fwTransaction);

			generateRMBApplicationData(fwTransaction);

			massageTNB4specificData(fwTransaction);

		} catch(Exception exception) {
			 
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"generateApplicationDataForMC", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateApplicationDataForMC() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);
	}

	/**
	 * As per CSPM-14666(Redetermination_MC210_Loading Your Info Service_Service).
	 * 
	 * @param fwTransaction as FwTransaction
	 * @return
	 */
	public void generateFormStatusReq(FwTransaction fwTransaction) {
		Map formStatusReqJson = null;
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateFormStsReqJsonForMC() - START");
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateFormStsReqJsonForMC() - ***generateFormStsReqJsonForMC START***");
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.generateFormStsReqJsonForMC() - processing getRMBFormDataAndClob...");
			getRMBFormDataAndClobForFinAndNonFin(fwTransaction);

			final Map pageCollection = fwTransaction.getPageCollection();

			CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = null != pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION)
							? (CpRmbRequestDetails_Collection) pageCollection
									.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION)
							: null;
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.generateFormStsReqJsonForMC() - cpRmbRequestDetailsCollection... ");

			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION,
					cpRmbRequestDetailsCollection);

		}catch(Exception exception) {
			 
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"generateFormStsReqJsonForMC", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.generateFormStsReqJsonForMC() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);
	}
	private void getOffcTtyNum(FwTransaction fwTransaction) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.getOffcTtyNum() - START");
		final Map pageCollection = fwTransaction.getPageCollection();

		try {
			CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = Objects
					.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION))
					? (CpRmbRequestDetails_Collection) pageCollection
							.get(HouseHoldDemoGraphicsConstants.CP_RMB_REQUEST_DETAILS_COLLECTION)
							: null;

			if (null != cpRmbRequestDetailsCollection && !cpRmbRequestDetailsCollection.isEmpty()) {

				CpRmbRequestDetails_Cargo cpRmbRequestDetailsCargo = (CpRmbRequestDetails_Cargo) cpRmbRequestDetailsCollection
						.get(0);

				Map formStatusReqJson = (Map) new ObjectMapper()
						.readValue(cpRmbRequestDetailsCargo.getForm_status_req(), Object.class);


				String offcNum = Objects.nonNull(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.OFFICE_NUM))
						? (String) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.OFFICE_NUM)
								: null;

				String telTypeNum = Objects.nonNull(formStatusReqJson.get(HouseHoldDemoGraphicsConstants.TELE_TYPE_NUM))
						? (String) formStatusReqJson.get(HouseHoldDemoGraphicsConstants.TELE_TYPE_NUM)
								: null;

				pageCollection.put(HouseHoldDemoGraphicsConstants.OFFICE_NUM, offcNum);
				pageCollection.put(HouseHoldDemoGraphicsConstants.TELE_TYPE_NUM, telTypeNum);

			}
		}catch (Exception e) {
			FwExceptionManager.handleException(e,this.getClass().getName(),
        			"getOffcTtyNum", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.getOffcTtyNum() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);
	}
	
	private void putPrimayPerAtFirstInList(List caseIndividuals, FwTransaction fwTransaction) {
		if (null != caseIndividuals && !caseIndividuals.isEmpty()) {
			ArrayList caseIndividualsPrimaryFirst = new ArrayList();
			for (Object caseIndividual : caseIndividuals) {
				/* Converting CaseIndividual JSON String to Java POJO */
				String caseIndividualString;
				try {
					caseIndividualString = new ObjectMapper().writeValueAsString(caseIndividual);
					CaseIndividualDetails caseIndv = new ObjectMapper().readValue(caseIndividualString,
							CaseIndividualDetails.class);
					if (Objects.nonNull(caseIndv.getPrimaryApplicant())
							&& caseIndv.getPrimaryApplicant().equals(HouseHoldDemoGraphicsConstants.Y)) {
						caseIndividualsPrimaryFirst.add(0, caseIndv);
					} else {
						caseIndividualsPrimaryFirst.add(caseIndv);
					}
				} catch (JsonProcessingException exception) {
					FwExceptionManager.handleException(exception,this.getClass().getName(),
		        			"putPrimayPerAtFirstInList", fwTransaction.getUserDetails().getAppNumber(),
		        			fwTransaction.getUserDetails().getLoginUserId(), true);
				}
				
			}
			caseIndividuals.clear();
			caseIndividuals.addAll(caseIndividualsPrimaryFirst);
		}
		
	}
}
