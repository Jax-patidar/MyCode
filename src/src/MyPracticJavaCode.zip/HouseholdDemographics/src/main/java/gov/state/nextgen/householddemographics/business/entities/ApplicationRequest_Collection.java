package gov.state.nextgen.householddemographics.business.entities;

/**
 * This class contains the collection of entities of CP_APP_AR_LG_CNTC
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class ApplicationRequest_Collection extends AbstractCollection  {

	private static final long serialVersionUID = 4537413576559576787L;

	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.ApplicationRequestCollection";
	
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final ApplicationRequest_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final ApplicationRequest_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final ApplicationRequest_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public ApplicationRequest_Cargo[] getResults() {
		final ApplicationRequest_Cargo[] cbArray = new ApplicationRequest_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public ApplicationRequest_Cargo getCargo(final int idx) {
		return (ApplicationRequest_Cargo) get(idx);
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof ApplicationRequest_Cargo[]) {
			final ApplicationRequest_Cargo[] cbArray = (ApplicationRequest_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
	
