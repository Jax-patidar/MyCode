package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseIndividualDetailsPassedAwayDetail implements Serializable {
	

	private static final long serialVersionUID = -3323278649520432068L;
	
	@JsonProperty("decesasedInd")
	private boolean deceasedInd;

	@JsonProperty("dateOfDeath")
	private Date dateOfDeath;
	
	@JsonProperty("deathExpl")
	private String deathExpl;

	public boolean isDeceasedInd() {
		return deceasedInd;
	}

	public void setDeceasedInd(boolean deceasedInd) {
		this.deceasedInd = deceasedInd;
	}

	public Date getDateOfDeath() {
		return dateOfDeath;
	}

	public void setDateOfDeath(Date dateOfDeath) {
		this.dateOfDeath = dateOfDeath;
	}

	public String getDeathExpl() {
		return deathExpl;
	}

	public void setDeathExpl(String deathExpl) {
		this.deathExpl = deathExpl;
	}
	
	
	
	
}
