/**
 * 
 */
package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;

/**
 * @author rudeshmukh
 *
 */
public class AppUserModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private String acsId;

	private String appNum;

	private String sbmtAcsId;


	public String getAcsId() {
		return acsId;
	}

	public void setAcsId(String acsId) {
		this.acsId = acsId;
	}

	public String getAppNum() {
		return appNum;
	}

	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}

	public String getSbmtAcsId() {
		return sbmtAcsId;
	}

	public void setSbmtAcsId(String sbmtAcsId) {
		this.sbmtAcsId = sbmtAcsId;
	}

}
