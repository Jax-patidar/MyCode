package gov.state.nextgen.householddemographics.business.services;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.framework.business.model.UserDetails;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_OUT_ST_BNFT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_SCHLE_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_PREG_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_SUPPORT_SERVICES_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_SUPPORT_SERVICES_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpUserSurveys_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpUserSurveys_Collection;
import gov.state.nextgen.householddemographics.business.rules.ABSupportServicesBO;
import gov.state.nextgen.householddemographics.business.rules.AFBHouseholdPregnancyBO;
import gov.state.nextgen.householddemographics.business.rules.AFBSchoolEnrollmentBO;
import gov.state.nextgen.householddemographics.business.rules.OutOfStateBenefitsBO;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CpUserSurveysRepository;

@SuppressWarnings("squid:S2229")
@Service("HouseHoldInfoService")
public class HouseHoldInfoServImpl implements HouseholdDemographicsService {

	@Autowired
	private OutOfStateBenefitsBO outOfStateBenefitsBO;

	@Autowired
	private AFBHouseholdPregnancyBO abprgObj;

	@Autowired
	private AFBSchoolEnrollmentBO schoolBO;
	
	@Autowired
    private ExceptionUtil exceptionUtil;

	// CSPM-1881
	@Autowired
	private ABSupportServicesBO supportServicesBo;
	
	@Autowired
	private CpUserSurveysRepository cpUserSurveysRepository;
	
	private static final String INDV_ID = "indvIds";
	

	
	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {
		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.GET_OUT_OF_STATE:
			this.getOutOfState(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_OUT_OF_STATE:
			this.storeOutOfState(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.DEL_GOV_AID:
			this.deleteGovernmentAid(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_HH_PREG_DET:
			this.storeHouseHoldPregnancyDetails(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.GET_HH_PREG_DET:
			this.getHouseHoldPregnancyDetails(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.DELETEPREGNANTDETAILS:
			this.deletePregnantDetails(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.LOADBREASTFEEDINGSUMMARYDETAILS:
			this.loadBreastFeedingSummaryDetails(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.DELETEBREASTFEEDINGDETAILS:
			this.deleteBreastFeedingDetails(fwTxn);
			break;
		// CSPM-1881
		case HouseHoldDemoGraphicsConstants.LOAD_SUPP_SER_DET:
			this.loadSupportServicesDetails(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_SUPP_SER_DET:
			this.storeSupportServicesDetails(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORE_SURVEYS:
			this.storeSurveys(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.GET_SURVEYS:
			this.getSurveys(fwTxn);
			break;	
		default:
		}
	}

	/**
	 * fetch surveys
	 * 
	 * @param fwTxn
	 */
	@Transactional
	private void getSurveys(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldInfoService.getSurveys() - START", fwTxn);
		try {

			Map pageCollection = fwTxn.getPageCollection();

			Integer appNum = Integer.parseInt(fwTxn.getUserDetails().getAppNumber());
			String pageId = fwTxn.getCurrentActionDetails().getPageId();
			
			pageCollection = new HashMap<>();
			
			CpUserSurveys_Cargo surveyCargo = cpUserSurveysRepository.findByAppNumPageId(appNum, pageId);
			CpUserSurveys_Collection surveyCollection = new CpUserSurveys_Collection();
			surveyCollection.add(surveyCargo);
			
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_USER_SURVEYS_COLLECTION, surveyCollection);
			fwTxn.setPageCollection(pageCollection);

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.getSurveys()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getSurveys", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldInfoService.getSurveys() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime), fwTxn );
	}

	/**
	 * store surveys
	 * 
	 * @param fwTxn
	 */
	@Transactional
	private void storeSurveys(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldInfoService.storeSurveys() - START", fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			Integer appNum = Integer.parseInt(fwTxn.getUserDetails().getAppNumber());
			String createUserId = Objects.nonNull(fwTxn.getUserDetails().getLoginUserId())
					?fwTxn.getUserDetails().getLoginUserId():"anonymous";
			String pageId = fwTxn.getCurrentActionDetails().getPageId();

			final CpUserSurveys_Collection surveyCollection = Objects.nonNull(pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_USER_SURVEYS_COLLECTION))
					?(CpUserSurveys_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_USER_SURVEYS_COLLECTION):null;
			CpUserSurveys_Cargo newSurveyCargo = Objects.nonNull(surveyCollection) && !surveyCollection.isEmpty()
					?surveyCollection.getCargo(0):null;

			CpUserSurveys_Cargo existingSurveyCargo = cpUserSurveysRepository.findByAppNumPageId(appNum, pageId);
			
			if(Objects.nonNull(existingSurveyCargo)) {
				if(Objects.nonNull(newSurveyCargo))
				{
					existingSurveyCargo.setSentimentCd(newSurveyCargo.getSentimentCd());
				}
				cpUserSurveysRepository.save(existingSurveyCargo);
			}else {
				if(Objects.nonNull(newSurveyCargo)) {
					newSurveyCargo.setAppNumber(appNum);
					newSurveyCargo.setPageId(pageId);
					newSurveyCargo.setCreateUserId(createUserId);
					newSurveyCargo.setCreateDt(LocalDateTime.now());
					cpUserSurveysRepository.save(newSurveyCargo);
				}
			}

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.storeSurveys()", fwTxn);
		 FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeSurveys", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldInfoService.storeSurveys() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	/**
	 * store out of state benefits details
	 * 
	 * @param fwTxn
	 */
	@Transactional
	public void storeOutOfState(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldInfoService.storeOutOfState() - START", fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			String appNum = fwTxn.getUserDetails().getAppNumber();
			String src_app_ind = AppConstants.AFB_SRC_APP_IND;

			final APP_IN_OUT_ST_BNFT_Collection appInCollReq = (APP_IN_OUT_ST_BNFT_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.APP_IN_OUT_ST_BNFT_COLL);
			APP_IN_OUT_ST_BNFT_Cargo cargoReq = appInCollReq.getCargo(0);
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());

			// the below will return a collection only if we have all the 3 values: appnum,
			// seqnum and indvseqnum. In case of a new records the seqnum
			// will come as null from the frontend. in case of edit we will have a seqnum
			// and get a record to update.
			final APP_IN_OUT_ST_BNFT_Collection appInOutStDBColl = outOfStateBenefitsBO
					.loadOutOfStateDetailsCurrent(appNum, indv_seq_num, seq_num);
			if (null != appInOutStDBColl && appInOutStDBColl.size() > 0) {
				APP_IN_OUT_ST_BNFT_Cargo cargo = appInOutStDBColl.getCargo();
				cargo.setCurr_rcv_out_of_st_bnft_ind(cargoReq.getCurr_rcv_out_of_st_bnft_ind());
				cargo.setOut_of_st_bnft_cd(
						null == cargoReq.getOut_of_st_bnft_cd() || (cargoReq.getOut_of_st_bnft_cd().isEmpty()) ? null
								: cargoReq.getOut_of_st_bnft_cd());
				cargo.setOut_of_st_bnft_sta_cd(
						null == cargoReq.getOut_of_st_bnft_sta_cd() || (cargoReq.getOut_of_st_bnft_sta_cd().isEmpty())
								? null
								: cargoReq.getOut_of_st_bnft_sta_cd());
				outOfStateBenefitsBO.storeStateBenefits(cargo);
			} else {
				cargoReq.setApp_num(appNum);
				cargoReq.setSrc_app_ind(src_app_ind);
				cargoReq.setIndv_seq_num(indv_seq_num);
				cargoReq.setSeq_num(seq_num);
				outOfStateBenefitsBO.storeStateBenefits(cargoReq);
			}

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.storeOutOfState()", fwTxn);
		 FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeOutOfState", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldInfoService.storeOutOfState() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	/**
	 * Gets the out of state benefits details
	 * 
	 * @param fwTxn
	 */
	@Transactional
	public void getOutOfState(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldInfoService.getOutOfState() - START", fwTxn);
		try {

			Map pageCollection = fwTxn.getPageCollection();

			final String appNum = fwTxn.getUserDetails().getAppNumber();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			pageCollection = new HashMap<>();
			final APP_IN_OUT_ST_BNFT_Collection outColl = (APP_IN_OUT_ST_BNFT_Collection) outOfStateBenefitsBO
					.loadIndividualOutOfStateDetails(appNum, indvIdList);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_OUT_ST_BNFT_COLL, outColl);
			fwTxn.setPageCollection(pageCollection);

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.getOutOfState()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getOutOfState", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldInfoService.getOutOfState() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime), fwTxn );
	}

	@Transactional
	public void deleteGovernmentAid(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldInfoServImpl.deleteGovernmentAid() - START", fwTxn);
		try {
		String appNum = fwTxn.getUserDetails().getAppNumber();
		Integer indivSeqNumInt = Integer.parseInt(
				fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
		Integer SeqNumInt = Integer
				.parseInt(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
		outOfStateBenefitsBO.deleteGovernmentAid(appNum, indivSeqNumInt, SeqNumInt);
		}catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.deleteGovernmentAid()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"deleteGovernmentAid", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseHoldInfoServImpl.deleteGovernmentAid() - END", fwTxn);
	}

	@Transactional
	public void storeHouseHoldPregnancyDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseHoldInfoServImpl.storeHouseHoldPregnancyDetails() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String pageId = fwTxn.getCurrentActionDetails().getPageId();
			int indvSeqNum = 0;
			if (Objects.nonNull(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			final String appNum = fwTxn.getUserDetails().getAppNumber();

			if (Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_PREG_COLLECTION))) {
				CP_APP_IN_PREG_Collection appInPregCollection = (CP_APP_IN_PREG_Collection) pageCollection
						.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_PREG_COLLECTION);
				CP_APP_IN_PREG_Cargo appInPregCargo = appInPregCollection.getCargo(0);

				appInPregCargo.setApp_num(appNum);
				appInPregCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
				appInPregCargo.setIndv_seq_num(indvSeqNum);
				abprgObj.storePregnancyDetailsInDb(appInPregCargo, appNum, indvSeqNum, AppConstants.AFB_SRC_APP_IND,
						pageId);
			}
		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.storeHouseHoldPregnancyDetails()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeHouseHoldPregnancyDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HouseHoldInfoServImpl.storeHouseHoldPregnancyDetails() - END", fwTxn);
	}

	@Transactional
	public void getHouseHoldPregnancyDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseHoldInfoServImpl.getHouseHoldPregnancyDetails() - START", fwTxn);
		try {
			CP_APP_IN_PREG_Collection appInPregCargoArray = null;
			APP_IN_SCHLE_Collection appInSchoolColl = null;
			CP_APP_IN_PREG_Cargo appInPregCargo = new CP_APP_IN_PREG_Cargo();

			Map pageCollection = fwTxn.getPageCollection();
			String appNum = fwTxn.getUserDetails().getAppNumber();
			appInPregCargo.setApp_num(appNum);
			appInPregCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			appInPregCargoArray = abprgObj.getAllPregnantList(appNum, AppConstants.SRC_APP_IND_AFB, indvIdList);
			if (Objects.nonNull(appInPregCargoArray)) {
				pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_IN_PREG_COLLECTION, appInPregCargoArray);
			}
			// School collection Added in response
			appInSchoolColl = schoolBO.getAllClgDetails(appNum, indvIdList);

			if (Objects.nonNull(appInSchoolColl)) {
				pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_SCHLE_COLLECTION, appInSchoolColl);
			}
		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.getHouseHoldPregnancyDetails()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"getHouseHoldPregnancyDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HouseHoldInfoServImpl.getHouseHoldPregnancyDetails() - END", fwTxn);
	}

	@Transactional
	public void deletePregnantDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseHoldInfoServImpl.deletePregnantDetails() - START", fwTxn);
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer indivSeqNumInt = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			CP_APP_IN_PREG_Collection appInPregBeforeColl = abprgObj.getPregnantDetails(appNum, AppConstants.SRC_APP_IND_AFB, indivSeqNumInt);
			if(appInPregBeforeColl.size() > 0){
				CP_APP_IN_PREG_Cargo appInPregBeforeCargo = appInPregBeforeColl.getCargo(0);
				appInPregBeforeCargo.setIs_pregnant(null);
				appInPregBeforeCargo.setPreg_due_dt(null);
				appInPregBeforeCargo.setBaby_ct(null);
				appInPregBeforeCargo.setPresump_elig_card_ind(null);
				appInPregBeforeCargo.setEnrl_stat_cd(null);
				appInPregBeforeCargo.setNt_enrl_stat_desc(null);
				appInPregBeforeCargo.setChg_eff_dt(null);
				abprgObj.savePregData(appInPregBeforeCargo);
			}
		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.deletePregnantDetails()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"deletePregnantDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HouseHoldInfoServImpl.deletePregnantDetails() - END", fwTxn);
	}

	/**
	 * deleteBreastFeedingDetails is to delete the breast feeding records from DB .
	 *
	 * @param fwTxn the txn object
	 */
	@Transactional
	public void deleteBreastFeedingDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO, "HouseHoldInfoServImpl.deleteBreastFeedingDetails() - START", fwTxn);
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer indvSeqNumber = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			abprgObj.deleteBreastFeedingDetails(appNum, indvSeqNumber);
		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.deleteBreastFeedingDetails()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"deleteBreastFeedingDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HouseHoldInfoServImpl.deleteBreastFeedingDetails() - END", fwTxn);
	}

	/**
	 * Load breast feeding collection for the Summary onPageLoad()
	 * 
	 * @param fwTransaction
	 */
	@Transactional
	public void loadBreastFeedingSummaryDetails(final FwTransaction fwTransaction) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "HouseHoldInfoServImpl.loadBreastFeedingSummaryDetails() - START", fwTransaction);
		try {
			String appNum = fwTransaction.getUserDetails().getAppNumber();
			Map pageCollection = fwTransaction.getPageCollection();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			CP_APP_IN_PREG_Collection appInPregSummaryCollection = abprgObj.getNonNullBreastFeedingDetails(appNum,
					AppConstants.SRC_APP_IND_AFB, indvIdList);
			if (Objects.nonNull(appInPregSummaryCollection)) {
				CP_APP_IN_PREG_Collection uiCollection = new CP_APP_IN_PREG_Collection();
				for (CP_APP_IN_PREG_Cargo app_in_preg_cargo : appInPregSummaryCollection.getResults()) {
					uiCollection.add(app_in_preg_cargo);
				}
				pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_IN_PREG_COLLECTION,
						ArrayUtils.isNotEmpty(uiCollection.getResults()) ? uiCollection : appInPregSummaryCollection);
			}

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.loadBreastFeedingSummaryDetails()", fwTransaction);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadBreastFeedingSummaryDetails", fwTransaction.getUserDetails().getAppNumber(),
        			fwTransaction.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldInfoService.loadBreastFeedingSummaryDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTransaction );
	}

	// CSPM - 1881 LOAD METHOD FOR SUPPORT SERVICES
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadSupportServicesDetails(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldInfoServiceImpl.loadSupportServicesDetails() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appnum = userDetails.getAppNumber();

			CP_APP_SUPPORT_SERVICES_Collection supportServiceColl = supportServicesBo
					.fetchSupportServicesDetails(appnum);
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_SUPPORT_SERVICES_COLL, supportServiceColl);

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.storeOutOfState()", txnBean);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"loadSupportServicesDetails", txnBean.getUserDetails().getAppNumber(),
        			txnBean.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldInfoServiceImpl.loadSupportServicesDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), txnBean);
	}

	/*
	 * CSPM- 1881 STORE SUPPORT PROGRAMS OPTED FOR
	 */
	@Transactional
	public void storeSupportServicesDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldInfoServiceImpl.storeSupportServicesDetails() - START", fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			String appNum = fwTxn.getUserDetails().getAppNumber();
			CP_APP_SUPPORT_SERVICES_Cargo supportServiceCargo = null;
			CP_APP_SUPPORT_SERVICES_Collection supportServiceColl = new CP_APP_SUPPORT_SERVICES_Collection();
			CP_APP_SUPPORT_SERVICES_Collection supServiceColl = (CP_APP_SUPPORT_SERVICES_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_APP_SUPPORT_SERVICES_COLL);

			if (Objects.nonNull(supServiceColl) && !supServiceColl.isEmpty()) {
				supportServiceCargo = supServiceColl.getCargo(0);

				supportServiceCargo.setApp_num(appNum);

				supportServiceColl.addCargo(supportServiceCargo);
				if (!ArrayUtils.isEmpty(supportServiceColl.getResults())) {
					supportServicesBo.saveSupportServicesDetails(supportServiceColl);
				}
			}

		} catch(Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseHoldInfoServImpl.storeSupportServicesDetails()", fwTxn);
        	FwExceptionManager.handleException(exception,this.getClass().getName(),
        			"storeSupportServicesDetails", fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseHoldInfoServiceImpl.storeSupportServicesDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);
	}
}
