package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 *
 */
public class APP_IN_TAX_RETURNS_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_IN_TAX_RETURNS";

	/**
	 *returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 *Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_TAX_RETURNS_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 *Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_TAX_RETURNS_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 *Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_TAX_RETURNS_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 *returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_TAX_RETURNS_Cargo[] getResults() {
		final APP_IN_TAX_RETURNS_Cargo[] cbArray = new APP_IN_TAX_RETURNS_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 *returns a cargo from the Collection for the given index.
	 */
	public APP_IN_TAX_RETURNS_Cargo getCargo(final int idx) {
		return (APP_IN_TAX_RETURNS_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_TAX_RETURNS_Cargo[] cloneResults() {
		final APP_IN_TAX_RETURNS_Cargo[] rescargo = new APP_IN_TAX_RETURNS_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_TAX_RETURNS_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_TAX_RETURNS_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setFile_tax_jointly_ind(cargo.getFile_tax_jointly_ind());
			rescargo[i].setTax_dependent_resp(cargo.getTax_dependent_resp());
			rescargo[i].setTax_dependent_claim_ind(cargo.getTax_dependent_claim_ind());
			rescargo[i].setTax_dependent_claim_seq_num(cargo.getTax_dependent_claim_seq_num());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_TAX_RETURNS_Cargo[]) {
			final APP_IN_TAX_RETURNS_Cargo[] cbArray = (APP_IN_TAX_RETURNS_Cargo[]) obj;
			setResults(cbArray);
		}
	}

	public APP_IN_TAX_RETURNS_Cargo getResult(final int idx) {
		return (APP_IN_TAX_RETURNS_Cargo) get(idx);
	}
}
