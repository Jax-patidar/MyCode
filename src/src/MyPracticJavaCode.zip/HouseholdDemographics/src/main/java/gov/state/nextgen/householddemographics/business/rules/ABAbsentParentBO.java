package gov.state.nextgen.householddemographics.business.rules;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.util.IndividualAge;
import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_ABS_PRNT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_ABSNP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_ABSNP_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAbsPrntRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInAbsnpRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppInPrflRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;
import gov.state.nextgen.householddemographics.model.IndivTypeSeqBean;

@Service("ABAbsentParentBO")
public class ABAbsentParentBO extends AbstractBO{
	

	
	@Autowired
	private HouseholdRelationshipRepo householdRelationshipRepo;
	
	@Autowired
	private CpAppIndvRepository cpAppIndvRepository;
	
	
	
	@Autowired
	CpAbsPrntRepository cpAbsPrntRepository;
	
	CpAppInAbsnpRepository cpAppInAbsnpRepository;
	
	CpAppInPrflRepository cpAppInPrflRepository;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List getNewAbsentParentList(final PeopleHandler peopleHandler,
			final String appNumber,APP_IN_PRFL_Collection sesAppInPrflColl, short[] programKey) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,  "AbsentParentBO.getNewAbsentParentList() - START");

        boolean maFlag = false;
        boolean childFlag = false;
        boolean tanFlag = false;
        boolean wcFlag = false;
        boolean snapFlag = false;
        boolean tanfOnly = false;
        boolean maOnly = false;
        boolean maOrTanf = false;
        if (isThisProgramRequested(programKey,
                FwConstants.CC_INDEX)) {
            childFlag = true;
        }
        if (isThisProgramRequested(programKey,
                FwConstants.WIC_INDEX)) {
            wcFlag = true;
        }
        if (isThisProgramRequested(programKey,
                FwConstants.FMA_INDEX)) {
            maFlag = true;
        }
        if (isThisProgramRequested(programKey,
                FwConstants.TANF_INDEX)) {
            tanFlag = true;
        }
        if (isThisProgramRequested(programKey,
                FwConstants.FS_INDEX)) {
            snapFlag = true;
        }
        if(tanFlag && !wcFlag && !maFlag && !childFlag && !snapFlag)
            tanfOnly = true;
        if(maFlag && !tanFlag && !wcFlag && !childFlag && !snapFlag)
            maOnly = true;
        if(maFlag || tanFlag)
            maOrTanf = true;
		
		INDIVIDUAL_Custom_Collection indvSortedCustColl = null;
		APP_HSHL_RLT_Collection appHshlRltColl = null;
		APP_HSHL_RLT_Cargo appHshlRltCargo = null;
		final List fatherMotherList = new ArrayList();

		try {
			// first i am loading all absent parent infomation
			// as well as i am setting current record index
			indvSortedCustColl = peopleHandler
					.sortIndividualsByAge(peopleHandler.getAllIndividuals());

			final int indvSortedCustCollSize = indvSortedCustColl.size();
			int appHshlRltCollSize = 0;

			String individualSeqNum = null;
			IndividualAge indvAge = null;
			boolean fatherRelationFound = false;
			boolean motherRelationFound = false;
			boolean absentFatherFound = false;
			boolean absentMotherFound = false;
			int existingUnknownAbsParent = 0;

			for (int index = 0; index < indvSortedCustCollSize; index++) {
				individualSeqNum = indvSortedCustColl.getResult(index)
						.getIndv_seq_num();
				indvAge = indvSortedCustColl.getResult(index).getIndv_age();
				fatherRelationFound = false;
				motherRelationFound = false;
				absentFatherFound = false;
				absentMotherFound = false;
				existingUnknownAbsParent = 0;
				int parentSize = 0;

				if (indvAge.getYears() < 18
						&& !checkMarried(appNumber, individualSeqNum)) {
				    //No AP screen if PI is 18 or above
				    if("1".equalsIgnoreCase(individualSeqNum))
				        continue;
				    Integer motherIndivId = 0;
				    
					// Find parents relationships
					appHshlRltColl = checkFatherMotherRelation(appNumber,
							individualSeqNum);

					// Check for Mother/Father Relationships
					if (appHshlRltColl != null) {
						appHshlRltCollSize = appHshlRltColl.size();

						for (int j = 0; j < appHshlRltCollSize; j++) {
							appHshlRltCargo = appHshlRltColl.getCargo(j);

							if (null!=appHshlRltCargo.getRef_indv_seq_num() && appHshlRltCargo.getRef_indv_seq_num().toString().trim().equals(
									individualSeqNum)) {
								if ("FTR".equals(appHshlRltCargo.getRlt_cd())) {
									fatherRelationFound = true;
									parentSize +=1;
								} else if ("MTR".equals(appHshlRltCargo
										.getRlt_cd())) {
									motherRelationFound = true;
									motherIndivId = appHshlRltCargo.getSrc_indv_seq_num();
									parentSize+=1;
								}
							} else if (null!=appHshlRltCargo.getSrc_indv_seq_num() && appHshlRltCargo.getSrc_indv_seq_num().toString().trim()
									.equals(individualSeqNum)) {
								if ("SON".equals(appHshlRltCargo.getRlt_cd())
										|| "DAU".equals(appHshlRltCargo
												.getRlt_cd())) {
									final INDIVIDUAL_Custom_Cargo indvCargo = peopleHandler
											.getIndividual(String.valueOf(appHshlRltCargo
													.getRef_indv_seq_num()));
									if (indvCargo != null
											&& indvCargo.getSex_ind() != null
											&& "M".equals(indvCargo
													.getSex_ind())) {
										fatherRelationFound = true;
										parentSize+=1;
									} else {
										motherRelationFound = true;
										motherIndivId = appHshlRltCargo.getRef_indv_seq_num();
										parentSize+=1;
									}
								}
							}

						}
					}
					//MA or TANF program specific conditions.
					if(maOrTanf){
					    //if minor parent's child excluded from TANF application - no AP screen for child
					    if((motherRelationFound || fatherRelationFound) && tanfOnly && isChildExTANF(individualSeqNum, sesAppInPrflColl))
					        continue;
					    //skip if the individual is parent.
					    if(isParent(appNumber,individualSeqNum))
                            continue;
					    //MA program only specific conditions
					    if(maOnly){
					        //minor female with a child - no AP screen for the child
					        //Pregnant Minor - no AP screen
					        if(isPregnant())
					            continue;
					    }
					}

					existingUnknownAbsParent = absentParentCount(appNumber,
							individualSeqNum, AppConstants.SEX_IND_UNKNOWN);
					
					int absentParentCountDB = absentParentCount(appNumber,individualSeqNum);
					
					//number of parent relationships needed
					int absentParentSize = 2-(parentSize + existingUnknownAbsParent + absentParentCountDB );
					//if parents on application are less than 2 add the difference number of idivTypeseq beans to the list.
					
					if(absentParentSize != 0){
						for(int i =0; i <absentParentSize; i++){
							fatherMotherList.add(new IndivTypeSeqBean(
									individualSeqNum, AppConstants.ABS_UNKNOWN,
									FwConstants.EMPTY_STRING));
						}
					}else{
						String sex_ind = null;
						APP_ABS_PRNT_Collection existingAbsentParents = loadAbsentParentDetails(appNumber, individualSeqNum);
						if(existingAbsentParents !=null && existingAbsentParents.size()>0){
						 for(int i=0; i<existingAbsentParents.size(); i++){
							 APP_ABS_PRNT_Cargo parentCargo = existingAbsentParents.getCargo(i);
							 if(parentCargo.getApSexInd().equals(AppConstants.SEX_IND_MALE)){
								 sex_ind = AppConstants.ABS_FATHER;
							 } else if(parentCargo.getApSexInd().equals(AppConstants.SEX_IND_FEMALE)){
								 sex_ind = AppConstants.ABS_MOTHER;
							 }
							 
							 fatherMotherList.add(new IndivTypeSeqBean(
										individualSeqNum,
										sex_ind,
										String.valueOf(parentCargo.getApSeqNum())));
						 }
						}
						
					}

				}
			}


			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"AbsentParentBO.getNewAbsentParentList() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + " milliseconds");
			return fatherMotherList;

		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(),
					"getNewAbsentParentList", e);
		}
	}
	
	public boolean isThisProgramRequested(final short[] prgKey, final short progInd) {
		boolean programRequested = false;
		if (prgKey[progInd] == 1) {
			programRequested = true;
		}
		return programRequested;
	}
	
	/**
	 * Method description here
	 */
	public boolean checkMarried(final String appNumber,
			final String indvSeqNumber) {

		final long startTime = System.currentTimeMillis();

		boolean marriedFlag = false;
		try {

			
			final List<CP_APP_HSHL_RLT_Cargo> cargoList = householdRelationshipRepo.findByAppNumAndSrcIndvSeqNumAndRefIndvSeqNum(Integer.parseInt(appNumber), indvSeqNumber,
					indvSeqNumber);
			if (!cargoList.isEmpty()) {
				for (CP_APP_HSHL_RLT_Cargo cargo : cargoList) {
					if ("HUS".equals(cargo.getRltCd())
							|| "WIF".equals(cargo.getRltCd())) {
						marriedFlag = true;
						break;
					}
				}
			}
			//VY checking the indiv table.
			if(!marriedFlag){


				List<APP_INDV_Cargo> indvCargoList  = cpAppIndvRepository.findByAppNumIndvSeqNum(Integer.parseInt(appNumber), Integer.valueOf(indvSeqNumber));
				for(APP_INDV_Cargo cargo : indvCargoList){
		            if(("MA").equalsIgnoreCase(cargo.getMrtl_stat_cd()))
		                marriedFlag = true;
		        }
		    
			}
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(),
					"checkMarried", e);
		}


		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABAbsentParentBO.checkMarried() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime) + " milliseconds");
		return marriedFlag;
	}
	
	/**
	 * Method description here
	 */
	public APP_HSHL_RLT_Collection checkFatherMotherRelation(
			final String appNumber, final String indvSeqNumber) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABAbsentParentBO.checkFatherMotherRelation() - START");
		APP_HSHL_RLT_Collection appHshlRltCollection = new APP_HSHL_RLT_Collection();
		try {

			
			List<CP_APP_HSHL_RLT_Cargo> cargoList = householdRelationshipRepo.findByAppNumAndRefIndvSeqNum(Integer.parseInt(appNumber),  indvSeqNumber);

			
			if (!cargoList.isEmpty()) {
				List<APP_HSHL_RLT_Cargo> hshlCargoList = new ArrayList<APP_HSHL_RLT_Cargo>();
				APP_HSHL_RLT_Cargo appHshlRltCargo = null;
				for (CP_APP_HSHL_RLT_Cargo cargo : cargoList) {
					appHshlRltCargo = new APP_HSHL_RLT_Cargo();
					appHshlRltCargo.setApp_num(cargo.getApp_num());
					appHshlRltCargo.setRef_indv_seq_num(cargo.getRefIndvSeqNum());
					appHshlRltCargo.setSrc_indv_seq_num(cargo.getSrcIndvSeqNum());
					appHshlRltCargo.setCare_resp(cargo.getCare_resp());
					appHshlRltCargo.setRec_cplt_ind(String.valueOf(cargo.getRec_cplt_ind()));
					appHshlRltCargo.setRlt_cd(cargo.getRltCd());
					hshlCargoList.add(appHshlRltCargo);
				}
				appHshlRltCollection.clear();
				appHshlRltCollection.setResults(hshlCargoList.toArray(new APP_HSHL_RLT_Cargo[hshlCargoList.size()]));
			}
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(),
					"checkFatherMotherRelation", e);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABAbsentParentBO.checkFatherMotherRelation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + " milliseconds");
		return appHshlRltCollection;
	}
	
	private boolean isChildExTANF(String individualSeqNum,final APP_IN_PRFL_Collection appInPrflColl) {
		APP_IN_PRFL_Cargo PrflCargo = getAppInProfile(individualSeqNum, appInPrflColl);
        int tanfReq =  PrflCargo.getIndv_tanf_rqst_ind();
        return 1==tanfReq ? true:false;
    }

	private APP_IN_PRFL_Cargo getAppInProfile(String individualSeqNum, APP_IN_PRFL_Collection appInPrflColl) {
		try {
			final int appInPrflCollSize = appInPrflColl.size();
			for (int i = 0; i < appInPrflCollSize; i++) {
				final APP_IN_PRFL_Cargo appInPrflCargo = (APP_IN_PRFL_Cargo) appInPrflColl.get(i);
				if ((appInPrflCargo.getIndv_seq_num()).toString().equals(individualSeqNum)) {
					return appInPrflCargo;
				}
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ApplicationManager.getAppInProfile() - Raising FwException manually on a condition");
			final FwException fe = new FwException("Data not found for the given IndvSeqNum : " + individualSeqNum);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID("getAppInProfile");
			fe.setExceptionType(FwConstants.EXP_TYP_APPLICATION);
			fe.setExceptionText("Data not found for the given IndvSeqNum : " + individualSeqNum);
			throw fe;
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(), "getAppInProfile", e);
		}
	}
	
	public boolean isParent(String appNumber, String indvSeqNumber){
	    boolean parent = false;
	    

	    
	    List<CP_APP_HSHL_RLT_Cargo>  cargoList = householdRelationshipRepo.findByAppNumAndSrcIndvSeqNumAndRefIndvSeqNum(Integer.parseInt(appNumber), indvSeqNumber, indvSeqNumber);

        if (cargoList.isEmpty()) {
            for (CP_APP_HSHL_RLT_Cargo cargo : cargoList) {
                Integer srcIndv = cargo.getSrcIndvSeqNum();

                if(null!=srcIndv && srcIndv.toString().trim().equals(indvSeqNumber)){
                    if ("FTR".equals(cargo.getRltCd())
                            || "MTR".equals(cargo.getRltCd())
                            ) {
                        parent = true;
                        break;
                    }
                }else{
                    if("DAU".equals(cargo.getRltCd())
                            || "SON".equals(cargo.getRltCd())){
                        parent = true;
                        break;
                    }
                }
            }
        }
        return parent;
	}
	
	private boolean isPregnant() {
		return false;
	}
	
	private int absentParentCount(final String appNumber,
			final String indvSeqNumber, final String apSexInd) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABAbsentParentBO.absentFatherExists() - START");
		int absParentsCount = 0;
		APP_IN_ABSNP_Collection appInAbsnpCollection = new APP_IN_ABSNP_Collection();
		try {
			
			List<APP_IN_ABSNP_Cargo> cargoList = cpAppInAbsnpRepository.findByAppNumIndvSeqNum(appNumber,
					Double.valueOf(indvSeqNumber));
			if (!cargoList.isEmpty()) {
				appInAbsnpCollection.setResults(cargoList.toArray(new APP_IN_ABSNP_Cargo[cargoList.size()]));

				final int appInAbsCollSize = appInAbsnpCollection.size();

				for (int i = 0; i < appInAbsCollSize; i++) {

					List<APP_ABS_PRNT_Cargo> absPrntCargoList = cpAbsPrntRepository.findByAppNumAndApSexInd(Integer.parseInt(appNumber),
							apSexInd);
					if (!absPrntCargoList.isEmpty()) {
						final List<Double> seqNumList = new ArrayList<>();

						for (APP_ABS_PRNT_Cargo cargo : absPrntCargoList) {
							if (!seqNumList.contains(cargo.getApSeqNum())) {
								absParentsCount++;
								seqNumList.add(cargo.getApSeqNum());
							}
						}
					}
				}

				return absParentsCount;
			}
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(),
					"absentFatherExists", e);
		}

		return absParentsCount;
	}
	
	private int absentParentCount(final String appNumber,
			final String indvSeqNumber) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,  "ABAbsentParentBO.absentFatherExists() - START");

		int absParentsCount = 0;
			
		List<APP_IN_ABSNP_Cargo> cargoList = cpAppInAbsnpRepository.findByAppNumIndvSeqNum(appNumber,
				Double.valueOf(indvSeqNumber));
		if(!cargoList.isEmpty()) {
			absParentsCount =  cargoList.size();
		}

		

		return absParentsCount;
	}
	
	@SuppressWarnings("unchecked")
	public APP_ABS_PRNT_Collection loadAbsentParentDetails(final String appNumber, final String indvSeqNumber) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AbsentParentBO.loadAbsentParentDetails() - START");
		APP_IN_ABSNP_Collection appInAbsnpCollection = new APP_IN_ABSNP_Collection();
		APP_ABS_PRNT_Collection appAbsPrntCollection = new APP_ABS_PRNT_Collection();
		try {

			
			List<APP_IN_ABSNP_Cargo> cargoList = cpAppInAbsnpRepository.findByAppNumIndvSeqNum(appNumber,
					Double.valueOf(indvSeqNumber));
			if (!cargoList.isEmpty()) {
				appInAbsnpCollection.setResults(cargoList.toArray(new APP_IN_ABSNP_Cargo[cargoList.size()]));

				for (APP_IN_ABSNP_Cargo cargo : cargoList) {
					List<APP_ABS_PRNT_Cargo> absPrntCargoList = cpAbsPrntRepository
							.findByAppNumAndApSeqNumAndSrcAppInd(Integer.parseInt(appNumber), cargo.getApSeqNum(), AppConstants.AFB_SRC_APP_IND);
					if (!absPrntCargoList.isEmpty()) {
						appAbsPrntCollection.addCargo(absPrntCargoList.get(0));
					}
				}
			}
			return appAbsPrntCollection;
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(), "loadAbsentParentDetails", e);
		}
	}
	
	public APP_IN_PRFL_Collection getAppInPrflCollection(String appNum) {
		List<APP_IN_PRFL_Cargo> cargoList = cpAppInPrflRepository.findByAppNum(appNum);
		APP_IN_PRFL_Collection appInPrflCollection = new APP_IN_PRFL_Collection();
		appInPrflCollection.setResults(cargoList.toArray(new APP_IN_PRFL_Cargo[cargoList.size()]));
		return appInPrflCollection;
	}
	
	public List<IndivTypeSeqBean> loadAbsentParentDB(final String appNumber) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABAbsentParentBO.absentFatherExists() - START");
		final List<IndivTypeSeqBean> fatherMotherList = new ArrayList<>();

		try {
			List<APP_IN_ABSNP_Cargo>  appInAbsnpCargoList = cpAppInAbsnpRepository.findByAppNum(appNumber);
			if(!appInAbsnpCargoList.isEmpty()) {
				for(APP_IN_ABSNP_Cargo cargo : appInAbsnpCargoList) {
					fatherMotherList.add(new IndivTypeSeqBean(String.valueOf(cargo.getIndvSeqNum()), AppConstants.ABS_UNKNOWN,
							String.valueOf(cargo.getApSeqNum())));
				}
			}
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(), "absentFatherExists", e);
		}
		return fatherMotherList;
	}
	
	@SuppressWarnings("unchecked")
	public Map loadAbsentParentDetailsPageCollection(final String appNumber, final String indvSeqNumber,
			final String seqNumber, final String absInd) {
		final long startTime = System.currentTimeMillis();
		final Map<String, Object> pageCollection = new HashMap<>();
		String apSexInd = null;
		List<APP_IN_ABSNP_Cargo> cargoList = null;

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AbsentParentBO.loadAbsentParentDetailsPageCollectionAFB() - START");
		APP_IN_ABSNP_Collection appInAbsnpCollection = new APP_IN_ABSNP_Collection();
		APP_ABS_PRNT_Collection appAbsPrntCollection = new APP_ABS_PRNT_Collection();
		try {
			// ABS Indicator
			if (AppConstants.ABS_FATHER.equals(absInd)) {
				apSexInd = AppConstants.SEX_IND_MALE;
			} else if (AppConstants.ABS_MOTHER.equals(absInd) || AppConstants.PREG_MOTHER.equals(absInd)) {
				apSexInd = AppConstants.SEX_IND_FEMALE;
			} else if (AppConstants.ABS_UNKNOWN.equals(absInd)) {
				apSexInd = AppConstants.SEX_IND_UNKNOWN;
			} else {
				apSexInd = AppConstants.SEX_IND_UNKNOWN;
			}


			
			if(null != seqNumber && !seqNumber.isEmpty()) {
				cargoList = cpAppInAbsnpRepository.findByAppNumIndvSeqNumSeqNum(appNumber, Double.valueOf(indvSeqNumber), Double.valueOf(seqNumber));
			}

			// If Master records found search for RM, CW, RN Records in that
			// order
			if (Objects.nonNull(cargoList)&& !cargoList.isEmpty()) {
				appInAbsnpCollection.setResults(cargoList.toArray(new APP_IN_ABSNP_Cargo[cargoList.size()]));
				for (APP_IN_ABSNP_Cargo cargo : cargoList) {
					List<APP_ABS_PRNT_Cargo> absPrntCargoList = cpAbsPrntRepository.findByAppNumAndApSeqNumAndSrcAppInd(
							Integer.parseInt(appNumber), cargo.getApSeqNum(), AppConstants.AFB_SRC_APP_IND);

					if (!absPrntCargoList.isEmpty()) {
						appAbsPrntCollection
								.setResults(absPrntCargoList.toArray(new APP_ABS_PRNT_Cargo[absPrntCargoList.size()]));
					}
				}

				if (Objects.nonNull(appAbsPrntCollection) || appAbsPrntCollection.isEmpty()) {
					// New Detail AB Record
					appAbsPrntCollection = new APP_ABS_PRNT_Collection();
					final APP_ABS_PRNT_Cargo appAbsPrntCargo = new APP_ABS_PRNT_Cargo();
					appAbsPrntCargo.setSrcAppInd(AppConstants.AFB_SRC_APP_IND);
					appAbsPrntCargo.setAppNum(appNumber);
					// ABS Indicator
					appAbsPrntCargo.setApSexInd(apSexInd);
					appAbsPrntCollection.addCargo(appAbsPrntCargo);
				}
			} else {
				// New Detail AB Record
				final APP_ABS_PRNT_Cargo appAbsPrntCargo = new APP_ABS_PRNT_Cargo();
				appAbsPrntCargo.setSrcAppInd(AppConstants.AFB_SRC_APP_IND);
				appAbsPrntCargo.setAppNum(appNumber);
				// ABS Indicator
				appAbsPrntCargo.setApSexInd(apSexInd);

				// New Master AB Record
				final APP_IN_ABSNP_Cargo appInAbsnp = new APP_IN_ABSNP_Cargo();
				appInAbsnp.setAppNum(appNumber);
				appInAbsnp.setIndvSeqNum(Double.valueOf(indvSeqNumber));

				// New Master-Detail Collection
				appAbsPrntCollection = new APP_ABS_PRNT_Collection();
				appInAbsnpCollection = new APP_IN_ABSNP_Collection();

				// Add New Cargos into Collections
				appAbsPrntCollection.addCargo(appAbsPrntCargo);
				appInAbsnpCollection.addCargo(appInAbsnp);
			}
			
			// Set Collections into Page Collection
			pageCollection.put("APP_IN_ABSNP_Collection", appAbsPrntCollection);
			pageCollection.put("APP_ABS_PRNT_Collection", appAbsPrntCollection);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AbsentParentBO.loadAbsentParentDetailsPageCollectionAFB() - END , Time Taken : "
					+ (System.currentTimeMillis() - startTime) + " milliseconds");

			return pageCollection;
		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(), "loadAbsentParentDetailsPageCollectionAFB", e);
		}
	}

	public void deletePeopleSummary(String appNum, Integer indivSeqNum) {
		final long startTime = System.currentTimeMillis();
		try {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AbsentParentBO.deletePeopleSummary() - START");
			householdRelationshipRepo.deleteHHRelations(Integer.parseInt(appNum), indivSeqNum);
			cpAbsPrntRepository.deletePrntDetails(Integer.parseInt(appNum), Double.valueOf(indivSeqNum));
			cpAppIndvRepository.deleteNonPrimApplicat(Integer.parseInt(appNum), indivSeqNum);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AbsentParentBO.deletePeopleSummary() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime) + " milliseconds");
		}
		catch (final Exception e) {
			throw e;
		}
	}
}
