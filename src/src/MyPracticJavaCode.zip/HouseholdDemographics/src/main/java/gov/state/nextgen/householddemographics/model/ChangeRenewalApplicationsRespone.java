/**
 * 
 */
package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author rudeshmukh
 *
 */
@Component
@Scope("prototype")
public class ChangeRenewalApplicationsRespone extends OngoingApplicationsResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private String formType;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate formDueDate;
	private String caseNumber;
	private Long rmbRequestId;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate viewEndDate;
	private List<String> programList;

	public List<String> getProgramList() {
		return programList;
	}

	public void setProgramList(List<String> programList) {
		this.programList = programList;
	}

	public String getFormType() {
		return formType;
	}

	public void setFormType(String formType) {
		this.formType = formType;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public LocalDate getFormDueDate() {
		return formDueDate;
	}

	public void setFormDueDate(LocalDate formDueDate) {
		this.formDueDate = formDueDate;
	}

	
	public Long getRmbRequestId() {
		return rmbRequestId;
	}

	public void setRmbRequestId(Long rmbRequestId) {
		this.rmbRequestId = rmbRequestId;
	}

	
	public void setViewEndDate(LocalDateTime dueDate) {
		if(Objects.nonNull(dueDate)) {
			this.viewEndDate = dueDate.toLocalDate();
		}
		
	}

	public LocalDate getViewEndDate() {
		return viewEndDate;
	}

	public void setViewEndDate(LocalDate viewEndDate) {
		this.viewEndDate = viewEndDate;
	}

}
