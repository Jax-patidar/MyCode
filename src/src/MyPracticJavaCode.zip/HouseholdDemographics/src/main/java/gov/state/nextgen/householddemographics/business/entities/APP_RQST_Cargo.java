/*
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;



import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * This java bean contains the entities of APP_RQST
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Wed Oct 03 14:16:52 CDT 2007 Modified By: Modified on: PCR#
 */

@Entity
@Table(name="CP_APP_REQUEST")
@IdClass(APP_RQST_Key.class)
public class APP_RQST_Cargo extends AbstractCargo implements java.io.Serializable {

	/**
	 *
	 */
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	private static final long serialVersionUID = 1L;
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date app_cplt_tms;
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date app_strt_tms;
	@JsonFormat(pattern = "MM/dd/yyyy")
	@Column(name = "app_sbmt_tms")
	private Date appSbmtTms;
	private String app_stat_cd;
	private String file_dt_only_resp;
	private int hshl_indv_ct;
	private int ma_backdt_mo_1_ind;
	private int ma_backdt_mo_2_ind;
	private int ma_backdt_mo_3_ind;
	
	@UpdateTimestamp
	@Column(name="update_dt")
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date updt_dt;
	
	@CreationTimestamp
	@Column(name = "create_dt", updatable = false)
	private Timestamp create_dt;
	
	@Transient
	private String ecf_stat_cd;
	
	private int chld_out_home_ct;
	@Transient
	private String household_pregnancy_ind;
	@Transient
	private String expedited_snap_eligibility_ind;
	@Transient
	private String id_proof_score;
	
	@Column(name = "form_rpt_type")
	private String formRptType;
	
	@Column(name = "case_num")
	private String caseNum;
	private String changes_reported;
	@Transient
	private String langCode;
	
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	
	public Date getApp_cplt_tms() {
		return app_cplt_tms;
	}
	public void setApp_cplt_tms(Date app_cplt_tms) {
		this.app_cplt_tms = app_cplt_tms;
	}
	public Date getApp_strt_tms() {
		return app_strt_tms;
	}
	public void setApp_strt_tms(Date app_strt_tms) {
		this.app_strt_tms = app_strt_tms;
	}
	public String getApp_stat_cd() {
		return app_stat_cd;
	}
	public void setApp_stat_cd(String app_stat_cd) {
		this.app_stat_cd = app_stat_cd;
	}
	public String getFile_dt_only_resp() {
		return file_dt_only_resp;
	}
	public void setFile_dt_only_resp(String file_dt_only_resp) {
		this.file_dt_only_resp = file_dt_only_resp;
	}
	public int getHshl_indv_ct() {
		return hshl_indv_ct;
	}
	public void setHshl_indv_ct(int hshl_indv_ct) {
		this.hshl_indv_ct = hshl_indv_ct;
	}
	public int getMa_backdt_mo_1_ind() {
		return ma_backdt_mo_1_ind;
	}
	public void setMa_backdt_mo_1_ind(int ma_backdt_mo_1_ind) {
		this.ma_backdt_mo_1_ind = ma_backdt_mo_1_ind;
	}
	public int getMa_backdt_mo_2_ind() {
		return ma_backdt_mo_2_ind;
	}
	public void setMa_backdt_mo_2_ind(int ma_backdt_mo_2_ind) {
		this.ma_backdt_mo_2_ind = ma_backdt_mo_2_ind;
	}
	public int getMa_backdt_mo_3_ind() {
		return ma_backdt_mo_3_ind;
	}
	public void setMa_backdt_mo_3_ind(int ma_backdt_mo_3_ind) {
		this.ma_backdt_mo_3_ind = ma_backdt_mo_3_ind;
	}
	public Date getUpdt_dt() {
		return updt_dt;
	}
	public void setUpdt_dt(Date updt_dt) {
		this.updt_dt = updt_dt;
	}
	public String getEcf_stat_cd() {
		return ecf_stat_cd;
	}
	public void setEcf_stat_cd(String ecf_stat_cd) {
		this.ecf_stat_cd = ecf_stat_cd;
	}
	public int getChld_out_home_ct() {
		return chld_out_home_ct;
	}
	public void setChld_out_home_ct(int chld_out_home_ct) {
		this.chld_out_home_ct = chld_out_home_ct;
	}
	public String getHousehold_pregnancy_ind() {
		return household_pregnancy_ind;
	}
	public void setHousehold_pregnancy_ind(String household_pregnancy_ind) {
		this.household_pregnancy_ind = household_pregnancy_ind;
	}
	public String getExpedited_snap_eligibility_ind() {
		return expedited_snap_eligibility_ind;
	}
	public void setExpedited_snap_eligibility_ind(String expedited_snap_eligibility_ind) {
		this.expedited_snap_eligibility_ind = expedited_snap_eligibility_ind;
	}
	public String getId_proof_score() {
		return id_proof_score;
	}
	public void setId_proof_score(String id_proof_score) {
		this.id_proof_score = id_proof_score;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getFormRptType() {
		return formRptType;
	}

	public void setFormRptType(String formRptType) {
		this.formRptType = formRptType;
	}

	public String getCaseNum() {
		return caseNum;
	}

	public void setCaseNum(String caseNum) {
		this.caseNum = caseNum;
	}
	public Date getAppSbmtTms() {
		return appSbmtTms;
	}
	public void setAppSbmtTms(Date appSbmtTms) {
		this.appSbmtTms = appSbmtTms;
	}
	public String getChanges_reported() {
		return changes_reported;
	}
	public void setChanges_reported(String changes_reported) {
		this.changes_reported = changes_reported;
	}
	public Timestamp getCreate_dt() {
		return create_dt;
	}
	public void setCreate_dt(Timestamp create_dt) {
		this.create_dt = create_dt;
	}
	public String getLangCode() {
		return langCode;
	}
	public void setLangCode(String langCode) {
		this.langCode = langCode;
	}
	

	
	}