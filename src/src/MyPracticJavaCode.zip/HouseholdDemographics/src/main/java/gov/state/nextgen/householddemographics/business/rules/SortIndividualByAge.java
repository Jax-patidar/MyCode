package gov.state.nextgen.householddemographics.business.rules;

import gov.state.nextgen.householddemographics.business.entities.INDIVIDUAL_Custom_Cargo;

public class SortIndividualByAge implements Comparable  {

	private INDIVIDUAL_Custom_Cargo individualCustomCargo = null;
	private int individualAge = -1;
	private int indvSeqNum = -1;

	public SortIndividualByAge() {
	}

	@Override
	public int compareTo(final Object obj) {
		final SortIndividualByAge ind = (SortIndividualByAge) obj;
		final int individualAge2 = ind.getIndividualCustomCargo().getIndv_age() !=null ? ind.getIndividualCustomCargo().getIndv_age().getYears() : -1;
		final int indvSeqNum2 = Integer.parseInt(ind.getIndividualCustomCargo().getIndv_seq_num());

		if (individualAge < individualAge2) {
			return -1;
		} else if (individualAge > individualAge2) {
			return 1;
		} else {
			if (indvSeqNum < indvSeqNum2) {
				return 1;
			} else if (indvSeqNum > indvSeqNum2) {
				return -1;
			} else {
				return 0;
			}
		}
	}

	/**
	 * Enter the description of the method Creation Date:
	 */
	public INDIVIDUAL_Custom_Cargo getIndividualCustomCargo() {
		return individualCustomCargo;
	}

	/**
	 * Enter the description of the method Creation Date:
	 */
	public void setIndividualCustomCargo(final INDIVIDUAL_Custom_Cargo cargo) {
		individualCustomCargo = cargo;
		if(cargo.getIndv_age() != null) {
		 individualAge = cargo.getIndv_age().getYears();
		}
		indvSeqNum = Integer.parseInt(cargo.getIndv_seq_num());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + individualAge;
		result = (prime * result) + ((individualCustomCargo == null) ? 0 : individualCustomCargo.hashCode());
		result = (prime * result) + indvSeqNum;
		return result;
	}

	
}
