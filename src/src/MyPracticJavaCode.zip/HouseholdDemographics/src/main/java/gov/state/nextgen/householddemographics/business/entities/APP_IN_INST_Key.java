package gov.state.nextgen.householddemographics.business.entities;


import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class APP_IN_INST_Key implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 6429431127754111607L;
	@Id
	private String app_num;
	@Id
	private Integer indv_seq_num;
	@Id
	private String src_app_ind;
	
	public APP_IN_INST_Key(String app_num, Integer indv_seq_num, String src_app_ind) {
		super();
		this.app_num = app_num;
		this.indv_seq_num = indv_seq_num;
		this.src_app_ind = src_app_ind;
	}

	public APP_IN_INST_Key() {
		
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}

	
	
	
}
