package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(CP_APP_IMMED_CASH_KEY.class)
@Table(name = "CP_APP_IMMED_CASH")
public class CP_APP_IMMED_CASH_Cargo extends AbstractCargo implements Serializable{
	/**
	*
	*
	*/
	private static final long serialVersionUID = 1L;

	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	@Id
	private String immed_cash_id;
	
	private Integer indv_seq_num;

	private String child_abuse;
	private String domestic_abuse;
	private String elser_abuse;
	private String emerg_desc;
	private String essential_clothing;
	private String eviction_notice;
	private String food_run_out;
	private String medical_leave;
	private String other_emergency;
	private String preg;
	private String transport_help;
	private String util_shut_off;
	private String other_emergency_explain;
	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	/**
	 * @return the immed_cash_id
	 */
	public String getImmed_cash_id() {
		return immed_cash_id;
	}
	/**
	 * @param immed_cash_id the immed_cash_id to set
	 */
	public void setImmed_cash_id(String immed_cash_id) {
		this.immed_cash_id = immed_cash_id;
	}
	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	/**
	 * @return the child_abuse
	 */
	public String getChild_abuse() {
		return child_abuse;
	}
	/**
	 * @param child_abuse the child_abuse to set
	 */
	public void setChild_abuse(String child_abuse) {
		this.child_abuse = child_abuse;
	}
	/**
	 * @return the domestic_abuse
	 */
	public String getDomestic_abuse() {
		return domestic_abuse;
	}
	/**
	 * @param domestic_abuse the domestic_abuse to set
	 */
	public void setDomestic_abuse(String domestic_abuse) {
		this.domestic_abuse = domestic_abuse;
	}
	/**
	 * @return the elser_abuse
	 */
	public String getElser_abuse() {
		return elser_abuse;
	}
	/**
	 * @param elser_abuse the elser_abuse to set
	 */
	public void setElser_abuse(String elser_abuse) {
		this.elser_abuse = elser_abuse;
	}
	/**
	 * @return the emerg_desc
	 */
	public String getEmerg_desc() {
		return emerg_desc;
	}
	/**
	 * @param emerg_desc the emerg_desc to set
	 */
	public void setEmerg_desc(String emerg_desc) {
		this.emerg_desc = emerg_desc;
	}
	/**
	 * @return the essential_clothing
	 */
	public String getEssential_clothing() {
		return essential_clothing;
	}
	/**
	 * @param essential_clothing the essential_clothing to set
	 */
	public void setEssential_clothing(String essential_clothing) {
		this.essential_clothing = essential_clothing;
	}
	/**
	 * @return the eviction_notice
	 */
	public String getEviction_notice() {
		return eviction_notice;
	}
	/**
	 * @param eviction_notice the eviction_notice to set
	 */
	public void setEviction_notice(String eviction_notice) {
		this.eviction_notice = eviction_notice;
	}
	/**
	 * @return the food_run_out
	 */
	public String getFood_run_out() {
		return food_run_out;
	}
	/**
	 * @param food_run_out the food_run_out to set
	 */
	public void setFood_run_out(String food_run_out) {
		this.food_run_out = food_run_out;
	}
	/**
	 * @return the medical_leave
	 */
	public String getMedical_leave() {
		return medical_leave;
	}
	/**
	 * @param medical_leave the medical_leave to set
	 */
	public void setMedical_leave(String medical_leave) {
		this.medical_leave = medical_leave;
	}
	/**
	 * @return the other_emergency
	 */
	public String getOther_emergency() {
		return other_emergency;
	}
	/**
	 * @param other_emergency the other_emergency to set
	 */
	public void setOther_emergency(String other_emergency) {
		this.other_emergency = other_emergency;
	}
	/**
	 * @return the preg
	 */
	public String getPreg() {
		return preg;
	}
	/**
	 * @param preg the preg to set
	 */
	public void setPreg(String preg) {
		this.preg = preg;
	}
	/**
	 * @return the transport_help
	 */
	public String getTransport_help() {
		return transport_help;
	}
	/**
	 * @param transport_help the transport_help to set
	 */
	public void setTransport_help(String transport_help) {
		this.transport_help = transport_help;
	}
	/**
	 * @return the util_shut_off
	 */
	public String getUtil_shut_off() {
		return util_shut_off;
	}
	/**
	 * @param util_shut_off the util_shut_off to set
	 */
	public void setUtil_shut_off(String util_shut_off) {
		this.util_shut_off = util_shut_off;
	}
	/**
	 * @return the other_emergency_explain
	 */
	public String getOther_emergency_explain() {
		return other_emergency_explain;
	}
	/**
	 * @param other_emergency_explain the other_emergency_explain to set
	 */
	public void setOther_emergency_explain(String other_emergency_explain) {
		this.other_emergency_explain = other_emergency_explain;
	}
	
		
	
}
