package gov.state.nextgen.householddemographics.model;

import java.io.Serializable;
import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;


@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseIndividualDetailsIncarceratedDetail implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -114449618870479923L;

	
	@JsonProperty("incarceratedInd")
	private boolean incarceratedInd;

	@JsonProperty("dateOfRelease")
	private Date dateOfRelease;
	
	public boolean isIncarceratedInd() {
		return incarceratedInd;
	}

	public void setIncarceratedInd(boolean incarceratedInd) {
		this.incarceratedInd = incarceratedInd;
	}

	public Date getDateOfRelease() {
		return dateOfRelease;
	}

	public void setDateOfRelease(Date dateOfRelease) {
		this.dateOfRelease = dateOfRelease;
	}
	
	
}
