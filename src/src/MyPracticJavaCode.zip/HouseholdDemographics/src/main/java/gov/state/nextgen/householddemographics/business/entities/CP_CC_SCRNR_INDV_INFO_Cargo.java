package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import java.sql.Date;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;


public class CP_CC_SCRNR_INDV_INFO_Cargo extends AbstractCargo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -39558514883805012L;
	
	@Id
	private String app_num;
	
	private Integer indv_seq_num;
	private String fst_nam;
	private String last_nam;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date dob;
	
	private String caretaker;
	private String court_ordr_suprvsn;
	private String minor_parent;
	private String spcl_needs;
	private String schl_attendance;
	private Float avg_wkly_inc;
	private Integer avg_wkly_hrs_wrk;
	private String scrnr_seq;
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getFst_nam() {
		return fst_nam;
	}
	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}
	public String getLast_nam() {
		return last_nam;
	}
	public void setLast_nam(String last_nam) {
		this.last_nam = last_nam;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getCaretaker() {
		return caretaker;
	}
	public void setCaretaker(String caretaker) {
		this.caretaker = caretaker;
	}
	public String getCourt_ordr_suprvsn() {
		return court_ordr_suprvsn;
	}
	public void setCourt_ordr_suprvsn(String court_ordr_suprvsn) {
		this.court_ordr_suprvsn = court_ordr_suprvsn;
	}
	public String getMinor_parent() {
		return minor_parent;
	}
	public void setMinor_parent(String minor_parent) {
		this.minor_parent = minor_parent;
	}
	public String getSpcl_needs() {
		return spcl_needs;
	}
	public void setSpcl_needs(String spcl_needs) {
		this.spcl_needs = spcl_needs;
	}
	public String getSchl_attendance() {
		return schl_attendance;
	}
	public void setSchl_attendance(String schl_attendance) {
		this.schl_attendance = schl_attendance;
	}
	public Float getAvg_wkly_inc() {
		return avg_wkly_inc;
	}
	public void setAvg_wkly_inc(Float avg_wkly_inc) {
		this.avg_wkly_inc = avg_wkly_inc;
	}
	public Integer getAvg_wkly_hrs_wrk() {
		return avg_wkly_hrs_wrk;
	}
	public void setAvg_wkly_hrs_wrk(Integer avg_wkly_hrs_wrk) {
		this.avg_wkly_hrs_wrk = avg_wkly_hrs_wrk;
	}
	public String getScrnr_seq() {
		return scrnr_seq;
	}
	public void setScrnr_seq(String scrnr_seq) {
		this.scrnr_seq = scrnr_seq;
	}
	@Override
	public String toString() {
		return "CP_CC_SCRNR_INDV_INFO_Cargo [app_num=" + app_num + ", indv_seq_num=" + indv_seq_num + ", fst_nam="
				+ fst_nam + ", last_nam=" + last_nam + ", dob=" + dob + ", caretaker=" + caretaker
				+ ", court_ordr_suprvsn=" + court_ordr_suprvsn + ", minor_parent=" + minor_parent + ", spcl_needs="
				+ spcl_needs + ", schl_attendance=" + schl_attendance + ", avg_wkly_inc=" + avg_wkly_inc
				+ ", avg_wkly_hrs_wrk=" + avg_wkly_hrs_wrk + ", scrnr_seq=" + scrnr_seq + "]";
	}
	
	
}
