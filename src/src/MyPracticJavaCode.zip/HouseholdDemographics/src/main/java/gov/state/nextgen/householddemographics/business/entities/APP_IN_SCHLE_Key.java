package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class APP_IN_SCHLE_Key implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer app_number;
	private Integer indv_seq_num;
	private Integer seq_num;
	private String school_type_cd;
		
	public APP_IN_SCHLE_Key() {
		
	}

	/**
	 * @param app_num
	 * @param indv_seq_num
	 * @param src_app_ind
	 * @param seq_num
	 */
	public APP_IN_SCHLE_Key(Integer app_number, Integer indv_seq_num, Integer seq_num, String school_type_cd) {
		super();
		this.app_number = app_number;
		this.indv_seq_num = indv_seq_num;
		this.seq_num = seq_num;
		this.school_type_cd = school_type_cd;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((school_type_cd == null)? 0 : school_type_cd.hashCode());
		return result;
	}

	
}
