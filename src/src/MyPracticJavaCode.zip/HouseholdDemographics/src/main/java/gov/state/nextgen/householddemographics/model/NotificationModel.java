package gov.state.nextgen.householddemographics.model;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.HashMap;
import java.util.Map;

public class NotificationModel {

    private String templateName;
    private String notificationType;
    private SMSNotificationModel smsInfo;
    private Map<String, Object> params = new HashMap<>();

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }

    public SMSNotificationModel getSmsInfo() {
        return smsInfo;
    }

    public void setSmsInfo(SMSNotificationModel smsInfo) {
        this.smsInfo = smsInfo;
    }

    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
