package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_PGM_RQST_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_PGM_RQST";

	/**
	 * returns the PACKAGE name.
	 *
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_PGM_RQST_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_PGM_RQST_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_PGM_RQST_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_PGM_RQST_Cargo[] getResults() {
		final APP_PGM_RQST_Cargo[] cbArray = new APP_PGM_RQST_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_PGM_RQST_Cargo getCargo(final int idx) {
		return (APP_PGM_RQST_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_PGM_RQST_Cargo[] cloneResults() {
		final APP_PGM_RQST_Cargo[] rescargo = new APP_PGM_RQST_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_PGM_RQST_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_PGM_RQST_Cargo();
			rescargo[i].setApp_number(cargo.getApp_number());
			rescargo[i].setFma_rqst_ind(cargo.getFma_rqst_ind());
			rescargo[i].setFpw_rqst_ind(cargo.getFpw_rqst_ind());
			rescargo[i].setFs_rqst_ind(cargo.getFs_rqst_ind());
			rescargo[i].setCc_rqst_ind(cargo.getCc_rqst_ind());
			rescargo[i].setEbd_rqst_ind(cargo.getEbd_rqst_ind());
			rescargo[i].setHc_rqst_ind(cargo.getHc_rqst_ind());
			rescargo[i].setTanf_rqst_ind(cargo.getTanf_rqst_ind());
			rescargo[i].setWic_rqst_ind(cargo.getWic_rqst_ind());
			rescargo[i].setLiheap_rqst_ind(cargo.getLiheap_rqst_ind());
			rescargo[i].setPeach_rqst_ind(cargo.getPeach_rqst_ind());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setProg_sel_sw(cargo.getProg_sel_sw());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
			rescargo[i].setMagi_rqst_ind(cargo.getMagi_rqst_ind());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_PGM_RQST_Cargo[]) {
			final APP_PGM_RQST_Cargo[] cbArray = (APP_PGM_RQST_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
