package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_PGM_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_PGM_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_RGST_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Collection;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Collection;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Cargo;
import gov.state.nextgen.householddemographics.business.entities.RMB_RQST_Collection;
import gov.state.nextgen.householddemographics.business.entities.Tnb4FormSpecificCargo;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("MCBWB")
@Scope("prototype")
public class MCBWBResponse implements LogicResponseInterface {

	private static final String PAGE_ID = "MCBWB";

	/*
	 * Constructing pageResponse and returning driverPageResponse.
	 */
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();

		List<RMB_RQST_Cargo> rmbReqList = new ArrayList<>();
		List<CpRmbRequestDetails_Cargo> cpRmbReqDetList = new ArrayList<>();
		List<APP_INDV_Cargo> appIndvCargoList = new ArrayList<>();
		List<CP_APP_PGM_INDV_Cargo> cpAppPgmIndvCargoList = new ArrayList<>();
		List<APP_PGM_RQST_Cargo> appPgmRqstCargoList = new ArrayList<>();
		List<CP_APP_RGST_Cargo> cpAppRgstCargoList = new ArrayList<>();
		List<CP_APP_HSHL_RLT_Cargo> cpAppHshlRltCargoList = new ArrayList<>();
		List<CpRmbLtcDtls_Cargo> cpRmbLtcDtlsCargoList = new ArrayList<>();
		
		Map<Object, Object> pageCollection = fwTxn.getPageCollection();

		CpRmbRequestDetails_Collection cpRmbReqDetColl = (CpRmbRequestDetails_Collection) pageCollection
				.get("CpRmbRequestDetails_Collection");

		RMB_RQST_Collection rmbReqColl = (RMB_RQST_Collection) pageCollection.get("RMB_RQST_Collection");

		APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection");

		CP_APP_PGM_INDV_Collection cpAppPgmIndvColl = (CP_APP_PGM_INDV_Collection) pageCollection
				.get("CP_APP_PGM_INDV_Collection");

		APP_PGM_RQST_Collection appPgmRqstColl = (APP_PGM_RQST_Collection) pageCollection
				.get("APP_PGM_RQST_Collection");

		CP_APP_RGST_Collection cpAppRgstColl = (CP_APP_RGST_Collection) pageCollection.get("CP_APP_RGST_Collection");
		
		CP_APP_HSHL_RLT_Collection cpAppHshlRltColl = (CP_APP_HSHL_RLT_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLLECTION);

		CpRmbLtcDtls_Collection cpRmbLtcDtlsColl = (CpRmbLtcDtls_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.CpRmbLtcDtlsCollection);
		
		cpRmbReqDetList  = setCpRmbReqDetList(cpRmbReqDetList, cpRmbReqDetColl);

		rmbReqList = setRmbReqList(rmbReqList, rmbReqColl);


		appIndvCargoList = setAppIndvCargoList(appIndvCargoList, appIndvColl);


		cpAppPgmIndvCargoList = setCpAppPgmIndvCargoList(cpAppPgmIndvCargoList, cpAppPgmIndvColl);


		appPgmRqstCargoList = setAppPgmRqstCargoList(appPgmRqstCargoList, appPgmRqstColl);

		cpAppRgstCargoList = setCpAppRgstCargoList(cpAppRgstCargoList, cpAppRgstColl);
		
		cpAppHshlRltCargoList = setHshlRltCargoList(cpAppHshlRltCargoList, cpAppHshlRltColl);
		
		cpRmbLtcDtlsCargoList = setCpRmbLtcDtlsCargoList(cpRmbLtcDtlsCargoList, cpRmbLtcDtlsColl);
	
		List<Tnb4FormSpecificCargo> tnb4FormData = new ArrayList<>();
		Tnb4FormSpecificCargo tnb4FormSpecificCargo = new Tnb4FormSpecificCargo();

		String caseNum = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.CASE_NUM))
				? pageCollection.get(HouseHoldDemoGraphicsConstants.CASE_NUM).toString()
				: null;
		tnb4FormSpecificCargo.setCaseNum(caseNum);

		Date tnbDueDate = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_DUE_DATE))
				&& !pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_DUE_DATE).equals("")
						? (Date) pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_DUE_DATE)
						: null;
		tnb4FormSpecificCargo.setTnbDueDate(tnbDueDate);

		Date tnbLastCertificationDate = Objects
				.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_LAST_CERTIFICATION_DATE))
				&& !pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_DUE_DATE).equals("")
						? (Date) pageCollection.get(HouseHoldDemoGraphicsConstants.TNB_LAST_CERTIFICATION_DATE)
						: null;
		tnb4FormSpecificCargo.setTnbLastCertificationDate(tnbLastCertificationDate);

		String caseName = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.CASE_NAME))
				? pageCollection.get(HouseHoldDemoGraphicsConstants.CASE_NAME).toString()
				: null;
		tnb4FormSpecificCargo.setCaseName(caseName);

		String countyCode = Objects.nonNull(pageCollection.get(HouseHoldDemoGraphicsConstants.COUNTY_CODE))
				? pageCollection.get(HouseHoldDemoGraphicsConstants.COUNTY_CODE).toString()
				: null;
		tnb4FormSpecificCargo.setCountyCode(countyCode);

		tnb4FormData.add(tnb4FormSpecificCargo);

		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.TNB4_FORM_DATA, tnb4FormData);

		driverPageResponse.getPageCollection().put("RMB_RQST_Collection", rmbReqList);
		driverPageResponse.getPageCollection().put("CpRmbRequestDetails_Collection", cpRmbReqDetList);

		driverPageResponse.getPageCollection().put("APP_INDV_Collection", appIndvCargoList);
		driverPageResponse.getPageCollection().put("CP_APP_PGM_INDV_Collection", cpAppPgmIndvCargoList);
		driverPageResponse.getPageCollection().put("APP_PGM_RQST_Collection", appPgmRqstCargoList);
		driverPageResponse.getPageCollection().put("CP_APP_RGST_Collection", cpAppRgstCargoList);
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_APP_HSHL_RLT_COLL, cpAppHshlRltCargoList);
		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_RMBLTCDTLSCOLL, cpRmbLtcDtlsCargoList);

		String appNum = null;

		if (pageCollection.get("APP_NUM") != null) {
			appNum = pageCollection.get("APP_NUM").toString();
		}

		List<String> offcNum = new ArrayList<>();
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.OFFICE_NUM) != null && pageCollection.get(HouseHoldDemoGraphicsConstants.OFFICE_NUM) != StringUtils.EMPTY){
			offcNum.add(pageCollection.get(HouseHoldDemoGraphicsConstants.OFFICE_NUM).toString());
			driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.OFFICE_NUM,offcNum);
		}
		List<String> ttyNum = new ArrayList<>();
		if(pageCollection.get(HouseHoldDemoGraphicsConstants.TELE_TYPE_NUM) != null && pageCollection.get(HouseHoldDemoGraphicsConstants.TELE_TYPE_NUM) != StringUtils.EMPTY){
			ttyNum.add(pageCollection.get(HouseHoldDemoGraphicsConstants.TELE_TYPE_NUM).toString());
			driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.TELE_TYPE_NUM,ttyNum);
		}
		
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));
		driverPageResponse.setAppNum(appNum);
		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

		return driverPageResponse;
	}

	/*
	 * Method for setting cpAppRgstCargoList from cpAppRgstColl
	 */
	private List<CP_APP_RGST_Cargo> setCpAppRgstCargoList(List<CP_APP_RGST_Cargo> cpAppRgstCargoList,
			CP_APP_RGST_Collection cpAppRgstColl) {
		CP_APP_RGST_Cargo cpAppRgstCargo;
		if(cpAppRgstColl != null) {
			for(int i = 0;i<cpAppRgstColl.size();i++) {
				cpAppRgstCargo = (CP_APP_RGST_Cargo) cpAppRgstColl.get(i);
				if(cpAppRgstCargo != null) {
					mailingAddressCheck(cpAppRgstCargo);
					homeAddressCheck(cpAppRgstCargo);
				}
				cpAppRgstCargoList.add(cpAppRgstCargo);
			}
		}
		return cpAppRgstCargoList;
	}

	private void homeAddressCheck(CP_APP_RGST_Cargo cpAppRgstCargo) {
		if(cpAppRgstCargo.getHshl_l2_adr() == null) {
			cpAppRgstCargo.setHshl_l2_adr(HouseHoldDemoGraphicsConstants.EMPTY);
		}
		if(cpAppRgstCargo.getHshl_zip_adr() == null) {
			cpAppRgstCargo.setHshl_zip_adr(HouseHoldDemoGraphicsConstants.EMPTY);
		}
		if(cpAppRgstCargo.getHshl_l1_adr() == null) {
			cpAppRgstCargo.setHshl_l1_adr(HouseHoldDemoGraphicsConstants.EMPTY);
		}
		if(cpAppRgstCargo.getHshl_city_adr() == null) {
			cpAppRgstCargo.setHshl_city_adr(HouseHoldDemoGraphicsConstants.EMPTY);
		}
		if(cpAppRgstCargo.getHshl_sta_adr() == null) {
			cpAppRgstCargo.setHshl_sta_adr(HouseHoldDemoGraphicsConstants.EMPTY);
		}
	}

	private void mailingAddressCheck(CP_APP_RGST_Cargo cpAppRgstCargo) {
		if(cpAppRgstCargo.getAlt_l2_adr() == null) {
			cpAppRgstCargo.setAlt_l2_adr(HouseHoldDemoGraphicsConstants.EMPTY);
		}
		if(cpAppRgstCargo.getAlt_st_adr() == null) {
			cpAppRgstCargo.setAlt_st_adr(HouseHoldDemoGraphicsConstants.EMPTY);				
		}
		if(cpAppRgstCargo.getAlt_l1_adr() == null) {
			cpAppRgstCargo.setAlt_l1_adr(HouseHoldDemoGraphicsConstants.EMPTY);				
		}
		if(cpAppRgstCargo.getAlt_city_adr() == null) {
			cpAppRgstCargo.setAlt_city_adr(HouseHoldDemoGraphicsConstants.EMPTY);				
		}
		if(cpAppRgstCargo.getAlt_sta_adr() == null) {
			cpAppRgstCargo.setAlt_sta_adr(HouseHoldDemoGraphicsConstants.EMPTY);				
		}
		if(cpAppRgstCargo.getAlt_zip_adr() == null) {
			cpAppRgstCargo.setAlt_zip_adr(HouseHoldDemoGraphicsConstants.EMPTY);				
		}
	}
	
	/*
	 * Method for setting appPgmRqstCargoList from appPgmRqstColl
	 */
	private List<APP_PGM_RQST_Cargo> setAppPgmRqstCargoList(List<APP_PGM_RQST_Cargo> appPgmRqstCargoList,
			APP_PGM_RQST_Collection appPgmRqstColl) {
		APP_PGM_RQST_Cargo appPgmRqstCargo;
		if(appPgmRqstColl != null) {
			for(int i = 0;i<appPgmRqstColl.size();i++) {
				appPgmRqstCargo = (APP_PGM_RQST_Cargo) appPgmRqstColl.get(i);
				appPgmRqstCargoList.add(appPgmRqstCargo);
			}
		}
		return appPgmRqstCargoList;
	}
	
	/*
	 * Method for setting cpRmbLtcDtlsCargoList from cpRmbLtcDtlsColl
	 */
	
	private List<CpRmbLtcDtls_Cargo> setCpRmbLtcDtlsCargoList(List<CpRmbLtcDtls_Cargo> cpRmbLtcDtlsCargoList,
			CpRmbLtcDtls_Collection cpRmbLtcDtlsColl) {
		CpRmbLtcDtls_Cargo cpRmbLtcCargo;
		if(cpRmbLtcDtlsColl != null) {
			for(int i = 0;i<cpRmbLtcDtlsColl.size();i++) {
				cpRmbLtcCargo = (CpRmbLtcDtls_Cargo) cpRmbLtcDtlsColl.get(i);
				cpRmbLtcDtlsCargoList.add(cpRmbLtcCargo);
			}
		}
		return cpRmbLtcDtlsCargoList;
	}

	/*
	 * Method for setting cpAppPgmIndvCargoList from cpAppPgmIndvColl
	 */
	private List<CP_APP_PGM_INDV_Cargo> setCpAppPgmIndvCargoList(List<CP_APP_PGM_INDV_Cargo> cpAppPgmIndvCargoList,
			CP_APP_PGM_INDV_Collection cpAppPgmIndvColl) {
		CP_APP_PGM_INDV_Cargo cpAppPgmIndvCargo;
		if(cpAppPgmIndvColl != null) {
			for(int i = 0;i<cpAppPgmIndvColl.size();i++) {
				cpAppPgmIndvCargo = (CP_APP_PGM_INDV_Cargo) cpAppPgmIndvColl.get(i);
				cpAppPgmIndvCargoList.add(cpAppPgmIndvCargo);
			}
		}
		return cpAppPgmIndvCargoList;
	}

	/*
	 * Method for setting appIndvCargoList from appIndvColl
	 */
	private List<APP_INDV_Cargo> setAppIndvCargoList(List<APP_INDV_Cargo> appIndvCargoList, APP_INDV_Collection appIndvColl) {
		APP_INDV_Cargo appIndvCargo;
		if(appIndvColl != null) {
			for(int i = 0;i<appIndvColl.size();i++) {
				appIndvCargo = (APP_INDV_Cargo) appIndvColl.get(i);
				appIndvCargoList.add(appIndvCargo);
			}
		}
		return appIndvCargoList;
	}

	/*
	 * Method for setting rmbReqList from rmbReqColl
	 */
	private List<RMB_RQST_Cargo> setRmbReqList(List<RMB_RQST_Cargo> rmbReqList, RMB_RQST_Collection rmbReqColl) {
		RMB_RQST_Cargo rmbReqCargo;
		if(rmbReqColl != null) {
			for(int i = 0;i<rmbReqColl.size();i++) {
				rmbReqCargo = (RMB_RQST_Cargo) rmbReqColl.get(i);
				rmbReqList.add(rmbReqCargo);
			}
		}
		return rmbReqList;
	}

	/*
	 * Method for setting cpRmbReqDetList from cpRmbReqDetColl
	 */
	private List<CpRmbRequestDetails_Cargo> setCpRmbReqDetList(List<CpRmbRequestDetails_Cargo> cpRmbReqDetList,
			CpRmbRequestDetails_Collection cpRmbReqDetColl) {
		CpRmbRequestDetails_Cargo cpRmbReqDetCargo;
		if(cpRmbReqDetColl != null) {
			for(int i = 0;i<cpRmbReqDetColl.size();i++) {
				cpRmbReqDetCargo = (CpRmbRequestDetails_Cargo) cpRmbReqDetColl.get(i);
				cpRmbReqDetList.add(cpRmbReqDetCargo);
			}
		}
		return cpRmbReqDetList;
	}
	
	/*
	 * Method for setting cpAppHshlRltCargoList from cpAppHshlRltColl
	 */
	private List<CP_APP_HSHL_RLT_Cargo> setHshlRltCargoList(List<CP_APP_HSHL_RLT_Cargo> cpAppHshlRltCargoList, CP_APP_HSHL_RLT_Collection cpAppHshlRltColl) {
		CP_APP_HSHL_RLT_Cargo cpAppHshlRltCargo;
		if(cpAppHshlRltColl != null) {
        	for(int i = 0; i<cpAppHshlRltColl.size(); i++) {
        		cpAppHshlRltCargo = (CP_APP_HSHL_RLT_Cargo)cpAppHshlRltColl.get(i);
        		cpAppHshlRltCargoList.add(cpAppHshlRltCargo);
        	}
        }
		return cpAppHshlRltCargoList;
	}
	
}
