package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_IN_NEWB_Collection extends AbstractCollection {

    private static final String PACKAGE = "gov.nextgen.householddemographics.model.collections";

    public APP_IN_NEWB_Collection() {
    }

    public void addCargo(final APP_IN_NEWB_Cargo newCargo) {
        add(newCargo);
    }

    @Override
    public String getPACKAGE() {
        return PACKAGE;
    }

    public APP_IN_NEWB_Cargo getCargo() {
        if (size() == 0) {
            add(new APP_IN_NEWB_Cargo());
        }
        return (APP_IN_NEWB_Cargo) get(0);
    }

    public void setCargo(final APP_IN_NEWB_Cargo newCargo) {
        if (size() == 0) {
            add(newCargo);
        } else {
            set(0, newCargo);
        }
    }

    public void setResults(final APP_IN_NEWB_Cargo[] cbArray) {
        clear();
        for (int i = 0; i < cbArray.length; i++) {
            add(cbArray[i]);
        }
    }

    public void setResults(final int idx, final APP_IN_NEWB_Cargo cb) {
        set(idx, cb);
    }

    @Override
    public void setGenericResults(final Object obj) {
        if (obj instanceof APP_IN_NEWB_Cargo[]) {
            final APP_IN_NEWB_Cargo[] cbArray = (APP_IN_NEWB_Cargo[]) obj;
            for (int i = 0; i < cbArray.length; i++) {
                add(cbArray[i]);
            }
        }
    }

    public APP_IN_NEWB_Cargo[] getResults() {
        final APP_IN_NEWB_Cargo[] cbArray = new APP_IN_NEWB_Cargo[size()];
        toArray(cbArray);
        return cbArray;
    }

    public APP_IN_NEWB_Cargo getResult(final int idx) {
        return (APP_IN_NEWB_Cargo) get(idx);
    }

    public int getResultsSize() {
        return size();
    }
}
