package gov.state.nextgen.householddemographics.responsewrappers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CpRmbLtcDtls_Collection;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.factory.LogicResponseInterface;
import gov.state.nextgen.householddemographics.model.DriverPageResponse;
import gov.state.nextgen.householddemographics.model.PageResponse;

@Component("MCHSR")
@Scope("prototype")
public class MCHSRResponse implements LogicResponseInterface {

	private static final String PAGE_ID = "MCHSR";

	/*
	 * Constructing pageResponse and returning driverPageResponse.
	 */
	@Override
	public PageResponse constructPageResponse(FwTransaction fwTxn) {

		DriverPageResponse driverPageResponse = new DriverPageResponse();

		List<CpRmbLtcDtls_Cargo> cpRmbLtcDtlsCargoList = new ArrayList<>();
		

		Map<Object, Object> pageCollection = fwTxn.getPageCollection();
		

		CpRmbLtcDtls_Collection cpRmbLtcDtlsColl = (CpRmbLtcDtls_Collection) pageCollection
				.get(HouseHoldDemoGraphicsConstants.CpRmbLtcDtlsCollection);
		CpRmbLtcDtls_Cargo cpRmbLtcCargo;
		if (cpRmbLtcDtlsColl != null) {
			for (int i = 0; i < cpRmbLtcDtlsColl.size(); i++) {
				cpRmbLtcCargo = (CpRmbLtcDtls_Cargo) cpRmbLtcDtlsColl.get(i);
				setFacilityAddress(cpRmbLtcCargo);
				cpRmbLtcDtlsCargoList.add(cpRmbLtcCargo);
			}
		}

		driverPageResponse.getPageCollection().put(HouseHoldDemoGraphicsConstants.CP_RMBLTCDTLSCOLL,
				cpRmbLtcDtlsCargoList);
		driverPageResponse.setCurrentPageID(PAGE_ID);
		driverPageResponse.setNextPageAction(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ACTION)));
		driverPageResponse.setNextPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.NEXT_PAGE_ID)));

		driverPageResponse.setPreviousPageID(String.valueOf(fwTxn.getRequest().get(FwConstants.PREVIOUS_PAGE_ID)));

		return driverPageResponse;
	}

	private void setFacilityAddress(CpRmbLtcDtls_Cargo cpRmbLtcCargo) {
		String facilityAddress = FwConstants.EMPTY_STRING;
		if(Objects.nonNull(cpRmbLtcCargo.getFacilityAddressLine1())) {
			facilityAddress += (cpRmbLtcCargo.getFacilityAddressLine1()) + " ";
		}
		if(Objects.nonNull(cpRmbLtcCargo.getFacilityAddressLine2())) {
			facilityAddress += (cpRmbLtcCargo.getFacilityAddressLine2()) + " ";
		}
		if(Objects.nonNull(cpRmbLtcCargo.getFacilityAddressCity())) {
			facilityAddress += (cpRmbLtcCargo.getFacilityAddressCity()) + " ";
		}
		if(Objects.nonNull(cpRmbLtcCargo.getFacilityAddressState())) {
			facilityAddress += (cpRmbLtcCargo.getFacilityAddressState()) + " ";
		}
		if(Objects.nonNull(cpRmbLtcCargo.getFacilityAddressZip())) {
			facilityAddress += (cpRmbLtcCargo.getFacilityAddressZip());
		}
		cpRmbLtcCargo.setFacilityAddress(facilityAddress);
	}

}
