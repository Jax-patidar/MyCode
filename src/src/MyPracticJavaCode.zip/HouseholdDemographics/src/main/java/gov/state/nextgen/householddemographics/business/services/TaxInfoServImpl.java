/**
 * 
 */
package gov.state.nextgen.householddemographics.business.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_TAX_RETURNS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_IN_TAX_RETURNS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_DEPENDENTS_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_DEPENDENTS_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Cargo;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_IN_TAX_RETURN_Collection;
import gov.state.nextgen.householddemographics.business.rules.TaxInformationBO;
import gov.state.nextgen.householddemographics.constants.HouseHoldDemoGraphicsConstants;
import gov.state.nextgen.householddemographics.data.db2.CpAppInTaxReturnRepository;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;

@SuppressWarnings("squid:S2229")
@Service("TaxInfoService")
public class TaxInfoServImpl implements HouseholdDemographicsService {

	@Autowired
	private TaxInformationBO taxBO;

	@Autowired
	private CpAppIndvRepository appRepo;

	@Autowired
	private ExceptionUtil exceptionUtil;

	@Autowired
	private CpAppInTaxReturnRepository taxRepo;
	
	@Autowired
	private CpAppIndvRepository cpAppIndvRepository; 

	/**
	 * To call specific business method of the same bean
	 */
	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {

		switch (methodName) {
		case HouseHoldDemoGraphicsConstants.STORETAXINFORMATION:
			this.storeTaxInformation(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.LOADTAXSUMMARYINFORMATION:
			this.LoadTaxSummaryInformation(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.DELETETAXINFORMATION:
			this.deleteTaxInformation(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.LOADTAXDEPENDENTSINFORMATION:
			this.loadTaxDependentsInformation(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.LOADTAXRETURNSUMMARY:
			this.loadTaxReturnSummary(fwTxn);
			break;
		case HouseHoldDemoGraphicsConstants.STORETAXPRIMARY:
			this.storeTaxprimary(fwTxn);
			break;
		default:
			break;

		}
	}

	/**
	 * 
	 * @param fwTxn
	 */
	@Transactional
	public void LoadTaxSummaryInformation(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInfoServImpl.LoadTaxSummaryInformation() - START",
				fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			String src_ind = HouseHoldDemoGraphicsConstants.APP_IND_AFB;
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("indvIds");
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			CP_APP_IN_TAX_RETURN_Collection taxColl = taxBO.loadTaxInfo(appNumber, src_ind, indvIdList);

			APP_IN_TAX_RETURNS_Collection taxReturnsColl = taxBO.loadTaxReturnsInfo(appNumber, src_ind, indvIdList);

			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_RETURN_COLLECTION, taxColl);
			pageCollection.put(HouseHoldDemoGraphicsConstants.APP_IN_TAX_RETURNS_COLLECTION, taxReturnsColl);

			fwTxn.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in LoadTaxSummaryInformation()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "LoadTaxSummaryInformation",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInfoServImpl.LoadTaxSummaryInformation() - END", fwTxn);
	}

	// start:changes CSPM-14999 MC210
	@Transactional
	public void loadTaxReturnSummary(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.loadTaxReturnLoad() - START");
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadTaxReturnLoad() - ***loadTaxReturnLoad START***");
		CP_APP_IN_TAX_RETURN_Collection taxReturnColl = null;
		APP_INDV_Collection appIndvCargo = null;
		try {

			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			CP_APP_IN_TAX_RETURN_Cargo[] appTaxRetCargo = null;
			CP_APP_IN_TAX_RETURN_Cargo[] appTaxCargoFinal = null;
			if (null != appNumber) {
				taxReturnColl = taxRepo.loadTaxtReturninfo(Integer.parseInt(appNumber));
				appIndvCargo = cpAppIndvRepository.getAppActiveIndvCargoByAppNum(Integer.parseInt(appNumber));
				processTaxReturnData(taxReturnColl, appIndvCargo);
			}
			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_RETURN_COLLECTION, taxReturnColl);
			fwTxn.setPageCollection(pageCollection);

		} catch (Exception exception) {

			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadTaxReturnLoad",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.loadTaxReturnLoad() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + HouseHoldDemoGraphicsConstants.MILLISECONDS);

	}

	private void processTaxReturnData(CP_APP_IN_TAX_RETURN_Collection taxReturnColl,
			APP_INDV_Collection appIndvCargo) {
		CP_APP_IN_TAX_RETURN_Cargo[] appTaxRetCargo;
		CP_APP_IN_TAX_RETURN_Cargo[] appTaxCargoFinal;
		if(taxReturnColl != null) {
			appTaxRetCargo = taxReturnColl.getResults();
			if(appIndvCargo != null && appIndvCargo.getResults() != null && appTaxRetCargo!= null) {
				List<Integer> indvList = Arrays.stream(taxReturnColl.getResults()).map(individualId -> individualId.getIndv_seq_num()).collect(Collectors.toList());
				
				Long finalLength = Arrays.stream(appIndvCargo.getResults()).filter(indvCargo ->  indvList.contains(indvCargo.getIndv_seq_num())).count();
				appTaxCargoFinal =  new CP_APP_IN_TAX_RETURN_Cargo[finalLength.intValue()];
				processIndvTaxReturn(appIndvCargo, appTaxRetCargo, appTaxCargoFinal, finalLength.intValue());
				taxReturnColl.setResults(appTaxCargoFinal);
			}
		}
	}

	private void processIndvTaxReturn(APP_INDV_Collection appIndvCargo, CP_APP_IN_TAX_RETURN_Cargo[] appTaxRetCargo,
			CP_APP_IN_TAX_RETURN_Cargo[] appTaxCargoFinal, int arrLength) {
		int k=0;
		for(int i=0; i<appIndvCargo.getResults().length;i++) {
			for(int j=0; j<appTaxRetCargo.length;j++) {
				if((appIndvCargo.getResults()[i].getIndv_seq_num().equals(appTaxRetCargo[j].getIndv_seq_num())) && k<arrLength) {
						appTaxCargoFinal[k]= appTaxRetCargo[j];
						k++;
				}
			}
		}
	}	
	@Transactional
	public void loadTaxDependentsInformation(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInfoServImpl.loadTaxDependentsInformation() - START",
				fwTxn);
		try {
			Map pageCollection = new HashMap();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			String src_ind = HouseHoldDemoGraphicsConstants.APP_IND_AFB;
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			CP_APP_IN_TAX_DEPENDENTS_Collection depColl = taxBO.loadTaxDepIndvInfo(appNumber, src_ind, indv_seq_num);

			pageCollection.put(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_DEPENDENTS_COLLECTION, depColl);

			fwTxn.setPageCollection(pageCollection);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in loadTaxDependentsInformation()",
					fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadTaxDependentsInformation",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInfoServImpl.loadTaxDependentsInformation() - END",
				fwTxn);
	}

	/**
	 * method to store the tax information for individual
	 * 
	 * @param fwTxn
	 */
	// added some logic for CSPM-22168 change date.

	@Transactional
	@SuppressWarnings({"squid:S3776","squid:S4973"})
	public void storeTaxInformation(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInfoService.storeTaxInformation() - START");
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			String src_ind = HouseHoldDemoGraphicsConstants.APP_IND_AFB;
			Integer seqNum = 0;

			Integer indv_seq_num = 0;
			CP_APP_IN_TAX_DEPENDENTS_Collection depColl = null;
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence() != null) {
				indv_seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence() != null && fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence() != "") {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			CP_APP_IN_TAX_RETURN_Collection taxColl = (CP_APP_IN_TAX_RETURN_Collection) pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_RETURN_COLLECTION);

			if (pageCollection.get("mode").equals("MR")) {
				CP_APP_IN_TAX_RETURN_Cargo taxretcargo = (CP_APP_IN_TAX_RETURN_Cargo) taxColl.get(0);
				if(indv_seq_num == 0 || null == indv_seq_num) {
					indv_seq_num = taxretcargo.getIndv_seq_num();
				}
				LocalDateTime ldt = LocalDateTime.now();
				String chngeDt = DateTimeFormatter.ofPattern("MM-dd-yyyy", Locale.ENGLISH).format(ldt);
				long millis = System.currentTimeMillis();
				java.sql.Date dates = new java.sql.Date(millis);
				taxretcargo.setChg_dt(dates);

			}

			if(null != pageCollection
					.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_DEPENDENTS_COLLECTION)) {
				depColl = (CP_APP_IN_TAX_DEPENDENTS_Collection) pageCollection
						.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_DEPENDENTS_COLLECTION);
			}
			
			if (null != taxColl && !taxColl.isEmpty()) {
				setTaxReturnCargot(appNumber, indv_seq_num, taxColl);
			}

			taxBO.deleteTaxDepData(appNumber, indv_seq_num, src_ind);
			CP_APP_IN_TAX_DEPENDENTS_Collection newDepColl = new CP_APP_IN_TAX_DEPENDENTS_Collection();
			if (depColl != null && !CollectionUtils.isNullOrEmpty(depColl) && depColl.getCargo(0).getDependent_indv_seq_num() != null) {
				for (int i = 0; i < depColl.size(); i++) {
					CP_APP_IN_TAX_DEPENDENTS_Cargo depCargo = depColl.getCargo(i);
					depCargo.setApp_number(Integer.parseInt(appNumber));
					depCargo.setIndv_seq_num(indv_seq_num);
					depCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
					if (depCargo.getDependent_indv_seq_num() == null) {
						depCargo.setDependent_indv_seq_num(0);
					}
					newDepColl.add(depCargo);
				}
				taxBO.storeTaxDepInfo(newDepColl);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeTaxInformation()", fwTxn);

        	FwExceptionManager.handleException(exception,this.getClass().getName(),

        			"storeTaxInformation", fwTxn.getUserDetails().getAppNumber(),

        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInfoService.storeTaxInformation() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime));
	}

	private void setTaxReturnCargot(String appNumber, Integer indv_seq_num, CP_APP_IN_TAX_RETURN_Collection taxColl) {
		try {
			CP_APP_IN_TAX_RETURN_Cargo taxCargo = taxColl.getCargo(0);
			taxCargo.setApp_num(appNumber);
			taxCargo.setIndv_seq_num(indv_seq_num);
			taxCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
			if (taxCargo.getSpouse_indv_id() != null) {
				if (taxCargo.getSpouse_indv_id() > 0) {
					APP_INDV_Collection appColl = appRepo.getCollByAppNumIndvSeq(Integer.parseInt(appNumber),
							taxCargo.getSpouse_indv_id());
					if (null != appColl && !appColl.isEmpty()) {
						APP_INDV_Cargo appCargo = appColl.getCargo(0);
						if (null!=appCargo.getPrim_prsn_sw() && "Y".equals(appCargo.getPrim_prsn_sw())) {
							taxCargo.setPrimary_filer_sw("Y");
						}
					}
				}
			}
			taxBO.storeTaxInfo(taxCargo);

			APP_IN_TAX_RETURNS_Cargo taxReturnsCargo = new APP_IN_TAX_RETURNS_Cargo();
			taxReturnsCargo.setApp_num(appNumber);
			taxReturnsCargo.setIndv_seq_num(indv_seq_num);
			taxReturnsCargo.setSrc_app_ind(HouseHoldDemoGraphicsConstants.APP_IND_AFB);
			taxReturnsCargo.setTax_dependent_resp(taxCargo.getTax_dependent_resp());
			taxBO.storeTaxReturnsInfo(taxReturnsCargo);
		} catch (Exception e) {
			throw e;
		}
	}

	@Transactional
	public void deleteTaxInformation(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInfoServImpl.deleteTaxInformation() - START", fwTxn);

		try {
			Integer indv_seq_num = 0;
			Integer zero = 0;
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			String src_ind = HouseHoldDemoGraphicsConstants.APP_IND_AFB;
			String indvSeqNum = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence();
			if (null != indvSeqNum && !("".equalsIgnoreCase(indvSeqNum))) {
				indv_seq_num = Integer.parseInt(indvSeqNum);
			}

			/************* Delete For CP_APP_IN_TAX_RETURN_Cargo **********/

			if (!(indv_seq_num.equals(zero))) {
				CP_APP_IN_TAX_RETURN_Collection beforeColl = taxBO.loadTaxRetInfo(appNum, src_ind, indv_seq_num);
				if (null != beforeColl && !beforeColl.isEmpty()) {
					taxBO.deleteTaxRetData(appNum, src_ind, indv_seq_num);
				}
			}

			/************* Delete For APP_IN_TAX_RETURNS_Cargo **********/

			if (!(indv_seq_num.equals(zero))) {
				APP_IN_TAX_RETURNS_Collection beforeColl = taxBO.fetchTaxReturnsDetails(appNum, src_ind, indv_seq_num);
				if (null != beforeColl && !beforeColl.isEmpty()) {
					taxBO.deleteTaxReturnsData(appNum, src_ind, indv_seq_num);
				}
			}

			/************* Delete For Tax Dependents **********/

			if (!(indv_seq_num.equals(zero))) {
				CP_APP_IN_TAX_DEPENDENTS_Collection beforeColl = taxBO.loadTaxDepIndvInfo(appNum, src_ind,
						indv_seq_num);
				if (null != beforeColl && !beforeColl.isEmpty()) {
					taxBO.deleteTaxDepData(appNum, indv_seq_num, src_ind);
				}
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in deleteTaxInformation()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteTaxInformation",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInfoServImpl.deleteTaxInformation() - END", fwTxn);
	}
	public void storeTaxprimary(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInfoServImpl.storeTaxprimary() - START",
				fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			String srcInd = HouseHoldDemoGraphicsConstants.APP_IND_AFB;
			Integer indvSeqNum = 0;
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence() != null && !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			CP_APP_IN_TAX_RETURN_Collection cpAppInTaxRetColl=null;
			List<CP_APP_IN_TAX_RETURN_Cargo> filteredTaxRetCargo = null;
			if(pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_RETURN_COLLECTION) instanceof ArrayList) {
				cpAppInTaxRetColl = null;//NOSONAR
			}
			else {
				cpAppInTaxRetColl = (CP_APP_IN_TAX_RETURN_Collection) pageCollection.get(HouseHoldDemoGraphicsConstants.CP_APP_IN_TAX_RETURN_COLLECTION);
				List<CP_APP_IN_TAX_RETURN_Cargo> listCargo = Arrays.asList(cpAppInTaxRetColl.getResults());
				final Integer indvId = indvSeqNum;
				filteredTaxRetCargo = listCargo.stream().filter(cargo -> indvId.equals(cargo.getIndv_seq_num())).collect(Collectors.toList());
			}
				
			CP_APP_IN_TAX_RETURN_Cargo cpAppInTaxRetCargo = new CP_APP_IN_TAX_RETURN_Cargo();
			if(filteredTaxRetCargo != null && !filteredTaxRetCargo.isEmpty()) {
				cpAppInTaxRetCargo = filteredTaxRetCargo.get(0);
				
			}
			if(indvSeqNum != 0) {
				cpAppInTaxRetCargo.setApp_num(appNumber);
				cpAppInTaxRetCargo.setIndv_seq_num(indvSeqNum);
				cpAppInTaxRetCargo.setSrc_app_ind(srcInd);
				cpAppInTaxRetCargo.setPrimary_filer_sw("Y");
				if(filteredTaxRetCargo == null || filteredTaxRetCargo.isEmpty()) {
					cpAppInTaxRetCargo.setTaxPrimaryFlag("Y");
				}
				taxRepo.save(cpAppInTaxRetCargo);

				taxRepo.updateOthersPrimSw(Integer.parseInt(appNumber),srcInd,cpAppInTaxRetCargo.getIndv_seq_num());
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeTaxprimary()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeTaxprimary",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "TaxInfoServImpl.storeTaxprimary() - END", fwTxn);
	}

}
