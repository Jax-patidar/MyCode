package gov.state.nextgen.householddemographics.model;

import gov.state.nextgen.access.management.messages.FwMessage;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 * Page Response Model class.
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 */

public class PageResponse implements Serializable {

	private static final long serialVersionUID = 160289513113160691L;

	private String currentPageID;
	private String nextPageID;
	private String nextPageAction;
	private String previousPageID;
	private List<FwMessage> validationMessages;

	public String getCurrentPageID() {
		return currentPageID;
	}

	public void setCurrentPageID(String currentPageID) {
		this.currentPageID = currentPageID;
	}


	public String getNextPageID() {
		return nextPageID;
	}

	public void setNextPageID(String nextPageID) {
		this.nextPageID = nextPageID;
	}

	public String getNextPageAction() {
		return nextPageAction;
	}

	public void setNextPageAction(String nextPageAction) {
		this.nextPageAction = nextPageAction;
	}

	public List<FwMessage> getValidationMessages() {
		if(validationMessages != null) {
			return new ArrayList<FwMessage>(validationMessages);
		} else {
			 return null;
		}	
	}

	public void setValidationMessages(List<FwMessage> validationMessages) {
		if(validationMessages != null) {
			this.validationMessages = new ArrayList<FwMessage>(validationMessages);
		} else {
			this.validationMessages =  null;
		}
	} 

	public String getPreviousPageID() {
		return previousPageID;
	}

	public void setPreviousPageID(String previousPageID) {
		this.previousPageID = previousPageID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((currentPageID == null) ? 0 : currentPageID.hashCode());
		result = prime * result + ((nextPageAction == null) ? 0 : nextPageAction.hashCode());
		result = prime * result + ((nextPageID == null) ? 0 : nextPageID.hashCode());
		result = prime * result + ((validationMessages == null) ? 0 : validationMessages.hashCode());
		return result;
	}

	
}
