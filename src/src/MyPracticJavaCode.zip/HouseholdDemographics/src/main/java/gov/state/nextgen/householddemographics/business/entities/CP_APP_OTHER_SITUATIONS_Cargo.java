/**
 * 
 */
package gov.state.nextgen.householddemographics.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "CP_APP_OTHER_SITUATIONS")

@IdClass(CP_APP_OTHER_SITUATIONS_Key.class)
public class CP_APP_OTHER_SITUATIONS_Cargo extends AbstractCargo implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	private Integer indv_seq_num; 
	private String work_status;
	private String family_change;
	private String disability;
	private String immigration;
	private String insurance;
	private String custody;
	private String school_attendance;
	private String in_home_support_services;
	private String someone_paid_explain;
	private String other_changes_explain;
	private String smone_paid_cmnt;
	private String othr_change_cmnt;
	private String none_of_these_apply;
	@Transient
	private String OtherSituationsGatepostListCheckBox;
	
	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	/**
	 * @return the work_status
	 */
	public String getWork_status() {
		return work_status;
	}
	/**
	 * @param work_status the work_status to set
	 */
	public void setWork_status(String work_status) {
		this.work_status = work_status;
	}
	/**
	 * @return the family_change
	 */
	public String getFamily_change() {
		return family_change;
	}
	/**
	 * @param family_change the family_change to set
	 */
	public void setFamily_change(String family_change) {
		this.family_change = family_change;
	}
	/**
	 * @return the disability
	 */
	public String getDisability() {
		return disability;
	}
	/**
	 * @param disability the disability to set
	 */
	public void setDisability(String disability) {
		this.disability = disability;
	}
	/**
	 * @return the immigration
	 */
	public String getImmigration() {
		return immigration;
	}
	/**
	 * @param immigration the immigration to set
	 */
	public void setImmigration(String immigration) {
		this.immigration = immigration;
	}
	/**
	 * @return the insurance
	 */
	public String getInsurance() {
		return insurance;
	}
	/**
	 * @param insurance the insurance to set
	 */
	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}
	/**
	 * @return the custody
	 */
	public String getCustody() {
		return custody;
	}
	/**
	 * @param custody the custody to set
	 */
	public void setCustody(String custody) {
		this.custody = custody;
	}
	/**
	 * @return the school_attendance
	 */
	public String getSchool_attendance() {
		return school_attendance;
	}
	/**
	 * @param school_attendance the school_attendance to set
	 */
	public void setSchool_attendance(String school_attendance) {
		this.school_attendance = school_attendance;
	}
	/**
	 * @return the in_home_support_services
	 */
	public String getIn_home_support_services() {
		return in_home_support_services;
	}
	/**
	 * @param in_home_support_services the in_home_support_services to set
	 */
	public void setIn_home_support_services(String in_home_support_services) {
		this.in_home_support_services = in_home_support_services;
	}
	/**
	 * @return the someone_paid_explain
	 */
	public String getSomeone_paid_explain() {
		return someone_paid_explain;
	}
	/**
	 * @param someone_paid_explain the someone_paid_explain to set
	 */
	public void setSomeone_paid_explain(String someone_paid_explain) {
		this.someone_paid_explain = someone_paid_explain;
	}
	/**
	 * @return the other_changes_explain
	 */
	public String getOther_changes_explain() {
		return other_changes_explain;
	}
	/**
	 * @param other_changes_explain the other_changes_explain to set
	 */
	public void setOther_changes_explain(String other_changes_explain) {
		this.other_changes_explain = other_changes_explain;
	}
	/**
	 * @return the smone_paid_cmnt
	 */
	public String getSmone_paid_cmnt() {
		return smone_paid_cmnt;
	}
	/**
	 * @param smone_paid_cmnt the smone_paid_cmnt to set
	 */
	public void setSmone_paid_cmnt(String smone_paid_cmnt) {
		this.smone_paid_cmnt = smone_paid_cmnt;
	}
	/**
	 * @return the othr_change_cmnt
	 */
	public String getOthr_change_cmnt() {
		return othr_change_cmnt;
	}
	/**
	 * @param othr_change_cmnt the othr_change_cmnt to set
	 */
	public void setOthr_change_cmnt(String othr_change_cmnt) {
		this.othr_change_cmnt = othr_change_cmnt;
	}
	
	public String getNone_of_these_apply() {
		return none_of_these_apply;
	}
	public void setNone_of_these_apply(String none_of_these_apply) {
		this.none_of_these_apply = none_of_these_apply;
	}
	@SuppressWarnings("squid:S3776")
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((OtherSituationsGatepostListCheckBox == null) ? 0 : OtherSituationsGatepostListCheckBox.hashCode());
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((custody == null) ? 0 : custody.hashCode());
		result = prime * result + ((disability == null) ? 0 : disability.hashCode());
		result = prime * result + ((family_change == null) ? 0 : family_change.hashCode());
		result = prime * result + ((immigration == null) ? 0 : immigration.hashCode());
		result = prime * result + ((in_home_support_services == null) ? 0 : in_home_support_services.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((insurance == null) ? 0 : insurance.hashCode());
		result = prime * result + ((none_of_these_apply == null) ? 0 : none_of_these_apply.hashCode());
		result = prime * result + ((other_changes_explain == null) ? 0 : other_changes_explain.hashCode());
		result = prime * result + ((othr_change_cmnt == null) ? 0 : othr_change_cmnt.hashCode());
		result = prime * result + ((school_attendance == null) ? 0 : school_attendance.hashCode());
		result = prime * result + ((smone_paid_cmnt == null) ? 0 : smone_paid_cmnt.hashCode());
		result = prime * result + ((someone_paid_explain == null) ? 0 : someone_paid_explain.hashCode());
		result = prime * result + ((work_status == null) ? 0 : work_status.hashCode());
		return result;
	}
	@SuppressWarnings("squid:S3776")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CP_APP_OTHER_SITUATIONS_Cargo other = (CP_APP_OTHER_SITUATIONS_Cargo) obj;
		if (OtherSituationsGatepostListCheckBox == null) {
			if (other.OtherSituationsGatepostListCheckBox != null)
				return false;
		} else if (!OtherSituationsGatepostListCheckBox.equals(other.OtherSituationsGatepostListCheckBox))
			return false;
		if (app_num == null) {
			if (other.app_num != null)
				return false;
		} else if (!app_num.equals(other.app_num))
			return false;
		if (custody == null) {
			if (other.custody != null)
				return false;
		} else if (!custody.equals(other.custody))
			return false;
		if (disability == null) {
			if (other.disability != null)
				return false;
		} else if (!disability.equals(other.disability))
			return false;
		if (family_change == null) {
			if (other.family_change != null)
				return false;
		} else if (!family_change.equals(other.family_change))
			return false;
		if (immigration == null) {
			if (other.immigration != null)
				return false;
		} else if (!immigration.equals(other.immigration))
			return false;
		if (in_home_support_services == null) {
			if (other.in_home_support_services != null)
				return false;
		} else if (!in_home_support_services.equals(other.in_home_support_services))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		if (insurance == null) {
			if (other.insurance != null)
				return false;
		} else if (!insurance.equals(other.insurance))
			return false;
		if (none_of_these_apply == null) {
			if (other.none_of_these_apply != null)
				return false;
		} else if (!none_of_these_apply.equals(other.none_of_these_apply))
			return false;
		if (other_changes_explain == null) {
			if (other.other_changes_explain != null)
				return false;
		} else if (!other_changes_explain.equals(other.other_changes_explain))
			return false;
		if (othr_change_cmnt == null) {
			if (other.othr_change_cmnt != null)
				return false;
		} else if (!othr_change_cmnt.equals(other.othr_change_cmnt))
			return false;
		if (school_attendance == null) {
			if (other.school_attendance != null)
				return false;
		} else if (!school_attendance.equals(other.school_attendance))
			return false;
		if (smone_paid_cmnt == null) {
			if (other.smone_paid_cmnt != null)
				return false;
		} else if (!smone_paid_cmnt.equals(other.smone_paid_cmnt))
			return false;
		if (someone_paid_explain == null) {
			if (other.someone_paid_explain != null)
				return false;
		} else if (!someone_paid_explain.equals(other.someone_paid_explain))
			return false;
		if (work_status == null) {
			if (other.work_status != null)
				return false;
		} else if (!work_status.equals(other.work_status))
			return false;
		return true;
	}
	
	
	
	
}
