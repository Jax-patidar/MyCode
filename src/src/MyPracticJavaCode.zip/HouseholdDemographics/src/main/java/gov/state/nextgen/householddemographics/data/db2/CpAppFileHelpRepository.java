package gov.state.nextgen.householddemographics.data.db2;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Cargo;
import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Collection;
import gov.state.nextgen.householddemographics.business.entities.APP_FILE_HELP_Key;

/**
 * Crud Interface and/or Repository for APP_FILE_HELP_Cargo.
 *
 * Created by @DeloitteUSI team
 * Creation Date Wed Sep 29 11:34:07 IST 2020
 * @authors: @prabhasingh
 */
@NoRepositoryBean
public interface CpAppFileHelpRepository extends CrudRepository<APP_FILE_HELP_Cargo, APP_FILE_HELP_Key>{

	@Query("select c from APP_FILE_HELP_Cargo c where c.app_num = ?1")
	public APP_FILE_HELP_Collection getByAppNum(String appNum); 
	
}
