/**
 * 
 */
package gov.state.nextgen.householddemographics.business.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.householddemographics.business.entities.APP_INDV_Collection;
import gov.state.nextgen.householddemographics.business.entities.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpAppIndvRepository;
import gov.state.nextgen.householddemographics.data.db2.HouseholdRelationshipRepo;

/**
 * @author shtony
 *
 */
@Service("PeopleSummaryBO")
public class PeopleSummaryBO extends AbstractBO{
	
	@Autowired
	private CpAppIndvRepository cpAppIndvRepository;
	
	@Autowired
	private HouseholdRelationshipRepo householdRelationshipRepo;

	public APP_INDV_Collection loadCpAppIndvDetails(String appNum) {
		return cpAppIndvRepository.loadCpAppIndvDetails(Integer.parseInt(appNum));
	}

	public CP_APP_HSHL_RLT_Collection loadCpAppHshlRltDetails(String appNum) {
		return householdRelationshipRepo.loadCpAppHshlRltDetails(Integer.parseInt(appNum));
	}
	

}
