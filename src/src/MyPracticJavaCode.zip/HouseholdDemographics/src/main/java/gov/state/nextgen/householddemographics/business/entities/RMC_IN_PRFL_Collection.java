package gov.state.nextgen.householddemographics.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class acts as a wrapper for one or many cargos of RMC_IN_PRFL
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Thu Oct 11 16:06:37 CDT 2007 Modified By: Modified on: PCR#
 */
public class RMC_IN_PRFL_Collection extends AbstractCollection {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.RMC_IN_PRFL";

    /**
     * returns the PACKAGE name.
     */
    @Override
    public String getPACKAGE() {
        return PACKAGE;
    }

    /**
     * Adds the given cargo to the collection.
     */
    public void addCargo(final RMC_IN_PRFL_Cargo aNewCargo) {
        add(aNewCargo);
    }

    /**
     * Sets cargo array into collection.
     */
    public void setResults(final RMC_IN_PRFL_Cargo[] cbArray) {
        clear();
        for (int i = 0; i < cbArray.length; i++) {
            add(cbArray[i]);
        }
    }

    /**
     * Sets cargo into collection at the given index.
     */
    public void setCargo(final int idx, final RMC_IN_PRFL_Cargo aCargo) {
        set(idx, aCargo);
    }

    /**
     * returns all the values in the Collection as Cargo Array.
     */
    public RMC_IN_PRFL_Cargo[] getResults() {
        final RMC_IN_PRFL_Cargo[] cbArray = new RMC_IN_PRFL_Cargo[size()];
        toArray(cbArray);
        return cbArray;
    }

    /**
     * returns a cargo from the Collection for the given index.
     */
    public RMC_IN_PRFL_Cargo getCargo(final int idx) {
        return (RMC_IN_PRFL_Cargo) get(idx);
    }

    /**
     * Set the cargo array object to the collection.
     */
    @Override
    public void setGenericResults(final Object obj) {
        if (obj instanceof RMC_IN_PRFL_Cargo[]) {
            final RMC_IN_PRFL_Cargo[] cbArray = (RMC_IN_PRFL_Cargo[]) obj;
            setResults(cbArray);
        }
    }
}