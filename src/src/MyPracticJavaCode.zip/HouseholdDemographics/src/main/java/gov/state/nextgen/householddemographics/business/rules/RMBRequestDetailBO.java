package gov.state.nextgen.householddemographics.business.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.householddemographics.business.entities.CpRmbRequestDetails_Collection;
import gov.state.nextgen.householddemographics.data.db2.CpRmbRequestDetailsRepository;

@Service
public class RMBRequestDetailBO extends AbstractBO {
	
	@Autowired
	CpRmbRequestDetailsRepository cpRmbRequestDetailsRepository;
	
	public CpRmbRequestDetails_Collection fetchRMBRqstDetailInfo(Long rmbRequestId) {
		try {
			return cpRmbRequestDetailsRepository.getCpRmbRequestId(rmbRequestId);
		}  catch (final Exception e) {
			throw createFwException(this.getClass().getName(), "fetchRMBRqstInfoByAppNum", e);
		}
	}
}
