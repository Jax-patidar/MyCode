package gov.state.nextgen.householddemographics.data.db2;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import gov.state.nextgen.householddemographics.business.entities.CP_RMC_CHG_SEL_PRFL_Cargo;

@NoRepositoryBean
public interface CategorySelectionProfileRepo extends CrudRepository<CP_RMC_CHG_SEL_PRFL_Cargo,String> {
    List<CP_RMC_CHG_SEL_PRFL_Cargo> findByAppNum(String appNum);
}
