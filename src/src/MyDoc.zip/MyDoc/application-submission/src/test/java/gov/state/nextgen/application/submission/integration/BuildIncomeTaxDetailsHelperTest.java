package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_DEDUCTION;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_INCOME_TAX_DED;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.FinancialExpenseSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.PageCollection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_IN_TAX_DEPENDENTS_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.HouseholdDemographicsPersonDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.CP_APP_IN_TAX_RETURN_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.HouseholdDemographicsProfileDetails;

@ExtendWith(MockitoExtension.class)
public class BuildIncomeTaxDetailsHelperTest {
	
	@InjectMocks
	BuildIncomeTaxDetailsHelper  buildDedHelp;

	@Before
	public void init() throws JsonMappingException, JsonProcessingException {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void buildIncomeTaxExpensesTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		FinancialExpenseSummaryDetails expenseSumm=new FinancialExpenseSummaryDetails();
		PageCollection pageCollection=new PageCollection();
		List<CP_APP_IN_INCOME_TAX_DED> dedExpenseList=new ArrayList<CP_APP_IN_INCOME_TAX_DED>();
		CP_APP_IN_INCOME_TAX_DED appInDed=new CP_APP_IN_INCOME_TAX_DED();
		appInDed.setIndv_seq_num(1);
		appInDed.setExp_type("RH");
		appInDed.setDeductible_self_exp("100.0");
		dedExpenseList.add(appInDed);
		pageCollection.setCP_APP_IN_INCOME_TAX_DED(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialExpenseSummaryDetails(expenseSumm);
		buildDedHelp.buildIncomeTaxExpenses(aggPayLoad,1);
	}
	
	@Test
	public void coverExceptionBuildIncomeTaxExpensesTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		buildDedHelp.buildIncomeTaxExpenses(null,1);
	}
	
	@Test
	public void getTaxDetailsTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		HouseholdDemographicsProfileDetails hhProfileDetails=new HouseholdDemographicsProfileDetails();
		HouseholdDemographicsPersonDetails hhPersonDetails=new HouseholdDemographicsPersonDetails();
		gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.PageCollection pageCollection=new gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.PageCollection();
		gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection pagePersonCollection=new gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection();
		List<CP_APP_IN_TAX_RETURN_Collection> dedExpenseList=new ArrayList<CP_APP_IN_TAX_RETURN_Collection>();
		CP_APP_IN_TAX_RETURN_Collection appInDed=new CP_APP_IN_TAX_RETURN_Collection();
		appInDed.setIndv_seq_num(1);
		appInDed.setSpouse_indv_id(2);
		dedExpenseList.add(appInDed);
		List<CP_APP_IN_TAX_DEPENDENTS_Collection> taxRetDepLst=new ArrayList<CP_APP_IN_TAX_DEPENDENTS_Collection>();
		CP_APP_IN_TAX_DEPENDENTS_Collection taxReturnDep=new CP_APP_IN_TAX_DEPENDENTS_Collection();
		taxReturnDep.setIndv_seq_num(1);
		taxRetDepLst.add(taxReturnDep);
		pageCollection.setCP_APP_IN_TAX_RETURN_Collection(dedExpenseList);
		pagePersonCollection.setCP_APP_IN_TAX_DEPENDENTS_Collection(taxRetDepLst);
		hhProfileDetails.setPageCollection(pageCollection);
		hhPersonDetails.setPageCollection(pagePersonCollection);
		aggPayLoad.setHouseholdDemographicsProfileDetails(hhProfileDetails);
		aggPayLoad.setHouseholdDemographicsPersonDetails(hhPersonDetails);
		buildDedHelp.getTaxDetails(aggPayLoad,1);
	}
	
	@Test
	public void coverExceptionGetTaxDetailsTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		buildDedHelp.getTaxDetails(null,1);
	}
}
