package gov.state.nextgen.application.submission.service;

import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.client.RestTemplate;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;

class HouseholdDemographicsPersonDetailsServiceTest {

	@InjectMocks
	HouseholdDemographicsPersonDetailsService hhPersonDetailsService;

	@Mock
	private RestTemplate restTemplate;

	@Mock
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;

	@Mock
	private LambdaInvokerServiceImpl service;


	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	String responseBodyException = "{\r\n" + "\"serviceContext\": \"financialinformation\"  ,\r\n" + "	\"userDetails\": {\r\n"
			+ "        \"appNumber\": \"1000381218\"\r\n" + "    }  ,\r\n" + "    \"currentActionDetails\": {\r\n"
			+ "        \"pageId\": \"CFFIS\"  ,\r\n" + "        \"pageAction\": \"ABESULoad\" , \r\n"
			+ "        \"pageActionUrl\":null}";

	private String responseBody= "{\r\n"
			+ "    \"serviceContext\": \"householddemographics\",\r\n"
			+ "    \"userDetails\": {\r\n"
			+ "        \"loginUserId\": \"dummyUser\",\r\n"
			+ "        \"appNumber\": \"100032\"\r\n"
			+ "		\r\n"
			+ "    },\r\n"
			+ "    \"currentActionDetails\": {\r\n"
			+ "        \"pageId\": \"ABPIF\",\r\n"
			+ "        \"pageAction\": \"ABPIFNext\",\r\n"
			+ "        \"indvSeqDetails\": {\r\n"
			+ "            \"individualSequence\": \"1\",\r\n"
			+ "            \"categorySequence\": \"1\"\r\n"
			+ "        }\r\n"
			+ "    },\r\n"
			+ "    \"pageCollection\": {\r\n"
			+ "        \"APP_INDV_Collection\": [\r\n"
			+ "            {\r\n"
			+ "                \"fst_nam\": \"Sean\",\r\n"
			+ "                \"mid_nam\": \"H\",\r\n"
			+ "                \"last_nam\": \"Thomas\",\r\n"
			+ "                \"indv_seq_num\": \"1\",\r\n"
			+ "                \"dob_dt\": \"\",\r\n"
			+ "                \"age\": \"36\",\r\n"
			+ "                \"gender\": \"M\",\r\n"
			+ "                \"DESCRIPTION\": \"Sean Thomas (36)\",\r\n"
			+ "                \"CODE\": \"1\",\r\n"
			+ "				\"decease_dt\":\"2021-04-30\",\r\n"
			+ "				\"src_app_ind\":\"TN\"\r\n"
			+ "            }\r\n"
			+ "           \r\n"
			+ "        ],\r\n" +
			"        \r\n" +
			"        \"CP_APP_HSHL_RLT_Collection\": [\r\n" + 
			"			{\r\n" + 
			"                \"user\": null,\r\n" + 
			"                \"cargoName\": null,\r\n" + 
			"                \"rowAction\": null,\r\n" + 
			"                \"adaptRecordId\": null,\r\n" + 
			"                \"delete_reason_cd\": null,\r\n" + 
			"                \"srcAppIndiv\": \"RC\",\r\n" + 
			"                \"change_dt\": null,\r\n" + 
			"                \"care_resp\": null,\r\n" + 
			"                \"rec_cplt_ind\": null,\r\n" + 
			"                \"phy_boe_sep_sw\": null,\r\n" + 
			"                \"change_eff_dt\": null,\r\n" + 
			"                \"pnp_tghr_sw\": \"Y\",\r\n" + 
			"                \"is_tax_dependent_of\": null,\r\n" + 
			"                \"chg_eff_dt\": null,\r\n" + 
			"                \"app_num\": \"337908539\",\r\n" + 
			"                \"ref_indv_seq_num\": \"2\",\r\n" + 
			"                \"src_indv_seq_num\": \"1\",\r\n" + 
			"                \"Rlt_cd\": \"\"\r\n" + 
			"            }\r\n" + 
			"        ]\r\n"  
			+ "    }\r\n"
			+ "}"; 


	@BeforeEach
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testFetchHouseholdDemographicsData() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1234");
		Mockito.when(service.invokeLambda(any(), any(), any())).thenReturn(responseBody);
		hhPersonDetailsService.fetchHouseholdDemographicsPersonDetailsData(aggPayLoad);
	}

	@Test
	public void testFetchHouseholdDemographicsDataException() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1234");
		Mockito.when(service.invokeLambda(any(), any(), any())).thenReturn(responseBodyException);
		hhPersonDetailsService.fetchHouseholdDemographicsPersonDetailsData(aggPayLoad);
	}
}
