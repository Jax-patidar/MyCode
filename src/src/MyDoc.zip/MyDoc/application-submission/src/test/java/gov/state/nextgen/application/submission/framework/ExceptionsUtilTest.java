package gov.state.nextgen.application.submission.framework;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.slf4j.spi.MDCAdapter;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class ExceptionsUtilTest {

	@InjectMocks
	ExceptionsUtil exceptionsUtil;

	@Mock
	Throwable t;

	@Mock
	MDCAdapter mdcAddapter;

	@BeforeEach
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void getExceptionCargomsgTest() {

		String msg = "One or more internal services are unreachable while aggregating data for the given application number::"
				+ "MC" + "::" + "12345";
		try {
			ExceptionsUtil.getExceptionCargo(this.getClass(), new Throwable(msg), "event", null);
		} catch (Exception e) {
		}
	}

	@Test
	void getExceptionCargoTest1() {
		Mockito.when(t.getMessage()).thenReturn(null);
		String n = null;
		try {
			ExceptionsUtil.getExceptionCargo(this.getClass(), new Throwable(n), "event", null);
		} catch (Exception e) {
		}
	}

	@Test
	void getExceptionCargoTest2() {
		String msg = "{\"serviceContext\":\"financialinformation\",\"userDetails\"\\\"serviceContext\\\":\\\"financialinformation\\\",\\\"userDetails\\\":{\\\"appNumber\\\":\\\"107706\\\"},\\\"currentActionDetails\\\":{\\\"pageId\\\":\\\"MCFIN\\\",\\\"pageAction\\\":\\\"MCFINNext\\\",\\\"indvSeqDetails\\\":{}},\\\"pageCollection\\\":{\\\"RMB_RQST_Collection\\\":{\\\"cp_rmb_request_id\\\":\\\"24\\\"},\\\"mode\\\":\\\"MR\\\",\\\"cp_rmb_request_id\\\":\\\"24\\\",\\\"indvIds\\\":[\\\"1\\\"]}:{\"appNumber\":\"107706\"},\"currentActionDetails\":{\"pageId\":\"MCFIN\",\"pageAction\":\"MCFINNext\",\"indvSeqDetails\":{}},\"pageCollection\":{\"RMB_RQST_Collection\":{\"cp_rmb_request_id\":\"24\"},\"mode\":\"MR\",\"cp_rmb_request_id\":\"24\",\"indvIds\":[\"1\"]}}";
		try {
			ExceptionsUtil.getExceptionCargo(this.getClass(), new Throwable(msg), "event", null);
		} catch (Exception e) {
		}
	}
}