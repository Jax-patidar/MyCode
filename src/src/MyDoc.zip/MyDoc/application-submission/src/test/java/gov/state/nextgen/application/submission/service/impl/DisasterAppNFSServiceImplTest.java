package gov.state.nextgen.application.submission.service.impl;

import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;

import gov.state.nextgen.application.submission.service.LambdaInvokerServiceImpl;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;

@RunWith(MockitoJUnitRunner.class)
class DisasterAppNFSServiceImplTest {


	@InjectMocks
	DisasterAppNFSServiceImpl disasterAppNFServiceImp;

	String responseBody="{\r\n" + 
			"\"serviceContext\": \"financialinformation\"  ,\r\n" + 
			"	\"userDetails\": {\r\n" + 
			"        \"appNumber\": \"1000381218\"\r\n" + 
			"    }  ,\r\n" + 
			"    \"currentActionDetails\": {\r\n" + 
			"        \"pageId\": \"DCHHS\"  ,\r\n" + 
			"        \"pageAction\": \"DCHHSLoad\" , \r\n" + 
			"        \"pageActionUrl\":null}";


	String responseBody2="{\r\n"
			+ "    \"currentPageID\": \"DCNFS\",\r\n"
			+ "    \"nextPageID\": null,\r\n"
			+ "    \"nextPageAction\": null,\r\n"
			+ "    \"previousPageID\": null,\r\n"
			+ "    \"validationMessages\": null,\r\n"
			+ "    \"appNum\": \"null\",\r\n"
			+ "    \"pageMap\": {},\r\n"
			+ "    \"pageCollection\": {\r\n"
			+ "        \"CP_OTHER_DETAILS_DISASTER_Collection\": [\r\n"
			+ "            {\r\n"
			+ "				\"app_num\" : \"100064\",\r\n"
			+ "				\"indv_seq_num\" : \"1\",\r\n"
			+ "				\"seq_num\" : \"1\",\r\n"
			+ "				\"src_app_ind\" : \"AB\",\r\n"
			+ "				\"cf_ind\" : \"Y\",\r\n"
			+ "				\"received_amt\" : \"239.93\",\r\n"
			+ "				\"state_cd\" : \"CA\",\r\n"
			+ "				\"county_num\" : \"Kings\"\r\n"
			+ "			},\r\n"
			+ "			{\r\n"
			+ "				\"app_num\" : \"100064\",\r\n"
			+ "				\"indv_seq_num\" : \"1622038536\",\r\n"
			+ "				\"seq_num\" : \"2\",\r\n"
			+ "				\"src_app_ind\" : \"AB\",\r\n"
			+ "				\"cf_ind\" : \"Y\",\r\n"
			+ "				\"received_amt\" : \"63.23\",\r\n"
			+ "				\"state_cd\" : \"CA\",\r\n"
			+ "				\"county_num\" : \"Butte\"\r\n"
			+ "			}\r\n"
			+ "        ],\r\n"
			+ "        \"CP_REPLACEMENT_DISASTER_Collection\": [\r\n"
			+ "            {\r\n"
			+ "				\"app_num\" : \"100064\",\r\n"
			+ "				\"src_app_ind\" : \"AB\",\r\n"
			+ "				\"replacement_amnt\" : \"99.33\",\r\n"
			+ "				\"replacement_cf_ind\" : \"Y\"\r\n"
			+ "			}\r\n"
			+ "        ]\r\n"
			+ "    }\r\n"
			+ "}";

	@Mock
	LambdaInvokerServiceImpl service;


	@BeforeEach
	public void initMocks(){
		MockitoAnnotations.initMocks(this);	
	}

	@Test
	void testFetchDisasterCalNFSData() throws Exception {
		AggregatedPayload aggPayLoad= new AggregatedPayload();
		aggPayLoad.setAppNumber("1234");
		HttpEntity<Object> httpEntity = new HttpEntity<>(aggPayLoad);
		Mockito.when(service.invokeLambda(any(), any(),
				any())).thenReturn(responseBody2);
		disasterAppNFServiceImp.fetchDisasterCalNFSData(aggPayLoad);
	}


	@Test void testFetchDisasterCalNFSDataException() throws Exception {
		AggregatedPayload aggPayLoad= new AggregatedPayload();
		aggPayLoad.setAppNumber("1234"); HttpEntity<Object> httpEntity = new
				HttpEntity<>(aggPayLoad); Mockito.when(service.invokeLambda(any(), any(),
						any())).thenReturn(responseBody);
				disasterAppNFServiceImp.fetchDisasterCalNFSData(aggPayLoad); }

}
