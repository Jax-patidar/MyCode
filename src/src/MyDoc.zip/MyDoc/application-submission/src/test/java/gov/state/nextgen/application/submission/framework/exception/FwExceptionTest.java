package gov.state.nextgen.application.submission.framework.exception;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class FwExceptionTest {

	@InjectMocks
	FwException fwException;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void FwExceptionContructorTest() {
		Throwable throwable = new Throwable();
		FwException fwException = new FwException("message" , throwable);
		FwException fwException1 = new FwException();
		FwException fwException2 = new FwException(throwable);
		FwException fwException3 = new FwException("message");
	}
	
	@Test
	public void getFunctionTest() {
		fwException.getClassID();
		fwException.getExceptionText();
		fwException.getExceptionType();
		fwException.getMessageCode();
		fwException.getMessageText();
		fwException.getMethodID();
		fwException.getParameterText();
		fwException.getServiceDescription();
		fwException.getServiceMessage();
		fwException.getServiceMethod();
		fwException.getServiceName();
		fwException.getStackTraceValue();
		fwException.getShowFullExp();
		fwException.isLoggable();
		fwException.inspectException();
	}
	
	@Test
	public void setFunctionTest() {
		fwException.setShowFullExp("str");
		fwException.setLoggable(true);
		fwException.setServiceName("A");
		fwException.setServiceMethod("B");
		fwException.setServiceMessage("C");
		fwException.setServiceDescription("D");
		fwException.setParameterText("E");
		fwException.setMessageCode("distributed");
		fwException.setExceptionType(2);
		fwException.setClassID("str");
		fwException.setExceptionText("distributed");
		fwException.setMethodID("TestID");
		fwException.setStackTraceValue("TestStackTrace");
		
	}
	
	@Test
	public void setFunctionTest1() {
		fwException.setShowFullExp(null);
		fwException.setLoggable(false);
		fwException.setServiceName(null);
		fwException.setServiceMethod(null);
		fwException.setServiceMessage(null);
		fwException.setServiceDescription(null);
		fwException.setParameterText(null);
		fwException.setMessageCode(null);
		fwException.setClassID(null);
		fwException.setExceptionText(null);
		fwException.setMethodID(null);
		fwException.setStackTraceValue(null);
	}
}
