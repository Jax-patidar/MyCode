package gov.state.nextgen.application.submission.integration;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_RGST_Collection;

@ExtendWith(MockitoExtension.class)
class BuildAddressDetailsHelperTest {
	
	@InjectMocks
	BuildAddressDetailsHelper buildAddressDetailsHelper;

	@Test
	public void buildAddressDetailsTest() throws Exception{
		CP_APP_RGST_Collection rgstInfo = new CP_APP_RGST_Collection();
		rgstInfo.setHshl_l1_adr("12345");
		rgstInfo.setAlt_st_adr("45678");
		buildAddressDetailsHelper.buildAddressDetails(rgstInfo);
	}
	
	@Test
	public void coverExceptionbuildAddressDetails() throws Exception {
		buildAddressDetailsHelper.buildAddressDetails(null);
	}

}
