package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_MED_BILLS;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.FinancialExpenseSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.PageCollection;
import gov.state.nextgen.application.submission.view.payload.Applicant;

class BuildMedicalBillsDetailsHelperTest {

	@InjectMocks
	BuildMedicalBillsDetailsHelper buildMedicalBillsDetailsHelper;
	
	@Test
	void buildMedicalExpensesTest() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialExpenseSummaryDetails expnDetails = new FinancialExpenseSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<CP_APP_IN_MED_BILLS> medExpenseList = new ArrayList<>();
		CP_APP_IN_MED_BILLS medCargo = new CP_APP_IN_MED_BILLS();
		medCargo.setIndv_seq_num(indvSeq);
		medCargo.setPay_freq("OT");
		medCargo.setMa_backdt_mo_1_ind("1");
		medCargo.setMa_backdt_mo_2_ind("1");
		medCargo.setMa_backdt_mo_3_ind("2");
		medExpenseList.add(medCargo);
		pageColl.setCP_APP_IN_MED_BILLS(medExpenseList);
		expnDetails.setPageCollection(pageColl);
		source.setFinancialExpenseSummaryDetails(expnDetails);
		BuildMedicalBillsDetailsHelper.buildMedicalExpenses(source, indvSeq);
		BuildMedicalBillsDetailsHelper.getRetroDetails(source, indvSeq);
	}
	
	@Test
	void buildMedicalExpensesTest2() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialExpenseSummaryDetails expnDetails = new FinancialExpenseSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<CP_APP_IN_MED_BILLS> medExpenseList = new ArrayList<>();
		CP_APP_IN_MED_BILLS medCargo = new CP_APP_IN_MED_BILLS();
		medCargo.setIndv_seq_num(indvSeq);
		medCargo.setPay_freq("OT");
		medCargo.setMa_backdt_mo_1_ind("");
		medCargo.setMa_backdt_mo_2_ind("");
		medCargo.setMa_backdt_mo_3_ind("");
		medExpenseList.add(medCargo);
		pageColl.setCP_APP_IN_MED_BILLS(medExpenseList);
		expnDetails.setPageCollection(pageColl);
		source.setFinancialExpenseSummaryDetails(expnDetails);
		BuildMedicalBillsDetailsHelper.buildMedicalExpenses(source, indvSeq);
		BuildMedicalBillsDetailsHelper.getRetroDetails(source, indvSeq);
	}
	
	@Test
	void buildMedicalExpensesTest1() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialExpenseSummaryDetails expnDetails = new FinancialExpenseSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<CP_APP_IN_MED_BILLS> medExpenseList = new ArrayList<>();
		CP_APP_IN_MED_BILLS medCargo = new CP_APP_IN_MED_BILLS();
		medCargo.setIndv_seq_num(indvSeq);
		medCargo.setMed_bill_type("RH");
		medCargo.setPayment_amt("200");
		medCargo.setReimburse_amt("123");
		medExpenseList.add(medCargo);
		pageColl.setCP_APP_IN_MED_BILLS(medExpenseList);
		expnDetails.setPageCollection(pageColl);
		source.setFinancialExpenseSummaryDetails(expnDetails);
		BuildMedicalBillsDetailsHelper.buildMedicalExpenses(source, indvSeq);
		BuildMedicalBillsDetailsHelper.getRetroDetails(source, indvSeq);
		Applicant app = new Applicant();
		BuildMedicalBillsDetailsHelper.setIhssDetails(source, indvSeq, app);
	}
	
	@Test
	void setIhssDetailsTest() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialExpenseSummaryDetails expnDetails = new FinancialExpenseSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<CP_APP_IN_MED_BILLS> medExpenseList = new ArrayList<>();
		CP_APP_IN_MED_BILLS medCargo = new CP_APP_IN_MED_BILLS();
		medCargo.setIndv_seq_num(indvSeq);
		medCargo.setMed_bill_type("HS");
		medCargo.setPayment_amt("200");
		medCargo.setReimburse_amt("123");
		medExpenseList.add(medCargo);
		pageColl.setCP_APP_IN_MED_BILLS(medExpenseList);
		expnDetails.setPageCollection(pageColl);
		source.setFinancialExpenseSummaryDetails(expnDetails);
		BuildMedicalBillsDetailsHelper.buildMedicalExpenses(source, indvSeq);
		BuildMedicalBillsDetailsHelper.getRetroDetails(source, indvSeq);
		Applicant app = new Applicant();
		BuildMedicalBillsDetailsHelper.setIhssDetails(source, indvSeq, app);
		BuildMedicalBillsDetailsHelper.getRetroDetails(source, 3);
		BuildMedicalBillsDetailsHelper.setIhssDetails(source, 5, app);
	}
	
	@Test
	void buildMedicalExpenseTest() throws Exception {
		BuildMedicalBillsDetailsHelper.buildMedicalExpenses(null, 0);
		BuildMedicalBillsDetailsHelper.getRetroDetails(null, 1);
		BuildMedicalBillsDetailsHelper.setIhssDetails(null, 1, null);
	}
}
