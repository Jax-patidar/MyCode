package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.APP_IN_LQD_ASET_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.FinancialAssetSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.PageCollection;

class BuildLiquidAssetDetailsHelperTest {

	@InjectMocks
	BuildLiquidAssetDetailsHelper buildLiquidAssetDetailsHelper;
	
	@Test
	void buildLiquidAssetsTest() {
		AggregatedPayload source = new AggregatedPayload();
		FinancialAssetSummaryDetails assetDetails = new FinancialAssetSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_LQD_ASET_Collection> liqAssetList = new ArrayList<>();
		APP_IN_LQD_ASET_Collection lqdColl = new APP_IN_LQD_ASET_Collection();
		lqdColl.setIndv_seq_num(1);
		lqdColl.setLqd_aset_typ("NA");
		liqAssetList.add(lqdColl);
		pageColl.setAPP_IN_LQD_ASET_Collection(liqAssetList);
		assetDetails.setPageCollection(pageColl);
		source.setFinancialAssetSummaryDetails(assetDetails);
		BuildLiquidAssetDetailsHelper.buildLiquidAssets(source, 1);
	}
	
	@Test
	void buildLiquidAssetsTest3() {
		AggregatedPayload source = new AggregatedPayload();
		FinancialAssetSummaryDetails assetDetails = new FinancialAssetSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_LQD_ASET_Collection> liqAssetList = new ArrayList<>();
		APP_IN_LQD_ASET_Collection lqdColl = new APP_IN_LQD_ASET_Collection();
		lqdColl.setIndv_seq_num(1);
		lqdColl.setLqd_aset_typ("NA");
		liqAssetList.add(lqdColl);
		pageColl.setAPP_IN_LQD_ASET_Collection(liqAssetList);
		assetDetails.setPageCollection(pageColl);
		source.setFinancialAssetSummaryDetails(assetDetails);
		BuildLiquidAssetDetailsHelper.buildLiquidAssets(source, 3);
	}

	@Test
	void buildLiquidAssetsTest1() {
		AggregatedPayload source = new AggregatedPayload();
		FinancialAssetSummaryDetails assetDetails = new FinancialAssetSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_LQD_ASET_Collection> liqAssetList = new ArrayList<>();
		APP_IN_LQD_ASET_Collection lqdColl = new APP_IN_LQD_ASET_Collection();
		lqdColl.setIndv_seq_num(1);
		lqdColl.setLqd_aset_typ(null);
		liqAssetList.add(lqdColl);
		pageColl.setAPP_IN_LQD_ASET_Collection(liqAssetList);
		assetDetails.setPageCollection(pageColl);
		source.setFinancialAssetSummaryDetails(assetDetails);
		BuildLiquidAssetDetailsHelper.buildLiquidAssets(source, 1);
	}
	
	@Test
	void buildLiquidAssetsTest2() {
		AggregatedPayload source = new AggregatedPayload();
		FinancialAssetSummaryDetails assetDetails = new FinancialAssetSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_LQD_ASET_Collection> liqAssetList = new ArrayList<>();
		APP_IN_LQD_ASET_Collection lqdColl = new APP_IN_LQD_ASET_Collection();
		lqdColl.setIndv_seq_num(1);
		lqdColl.setLqd_aset_typ("DD");
		liqAssetList.add(lqdColl);
		pageColl.setAPP_IN_LQD_ASET_Collection(liqAssetList);
		assetDetails.setPageCollection(pageColl);
		source.setFinancialAssetSummaryDetails(assetDetails);
		BuildLiquidAssetDetailsHelper.buildLiquidAssets(source, 1);
	}
	
	@Test
	void exceptionCoverTest() throws Exception {
		BuildLiquidAssetDetailsHelper.buildLiquidAssets(null, 1);
	}
}
