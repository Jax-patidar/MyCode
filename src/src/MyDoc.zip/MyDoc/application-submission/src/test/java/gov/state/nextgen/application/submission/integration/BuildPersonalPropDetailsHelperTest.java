package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.APP_IN_P_PROP_ASET_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.FinancialAssetSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.PageCollection;

class BuildPersonalPropDetailsHelperTest {

	@InjectMocks
	BuildPersonalPropDetailsHelper buildPersonalPropDetailsHelper;

	@Test
	void buildPersonalPropertiesTest() {
		AggregatedPayload source = new AggregatedPayload();
		FinancialAssetSummaryDetails assetDetails = new FinancialAssetSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_P_PROP_ASET_Collection> personalAsetList = new ArrayList<>();
		APP_IN_P_PROP_ASET_Collection ppropColl = new APP_IN_P_PROP_ASET_Collection();
		ppropColl.setIndv_seq_num(0);
		ppropColl.setPrsn_prop_aset_typ("TN");
		personalAsetList.add(ppropColl);
		pageColl.setAPP_IN_P_PROP_ASET_Collection(personalAsetList);
		assetDetails.setPageCollection(pageColl);
		source.setFinancialAssetSummaryDetails(assetDetails);
		BuildPersonalPropDetailsHelper.buildPersonalProperties(source, 0);
		ppropColl.setPrsn_prop_aset_typ("CS");
		personalAsetList.add(ppropColl);
		pageColl.setAPP_IN_P_PROP_ASET_Collection(personalAsetList);
		assetDetails.setPageCollection(pageColl);
		source.setFinancialAssetSummaryDetails(assetDetails);
		BuildPersonalPropDetailsHelper.buildPersonalProperties(source, 0);
		ppropColl.setPrsn_prop_aset_typ("FF");
		personalAsetList.add(ppropColl);
		pageColl.setAPP_IN_P_PROP_ASET_Collection(personalAsetList);
		assetDetails.setPageCollection(pageColl);
		source.setFinancialAssetSummaryDetails(assetDetails);
		BuildPersonalPropDetailsHelper.buildPersonalProperties(source, 0);
		ppropColl.setPrsn_prop_aset_typ(null);
		personalAsetList.add(ppropColl);
		pageColl.setAPP_IN_P_PROP_ASET_Collection(personalAsetList);
		assetDetails.setPageCollection(pageColl);
		source.setFinancialAssetSummaryDetails(assetDetails);
		BuildPersonalPropDetailsHelper.buildPersonalProperties(source, 0);
		BuildPersonalPropDetailsHelper.buildPersonalProperties(source, 5);
	}

	@Test
	void exceptioncoverTest() throws Exception {
		BuildPersonalPropDetailsHelper.buildPersonalProperties(null, 0);
	}

}
