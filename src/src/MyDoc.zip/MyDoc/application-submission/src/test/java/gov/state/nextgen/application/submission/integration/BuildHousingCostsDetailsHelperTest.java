package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_DEDUCTION;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_HOU_BILLS;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.FinancialExpenseSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.PageCollection;

@ExtendWith(MockitoExtension.class)
public class BuildHousingCostsDetailsHelperTest {

	@InjectMocks
	BuildHousingCostsDetailsHelper  buildDedHelp;

	@Before
	public void init() throws JsonMappingException, JsonProcessingException {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void buildHouseExpensesTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		FinancialExpenseSummaryDetails expenseSumm=new FinancialExpenseSummaryDetails();
		PageCollection pageCollection=new PageCollection();
		List<CP_APP_IN_HOU_BILLS> dedExpenseList=new ArrayList<CP_APP_IN_HOU_BILLS>();
		CP_APP_IN_HOU_BILLS appInDed=new CP_APP_IN_HOU_BILLS();
		appInDed.setIndv_seq_num(1);
		appInDed.setBill_type("RH");
		appInDed.setPaid_amt("100");
		dedExpenseList.add(appInDed);
		pageCollection.setCP_APP_IN_HOU_BILLS(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialExpenseSummaryDetails(expenseSumm);
		buildDedHelp.buildHouseExpenses(aggPayLoad,1);
	}
	
	@Test
	public void coverExceptionBuildHouseExpensesTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		buildDedHelp.buildHouseExpenses(null,1);
	}
}
