package gov.state.nextgen.application.submission.framework.logging;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import gov.state.nextgen.application.submission.framework.logging.FwLogger.Level;


@ExtendWith(SpringExtension.class)
class FwLoggerTest {
	@InjectMocks
	FwLogger fwLogger;
	
	@BeforeEach
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@SuppressWarnings("static-access")
	@Test
	void logTraceTest() { 

		fwLogger.log(getClass(), Level.TRACE, "NA");
		fwLogger.log(getClass(), Level.DEBUG, "NA");
		fwLogger.log(getClass(), Level.INFO, "NA");
		fwLogger.log(getClass(), Level.WARN, "NA");
		fwLogger.log(getClass(), Level.ERROR, "NA");
		assertDoesNotThrow(() -> {fwLogger.log(getClass(), Level.TRACE, "NA");});
	}

	@SuppressWarnings("static-access")
	@Test
	void logThrowableTraceTest() {
		Throwable throwable = new Throwable();
		fwLogger.log(getClass(), Level.TRACE, "NA", throwable);
		fwLogger.log(getClass(), Level.DEBUG, "NA", throwable);
		fwLogger.log(getClass(), Level.INFO, "NA", throwable);
		fwLogger.log(getClass(), Level.WARN, "NA", throwable);
		fwLogger.log(getClass(), Level.ERROR, "NA", throwable);
		assertDoesNotThrow(() -> {fwLogger.log(getClass(), Level.TRACE, "NA", throwable);});
	}
}
