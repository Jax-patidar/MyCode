package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_UEI_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.FinancialIncomeSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.PageCollection;

class BuildOtherPrgDetailsHelperTest {

	@InjectMocks
	BuildOtherPrgDetailsHelper buildOtherPrgDetailsHelper;

	@Test
	void buildOtherPrgDetailsTest() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finIncomeDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_UEI_Collection> ueiList = new ArrayList<APP_IN_UEI_Collection>();
		APP_IN_UEI_Collection ueiColl = new APP_IN_UEI_Collection();
		ueiColl.setIndv_seq_num(indvSeq);
		ueiColl.setUei_typ("SI");
		ueiColl.setFreq_cd("OT");
		ueiList.add(ueiColl);
		pageColl.setaPP_IN_UEI_Collection(ueiList);
		finIncomeDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finIncomeDetails);
		BuildOtherPrgDetailsHelper.buildOtherPrgDetails(source, indvSeq);
		ueiColl.setUei_typ("PA");
		ueiList.add(ueiColl);
		pageColl.setaPP_IN_UEI_Collection(ueiList);
		finIncomeDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finIncomeDetails);
		BuildOtherPrgDetailsHelper.buildOtherPrgDetails(source, indvSeq);
		ueiColl.setUei_typ("FP");
		ueiList.add(ueiColl);
		pageColl.setaPP_IN_UEI_Collection(ueiList);
		finIncomeDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finIncomeDetails);
		BuildOtherPrgDetailsHelper.buildOtherPrgDetails(source, indvSeq);
		ueiColl.setUei_typ("CP");
		ueiColl.setFreq_cd(null);
		ueiList.add(ueiColl);
		pageColl.setaPP_IN_UEI_Collection(ueiList);
		finIncomeDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finIncomeDetails);
		BuildOtherPrgDetailsHelper.buildOtherPrgDetails(source, indvSeq);
		BuildOtherPrgDetailsHelper.buildOtherPrgDetails(source, 4);
	}

	@Test
	void exceptionCoverTest() throws Exception {
		BuildOtherPrgDetailsHelper.buildOtherPrgDetails(null, 4);
	}
}
