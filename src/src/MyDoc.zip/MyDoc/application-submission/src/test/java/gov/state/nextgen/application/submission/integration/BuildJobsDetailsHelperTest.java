package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_EMPL_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_SELFE_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.FinancialIncomeSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.PageCollection;

class BuildJobsDetailsHelperTest {

	@InjectMocks
	BuildJobsDetailsHelper buildJobsDetailsHelper;
	
	@Test
	void buildJobDetailsTest() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		List<APP_IN_SELFE_Collection> seCollList = new ArrayList<APP_IN_SELFE_Collection>();
		APP_IN_SELFE_Collection coll = new APP_IN_SELFE_Collection();
		seCollList.add(coll);
		pageColl.setaPP_IN_SELFE_Collection(seCollList);
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIk_freq("OT");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildJobsDetailsHelper.buildJobDetails(source, indvSeq);
	}
	
	@Test
	void buildJobDetailsTest1() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		List<APP_IN_SELFE_Collection> seCollList = new ArrayList<APP_IN_SELFE_Collection>();
		APP_IN_SELFE_Collection coll = new APP_IN_SELFE_Collection();
		coll.setIndv_seq_num(indvSeq);
		seCollList.add(coll);
		pageColl.setaPP_IN_SELFE_Collection(seCollList);
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEr_phone_num("2334566");
		emplColl.setIk_freq("OT");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildJobsDetailsHelper.buildJobDetails(source, indvSeq);
	}
	
	@Test
	void buildJobDetailsTest2() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEr_phone_num("2334566");
		emplColl.setEmpl_type("IK");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildJobsDetailsHelper.buildJobDetails(source, indvSeq);
	}

	@Test
	void buildJobDetailsTest3() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEr_phone_num(null);
		emplColl.setEmpl_type("OIK");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildJobsDetailsHelper.buildJobDetails(source, indvSeq);
	}
	
	@Test
	void buildjobDetailsExceptionTest() throws Exception {
		BuildJobsDetailsHelper.buildJobDetails(null, 1);
	}
	
	@Test
	void getAddressTest1() {
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setEr_l1_address("12345");
		BuildJobsDetailsHelper.getAddress(emplColl);
	}
	
	@Test
	void getAddressTest2() {
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setEr_city_address("12345");
		BuildJobsDetailsHelper.getAddress(emplColl);
	}
	
	@Test
	void getAddressTest3() {
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setEr_zip_address("12345");
		BuildJobsDetailsHelper.getAddress(emplColl);
	}
	
	@Test
	void getAddressTest4() {
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setEr_st_address("CA");
		BuildJobsDetailsHelper.getAddress(emplColl);
	}
	
	@Test
	void getAddressTest5() {
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		BuildJobsDetailsHelper.getAddress(emplColl);
		BuildJobsDetailsHelper.getNoOfMonths(null);
		BuildJobsDetailsHelper.getNoOfMonths("");
		BuildJobsDetailsHelper.getNoOfMonths("1");
	}
}
