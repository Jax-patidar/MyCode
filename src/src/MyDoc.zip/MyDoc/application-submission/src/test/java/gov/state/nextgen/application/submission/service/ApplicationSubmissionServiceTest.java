package gov.state.nextgen.application.submission.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.payload.ApplicationSubmissionPayload;

@ExtendWith(MockitoExtension.class)
class ApplicationSubmissionServiceTest {

	@InjectMocks
	ApplicationSubmissionService appSubService;

	@Mock
	private PayloadAggregatorService payloadAggregatorService;

	@Mock
	private PayloadTransformService payloadTransformService;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testBuildPayload() {
		AggregatedPayload ap = new AggregatedPayload();
		ap.setAppNumber("app_num");
		Mockito.lenient().when(payloadAggregatorService.buildPayload(ap)).thenReturn(new AggregatedPayload());
		appSubService.buildPayload("app_num");
	}

	@Test
	void testFromAggregatedPayload() throws Exception {
		AggregatedPayload ap = new AggregatedPayload();
		ap.setAppNumber("app_num");
		Mockito.lenient().when(payloadTransformService.fromAggregatedPayload(ap)).thenReturn(new ApplicationSubmissionPayload());
		appSubService.fromAggregatedPayload(ap);
	}

}
