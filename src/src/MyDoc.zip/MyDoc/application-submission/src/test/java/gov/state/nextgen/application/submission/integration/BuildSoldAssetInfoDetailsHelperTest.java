package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.CP_APP_IN_ASET_XFER_Collection;

class BuildSoldAssetInfoDetailsHelperTest {

	@InjectMocks
	BuildSoldAssetInfoDetailsHelper buildSoldAssetInfoDetailsHelper;
		
	@Test
	void buildTransferRecordsTest() {
		List<CP_APP_IN_ASET_XFER_Collection> xferColl = new ArrayList<>();
		CP_APP_IN_ASET_XFER_Collection coll = new CP_APP_IN_ASET_XFER_Collection();
		int indvSeqNum = 1;
		coll.setIndv_seq_num(indvSeqNum);
		xferColl.add(coll);
		BuildSoldAssetInfoDetailsHelper.buildTransferRecords(xferColl, indvSeqNum);
		BuildSoldAssetInfoDetailsHelper.buildTransferRecords(xferColl, 2);
		BuildSoldAssetInfoDetailsHelper.buildTransferRecords(null, 2);
		List<CP_APP_IN_ASET_XFER_Collection> xferCollec = new ArrayList<>();
		BuildSoldAssetInfoDetailsHelper.buildTransferRecords(xferCollec, 2);
	}

}
