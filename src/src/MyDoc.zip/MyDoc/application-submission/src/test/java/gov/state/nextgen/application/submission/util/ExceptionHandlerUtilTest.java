package gov.state.nextgen.application.submission.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ExceptionHandlerUtilTest {
	
	@InjectMocks
	ExceptionHandlerUtil exceptionHandlerUtil;
	
	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testBuildApplicationResponse() {
		ExceptionHandlerUtil.buildApplicationResponse(new Exception(), "400", "Test", "201");
	}

}
