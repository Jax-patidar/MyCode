package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_EMPL_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.FinancialIncomeSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.PageCollection;

class BuildEarnedIncomeDetailsHelperTest {

	@InjectMocks
	BuildEarnedIncomeDetailsHelper buildEarnedIncomeDetailsHelper;
	
	@Test
	public void buildEarnedIncomeTest() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIk_freq("OT");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.buildEarnedIncome(source, indvSeq);
	}
	
	@Test
	public void buildEarnedIncomeTest1() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEmpl_type("IK");
		emplColl.setIk_freq("OT");
		emplColl.setIk_income_type("SD");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.buildEarnedIncome(source, indvSeq);
	}
	
	@Test
	public void buildEarnedIncomeTest3() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEmpl_type("IK");
		emplColl.setIk_income_type("");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.buildEarnedIncome(source, indvSeq);
	}
	
	@Test
	public void buildEarnedIncomeTest2() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEmpl_type("SD");
		emplColl.setIk_income_type("SS");
		emplColl.setIk_freq("OT");
		emplColl.setGross_pay_amt("123");
		emplColl.setPay_freq_cd("OT");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.buildEarnedIncome(source, indvSeq);
	}
	
	@Test
	public void buildEarnedIncomeTest7() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEmpl_type("SS");
		emplColl.setIk_income_type("SS");
		emplColl.setIk_freq("OT");
		emplColl.setGross_pay_amt("123");
		emplColl.setPay_freq_cd("OT");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.buildEarnedIncome(source, indvSeq);
	}
	
	@Test
	public void buildEarnedIncomeTest6() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEmpl_type("CB");
		emplColl.setIk_income_type("SS");
		emplColl.setIk_freq("OT");
		emplColl.setGross_pay_amt("123");
		emplColl.setPay_freq_cd("OT");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.buildEarnedIncome(source, indvSeq);
	}
	
	@Test
	public void buildEarnedIncomeTest5() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEmpl_type("CA");
		emplColl.setIk_income_type("SS");
		emplColl.setIk_freq("OT");
		emplColl.setGross_pay_amt("123");
		emplColl.setPay_freq_cd("OT");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.buildEarnedIncome(source, indvSeq);
	}
	
	@Test
	public void buildEarnedIncomeTest4() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEmpl_type("SD");
		emplColl.setIk_income_type("SS");
		emplColl.setIk_freq("OT");
		emplColl.setGross_pay_amt("123");
		emplColl.setPay_freq_cd("DT");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.buildEarnedIncome(source, indvSeq);
		BuildEarnedIncomeDetailsHelper.getStrikeDetails(source, 2);
	}
	
	@Test
	void coverExceptionTest() throws Exception {
		BuildEarnedIncomeDetailsHelper.buildEarnedIncome(null, 1);
	}

	@Test
	void getStrikeDetailsTest() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEmpl_type("SD");
		emplColl.setIk_income_type("SS");
		emplColl.setIk_freq("OT");
		emplColl.setOn_strike_sw("Y");
		emplColl.setPay_freq_cd("DT");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.getStrikeDetails(source, indvSeq);
	}
	
	@Test
	void getStrikeDetailsTest1() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEmpl_type("CA");
		emplColl.setIk_income_type("SS");
		emplColl.setIk_freq("OT");
		emplColl.setOn_strike_sw("N");
		emplColl.setPay_freq_cd("DT");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.getStrikeDetails(source, indvSeq);
	}
	
	@Test
	void getStrikeDetailsTest2() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_EMPL_Collection> emplList = new ArrayList<>();
		APP_IN_EMPL_Collection emplColl = new APP_IN_EMPL_Collection();
		emplColl.setApp_num("12345");
		emplColl.setIndv_seq_num(indvSeq);
		emplColl.setEmpl_type("CC");
		emplColl.setOn_strike_sw("N");
		emplList.add(emplColl);
		pageColl.setaPP_IN_EMPL_Collection(emplList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildEarnedIncomeDetailsHelper.getStrikeDetails(source, indvSeq);
	}
	
	@Test
	void getStrikeDetailsExceptionTest() throws Exception {
		BuildEarnedIncomeDetailsHelper.getStrikeDetails(null, 1);
	}
}
