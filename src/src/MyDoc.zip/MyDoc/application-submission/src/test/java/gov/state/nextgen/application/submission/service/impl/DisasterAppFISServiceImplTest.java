package gov.state.nextgen.application.submission.service.impl;

import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;

import gov.state.nextgen.application.submission.service.LambdaInvokerServiceImpl;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;

@RunWith(MockitoJUnitRunner.class)
class DisasterAppFISServiceImplTest {

	@InjectMocks
	DisasterAppFISServiceImpl disasterAppServiceImp;
	
	/*
	 * @Mock LambdaInvokerServiceImpl service;
	 */
	
	String responseBody="{\r\n" + 
			"\"serviceContext\": \"financialinformation\"  ,\r\n" + 
			"	\"userDetails\": {\r\n" + 
			"        \"appNumber\": \"1000381218\"\r\n" + 
			"    }  ,\r\n" + 
			"    \"currentActionDetails\": {\r\n" + 
			"        \"pageId\": \"ABESU\"  ,\r\n" + 
			"        \"pageAction\": \"ABESULoad\" , \r\n" + 
			"        \"pageActionUrl\":null}";
	
	String responseBody2="{\r\n"
			+ "    \"currentPageID\": \"DCFIS\",\r\n"
			+ "    \"nextPageID\": null,\r\n"
			+ "    \"nextPageAction\": null,\r\n"
			+ "    \"previousPageID\": null,\r\n"
			+ "    \"validationMessages\": null,\r\n"
			+ "    \"pageCollectionResp\": null,\r\n"
			+ "    \"appNum\": \"null\",\r\n"
			+ "    \"pageMap\": {},\r\n"
			+ "    \"pageCollection\": {\r\n"
			+ "        \"CP_EXPENSE_DISASTER_Collection\": [\r\n"
			+ "            {\r\n"
			+ "                \"user\": null,\r\n"
			+ "                \"cargoName\": null,\r\n"
			+ "                \"rowAction\": null,\r\n"
			+ "                \"adaptRecordId\": null,\r\n"
			+ "                \"delete_reason_cd\": null,\r\n"
			+ "                \"app_num\": \"100064\",\r\n"
			+ "                \"src_app_ind\": \"AB\",\r\n"
			+ "                \"exp_type\": \"HP\",\r\n"
			+ "                \"exp_amt\": 22.67\r\n"
			+ "            },\r\n"
			+ "            {\r\n"
			+ "                \"user\": null,\r\n"
			+ "                \"cargoName\": null,\r\n"
			+ "                \"rowAction\": null,\r\n"
			+ "                \"adaptRecordId\": null,\r\n"
			+ "                \"delete_reason_cd\": null,\r\n"
			+ "                \"app_num\": \"100064\",\r\n"
			+ "                \"src_app_ind\": \"AB\",\r\n"
			+ "                \"exp_type\": \"TS\",\r\n"
			+ "                \"exp_amt\": 58.12\r\n"
			+ "            },\r\n"
			+ "            {\r\n"
			+ "                \"user\": null,\r\n"
			+ "                \"cargoName\": null,\r\n"
			+ "                \"rowAction\": null,\r\n"
			+ "                \"adaptRecordId\": null,\r\n"
			+ "                \"delete_reason_cd\": null,\r\n"
			+ "                \"app_num\": \"100064\",\r\n"
			+ "                \"src_app_ind\": \"AB\",\r\n"
			+ "                \"exp_type\": \"EV\",\r\n"
			+ "                \"exp_amt\": 89.1\r\n"
			+ "            },\r\n"
			+ "            {\r\n"
			+ "                \"user\": null,\r\n"
			+ "                \"cargoName\": null,\r\n"
			+ "                \"rowAction\": null,\r\n"
			+ "                \"adaptRecordId\": null,\r\n"
			+ "                \"delete_reason_cd\": null,\r\n"
			+ "                \"app_num\": \"100064\",\r\n"
			+ "                \"src_app_ind\": \"AB\",\r\n"
			+ "                \"exp_type\": \"FU\",\r\n"
			+ "                \"exp_amt\": 150.0\r\n"
			+ "            },\r\n"
			+ "            {\r\n"
			+ "                \"user\": null,\r\n"
			+ "                \"cargoName\": null,\r\n"
			+ "                \"rowAction\": null,\r\n"
			+ "                \"adaptRecordId\": null,\r\n"
			+ "                \"delete_reason_cd\": null,\r\n"
			+ "                \"app_num\": \"100064\",\r\n"
			+ "                \"src_app_ind\": \"AB\",\r\n"
			+ "                \"exp_type\": \"PB\",\r\n"
			+ "                \"exp_amt\": 64.55\r\n"
			+ "            }\r\n"
			+ "        ],\r\n"
			+ "        \"CP_INCOME_DISASTER_Collection\": [\r\n"
			+ "            {\r\n"
			+ "                \"user\": null,\r\n"
			+ "                \"cargoName\": null,\r\n"
			+ "                \"rowAction\": null,\r\n"
			+ "                \"adaptRecordId\": null,\r\n"
			+ "                \"delete_reason_cd\": null,\r\n"
			+ "                \"app_num\": \"100064\",\r\n"
			+ "                \"src_app_ind\": \"AB\",\r\n"
			+ "                \"additional_info\": \"Self Employment\",\r\n"
			+ "                \"income_amt\": 250.0\r\n"
			+ "            }\r\n"
			+ "        ],\r\n"
			+ "        \"CP_ASSETS_DISASTER_Collection\": [\r\n"
			+ "			{\r\n"
			+ "                \"user\": null,\r\n"
			+ "                \"cargoName\": null,\r\n"
			+ "                \"rowAction\": null,\r\n"
			+ "                \"adaptRecordId\": null,\r\n"
			+ "                \"delete_reason_cd\": null,\r\n"
			+ "                \"app_num\": \"100064\",\r\n"
			+ "                \"src_app_ind\": \"AB\",\r\n"
			+ "                \"cash_in_hand_amt\": 23.22,\r\n"
			+ "                \"saving_account_amt\": 42.87,\r\n"
			+ "                \"checking_account_amt\": 200.86,\r\n"
			+ "                \"other_amt\": 100\r\n"
			+ "            }\r\n"
			+ "		]\r\n"
			+ "    },\r\n"
			+ "    \"beforeCollection\": null\r\n"
			+ "}";
	
	@Mock
	LambdaInvokerServiceImpl lambdaInvokeServiceImpl;
	
	
	 @BeforeEach
	 public void initMocks(){
	   MockitoAnnotations.initMocks(this);	
	 }
	
	@Test
	void fetchDisasterCalFISDataTest() throws Exception {
		AggregatedPayload aggPayLoad= new AggregatedPayload();
		aggPayLoad.setAppNumber("1234");
		HttpEntity<Object> httpEntity = new HttpEntity<>(aggPayLoad);
		Mockito.when(lambdaInvokeServiceImpl.invokeLambda(any(), any(), any())).thenReturn(responseBody);
		disasterAppServiceImp.fetchDisasterCalFISData(aggPayLoad);
	}
	
	@Test
	void fetchDisasterCalFISDataTestException() throws Exception {
		AggregatedPayload aggPayLoad= new AggregatedPayload();
		aggPayLoad.setAppNumber("1234");
		HttpEntity<Object> httpEntity = new HttpEntity<>(aggPayLoad);
		Mockito.when(lambdaInvokeServiceImpl.invokeLambda(any(), any(), any())).thenReturn(responseBody2);
		disasterAppServiceImp.fetchDisasterCalFISData(aggPayLoad);
	}
}
