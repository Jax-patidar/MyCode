package gov.state.nextgen.application.submission.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import gov.state.nextgen.application.submission.framework.exception.ExceptionLogManager;
import gov.state.nextgen.application.submission.service.ApplicationSubmissionService;
import gov.state.nextgen.application.submission.service.DisasterAppTransferService;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.payload.ApplicationSubmissionPayload;


@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class ApplicationSubmissionControllerTest {

	@InjectMocks
	ApplicationSubmissionController applicationSubmittion;
	
	@Mock
	ApplicationSubmissionService applicationSubmissionService;
	
	@Mock
	DisasterAppTransferService disasterAppTransferService;
	
	@Mock
	private ExceptionLogManager exceptionLogManager;
	
	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		MockitoJUnit.rule();
	}

	
	@Test
	public void testAppTransferWithAppNull() throws Exception {
		String message = "{\"formType\": \"DISASTERAPPTRANSFER\"}";
        applicationSubmittion.appTransfer("DCFIN", message);
	}	
	
	@Test
	public void testAppTransfer() throws Exception {
		String message = "{\"appNum\": \"app_num\",\"formType\": \"DISASTERAPPTRANSFER\"}";
		AggregatedPayload aggregatedPayload = new  AggregatedPayload();
		aggregatedPayload.setAppNumber("app_num");
		ApplicationSubmissionPayload applicationSubmission = new ApplicationSubmissionPayload();
		applicationSubmission.setAppNumber("app_num");
		aggregatedPayload.setErrorWhileAccessingInternalServices(true);
		Mockito.when(disasterAppTransferService.fetchDisasterCalFresh("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(disasterAppTransferService.fetchApplicationSubmissionPayload(aggregatedPayload)).thenReturn(applicationSubmission);
        Mockito.when(applicationSubmissionService.buildPayload("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(applicationSubmissionService.fromAggregatedPayload(aggregatedPayload)).thenReturn(applicationSubmission);

        applicationSubmittion.appTransfer("DCFIN", message);
	}

	
	@Test
	public void testAppTransferNotWithDISASTERAPPTRANSFER() throws Exception {
		String message = "{\"appNum\": \"app_num\",\"formType\": \"DISASTERAPTRANSFER\"}";
		AggregatedPayload aggregatedPayload = new  AggregatedPayload();
		aggregatedPayload.setAppNumber("app_num");
		aggregatedPayload.setErrorWhileAccessingInternalServices(false);
		ApplicationSubmissionPayload applicationSubmission = new ApplicationSubmissionPayload();
		applicationSubmission.setAppNumber("app_num");
		applicationSubmission.setContractFulfilled(false);
        Mockito.when(applicationSubmissionService.buildPayload("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(applicationSubmissionService.fromAggregatedPayload(aggregatedPayload)).thenReturn(applicationSubmission);

        applicationSubmittion.appTransfer("DCFIN", message);
	}
	
	@Test
	public void testAppTransferNotWithContractFulfilledTrue() throws Exception {
		String message = "{\"appNum\": \"app_num\",\"formType\": \"DISASTERAPTRANSFER\"}";
		AggregatedPayload aggregatedPayload = new  AggregatedPayload();
		aggregatedPayload.setAppNumber("app_num");
		aggregatedPayload.setErrorWhileAccessingInternalServices(false);
		ApplicationSubmissionPayload applicationSubmission = new ApplicationSubmissionPayload();
		applicationSubmission.setAppNumber("app_num");
		applicationSubmission.setContractFulfilled(true);
        Mockito.when(applicationSubmissionService.buildPayload("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(applicationSubmissionService.fromAggregatedPayload(aggregatedPayload)).thenReturn(applicationSubmission);

        applicationSubmittion.appTransfer("DCFIN", message);
	}
	
	@Test
	public void testAppTransferException() throws Exception {
		String message = "{\"appNum\": \"app_num\",\"formType\": \"DISASTERAPPTRANSFER\"}";
		AggregatedPayload aggregatedPayload = new  AggregatedPayload();
		aggregatedPayload.setErrorWhileAccessingInternalServices(true);
		Mockito.when(disasterAppTransferService.fetchDisasterCalFresh("app_num")).thenReturn(new AggregatedPayload());
		Mockito.when(disasterAppTransferService.fetchApplicationSubmissionPayload(aggregatedPayload)).thenReturn(new ApplicationSubmissionPayload());
        Mockito.when(applicationSubmissionService.buildPayload("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(applicationSubmissionService.fromAggregatedPayload(aggregatedPayload)).thenReturn(new ApplicationSubmissionPayload());

        applicationSubmittion.appTransfer("DCFIN", message);
	}

	
	@Test
	public void testAppTransferJson() throws Exception {
		AggregatedPayload aggregatedPayload = new  AggregatedPayload();
		aggregatedPayload.setAppNumber("app_num");
		aggregatedPayload.setErrorWhileAccessingInternalServices(true);
		ApplicationSubmissionPayload applicationSubmission = new ApplicationSubmissionPayload();
		applicationSubmission.setAppNumber("app_num");
		applicationSubmission.setContractFulfilled(true);
        Mockito.when(applicationSubmissionService.buildPayload("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(applicationSubmissionService.fromAggregatedPayload(aggregatedPayload)).thenReturn(applicationSubmission);

        applicationSubmittion.appTransferJson("app_num");
	}

	@Test
	public void testAppTransferJsonWithContractFulfilledFalse() throws Exception {
		AggregatedPayload aggregatedPayload = new  AggregatedPayload();
		aggregatedPayload.setAppNumber("app_num");
		aggregatedPayload.setErrorWhileAccessingInternalServices(false);
		ApplicationSubmissionPayload applicationSubmission = new ApplicationSubmissionPayload();
		applicationSubmission.setAppNumber("app_num");
		applicationSubmission.setContractFulfilled(false);
        Mockito.when(applicationSubmissionService.buildPayload("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(applicationSubmissionService.fromAggregatedPayload(aggregatedPayload)).thenReturn(applicationSubmission);

        applicationSubmittion.appTransferJson("app_num");
	}
	
	@Test
	public void testAppTransferJsonWithContractFulfilledTrue() throws Exception {
		AggregatedPayload aggregatedPayload = new  AggregatedPayload();
		aggregatedPayload.setAppNumber("app_num");
		aggregatedPayload.setErrorWhileAccessingInternalServices(false);
		ApplicationSubmissionPayload applicationSubmission = new ApplicationSubmissionPayload();
		applicationSubmission.setAppNumber("app_num");
		applicationSubmission.setContractFulfilled(true);
        Mockito.when(applicationSubmissionService.buildPayload("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(applicationSubmissionService.fromAggregatedPayload(aggregatedPayload)).thenReturn(applicationSubmission);

        applicationSubmittion.appTransferJson("app_num");
	}
	
	
	@Test
	public void testCalTransferJson() throws Exception {
		AggregatedPayload aggregatedPayload = new  AggregatedPayload();
		aggregatedPayload.setAppNumber("app_num");
		aggregatedPayload.setErrorWhileAccessingInternalServices(true);
		ApplicationSubmissionPayload applicationSubmission = new ApplicationSubmissionPayload();
		applicationSubmission.setAppNumber("app_num");
		applicationSubmission.setContractFulfilled(true);
		Mockito.when(disasterAppTransferService.fetchDisasterCalFresh("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(disasterAppTransferService.fetchApplicationSubmissionPayload(aggregatedPayload)).thenReturn(applicationSubmission);
        applicationSubmittion.dcalTransferJson("app_num");
	}

	@Test
	public void testCalTransferJsonWithContractFulfilledFalse() throws Exception {
		AggregatedPayload aggregatedPayload = new  AggregatedPayload();
		aggregatedPayload.setAppNumber("app_num");
		aggregatedPayload.setErrorWhileAccessingInternalServices(false);
		ApplicationSubmissionPayload applicationSubmission = new ApplicationSubmissionPayload();
		applicationSubmission.setAppNumber("app_num");
		applicationSubmission.setContractFulfilled(false);
		Mockito.when(disasterAppTransferService.fetchDisasterCalFresh("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(disasterAppTransferService.fetchApplicationSubmissionPayload(aggregatedPayload)).thenReturn(applicationSubmission);
 
        applicationSubmittion.dcalTransferJson("app_num");
	}
	
	@Test
	public void testdCalTransferJsonWithContractFulfilledTrue() throws Exception {
		AggregatedPayload aggregatedPayload = new  AggregatedPayload();
		aggregatedPayload.setAppNumber("app_num");
		aggregatedPayload.setErrorWhileAccessingInternalServices(false);
		ApplicationSubmissionPayload applicationSubmission = new ApplicationSubmissionPayload();
		applicationSubmission.setAppNumber("app_num");
		applicationSubmission.setContractFulfilled(true);
		Mockito.when(disasterAppTransferService.fetchDisasterCalFresh("app_num")).thenReturn(aggregatedPayload);
		Mockito.when(disasterAppTransferService.fetchApplicationSubmissionPayload(aggregatedPayload)).thenReturn(applicationSubmission);
 
        applicationSubmittion.dcalTransferJson("app_num");
	}
}
