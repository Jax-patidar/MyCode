package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_AUTH_REP_Collection;

class BuildAuthRepDetailsTest {
	
	@InjectMocks
	BuildAuthRepDetails buildAuthRepDetails;

	@Test
	public void buildAddressDetailsTest() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		coll.setApp_num("12345");
		coll.setAuth_rep_req_ind("Y");
		coll.setL1_adr("Y");
		coll.setPhn_num("923468394");
		authRepDetails.add(coll);
		buildAuthRepDetails.buildCfAuthRepInfo(authRepDetails);
	}
	
	@Test
	public void buildAddressDetailsTest2() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		coll.setApp_num("12345");
		coll.setAuth_rep_req_ind("Y");
		coll.setL1_adr("Y");
		coll.setPhn_num("");
		authRepDetails.add(coll);
		buildAuthRepDetails.buildCfAuthRepInfo(authRepDetails);
	}
	
	@Test
	public void buildAddressDetailsTest1() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		coll.setApp_num("12345");
		coll.setAuth_rep_req_ind("Y");
		authRepDetails.add(coll);
		buildAuthRepDetails.buildCfAuthRepInfo(authRepDetails);
	}
	
	@Test
	public void buildSnapdAuthRepInfoTest() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		coll.setSnap_auth_rep_ind("Y");
		coll.setL1_adr("Y");
		coll.setPhn_num("949398490");
		authRepDetails.add(coll);
		buildAuthRepDetails.buildSnapdAuthRepInfo(authRepDetails);
	}
	
	@Test
	public void buildSnapdAuthRepInfoTest1() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		coll.setSnap_auth_rep_ind("Y");
		coll.setL1_adr("Y");
		coll.setPhn_num("");
		authRepDetails.add(coll);
		buildAuthRepDetails.buildSnapdAuthRepInfo(authRepDetails);
	}
	
	@Test
	public void buildAuthRepInfoTest1() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		//coll.setAuth_rep_medical_assist_ind("Y");
		authRepDetails.add(coll);
		BuildAuthRepDetails.buildAuthRepInfo(authRepDetails);
	}

	@Test
	public void buildAuthRepInfoTest() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		coll.setAuth_rep_medical_assist_ind("Y");
		coll.setPhn_num("");
		authRepDetails.add(coll);
		BuildAuthRepDetails.buildAuthRepInfo(authRepDetails);
	}
	
	@Test
	public void buildGeneralAuthRepInfoTest() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		coll.setAuth_rep_medical_assist_ind("Y");
		authRepDetails.add(coll);
		BuildAuthRepDetails.buildGeneralAuthRepInfo(authRepDetails);
	}
	
	@Test
	public void buildGeneralAuthRepInfoTest1() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		coll.setAuth_rep_medical_assist_ind("Y");
		coll.setL1_adr("Y");
		coll.setPhn_num("12345");
		authRepDetails.add(coll);
		BuildAuthRepDetails.buildGeneralAuthRepInfo(authRepDetails);
	}
	
	@Test
	public void buildAuthRepInfo3Test() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		coll.setAuth_rep_medical_assist_ind("Y");
		coll.setCbo_rep_id_num("Y");
		authRepDetails.add(coll);
		BuildAuthRepDetails.buildAuthRepInfo3(authRepDetails);
	}
	
	@Test
	public void buildAuthRepInfo3Test1() {
		List<CP_APP_AUTH_REP_Collection> authRepDetails = new ArrayList<>();
		CP_APP_AUTH_REP_Collection coll = new CP_APP_AUTH_REP_Collection();
		coll.setCbo_rep_id_num("Y");
		authRepDetails.add(coll);
		BuildAuthRepDetails.buildAuthRepInfo3(authRepDetails);
	}
}
