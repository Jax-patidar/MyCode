package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.APP_IN_SCHLE_Collection;

class BuildSchoolDetailsHelperTest {

	
	@InjectMocks
	BuildSchoolDetailsHelper buildSchoolDetailsHelper;
	
	@Test
	void buildSchoolDetailsTest() {
		int indvSeqNum = 1;
		List<APP_IN_SCHLE_Collection> sourceSchools = new ArrayList<>();
		APP_IN_SCHLE_Collection schlColl = new APP_IN_SCHLE_Collection();
		schlColl.setIndv_seq_num(indvSeqNum);
		schlColl.setSchool_type_cd("CL");
		sourceSchools.add(schlColl);
		BuildSchoolDetailsHelper.buildSchoolDetails(sourceSchools, indvSeqNum);
	}
	
	@Test
	void buildSchoolDetailsTest1() {
		int indvSeqNum = 1;
		List<APP_IN_SCHLE_Collection> sourceSchools = new ArrayList<>();
		APP_IN_SCHLE_Collection schlColl = new APP_IN_SCHLE_Collection();
		schlColl.setIndv_seq_num(indvSeqNum);
		schlColl.setSchool_type_cd("CL");
		schlColl.setAvg_weekly_work_hrs("0");
		schlColl.setNo_of_units("1");
		sourceSchools.add(schlColl);
		BuildSchoolDetailsHelper.buildSchoolDetails(sourceSchools, indvSeqNum);
		schlColl.setSchool_type_cd(null);
		schlColl.setAvg_weekly_work_hrs(null);
		schlColl.setNo_of_units(null);
		sourceSchools.add(schlColl);
		BuildSchoolDetailsHelper.buildSchoolDetails(sourceSchools, indvSeqNum);
		schlColl.setSchool_type_cd("");
		schlColl.setAvg_weekly_work_hrs("");
		schlColl.setNo_of_units("");
		sourceSchools.add(schlColl);
		BuildSchoolDetailsHelper.buildSchoolDetails(sourceSchools, indvSeqNum);
		BuildSchoolDetailsHelper.buildSchoolDetails(sourceSchools, 2);
		BuildSchoolDetailsHelper.buildSchoolDetails(null, 2);
		List<APP_IN_SCHLE_Collection> source = new ArrayList<>();
		BuildSchoolDetailsHelper.buildSchoolDetails(source, 2);
	}

}
