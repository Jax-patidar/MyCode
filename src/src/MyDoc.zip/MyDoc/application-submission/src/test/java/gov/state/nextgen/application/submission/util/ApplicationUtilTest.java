package gov.state.nextgen.application.submission.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;

@ExtendWith(MockitoExtension.class)
public class ApplicationUtilTest {

	@BeforeEach
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testConvertToRequest() {
		ApplicationUtil.convertToRequest("json","url");
	}

	@Test
	public void testPrepareAWSRequest() throws JsonProcessingException {
		ApplicationUtil.prepareAWSRequest("Post", "HH", "Path", "Dumy");
	}
}
