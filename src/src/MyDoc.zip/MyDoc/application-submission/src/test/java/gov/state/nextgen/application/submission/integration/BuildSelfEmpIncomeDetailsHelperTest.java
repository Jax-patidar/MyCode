package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_SELFE_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.FinancialIncomeSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.PageCollection;

class BuildSelfEmpIncomeDetailsHelperTest {

	@InjectMocks
	BuildSelfEmpIncomeDetailsHelper buildSelfEmpIncomeDetailsHelper;

	@Test
	void buildSelfIncomeTest() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeq = 1;
		BuildSelfEmpIncomeDetailsHelper.buildSelfIncome(source, indvSeq);
		FinancialIncomeSummaryDetails incomeDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_SELFE_Collection> selfList = new ArrayList<>();
		APP_IN_SELFE_Collection selfColl = new APP_IN_SELFE_Collection();
		selfColl.setIndv_seq_num(indvSeq);
		selfColl.setAvg_incm_amt(2.0);
		selfColl.setPay_freq("HM");
		selfColl.setPay_freq("OT");
		selfList.add(selfColl);
		pageColl.setaPP_IN_SELFE_Collection(selfList);
		incomeDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(incomeDetails);
		BuildSelfEmpIncomeDetailsHelper.buildSelfIncome(source, indvSeq);
		selfColl.setPay_freq("SM");
		selfList.add(selfColl);
		pageColl.setaPP_IN_SELFE_Collection(selfList);
		incomeDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(incomeDetails);
		BuildSelfEmpIncomeDetailsHelper.buildSelfIncome(source, indvSeq);
		BuildSelfEmpIncomeDetailsHelper.buildSelfIncome(source, 3);
	}

	@Test
	void buildSelfIncomeNullTest() throws Exception {
		AggregatedPayload source = new AggregatedPayload();
		FinancialIncomeSummaryDetails incomeDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_SELFE_Collection> selfList = new ArrayList<>();
		pageColl.setaPP_IN_SELFE_Collection(selfList);
		incomeDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(incomeDetails);
		BuildSelfEmpIncomeDetailsHelper.buildSelfIncome(source, 2);
		BuildSelfEmpIncomeDetailsHelper.buildSelfIncome(null, 2);
	}

}
