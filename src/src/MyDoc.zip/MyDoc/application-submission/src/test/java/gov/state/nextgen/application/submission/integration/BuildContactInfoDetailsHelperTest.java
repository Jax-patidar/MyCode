package gov.state.nextgen.application.submission.integration;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_RGST_Collection;

class BuildContactInfoDetailsHelperTest {

	@InjectMocks
	BuildContactInfoDetailsHelper buildContactInfoDetailsHelper;
	
	@Test
	void buildPhoneNumberTest() {
		CP_APP_RGST_Collection rgstInfo = new CP_APP_RGST_Collection();
		rgstInfo.setHshl_cell_phn_num("8945895489");
		rgstInfo.setHshl_home_phn_num("6445446664");
		rgstInfo.setHshl_work_phn_num("7535389894");
		BuildContactInfoDetailsHelper.buildPhoneNumber(rgstInfo);
	}
	
	@Test
	void buildPhoneNumberTest2() {
		CP_APP_RGST_Collection rgstInfo = new CP_APP_RGST_Collection();
		rgstInfo.setHshl_cell_phn_num(null);
		rgstInfo.setHshl_home_phn_num(null);
		rgstInfo.setHshl_work_phn_num(null);
		BuildContactInfoDetailsHelper.buildPhoneNumber(rgstInfo);
	}
	
	@Test
	void buildPhoneNumberTest4() {
		CP_APP_RGST_Collection rgstInfo = new CP_APP_RGST_Collection();
		rgstInfo.setHshl_cell_phn_num("");
		rgstInfo.setHshl_home_phn_num("");
		rgstInfo.setHshl_work_phn_num("");
		BuildContactInfoDetailsHelper.buildPhoneNumber(rgstInfo);
	}
	
	@Test
	void buildPhoneNumberTest3() {
		BuildContactInfoDetailsHelper.buildPhoneNumber(null);
	}

}
