package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.APP_IN_R_PROP_ASET_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.FinancialAssetSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_DEDUCTION;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.FinancialExpenseSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.PageCollection;

@ExtendWith(MockitoExtension.class)
public class BuildRealPropertyDetailsHelperTest {

	@InjectMocks
	BuildRealPropertyDetailsHelper  buildDedHelp;

	@Before
	public void init() throws JsonMappingException, JsonProcessingException {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void buildRealPropertyTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		FinancialAssetSummaryDetails expenseSumm=new FinancialAssetSummaryDetails();
		PageCollection pageCollection=new PageCollection();
		List<APP_IN_R_PROP_ASET_Collection> dedExpenseList=new ArrayList<APP_IN_R_PROP_ASET_Collection>();
		APP_IN_R_PROP_ASET_Collection appInDed=new APP_IN_R_PROP_ASET_Collection();
		appInDed.setIndv_seq_num(1);
		appInDed.setProp_fmv_amt("100");
		appInDed.setProp_l1_adr("l1");
		appInDed.setProp_l2_adr("l2");
		appInDed.setProp_sta_adr("St");
		appInDed.setProp_city_adr("City");
		appInDed.setRent_amt("100");
		dedExpenseList.add(appInDed);
		pageCollection.setAPP_IN_R_PROP_ASET_Collection(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialAssetSummaryDetails(expenseSumm);
		buildDedHelp.buildRealProperty(aggPayLoad,1);
	}
	
	@Test
	public void buildRealPropertyTest1() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		FinancialAssetSummaryDetails expenseSumm=new FinancialAssetSummaryDetails();
		PageCollection pageCollection=new PageCollection();
		List<APP_IN_R_PROP_ASET_Collection> dedExpenseList=new ArrayList<APP_IN_R_PROP_ASET_Collection>();
		APP_IN_R_PROP_ASET_Collection appInDed=new APP_IN_R_PROP_ASET_Collection();
		appInDed.setIndv_seq_num(1);
		appInDed.setProp_fmv_amt(null);
		appInDed.setProp_l1_adr("l1");
		appInDed.setProp_l2_adr("l2");
		appInDed.setProp_sta_adr("St");
		appInDed.setProp_city_adr("City");
		appInDed.setHow_often_rent_paid("OT");
		appInDed.setRent_amt("100");
		dedExpenseList.add(appInDed);
		pageCollection.setAPP_IN_R_PROP_ASET_Collection(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialAssetSummaryDetails(expenseSumm);
		buildDedHelp.buildRealProperty(aggPayLoad,1);
		buildDedHelp.buildRealProperty(aggPayLoad,5);
	}
	@Test
	public void coverExceptionBuildRealPropertyTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		buildDedHelp.buildRealProperty(null,1);
		buildDedHelp.getRealProperty(null);
	}
	
	@Test
	public void getAddressTest() {
		APP_IN_R_PROP_ASET_Collection realPropAddrs = new APP_IN_R_PROP_ASET_Collection();
		BuildRealPropertyDetailsHelper.getAddress(null);
		realPropAddrs.setProp_l1_adr("CA");
		BuildRealPropertyDetailsHelper.getAddress(realPropAddrs);
	}
	
	@Test
	public void getAddressTest1() {
		APP_IN_R_PROP_ASET_Collection realPropAddrs = new APP_IN_R_PROP_ASET_Collection();
		realPropAddrs.setProp_city_adr("CA");
		BuildRealPropertyDetailsHelper.getAddress(realPropAddrs);
	}
	
	@Test
	public void getAddressTest2() {
		APP_IN_R_PROP_ASET_Collection realPropAddrs = new APP_IN_R_PROP_ASET_Collection();
		realPropAddrs.setProp_sta_adr("4/123");
		BuildRealPropertyDetailsHelper.getAddress(realPropAddrs);
	}
	
	@Test
	public void getAddressTest3() {
		APP_IN_R_PROP_ASET_Collection realPropAddrs = new APP_IN_R_PROP_ASET_Collection();
		BuildRealPropertyDetailsHelper.getAddress(realPropAddrs);
		realPropAddrs.setProp_zip_adr("4d123");
		BuildRealPropertyDetailsHelper.getAddress(realPropAddrs);
	}
}
