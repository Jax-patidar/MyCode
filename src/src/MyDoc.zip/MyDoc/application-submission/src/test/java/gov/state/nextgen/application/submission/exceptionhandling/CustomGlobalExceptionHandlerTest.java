package gov.state.nextgen.application.submission.exceptionhandling;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.MethodParameter;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.context.request.WebRequest;

@ExtendWith(MockitoExtension.class)
class CustomGlobalExceptionHandlerTest {

	@InjectMocks
	CustomGlobalExceptionHandler customGLobalException;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testHandleMethodArgumentNotValid() {
		  BindingResult bindingResult= new BeanPropertyBindingResult(Object.class, "Test");
		    MethodParameter m = Mockito.mock(MethodParameter.class);
		    MethodArgumentNotValidException methodArgumentNotValidException = new MethodArgumentNotValidException(m, bindingResult);	

			WebRequest webrqst =Mockito.mock(WebRequest.class);
		
		
		
		Exception e = assertThrows(NullPointerException.class,() ->{
			customGLobalException.handleMethodArgumentNotValid(methodArgumentNotValidException, webrqst);
		});
		
		System.out.println(e.getMessage());
		assertTrue(e.getMessage().contains(" is null"));
	}

	@Test
	void testHandleInvalidFormatException() {
		WebRequest webrqst =Mockito.mock(WebRequest.class);
		ApplicationResourceNotFoundException ex =new ApplicationResourceNotFoundException("Hello");
		customGLobalException.handleInvalidFormatException(ex, webrqst);
	}

	@Test
	void testGlobalExceptionHandler() {
		WebRequest webrqst =Mockito.mock(WebRequest.class);
		customGLobalException.globalExceptionHandler(new Exception(), webrqst);  

	}

}
