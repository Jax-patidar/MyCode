package gov.state.nextgen.application.submission.service;

import static org.mockito.ArgumentMatchers.any;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.client.RestTemplate;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;

@ExtendWith(MockitoExtension.class)
class FinancialAssetSummaryDetailsServiceTest {
	
	@InjectMocks
	FinancialAssetSummaryDetailsService finAssetService;
	
	@Mock
	private RestTemplate restTemplate;

	@Mock
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;
	
	@Mock
    private LambdaInvokerServiceImpl service;

	
	String responseBody = "{\r\n" + "\"serviceContext\": \"financialinformation\"  ,\r\n" + "	\"userDetails\": {\r\n"
			+ "        \"appNumber\": \"1000381218\"\r\n" + "    }  ,\r\n" + "    \"currentActionDetails\": {\r\n"
			+ "        \"pageId\": \"CFFIS\"  ,\r\n" + "        \"pageAction\": \"ABESULoad\" , \r\n"
			+ "        \"pageActionUrl\":null}";

	String responseBody2 = "{\r\n" + "  \"currentPageID\": \"CFFIS\",\r\n" + "  \"nextPageID\": null,\r\n"
			+ "  \"nextPageAction\": null,\r\n" + "  \"previousPageID\": null,\r\n"
			+ "  \"validationMessages\": null,\r\n" + "  \"pageCollectionResp\": null,\r\n"
			+ "  \"appNum\": \"null\",\r\n" + "  \"pageMap\": {},\r\n" + "  \"pageCollection\": {\r\n"
			+ "    \"APP_IN_SELFE_Collection\": [\r\n" + "      {\r\n" + "        \"user\": null,\r\n"
			+ "        \"cargoName\": null,\r\n" + "        \"rowAction\": null,\r\n"
			+ "        \"adaptRecordId\": null,\r\n" + "        \"delete_reason_cd\": null,\r\n"
			+ "        \"app_num\": \"100064\",\r\n" + "        \"src_app_ind\": \"AB\",\r\n"
			+ "        \"exp_amt\": 22.67\r\n" + "      }\r\n" + "    ],\r\n" + "    \"APP_IN_EMPL_Collection\": [\r\n"
			+ "      {\r\n" + "        \"user\": null,\r\n" + "        \"cargoName\": null,\r\n"
			+ "        \"rowAction\": null,\r\n" + "        \"adaptRecordId\": null,\r\n"
			+ "        \"delete_reason_cd\": null,\r\n" + "        \"app_num\": \"100064\",\r\n"
			+ "        \"src_app_ind\": \"AB\",\r\n" + "        \"ik_amt\": 250.0\r\n" + "      }\r\n" + "    ],\r\n"
			+ "    \"APP_IN_UEI_Collection\": [\r\n" + "      {\r\n" + "        \"user\": null,\r\n"
			+ "        \"cargoName\": null,\r\n" + "        \"rowAction\": null,\r\n"
			+ "        \"adaptRecordId\": null,\r\n" + "        \"delete_reason_cd\": null,\r\n"
			+ "        \"app_num\": \"100064\",\r\n" + "        \"src_app_ind\": \"AB\"\r\n" + "      }\r\n"
			+ "    ]\r\n" + "  }\r\n" + "}";


	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testFetchFinancialAssetSummaryDetailsData() throws Exception {
		AggregatedPayload aggPayLoad= new AggregatedPayload();
		aggPayLoad.setAppNumber("1234");
		Mockito.when(service.invokeLambda(any(), any(), any())).thenReturn(responseBody);
		finAssetService.fetchFinancialAssetSummaryDetailsData(aggPayLoad);
	
	}

	
	
	@Test 
	public void test_fetchDisasterCalFISDataTestException() throws Exception {
		AggregatedPayload aggPayLoad= new AggregatedPayload();
		aggPayLoad.setAppNumber("1234");
		Mockito.when(service.invokeLambda(any(), any(), any())).thenReturn(responseBody);
		finAssetService.fetchFinancialAssetSummaryDetailsData(aggPayLoad);
	}

	
	@Test
	public void test_fetchDisasterCalFISDataTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1234");
		Mockito.when(service.invokeLambda(any(), any(), any())).thenReturn(responseBody2);
		finAssetService.fetchFinancialAssetSummaryDetailsData(aggPayLoad);
	}


}
