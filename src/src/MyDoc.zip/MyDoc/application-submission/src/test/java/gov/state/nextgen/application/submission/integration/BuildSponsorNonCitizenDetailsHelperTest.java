package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.APP_INDV_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.HouseholdDemographicsPersonDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection;

class BuildSponsorNonCitizenDetailsHelperTest {

	@InjectMocks
	BuildSponsorNonCitizenDetailsHelper buildSponsorNonCitizenDetailsHelper;

	@Test
	void buildSponsorInfoTest() throws Exception {
		AggregatedPayload source = new AggregatedPayload();
		HouseholdDemographicsPersonDetails hhDetails = new HouseholdDemographicsPersonDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_INDV_Collection> indvList = new ArrayList<>();
		APP_INDV_Collection indvColl = new APP_INDV_Collection();
		indvColl.setIndv_seq_num(1);
		indvColl.setSpnsr_ctzn_ind("Y");
		indvColl.setAln_sponser_sw("Y");
		indvColl.setSpnsr_amt("120");
		indvColl.setSpnsr_phn_num("895889569");
		indvList.add(indvColl);
		pageColl.setAPP_INDV_Collection(indvList);
		hhDetails.setPageCollection(pageColl);
		source.setHouseholdDemographicsPersonDetails(hhDetails);
		BuildSponsorNonCitizenDetailsHelper.buildSponsorInfo(source);
		indvColl.setSpnsr_ctzn_ind("N");
		indvColl.setAln_sponser_sw("Y");
		indvColl.setSpnsr_amt(null);
		indvColl.setSpnsr_phn_num(null);
		indvList.add(indvColl);
		pageColl.setAPP_INDV_Collection(indvList);
		hhDetails.setPageCollection(pageColl);
		source.setHouseholdDemographicsPersonDetails(hhDetails);
		BuildSponsorNonCitizenDetailsHelper.buildSponsorInfo(source);
		indvColl.setSpnsr_ctzn_ind("N");
		indvColl.setAln_sponser_sw("Y");
		indvColl.setSpnsr_amt(null);
		indvColl.setSpnsr_phn_num("");
		indvList.add(indvColl);
		pageColl.setAPP_INDV_Collection(indvList);
		hhDetails.setPageCollection(pageColl);
		source.setHouseholdDemographicsPersonDetails(hhDetails);
		BuildSponsorNonCitizenDetailsHelper.buildSponsorInfo(source);
		indvColl.setSpnsr_ctzn_ind("N");
		indvColl.setAln_sponser_sw("N");
		indvList.add(indvColl);
		pageColl.setAPP_INDV_Collection(indvList);
		hhDetails.setPageCollection(pageColl);
		source.setHouseholdDemographicsPersonDetails(hhDetails);
		BuildSponsorNonCitizenDetailsHelper.buildSponsorInfo(source);
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		HouseholdDemographicsPersonDetails hHDetails = new HouseholdDemographicsPersonDetails();
		PageCollection pagecoll = new PageCollection();
		List<APP_INDV_Collection> indvlist = new ArrayList<>();
		pagecoll.setAPP_INDV_Collection(indvlist);
		hHDetails.setPageCollection(pagecoll);
		aggPayLoad.setHouseholdDemographicsPersonDetails(hHDetails);
		BuildSponsorNonCitizenDetailsHelper.buildSponsorInfo(aggPayLoad);
		pagecoll.setAPP_INDV_Collection(null);
		hHDetails.setPageCollection(pagecoll);
		aggPayLoad.setHouseholdDemographicsPersonDetails(hHDetails);
		BuildSponsorNonCitizenDetailsHelper.buildSponsorInfo(aggPayLoad);
		BuildSponsorNonCitizenDetailsHelper.buildSponsorInfo(null);
	}

}
