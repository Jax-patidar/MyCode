package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.APP_IN_R_PROP_ASET_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.APP_IN_VEH_ASET_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.FinancialAssetSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.PageCollection;

@ExtendWith(MockitoExtension.class)
public class BuildVehicleDetailsHelperTest {

	@InjectMocks
	BuildVehicleDetailsHelper buildDedHelp;

	@Before
	public void init() throws JsonMappingException, JsonProcessingException {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void buildvehicleTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		FinancialAssetSummaryDetails expenseSumm = new FinancialAssetSummaryDetails();
		PageCollection pageCollection = new PageCollection();
		List<APP_IN_VEH_ASET_Collection> dedExpenseList = new ArrayList<APP_IN_VEH_ASET_Collection>();
		APP_IN_VEH_ASET_Collection appInDed = new APP_IN_VEH_ASET_Collection();
		appInDed.setIndv_seq_num(1);
		appInDed.setVeh_fmv_amt("100");
		appInDed.setVeh_aset_typ("TN");
		appInDed.setHow_it_is_used("AH");
		APP_IN_VEH_ASET_Collection appInDedN = new APP_IN_VEH_ASET_Collection();
		appInDedN.setIndv_seq_num(1);
		appInDedN.setVeh_fmv_amt("100");
		appInDedN.setVeh_aset_typ("CS");
		appInDedN.setHow_it_is_used("FW");
		appInDedN.setVeh_yr("2001");
		dedExpenseList.add(appInDed);
		dedExpenseList.add(appInDedN);
		pageCollection.setAPP_IN_VEH_ASET_Collection(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialAssetSummaryDetails(expenseSumm);
		buildDedHelp.buildvehicle(aggPayLoad, 1);
	}

	@Test
	public void buildvehicleTest1() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		FinancialAssetSummaryDetails expenseSumm = new FinancialAssetSummaryDetails();
		PageCollection pageCollection = new PageCollection();
		List<APP_IN_VEH_ASET_Collection> dedExpenseList = new ArrayList<APP_IN_VEH_ASET_Collection>();
		APP_IN_VEH_ASET_Collection appInDed = new APP_IN_VEH_ASET_Collection();
		appInDed.setIndv_seq_num(1);
		appInDed.setVeh_fmv_amt("100");
		appInDed.setVeh_aset_typ("TN");
		appInDed.setHow_it_is_used("AH");
		APP_IN_VEH_ASET_Collection appInDedN = new APP_IN_VEH_ASET_Collection();
		appInDedN.setIndv_seq_num(1);
		appInDedN.setVeh_fmv_amt("100");
		appInDedN.setVeh_aset_typ("CS");
		appInDedN.setHow_it_is_used("FW");
		appInDedN.setVeh_yr("2001");
		appInDedN.setMv_owe_amt("32");
		dedExpenseList.add(appInDed);
		dedExpenseList.add(appInDedN);
		pageCollection.setAPP_IN_VEH_ASET_Collection(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialAssetSummaryDetails(expenseSumm);
		buildDedHelp.buildvehicle(aggPayLoad, 1);
		appInDedN.setVeh_owe_amt_ind("12");
		dedExpenseList.add(appInDedN);
		pageCollection.setAPP_IN_VEH_ASET_Collection(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialAssetSummaryDetails(expenseSumm);
		buildDedHelp.buildvehicle(aggPayLoad, 1);
		appInDed.setVeh_owe_amt(1);
		dedExpenseList.add(appInDed);
		pageCollection.setAPP_IN_VEH_ASET_Collection(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialAssetSummaryDetails(expenseSumm);
		buildDedHelp.buildvehicle(aggPayLoad, 1);
		buildDedHelp.buildvehicle(aggPayLoad, 0);
		APP_IN_VEH_ASET_Collection asetColl = new APP_IN_VEH_ASET_Collection();
		asetColl.setMv_owe_amt_ind("1");
		dedExpenseList.add(asetColl);
		pageCollection.setAPP_IN_VEH_ASET_Collection(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialAssetSummaryDetails(expenseSumm);
		buildDedHelp.buildvehicle(aggPayLoad, 1);
	}

	@Test
	public void coverExceptionBuildbuildvehicleTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		buildDedHelp.buildvehicle(null, 1);
	}
}
