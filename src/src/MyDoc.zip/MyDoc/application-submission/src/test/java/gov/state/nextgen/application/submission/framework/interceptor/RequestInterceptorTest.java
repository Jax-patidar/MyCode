package gov.state.nextgen.application.submission.framework.interceptor;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
class RequestInterceptorTest {

	@InjectMocks
	RequestInterceptor requestInterceptor;

	@Mock
	ServletRequest request;

	@Mock
	ServletResponse response;

	@Mock
	FilterChain chain;
	
	@BeforeEach
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void doFilterTest() throws IOException, ServletException {

		HttpServletRequest mockReq = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse mockResp = Mockito.mock(HttpServletResponse.class);
		FilterChain mockFilterChain = Mockito.mock(FilterChain.class);
		Mockito.when(mockReq.getHeader("CORELATION_ID")).thenReturn("Test");
		requestInterceptor.doFilter(mockReq, mockResp, mockFilterChain);

		Mockito.when(mockReq.getHeader("CORELATION_ID")).thenReturn(null);
		requestInterceptor.doFilter(mockReq, mockResp, mockFilterChain);
	}
}
