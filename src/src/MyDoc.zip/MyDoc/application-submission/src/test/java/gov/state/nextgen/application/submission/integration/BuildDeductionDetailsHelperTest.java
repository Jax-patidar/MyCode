package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_DEDUCTION;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.FinancialExpenseSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.PageCollection;
import gov.state.nextgen.application.submission.view.payload.AdditionalServices;

@ExtendWith(MockitoExtension.class)
public class BuildDeductionDetailsHelperTest {

	@InjectMocks
	BuildDeductionDetailsHelper buildDedHelp;

	@Test
	public void buildDeductionExpenses() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		FinancialExpenseSummaryDetails expenseSumm = new FinancialExpenseSummaryDetails();
		PageCollection pageCollection = new PageCollection();
		List<CP_APP_IN_DEDUCTION> dedExpenseList = new ArrayList<CP_APP_IN_DEDUCTION>();
		CP_APP_IN_DEDUCTION appInDed = new CP_APP_IN_DEDUCTION();
		appInDed.setExp_typ("RH");
		appInDed.setExp_amt("10.0");
		appInDed.setCourt_order_pay_amt("100.0");
		dedExpenseList.add(appInDed);
		pageCollection.setCP_APP_IN_DEDUCTION(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialExpenseSummaryDetails(expenseSumm);
		BuildDeductionDetailsHelper.buildDeductionExpenses(aggPayLoad, 1);
	}
	
	@Test
	public void buildDeductionExpensesTest1() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		FinancialExpenseSummaryDetails expenseSumm = new FinancialExpenseSummaryDetails();
		PageCollection pageCollection = new PageCollection();
		List<CP_APP_IN_DEDUCTION> dedExpenseList = new ArrayList<CP_APP_IN_DEDUCTION>();
		CP_APP_IN_DEDUCTION appInDed = new CP_APP_IN_DEDUCTION();
		appInDed.setIndv_seq_num(1);
		appInDed.setExp_typ("RH");
		appInDed.setExp_amt("10.0");
		appInDed.setCourt_order_pay_amt("100.0");
		dedExpenseList.add(appInDed);
		pageCollection.setCP_APP_IN_DEDUCTION(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialExpenseSummaryDetails(expenseSumm);
		BuildDeductionDetailsHelper.buildDeductionExpenses(aggPayLoad, 1);
	}
	
	@Test
	public void buildDeductionExpensesTest2() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		FinancialExpenseSummaryDetails expenseSumm = new FinancialExpenseSummaryDetails();
		PageCollection pageCollection = new PageCollection();
		List<CP_APP_IN_DEDUCTION> dedExpenseList = new ArrayList<CP_APP_IN_DEDUCTION>();
		CP_APP_IN_DEDUCTION appInDed = new CP_APP_IN_DEDUCTION();
		appInDed.setIndv_seq_num(1);
		appInDed.setExp_typ("RH");
		appInDed.setExp_amt(null);
		appInDed.setCourt_order_pay_amt(null);
		appInDed.setPay_freq_cd("OT");
		dedExpenseList.add(appInDed);
		pageCollection.setCP_APP_IN_DEDUCTION(dedExpenseList);
		expenseSumm.setPageCollection(pageCollection);
		aggPayLoad.setFinancialExpenseSummaryDetails(expenseSumm);
		BuildDeductionDetailsHelper.buildDeductionExpenses(aggPayLoad, 1);
	}

	@Test
	public void coverExceptionBuildDeductionExpenses() throws Exception {
		BuildDeductionDetailsHelper.buildDeductionExpenses(null, 1);
	}

	@Test
	public void buildDeductionExpensesTest() {
		AggregatedPayload source = new AggregatedPayload();
		BuildDeductionDetailsHelper.buildDeductionExpenses(source, 1);
		List<CP_APP_IN_DEDUCTION> collecList = new ArrayList<>();
		FinancialExpenseSummaryDetails findetail = new FinancialExpenseSummaryDetails();
		PageCollection pageCollec = new PageCollection();
		pageCollec.setCP_APP_IN_DEDUCTION(collecList);
		findetail.setPageCollection(pageCollec);
		source.setFinancialExpenseSummaryDetails(findetail);
		BuildDeductionDetailsHelper.buildDeductionExpenses(source, 1);
		FinancialExpenseSummaryDetails findetails = new FinancialExpenseSummaryDetails();
		PageCollection pageCollection = new PageCollection();
		List<CP_APP_IN_DEDUCTION> collList = new ArrayList<>();
		CP_APP_IN_DEDUCTION coll = new CP_APP_IN_DEDUCTION();
		coll.setApp_num("12345");
		pageCollection.setCP_APP_IN_DEDUCTION(collList);
		findetails.setPageCollection(pageCollection);
		source.setFinancialExpenseSummaryDetails(findetails);
		BuildDeductionDetailsHelper.buildDeductionExpenses(source, 1);
	}
}
