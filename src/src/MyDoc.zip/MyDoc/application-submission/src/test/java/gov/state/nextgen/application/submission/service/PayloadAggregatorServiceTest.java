package gov.state.nextgen.application.submission.service;

import static org.mockito.ArgumentMatchers.any;

import java.util.concurrent.CompletableFuture;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;

@ExtendWith(MockitoExtension.class)
class PayloadAggregatorServiceTest {


	@InjectMocks
	PayloadAggregatorService payLoadService;

	@Mock
	private FinancialIncomeSummaryDetailsService financialIncomeSummaryDetailsService;
	@Mock
	private FinancialAssetSummaryDetailsService financialAssetSummaryDetailsService;
	@Mock
	private NonFinancialInformationDetailsService nonFinancialInformationDetailsService;
	@Mock
	private FinancialExpenseSummaryDetailsService financialExpenseSummaryDetailsService;
	@Mock
	private HouseholdDemographicsProfileDetailsService householdDemographicsProfileDetailsService;
	@Mock
	private HouseholdDemographicsPersonDetailsService householdDemographicsPersonDetailsService;
	
	
	@BeforeEach
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testBuildPayload() {
		AggregatedPayload aggPayLoad= new AggregatedPayload();
		aggPayLoad.setAppNumber("1234");

		Mockito.when(financialIncomeSummaryDetailsService.fetchFinancialIncomeSummaryDetailsData(any())).thenReturn(CompletableFuture.completedFuture(aggPayLoad));
		Mockito.when(financialAssetSummaryDetailsService.fetchFinancialAssetSummaryDetailsData(any())).thenReturn(CompletableFuture.completedFuture(aggPayLoad));
		Mockito.when(nonFinancialInformationDetailsService.fetchNonFinancialInformationDetailsData(any())).thenReturn(CompletableFuture.completedFuture(aggPayLoad));
		Mockito.when(financialExpenseSummaryDetailsService.fetchFinancialExpenseSummaryDetailsData(any())).thenReturn(CompletableFuture.completedFuture(aggPayLoad));
		Mockito.when(householdDemographicsProfileDetailsService.fetchHouseholdDemographicsProfileDetailsData(any())).thenReturn(CompletableFuture.completedFuture(aggPayLoad));
		Mockito.when(householdDemographicsPersonDetailsService.fetchHouseholdDemographicsPersonDetailsData(any())).thenReturn(CompletableFuture.completedFuture(aggPayLoad));

		payLoadService.buildPayload(Mockito.any());
	}

	
	@Test
	public void testBuildPayloadException() {
		CompletableFuture<AggregatedPayload> sd= null;
		AggregatedPayload aggPayLoad= new AggregatedPayload();
		aggPayLoad.setAppNumber("1234");

		Mockito.when(financialIncomeSummaryDetailsService.fetchFinancialIncomeSummaryDetailsData(any())).thenReturn(sd);
		Mockito.when(financialAssetSummaryDetailsService.fetchFinancialAssetSummaryDetailsData(any())).thenReturn(sd);
		Mockito.when(nonFinancialInformationDetailsService.fetchNonFinancialInformationDetailsData(any())).thenReturn(sd);
		Mockito.when(financialExpenseSummaryDetailsService.fetchFinancialExpenseSummaryDetailsData(any())).thenReturn(sd);
		Mockito.when(householdDemographicsProfileDetailsService.fetchHouseholdDemographicsProfileDetailsData(any())).thenReturn(sd);
		Mockito.when(householdDemographicsPersonDetailsService.fetchHouseholdDemographicsPersonDetailsData(any())).thenReturn(sd);

		payLoadService.buildPayload(aggPayLoad);
	}

}
