package gov.state.nextgen.application.submission.framework.exception;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.sql.Timestamp;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class FwWrappedExceptionTest {
	
	@InjectMocks
	FwWrappedException fwWrappedException;
	
	FwException fwException;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	
	@SuppressWarnings("static-access")
	@Test
	public void FwExceptionTest() {
		Exception e = new Exception();
		fwWrappedException.getStackTraceValue(e);
	}
	
	@Test
	public void FwWrappedExceptionTest() {
		Throwable t = new Throwable();
		FwWrappedException fwException = new FwWrappedException(t);
		FwWrappedException fwException1 = new FwWrappedException();
		FwWrappedException fwException2 = new FwWrappedException("exceptionTest");
//		FwWrappedException.FwWrappedException(t);
//		verify(fwWrappedException,times(1)).FwWrappedException(t);
	}
	
	@Test
	public void getCallingClassIDTest() {
		fwWrappedException.getCallingClassID();
		fwWrappedException.getCallingMethodID();
		fwWrappedException.getCurrentPageID();
		fwWrappedException.getExceptionID();
		fwWrappedException.getFwException();
		fwWrappedException.getIpAddress();
		fwWrappedException.getPreviousPageID();
		fwWrappedException.getPrimaryKeyText();
		fwWrappedException.getUserID();
		fwWrappedException.getWamsLoginID();
	}
	
	@Test
	public void setCallingClassIDTest() {
		fwWrappedException.setCallingClassID(" ");
		fwWrappedException.setCallingMethodID(" ");
		fwWrappedException.setCurrentPageID(" ");
	}
	
	@Test
	public void setExceptionIDTest() {
		Timestamp exceptionTime = new Timestamp(0);
		fwWrappedException.setExceptionID(123);
		fwWrappedException.getExceptionTime();
		fwWrappedException.setExceptionTime(exceptionTime);
		fwWrappedException.setIpAddress("AlpAddress");
		fwWrappedException.setPreviousPageID("ABPRN");
		fwWrappedException.setPrimaryKeyText("PrimaryText");
		fwWrappedException.setUserID("123421");
		fwWrappedException.setWamsLoginID("ASDA");
		fwWrappedException.getAppNum();
		fwWrappedException.setAppNum("1234231");
		fwWrappedException.getUserExceptionId();
		fwWrappedException.setUserExceptionId("23432");
		fwWrappedException.inspectException();
		fwWrappedException.getServerName();
		fwWrappedException.isInTransaction();
		fwWrappedException.setInTransaction(true);
		fwWrappedException.setFwException(fwException);
	}
	
	@Test
	public void setExceptionIDTest1() {
		fwWrappedException.setExceptionTime(null);
		fwWrappedException.setIpAddress(null);
		fwWrappedException.setPreviousPageID(null);
		fwWrappedException.setPrimaryKeyText(null);
		fwWrappedException.setUserID(null);
		fwWrappedException.setWamsLoginID(null);
		fwWrappedException.setAppNum(null);
		fwWrappedException.setAppNum(null);
		fwWrappedException.setUserExceptionId(null);
		fwWrappedException.setInTransaction(true);
		fwWrappedException.setCallingMethodID(null);
		fwWrappedException.setCallingClassID(null);
		fwWrappedException.setCurrentPageID(null);
	}
	
	
}
