package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_SUPPORT_SERVICES_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.HouseholdDemographicsPersonDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.APP_IN_BreastFeeding_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.APP_IN_OUT_ST_BNFT_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.APP_IN_Teen_Parent_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.HouseholdDemographicsProfileDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.PageCollection;
import gov.state.nextgen.application.submission.view.payload.AdditionalServices;
import gov.state.nextgen.application.submission.view.payload.Applicant;

@SuppressWarnings("squid:S2187")
@ExtendWith(MockitoExtension.class)
class BuildAdditionalServicesInfoDetailsHelperTest {

	@InjectMocks
	BuildAdditionalServicesInfoDetailsHelper buildAdditionalServicesInfoDetailsHelper;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void buildTribalTanfDetailsTest() {
		AggregatedPayload source = new AggregatedPayload();
		HouseholdDemographicsProfileDetails hhdetails = new HouseholdDemographicsProfileDetails();
		PageCollection pageCollection = new PageCollection();
		List<APP_IN_OUT_ST_BNFT_Collection> collList = new ArrayList<>();
		APP_IN_OUT_ST_BNFT_Collection coll = new APP_IN_OUT_ST_BNFT_Collection();
		coll.setAge(12);
		coll.setApp_num("12345");
		coll.setSeq_num(1);
		coll.setIndv_seq_num(1);
		collList.add(coll);
		pageCollection.setAPP_IN_OUT_ST_BNFT_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setHouseholdDemographicsProfileDetails(hhdetails);
		int indvSeqNum = 1;
		Applicant tribeIndv = new Applicant();
		BuildAdditionalServicesInfoDetailsHelper.buildTribalTanfDetails(source, indvSeqNum, tribeIndv);
	}

	@Test
	void buildTribalTanfDetailsExceptionTest() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeqNum = 1;
		Applicant tribeIndv = new Applicant();
		BuildAdditionalServicesInfoDetailsHelper.buildTribalTanfDetails(source, indvSeqNum, tribeIndv);
		List<APP_IN_OUT_ST_BNFT_Collection> collecList = new ArrayList<>();
		HouseholdDemographicsProfileDetails hhdetail = new HouseholdDemographicsProfileDetails();
		PageCollection pageCollec = new PageCollection();
		pageCollec.setAPP_IN_OUT_ST_BNFT_Collection(collecList);
		hhdetail.setPageCollection(pageCollec);
		source.setHouseholdDemographicsProfileDetails(hhdetail);
		BuildAdditionalServicesInfoDetailsHelper.buildTribalTanfDetails(source, indvSeqNum, tribeIndv);
		HouseholdDemographicsProfileDetails hhdetails = new HouseholdDemographicsProfileDetails();
		PageCollection pageCollection = new PageCollection();
		List<APP_IN_OUT_ST_BNFT_Collection> collList = new ArrayList<>();
		APP_IN_OUT_ST_BNFT_Collection coll = new APP_IN_OUT_ST_BNFT_Collection();
		coll.setAge(12);
		coll.setApp_num("12345");
		coll.setSeq_num(1);
		collList.add(coll);
		pageCollection.setAPP_IN_OUT_ST_BNFT_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setHouseholdDemographicsProfileDetails(hhdetails);
		BuildAdditionalServicesInfoDetailsHelper.buildTribalTanfDetails(source, indvSeqNum, tribeIndv);
	}

	@Test
	public void buildTeenDetailsTest() {
		AggregatedPayload source = new AggregatedPayload();
		HouseholdDemographicsProfileDetails hhdetails = new HouseholdDemographicsProfileDetails();
		PageCollection pageCollection = new PageCollection();
		List<APP_IN_Teen_Parent_Collection> collList = new ArrayList<>();
		APP_IN_Teen_Parent_Collection coll = new APP_IN_Teen_Parent_Collection();
		coll.setAge(12);
		coll.setApp_num("12345");
		coll.setSeq_num(1);
		coll.setIndv_seq_num(1);
		collList.add(coll);
		pageCollection.setAPP_IN_Teen_Parent_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setHouseholdDemographicsProfileDetails(hhdetails);
		int indvSeqNum = 1;
		Applicant tribeIndv = new Applicant();
		BuildAdditionalServicesInfoDetailsHelper.buildTeenDetails(source, indvSeqNum, tribeIndv);
	}

	@Test
	void buildTeenDetailsExceptionTest() {
		AggregatedPayload source = new AggregatedPayload();
		int indvSeqNum = 1;
		Applicant tribeIndv = new Applicant();
		BuildAdditionalServicesInfoDetailsHelper.buildTeenDetails(source, indvSeqNum, tribeIndv);
		List<APP_IN_Teen_Parent_Collection> collecList = new ArrayList<>();
		HouseholdDemographicsProfileDetails hhdetail = new HouseholdDemographicsProfileDetails();
		PageCollection pageCollec = new PageCollection();
		pageCollec.setAPP_IN_Teen_Parent_Collection(collecList);
		hhdetail.setPageCollection(pageCollec);
		source.setHouseholdDemographicsProfileDetails(hhdetail);
		BuildAdditionalServicesInfoDetailsHelper.buildTeenDetails(source, indvSeqNum, tribeIndv);
		HouseholdDemographicsProfileDetails hhdetails = new HouseholdDemographicsProfileDetails();
		PageCollection pageCollection = new PageCollection();
		List<APP_IN_Teen_Parent_Collection> collList = new ArrayList<>();
		APP_IN_Teen_Parent_Collection coll = new APP_IN_Teen_Parent_Collection();
		coll.setAge(12);
		coll.setApp_num("12345");
		coll.setSeq_num(1);
		collList.add(coll);
		pageCollection.setAPP_IN_Teen_Parent_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setHouseholdDemographicsProfileDetails(hhdetails);
		BuildAdditionalServicesInfoDetailsHelper.buildTeenDetails(source, indvSeqNum, tribeIndv);
	}

	@Test
	public void getAppSupportDetailsTest() {
		AggregatedPayload source = new AggregatedPayload();
		HouseholdDemographicsPersonDetails hhdetails = new HouseholdDemographicsPersonDetails();
		gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection pageCollection = new gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection();
		List<CP_APP_SUPPORT_SERVICES_Collection> collList = new ArrayList<>();
		CP_APP_SUPPORT_SERVICES_Collection coll = new CP_APP_SUPPORT_SERVICES_Collection();
		coll.setApp_num("12345");
		collList.add(coll);
		pageCollection.setCP_APP_SUPPORT_SERVICES_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setHouseholdDemographicsPersonDetails(hhdetails);
		BuildAdditionalServicesInfoDetailsHelper.getAppSupportDetails(source);
	}

	@Test
	public void getAppSupportDetailsTest1() {
		AggregatedPayload source = new AggregatedPayload();
		HouseholdDemographicsPersonDetails hhdetails = new HouseholdDemographicsPersonDetails();
		gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection pageCollection = new gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection();
		List<CP_APP_SUPPORT_SERVICES_Collection> collList = new ArrayList<>();
		CP_APP_SUPPORT_SERVICES_Collection coll = new CP_APP_SUPPORT_SERVICES_Collection();
		coll.setApp_num("12345");
		coll.setFree_vaccines("IS");
		coll.setFamily_planning("FP");
		coll.setChild_health_disability("CH");
		collList.add(coll);
		pageCollection.setCP_APP_SUPPORT_SERVICES_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setHouseholdDemographicsPersonDetails(hhdetails);
		BuildAdditionalServicesInfoDetailsHelper.getAppSupportDetails(source);
	}

	@Test
	void getAppSupportDetailsExceptionTest() {
		AggregatedPayload source = new AggregatedPayload();
		BuildAdditionalServicesInfoDetailsHelper.getAppSupportDetails(source);
		List<CP_APP_SUPPORT_SERVICES_Collection> collecList = new ArrayList<>();
		HouseholdDemographicsPersonDetails hhdetail = new HouseholdDemographicsPersonDetails();
		gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection pageCollec = new gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection();
		pageCollec.setCP_APP_SUPPORT_SERVICES_Collection(collecList);
		hhdetail.setPageCollection(pageCollec);
		source.setHouseholdDemographicsPersonDetails(hhdetail);
		BuildAdditionalServicesInfoDetailsHelper.getAppSupportDetails(source);
		HouseholdDemographicsPersonDetails hhdetails = new HouseholdDemographicsPersonDetails();
		gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection pageCollection = new gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.PageCollection();
		List<CP_APP_SUPPORT_SERVICES_Collection> collList = new ArrayList<>();
		CP_APP_SUPPORT_SERVICES_Collection coll = new CP_APP_SUPPORT_SERVICES_Collection();
		coll.setApp_num("12345");
		pageCollection.setCP_APP_SUPPORT_SERVICES_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setHouseholdDemographicsPersonDetails(hhdetails);
		BuildAdditionalServicesInfoDetailsHelper.getAppSupportDetails(source);
	}

	@Test
	public void getBirthDetailsTest() {
		AggregatedPayload source = new AggregatedPayload();
		AdditionalServices aServicesOut = new AdditionalServices();
		HouseholdDemographicsProfileDetails hhdetails = new HouseholdDemographicsProfileDetails();
		PageCollection pageCollection = new PageCollection();
		List<APP_IN_BreastFeeding_Collection> collList = new ArrayList<>();
		APP_IN_BreastFeeding_Collection coll = new APP_IN_BreastFeeding_Collection();
		coll.setApp_num("12345");
		collList.add(coll);
		pageCollection.setAPP_IN_BreastFeeding_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setHouseholdDemographicsProfileDetails(hhdetails);
		BuildAdditionalServicesInfoDetailsHelper.getBirthDetails(source, aServicesOut);
	}

	@Test
	public void getBirthDetailsTest1() {
		AggregatedPayload source = new AggregatedPayload();
		HouseholdDemographicsProfileDetails hhdetails = new HouseholdDemographicsProfileDetails();
		PageCollection pageCollection = new PageCollection();
		List<APP_IN_BreastFeeding_Collection> collList = new ArrayList<>();
		APP_IN_BreastFeeding_Collection coll = new APP_IN_BreastFeeding_Collection();
		coll.setApp_num("12345");
		collList.add(coll);
		pageCollection.setAPP_IN_BreastFeeding_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setHouseholdDemographicsProfileDetails(hhdetails);
		BuildAdditionalServicesInfoDetailsHelper.getBirthDetails(source, null);
	}

	@Test
	void getBirthDetailsExcepTest() {
		AggregatedPayload source = new AggregatedPayload();
		AdditionalServices aServicesOut = new AdditionalServices();
		BuildAdditionalServicesInfoDetailsHelper.getBirthDetails(source, aServicesOut);
		List<APP_IN_BreastFeeding_Collection> collecList = new ArrayList<>();
		HouseholdDemographicsProfileDetails hhdetail = new HouseholdDemographicsProfileDetails();
		PageCollection pageCollec = new PageCollection();
		pageCollec.setAPP_IN_BreastFeeding_Collection(collecList);
		hhdetail.setPageCollection(pageCollec);
		source.setHouseholdDemographicsProfileDetails(hhdetail);
		BuildAdditionalServicesInfoDetailsHelper.getBirthDetails(source, aServicesOut);
		HouseholdDemographicsProfileDetails hhdetails = new HouseholdDemographicsProfileDetails();
		PageCollection pageCollection = new PageCollection();
		List<APP_IN_BreastFeeding_Collection> collList = new ArrayList<>();
		APP_IN_BreastFeeding_Collection coll = new APP_IN_BreastFeeding_Collection();
		coll.setApp_num("12345");
		pageCollection.setAPP_IN_BreastFeeding_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setHouseholdDemographicsProfileDetails(hhdetails);
		BuildAdditionalServicesInfoDetailsHelper.getBirthDetails(source, aServicesOut);
		BuildAdditionalServicesInfoDetailsHelper.buildAdditionaServices(source);
	}
}
