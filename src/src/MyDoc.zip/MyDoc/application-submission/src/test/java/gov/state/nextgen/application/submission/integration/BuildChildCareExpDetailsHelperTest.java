package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_ABCHS_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.FinancialExpenseSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.PageCollection;

class BuildChildCareExpDetailsHelperTest {

	@InjectMocks
	BuildChildCareExpDetailsHelper buildChildCareExpDetailsHelper;

	@Test
	void buildChildExpensesTest() {
		AggregatedPayload source = new AggregatedPayload();
		FinancialExpenseSummaryDetails hhdetails = new FinancialExpenseSummaryDetails();
		PageCollection pageCollection = new PageCollection();
		List<CP_ABCHS_Collection> collList = new ArrayList<>();
		CP_ABCHS_Collection coll = new CP_ABCHS_Collection();
		coll.setApp_num("12345");
		coll.setIndv_seq_num(1);
		coll.setPay_freq("OT");
		collList.add(coll);
		pageCollection.setCP_ABCHS_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setFinancialExpenseSummaryDetails(hhdetails);
		int indvSeq = 1;
		buildChildCareExpDetailsHelper.buildChildExpenses(source, indvSeq);
	}

	@Test
	void buildChildExpensesTest1() {
		AggregatedPayload source = new AggregatedPayload();
		FinancialExpenseSummaryDetails hhdetails = new FinancialExpenseSummaryDetails();
		PageCollection pageCollection = new PageCollection();
		List<CP_ABCHS_Collection> collList = new ArrayList<>();
		CP_ABCHS_Collection coll = new CP_ABCHS_Collection();
		coll.setApp_num("12345");
		coll.setIndv_seq_num(2);
		coll.setPrvd_type("SS");
		coll.setPay_freq("ST");
		coll.setJnt_pay_resp("Y");
		coll.setJnt_amt_paid("123");
		coll.setDpnd_care_exp_amt("1234");
		collList.add(coll);
		pageCollection.setCP_ABCHS_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setFinancialExpenseSummaryDetails(hhdetails);
		int indvSeq = 2;
		buildChildCareExpDetailsHelper.buildChildExpenses(source, indvSeq);
	}

	@Test
	void buildChildExpensesTest2() {
		AggregatedPayload source = new AggregatedPayload();
		FinancialExpenseSummaryDetails hhdetails = new FinancialExpenseSummaryDetails();
		PageCollection pageCollection = new PageCollection();
		List<CP_ABCHS_Collection> collList = new ArrayList<>();
		CP_ABCHS_Collection coll = new CP_ABCHS_Collection();
		coll.setApp_num("12345");
		coll.setIndv_seq_num(2);
		coll.setPrvd_type("SS");
		coll.setPay_freq("ST");
		coll.setJnt_pay_resp("Y");
		coll.setDpnd_care_exp_amt("1234");
		collList.add(coll);
		pageCollection.setCP_ABCHS_Collection(collList);
		hhdetails.setPageCollection(pageCollection);
		source.setFinancialExpenseSummaryDetails(hhdetails);
		int indvSeq = 2;
		buildChildCareExpDetailsHelper.buildChildExpenses(source, indvSeq);
	}

	@Test
	void getAddressTest1() {
		CP_ABCHS_Collection childEmpColl = new CP_ABCHS_Collection();
		childEmpColl.setApp_num("12345");
		buildChildCareExpDetailsHelper.getAddress(childEmpColl);
	}

	@Test
	void getAddressTest4() {
		buildChildCareExpDetailsHelper.getAddress(null);
	}

	@Test
	void getAddressTest() {
		CP_ABCHS_Collection childEmpColl = new CP_ABCHS_Collection();
		childEmpColl.setPrvd_addr_line1("SE");
		buildChildCareExpDetailsHelper.getAddress(childEmpColl);
	}

	@Test
	void getAddressTest2() {
		CP_ABCHS_Collection childEmpColl = new CP_ABCHS_Collection();
		childEmpColl.setPrvd_addr_city("ER");
		buildChildCareExpDetailsHelper.getAddress(childEmpColl);
	}

	@Test
	void getAddressTest6() {
		CP_ABCHS_Collection childEmpColl = new CP_ABCHS_Collection();
		childEmpColl.setPrvd_addr_zip("ER");
		buildChildCareExpDetailsHelper.getAddress(childEmpColl);
	}

	@Test
	void getAddressTest3() {
		CP_ABCHS_Collection childEmpColl = new CP_ABCHS_Collection();
		childEmpColl.setPrvd_address_state_cd("ER");
		buildChildCareExpDetailsHelper.getAddress(childEmpColl);
	}
}
