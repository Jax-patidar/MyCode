package gov.state.nextgen.application.submission;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class ApplicationSubmissionLambdaApplicationTest {

	@InjectMocks
	ApplicationSubmissionLambdaApplication appSubissionLambda;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testMain() {
		Exception e = assertThrows(IllegalArgumentException.class,() ->{	
			ApplicationSubmissionLambdaApplication.main(new String[]{});
		});
	}

	@Test
	void testObjectMapper() {
		appSubissionLambda.objectMapper();
	}

}
