package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.APP_IN_EMPL_HEALTH_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.APP_IN_HLTH_INS_BNFTS_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.CP_APP_IN_MED_INS_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.CP_APP_IN_WORKERS_COMP_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.NonFinancialInformationDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.PageCollection;
import gov.state.nextgen.application.submission.view.payload.Applicant;

@ExtendWith(MockitoExtension.class)
public class BuildHealthInsurDetailsHelperTest {
	
	@InjectMocks
	BuildHealthInsurDetailsHelper  buildDedHelp;

	@Before
	public void init() throws JsonMappingException, JsonProcessingException {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void buildHealthInsurDetailsTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		NonFinancialInformationDetails nonfin=new NonFinancialInformationDetails();
		List<APP_IN_EMPL_HEALTH_Collection> emplHthLst=new ArrayList<APP_IN_EMPL_HEALTH_Collection>();
		APP_IN_EMPL_HEALTH_Collection emplHthColl=new APP_IN_EMPL_HEALTH_Collection();
		emplHthColl.setIndv_seq_num(1);
		emplHthColl.setEmpl_addrline1("Line1");
		emplHthColl.setEmpl_city("City");
		emplHthColl.setEmpl_state("State");
		emplHthLst.add(emplHthColl);
		List<APP_IN_HLTH_INS_BNFTS_Collection> emplHthInsBftsLst=new ArrayList<APP_IN_HLTH_INS_BNFTS_Collection>();
		APP_IN_HLTH_INS_BNFTS_Collection hlthInsColl=new APP_IN_HLTH_INS_BNFTS_Collection();
		hlthInsColl.setIndv_seq_num(1);
		emplHthInsBftsLst.add(hlthInsColl);
		List<CP_APP_IN_MED_INS_Collection> emplMedInsLst=new ArrayList<CP_APP_IN_MED_INS_Collection>();
		CP_APP_IN_MED_INS_Collection medInsColl=new CP_APP_IN_MED_INS_Collection();
		medInsColl.setIndv_seq_num(1);
		medInsColl.setHealth_ins_type("MC");
		emplMedInsLst.add(medInsColl);
		PageCollection pageCollection=new PageCollection();
		pageCollection.setAPP_IN_EMPL_HEALTH_Collection(emplHthLst);
		pageCollection.setAPP_IN_HLTH_INS_BNFTS_Collection(emplHthInsBftsLst);
		pageCollection.setCP_APP_IN_MED_INS_Collection(emplMedInsLst);
		nonfin.setPageCollection(pageCollection);
		aggPayLoad.setNonFinancialInformationDetails(nonfin);
		buildDedHelp.buildHealthInsurDetails(aggPayLoad,1);
	}
	
	@Test
	public void setThirdPartyIndTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		aggPayLoad.setAppNumber("1000418776");
		NonFinancialInformationDetails nonfin=new NonFinancialInformationDetails();
		List<CP_APP_IN_WORKERS_COMP_Collection> emplHthLst=new ArrayList<CP_APP_IN_WORKERS_COMP_Collection>();
		CP_APP_IN_WORKERS_COMP_Collection emplHthColl=new CP_APP_IN_WORKERS_COMP_Collection();
		emplHthColl.setIndv_seq_num(1);
		emplHthLst.add(emplHthColl);
		PageCollection pageCollection=new PageCollection();
		pageCollection.setCP_APP_IN_WORKERS_COMP_Collection(emplHthLst);
		nonfin.setPageCollection(pageCollection);
		aggPayLoad.setNonFinancialInformationDetails(nonfin);
		Applicant app=new Applicant();
		buildDedHelp.setThirdPartyInd(aggPayLoad,1,app);
	}
	
	@Test
	public void coverExceptionSetThirdPartyIndTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		Applicant app=new Applicant();
		buildDedHelp.setThirdPartyInd(null,1,app);
	}
	
	@Test
	public void coverExceptionBuildHealthInsurDetailsTest() throws Exception {
		AggregatedPayload aggPayLoad = new AggregatedPayload();
		buildDedHelp.buildHealthInsurDetails(null,1);
	}
}
