package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_UEI_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.FinancialIncomeSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.PageCollection;
import gov.state.nextgen.application.submission.view.payload.Applicant;

class BuildUnEarnedIncomeDetailsHelperTest {

	@InjectMocks
	BuildUnEarnedIncomeDetailsHelper buildUnEarnedIncomeDetailsHelper;

	@Test
	void buildUnearnedIncomeTest() {
		AggregatedPayload source = new AggregatedPayload();
		Applicant calLrnIndv = new Applicant();
		int indvSeq = 1;
		FinancialIncomeSummaryDetails finDetails = new FinancialIncomeSummaryDetails();
		PageCollection pageColl = new PageCollection();
		List<APP_IN_UEI_Collection> ueiCollList = new ArrayList<APP_IN_UEI_Collection>();
		APP_IN_UEI_Collection ueiColl = new APP_IN_UEI_Collection();
		ueiColl.setIndv_seq_num(indvSeq);
		ueiColl.setUei_typ("SD");
		ueiColl.setFreq_cd("OT");
		ueiColl.setDt_services_rcvd(null);
		ueiCollList.add(ueiColl);
		pageColl.setaPP_IN_UEI_Collection(ueiCollList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildUnEarnedIncomeDetailsHelper.setCalLrnDetails(source, indvSeq, calLrnIndv);
		BuildUnEarnedIncomeDetailsHelper.buildUnearnedIncome(source, indvSeq);
		BuildUnEarnedIncomeDetailsHelper.buildUnearnedIncome(source, 2);
		ueiColl.setUei_typ("PA");
		ueiColl.setFreq_cd("FT");
		ueiColl.setDt_services_rcvd("SS");
		ueiCollList.add(ueiColl);
		pageColl.setaPP_IN_UEI_Collection(ueiCollList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildUnEarnedIncomeDetailsHelper.buildUnearnedIncome(source, indvSeq);
		BuildUnEarnedIncomeDetailsHelper.setCalLrnDetails(source, indvSeq, calLrnIndv);
		ueiColl.setUei_typ("SS");
		ueiCollList.add(ueiColl);
		pageColl.setaPP_IN_UEI_Collection(ueiCollList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildUnEarnedIncomeDetailsHelper.buildUnearnedIncome(source, indvSeq);
		ueiColl.setUei_typ("GHS");
		ueiCollList.add(ueiColl);
		pageColl.setaPP_IN_UEI_Collection(ueiCollList);
		finDetails.setPageCollection(pageColl);
		source.setFinancialIncomeSummaryDetails(finDetails);
		BuildUnEarnedIncomeDetailsHelper.buildUnearnedIncome(source, indvSeq);
		BuildUnEarnedIncomeDetailsHelper.setCalLrnDetails(source, 3, calLrnIndv);
	}
	
	@Test
	void exceptionCoverTest() throws Exception {
		BuildUnEarnedIncomeDetailsHelper.buildUnearnedIncome(null, 1);
		BuildUnEarnedIncomeDetailsHelper.setCalLrnDetails(null, 1, null);
	}
}
