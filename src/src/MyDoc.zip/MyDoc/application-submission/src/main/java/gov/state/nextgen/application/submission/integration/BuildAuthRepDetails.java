package gov.state.nextgen.application.submission.integration;

import java.util.List;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.application.submission.view.payload.Address;
import gov.state.nextgen.application.submission.view.payload.CalFreshAuthRep;
import gov.state.nextgen.application.submission.view.payload.CfBeneficiaryDetails;
import gov.state.nextgen.application.submission.view.payload.HlthRepInfo;
import gov.state.nextgen.application.submission.view.payload.HtlhRepAgentInfo;
import gov.state.nextgen.application.submission.view.payload.HtlhRepSig;
import gov.state.nextgen.application.submission.view.payload.PhoneNumber;

public class BuildAuthRepDetails {
	
	private BuildAuthRepDetails() {}
	
	public static CfBeneficiaryDetails buildCfAuthRepInfo(List<CP_APP_AUTH_REP_Collection> authRepDetails) {
		
		CfBeneficiaryDetails cfAuthRep = null;
		if(authRepDetails != null && !authRepDetails.isEmpty()) {

			CP_APP_AUTH_REP_Collection authRepIn = authRepDetails.stream().filter(
					auth->ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(auth.getAuth_rep_req_ind())).findFirst().orElse(null);

			if(authRepIn!=null) {
				cfAuthRep = new CfBeneficiaryDetails();
				cfAuthRep.setFirstName(authRepIn.getAuth_rep_fst_nam());
				cfAuthRep.setLastName(authRepIn.getAuth_rep_last_nam());
				Address address = null;
				if(authRepIn.getL1_adr() != null) {
					address = new Address();
					address.setAddrType(ApplicationSubmissionConstants.STR_PH);
					address.setStreetAddr1(authRepIn.getL1_adr());
					address.setStreetAddr2(authRepIn.getL2_adr());
					address.setCityName(authRepIn.getCity_adr());
					address.setZipCode(authRepIn.getZip_adr());
					address.setState(authRepIn.getSta_adr());
					cfAuthRep.setAddress(address);
				}

				if(authRepIn.getPhn_num() != null && !ApplicationSubmissionConstants.STR_EMPT.equals(authRepIn.getPhn_num().trim())) {
					PhoneNumber phNum = new PhoneNumber();
					phNum.setNumber(authRepIn.getPhn_num());
					cfAuthRep.setPhoneNumber(phNum);
				}
			}

		}

		return cfAuthRep;

	}

	
	public static CalFreshAuthRep buildSnapdAuthRepInfo(List<CP_APP_AUTH_REP_Collection> authRepDetails) {
		
		CalFreshAuthRep snapAuthRep = null;
		if(authRepDetails != null && !authRepDetails.isEmpty()) {

			CP_APP_AUTH_REP_Collection authRepIn = authRepDetails.stream().filter(
					auth->ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(auth.getSnap_auth_rep_ind())).findFirst().orElse(null);

			if(authRepIn!=null) {
				snapAuthRep = new CalFreshAuthRep();
				snapAuthRep.setFirstName(authRepIn.getAuth_rep_fst_nam());
				snapAuthRep.setLastName(authRepIn.getAuth_rep_last_nam());
				snapAuthRep.setPickupEBTCard(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(authRepIn.getBrg_crd_rcv_ind())?true:false);//NOSONAR
				Address address = null;
				if(authRepIn.getL1_adr() != null) {
					address = new Address();
					address.setAddrType(ApplicationSubmissionConstants.STR_PH);
					address.setStreetAddr1(authRepIn.getL1_adr());
					address.setStreetAddr2(authRepIn.getL2_adr());
					address.setCityName(authRepIn.getCity_adr());
					address.setZipCode(authRepIn.getZip_adr());
					address.setState(authRepIn.getSta_adr());
					snapAuthRep.setAddress(address);
				}

				if(authRepIn.getPhn_num() != null && !ApplicationSubmissionConstants.STR_EMPT.equals(authRepIn.getPhn_num().trim())) {
					PhoneNumber phNum = new PhoneNumber();
					phNum.setNumber(authRepIn.getPhn_num());
					snapAuthRep.setPhoneNumber(phNum);
				}
			}

		}

		return snapAuthRep;

	}
	
	public static HtlhRepSig buildAuthRepInfo(List<CP_APP_AUTH_REP_Collection> authRepDetails) {

		HtlhRepSig authRepOut = null;

		if(authRepDetails != null && !authRepDetails.isEmpty()) {

			CP_APP_AUTH_REP_Collection authRepIn = authRepDetails.stream().filter(
					auth->ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(auth.getAuth_rep_medical_assist_ind())).findFirst().orElse(null);

			if(authRepIn!=null) {
				authRepOut = new HtlhRepSig();
				authRepOut.setFirstName(authRepIn.getAppl_fst_nam());
				authRepOut.setLastName(authRepIn.getAppl_last_nam());
				authRepOut.setDate(authRepIn.getAppl_esign_dt());
			}

		}

		return authRepOut;
	}
	
	
	public static HlthRepInfo buildGeneralAuthRepInfo(List<CP_APP_AUTH_REP_Collection> authRepDetails) {

		HlthRepInfo authRepOut = null;

		if(authRepDetails != null && !authRepDetails.isEmpty()) {

			CP_APP_AUTH_REP_Collection authRepIn = authRepDetails.stream().filter(
					auth->ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(auth.getAuth_rep_medical_assist_ind())).findFirst().orElse(null);
			if(authRepIn !=null) {
				authRepOut = new HlthRepInfo();

				authRepOut.setFirstName(authRepIn.getAuth_rep_fst_nam());
				authRepOut.setLastName(authRepIn.getAuth_rep_last_nam());
				authRepOut.setOrganizationName(authRepIn.getAuth_rep_org_nam());
				authRepOut.setIdNumber(authRepIn.getAuth_rep_id_num());

				Address address = null;
				if(authRepIn.getL1_adr() != null) {
					address = new Address();
					address.setAddrType(ApplicationSubmissionConstants.STR_PH);
					address.setStreetAddr1(authRepIn.getL1_adr());
					address.setStreetAddr2(authRepIn.getL2_adr());
					address.setCityName(authRepIn.getCity_adr());
					address.setZipCode(authRepIn.getZip_adr());
					address.setState(authRepIn.getSta_adr());
					authRepOut.setAddress(address);
				}

				if(authRepIn.getPhn_num() != null && !ApplicationSubmissionConstants.STR_EMPT.equals(authRepIn.getPhn_num().trim())) {
					PhoneNumber phNum = new PhoneNumber();
					phNum.setNumber(authRepIn.getPhn_num());
					authRepOut.setPhoneNumber(phNum);
				}

			}
		}

		return authRepOut;

	}


public static HtlhRepAgentInfo buildAuthRepInfo3(List<CP_APP_AUTH_REP_Collection> authRepDetails) {
	
	HtlhRepAgentInfo authRepOut = null;
		
		if(authRepDetails != null && !authRepDetails.isEmpty()) {
			
			CP_APP_AUTH_REP_Collection authRepIn = authRepDetails.stream().filter(
					auth->ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(auth.getAuth_rep_medical_assist_ind())).findFirst().orElse(null);
			
			if(authRepIn !=null && (authRepIn.getCbo_rep_id_num() != null || authRepIn.getCbo_rep_org_name() != null)) {
				authRepOut = new HtlhRepAgentInfo();			
				authRepOut.setFirstName(authRepIn.getAuth_rep_fst_nam());
				authRepOut.setMiddleName(authRepIn.getAppl_mid_init());
				authRepOut.setSuffix(authRepIn.getAuth_rep_suffix_nam());
				authRepOut.setLastName(authRepIn.getAuth_rep_last_nam());
				authRepOut.setOrganizationName(authRepIn.getCbo_rep_org_name());
				authRepOut.setIdNumber(authRepIn.getCbo_rep_id_num());
				authRepOut.setAppStartDate(authRepIn.getApp_start_dt());
			}
		}
		return authRepOut;
		
	}
}
