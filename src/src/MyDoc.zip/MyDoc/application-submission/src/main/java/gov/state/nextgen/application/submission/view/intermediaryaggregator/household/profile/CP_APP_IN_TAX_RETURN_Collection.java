package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class CP_APP_IN_TAX_RETURN_Collection {
	private int indv_seq_num;
	private int spouse_indv_id;
	private String jointly_file_sw;
	private String spouse_first_name;
	private String spouse_mid_nam;
	private String spouse_last_name;
	private String tax_dependent_resp;
	private String tax_auto_enrl_ind;
	private int years;
	private String primary_filer_sw;
	
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public int getSpouse_indv_id() {
		return spouse_indv_id;
	}
	public void setSpouse_indv_id(int spouse_indv_id) {
		this.spouse_indv_id = spouse_indv_id;
	}
	public String getJointly_file_sw() {
		return jointly_file_sw;
	}
	public void setJointly_file_sw(String jointly_file_sw) {
		this.jointly_file_sw = jointly_file_sw;
	}
	public String getSpouse_first_name() {
		return spouse_first_name;
	}
	public void setSpouse_first_name(String spouse_first_name) {
		this.spouse_first_name = spouse_first_name;
	}
	public String getSpouse_mid_nam() {
		return spouse_mid_nam;
	}
	public void setSpouse_mid_nam(String spouse_mid_nam) {
		this.spouse_mid_nam = spouse_mid_nam;
	}
	public String getSpouse_last_name() {
		return spouse_last_name;
	}
	public void setSpouse_last_name(String spouse_last_name) {
		this.spouse_last_name = spouse_last_name;
	}
	public String getTax_dependent_resp() {
		return tax_dependent_resp;
	}
	public void setTax_dependent_resp(String tax_dependent_resp) {
		this.tax_dependent_resp = tax_dependent_resp;
	}
	public String getTax_auto_enrl_ind() {
		return tax_auto_enrl_ind;
	}
	public void setTax_auto_enrl_ind(String tax_auto_enrl_ind) {
		this.tax_auto_enrl_ind = tax_auto_enrl_ind;
	}
	public int getYears() {
		return years;
	}
	public void setYears(int years) {
		this.years = years;
	}
	public String getPrimary_filer_sw() {
		return primary_filer_sw;
	}
	public void setPrimary_filer_sw(String primary_filer_sw) {
		this.primary_filer_sw = primary_filer_sw;
	}
	
}
