package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class CP_APP_IN_SCHOOL_Collection {
	
	private String enrl_stat_cd;
	
	private String nt_enrl_stat_desc;
	
	private int indv_seq_num;

	public String getEnrl_stat_cd() {
		return enrl_stat_cd;
	}

	public void setEnrl_stat_cd(String enrl_stat_cd) {
		this.enrl_stat_cd = enrl_stat_cd;
	}

	public String getNt_enrl_stat_desc() {
		return nt_enrl_stat_desc;
	}

	public void setNt_enrl_stat_desc(String nt_enrl_stat_desc) {
		this.nt_enrl_stat_desc = nt_enrl_stat_desc;
	}

	public int getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	
	

}
