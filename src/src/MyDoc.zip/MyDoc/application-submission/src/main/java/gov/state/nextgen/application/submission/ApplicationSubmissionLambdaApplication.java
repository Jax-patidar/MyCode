package gov.state.nextgen.application.submission;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class ApplicationSubmissionLambdaApplication {

    public static void main(String[] args) {
        new SpringApplicationBuilder().sources(ApplicationSubmissionLambdaApplication.class)
                .profiles(System.getenv(ApplicationSubmissionConstants.ENVIRONMENT)).build().run(args);
    }

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper().disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
    }


}
