package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class HouseholdSituation {
	@JsonIgnore
	private boolean propertyDamageInd;
	@JsonIgnore
	private boolean additionalExpensesInd;
	@JsonIgnore
	private boolean foodPlanningInd;
	@JsonIgnore
	private boolean incomeDelayInd;
	@JsonIgnore
	private boolean moneyInBankInd;
	@JsonIgnore
	private boolean currentFoodStampParticipantInd;
	@JsonIgnore
	private String county;
	@JsonIgnore
	private String stateCode;

	public boolean isPropertyDamageInd() {
		return propertyDamageInd;
	}

	public void setPropertyDamageInd(boolean propertyDamageInd) {
		this.propertyDamageInd = propertyDamageInd;
	}

	public boolean isAdditionalExpensesInd() {
		return additionalExpensesInd;
	}

	public void setAdditionalExpensesInd(boolean additionalExpensesInd) {
		this.additionalExpensesInd = additionalExpensesInd;
	}

	public boolean isFoodPlanningInd() {
		return foodPlanningInd;
	}

	public void setFoodPlanningInd(boolean foodPlanningInd) {
		this.foodPlanningInd = foodPlanningInd;
	}

	public boolean isIncomeDelayInd() {
		return incomeDelayInd;
	}

	public void setIncomeDelayInd(boolean incomeDelayInd) {
		this.incomeDelayInd = incomeDelayInd;
	}

	public boolean isMoneyInBankInd() {
		return moneyInBankInd;
	}

	public void setMoneyInBankInd(boolean moneyInBankInd) {
		this.moneyInBankInd = moneyInBankInd;
	}

	public boolean isCurrentFoodStampParticipantInd() {
		return currentFoodStampParticipantInd;
	}

	public void setCurrentFoodStampParticipantInd(boolean currentFoodStampParticipantInd) {
		this.currentFoodStampParticipantInd = currentFoodStampParticipantInd;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
}
