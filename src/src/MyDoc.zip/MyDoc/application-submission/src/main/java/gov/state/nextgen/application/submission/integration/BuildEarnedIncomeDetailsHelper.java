package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_EMPL_Collection;
import gov.state.nextgen.application.submission.view.payload.Income;
import gov.state.nextgen.application.submission.view.payload.Strike;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BuildEarnedIncomeDetailsHelper {

    private BuildEarnedIncomeDetailsHelper() {
    }

    public static List<Income> buildEarnedIncome(AggregatedPayload source, int indvSeq) {//NOSONAR
        Income income = null;
        List<Income> incomeList = new ArrayList<>();

        try {
            List<APP_IN_EMPL_Collection> indvEarnedIncomeList = source.getFinancialIncomeSummaryDetails().getPageCollection().getaPP_IN_EMPL_Collection();
            if (indvEarnedIncomeList != null && !indvEarnedIncomeList.isEmpty()) {
                for (APP_IN_EMPL_Collection empIncome : indvEarnedIncomeList) {
                    if (indvSeq == empIncome.getIndv_seq_num()) {

                        if (ApplicationSubmissionConstants.STR_IK.equalsIgnoreCase(empIncome.getEmpl_type())) {
                            income = new Income();
                            List<String> typeCatList = BuildIncomeTypeMappingHelper.getUnEarnTypeCatCd(empIncome.getIk_income_type());
                            if (!typeCatList.isEmpty()) {
                                income.setCategory(typeCatList.get(0));
                                if (!ApplicationSubmissionConstants.STR_EMPT.equals(typeCatList.get(1)))
                                    income.setTypeCode(typeCatList.get(1));
                            }

                            income.setAmount(empIncome.getIk_amt_each_month());
                            String freqCd = empIncome.getIk_freq();
                            if (ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
                                income.setFrequency(ApplicationSubmissionConstants.FRE_II);
                            } else {
                                income.setFrequency(freqCd);
                            }
                            income.setSourceName(empIncome.getIk_empl_name());
                            income.setBeginDate(empIncome.getIk_job_start_dt());
                            income.setEndDate(empIncome.getIk_job_end_dt());
                            income.setContinueToReceiveIncomeInd(ApplicationUtil.translateBoolean(empIncome.getExpected_to_cont_resp()));//NOSONAR
                            income.setInKindFreeOrWork(empIncome.getIk_recv_type());
                            income.setInKindItemVal(empIncome.getIk_amt_each_month());
                            income.setInKindGivenBy(empIncome.getIk_empl_name());
                            income.setIncomeNotExpectedToContExpl(null);
                            income.setState(null);
                            income.setCounty(null);
                            income.setServicesReceived(null);
                            income.setEstimatedValueofService(null);
                            incomeList.add(income);
                        } else if (!ApplicationSubmissionConstants.STR_CB.equalsIgnoreCase(empIncome.getEmpl_type()) &&
                                !ApplicationSubmissionConstants.STR_CA.equalsIgnoreCase(empIncome.getEmpl_type())) {
                            income = new Income();
                            List<String> typeCatList = BuildIncomeTypeMappingHelper.getUnEarnTypeCatCd(empIncome.getEmpl_type());
                            if (!typeCatList.isEmpty()) {
                                income.setCategory(typeCatList.get(0));
                                if (!ApplicationSubmissionConstants.STR_EMPT.equals(typeCatList.get(1)))
                                    income.setTypeCode(typeCatList.get(1));
                            }
                            if (empIncome.getGross_pay_amt() != null) {
                                double incomeAmt = Double.parseDouble(empIncome.getGross_pay_amt());
                                income.setAmount(incomeAmt);
                            }
                            String freqCd = empIncome.getPay_freq_cd();
                            if (ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
                                income.setFrequency(ApplicationSubmissionConstants.FRE_II);
                            } else {
                                income.setFrequency(freqCd);
                            }
                            income.setSourceName(empIncome.getEr_name());
                            income.setBeginDate(empIncome.getEmpl_begin_dt());
                            income.setEndDate(empIncome.getEmpl_end_dt());
                            income.setContinueToReceiveIncomeInd(ApplicationUtil.translateBoolean(empIncome.getExpected_to_cont_resp()));//NOSONAR
                            income.setIncomeNotExpectedToContExpl(null);
                            income.setState(empIncome.getEr_st_address());
                            incomeList.add(income);
                        }
                    }
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildEarnedIncomeDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while loading Earned Income Details - " + e.getMessage());
        }
        return incomeList;
    }


    public static List<Strike> getStrikeDetails(AggregatedPayload source, int indvSeqNum) {
        Strike strikeDetail = null;
        List<Strike> strikeList = new ArrayList<>();
        List<APP_IN_EMPL_Collection> indvsStrikeList = null;
        try {
            indvsStrikeList = source.getFinancialIncomeSummaryDetails().getPageCollection().getaPP_IN_EMPL_Collection();

            if (indvsStrikeList != null && !indvsStrikeList.isEmpty()) {
                List<APP_IN_EMPL_Collection> indvStrikeList = indvsStrikeList.stream().filter(indvStrike -> indvSeqNum == indvStrike.getIndv_seq_num()).collect(Collectors.toList());

                for (APP_IN_EMPL_Collection strike : indvStrikeList) {
                    if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(strike.getOn_strike_sw())
                            || ApplicationSubmissionConstants.STR_CA.equalsIgnoreCase(strike.getEmpl_type())) {
                        strikeDetail = new Strike();
                        strikeDetail.setBeginDate(strike.getStrike_begin_dt());
                        strikeDetail.setEmployerName(strike.getEr_name());
                        strikeDetail.setLastPayDate(strike.getLast_payck_dt());
                        strikeDetail.setReasonForStrike(strike.getEmpl_addtl_info());
                        strikeList.add(strikeDetail);
                    }
                }
            }

        } catch (Exception e) {
            FwLogger.log(BuildEarnedIncomeDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while loading Strike Details - " + e.getMessage());
        }
        return strikeList;
    }
}