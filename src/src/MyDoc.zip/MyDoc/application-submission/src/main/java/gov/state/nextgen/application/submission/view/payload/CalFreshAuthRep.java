package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class CalFreshAuthRep {
	private String firstName;
	private String lastName;
	private PhoneNumber phoneNumber;
	private Address address;
	private Boolean pickupEBTCard;
	private Boolean pickupEBTToPurchaseFood;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public PhoneNumber getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(PhoneNumber phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Boolean isPickupEBTCard() {
		return pickupEBTCard;
	}

	public void setPickupEBTCard(Boolean pickupEBTCard) {
		this.pickupEBTCard = pickupEBTCard;
	}

	public Boolean isPickupEBTToPurchaseFood() {
		return pickupEBTToPurchaseFood;
	}

	public void setPickupEBTToPurchaseFood(Boolean pickupEBTToPurchaseFood) {
		this.pickupEBTToPurchaseFood = pickupEBTToPurchaseFood;
	}
}
