package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class VitalStatistics {
	
    private String birthCityName;
    private String birthStateCode;
	public String getBirthCityName() {
		return birthCityName;
	}
	public void setBirthCityName(String birthCityName) {
		this.birthCityName = birthCityName;
	}
	public String getBirthStateCode() {
		return birthStateCode;
	}
	public void setBirthStateCode(String birthStateCode) {
		this.birthStateCode = birthStateCode;
	}

}
