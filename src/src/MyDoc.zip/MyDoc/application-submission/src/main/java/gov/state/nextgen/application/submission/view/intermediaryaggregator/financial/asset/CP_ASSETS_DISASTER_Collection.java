package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset;

public class CP_ASSETS_DISASTER_Collection {
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private String src_app_ind;
	private double cash_in_hand_amt;
	private double saving_account_amt;
	private double checking_account_amt;
	private double other_amt;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public double getCash_in_hand_amt() {
		return cash_in_hand_amt;
	}
	public void setCash_in_hand_amt(double cash_in_hand_amt) {
		this.cash_in_hand_amt = cash_in_hand_amt;
	}
	public double getSaving_account_amt() {
		return saving_account_amt;
	}
	public void setSaving_account_amt(double saving_account_amt) {
		this.saving_account_amt = saving_account_amt;
	}
	public double getChecking_account_amt() {
		return checking_account_amt;
	}
	public void setChecking_account_amt(double checking_account_amt) {
		this.checking_account_amt = checking_account_amt;
	}
	public double getOther_amt() {
		return other_amt;
	}
	public void setOther_amt(double other_amt) {
		this.other_amt = other_amt;
	}
	
}
