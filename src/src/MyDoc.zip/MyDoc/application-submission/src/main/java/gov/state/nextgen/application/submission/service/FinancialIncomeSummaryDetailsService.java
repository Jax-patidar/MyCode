package gov.state.nextgen.application.submission.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.ExceptionsUtil;
import gov.state.nextgen.application.submission.framework.exception.ExceptionLogManager;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.FinancialIncomeSummaryDetails;
import gov.state.nextgen.application.submission.view.request.PayLoadRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import static gov.state.nextgen.application.submission.framework.constants.ExceptionConstants.KEY_IDENTIFIER_ONE;

import java.util.concurrent.CompletableFuture;

@Service
public class FinancialIncomeSummaryDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(FinancialIncomeSummaryDetailsService.class);

    @Autowired
    @Qualifier("appSubmissionRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    @Qualifier("appSubmissionThreadPoolTaskExecutor")
    private ThreadPoolTaskExecutor threadPoolTaskExecutor;

    @Autowired
    private LambdaInvokerServiceImpl service;

    @Autowired
    private ExceptionLogManager exceptionLogManager;

    @Async("appSubmissionThreadPoolTaskExecutor")
    public CompletableFuture<AggregatedPayload> fetchFinancialIncomeSummaryDetailsData(AggregatedPayload payload) {
    	MDC.put(KEY_IDENTIFIER_ONE,  payload.getAppNumber());
        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "fetching Financial Income Summary Details data for case::" + payload.getAppNumber());

        String responseBody = null;

        PayLoadRequest payLoadRequest = new PayLoadRequest(payload.getAppNumber(), ApplicationSubmissionConstants.ABJIS, ApplicationSubmissionConstants.ABJIS_LOAD);

        HttpEntity<Object> httpEntity = new HttpEntity<>(payLoadRequest);
        FinancialIncomeSummaryDetails financialIncomeSummaryDetails;
        try {
            String url = System.getenv(ApplicationSubmissionConstants.FINANCIAL_INCOME_SUMMARY_DETAILS_URL);
            String path = "/financialinfo/" + ApplicationSubmissionConstants.ABJIS + "/" + ApplicationSubmissionConstants.ABJIS_LOAD;
            responseBody = service.invokeLambda(url, httpEntity, path);

            ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            financialIncomeSummaryDetails = objMapper.readValue(responseBody, FinancialIncomeSummaryDetails.class);

            payload.setFinancialIncomeSummaryDetails(financialIncomeSummaryDetails);
            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "successfully fetched Financial Income Summary Details data for case::" + payload.getAppNumber());
        } catch (Throwable e) {//NOSONAR
            payload.setErrorWhileAccessingInternalServices(true);
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Error while fetching data from Financial Income Summary Details data for case ::" + payload.getAppNumber());
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Exception occurred due to::" + e.getMessage());
            exceptionLogManager.sendMessage(ExceptionsUtil.getExceptionCargo(this.getClass(), e, "fetchFinancialIncomeSummaryDetailsData", payload.getAppNumber()));
        }
        return CompletableFuture.completedFuture(payload);
    }

}
