package gov.state.nextgen.application.submission.framework.interceptor;

import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Component
public class RequestInterceptor implements Filter {

    public static final String TRANSACTION_IDENTIFIER = "transactionIdentifier";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        setTraceId((HttpServletRequest) request);
        chain.doFilter(request, response);
        clearMDCAttributes();
    }

    private void setTraceId(HttpServletRequest request) {
        String traceId = request.getHeader("CORELATION_ID") == null ? request.getHeader("X-Amzn-Trace-Id") : request.getHeader("CORELATION_ID");
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, " TraceId:" + traceId);
        MDC.put(TRANSACTION_IDENTIFIER, traceId);
    }

    private void clearMDCAttributes() {
        MDC.clear();
    }
}
