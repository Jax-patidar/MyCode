package gov.state.nextgen.application.submission.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.ExceptionsUtil;
import gov.state.nextgen.application.submission.framework.exception.ExceptionLogManager;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.FinancialAssetSummaryDetails;
import gov.state.nextgen.application.submission.view.request.PayLoadRequest;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import static gov.state.nextgen.application.submission.framework.constants.ExceptionConstants.KEY_IDENTIFIER_ONE;

import java.util.concurrent.CompletableFuture;

@Service
public class FinancialAssetSummaryDetailsService {

    @Autowired
    @Qualifier("appSubmissionRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    @Qualifier("appSubmissionThreadPoolTaskExecutor")
    private ThreadPoolTaskExecutor threadPoolTaskExecutor;

    @Autowired
    private LambdaInvokerServiceImpl service;

    @Autowired
    private ExceptionLogManager exceptionLogManager;

    @Async("appSubmissionThreadPoolTaskExecutor")
    public CompletableFuture<AggregatedPayload> fetchFinancialAssetSummaryDetailsData(AggregatedPayload payload) {
    	MDC.put(KEY_IDENTIFIER_ONE,  payload.getAppNumber());
        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "fetching Financial Asset Summary Details data for case::" + payload.getAppNumber());

        String responseBody = null;

        PayLoadRequest payLoadRequest = new PayLoadRequest(payload.getAppNumber(), ApplicationSubmissionConstants.ABASU, ApplicationSubmissionConstants.ABASU_LOAD);

        HttpEntity<Object> httpEntity = new HttpEntity<>(payLoadRequest);
        FinancialAssetSummaryDetails financialAssetSummaryDetails;
        try {
            String url = System.getenv(ApplicationSubmissionConstants.FINANCIAL_ASSET_SUMMARY_DETAILS_URL);
            String path = "/financialinfo/" + ApplicationSubmissionConstants.ABASU + "/" + ApplicationSubmissionConstants.ABASU_LOAD;
            responseBody = service.invokeLambda(url, httpEntity, path);

            ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            financialAssetSummaryDetails = objMapper.readValue(responseBody, FinancialAssetSummaryDetails.class);

            payload.setFinancialAssetSummaryDetails(financialAssetSummaryDetails);
            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "successfully fetched Financial Asset Summary Details data for case::" + payload.getAppNumber());

        } catch (Throwable e) {//NOSONAR
            payload.setErrorWhileAccessingInternalServices(true);
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Error while fetching data from Financial Asset Summary Details data for case::" + payload.getAppNumber());
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Exception occurred due to::" + e.getMessage());
            exceptionLogManager.sendMessage(ExceptionsUtil.getExceptionCargo(this.getClass(), e, "fetchFinancialAssetSummaryDetailsData", payload.getAppNumber()));
        }
        return CompletableFuture.completedFuture(payload);
    }

}
