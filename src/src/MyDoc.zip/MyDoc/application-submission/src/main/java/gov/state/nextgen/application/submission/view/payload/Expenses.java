package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class Expenses {
	private String freqCode;
	private String typeCode;
	private double dollarAmt;
	private double otherDollarAmount;
	private String categoryCode;
	private String recipientName;
	@JsonIgnore
	private String description;
	private String careProviderName;
	private Address careProviderAddress;
	private Boolean hsngExpnHelpInd;
	private String hsngHlpFirstName;
	private String hsngHlpLastName;
	private double hsngHlpAmt;
	private String hsngHlpFreq;
	private Boolean liheapInd;
	private String whoWillReimburse;
	private double reimburseAmount;
	private String nameOfChildren;
	private Boolean taxDeductibleAlimonyPmtInd;
	private String otherDeductableExpenseText;

	public String getFreqCode() {
		return freqCode;
	}

	public void setFreqCode(String freqCode) {
		this.freqCode = freqCode;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public double getDollarAmt() {
		return dollarAmt;
	}

	public void setDollarAmt(double dollarAmt) {
		this.dollarAmt = dollarAmt;
	}

	public double getOtherDollarAmount() {
		return otherDollarAmount;
	}

	public void setOtherDollarAmount(double otherDollarAmount) {
		this.otherDollarAmount = otherDollarAmount;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getRecipientName() {
		return recipientName;
	}

	public void setRecipientName(String recipientName) {
		this.recipientName = recipientName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCareProviderName() {
		return careProviderName;
	}

	public void setCareProviderName(String careProviderName) {
		this.careProviderName = careProviderName;
	}

	public Address getCareProviderAddress() {
		return careProviderAddress;
	}

	public void setCareProviderAddress(Address careProviderAddress) {
		this.careProviderAddress = careProviderAddress;
	}

	public Boolean isHsngExpnHelpInd() {
		return hsngExpnHelpInd;
	}

	public void setHsngExpnHelpInd(Boolean hsngExpnHelpInd) {
		this.hsngExpnHelpInd = hsngExpnHelpInd;
	}

	public String getHsngHlpFirstName() {
		return hsngHlpFirstName;
	}

	public void setHsngHlpFirstName(String hsngHlpFirstName) {
		this.hsngHlpFirstName = hsngHlpFirstName;
	}

	public String getHsngHlpLastName() {
		return hsngHlpLastName;
	}

	public void setHsngHlpLastName(String hsngHlpLastName) {
		this.hsngHlpLastName = hsngHlpLastName;
	}

	public double getHsngHlpAmt() {
		return hsngHlpAmt;
	}

	public void setHsngHlpAmt(double hsngHlpAmt) {
		this.hsngHlpAmt = hsngHlpAmt;
	}

	public String getHsngHlpFreq() {
		return hsngHlpFreq;
	}

	public void setHsngHlpFreq(String hsngHlpFreq) {
		this.hsngHlpFreq = hsngHlpFreq;
	}

	public Boolean isLiheapInd() {
		return liheapInd;
	}

	public void setLiheapInd(Boolean liheapInd) {
		this.liheapInd = liheapInd;
	}

	public String getWhoWillReimburse() {
		return whoWillReimburse;
	}

	public void setWhoWillReimburse(String whoWillReimburse) {
		this.whoWillReimburse = whoWillReimburse;
	}

	public double getReimburseAmount() {
		return reimburseAmount;
	}

	public void setReimburseAmount(double reimburseAmount) {
		this.reimburseAmount = reimburseAmount;
	}

	public String getNameOfChildren() {
		return nameOfChildren;
	}

	public void setNameOfChildren(String nameOfChildren) {
		this.nameOfChildren = nameOfChildren;
	}

	public Boolean isTaxDeductibleAlimonyPmtInd() {
		return taxDeductibleAlimonyPmtInd;
	}

	public void setTaxDeductibleAlimonyPmtInd(Boolean taxDeductibleAlimonyPmtInd) {
		this.taxDeductibleAlimonyPmtInd = taxDeductibleAlimonyPmtInd;
	}

	public String getOtherDeductableExpenseText() {
		return otherDeductableExpenseText;
	}

	public void setOtherDeductableExpenseText(String otherDeductableExpenseText) {
		this.otherDeductableExpenseText = otherDeductableExpenseText;
	}
}
