package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class PageCollection {
	@JsonDeserialize(contentAs = CP_APP_INDV_ADDI_INFO_Collection.class)
	private List<CP_APP_INDV_ADDI_INFO_Collection> CP_APP_INDV_ADDI_INFO_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_IMMED_CASH_Collection.class)
	private List<CP_APP_IMMED_CASH_Collection> CP_APP_IMMED_CASH_Collection;
	
	@JsonDeserialize(contentAs = APP_ABS_PRNT_Collection.class)
	private List<APP_ABS_PRNT_Collection> APP_ABS_PRNT_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_PGM_RQST_Collection.class)
	private List<CP_APP_PGM_RQST_Collection> CP_APP_PGM_RQST_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_RGST_Collection.class)
	private List<CP_APP_RGST_Collection> CP_APP_RGST_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_AUTH_REP_Collection.class)
	private List<CP_APP_AUTH_REP_Collection> CP_APP_AUTH_REP_Collection;
	
	@JsonDeserialize(contentAs = APP_INDV_Collection.class)
	private List<APP_INDV_Collection> APP_INDV_Collection;
	
	@JsonDeserialize(contentAs = APP_SBMS_Collection.class)
	private List<APP_SBMS_Collection> APP_SBMS_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_SUPPORT_SERVICES_Collection.class)
	private List<CP_APP_SUPPORT_SERVICES_Collection> CP_APP_SUPPORT_SERVICES_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_PGM_INDV_Collection.class)
	private List<CP_APP_PGM_INDV_Collection> CP_APP_PGM_INDV_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_HSHL_RLT_Collection.class)
	private List<CP_APP_HSHL_RLT_Collection> CP_APP_HSHL_RLT_Collection;
	
	 @JsonDeserialize(contentAs = CP_APP_IN_TAX_DEPENDENTS_Collection.class)
	 private List<CP_APP_IN_TAX_DEPENDENTS_Collection> CP_APP_IN_TAX_DEPENDENTS_Collection;
	 
	 @JsonDeserialize(contentAs = OTHER_HOUSEHOLD_DETAILS_Collection.class)
	 private List<OTHER_HOUSEHOLD_DETAILS_Collection> OTHER_HOUSEHOLD_DETAILS_Collection;
	 
	 @JsonDeserialize(contentAs = APP_USER_Collection.class)
	 private List<APP_USER_Collection> APP_USER_Collection;

	public List<CP_APP_INDV_ADDI_INFO_Collection> getCP_APP_INDV_ADDI_INFO_Collection() {
		return CP_APP_INDV_ADDI_INFO_Collection;
	}

	public void setCP_APP_INDV_ADDI_INFO_Collection(
			List<CP_APP_INDV_ADDI_INFO_Collection> cP_APP_INDV_ADDI_INFO_Collection) {
		CP_APP_INDV_ADDI_INFO_Collection = cP_APP_INDV_ADDI_INFO_Collection;
	}

	public List<CP_APP_IMMED_CASH_Collection> getCP_APP_IMMED_CASH_Collection() {
		return CP_APP_IMMED_CASH_Collection;
	}

	public void setCP_APP_IMMED_CASH_Collection(List<CP_APP_IMMED_CASH_Collection> cP_APP_IMMED_CASH_Collection) {
		CP_APP_IMMED_CASH_Collection = cP_APP_IMMED_CASH_Collection;
	}

	public List<APP_ABS_PRNT_Collection> getAPP_ABS_PRNT_Collection() {
		return APP_ABS_PRNT_Collection;
	}

	public void setAPP_ABS_PRNT_Collection(List<APP_ABS_PRNT_Collection> aPP_ABS_PRNT_Collection) {
		APP_ABS_PRNT_Collection = aPP_ABS_PRNT_Collection;
	}

	public List<CP_APP_PGM_RQST_Collection> getCP_APP_PGM_RQST_Collection() {
		return CP_APP_PGM_RQST_Collection;
	}

	public void setCP_APP_PGM_RQST_Collection(List<CP_APP_PGM_RQST_Collection> cP_APP_PGM_RQST_Collection) {
		CP_APP_PGM_RQST_Collection = cP_APP_PGM_RQST_Collection;
	}

	public List<CP_APP_RGST_Collection> getCP_APP_RGST_Collection() {
		return CP_APP_RGST_Collection;
	}

	public void setCP_APP_RGST_Collection(List<CP_APP_RGST_Collection> cP_APP_RGST_Collection) {
		CP_APP_RGST_Collection = cP_APP_RGST_Collection;
	}

	public List<CP_APP_AUTH_REP_Collection> getCP_APP_AUTH_REP_Collection() {
		return CP_APP_AUTH_REP_Collection;
	}

	public void setCP_APP_AUTH_REP_Collection(List<CP_APP_AUTH_REP_Collection> cP_APP_AUTH_REP_Collection) {
		CP_APP_AUTH_REP_Collection = cP_APP_AUTH_REP_Collection;
	}

	public List<APP_INDV_Collection> getAPP_INDV_Collection() {
		return APP_INDV_Collection;
	}

	public void setAPP_INDV_Collection(List<APP_INDV_Collection> aPP_INDV_Collection) {
		APP_INDV_Collection = aPP_INDV_Collection;
	}

	public List<APP_SBMS_Collection> getAPP_SBMS_Collection() {
		return APP_SBMS_Collection;
	}

	public void setAPP_SBMS_Collection(List<APP_SBMS_Collection> aPP_SBMS_Collection) {
		APP_SBMS_Collection = aPP_SBMS_Collection;
	}

	public List<CP_APP_SUPPORT_SERVICES_Collection> getCP_APP_SUPPORT_SERVICES_Collection() {
		return CP_APP_SUPPORT_SERVICES_Collection;
	}

	public void setCP_APP_SUPPORT_SERVICES_Collection(
			List<CP_APP_SUPPORT_SERVICES_Collection> cP_APP_SUPPORT_SERVICES_Collection) {
		CP_APP_SUPPORT_SERVICES_Collection = cP_APP_SUPPORT_SERVICES_Collection;
	}

	public List<CP_APP_PGM_INDV_Collection> getCP_APP_PGM_INDV_Collection() {
		return CP_APP_PGM_INDV_Collection;
	}

	public void setCP_APP_PGM_INDV_Collection(List<CP_APP_PGM_INDV_Collection> cP_APP_PGM_INDV_Collection) {
		CP_APP_PGM_INDV_Collection = cP_APP_PGM_INDV_Collection;
	}

	public List<CP_APP_HSHL_RLT_Collection> getCP_APP_HSHL_RLT_Collection() {
		return CP_APP_HSHL_RLT_Collection;
	}

	public void setCP_APP_HSHL_RLT_Collection(List<CP_APP_HSHL_RLT_Collection> cP_APP_HSHL_RLT_Collection) {
		CP_APP_HSHL_RLT_Collection = cP_APP_HSHL_RLT_Collection;
	}

	public List<CP_APP_IN_TAX_DEPENDENTS_Collection> getCP_APP_IN_TAX_DEPENDENTS_Collection() {
		return CP_APP_IN_TAX_DEPENDENTS_Collection;
	}

	public void setCP_APP_IN_TAX_DEPENDENTS_Collection(
			List<CP_APP_IN_TAX_DEPENDENTS_Collection> cP_APP_IN_TAX_DEPENDENTS_Collection) {
		CP_APP_IN_TAX_DEPENDENTS_Collection = cP_APP_IN_TAX_DEPENDENTS_Collection;
	}

	public List<OTHER_HOUSEHOLD_DETAILS_Collection> getOTHER_HOUSEHOLD_DETAILS_Collection() {
		return OTHER_HOUSEHOLD_DETAILS_Collection;
	}

	public void setOTHER_HOUSEHOLD_DETAILS_Collection(
			List<OTHER_HOUSEHOLD_DETAILS_Collection> oTHER_HOUSEHOLD_DETAILS_Collection) {
		OTHER_HOUSEHOLD_DETAILS_Collection = oTHER_HOUSEHOLD_DETAILS_Collection;
	}

	public List<APP_USER_Collection> getAPP_USER_Collection() {
		return APP_USER_Collection;
	}

	public void setAPP_USER_Collection(List<APP_USER_Collection> aPP_USER_Collection) {
		APP_USER_Collection = aPP_USER_Collection;
	}
	
}
	
	
	
	

