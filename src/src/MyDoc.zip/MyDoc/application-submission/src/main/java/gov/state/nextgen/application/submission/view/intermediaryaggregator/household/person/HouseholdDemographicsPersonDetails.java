package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class HouseholdDemographicsPersonDetails {
	private PageCollection pageCollection;
	private String currentPageID;

	public PageCollection getPageCollection() {
		if(pageCollection == null) {
			pageCollection = new PageCollection();
		}
		return pageCollection;
	}

	public void setPageCollection(PageCollection pageCollection) {
		this.pageCollection = pageCollection;
	}

	public String getCurrentPageID() {
		return currentPageID;
	}

	public void setCurrentPageID(String currentPageID) {
		this.currentPageID = currentPageID;
	}
	
	
}