package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset;

public class APP_IN_VEH_ASET_Collection {
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private String ecp_id;
	private int indv_seq_num;
	private int seq_num;
	private String jnt_own_resp;
	private String lic_plate_txt;
	private String lic_sta_cd;
	private String mv_owe_amt;
	private String mv_owe_amt_ind;
	private String rec_cplt_ind;
	private String veh_aset_typ;
	private String asset_end_dt;
	private String motor_vehicle_description;
	private String src_app_ind;
	private String vehicle_acquired_dt;
	private String chg_eff_dt;
	private String mv_use_1_cd;
	private String mv_use_2_cd;
	private String mv_use_3_cd;
	private String loopingQuestion;
	private String chg_dt;
	private String adapt_record_id;
	private String veh_brw_ind;
	private String veh_find_value;
	private String veh_gift_how;
	private String veh_gift_ind;
	private String veh_used_by;
	private String how_it_is_used;
	private String leased_ind;
	private String how_it_is_usedarray;
	private String fst_nam;
	private String first_name;
	private String last_name;
	private String age;
	private String veh_fmv_amt;
	private String veh_fmv_amt_ind;
	private String veh_make_txt;
	private String veh_modl_txt;
	private double veh_owe_amt;
	private String veh_owe_amt_ind;
	private String veh_rgst_rqr_sw;
	private String veh_yr;
	
	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getCargoName() {
		return cargoName;
	}

	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}

	public String getRowAction() {
		return rowAction;
	}

	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}

	public String getAdaptRecordId() {
		return adaptRecordId;
	}

	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}

	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}

	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}

	public String getApp_num() {
		return app_num;
	}

	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}

	public String getEcp_id() {
		return ecp_id;
	}

	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}

	public int getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public int getSeq_num() {
		return seq_num;
	}

	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}

	public String getJnt_own_resp() {
		return jnt_own_resp;
	}

	public void setJnt_own_resp(String jnt_own_resp) {
		this.jnt_own_resp = jnt_own_resp;
	}

	public String getLic_plate_txt() {
		return lic_plate_txt;
	}

	public void setLic_plate_txt(String lic_plate_txt) {
		this.lic_plate_txt = lic_plate_txt;
	}

	public String getLic_sta_cd() {
		return lic_sta_cd;
	}

	public void setLic_sta_cd(String lic_sta_cd) {
		this.lic_sta_cd = lic_sta_cd;
	}

	public String getMv_owe_amt() {
		return mv_owe_amt;
	}

	public void setMv_owe_amt(String mv_owe_amt) {
		this.mv_owe_amt = mv_owe_amt;
	}

	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	public String getVeh_aset_typ() {
		return veh_aset_typ;
	}

	public void setVeh_aset_typ(String veh_aset_typ) {
		this.veh_aset_typ = veh_aset_typ;
	}

	public String getAsset_end_dt() {
		return asset_end_dt;
	}

	public void setAsset_end_dt(String asset_end_dt) {
		this.asset_end_dt = asset_end_dt;
	}

	public String getMotor_vehicle_description() {
		return motor_vehicle_description;
	}

	public void setMotor_vehicle_description(String motor_vehicle_description) {
		this.motor_vehicle_description = motor_vehicle_description;
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public String getVehicle_acquired_dt() {
		return vehicle_acquired_dt;
	}

	public void setVehicle_acquired_dt(String vehicle_acquired_dt) {
		this.vehicle_acquired_dt = vehicle_acquired_dt;
	}

	public String getChg_eff_dt() {
		return chg_eff_dt;
	}

	public void setChg_eff_dt(String chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}

	public String getMv_use_1_cd() {
		return mv_use_1_cd;
	}

	public void setMv_use_1_cd(String mv_use_1_cd) {
		this.mv_use_1_cd = mv_use_1_cd;
	}

	public String getMv_use_2_cd() {
		return mv_use_2_cd;
	}

	public void setMv_use_2_cd(String mv_use_2_cd) {
		this.mv_use_2_cd = mv_use_2_cd;
	}

	public String getMv_use_3_cd() {
		return mv_use_3_cd;
	}

	public void setMv_use_3_cd(String mv_use_3_cd) {
		this.mv_use_3_cd = mv_use_3_cd;
	}

	public String getLoopingQuestion() {
		return loopingQuestion;
	}

	public void setLoopingQuestion(String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}

	public String getChg_dt() {
		return chg_dt;
	}

	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}

	public String getAdapt_record_id() {
		return adapt_record_id;
	}

	public void setAdapt_record_id(String adapt_record_id) {
		this.adapt_record_id = adapt_record_id;
	}

	public String getVeh_brw_ind() {
		return veh_brw_ind;
	}

	public void setVeh_brw_ind(String veh_brw_ind) {
		this.veh_brw_ind = veh_brw_ind;
	}

	public String getVeh_find_value() {
		return veh_find_value;
	}

	public void setVeh_find_value(String veh_find_value) {
		this.veh_find_value = veh_find_value;
	}

	public String getVeh_gift_how() {
		return veh_gift_how;
	}

	public void setVeh_gift_how(String veh_gift_how) {
		this.veh_gift_how = veh_gift_how;
	}

	public String getVeh_gift_ind() {
		return veh_gift_ind;
	}

	public void setVeh_gift_ind(String veh_gift_ind) {
		this.veh_gift_ind = veh_gift_ind;
	}

	public String getVeh_used_by() {
		return veh_used_by;
	}

	public void setVeh_used_by(String veh_used_by) {
		this.veh_used_by = veh_used_by;
	}

	public String getHow_it_is_used() {
		return how_it_is_used;
	}

	public void setHow_it_is_used(String how_it_is_used) {
		this.how_it_is_used = how_it_is_used;
	}

	public String getLeased_ind() {
		return leased_ind;
	}

	public void setLeased_ind(String leased_ind) {
		this.leased_ind = leased_ind;
	}

	public String getHow_it_is_usedarray() {
		return how_it_is_usedarray;
	}

	public void setHow_it_is_usedarray(String how_it_is_usedarray) {
		this.how_it_is_usedarray = how_it_is_usedarray;
	}

	public String getFst_nam() {
		return fst_nam;
	}

	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getVeh_fmv_amt() {
		return veh_fmv_amt;
	}

	public void setVeh_fmv_amt(String veh_fmv_amt) {
		this.veh_fmv_amt = veh_fmv_amt;
	}

	public String getVeh_fmv_amt_ind() {
		return veh_fmv_amt_ind;
	}

	public void setVeh_fmv_amt_ind(String veh_fmv_amt_ind) {
		this.veh_fmv_amt_ind = veh_fmv_amt_ind;
	}

	public String getVeh_make_txt() {
		return veh_make_txt;
	}

	public void setVeh_make_txt(String veh_make_txt) {
		this.veh_make_txt = veh_make_txt;
	}

	public String getVeh_modl_txt() {
		return veh_modl_txt;
	}

	public void setVeh_modl_txt(String veh_modl_txt) {
		this.veh_modl_txt = veh_modl_txt;
	}

	public String getVeh_owe_amt_ind() {
		return veh_owe_amt_ind;
	}

	public void setVeh_owe_amt_ind(String veh_owe_amt_ind) {
		this.veh_owe_amt_ind = veh_owe_amt_ind;
	}

	public String getVeh_rgst_rqr_sw() {
		return veh_rgst_rqr_sw;
	}

	public void setVeh_rgst_rqr_sw(String veh_rgst_rqr_sw) {
		this.veh_rgst_rqr_sw = veh_rgst_rqr_sw;
	}

	public String getVeh_yr() {
		return veh_yr;
	}

	public void setVeh_yr(String veh_yr) {
		this.veh_yr = veh_yr;
	}

	public double getVeh_owe_amt() {
		return veh_owe_amt;
	}

	public void setVeh_owe_amt(double veh_owe_amt) {
		this.veh_owe_amt = veh_owe_amt;
	}

	public String getMv_owe_amt_ind() {
		return mv_owe_amt_ind;
	}

	public void setMv_owe_amt_ind(String mv_owe_amt_ind) {
		this.mv_owe_amt_ind = mv_owe_amt_ind;
	}

}
