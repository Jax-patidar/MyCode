package gov.state.nextgen.application.submission.exceptionhandling;

import gov.state.nextgen.application.submission.framework.ExceptionsUtil;
import gov.state.nextgen.application.submission.framework.exception.ExceptionLogManager;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import java.util.stream.Collectors;

import static gov.state.nextgen.application.submission.util.ExceptionHandlerUtil.buildApplicationResponse;


@ControllerAdvice
public class CustomGlobalExceptionHandler {

    @Autowired
    private ExceptionLogManager exceptionLogManager;

    private static final String FORMCF37TRANSFER = "formCF37Transfer";
    
    /**
     * @param ex
     * @param webRequest
     * @return
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, WebRequest webRequest) {
        String error = ex.getBindingResult().getFieldErrors().stream().map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.joining(","));
        FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "handleMethodArgumentNotValid - Exception occurred due to:::" + ex.getMessage());
        exceptionLogManager.sendMessage(ExceptionsUtil.getExceptionCargo(this.getClass(), ex, FORMCF37TRANSFER, null));
        return new ResponseEntity<>(buildApplicationResponse(ex, String.valueOf(HttpStatus.BAD_REQUEST.value()), error, "Validation Error"), HttpStatus.BAD_REQUEST);
    }


    /**
     * @param ex
     * @param webRequest
     * @return
     */
    @ExceptionHandler(ApplicationResourceNotFoundException.class)
    public ResponseEntity<Object> handleInvalidFormatException(ApplicationResourceNotFoundException ex, WebRequest webRequest) {
        FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "handleInvalidFormatException - Exception occurred due to:::" + ex.getMessage());
        exceptionLogManager.sendMessage(ExceptionsUtil.getExceptionCargo(this.getClass(), ex, FORMCF37TRANSFER, null));
        return new ResponseEntity<>(buildApplicationResponse(ex, String.valueOf(HttpStatus.NOT_FOUND.value()), ex.getMessage(), HttpStatus.NOT_FOUND.getReasonPhrase()), HttpStatus.NOT_FOUND);
    }

    /**
     * @param ex
     * @param webRequest
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> globalExceptionHandler(Exception ex, WebRequest webRequest) {
        FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "globalExceptionHandler - Exception occurred due to:::" + ex.getMessage());
        exceptionLogManager.sendMessage(ExceptionsUtil.getExceptionCargo(this.getClass(), ex, FORMCF37TRANSFER, null));
        return new ResponseEntity<>(buildApplicationResponse(ex, String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), ex.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase()), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
