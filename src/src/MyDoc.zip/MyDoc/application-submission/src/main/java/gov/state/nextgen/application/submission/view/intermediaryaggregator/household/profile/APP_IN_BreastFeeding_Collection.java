package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class APP_IN_BreastFeeding_Collection {
	
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int indv_seq_num;
	private String src_app_ind;
	private String ecp_id;
	private String chg_eff_dt;
	private String fetus_ct;
	private String preg_due_dt;
	private String rec_cplt_ind;
	private String conception_dt;
	private int baby_ct;
	private String baby_reside_hshld_ind;
	private String cur_preg;
	private String cur_in_post_partum;
	private String preg_term_dt;
	private String pp_babies_ct;
	private String bf_infant;
	private String preg_dlvry_dt;
	private String preg_end_dt;
	private String birth_in_twelv_mnths;
	private String presump_elig_card_ind;
	private String enrl_stat_cd;
	private String nt_enrl_stat_desc;
	private String is_breast_feeding;
	private String is_pregnant;
	private String first_name;
	private String last_name;
	private int age;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getChg_eff_dt() {
		return chg_eff_dt;
	}
	public void setChg_eff_dt(String chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}
	public String getFetus_ct() {
		return fetus_ct;
	}
	public void setFetus_ct(String fetus_ct) {
		this.fetus_ct = fetus_ct;
	}
	public String getPreg_due_dt() {
		return preg_due_dt;
	}
	public void setPreg_due_dt(String preg_due_dt) {
		this.preg_due_dt = preg_due_dt;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getConception_dt() {
		return conception_dt;
	}
	public void setConception_dt(String conception_dt) {
		this.conception_dt = conception_dt;
	}
	public int getBaby_ct() {
		return baby_ct;
	}
	public void setBaby_ct(int baby_ct) {
		this.baby_ct = baby_ct;
	}
	public String getBaby_reside_hshld_ind() {
		return baby_reside_hshld_ind;
	}
	public void setBaby_reside_hshld_ind(String baby_reside_hshld_ind) {
		this.baby_reside_hshld_ind = baby_reside_hshld_ind;
	}
	public String getCur_preg() {
		return cur_preg;
	}
	public void setCur_preg(String cur_preg) {
		this.cur_preg = cur_preg;
	}
	public String getCur_in_post_partum() {
		return cur_in_post_partum;
	}
	public void setCur_in_post_partum(String cur_in_post_partum) {
		this.cur_in_post_partum = cur_in_post_partum;
	}
	public String getPreg_term_dt() {
		return preg_term_dt;
	}
	public void setPreg_term_dt(String preg_term_dt) {
		this.preg_term_dt = preg_term_dt;
	}
	public String getPp_babies_ct() {
		return pp_babies_ct;
	}
	public void setPp_babies_ct(String pp_babies_ct) {
		this.pp_babies_ct = pp_babies_ct;
	}
	public String getBf_infant() {
		return bf_infant;
	}
	public void setBf_infant(String bf_infant) {
		this.bf_infant = bf_infant;
	}
	public String getPreg_dlvry_dt() {
		return preg_dlvry_dt;
	}
	public void setPreg_dlvry_dt(String preg_dlvry_dt) {
		this.preg_dlvry_dt = preg_dlvry_dt;
	}
	public String getPreg_end_dt() {
		return preg_end_dt;
	}
	public void setPreg_end_dt(String preg_end_dt) {
		this.preg_end_dt = preg_end_dt;
	}
	public String getBirth_in_twelv_mnths() {
		return birth_in_twelv_mnths;
	}
	public void setBirth_in_twelv_mnths(String birth_in_twelv_mnths) {
		this.birth_in_twelv_mnths = birth_in_twelv_mnths;
	}
	public String getPresump_elig_card_ind() {
		return presump_elig_card_ind;
	}
	public void setPresump_elig_card_ind(String presump_elig_card_ind) {
		this.presump_elig_card_ind = presump_elig_card_ind;
	}
	public String getEnrl_stat_cd() {
		return enrl_stat_cd;
	}
	public void setEnrl_stat_cd(String enrl_stat_cd) {
		this.enrl_stat_cd = enrl_stat_cd;
	}
	public String getNt_enrl_stat_desc() {
		return nt_enrl_stat_desc;
	}
	public void setNt_enrl_stat_desc(String nt_enrl_stat_desc) {
		this.nt_enrl_stat_desc = nt_enrl_stat_desc;
	}
	public String getIs_breast_feeding() {
		return is_breast_feeding;
	}
	public void setIs_breast_feeding(String is_breast_feeding) {
		this.is_breast_feeding = is_breast_feeding;
	}
	public String getIs_pregnant() {
		return is_pregnant;
	}
	public void setIs_pregnant(String is_pregnant) {
		this.is_pregnant = is_pregnant;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	

}
