package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income;

public class CP_INCOME_DISASTER_Collection {
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private String src_app_ind;
	private String additional_info;
	private double exp_amt;
	private double income_amt;
	private double cash_in_hand_amt;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getAdditional_info() {
		return additional_info;
	}
	public void setAdditional_info(String additional_info) {
		this.additional_info = additional_info;
	}
	public double getExp_amt() {
		return exp_amt;
	}
	public void setExp_amt(double exp_amt) {
		this.exp_amt = exp_amt;
	}
	public double getIncome_amt() {
		return income_amt;
	}
	public void setIncome_amt(double income_amt) {
		this.income_amt = income_amt;
	}
	public double getCash_in_hand_amt() {
		return cash_in_hand_amt;
	}
	public void setCash_in_hand_amt(double cash_in_hand_amt) {
		this.cash_in_hand_amt = cash_in_hand_amt;
	}
	

}
