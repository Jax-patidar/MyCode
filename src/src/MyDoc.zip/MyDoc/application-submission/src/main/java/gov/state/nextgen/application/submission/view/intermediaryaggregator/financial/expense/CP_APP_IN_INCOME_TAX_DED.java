package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense;

public class CP_APP_IN_INCOME_TAX_DED {
	
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int indv_seq_num;
	private String src_app_ind;
	private String ecp_id;
	private String end_date;
	private String educator_exp;
	private String business_exp;
	private String health_saving_exp;
	private String moving_exp;
	private String deductible_self_exp;
	private String self_sep_exp;
	private String self_health_exp;
	private String penalty_exp;
	private String alimony_exp;
	private String ira_exp;
	private String student_loan_exp;
	private String tution_exp;
	private String domestic_exp;
	private String chg_dt;
	private String seq_num;
	private String fst_name;
	private String pay_freq;
	private String exp_pay_desc;
	private String exp_type;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getEnd_date() {
		return end_date;
	}
	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}
	public String getEducator_exp() {
		return educator_exp;
	}
	public void setEducator_exp(String educator_exp) {
		this.educator_exp = educator_exp;
	}
	public String getBusiness_exp() {
		return business_exp;
	}
	public void setBusiness_exp(String business_exp) {
		this.business_exp = business_exp;
	}
	public String getHealth_saving_exp() {
		return health_saving_exp;
	}
	public void setHealth_saving_exp(String health_saving_exp) {
		this.health_saving_exp = health_saving_exp;
	}
	public String getMoving_exp() {
		return moving_exp;
	}
	public void setMoving_exp(String moving_exp) {
		this.moving_exp = moving_exp;
	}
	public String getDeductible_self_exp() {
		return deductible_self_exp;
	}
	public void setDeductible_self_exp(String deductible_self_exp) {
		this.deductible_self_exp = deductible_self_exp;
	}
	public String getSelf_sep_exp() {
		return self_sep_exp;
	}
	public void setSelf_sep_exp(String self_sep_exp) {
		this.self_sep_exp = self_sep_exp;
	}
	public String getSelf_health_exp() {
		return self_health_exp;
	}
	public void setSelf_health_exp(String self_health_exp) {
		this.self_health_exp = self_health_exp;
	}
	public String getPenalty_exp() {
		return penalty_exp;
	}
	public void setPenalty_exp(String penalty_exp) {
		this.penalty_exp = penalty_exp;
	}
	public String getAlimony_exp() {
		return alimony_exp;
	}
	public void setAlimony_exp(String alimony_exp) {
		this.alimony_exp = alimony_exp;
	}
	public String getIra_exp() {
		return ira_exp;
	}
	public void setIra_exp(String ira_exp) {
		this.ira_exp = ira_exp;
	}
	public String getStudent_loan_exp() {
		return student_loan_exp;
	}
	public void setStudent_loan_exp(String student_loan_exp) {
		this.student_loan_exp = student_loan_exp;
	}
	public String getTution_exp() {
		return tution_exp;
	}
	public void setTution_exp(String tution_exp) {
		this.tution_exp = tution_exp;
	}
	public String getDomestic_exp() {
		return domestic_exp;
	}
	public void setDomestic_exp(String domestic_exp) {
		this.domestic_exp = domestic_exp;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(String seq_num) {
		this.seq_num = seq_num;
	}
	public String getFst_name() {
		return fst_name;
	}
	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}
	public String getPay_freq() {
		return pay_freq;
	}
	public void setPay_freq(String pay_freq) {
		this.pay_freq = pay_freq;
	}
	public String getExp_pay_desc() {
		return exp_pay_desc;
	}
	public void setExp_pay_desc(String exp_pay_desc) {
		this.exp_pay_desc = exp_pay_desc;
	}
	public String getExp_type() {
		return exp_type;
	}
	public void setExp_type(String exp_type) {
		this.exp_type = exp_type;
	}
	@Override
	public String toString() {
		return "CP_APP_IN_INCOME_TAX_DED [user=" + user + ", cargoName=" + cargoName + ", rowAction=" + rowAction
				+ ", adaptRecordId=" + adaptRecordId + ", delete_reason_cd=" + delete_reason_cd + ", app_num=" + app_num
				+ ", indv_seq_num=" + indv_seq_num + ", src_app_ind=" + src_app_ind + ", ecp_id=" + ecp_id
				+ ", end_date=" + end_date + ", educator_exp=" + educator_exp + ", business_exp=" + business_exp
				+ ", health_saving_exp=" + health_saving_exp + ", moving_exp=" + moving_exp + ", deductible_self_exp="
				+ deductible_self_exp + ", self_sep_exp=" + self_sep_exp + ", self_health_exp=" + self_health_exp
				+ ", penalty_exp=" + penalty_exp + ", alimony_exp=" + alimony_exp + ", ira_exp=" + ira_exp
				+ ", student_loan_exp=" + student_loan_exp + ", tution_exp=" + tution_exp + ", domestic_exp="
				+ domestic_exp + ", chg_dt=" + chg_dt + ", seq_num=" + seq_num + ", fst_name=" + fst_name
				+ ", pay_freq=" + pay_freq + ", exp_pay_desc=" + exp_pay_desc + ", exp_type=" + exp_type + "]";
	}
	
	
	

}
