package gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial;

public class CPAPPINCSHAIDSTPCollection {
	private String user;
    private String cargoName;
    private boolean dirty;
    private String rowAction;
    private String adaptRecordId;
    private String app_num;
    private String cshaid_stp_id;
    private String type_cd;
    private int indv_seq_num;
    private String stopped_dt;
    private String comments;
    private String county;
    private String state_cd;
    private String delete_reason_cd;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public boolean isDirty() {
		return dirty;
	}
	public void setDirty(boolean dirty) {
		this.dirty = dirty;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getCshaid_stp_id() {
		return cshaid_stp_id;
	}
	public void setCshaid_stp_id(String cshaid_stp_id) {
		this.cshaid_stp_id = cshaid_stp_id;
	}
	public String getType_cd() {
		return type_cd;
	}
	public void setType_cd(String type_cd) {
		this.type_cd = type_cd;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getStopped_dt() {
		return stopped_dt;
	}
	public void setStopped_dt(String stopped_dt) {
		this.stopped_dt = stopped_dt;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getState_cd() {
		return state_cd;
	}
	public void setState_cd(String state_cd) {
		this.state_cd = state_cd;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
}
