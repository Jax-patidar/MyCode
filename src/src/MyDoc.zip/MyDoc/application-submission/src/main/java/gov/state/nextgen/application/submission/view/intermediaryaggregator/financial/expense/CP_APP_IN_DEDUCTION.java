package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense;

public class CP_APP_IN_DEDUCTION {
	
	private String  user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int indv_seq_num;
	private String seq_num;
	private String src_app_ind;
	private String exp_typ;
	private String exp_amt;
	private String ecp_id;
	private String rec_cplt_ind;
	private String expense_end_dt;
	private String exp_sub_type;
	private String smone_els_pay_ind;
	private String child_sup_payee_name;
	private String court_order_pay_chld_sup_ind;
	private String court_order_pay_amt;
	private String pay_freq_cd;
	private String children_name;
	private String divorce_dt;
	private String chld_sup_payee_nam;
	private String loopingInd;
	private String fst_name;
	private String chg_dt;
	private String exp_end_date;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(String seq_num) {
		this.seq_num = seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getExp_typ() {
		return exp_typ;
	}
	public void setExp_typ(String exp_typ) {
		this.exp_typ = exp_typ;
	}
	public String getExp_amt() {
		return exp_amt;
	}
	public void setExp_amt(String exp_amt) {
		this.exp_amt = exp_amt;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getExpense_end_dt() {
		return expense_end_dt;
	}
	public void setExpense_end_dt(String expense_end_dt) {
		this.expense_end_dt = expense_end_dt;
	}
	public String getExp_sub_type() {
		return exp_sub_type;
	}
	public void setExp_sub_type(String exp_sub_type) {
		this.exp_sub_type = exp_sub_type;
	}
	public String getSmone_els_pay_ind() {
		return smone_els_pay_ind;
	}
	public void setSmone_els_pay_ind(String smone_els_pay_ind) {
		this.smone_els_pay_ind = smone_els_pay_ind;
	}
	public String getChild_sup_payee_name() {
		return child_sup_payee_name;
	}
	public void setChild_sup_payee_name(String child_sup_payee_name) {
		this.child_sup_payee_name = child_sup_payee_name;
	}
	public String getCourt_order_pay_chld_sup_ind() {
		return court_order_pay_chld_sup_ind;
	}
	public void setCourt_order_pay_chld_sup_ind(String court_order_pay_chld_sup_ind) {
		this.court_order_pay_chld_sup_ind = court_order_pay_chld_sup_ind;
	}
	public String getCourt_order_pay_amt() {
		return court_order_pay_amt;
	}
	public void setCourt_order_pay_amt(String court_order_pay_amt) {
		this.court_order_pay_amt = court_order_pay_amt;
	}
	public String getPay_freq_cd() {
		return pay_freq_cd;
	}
	public void setPay_freq_cd(String pay_freq_cd) {
		this.pay_freq_cd = pay_freq_cd;
	}
	public String getChildren_name() {
		return children_name;
	}
	public void setChildren_name(String children_name) {
		this.children_name = children_name;
	}
	public String getDivorce_dt() {
		return divorce_dt;
	}
	public void setDivorce_dt(String divorce_dt) {
		this.divorce_dt = divorce_dt;
	}
	public String getChld_sup_payee_nam() {
		return chld_sup_payee_nam;
	}
	public void setChld_sup_payee_nam(String chld_sup_payee_nam) {
		this.chld_sup_payee_nam = chld_sup_payee_nam;
	}
	public String getLoopingInd() {
		return loopingInd;
	}
	public void setLoopingInd(String loopingInd) {
		this.loopingInd = loopingInd;
	}
	public String getFst_name() {
		return fst_name;
	}
	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getExp_end_date() {
		return exp_end_date;
	}
	public void setExp_end_date(String exp_end_date) {
		this.exp_end_date = exp_end_date;
	}
	@Override
	public String toString() {
		return "CP_APP_IN_DEDUCTION [user=" + user + ", cargoName=" + cargoName + ", rowAction=" + rowAction
				+ ", adaptRecordId=" + adaptRecordId + ", delete_reason_cd=" + delete_reason_cd + ", app_num=" + app_num
				+ ", indv_seq_num=" + indv_seq_num + ", seq_num=" + seq_num + ", src_app_ind=" + src_app_ind
				+ ", exp_typ=" + exp_typ + ", exp_amt=" + exp_amt + ", ecp_id=" + ecp_id + ", rec_cplt_ind="
				+ rec_cplt_ind + ", expense_end_dt=" + expense_end_dt + ", exp_sub_type=" + exp_sub_type
				+ ", smone_els_pay_ind=" + smone_els_pay_ind + ", child_sup_payee_name=" + child_sup_payee_name
				+ ", court_order_pay_chld_sup_ind=" + court_order_pay_chld_sup_ind + ", court_order_pay_amt="
				+ court_order_pay_amt + ", pay_freq_cd=" + pay_freq_cd + ", children_name=" + children_name
				+ ", divorce_dt=" + divorce_dt + ", chld_sup_payee_nam=" + chld_sup_payee_nam + ", loopingInd="
				+ loopingInd + ", fst_name=" + fst_name + ", chg_dt=" + chg_dt + ", exp_end_date=" + exp_end_date + "]";
	}
	
	
	

}
