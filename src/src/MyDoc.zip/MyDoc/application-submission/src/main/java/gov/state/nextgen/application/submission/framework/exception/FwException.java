package gov.state.nextgen.application.submission.framework.exception;

/**
 * Services Framework. Framework Runtime Exception. This exception is used
 * primarily when a system exception is caught and rethrown. However,
 * unacceptable conditions within the framework, mostly during service
 * initialization, may be thrown as this exception. All application classes that
 * call on framework services never need to catch any system exceptions; they
 * catch only this exception.
 *
 * @author Architecture Team Creation Date Apr 7, 2004 Modified By: Modified on:
 *         PCR#
 */

public class FwException extends RuntimeException {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String classID = "";
	private String methodID = "";
	private String parameterText = "";
	private String exceptionText = "";
	private int exceptionType;
	private String messageCode = "";
	private String messageText = "";
	private String serviceName = "";
	private String serviceMethod = "";
	private String serviceDescription = "";
	private String serviceMessage = "";
	private String stackTraceValue = "";
	private String showFullExp = "Y"; 
	// defaulted to Y. always should show full
	// exception by default
	private boolean isLoggable = true; 
	// defaulted to true. always should log
	// by default

	private static final String DEFAULTSTRINGVALUE = "";

	/**
	 * FwException constructor.
	 */
	public FwException(final Throwable t) {
		super(t);
	}

	public FwException() {
		super();
	}

	public FwException(final String message) {
		super(message);
	}

	public FwException(final String message, final Throwable throwable) {
		super(message, throwable);
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getClassID() {
		return classID;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getExceptionText() {
		return exceptionText;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public int getExceptionType() {
		return exceptionType;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getMessageCode() {
		return messageCode;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getMessageText() {
		return messageText;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getMethodID() {
		return methodID;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getParameterText() {
		return parameterText;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getServiceDescription() {
		return serviceDescription;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getServiceMessage() {
		return serviceMessage;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getServiceMethod() {
		return serviceMethod;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getStackTraceValue() {
		return stackTraceValue;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setClassID(final String aClassID) {
		classID = aClassID != null ? aClassID : DEFAULTSTRINGVALUE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setExceptionText(final String aExceptionText) {
		exceptionText = aExceptionText != null ? aExceptionText : DEFAULTSTRINGVALUE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setExceptionType(final int aExceptionType) {
		exceptionType = aExceptionType;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setMessageCode(final String aMessageCode) {
		messageCode = aMessageCode != null ? aMessageCode : DEFAULTSTRINGVALUE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setMethodID(final String aMethodID) {
		methodID = aMethodID != null ? aMethodID : DEFAULTSTRINGVALUE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setParameterText(final String aParameterText) {
		parameterText = aParameterText != null ? aParameterText : DEFAULTSTRINGVALUE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setServiceDescription(final String aServiceDescription) {
		serviceDescription = aServiceDescription != null ? aServiceDescription : DEFAULTSTRINGVALUE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setServiceMessage(final String aServiceMessage) {
		serviceMessage = aServiceMessage != null ? aServiceMessage : DEFAULTSTRINGVALUE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setServiceMethod(final String aServiceMethod) {
		serviceMethod = aServiceMethod != null ? aServiceMethod : DEFAULTSTRINGVALUE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setServiceName(final String aServiceName) {
		serviceName = aServiceName != null ? aServiceName : DEFAULTSTRINGVALUE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setStackTraceValue(final String aStackTraceValue) {
		stackTraceValue = aStackTraceValue != null ? aStackTraceValue : DEFAULTSTRINGVALUE;
	}

	public String inspectException() {

		final StringBuilder temp = new StringBuilder();
		temp.append(" | classID=").append(classID).append(" | MethodID=").append(methodID).append(" | exceptionText=").append(exceptionText)
				.append(" | exceptionType=").append(exceptionType).append(" | messageCode=").append(messageCode).append(" | messageText=")
				.append(messageText).append(" | serviceName=").append(serviceName).append(" | serviceMethod=").append(serviceMethod)
				.append(" | serviceDescription=").append(serviceDescription).append(" | serviceMessage=").append(serviceMessage)
				.append(" | parameterText=").append(parameterText).append(" | stackTraceValue=").append(stackTraceValue);
		return temp.toString();

	}

	/**
	 * Enter the description of the method Creation Date:
	 */
	public boolean isLoggable() {
		return isLoggable;
	}

	/**
	 * Enter the description of the method Creation Date:
	 */
	public String getShowFullExp() {
		return showFullExp;
	}

	/**
	 * Enter the description of the method Creation Date:
	 */
	public void setLoggable(final boolean b) {
		isLoggable = b;
	}

	/**
	 * Enter the description of the method Creation Date:
	 */
	public void setShowFullExp(final String str) {
		showFullExp = str;
	}

}

