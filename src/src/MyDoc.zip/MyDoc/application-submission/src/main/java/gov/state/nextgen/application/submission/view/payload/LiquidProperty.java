package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class LiquidProperty {
	private String hldrFirstName;
	private String hldrLastName;
	private String hldrMidName;
	private String instName;
	private Boolean jointInd;
	private String assetName;
	@JsonIgnore
	private String accountNumber;
	@JsonIgnore
	private boolean courtOrderedAccount;
	@JsonIgnore
	private double curMonthlyInc;	
	@JsonIgnore
	private String maturityDate;
	@JsonIgnore
	private String courtPetitionFilingDate;
	@JsonIgnore
	private String courtPetitionReviewDate;
	@JsonIgnore
	private String coutPetitionStatus;
	@JsonIgnore
	private Address bankAddress;
	@JsonIgnore
	private String revocableCode;
	@JsonIgnore
	private String establishDate;
	@JsonIgnore
	private boolean ownedInd;
	@JsonIgnore
	private String grantorLastName;
	@JsonIgnore
	private String grantorFirstName;
	@JsonIgnore
	private String grantorMi;
	@JsonIgnore
	private String grantorSuf;
	@JsonIgnore
	private String remainderLast;
	@JsonIgnore
	private String remainderFirst;
	@JsonIgnore
	private String remainderMid;
	@JsonIgnore
	private String remainderSuf;
	@JsonIgnore
	private String benLast;
	@JsonIgnore
	private String benFirst;
	@JsonIgnore
	private String benMid;
	@JsonIgnore
	private String benSuf;
	@JsonIgnore
	private String communityProperty;
	@JsonIgnore
	private String rscDpDate;
	@JsonIgnore
	private double dpAmount;
	@JsonIgnore
	private String dpRecieveDate;
	@JsonIgnore
	private String dpTransferDate;

	public String getHldrFirstName() {
		return hldrFirstName;
	}

	public void setHldrFirstName(String hldrFirstName) {
		this.hldrFirstName = hldrFirstName;
	}

	public String getHldrLastName() {
		return hldrLastName;
	}

	public void setHldrLastName(String hldrLastName) {
		this.hldrLastName = hldrLastName;
	}

	public String getHldrMidName() {
		return hldrMidName;
	}

	public void setHldrMidName(String hldrMidName) {
		this.hldrMidName = hldrMidName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public boolean isCourtOrderedAccount() {
		return courtOrderedAccount;
	}

	public void setCourtOrderedAccount(boolean courtOrderedAccount) {
		this.courtOrderedAccount = courtOrderedAccount;
	}

	public double getCurMonthlyInc() {
		return curMonthlyInc;
	}

	public void setCurMonthlyInc(double curMonthlyInc) {
		this.curMonthlyInc = curMonthlyInc;
	}

	public String getInstName() {
		return instName;
	}

	public void setInstName(String instName) {
		this.instName = instName;
	}

	public String getMaturityDate() {
		return maturityDate;
	}

	public void setMaturityDate(String maturityDate) {
		this.maturityDate = maturityDate;
	}

	public String getCourtPetitionFilingDate() {
		return courtPetitionFilingDate;
	}

	public void setCourtPetitionFilingDate(String courtPetitionFilingDate) {
		this.courtPetitionFilingDate = courtPetitionFilingDate;
	}

	public String getCourtPetitionReviewDate() {
		return courtPetitionReviewDate;
	}

	public void setCourtPetitionReviewDate(String courtPetitionReviewDate) {
		this.courtPetitionReviewDate = courtPetitionReviewDate;
	}

	public String getCoutPetitionStatus() {
		return coutPetitionStatus;
	}

	public void setCoutPetitionStatus(String coutPetitionStatus) {
		this.coutPetitionStatus = coutPetitionStatus;
	}

	public Address getBankAddress() {
		return bankAddress;
	}

	public void setBankAddress(Address bankAddress) {
		this.bankAddress = bankAddress;
	}

	public String getRevocableCode() {
		return revocableCode;
	}

	public void setRevocableCode(String revocableCode) {
		this.revocableCode = revocableCode;
	}

	public String getEstablishDate() {
		return establishDate;
	}

	public void setEstablishDate(String establishDate) {
		this.establishDate = establishDate;
	}

	public boolean isOwnedInd() {
		return ownedInd;
	}

	public void setOwnedInd(boolean ownedInd) {
		this.ownedInd = ownedInd;
	}

	public String getGrantorLastName() {
		return grantorLastName;
	}

	public void setGrantorLastName(String grantorLastName) {
		this.grantorLastName = grantorLastName;
	}

	public String getGrantorFirstName() {
		return grantorFirstName;
	}

	public void setGrantorFirstName(String grantorFirstName) {
		this.grantorFirstName = grantorFirstName;
	}

	public String getGrantorMi() {
		return grantorMi;
	}

	public void setGrantorMi(String grantorMi) {
		this.grantorMi = grantorMi;
	}

	public String getGrantorSuf() {
		return grantorSuf;
	}

	public void setGrantorSuf(String grantorSuf) {
		this.grantorSuf = grantorSuf;
	}

	public String getRemainderLast() {
		return remainderLast;
	}

	public void setRemainderLast(String remainderLast) {
		this.remainderLast = remainderLast;
	}

	public String getRemainderFirst() {
		return remainderFirst;
	}

	public void setRemainderFirst(String remainderFirst) {
		this.remainderFirst = remainderFirst;
	}

	public String getRemainderMid() {
		return remainderMid;
	}

	public void setRemainderMid(String remainderMid) {
		this.remainderMid = remainderMid;
	}

	public String getRemainderSuf() {
		return remainderSuf;
	}

	public void setRemainderSuf(String remainderSuf) {
		this.remainderSuf = remainderSuf;
	}

	public String getBenLast() {
		return benLast;
	}

	public void setBenLast(String benLast) {
		this.benLast = benLast;
	}

	public String getBenFirst() {
		return benFirst;
	}

	public void setBenFirst(String benFirst) {
		this.benFirst = benFirst;
	}

	public String getBenMid() {
		return benMid;
	}

	public void setBenMid(String benMid) {
		this.benMid = benMid;
	}

	public String getBenSuf() {
		return benSuf;
	}

	public void setBenSuf(String benSuf) {
		this.benSuf = benSuf;
	}

	public String getCommunityProperty() {
		return communityProperty;
	}

	public void setCommunityProperty(String communityProperty) {
		this.communityProperty = communityProperty;
	}

	public String getRscDpDate() {
		return rscDpDate;
	}

	public void setRscDpDate(String rscDpDate) {
		this.rscDpDate = rscDpDate;
	}

	public double getDpAmount() {
		return dpAmount;
	}

	public void setDpAmount(double dpAmount) {
		this.dpAmount = dpAmount;
	}

	public String getDpRecieveDate() {
		return dpRecieveDate;
	}

	public void setDpRecieveDate(String dpRecieveDate) {
		this.dpRecieveDate = dpRecieveDate;
	}

	public String getDpTransferDate() {
		return dpTransferDate;
	}

	public void setDpTransferDate(String dpTransferDate) {
		this.dpTransferDate = dpTransferDate;
	}

	public Boolean isJointInd() {
		return jointInd;
	}

	public void setJointInd(Boolean jointInd) {
		this.jointInd = jointInd;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	
}
