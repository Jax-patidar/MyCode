package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class CP_APP_PGM_INDV_Collection {

	private Double indv_seq_num;
	
	private int tanf_rqst_ind;
	
	private int fs_rqst_ind;
	
	private int fma_rqst_ind;
	
	private int ggr_ind;

	public Double getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(Double indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public int getTanf_rqst_ind() {
		return tanf_rqst_ind;
	}

	public void setTanf_rqst_ind(int tanf_rqst_ind) {
		this.tanf_rqst_ind = tanf_rqst_ind;
	}

	public int getFs_rqst_ind() {
		return fs_rqst_ind;
	}

	public void setFs_rqst_ind(int fs_rqst_ind) {
		this.fs_rqst_ind = fs_rqst_ind;
	}

	public int getFma_rqst_ind() {
		return fma_rqst_ind;
	}

	public void setFma_rqst_ind(int fma_rqst_ind) {
		this.fma_rqst_ind = fma_rqst_ind;
	}

	public int getGgr_ind() {
		return ggr_ind;
	}

	public void setGgr_ind(int ggr_ind) {
		this.ggr_ind = ggr_ind;
	}
	
	
}
