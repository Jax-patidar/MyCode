package gov.state.nextgen.application.submission.view.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class HealthCoverage {

	private Boolean employerInd;
	private String typeCode;
	private String providerName;
	@JsonIgnore
	private String providerAbsentParent;
	@JsonIgnore
	private String employerName;
	@JsonIgnore
	private String enrollmentStatus;
	@JsonIgnore
	private double monthlyPremium;
	private Boolean minimumStandardValue;
	@JsonIgnore
	private String companyCode;
	@JsonIgnore
	private PhoneNumber phoneNumber;
	@JsonIgnore
	private String otherInsCompany;
	@JsonIgnore
	private String beginDate;
	@JsonIgnore
	private String endDate;
	private String policyHolderLastName;
	private String policyHolderFirstName;
	private String policyHolderMiddleInitial;
	private String policyHolderSuffix;
	private String policyHolderSSN;
	private String policyHolderNumber;
	private Boolean insuranceEndsin90Ind;
	@JsonIgnore
	private PhoneNumber policyHolderPhone;
	@JsonIgnore
	private Address address;
	@JsonIgnore
	private String employerIdentificationNumber;
	@JsonIgnore
	private String employeeContactName;
	private PhoneNumber otherPhoneNumber;
	private String employerEmailAddress;
	private String freqCode;
	private Boolean empChangeNoCovrg;
	private Boolean empChangeStartCovrg;
	private Boolean empChangePremium;
	private Boolean empNoChange;
	private Boolean cobraInd;
	private Boolean retireeHealthPlanInd;
	private Boolean stateEmpBenefitPlanInd;
	private Boolean limitedBenefitPlanInd;
	private List<WhoElseCovered> whoElseCovered;
	private String enrollmentDate;
	private String insurCompanyName;
	private String insurCoverageEndReason;
	private Boolean empWellnessPgmInd;
	private String empPlanChangeDate;

	public Boolean isEmployerInd() {
		return employerInd;
	}

	public void setEmployerInd(Boolean employerInd) {
		this.employerInd = employerInd;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getProviderAbsentParent() {
		return providerAbsentParent;
	}

	public void setProviderAbsentParent(String providerAbsentParent) {
		this.providerAbsentParent = providerAbsentParent;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getEnrollmentStatus() {
		return enrollmentStatus;
	}

	public void setEnrollmentStatus(String enrollmentStatus) {
		this.enrollmentStatus = enrollmentStatus;
	}

	public double getMonthlyPremium() {
		return monthlyPremium;
	}

	public void setMonthlyPremium(double monthlyPremium) {
		this.monthlyPremium = monthlyPremium;
	}

	public Boolean isMinimumStandardValue() {
		return minimumStandardValue;
	}

	public void setMinimumStandardValue(Boolean minimumStandardValue) {
		this.minimumStandardValue = minimumStandardValue;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public PhoneNumber getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(PhoneNumber phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getOtherInsCompany() {
		return otherInsCompany;
	}

	public void setOtherInsCompany(String otherInsCompany) {
		this.otherInsCompany = otherInsCompany;
	}

	public String getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getPolicyHolderLastName() {
		return policyHolderLastName;
	}

	public void setPolicyHolderLastName(String policyHolderLastName) {
		this.policyHolderLastName = policyHolderLastName;
	}

	public String getPolicyHolderFirstName() {
		return policyHolderFirstName;
	}

	public void setPolicyHolderFirstName(String policyHolderFirstName) {
		this.policyHolderFirstName = policyHolderFirstName;
	}

	public String getPolicyHolderMiddleInitial() {
		return policyHolderMiddleInitial;
	}

	public void setPolicyHolderMiddleInitial(String policyHolderMiddleInitial) {
		this.policyHolderMiddleInitial = policyHolderMiddleInitial;
	}

	public String getPolicyHolderSuffix() {
		return policyHolderSuffix;
	}

	public void setPolicyHolderSuffix(String policyHolderSuffix) {
		this.policyHolderSuffix = policyHolderSuffix;
	}

	public String getPolicyHolderSSN() {
		return policyHolderSSN;
	}

	public void setPolicyHolderSSN(String policyHolderSSN) {
		this.policyHolderSSN = policyHolderSSN;
	}

	public String getPolicyHolderNumber() {
		return policyHolderNumber;
	}

	public void setPolicyHolderNumber(String policyHolderNumber) {
		this.policyHolderNumber = policyHolderNumber;
	}

	public Boolean isInsuranceEndsin90Ind() {
		return insuranceEndsin90Ind;
	}

	public void setInsuranceEndsin90Ind(Boolean insuranceEndsin90Ind) {
		this.insuranceEndsin90Ind = insuranceEndsin90Ind;
	}

	public PhoneNumber getPolicyHolderPhone() {
		return policyHolderPhone;
	}

	public void setPolicyHolderPhone(PhoneNumber policyHolderPhone) {
		this.policyHolderPhone = policyHolderPhone;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getEmployerIdentificationNumber() {
		return employerIdentificationNumber;
	}

	public void setEmployerIdentificationNumber(String employerIdentificationNumber) {
		this.employerIdentificationNumber = employerIdentificationNumber;
	}

	public String getEmployeeContactName() {
		return employeeContactName;
	}

	public void setEmployeeContactName(String employeeContactName) {
		this.employeeContactName = employeeContactName;
	}

	public PhoneNumber getOtherPhoneNumber() {
		return otherPhoneNumber;
	}

	public void setOtherPhoneNumber(PhoneNumber otherPhoneNumber) {
		this.otherPhoneNumber = otherPhoneNumber;
	}

	public String getEmployerEmailAddress() {
		return employerEmailAddress;
	}

	public void setEmployerEmailAddress(String employerEmailAddress) {
		this.employerEmailAddress = employerEmailAddress;
	}

	public String getFreqCode() {
		return freqCode;
	}

	public void setFreqCode(String freqCode) {
		this.freqCode = freqCode;
	}

	public Boolean isEmpChangeNoCovrg() {
		return empChangeNoCovrg;
	}

	public void setEmpChangeNoCovrg(Boolean empChangeNoCovrg) {
		this.empChangeNoCovrg = empChangeNoCovrg;
	}

	public Boolean isEmpChangeStartCovrg() {
		return empChangeStartCovrg;
	}

	public void setEmpChangeStartCovrg(Boolean empChangeStartCovrg) {
		this.empChangeStartCovrg = empChangeStartCovrg;
	}

	public Boolean isEmpChangePremium() {
		return empChangePremium;
	}

	public void setEmpChangePremium(Boolean empChangePremium) {
		this.empChangePremium = empChangePremium;
	}

	public Boolean isEmpNoChange() {
		return empNoChange;
	}

	public void setEmpNoChange(Boolean empNoChange) {
		this.empNoChange = empNoChange;
	}

	public Boolean isCobraInd() {
		return cobraInd;
	}

	public void setCobraInd(Boolean cobraInd) {
		this.cobraInd = cobraInd;
	}

	public Boolean isRetireeHealthPlanInd() {
		return retireeHealthPlanInd;
	}

	public void setRetireeHealthPlanInd(Boolean retireeHealthPlanInd) {
		this.retireeHealthPlanInd = retireeHealthPlanInd;
	}

	public Boolean isStateEmpBenefitPlanInd() {
		return stateEmpBenefitPlanInd;
	}

	public void setStateEmpBenefitPlanInd(Boolean stateEmpBenefitPlanInd) {
		this.stateEmpBenefitPlanInd = stateEmpBenefitPlanInd;
	}

	public Boolean isLimitedBenefitPlanInd() {
		return limitedBenefitPlanInd;
	}

	public void setLimitedBenefitPlanInd(Boolean limitedBenefitPlanInd) {
		this.limitedBenefitPlanInd = limitedBenefitPlanInd;
	}

	public List<WhoElseCovered> getWhoElseCovered() {
		return whoElseCovered;
	}

	public void setWhoElseCovered(List<WhoElseCovered> whoElseCovered) {
		this.whoElseCovered = whoElseCovered;
	}

	public String getEnrollmentDate() {
		return enrollmentDate;
	}

	public void setEnrollmentDate(String enrollmentDate) {
		this.enrollmentDate = enrollmentDate;
	}

	public String getInsurCompanyName() {
		return insurCompanyName;
	}

	public void setInsurCompanyName(String insurCompanyName) {
		this.insurCompanyName = insurCompanyName;
	}

	public String getInsurCoverageEndReason() {
		return insurCoverageEndReason;
	}

	public void setInsurCoverageEndReason(String insurCoverageEndReason) {
		this.insurCoverageEndReason = insurCoverageEndReason;
	}

	public Boolean isEmpWellnessPgmInd() {
		return empWellnessPgmInd;
	}

	public void setEmpWellnessPgmInd(Boolean empWellnessPgmInd) {
		this.empWellnessPgmInd = empWellnessPgmInd;
	}

	public String getEmpPlanChangeDate() {
		return empPlanChangeDate;
	}

	public void setEmpPlanChangeDate(String empPlanChangeDate) {
		this.empPlanChangeDate = empPlanChangeDate;
	}
}
