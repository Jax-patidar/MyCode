package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class Residence {

	@JsonIgnore
	private boolean laResidentInd;
	@JsonIgnore
	private boolean caResidentInd;
	@JsonIgnore
	private boolean intentToReside;
	@JsonIgnore
	private String dateArrived;

	public boolean isLaResidentInd() {
		return laResidentInd;
	}

	public void setLaResidentInd(boolean laResidentInd) {
		this.laResidentInd = laResidentInd;
	}

	public boolean isCaResidentInd() {
		return caResidentInd;
	}

	public void setCaResidentInd(boolean caResidentInd) {
		this.caResidentInd = caResidentInd;
	}

	public boolean isIntentToReside() {
		return intentToReside;
	}

	public void setIntentToReside(boolean intentToReside) {
		this.intentToReside = intentToReside;
	}

	public String getDateArrived() {
		return dateArrived;
	}

	public void setDateArrived(String dateArrived) {
		this.dateArrived = dateArrived;
	}

}
