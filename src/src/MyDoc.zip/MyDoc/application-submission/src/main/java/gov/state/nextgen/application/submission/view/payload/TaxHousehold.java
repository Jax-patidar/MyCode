package gov.state.nextgen.application.submission.view.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class TaxHousehold {
	private String spousePersId;
	private String spouseFirstName;
	private String spouseMiddleName;
	private String spouseLastName;
	private int autoEnrollNumYears;
	private boolean primaryTaxFilerInd;
	@JsonIgnore
	private int currentYear;
	private Boolean expectFileInd;
	@JsonIgnore
	private boolean priorFileInd;
	@JsonIgnore
	private String piorFileStatCode;
	@JsonIgnore
	private String expectFileStatCode;
	private List<TaxDependent> taxDependents;

	public String getSpousePersId() {
		return spousePersId;
	}

	public void setSpousePersId(String spousePersId) {
		this.spousePersId = spousePersId;
	}

	public String getSpouseFirstName() {
		return spouseFirstName;
	}

	public void setSpouseFirstName(String spouseFirstName) {
		this.spouseFirstName = spouseFirstName;
	}

	public String getSpouseMiddleName() {
		return spouseMiddleName;
	}

	public void setSpouseMiddleName(String spouseMiddleName) {
		this.spouseMiddleName = spouseMiddleName;
	}

	public String getSpouseLastName() {
		return spouseLastName;
	}

	public void setSpouseLastName(String spouseLastName) {
		this.spouseLastName = spouseLastName;
	}

	public int getAutoEnrollNumYears() {
		return autoEnrollNumYears;
	}

	public void setAutoEnrollNumYears(int autoEnrollNumYears) {
		this.autoEnrollNumYears = autoEnrollNumYears;
	}

	public boolean isPrimaryTaxFilerInd() {
		return primaryTaxFilerInd;
	}

	public void setPrimaryTaxFilerInd(boolean primaryTaxFilerInd) {
		this.primaryTaxFilerInd = primaryTaxFilerInd;
	}

	public int getCurrentYear() {
		return currentYear;
	}

	public void setCurrentYear(int currentYear) {
		this.currentYear = currentYear;
	}

	public Boolean isExpectFileInd() {
		return expectFileInd;
	}

	public void setExpectFileInd(Boolean expectFileInd) {
		this.expectFileInd = expectFileInd;
	}

	public boolean isPriorFileInd() {
		return priorFileInd;
	}

	public void setPriorFileInd(boolean priorFileInd) {
		this.priorFileInd = priorFileInd;
	}

	public String getPiorFileStatCode() {
		return piorFileStatCode;
	}

	public void setPiorFileStatCode(String piorFileStatCode) {
		this.piorFileStatCode = piorFileStatCode;
	}

	public String getExpectFileStatCode() {
		return expectFileStatCode;
	}

	public void setExpectFileStatCode(String expectFileStatCode) {
		this.expectFileStatCode = expectFileStatCode;
	}

	public List<TaxDependent> getTaxDependents() {
		return taxDependents;
	}

	public void setTaxDependents(List<TaxDependent> taxDependents) {
		this.taxDependents = taxDependents;
	}
}
