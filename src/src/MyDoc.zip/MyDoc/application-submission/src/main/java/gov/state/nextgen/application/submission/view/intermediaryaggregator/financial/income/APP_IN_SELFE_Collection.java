package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income;

public class APP_IN_SELFE_Collection {
	private String user;
    private String cargoName;
    private String rowAction;
    private String adaptRecordId;
    private String delete_reason_cd;
    private String app_num;
    private int indv_seq_num;
    private int seq_num;
    private String src_app_ind;
    private double avg_incm_amt;
    private String avg_incm_ind;
    private String chg_eff_dt;
    private String dprc_amt;
    private String dprc_ind;
    private double exp_amt;
    private int exp_ind;
    private String hr_work_mo_ind;
    private String hr_work_mo_qty;
    private int rec_cplt_ind;
    private String self_empl_typ;
    private String self_mng_sw;
    private String eff_begin_dt;
    private String expected_to_cont_resp;
    private String bus_nam;
    private String self_empl_beg_mo;
    private String bus_tax_id_num;
    private String bus_tax_file_yr;
    private String bus_sgnf_chg_ind;
    private String bus_sgnf_chg_mo;
    private String bus_owsp_typ;
    private String fst_name;
    private String self_empl_bus_nam;
    private String ecp_id;
    private String chg_dt;
    private double amount;
    private String pay_freq;
    private String gross_mthly_income_amt;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public int getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public double getAvg_incm_amt() {
		return avg_incm_amt;
	}
	public void setAvg_incm_amt(double avg_incm_amt) {
		this.avg_incm_amt = avg_incm_amt;
	}
	public String getAvg_incm_ind() {
		return avg_incm_ind;
	}
	public void setAvg_incm_ind(String avg_incm_ind) {
		this.avg_incm_ind = avg_incm_ind;
	}
	public String getChg_eff_dt() {
		return chg_eff_dt;
	}
	public void setChg_eff_dt(String chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}
	public String getDprc_amt() {
		return dprc_amt;
	}
	public void setDprc_amt(String dprc_amt) {
		this.dprc_amt = dprc_amt;
	}
	public String getDprc_ind() {
		return dprc_ind;
	}
	public void setDprc_ind(String dprc_ind) {
		this.dprc_ind = dprc_ind;
	}
	public double getExp_amt() {
		return exp_amt;
	}
	public void setExp_amt(double exp_amt) {
		this.exp_amt = exp_amt;
	}
	public int getExp_ind() {
		return exp_ind;
	}
	public void setExp_ind(int exp_ind) {
		this.exp_ind = exp_ind;
	}
	public String getHr_work_mo_ind() {
		return hr_work_mo_ind;
	}
	public void setHr_work_mo_ind(String hr_work_mo_ind) {
		this.hr_work_mo_ind = hr_work_mo_ind;
	}
	public String getHr_work_mo_qty() {
		return hr_work_mo_qty;
	}
	public void setHr_work_mo_qty(String hr_work_mo_qty) {
		this.hr_work_mo_qty = hr_work_mo_qty;
	}
	public int getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(int rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getSelf_empl_typ() {
		return self_empl_typ;
	}
	public void setSelf_empl_typ(String self_empl_typ) {
		this.self_empl_typ = self_empl_typ;
	}
	public String getSelf_mng_sw() {
		return self_mng_sw;
	}
	public void setSelf_mng_sw(String self_mng_sw) {
		this.self_mng_sw = self_mng_sw;
	}
	public String getEff_begin_dt() {
		return eff_begin_dt;
	}
	public void setEff_begin_dt(String eff_begin_dt) {
		this.eff_begin_dt = eff_begin_dt;
	}
	public String getExpected_to_cont_resp() {
		return expected_to_cont_resp;
	}
	public void setExpected_to_cont_resp(String expected_to_cont_resp) {
		this.expected_to_cont_resp = expected_to_cont_resp;
	}
	public String getBus_nam() {
		return bus_nam;
	}
	public void setBus_nam(String bus_nam) {
		this.bus_nam = bus_nam;
	}
	public String getSelf_empl_beg_mo() {
		return self_empl_beg_mo;
	}
	public void setSelf_empl_beg_mo(String self_empl_beg_mo) {
		this.self_empl_beg_mo = self_empl_beg_mo;
	}
	public String getBus_tax_id_num() {
		return bus_tax_id_num;
	}
	public void setBus_tax_id_num(String bus_tax_id_num) {
		this.bus_tax_id_num = bus_tax_id_num;
	}
	public String getBus_tax_file_yr() {
		return bus_tax_file_yr;
	}
	public void setBus_tax_file_yr(String bus_tax_file_yr) {
		this.bus_tax_file_yr = bus_tax_file_yr;
	}
	public String getBus_sgnf_chg_ind() {
		return bus_sgnf_chg_ind;
	}
	public void setBus_sgnf_chg_ind(String bus_sgnf_chg_ind) {
		this.bus_sgnf_chg_ind = bus_sgnf_chg_ind;
	}
	public String getBus_sgnf_chg_mo() {
		return bus_sgnf_chg_mo;
	}
	public void setBus_sgnf_chg_mo(String bus_sgnf_chg_mo) {
		this.bus_sgnf_chg_mo = bus_sgnf_chg_mo;
	}
	public String getBus_owsp_typ() {
		return bus_owsp_typ;
	}
	public void setBus_owsp_typ(String bus_owsp_typ) {
		this.bus_owsp_typ = bus_owsp_typ;
	}
	public String getFst_name() {
		return fst_name;
	}
	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}
	public String getSelf_empl_bus_nam() {
		return self_empl_bus_nam;
	}
	public void setSelf_empl_bus_nam(String self_empl_bus_nam) {
		this.self_empl_bus_nam = self_empl_bus_nam;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getPay_freq() {
		return pay_freq;
	}
	public void setPay_freq(String pay_freq) {
		this.pay_freq = pay_freq;
	}
	public String getGross_mthly_income_amt() {
		return gross_mthly_income_amt;
	}
	public void setGross_mthly_income_amt(String gross_mthly_income_amt) {
		this.gross_mthly_income_amt = gross_mthly_income_amt;
	}
}
