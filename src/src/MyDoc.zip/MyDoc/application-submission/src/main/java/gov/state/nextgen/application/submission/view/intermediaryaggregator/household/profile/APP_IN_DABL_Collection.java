package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class APP_IN_DABL_Collection {

	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int indv_seq_num;
	private String src_app_ind;
	private int seq_num;
	private String ssa_applied_last_dt;
	private String blnd_dt;
	private String dabl_dt;
	private String estb_blnd_resp;
	private String estb_dabl_resp;
	private String irwe_sw;
	private String rec_cplt_ind;
	private String uabl_work_sw;
	private String reduced_child_care_ind;
	private String someone_provide_care_ind;
	private String ssi_payment_stopped_ind;
	private String ssi_railrdret_ben_app_ind;
	private String ssi_received_ind;
	private String medical_cond_post_denial_dtl;
	private String medical_cond_post_denial_ind;
	private String no_long_caring_disabled_resp;
	private String no_long_disabled_resp;
	private String benefit_denial_appeal_ind;
	private String benefit_denial_appeal_outcome;
	private String caring_disabled_resp;
	private String disability_end_dt;
	private String dabl_type_cd;
	private String ssa_dbal_appr_src_oth_dsc;
	private String ssa_dbal_appr_src_cd;
	private String dabl_type_oth_dsc;
	private String ssa_dbal_bnft_rcv_ind;
	private String estb_phy_resp;
	private String ecp_id;
	private String loopingQuestion;
	private String fts_nam;
	private String firstname;
	private String lastname;
	private int age;
	private String dabl_lim_activity_ind;
	private String nursing_care_ind;
	private String dabl_caring_desc;
	private String need_care_work_schl_ind;
	private String need_care_other_hhm;
	private String need_care_other_hhm_desc;
	private String dabl_med_expens_work_ind;
	private String dabl_med_expens_work_desc;
	private String dabl_more_than_one_yr_ind;
	private String nur_hspc_prvd_nm;
	private String chg_dt;

	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public int getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}
	public String getSsa_applied_last_dt() {
		return ssa_applied_last_dt;
	}
	public void setSsa_applied_last_dt(String ssa_applied_last_dt) {
		this.ssa_applied_last_dt = ssa_applied_last_dt;
	}
	public String getBlnd_dt() {
		return blnd_dt;
	}
	public void setBlnd_dt(String blnd_dt) {
		this.blnd_dt = blnd_dt;
	}
	public String getDabl_dt() {
		return dabl_dt;
	}
	public void setDabl_dt(String dabl_dt) {
		this.dabl_dt = dabl_dt;
	}
	public String getEstb_blnd_resp() {
		return estb_blnd_resp;
	}
	public void setEstb_blnd_resp(String estb_blnd_resp) {
		this.estb_blnd_resp = estb_blnd_resp;
	}
	public String getEstb_dabl_resp() {
		return estb_dabl_resp;
	}
	public void setEstb_dabl_resp(String estb_dabl_resp) {
		this.estb_dabl_resp = estb_dabl_resp;
	}
	public String getIrwe_sw() {
		return irwe_sw;
	}
	public void setIrwe_sw(String irwe_sw) {
		this.irwe_sw = irwe_sw;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getUabl_work_sw() {
		return uabl_work_sw;
	}
	public void setUabl_work_sw(String uabl_work_sw) {
		this.uabl_work_sw = uabl_work_sw;
	}
	public String getReduced_child_care_ind() {
		return reduced_child_care_ind;
	}
	public void setReduced_child_care_ind(String reduced_child_care_ind) {
		this.reduced_child_care_ind = reduced_child_care_ind;
	}
	public String getSomeone_provide_care_ind() {
		return someone_provide_care_ind;
	}
	public void setSomeone_provide_care_ind(String someone_provide_care_ind) {
		this.someone_provide_care_ind = someone_provide_care_ind;
	}
	public String getSsi_payment_stopped_ind() {
		return ssi_payment_stopped_ind;
	}
	public void setSsi_payment_stopped_ind(String ssi_payment_stopped_ind) {
		this.ssi_payment_stopped_ind = ssi_payment_stopped_ind;
	}
	public String getSsi_railrdret_ben_app_ind() {
		return ssi_railrdret_ben_app_ind;
	}
	public void setSsi_railrdret_ben_app_ind(String ssi_railrdret_ben_app_ind) {
		this.ssi_railrdret_ben_app_ind = ssi_railrdret_ben_app_ind;
	}
	public String getSsi_received_ind() {
		return ssi_received_ind;
	}
	public void setSsi_received_ind(String ssi_received_ind) {
		this.ssi_received_ind = ssi_received_ind;
	}
	public String getMedical_cond_post_denial_dtl() {
		return medical_cond_post_denial_dtl;
	}
	public void setMedical_cond_post_denial_dtl(String medical_cond_post_denial_dtl) {
		this.medical_cond_post_denial_dtl = medical_cond_post_denial_dtl;
	}
	public String getMedical_cond_post_denial_ind() {
		return medical_cond_post_denial_ind;
	}
	public void setMedical_cond_post_denial_ind(String medical_cond_post_denial_ind) {
		this.medical_cond_post_denial_ind = medical_cond_post_denial_ind;
	}
	public String getNo_long_caring_disabled_resp() {
		return no_long_caring_disabled_resp;
	}
	public void setNo_long_caring_disabled_resp(String no_long_caring_disabled_resp) {
		this.no_long_caring_disabled_resp = no_long_caring_disabled_resp;
	}
	public String getNo_long_disabled_resp() {
		return no_long_disabled_resp;
	}
	public void setNo_long_disabled_resp(String no_long_disabled_resp) {
		this.no_long_disabled_resp = no_long_disabled_resp;
	}
	public String getBenefit_denial_appeal_ind() {
		return benefit_denial_appeal_ind;
	}
	public void setBenefit_denial_appeal_ind(String benefit_denial_appeal_ind) {
		this.benefit_denial_appeal_ind = benefit_denial_appeal_ind;
	}
	public String getBenefit_denial_appeal_outcome() {
		return benefit_denial_appeal_outcome;
	}
	public void setBenefit_denial_appeal_outcome(String benefit_denial_appeal_outcome) {
		this.benefit_denial_appeal_outcome = benefit_denial_appeal_outcome;
	}
	public String getCaring_disabled_resp() {
		return caring_disabled_resp;
	}
	public void setCaring_disabled_resp(String caring_disabled_resp) {
		this.caring_disabled_resp = caring_disabled_resp;
	}
	public String getDisability_end_dt() {
		return disability_end_dt;
	}
	public void setDisability_end_dt(String disability_end_dt) {
		this.disability_end_dt = disability_end_dt;
	}
	public String getDabl_type_cd() {
		return dabl_type_cd;
	}
	public void setDabl_type_cd(String dabl_type_cd) {
		this.dabl_type_cd = dabl_type_cd;
	}
	public String getSsa_dbal_appr_src_oth_dsc() {
		return ssa_dbal_appr_src_oth_dsc;
	}
	public void setSsa_dbal_appr_src_oth_dsc(String ssa_dbal_appr_src_oth_dsc) {
		this.ssa_dbal_appr_src_oth_dsc = ssa_dbal_appr_src_oth_dsc;
	}
	public String getSsa_dbal_appr_src_cd() {
		return ssa_dbal_appr_src_cd;
	}
	public void setSsa_dbal_appr_src_cd(String ssa_dbal_appr_src_cd) {
		this.ssa_dbal_appr_src_cd = ssa_dbal_appr_src_cd;
	}
	public String getDabl_type_oth_dsc() {
		return dabl_type_oth_dsc;
	}
	public void setDabl_type_oth_dsc(String dabl_type_oth_dsc) {
		this.dabl_type_oth_dsc = dabl_type_oth_dsc;
	}
	public String getSsa_dbal_bnft_rcv_ind() {
		return ssa_dbal_bnft_rcv_ind;
	}
	public void setSsa_dbal_bnft_rcv_ind(String ssa_dbal_bnft_rcv_ind) {
		this.ssa_dbal_bnft_rcv_ind = ssa_dbal_bnft_rcv_ind;
	}
	public String getEstb_phy_resp() {
		return estb_phy_resp;
	}
	public void setEstb_phy_resp(String estb_phy_resp) {
		this.estb_phy_resp = estb_phy_resp;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getLoopingQuestion() {
		return loopingQuestion;
	}
	public void setLoopingQuestion(String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}
	public String getFts_nam() {
		return fts_nam;
	}
	public void setFts_nam(String fts_nam) {
		this.fts_nam = fts_nam;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getDabl_lim_activity_ind() {
		return dabl_lim_activity_ind;
	}
	public void setDabl_lim_activity_ind(String dabl_lim_activity_ind) {
		this.dabl_lim_activity_ind = dabl_lim_activity_ind;
	}
	public String getNursing_care_ind() {
		return nursing_care_ind;
	}
	public void setNursing_care_ind(String nursing_care_ind) {
		this.nursing_care_ind = nursing_care_ind;
	}
	public String getDabl_caring_desc() {
		return dabl_caring_desc;
	}
	public void setDabl_caring_desc(String dabl_caring_desc) {
		this.dabl_caring_desc = dabl_caring_desc;
	}
	public String getNeed_care_work_schl_ind() {
		return need_care_work_schl_ind;
	}
	public void setNeed_care_work_schl_ind(String need_care_work_schl_ind) {
		this.need_care_work_schl_ind = need_care_work_schl_ind;
	}
	public String getNeed_care_other_hhm() {
		return need_care_other_hhm;
	}
	public void setNeed_care_other_hhm(String need_care_other_hhm) {
		this.need_care_other_hhm = need_care_other_hhm;
	}
	public String getNeed_care_other_hhm_desc() {
		return need_care_other_hhm_desc;
	}
	public void setNeed_care_other_hhm_desc(String need_care_other_hhm_desc) {
		this.need_care_other_hhm_desc = need_care_other_hhm_desc;
	}
	public String getDabl_med_expens_work_ind() {
		return dabl_med_expens_work_ind;
	}
	public void setDabl_med_expens_work_ind(String dabl_med_expens_work_ind) {
		this.dabl_med_expens_work_ind = dabl_med_expens_work_ind;
	}
	public String getDabl_med_expens_work_desc() {
		return dabl_med_expens_work_desc;
	}
	public void setDabl_med_expens_work_desc(String dabl_med_expens_work_desc) {
		this.dabl_med_expens_work_desc = dabl_med_expens_work_desc;
	}
	public String getDabl_more_than_one_yr_ind() {
		return dabl_more_than_one_yr_ind;
	}
	public void setDabl_more_than_one_yr_ind(String dabl_more_than_one_yr_ind) {
		this.dabl_more_than_one_yr_ind = dabl_more_than_one_yr_ind;
	}
	public String getNur_hspc_prvd_nm() {
		return nur_hspc_prvd_nm;
	}
	public void setNur_hspc_prvd_nm(String nur_hspc_prvd_nm) {
		this.nur_hspc_prvd_nm = nur_hspc_prvd_nm;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
}
