package gov.state.nextgen.application.submission.view.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class DisasterCalFresh {
	private Boolean livedIndisasterArea;
	private Boolean workedIndisasterArea;
	private Boolean unableToGetIncome;
	private Boolean loweredIncome;
	private Boolean buyAndPrepareMeals;
	private Boolean employedbyStateAgency;
	private String employedbyWhichStateAgency;
	private double totalIncome;
	private String incomeSources;
	private double cashOnHand;
	private double savingAccounts;
	private double checkingAccounts;
	private double other;
	private List<Expenses> disasterExpense;
	private Boolean gettingCalFreshBenefits;
	private Boolean replaceBenefitsInd;
	private double replaceBenefitsAmount;

	public Boolean getLivedIndisasterArea() {
		return livedIndisasterArea;
	}

	public Boolean getWorkedIndisasterArea() {
		return workedIndisasterArea;
	}

	public Boolean getUnableToGetIncome() {
		return unableToGetIncome;
	}

	public Boolean getLoweredIncome() {
		return loweredIncome;
	}

	public Boolean getBuyAndPrepareMeals() {
		return buyAndPrepareMeals;
	}

	public Boolean getEmployedbyStateAgency() {
		return employedbyStateAgency;
	}

	public String getEmployedbyWhichStateAgency() {
		return employedbyWhichStateAgency;
	}

	public double getTotalIncome() {
		return totalIncome;
	}

	public void setTotalIncome(double totalIncome) {
		this.totalIncome = totalIncome;
	}

	public double getCashOnHand() {
		return cashOnHand;
	}

	public void setCashOnHand(double cashOnHand) {
		this.cashOnHand = cashOnHand;
	}

	public double getSavingAccounts() {
		return savingAccounts;
	}

	public void setSavingAccounts(double savingAccounts) {
		this.savingAccounts = savingAccounts;
	}

	public double getCheckingAccounts() {
		return checkingAccounts;
	}

	public void setCheckingAccounts(double checkingAccounts) {
		this.checkingAccounts = checkingAccounts;
	}

	public double getOther() {
		return other;
	}

	public void setOther(double other) {
		this.other = other;
	}

	public double getReplaceBenefitsAmount() {
		return replaceBenefitsAmount;
	}

	public void setReplaceBenefitsAmount(double replaceBenefitsAmount) {
		this.replaceBenefitsAmount = replaceBenefitsAmount;
	}

	public String getIncomeSources() {
		return incomeSources;
	}

	public Boolean getGettingCalFreshBenefits() {
		return gettingCalFreshBenefits;
	}

	public Boolean getReplaceBenefitsInd() {
		return replaceBenefitsInd;
	}

	public void setLivedIndisasterArea(Boolean livedIndisasterArea) {
		this.livedIndisasterArea = livedIndisasterArea;
	}

	public void setWorkedIndisasterArea(Boolean workedIndisasterArea) {
		this.workedIndisasterArea = workedIndisasterArea;
	}

	public void setUnableToGetIncome(Boolean unableToGetIncome) {
		this.unableToGetIncome = unableToGetIncome;
	}

	public void setLoweredIncome(Boolean loweredIncome) {
		this.loweredIncome = loweredIncome;
	}

	public void setBuyAndPrepareMeals(Boolean buyAndPrepareMeals) {
		this.buyAndPrepareMeals = buyAndPrepareMeals;
	}

	public void setEmployedbyStateAgency(Boolean employedbyStateAgency) {
		this.employedbyStateAgency = employedbyStateAgency;
	}

	public void setEmployedbyWhichStateAgency(String employedbyWhichStateAgency) {
		this.employedbyWhichStateAgency = employedbyWhichStateAgency;
	}
	
	public void setIncomeSources(String incomeSources) {
		this.incomeSources = incomeSources;
	}

	public void setGettingCalFreshBenefits(Boolean gettingCalFreshBenefits) {
		this.gettingCalFreshBenefits = gettingCalFreshBenefits;
	}

	public void setReplaceBenefitsInd(Boolean replaceBenefitsInd) {
		this.replaceBenefitsInd = replaceBenefitsInd;
	}

	public List<Expenses> getDisasterExpense() {
		return disasterExpense;
	}

	public void setDisasterExpense(List<Expenses> disasterExpense) {
		this.disasterExpense = disasterExpense;
	}
}