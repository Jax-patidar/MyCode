package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense;

public class FinancialExpenseSummaryDetails {
    
    private PageCollection pageCollection;

	public PageCollection getPageCollection() {
		if(pageCollection == null) {
			pageCollection = new PageCollection();
		}
		return pageCollection;
	}

	public void setPageCollection(PageCollection pageCollection) {
		this.pageCollection = pageCollection;
	}
    

}
