package gov.state.nextgen.application.submission.view.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class School {

	private String schoolName;
	private String schoolType;
	private String enrollCode;
	@JsonIgnore
	private String gradDate;
	private int unitsPerWeek;
	private String schoolTerm;
	@JsonIgnore
	private String degreeCode;
	@JsonIgnore
	private int roundTripMiles;
	@JsonIgnore
	private String transportationUsed;
	@JsonIgnore
	private boolean publicTransportationUsed;
	@JsonIgnore
	private double publicTransCost;
	@JsonIgnore
	private String unexpectedAbsence;
	@JsonIgnore
	private String dropOutDate;
	@JsonIgnore
	private boolean workStudyInd;
	private int avgWorkHrsPerWeek;
	private Boolean applyFinancialAidInd;
	@JsonIgnore
	private List<StudentFinancialAid> studentFinancialAid;

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolType() {
		return schoolType;
	}

	public void setSchoolType(String schoolType) {
		this.schoolType = schoolType;
	}

	public String getEnrollCode() {
		return enrollCode;
	}

	public void setEnrollCode(String enrollCode) {
		this.enrollCode = enrollCode;
	}

	public String getGradDate() {
		return gradDate;
	}

	public void setGradDate(String gradDate) {
		this.gradDate = gradDate;
	}

	public int getUnitsPerWeek() {
		return unitsPerWeek;
	}

	public void setUnitsPerWeek(int unitsPerWeek) {
		this.unitsPerWeek = unitsPerWeek;
	}

	public String getSchoolTerm() {
		return schoolTerm;
	}

	public void setSchoolTerm(String schoolTerm) {
		this.schoolTerm = schoolTerm;
	}

	public String getDegreeCode() {
		return degreeCode;
	}

	public void setDegreeCode(String degreeCode) {
		this.degreeCode = degreeCode;
	}

	public int getRoundTripMiles() {
		return roundTripMiles;
	}

	public void setRoundTripMiles(int roundTripMiles) {
		this.roundTripMiles = roundTripMiles;
	}

	public String getTransportationUsed() {
		return transportationUsed;
	}

	public void setTransportationUsed(String transportationUsed) {
		this.transportationUsed = transportationUsed;
	}

	public boolean isPublicTransportationUsed() {
		return publicTransportationUsed;
	}

	public void setPublicTransportationUsed(boolean publicTransportationUsed) {
		this.publicTransportationUsed = publicTransportationUsed;
	}

	public double getPublicTransCost() {
		return publicTransCost;
	}

	public void setPublicTransCost(double publicTransCost) {
		this.publicTransCost = publicTransCost;
	}

	public String getUnexpectedAbsence() {
		return unexpectedAbsence;
	}

	public void setUnexpectedAbsence(String unexpectedAbsence) {
		this.unexpectedAbsence = unexpectedAbsence;
	}

	public String getDropOutDate() {
		return dropOutDate;
	}

	public void setDropOutDate(String dropOutDate) {
		this.dropOutDate = dropOutDate;
	}

	public boolean isWorkStudyInd() {
		return workStudyInd;
	}

	public void setWorkStudyInd(boolean workStudyInd) {
		this.workStudyInd = workStudyInd;
	}

	public int getAvgWorkHrsPerWeek() {
		return avgWorkHrsPerWeek;
	}

	public void setAvgWorkHrsPerWeek(int avgWorkHrsPerWeek) {
		this.avgWorkHrsPerWeek = avgWorkHrsPerWeek;
	}

	public Boolean isApplyFinancialAidInd() {
		return applyFinancialAidInd;
	}

	public void setApplyFinancialAidInd(Boolean applyFinancialAidInd) {
		this.applyFinancialAidInd = applyFinancialAidInd;
	}

	public List<StudentFinancialAid> getStudentFinancialAid() {
		return studentFinancialAid;
	}

	public void setStudentFinancialAid(List<StudentFinancialAid> studentFinancialAid) {
		this.studentFinancialAid = studentFinancialAid;
	}
}
