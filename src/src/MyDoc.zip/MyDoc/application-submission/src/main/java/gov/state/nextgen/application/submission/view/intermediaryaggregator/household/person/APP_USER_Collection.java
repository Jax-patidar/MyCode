package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class APP_USER_Collection {
	
	private String acs_id;
	private String app_num;
	private String sbmt_acs_id;
	
	public String getAcs_id() {
		return acs_id;
	}
	public void setAcs_id(String acs_id) {
		this.acs_id = acs_id;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getSbmt_acs_id() {
		return sbmt_acs_id;
	}
	public void setSbmt_acs_id(String sbmt_acs_id) {
		this.sbmt_acs_id = sbmt_acs_id;
	}

}
