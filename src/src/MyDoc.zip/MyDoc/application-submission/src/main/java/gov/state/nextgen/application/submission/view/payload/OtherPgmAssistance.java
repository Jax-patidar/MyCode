package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class OtherPgmAssistance {
	private String programCode;
	private String programName;
	private String begDate;
	private String county;
	private String state;
	private double amount;
	private String frequency;
	private Boolean continueToReceiveInd;

	public String getProgramCode() {
		return programCode;
	}

	public void setProgramCode(String programCode) {
		this.programCode = programCode;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getBegDate() {
		return begDate;
	}

	public void setBegDate(String begDate) {
		this.begDate = begDate;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public Boolean isContinueToReceiveInd() {
		return continueToReceiveInd;
	}

	public void setContinueToReceiveInd(Boolean continueToReceiveInd) {
		this.continueToReceiveInd = continueToReceiveInd;
	}
	
}
