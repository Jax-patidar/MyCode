package gov.state.nextgen.application.submission.framework.exception;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.framework.model.CP_WEB_EXCP_Cargo;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import static gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants.EXECUTION_PROFILE_NOT_USED_IN_AWS;
import static gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants.LOCAL;


@Component
@EnableAsync
public class ExceptionLogManager {

    private AmazonSQS sqs = null;
    private String awsExceptionQueue;

    public ExceptionLogManager() {
        super();
        String executionProfile = System.getenv(EXECUTION_PROFILE_NOT_USED_IN_AWS);
        if (LOCAL.equals(executionProfile)) {
            this.awsExceptionQueue = "local.queue";
        } else {
            sqs = AmazonSQSClientBuilder.defaultClient();
            this.awsExceptionQueue = System.getenv("EXCEPTION_QUEUE");
        }
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, " Lambda startup::exception queue:: " + awsExceptionQueue);
    }

    /* Send message to AWS SQS service
     *
     * @param errorResponse
     * @return
     */
    @Async
    public void sendMessage(CP_WEB_EXCP_Cargo errorResponse) {
        FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Exception Queue Name received: " + awsExceptionQueue);
        String queueUrl = sqs.getQueueUrl(awsExceptionQueue).getQueueUrl();
        FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Generated Queue Url: " + queueUrl + " for queue: " + awsExceptionQueue);
        SendMessageRequest sendMsgRequest = new SendMessageRequest().withQueueUrl(queueUrl).withMessageBody(getErrorResponseJsonBody(errorResponse));
        sqs.sendMessage(sendMsgRequest);
        FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Exception send to queue for exceptionId: " + errorResponse.getUnique_excp_id());
    }

    /**
     * Mapping from ErrorResponse model to JSON data. This JSON Data will then be
     * saved to SQS Queue
     *
     * @param excepCargo
     * @return
     * @throws JsonProcessingException
     */
    public String getErrorResponseJsonBody(CP_WEB_EXCP_Cargo excepCargo) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(excepCargo);
        } catch (JsonProcessingException e) {
        	FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExceptionLogManager.getErrorResponseJsonBody()", e);
        }
        return null;
    }
}
