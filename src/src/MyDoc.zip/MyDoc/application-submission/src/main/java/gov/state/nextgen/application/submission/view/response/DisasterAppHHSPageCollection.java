package gov.state.nextgen.application.submission.view.response;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.APP_INDV_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.APP_SBMS_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_AUTH_REP_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_PGM_RQST_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_RGST_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_HSHL_DETAILS_DISASTER_Collection;

public class DisasterAppHHSPageCollection {
	
	@JsonDeserialize(contentAs = CP_APP_HSHL_RLT_Collection.class)
	private List<CP_APP_HSHL_RLT_Collection> CP_APP_HSHL_RLT_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_PGM_RQST_Collection.class)
	private List<CP_APP_PGM_RQST_Collection> CP_APP_PGM_RQST_Collection;
	
	@JsonDeserialize(contentAs = CP_HSHL_DETAILS_DISASTER_Collection.class)
	private List<CP_HSHL_DETAILS_DISASTER_Collection> CP_HSHL_DETAILS_DISASTER_Collection;
	
	@JsonDeserialize(contentAs = APP_SBMS_Collection.class)
	private List<APP_SBMS_Collection> APP_SBMS_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_RGST_Collection.class)
	private List<CP_APP_RGST_Collection> CP_APP_RGST_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_AUTH_REP_Collection.class)
	private List<CP_APP_AUTH_REP_Collection> CP_APP_AUTH_REP_Collection;
	
	@JsonDeserialize(contentAs = APP_INDV_Collection.class)
	private List<APP_INDV_Collection> APP_INDV_Collection;

	public List<CP_APP_HSHL_RLT_Collection> getCP_APP_HSHL_RLT_Collection() {
		return CP_APP_HSHL_RLT_Collection;
	}

	public void setCP_APP_HSHL_RLT_Collection(List<CP_APP_HSHL_RLT_Collection> cP_APP_HSHL_RLT_Collection) {
		CP_APP_HSHL_RLT_Collection = cP_APP_HSHL_RLT_Collection;
	}

	public List<CP_APP_PGM_RQST_Collection> getCP_APP_PGM_RQST_Collection() {
		return CP_APP_PGM_RQST_Collection;
	}

	public void setCP_APP_PGM_RQST_Collection(List<CP_APP_PGM_RQST_Collection> cP_APP_PGM_RQST_Collection) {
		CP_APP_PGM_RQST_Collection = cP_APP_PGM_RQST_Collection;
	}

	public List<CP_HSHL_DETAILS_DISASTER_Collection> getCP_HSHL_DETAILS_DISASTER_Collection() {
		return CP_HSHL_DETAILS_DISASTER_Collection;
	}

	public void setCP_HSHL_DETAILS_DISASTER_Collection(
			List<CP_HSHL_DETAILS_DISASTER_Collection> cP_HSHL_DETAILS_DISASTER_Collection) {
		CP_HSHL_DETAILS_DISASTER_Collection = cP_HSHL_DETAILS_DISASTER_Collection;
	}

	public List<APP_SBMS_Collection> getAPP_SBMS_Collection() {
		return APP_SBMS_Collection;
	}

	public void setAPP_SBMS_Collection(List<APP_SBMS_Collection> aPP_SBMS_Collection) {
		APP_SBMS_Collection = aPP_SBMS_Collection;
	}

	public List<CP_APP_RGST_Collection> getCP_APP_RGST_Collection() {
		return CP_APP_RGST_Collection;
	}

	public void setCP_APP_RGST_Collection(List<CP_APP_RGST_Collection> cP_APP_RGST_Collection) {
		CP_APP_RGST_Collection = cP_APP_RGST_Collection;
	}

	public List<CP_APP_AUTH_REP_Collection> getCP_APP_AUTH_REP_Collection() {
		return CP_APP_AUTH_REP_Collection;
	}

	public void setCP_APP_AUTH_REP_Collection(List<CP_APP_AUTH_REP_Collection> cP_APP_AUTH_REP_Collection) {
		CP_APP_AUTH_REP_Collection = cP_APP_AUTH_REP_Collection;
	}

	public List<APP_INDV_Collection> getAPP_INDV_Collection() {
		return APP_INDV_Collection;
	}

	public void setAPP_INDV_Collection(List<APP_INDV_Collection> aPP_INDV_Collection) {
		APP_INDV_Collection = aPP_INDV_Collection;
	}

}
