package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class HouseholdDemographicsProfileDetails {

	public String currentPageID;
	private String nextPageID;
	private String nextPageAction;
	private String previousPageID;
	private Object validationMessages;
	private String appNum;
	private PageCollection pageCollection;

	public String getCurrentPageID() {
		return currentPageID;
	}

	public void setCurrentPageID(String currentPageID) {
		this.currentPageID = currentPageID;
	}

	public String getNextPageID() {
		return nextPageID;
	}

	public void setNextPageID(String nextPageID) {
		this.nextPageID = nextPageID;
	}

	public String getNextPageAction() {
		return nextPageAction;
	}

	public void setNextPageAction(String nextPageAction) {
		this.nextPageAction = nextPageAction;
	}

	public String getPreviousPageID() {
		return previousPageID;
	}

	public void setPreviousPageID(String previousPageID) {
		this.previousPageID = previousPageID;
	}

	public Object getValidationMessages() {
		return validationMessages;
	}

	public void setValidationMessages(Object validationMessages) {
		this.validationMessages = validationMessages;
	}

	public String getAppNum() {
		return appNum;
	}

	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}

	public PageCollection getPageCollection() {
		if(pageCollection == null) {
			pageCollection = new PageCollection();
		}
		return pageCollection;
	}

	public void setPageCollection(PageCollection pageCollection) {
		this.pageCollection = pageCollection;
	}

}