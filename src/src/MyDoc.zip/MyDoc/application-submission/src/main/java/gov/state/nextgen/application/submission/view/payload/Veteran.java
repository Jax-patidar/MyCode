package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class Veteran {
	@JsonIgnore
	private String serviceBranch;
	private Boolean honorableDischargeInd;
	private String begDate;
	private String endDate;
	private String relationCode;
	private String firstName;
	private String lastName;
	private String middleName;
	private String suffix;
	private Boolean activeInd;
	private String serialNumber;
	private String claimNumber;
	private String vaContractBeginDate;
	private String referalRercvDate;
	private Boolean benefitRcvdInd;
	private Boolean campusBenefitInd;
	private String veteranStatus;

	public String getServiceBranch() {
		return serviceBranch;
	}

	public void setServiceBranch(String serviceBranch) {
		this.serviceBranch = serviceBranch;
	}

	public Boolean isHonorableDischargeInd() {
		return honorableDischargeInd;
	}

	public void setHonorableDischargeInd(Boolean honorableDischargeInd) {
		this.honorableDischargeInd = honorableDischargeInd;
	}

	public String getBegDate() {
		return begDate;
	}

	public void setBegDate(String begDate) {
		this.begDate = begDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getRelationCode() {
		return relationCode;
	}

	public void setRelationCode(String relationCode) {
		this.relationCode = relationCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public Boolean isActiveInd() {
		return activeInd;
	}

	public void setActiveInd(Boolean activeInd) {
		this.activeInd = activeInd;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getVaContractBeginDate() {
		return vaContractBeginDate;
	}

	public void setVaContractBeginDate(String vaContractBeginDate) {
		this.vaContractBeginDate = vaContractBeginDate;
	}

	public String getReferalRercvDate() {
		return referalRercvDate;
	}

	public void setReferalRercvDate(String referalRercvDate) {
		this.referalRercvDate = referalRercvDate;
	}

	public Boolean isBenefitRcvdInd() {
		return benefitRcvdInd;
	}

	public void setBenefitRcvdInd(Boolean benefitRcvdInd) {
		this.benefitRcvdInd = benefitRcvdInd;
	}

	public Boolean isCampusBenefitInd() {
		return campusBenefitInd;
	}

	public void setCampusBenefitInd(Boolean campusBenefitInd) {
		this.campusBenefitInd = campusBenefitInd;
	}

	public String getVeteranStatus() {
		return veteranStatus;
	}

	public void setVeteranStatus(String veteranStatus) {
		this.veteranStatus = veteranStatus;
	}
}
