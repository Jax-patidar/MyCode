package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income;

public class APP_IN_EMPL_Collection {
	private String user;
    private String cargoName;
    private boolean dirty;
    private String rowAction;
    private String adaptRecordId;
    private String app_num;
    private int indv_seq_num;
    private int empl_seq_num;
    private String src_app_ind;
    private String change_eff_dt;
    private String empl_begin_dt;
    private String empl_end_dt;
    private String er_city_address;
    private String er_l1_address;
    private String er_l2_address;
    private String er_name;
    private String er_phone_num;
    private String er_st_address;
    private String er_zip_address;
    private String first_payck_dt;
    private String last_payck_dt;
    private String pay_freq_cd;
    private String rec_cplt_ind;
    private String strike_begin_dt;
    private String strike_end_dt;
    private String ref_job_sw;
    private String job_termination_reason;
    private String on_strike_sw;
    private String expected_to_cont_resp;
    private String er_Typ;
    private String pay_day_week_cd;
    private String next_paycheck_dt;
    private String hourly_pay_amt;
    private String num_of_hours;
    private String gross_pay_amt;
    private String last_paycheck_amt;
    private String empl_loss_gdcs_cd;
    private String empl_addtl_info;
    private String looping_ind;
    private String ik_empl_name;
    private String ik_job_start_dt;
    private String ik_job_end_dt;
    private double ik_amt_each_month;
    private String ik_loopingInd;
    private String fst_nam;
    private String address_zip4;
    private String change_dt;
    private String ik_income_type;
    private String ik_recv_type;
    private String er_prvd_med_ins_ind;
    private String mthly_est_val_gs_rcvd;
    private String ik_amt;
    private String ik_freq;
    private String upcmng_job_chng_ind;
    private String employment_county_job;
    private String empl_type;
    private String last_60_days_ind;
    private String next_year_income_change_ind;
    private String county_help_job_ind;
    private String delete_reason_cd;
    private String yearly_income_current_year;
    private String yearly_income_next_year;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public boolean isDirty() {
		return dirty;
	}
	public void setDirty(boolean dirty) {
		this.dirty = dirty;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public int getEmpl_seq_num() {
		return empl_seq_num;
	}
	public void setEmpl_seq_num(int empl_seq_num) {
		this.empl_seq_num = empl_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getChange_eff_dt() {
		return change_eff_dt;
	}
	public void setChange_eff_dt(String change_eff_dt) {
		this.change_eff_dt = change_eff_dt;
	}
	public String getEmpl_begin_dt() {
		return empl_begin_dt;
	}
	public void setEmpl_begin_dt(String empl_begin_dt) {
		this.empl_begin_dt = empl_begin_dt;
	}
	public String getEmpl_end_dt() {
		return empl_end_dt;
	}
	public void setEmpl_end_dt(String empl_end_dt) {
		this.empl_end_dt = empl_end_dt;
	}
	public String getEr_city_address() {
		return er_city_address;
	}
	public void setEr_city_address(String er_city_address) {
		this.er_city_address = er_city_address;
	}
	public String getEr_l1_address() {
		return er_l1_address;
	}
	public void setEr_l1_address(String er_l1_address) {
		this.er_l1_address = er_l1_address;
	}
	public String getEr_l2_address() {
		return er_l2_address;
	}
	public void setEr_l2_address(String er_l2_address) {
		this.er_l2_address = er_l2_address;
	}
	public String getEr_name() {
		return er_name;
	}
	public void setEr_name(String er_name) {
		this.er_name = er_name;
	}
	public String getEr_phone_num() {
		return er_phone_num;
	}
	public void setEr_phone_num(String er_phone_num) {
		this.er_phone_num = er_phone_num;
	}
	public String getEr_st_address() {
		return er_st_address;
	}
	public void setEr_st_address(String er_st_address) {
		this.er_st_address = er_st_address;
	}
	public String getEr_zip_address() {
		return er_zip_address;
	}
	public void setEr_zip_address(String er_zip_address) {
		this.er_zip_address = er_zip_address;
	}
	public String getFirst_payck_dt() {
		return first_payck_dt;
	}
	public void setFirst_payck_dt(String first_payck_dt) {
		this.first_payck_dt = first_payck_dt;
	}
	public String getLast_payck_dt() {
		return last_payck_dt;
	}
	public void setLast_payck_dt(String last_payck_dt) {
		this.last_payck_dt = last_payck_dt;
	}
	public String getPay_freq_cd() {
		return pay_freq_cd;
	}
	public void setPay_freq_cd(String pay_freq_cd) {
		this.pay_freq_cd = pay_freq_cd;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getStrike_begin_dt() {
		return strike_begin_dt;
	}
	public void setStrike_begin_dt(String strike_begin_dt) {
		this.strike_begin_dt = strike_begin_dt;
	}
	public String getStrike_end_dt() {
		return strike_end_dt;
	}
	public void setStrike_end_dt(String strike_end_dt) {
		this.strike_end_dt = strike_end_dt;
	}
	public String getRef_job_sw() {
		return ref_job_sw;
	}
	public void setRef_job_sw(String ref_job_sw) {
		this.ref_job_sw = ref_job_sw;
	}
	public String getJob_termination_reason() {
		return job_termination_reason;
	}
	public void setJob_termination_reason(String job_termination_reason) {
		this.job_termination_reason = job_termination_reason;
	}
	public String getOn_strike_sw() {
		return on_strike_sw;
	}
	public void setOn_strike_sw(String on_strike_sw) {
		this.on_strike_sw = on_strike_sw;
	}
	public String getExpected_to_cont_resp() {
		return expected_to_cont_resp;
	}
	public void setExpected_to_cont_resp(String expected_to_cont_resp) {
		this.expected_to_cont_resp = expected_to_cont_resp;
	}
	public String getEr_Typ() {
		return er_Typ;
	}
	public void setEr_Typ(String er_Typ) {
		this.er_Typ = er_Typ;
	}
	public String getPay_day_week_cd() {
		return pay_day_week_cd;
	}
	public void setPay_day_week_cd(String pay_day_week_cd) {
		this.pay_day_week_cd = pay_day_week_cd;
	}
	public String getNext_paycheck_dt() {
		return next_paycheck_dt;
	}
	public void setNext_paycheck_dt(String next_paycheck_dt) {
		this.next_paycheck_dt = next_paycheck_dt;
	}
	public String getHourly_pay_amt() {
		return hourly_pay_amt;
	}
	public void setHourly_pay_amt(String hourly_pay_amt) {
		this.hourly_pay_amt = hourly_pay_amt;
	}
	public String getNum_of_hours() {
		return num_of_hours;
	}
	public void setNum_of_hours(String num_of_hours) {
		this.num_of_hours = num_of_hours;
	}
	public String getGross_pay_amt() {
		return gross_pay_amt;
	}
	public void setGross_pay_amt(String gross_pay_amt) {
		this.gross_pay_amt = gross_pay_amt;
	}
	public String getLast_paycheck_amt() {
		return last_paycheck_amt;
	}
	public void setLast_paycheck_amt(String last_paycheck_amt) {
		this.last_paycheck_amt = last_paycheck_amt;
	}
	public String getEmpl_loss_gdcs_cd() {
		return empl_loss_gdcs_cd;
	}
	public void setEmpl_loss_gdcs_cd(String empl_loss_gdcs_cd) {
		this.empl_loss_gdcs_cd = empl_loss_gdcs_cd;
	}
	public String getEmpl_addtl_info() {
		return empl_addtl_info;
	}
	public void setEmpl_addtl_info(String empl_addtl_info) {
		this.empl_addtl_info = empl_addtl_info;
	}
	public String getLooping_ind() {
		return looping_ind;
	}
	public void setLooping_ind(String looping_ind) {
		this.looping_ind = looping_ind;
	}
	public String getIk_empl_name() {
		return ik_empl_name;
	}
	public void setIk_empl_name(String ik_empl_name) {
		this.ik_empl_name = ik_empl_name;
	}
	public String getIk_job_start_dt() {
		return ik_job_start_dt;
	}
	public void setIk_job_start_dt(String ik_job_start_dt) {
		this.ik_job_start_dt = ik_job_start_dt;
	}
	public String getIk_job_end_dt() {
		return ik_job_end_dt;
	}
	public void setIk_job_end_dt(String ik_job_end_dt) {
		this.ik_job_end_dt = ik_job_end_dt;
	}
	public double getIk_amt_each_month() {
		return ik_amt_each_month;
	}
	public void setIk_amt_each_month(double ik_amt_each_month) {
		this.ik_amt_each_month = ik_amt_each_month;
	}
	public String getIk_loopingInd() {
		return ik_loopingInd;
	}
	public void setIk_loopingInd(String ik_loopingInd) {
		this.ik_loopingInd = ik_loopingInd;
	}
	public String getFst_nam() {
		return fst_nam;
	}
	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}
	public String getAddress_zip4() {
		return address_zip4;
	}
	public void setAddress_zip4(String address_zip4) {
		this.address_zip4 = address_zip4;
	}
	public String getChange_dt() {
		return change_dt;
	}
	public void setChange_dt(String change_dt) {
		this.change_dt = change_dt;
	}
	public String getIk_income_type() {
		return ik_income_type;
	}
	public void setIk_income_type(String ik_income_type) {
		this.ik_income_type = ik_income_type;
	}
	public String getIk_recv_type() {
		return ik_recv_type;
	}
	public void setIk_recv_type(String ik_recv_type) {
		this.ik_recv_type = ik_recv_type;
	}
	public String getEr_prvd_med_ins_ind() {
		return er_prvd_med_ins_ind;
	}
	public void setEr_prvd_med_ins_ind(String er_prvd_med_ins_ind) {
		this.er_prvd_med_ins_ind = er_prvd_med_ins_ind;
	}
	public String getMthly_est_val_gs_rcvd() {
		return mthly_est_val_gs_rcvd;
	}
	public void setMthly_est_val_gs_rcvd(String mthly_est_val_gs_rcvd) {
		this.mthly_est_val_gs_rcvd = mthly_est_val_gs_rcvd;
	}
	public String getIk_amt() {
		return ik_amt;
	}
	public void setIk_amt(String ik_amt) {
		this.ik_amt = ik_amt;
	}
	public String getIk_freq() {
		return ik_freq;
	}
	public void setIk_freq(String ik_freq) {
		this.ik_freq = ik_freq;
	}
	public String getUpcmng_job_chng_ind() {
		return upcmng_job_chng_ind;
	}
	public void setUpcmng_job_chng_ind(String upcmng_job_chng_ind) {
		this.upcmng_job_chng_ind = upcmng_job_chng_ind;
	}
	public String getEmployment_county_job() {
		return employment_county_job;
	}
	public void setEmployment_county_job(String employment_county_job) {
		this.employment_county_job = employment_county_job;
	}
	public String getEmpl_type() {
		return empl_type;
	}
	public void setEmpl_type(String empl_type) {
		this.empl_type = empl_type;
	}
	public String getLast_60_days_ind() {
		return last_60_days_ind;
	}
	public void setLast_60_days_ind(String last_60_days_ind) {
		this.last_60_days_ind = last_60_days_ind;
	}
	public String getNext_year_income_change_ind() {
		return next_year_income_change_ind;
	}
	public void setNext_year_income_change_ind(String next_year_income_change_ind) {
		this.next_year_income_change_ind = next_year_income_change_ind;
	}
	public String getCounty_help_job_ind() {
		return county_help_job_ind;
	}
	public void setCounty_help_job_ind(String county_help_job_ind) {
		this.county_help_job_ind = county_help_job_ind;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getYearly_income_current_year() {
		return yearly_income_current_year;
	}
	public void setYearly_income_current_year(String yearly_income_current_year) {
		this.yearly_income_current_year = yearly_income_current_year;
	}
	public String getYearly_income_next_year() {
		return yearly_income_next_year;
	}
	public void setYearly_income_next_year(String yearly_income_next_year) {
		this.yearly_income_next_year = yearly_income_next_year;
	}
}
