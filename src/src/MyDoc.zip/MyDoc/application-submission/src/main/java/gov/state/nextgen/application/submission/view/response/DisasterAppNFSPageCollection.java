package gov.state.nextgen.application.submission.view.response;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.CP_OTHER_DETAILS_DISASTER_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.CP_REPLACEMENT_DISASTER_Collection;

public class DisasterAppNFSPageCollection {
	
	@JsonDeserialize(contentAs = CP_OTHER_DETAILS_DISASTER_Collection.class)
	private List<CP_OTHER_DETAILS_DISASTER_Collection> CP_OTHER_DETAILS_DISASTER_Collection;
	
	@JsonDeserialize(contentAs = CP_REPLACEMENT_DISASTER_Collection.class)
	private List<CP_REPLACEMENT_DISASTER_Collection> CP_REPLACEMENT_DISASTER_Collection;

	public List<CP_OTHER_DETAILS_DISASTER_Collection> getCP_OTHER_DETAILS_DISASTER_Collection() {
		return CP_OTHER_DETAILS_DISASTER_Collection;
	}

	public void setCP_OTHER_DETAILS_DISASTER_Collection(
			List<CP_OTHER_DETAILS_DISASTER_Collection> cP_OTHER_DETAILS_DISASTER_Collection) {
		CP_OTHER_DETAILS_DISASTER_Collection = cP_OTHER_DETAILS_DISASTER_Collection;
	}

	public List<CP_REPLACEMENT_DISASTER_Collection> getCP_REPLACEMENT_DISASTER_Collection() {
		return CP_REPLACEMENT_DISASTER_Collection;
	}

	public void setCP_REPLACEMENT_DISASTER_Collection(
			List<CP_REPLACEMENT_DISASTER_Collection> cP_REPLACEMENT_DISASTER_Collection) {
		CP_REPLACEMENT_DISASTER_Collection = cP_REPLACEMENT_DISASTER_Collection;
	}

}
