package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.APP_IN_P_PROP_ASET_Collection;
import gov.state.nextgen.application.submission.view.payload.PersonalProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BuildPersonalPropDetailsHelper {
	
	private BuildPersonalPropDetailsHelper() {}
	
	public static List<PersonalProperty> buildPersonalProperties(AggregatedPayload source, int indvSeq) {//NOSONAR

		PersonalProperty personProp = null;
		List<PersonalProperty> persAsetList = new ArrayList<>();
				
		try {
			List<APP_IN_P_PROP_ASET_Collection> personalAsetList = source.getFinancialAssetSummaryDetails().getPageCollection().getAPP_IN_P_PROP_ASET_Collection();

			if(personalAsetList != null && !personalAsetList.isEmpty()) {
				List<APP_IN_P_PROP_ASET_Collection> indvLiqAsetList = personalAsetList.stream().filter(liqAset->indvSeq == liqAset.getIndv_seq_num()).collect(Collectors.toList());

				if(indvLiqAsetList != null && !indvLiqAsetList.isEmpty()) {
					for(APP_IN_P_PROP_ASET_Collection persProp : indvLiqAsetList) {						
						String perPropStr = persProp.getPrsn_prop_aset_typ();
						if(perPropStr != null) {
							personProp = new PersonalProperty();
							personProp.setAcquired(persProp.getAcquired_dt());
							personProp.setAvailableInd(false);
							personProp.setBegDate(persProp.getChg_dt());							
							if(ApplicationSubmissionConstants.STR_TN.equalsIgnoreCase(perPropStr) ||
									ApplicationSubmissionConstants.EXP_CS.equalsIgnoreCase(perPropStr)) {
								personProp.setCategoryCode(ApplicationSubmissionConstants.STR_MV);
							} else {
								personProp.setCategoryCode(ApplicationSubmissionConstants.STR_PP);		
							}
							personProp.setOwedAmount(persProp.getProperty_owe_amt());						
							personProp.setType(BuildIncomeTypeMappingHelper.getPersonalProCd(perPropStr));
							personProp.setValAmount(persProp.getPrsn_prop_amt());
							persAsetList.add(personProp);
						}
					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildPersonalPropDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while buildPersonalProperties::" + e.getMessage());
		}
		return persAsetList;
	}
}
