package gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial;

public class CP_OTHER_DETAILS_DISASTER_Collection {
	
	private String app_num;
	private String indv_seq_num;
	private String seq_num;
	private String src_app_ind;
	private String cf_ind;
	private String received_amt;
	private String state_cd;
	private String county_num;
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(String indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(String seq_num) {
		this.seq_num = seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getCf_ind() {
		return cf_ind;
	}
	public void setCf_ind(String cf_ind) {
		this.cf_ind = cf_ind;
	}
	public String getReceived_amt() {
		return received_amt;
	}
	public void setReceived_amt(String received_amt) {
		this.received_amt = received_amt;
	}
	public String getState_cd() {
		return state_cd;
	}
	public void setState_cd(String state_cd) {
		this.state_cd = state_cd;
	}
	public String getCounty_num() {
		return county_num;
	}
	public void setCounty_num(String county_num) {
		this.county_num = county_num;
	}
	
	

}
