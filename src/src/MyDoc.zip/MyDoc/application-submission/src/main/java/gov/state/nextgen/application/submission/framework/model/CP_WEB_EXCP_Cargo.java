package gov.state.nextgen.application.submission.framework.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * This java bean contains the entities for the given table
 *
 * @author Architecture Team Creation Date Thu Mar 17 14:42:40 CST 2005 Modified
 *         By: Modified on: PCR#
 */


public class CP_WEB_EXCP_Cargo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4433806036174601564L;

	private int excp_id;
	
	private String cls_id;
	private String cur_page_id;
	private Timestamp excp_tms;
	
	private String unique_excp_id;
	
	private String mthd_id;
		
	private String srvc_nam;
	
	private String user_id;
	private String excp_txt;

	private String stak_trc_txt;
	private String parm_txt;
	
	private Integer app_num;
	
	public String getCls_id() {
		return cls_id;
	}

	public void setCls_id(String cls_id) {
		this.cls_id = cls_id;
	}

	public String getCur_page_id() {
		return cur_page_id;
	}

	public void setCur_page_id(String cur_page_id) {
		this.cur_page_id = cur_page_id;
	}

	public Timestamp getExcp_tms() {
        return this.excp_tms!= null ? new Timestamp(excp_tms.getTime()) : null;
	}

	public void setExcp_tms(Timestamp excp_tms) {
    	this.excp_tms = (excp_tms == null) ? null : new Timestamp(excp_tms.getTime());    
	}


	public String getMthd_id() {
		return mthd_id;
	}

	public void setMthd_id(String mthd_id) {
		this.mthd_id = mthd_id;
	}


	public String getSrvc_nam() {
		return srvc_nam;
	}

	public void setSrvc_nam(String srvc_nam) {
		this.srvc_nam = srvc_nam;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}


	public String getExcp_txt() {
		return excp_txt;
	}

	public void setExcp_txt(String excp_txt) {
		this.excp_txt = excp_txt;
	}


	public String getStak_trc_txt() {
		return stak_trc_txt;
	}

	public void setStak_trc_txt(String stak_trc_txt) {
		this.stak_trc_txt = stak_trc_txt;
	}


	public String getParm_txt() {
		return parm_txt;
	}

	public void setParm_txt(String parm_txt) {
		this.parm_txt = parm_txt;
	}


	public int getExcp_id() {
		return excp_id;
	}

	public void setExcp_id(int excp_id) {
		this.excp_id = excp_id;
	}

	public String getUnique_excp_id() {
		return unique_excp_id;
	}

	public void setUnique_excp_id(String unique_excp_id) {
		this.unique_excp_id = unique_excp_id;
	}
	
	public Integer getApp_num() {
		return app_num;
	}

	public void setApp_num(Integer app_num) {
		this.app_num = app_num;
	}

	public CP_WEB_EXCP_Cargo() {
	}

	@SuppressWarnings({"squid:S107","squid:S117"})
	public CP_WEB_EXCP_Cargo(int excp_id, String cls_id, String cur_page_id,
                             Timestamp excp_tms, String mthd_id,
                             String srvc_nam, String user_id,
                             String excp_txt, String stak_trc_txt,
                             String parm_txt, String unique_excp_id, Integer app_num) {
		super();
		this.excp_id = excp_id;
		this.cls_id = cls_id;
		this.cur_page_id = cur_page_id;
    	this.excp_tms = (excp_tms == null) ? null : new Timestamp(excp_tms.getTime());    
		this.mthd_id = mthd_id;
		this.srvc_nam = srvc_nam;
		this.user_id = user_id;
		this.excp_txt = excp_txt;
		this.stak_trc_txt = stak_trc_txt;
		this.parm_txt = parm_txt;
		this.unique_excp_id = unique_excp_id;
		this.app_num = app_num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((cls_id == null) ? 0 : cls_id.hashCode());
		result = prime * result + ((cur_page_id == null) ? 0 : cur_page_id.hashCode());
		result = prime * result + excp_id;
		result = prime * result + ((excp_tms == null) ? 0 : excp_tms.hashCode());
		result = prime * result + ((excp_txt == null) ? 0 : excp_txt.hashCode());
		result = prime * result + ((mthd_id == null) ? 0 : mthd_id.hashCode());
		result = prime * result + ((parm_txt == null) ? 0 : parm_txt.hashCode());
		result = prime * result + ((srvc_nam == null) ? 0 : srvc_nam.hashCode());
		result = prime * result + ((stak_trc_txt == null) ? 0 : stak_trc_txt.hashCode());
		result = prime * result + ((unique_excp_id == null) ? 0 : unique_excp_id.hashCode());
		result = prime * result + ((user_id == null) ? 0 : user_id.hashCode());
		return result;
	}
	@SuppressWarnings("squid:S3776")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CP_WEB_EXCP_Cargo other = (CP_WEB_EXCP_Cargo) obj;
		if (app_num == null) {
			if (other.app_num != null)
				return false;
		} else if (!app_num.equals(other.app_num))
			return false;
		if (cls_id == null) {
			if (other.cls_id != null)
				return false;
		} else if (!cls_id.equals(other.cls_id))
			return false;
		if (cur_page_id == null) {
			if (other.cur_page_id != null)
				return false;
		} else if (!cur_page_id.equals(other.cur_page_id))
			return false;
		if (excp_id != other.excp_id)
			return false;
		if (excp_tms == null) {
			if (other.excp_tms != null)
				return false;
		} else if (!excp_tms.equals(other.excp_tms))
			return false;
		if (excp_txt == null) {
			if (other.excp_txt != null)
				return false;
		} else if (!excp_txt.equals(other.excp_txt))
			return false;
		if (mthd_id == null) {
			if (other.mthd_id != null)
				return false;
		} else if (!mthd_id.equals(other.mthd_id))
			return false;
		if (parm_txt == null) {
			if (other.parm_txt != null)
				return false;
		} else if (!parm_txt.equals(other.parm_txt))
			return false;
		if (srvc_nam == null) {
			if (other.srvc_nam != null)
				return false;
		} else if (!srvc_nam.equals(other.srvc_nam))
			return false;
		if (stak_trc_txt == null) {
			if (other.stak_trc_txt != null)
				return false;
		} else if (!stak_trc_txt.equals(other.stak_trc_txt))
			return false;
		if (unique_excp_id == null) {
			if (other.unique_excp_id != null)
				return false;
		} else if (!unique_excp_id.equals(other.unique_excp_id))
			return false;
		if (user_id == null) {
			if (other.user_id != null)
				return false;
		} else if (!user_id.equals(other.user_id))
			return false;
		return true;
	}


	


}
