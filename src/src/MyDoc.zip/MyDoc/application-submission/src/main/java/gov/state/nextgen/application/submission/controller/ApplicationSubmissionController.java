package gov.state.nextgen.application.submission.controller;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.state.nextgen.application.submission.framework.ExceptionsUtil;
import gov.state.nextgen.application.submission.framework.exception.ExceptionLogManager;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.model.*;
import gov.state.nextgen.application.submission.service.ApplicationSubmissionService;
import gov.state.nextgen.application.submission.service.DisasterAppTransferService;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.payload.ApplicationSubmissionPayload;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

import static gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants.ERROR;
import static gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants.LAMBDA_NAME;
import static gov.state.nextgen.application.submission.framework.constants.ExceptionConstants.KEY_IDENTIFIER_ONE;
import static gov.state.nextgen.application.submission.framework.constants.ExceptionConstants.KEY_IDENTIFIER_TWO;
import static gov.state.nextgen.application.submission.util.ApplicationUtil.buildErrorMessageModelFn;
import static gov.state.nextgen.application.submission.util.ApplicationUtil.buildNVPModelFn;

@RestController
public class ApplicationSubmissionController {

    private static final String PAYLOAD_GENERATED_SUCCESSFULLY = "Aggregated Payload generated successfully. Now Transformation begins...";

    private static final String TRANSFORMATION_COMPLETED_SUCCESSFULLY = "Transformation completed successfully...";

    @Autowired
    ApplicationSubmissionService applicationSubmissionService;

    @Autowired
    DisasterAppTransferService disasterAppTransferService;

    @Autowired
    private ExceptionLogManager exceptionLogManager;

    @PostMapping(path = "/event", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> appTransfer(@RequestParam("type") String type, @RequestBody String message) {// NOSONAR
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Received body::" + message);

        ApplicationResponse<List<FormResponseModel>> applicationResponse = new ApplicationResponse<>();
        try {
            ObjectMapper objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            FormRequestModel formRequestModel = objectMapper.readValue(message, FormRequestModel.class);
            if (formRequestModel == null || formRequestModel.getAppNum() == null) {
                return new ResponseEntity<>(new Object(), HttpStatus.NO_CONTENT);
            }

            FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FormType::" + formRequestModel.getFormType());
            FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ApplicationNumber::" + formRequestModel.getAppNum());

            MDC.put(KEY_IDENTIFIER_ONE, formRequestModel.getAppNum());
            MDC.put(KEY_IDENTIFIER_TWO, formRequestModel.getFormType());

            AggregatedPayload aggregatedPayload = null;
            ApplicationSubmissionPayload applicationSubmissionPayload = null;

            if (formRequestModel.getFormType().equals("DISASTERAPPTRANSFER")) {
                aggregatedPayload = disasterAppTransferService.fetchDisasterCalFresh(formRequestModel.getAppNum());
                applicationSubmissionPayload = disasterAppTransferService.fetchApplicationSubmissionPayload(aggregatedPayload);
            } else {
                aggregatedPayload = applicationSubmissionService.buildPayload(formRequestModel.getAppNum());
                applicationSubmissionPayload = applicationSubmissionService.fromAggregatedPayload(aggregatedPayload);
            }

            if (aggregatedPayload.isErrorWhileAccessingInternalServices()) {
                String msg = "One or more internal services are unreachable while aggregating data for the given application number::" + formRequestModel.getFormType() + "::" + formRequestModel.getAppNum();
                FwLogger.log(this.getClass(), FwLogger.Level.INFO, msg);
                updateResponse(applicationResponse, "One or more internal APIs are unreachable while aggregating data for the given application number");
                Throwable t = new Throwable(msg);
                exceptionLogManager.sendMessage(ExceptionsUtil.getExceptionCargo(this.getClass(), t, "formCF37Transfer", null));
                return new ResponseEntity<>(applicationResponse, HttpStatus.SERVICE_UNAVAILABLE);
            }

            FwLogger.log(this.getClass(), FwLogger.Level.INFO, PAYLOAD_GENERATED_SUCCESSFULLY);
            FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Checking if we have enough data to fulfill the contract...");

            if (!applicationSubmissionPayload.isContractFulfilled()) {
                FwLogger.log(this.getClass(), FwLogger.Level.INFO, "There are some issues with data quality for the given application number::" + formRequestModel.getAppNum());
                updateResponse(applicationResponse, "There are some issues with data quality for the given application number ");
                return new ResponseEntity<>(applicationResponse, HttpStatus.INTERNAL_SERVER_ERROR);
            }

            FwLogger.log(this.getClass(), FwLogger.Level.INFO, TRANSFORMATION_COMPLETED_SUCCESSFULLY);
            FormResponseModel appSubmissionFormResponseModel = new FormResponseModel();
            appSubmissionFormResponseModel.setFormType(formRequestModel.getFormType());
            appSubmissionFormResponseModel.setPayload(objectMapper.writeValueAsString(applicationSubmissionPayload));
            appSubmissionFormResponseModel.setAppNum(formRequestModel.getAppNum());
            List<NameValuePairModel> nameValuePairModels = new ArrayList<>();
            nameValuePairModels.add(buildNVPModelFn().apply("countyCode", applicationSubmissionPayload.getCountyCode()));
            appSubmissionFormResponseModel.setQueryParams(nameValuePairModels);
            List<FormResponseModel> formResponseModels = new ArrayList<>();
            formResponseModels.add(appSubmissionFormResponseModel);
            applicationResponse.setData(formResponseModels);
            applicationResponse.setStatus("Success");
            FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ApplicationResponse::" + applicationResponse);
            return new ResponseEntity<>(applicationResponse, HttpStatus.OK);
        } catch (Exception e) {
            updateResponse(applicationResponse, e.getMessage());
            return new ResponseEntity<>(applicationResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private void updateResponse(ApplicationResponse<List<FormResponseModel>> applicationResponse, String message) {
        applicationResponse.setStatus(ERROR);
        List<ErrorMessageModel> errorMessageModels = new ArrayList<>();
        errorMessageModels.add(buildErrorMessageModelFn().apply(LAMBDA_NAME, message));
        applicationResponse.setErrors(errorMessageModels);
    }

    @GetMapping("/app-submission/{appNumber}/json")
    public ResponseEntity<Object> appTransferJson(@PathVariable String appNumber) throws Exception {
        ApplicationResponse<List<FormResponseModel>> applicationResponse = new ApplicationResponse<>();
        appNumber = appNumber.replaceAll("[\n|\r|\t]", "_"); // for sonar's sake
        MDC.put(KEY_IDENTIFIER_ONE,  appNumber);
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "initiating processing data for case::" + appNumber);

        AggregatedPayload aggregatedPayload = applicationSubmissionService.buildPayload(appNumber);
        if (aggregatedPayload.isErrorWhileAccessingInternalServices()) {
            FwLogger.log(this.getClass(), FwLogger.Level.INFO, "One or more internal services are unreachable while aggregating data for the given application number::" + appNumber);
            updateResponse(applicationResponse, "One or more internal APIs are unreachable while aggregating data for the given application number");
            return new ResponseEntity<>(applicationResponse, HttpStatus.SERVICE_UNAVAILABLE);
        }

        FwLogger.log(this.getClass(), FwLogger.Level.INFO, PAYLOAD_GENERATED_SUCCESSFULLY);
        ApplicationSubmissionPayload applicationSubmissionPayload = applicationSubmissionService.fromAggregatedPayload(aggregatedPayload);
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Checking if we have enough data to fulfill the contract...");

        if (!applicationSubmissionPayload.isContractFulfilled()) {
            FwLogger.log(this.getClass(), FwLogger.Level.INFO, "There are some issues with data quality for the given application number.." + appNumber);
            updateResponse(applicationResponse, "There are some issues with data quality for the given application number ");
            return new ResponseEntity<>(applicationResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, TRANSFORMATION_COMPLETED_SUCCESSFULLY);
        return new ResponseEntity<>(applicationSubmissionPayload, HttpStatus.OK);
    }

    @GetMapping("/app-submission/dcal-submission/{appNumber}/json")
    public ResponseEntity<Object> dcalTransferJson(@PathVariable String appNumber) throws Exception {
        ApplicationResponse<List<FormResponseModel>> applicationResponse = new ApplicationResponse<>();
        appNumber = appNumber.replaceAll("[\n|\r|\t]", "_"); // for sonar's sake

        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "initiating processing dcal data for case .." + appNumber);

        AggregatedPayload aggregatedPayload = disasterAppTransferService.fetchDisasterCalFresh(appNumber);
        if (aggregatedPayload.isErrorWhileAccessingInternalServices()) {
            FwLogger.log(this.getClass(), FwLogger.Level.INFO, "One or more internal dcal services are unreachable while aggregating data for the given application number.." + appNumber);
            updateResponse(applicationResponse, "One or more dcal internal APIs are unreachable while aggregating data for the given application number");
            return new ResponseEntity<>(applicationResponse, HttpStatus.SERVICE_UNAVAILABLE);
        }

        FwLogger.log(this.getClass(), FwLogger.Level.INFO, PAYLOAD_GENERATED_SUCCESSFULLY);
        ApplicationSubmissionPayload applicationSubmissionPayload = disasterAppTransferService.fetchApplicationSubmissionPayload(aggregatedPayload);

        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Checking if we have enough dcal data to fulfill the contract.");

        if (!applicationSubmissionPayload.isContractFulfilled()) {
            FwLogger.log(this.getClass(), FwLogger.Level.INFO, "There are some issues with dcal data quality for the given application number::" + appNumber);
            updateResponse(applicationResponse, "There are some issues with dcal data quality for the given application number ");
            return new ResponseEntity<>(applicationResponse, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, TRANSFORMATION_COMPLETED_SUCCESSFULLY);
        return new ResponseEntity<>(applicationSubmissionPayload, HttpStatus.OK);
    }

}
