package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense;

public class CP_APP_IN_MED_BILLS {
	
	
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int indv_seq_num;
	private String medical_seq_num;
	private String med_bill_type;
	private String src_app_ind;
	private String payment_amt;
	private String pay_freq;
	private String rec_cplt_ind;
	private String medical_bill_end_dt;
	private String adapt_record_id;
	private String change_dt;
	private String special_needs_desc;
	private String reimburse_name;
	private String reimburse_ind;
	private String reimburse_amt;
	private String pymnt_amnt;
	private String firstName;
	private String lastName;
	private String age;
	private String medBillTypes;
	private String ma_backdt_mo_1_ind;
	private String ma_backdt_mo_2_ind;
	private String ma_backdt_mo_3_ind;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getMedical_seq_num() {
		return medical_seq_num;
	}
	public void setMedical_seq_num(String medical_seq_num) {
		this.medical_seq_num = medical_seq_num;
	}
	public String getMed_bill_type() {
		return med_bill_type;
	}
	public void setMed_bill_type(String med_bill_type) {
		this.med_bill_type = med_bill_type;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getPayment_amt() {
		return payment_amt;
	}
	public void setPayment_amt(String payment_amt) {
		this.payment_amt = payment_amt;
	}
	public String getPay_freq() {
		return pay_freq;
	}
	public void setPay_freq(String pay_freq) {
		this.pay_freq = pay_freq;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getMedical_bill_end_dt() {
		return medical_bill_end_dt;
	}
	public void setMedical_bill_end_dt(String medical_bill_end_dt) {
		this.medical_bill_end_dt = medical_bill_end_dt;
	}
	public String getAdapt_record_id() {
		return adapt_record_id;
	}
	public void setAdapt_record_id(String adapt_record_id) {
		this.adapt_record_id = adapt_record_id;
	}
	public String getChange_dt() {
		return change_dt;
	}
	public void setChange_dt(String change_dt) {
		this.change_dt = change_dt;
	}
	public String getSpecial_needs_desc() {
		return special_needs_desc;
	}
	public void setSpecial_needs_desc(String special_needs_desc) {
		this.special_needs_desc = special_needs_desc;
	}
	public String getReimburse_name() {
		return reimburse_name;
	}
	public void setReimburse_name(String reimburse_name) {
		this.reimburse_name = reimburse_name;
	}
	public String getReimburse_ind() {
		return reimburse_ind;
	}
	public void setReimburse_ind(String reimburse_ind) {
		this.reimburse_ind = reimburse_ind;
	}
	public String getReimburse_amt() {
		return reimburse_amt;
	}
	public void setReimburse_amt(String reimburse_amt) {
		this.reimburse_amt = reimburse_amt;
	}
	public String getPymnt_amnt() {
		return pymnt_amnt;
	}
	public void setPymnt_amnt(String pymnt_amnt) {
		this.pymnt_amnt = pymnt_amnt;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getMedBillTypes() {
		return medBillTypes;
	}
	public void setMedBillTypes(String medBillTypes) {
		this.medBillTypes = medBillTypes;
	}
	public String getMa_backdt_mo_1_ind() {
		return ma_backdt_mo_1_ind;
	}
	public void setMa_backdt_mo_1_ind(String ma_backdt_mo_1_ind) {
		this.ma_backdt_mo_1_ind = ma_backdt_mo_1_ind;
	}
	public String getMa_backdt_mo_2_ind() {
		return ma_backdt_mo_2_ind;
	}
	public void setMa_backdt_mo_2_ind(String ma_backdt_mo_2_ind) {
		this.ma_backdt_mo_2_ind = ma_backdt_mo_2_ind;
	}
	public String getMa_backdt_mo_3_ind() {
		return ma_backdt_mo_3_ind;
	}
	public void setMa_backdt_mo_3_ind(String ma_backdt_mo_3_ind) {
		this.ma_backdt_mo_3_ind = ma_backdt_mo_3_ind;
	}
	@Override
	public String toString() {
		return "CP_APP_IN_MED_BILLS [user=" + user + ", cargoName=" + cargoName + ", rowAction=" + rowAction
				+ ", adaptRecordId=" + adaptRecordId + ", delete_reason_cd=" + delete_reason_cd + ", app_num=" + app_num
				+ ", indv_seq_num=" + indv_seq_num + ", medical_seq_num=" + medical_seq_num + ", med_bill_type="
				+ med_bill_type + ", src_app_ind=" + src_app_ind + ", payment_amt=" + payment_amt + ", pay_freq="
				+ pay_freq + ", rec_cplt_ind=" + rec_cplt_ind + ", medical_bill_end_dt=" + medical_bill_end_dt
				+ ", adapt_record_id=" + adapt_record_id + ", change_dt=" + change_dt + ", special_needs_desc="
				+ special_needs_desc + ", reimburse_name=" + reimburse_name + ", reimburse_ind=" + reimburse_ind
				+ ", reimburse_amt=" + reimburse_amt + ", pymnt_amnt=" + pymnt_amnt + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", age=" + age + ", medBillTypes=" + medBillTypes + ", ma_backdt_mo_1_ind="
				+ ma_backdt_mo_1_ind + ", ma_backdt_mo_2_ind=" + ma_backdt_mo_2_ind + ", ma_backdt_mo_3_ind="
				+ ma_backdt_mo_3_ind + "]";
	}
	
	
	
	

}
