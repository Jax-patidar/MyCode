package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense;

public class CP_APP_IN_MED_INS_Collection {

	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int policy_seq_num;
	private int indv_seq_num;
	private String src_app_ind;
	private String cvrg_begin_dt;
	private String cvrg_end_dt;
	private String rec_cplt_ind;
	private String health_insurance_name;
	private String past_cvrg_gdcs_cd;
	private String policy_num;
	private String ins_cobra_ind;
	private String jnt_ins_resp;
	private String ins_type_cd;
	private String ins_limited_benefit_plan_ind;
	private String ins_retiree_plan_ind;
	private String health_insurance_cont_name;
	private String health_ins_type;
	private String health_cvrg_exp_to_end_ind;
	private String state_emp_benefit_ind;
	private String medicare_beneficiary;
	private String medicare_who_pays_A;
	private String medicare_who_pays_B;
	private String medicare_who_pays_C;
	private String medicare_who_pays_D;
	private String medicare_premium_A;
	private String medicare_premium_B;
	private String medicare_premium_C;
	private String medicare_premium_D;
	private String health_ins_premium;
	private String health_ins_frequency;

	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getPolicy_seq_num() {
		return policy_seq_num;
	}
	public void setPolicy_seq_num(int policy_seq_num) {
		this.policy_seq_num = policy_seq_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getCvrg_begin_dt() {
		return cvrg_begin_dt;
	}
	public void setCvrg_begin_dt(String cvrg_begin_dt) {
		this.cvrg_begin_dt = cvrg_begin_dt;
	}
	public String getCvrg_end_dt() {
		return cvrg_end_dt;
	}
	public void setCvrg_end_dt(String cvrg_end_dt) {
		this.cvrg_end_dt = cvrg_end_dt;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getHealth_insurance_name() {
		return health_insurance_name;
	}
	public void setHealth_insurance_name(String health_insurance_name) {
		this.health_insurance_name = health_insurance_name;
	}
	public String getPast_cvrg_gdcs_cd() {
		return past_cvrg_gdcs_cd;
	}
	public void setPast_cvrg_gdcs_cd(String past_cvrg_gdcs_cd) {
		this.past_cvrg_gdcs_cd = past_cvrg_gdcs_cd;
	}
	public String getPolicy_num() {
		return policy_num;
	}
	public void setPolicy_num(String policy_num) {
		this.policy_num = policy_num;
	}
	public String getIns_cobra_ind() {
		return ins_cobra_ind;
	}
	public void setIns_cobra_ind(String ins_cobra_ind) {
		this.ins_cobra_ind = ins_cobra_ind;
	}
	public String getJnt_ins_resp() {
		return jnt_ins_resp;
	}
	public void setJnt_ins_resp(String jnt_ins_resp) {
		this.jnt_ins_resp = jnt_ins_resp;
	}
	public String getIns_type_cd() {
		return ins_type_cd;
	}
	public void setIns_type_cd(String ins_type_cd) {
		this.ins_type_cd = ins_type_cd;
	}
	public String getIns_limited_benefit_plan_ind() {
		return ins_limited_benefit_plan_ind;
	}
	public void setIns_limited_benefit_plan_ind(String ins_limited_benefit_plan_ind) {
		this.ins_limited_benefit_plan_ind = ins_limited_benefit_plan_ind;
	}
	public String getIns_retiree_plan_ind() {
		return ins_retiree_plan_ind;
	}
	public void setIns_retiree_plan_ind(String ins_retiree_plan_ind) {
		this.ins_retiree_plan_ind = ins_retiree_plan_ind;
	}
	public String getHealth_insurance_cont_name() {
		return health_insurance_cont_name;
	}
	public void setHealth_insurance_cont_name(String health_insurance_cont_name) {
		this.health_insurance_cont_name = health_insurance_cont_name;
	}
	public String getHealth_ins_type() {
		return health_ins_type;
	}
	public void setHealth_ins_type(String health_ins_type) {
		this.health_ins_type = health_ins_type;
	}
	public String getHealth_cvrg_exp_to_end_ind() {
		return health_cvrg_exp_to_end_ind;
	}
	public void setHealth_cvrg_exp_to_end_ind(String health_cvrg_exp_to_end_ind) {
		this.health_cvrg_exp_to_end_ind = health_cvrg_exp_to_end_ind;
	}
	public String getState_emp_benefit_ind() {
		return state_emp_benefit_ind;
	}
	public void setState_emp_benefit_ind(String state_emp_benefit_ind) {
		this.state_emp_benefit_ind = state_emp_benefit_ind;
	}
	public String getMedicare_beneficiary() {
		return medicare_beneficiary;
	}
	public void setMedicare_beneficiary(String medicare_beneficiary) {
		this.medicare_beneficiary = medicare_beneficiary;
	}
	public String getMedicare_who_pays_A() {
		return medicare_who_pays_A;
	}
	public void setMedicare_who_pays_A(String medicare_who_pays_A) {
		this.medicare_who_pays_A = medicare_who_pays_A;
	}
	public String getMedicare_who_pays_B() {
		return medicare_who_pays_B;
	}
	public void setMedicare_who_pays_B(String medicare_who_pays_B) {
		this.medicare_who_pays_B = medicare_who_pays_B;
	}
	public String getMedicare_who_pays_C() {
		return medicare_who_pays_C;
	}
	public void setMedicare_who_pays_C(String medicare_who_pays_C) {
		this.medicare_who_pays_C = medicare_who_pays_C;
	}
	public String getMedicare_who_pays_D() {
		return medicare_who_pays_D;
	}
	public void setMedicare_who_pays_D(String medicare_who_pays_D) {
		this.medicare_who_pays_D = medicare_who_pays_D;
	}
	public String getMedicare_premium_A() {
		return medicare_premium_A;
	}
	public void setMedicare_premium_A(String medicare_premium_A) {
		this.medicare_premium_A = medicare_premium_A;
	}
	public String getMedicare_premium_B() {
		return medicare_premium_B;
	}
	public void setMedicare_premium_B(String medicare_premium_B) {
		this.medicare_premium_B = medicare_premium_B;
	}
	public String getMedicare_premium_C() {
		return medicare_premium_C;
	}
	public void setMedicare_premium_C(String medicare_premium_C) {
		this.medicare_premium_C = medicare_premium_C;
	}
	public String getMedicare_premium_D() {
		return medicare_premium_D;
	}
	public void setMedicare_premium_D(String medicare_premium_D) {
		this.medicare_premium_D = medicare_premium_D;
	}
	public String getHealth_ins_premium() {
		return health_ins_premium;
	}
	public void setHealth_ins_premium(String health_ins_premium) {
		this.health_ins_premium = health_ins_premium;
	}
	public String getHealth_ins_frequency() {
		return health_ins_frequency;
	}
	public void setHealth_ins_frequency(String health_ins_frequency) {
		this.health_ins_frequency = health_ins_frequency;
	}
}
