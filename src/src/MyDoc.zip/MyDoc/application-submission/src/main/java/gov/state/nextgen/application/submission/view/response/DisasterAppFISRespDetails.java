package gov.state.nextgen.application.submission.view.response;

public class DisasterAppFISRespDetails {
	private String currentPageID;
	private Object nextPageID;
	private Object nextPageAction;
	private Object previousPageID;
	private Object validationMessages;
	private Object pageCollectionResp;
	private String appNum;
	private Object pageMap;
	private DisasterAppFISPageCollection pageCollection;
	private Object beforeCollection;
	
	public String getCurrentPageID() {
		return currentPageID;
	}
	public void setCurrentPageID(String currentPageID) {
		this.currentPageID = currentPageID;
	}
	public Object getNextPageID() {
		return nextPageID;
	}
	public void setNextPageID(Object nextPageID) {
		this.nextPageID = nextPageID;
	}
	public Object getNextPageAction() {
		return nextPageAction;
	}
	public void setNextPageAction(Object nextPageAction) {
		this.nextPageAction = nextPageAction;
	}
	public Object getPreviousPageID() {
		return previousPageID;
	}
	public void setPreviousPageID(Object previousPageID) {
		this.previousPageID = previousPageID;
	}
	public Object getValidationMessages() {
		return validationMessages;
	}
	public void setValidationMessages(Object validationMessages) {
		this.validationMessages = validationMessages;
	}
	public Object getPageCollectionResp() {
		return pageCollectionResp;
	}
	public void setPageCollectionResp(Object pageCollectionResp) {
		this.pageCollectionResp = pageCollectionResp;
	}
	public String getAppNum() {
		return appNum;
	}
	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}
	public Object getPageMap() {
		return pageMap;
	}
	public void setPageMap(Object pageMap) {
		this.pageMap = pageMap;
	}
	public DisasterAppFISPageCollection getPageCollection() {
		return pageCollection;
	}
	public void setPageCollection(DisasterAppFISPageCollection pageCollection) {
		this.pageCollection = pageCollection;
	}
	public Object getBeforeCollection() {
		return beforeCollection;
	}
	public void setBeforeCollection(Object beforeCollection) {
		this.beforeCollection = beforeCollection;
	}

}
