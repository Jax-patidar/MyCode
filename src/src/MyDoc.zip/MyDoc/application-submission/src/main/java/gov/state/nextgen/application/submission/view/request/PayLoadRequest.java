package gov.state.nextgen.application.submission.view.request;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
class UserDetails{
    private String appNumber;

	public String getAppNumber() {
		return appNumber;
	}

	public void setAppNumber(String appNumber) {
		this.appNumber = appNumber;
	}
}

 @JsonAutoDetect(fieldVisibility = Visibility.ANY)
 class PageCollection { //NOSONAR


}
 class IndvSeqDetails{//NOSONAR
}

 class CurrentActionDetails{
	 
    private String pageId;
    private String pageAction;
    private IndvSeqDetails indvSeqDetails;
	public String getPageId() {
		return pageId;
	}
	public void setPageId(String pageId) {
		this.pageId = pageId;
	}
	public String getPageAction() {
		return pageAction;
	}
	public void setPageAction(String pageAction) {
		this.pageAction = pageAction;
	}
	public IndvSeqDetails getIndvSeqDetails() {
		return indvSeqDetails;
	}
	public void setIndvSeqDetails(IndvSeqDetails indvSeqDetails) {
		this.indvSeqDetails = indvSeqDetails;
	}
}



public class PayLoadRequest {
	
	private UserDetails userDetails;
	private CurrentActionDetails currentActionDetails;
	private PageCollection pageCollection = new PageCollection();
    
    public PayLoadRequest(String appNumber,String pageId,String pageAction) {
    	userDetails = new UserDetails();
    	currentActionDetails = new CurrentActionDetails();
    	this.getCurrentActionDetails().setPageAction(pageAction);
    	this.getCurrentActionDetails().setPageId(pageId);
    	this.getUserDetails().setAppNumber(appNumber);
    }
	public UserDetails getUserDetails() {
		return userDetails;
	}
	public void setUserDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
	}
	public CurrentActionDetails getCurrentActionDetails() {
		return currentActionDetails;
	}
	public void setCurrentActionDetails(CurrentActionDetails currentActionDetails) {
		this.currentActionDetails = currentActionDetails;
	}
	public PageCollection getPageCollection() {
		return pageCollection;
	}
	public void setPageCollection(PageCollection pageCollection) {
		this.pageCollection = pageCollection;
	}

}

