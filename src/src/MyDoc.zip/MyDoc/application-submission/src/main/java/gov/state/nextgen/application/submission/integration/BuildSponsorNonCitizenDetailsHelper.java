package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.APP_INDV_Collection;
import gov.state.nextgen.application.submission.view.payload.PhoneNumber;
import gov.state.nextgen.application.submission.view.payload.SponsoredNonCitzInfo;

import java.util.ArrayList;
import java.util.List;

public class BuildSponsorNonCitizenDetailsHelper {

    private BuildSponsorNonCitizenDetailsHelper() {
    }

    public static List<SponsoredNonCitzInfo> buildSponsorInfo(AggregatedPayload source) {//NOSONAR

        List<SponsoredNonCitzInfo> sponsors = new ArrayList<>();

        try {
            List<APP_INDV_Collection> individuals = source.getHouseholdDemographicsPersonDetails().getPageCollection().getAPP_INDV_Collection();
            if (individuals != null && !individuals.isEmpty()) {
                for (APP_INDV_Collection indv : individuals) {
                    if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(indv.getSpnsr_ctzn_ind()) || ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(indv.getAln_sponser_sw())) {
                        SponsoredNonCitzInfo sponsorInfo = new SponsoredNonCitzInfo();
                        sponsorInfo.setFirstName(indv.getSpnsr_first_name());
                        sponsorInfo.setLastName(indv.getSpnsr_last_name());
                        sponsorInfo.setHelpWithClothesInd(ApplicationUtil.translateBoolean(indv.getSpnsr_clothes_sw()));//NOSONAR
                        sponsorInfo.setHelpWithFoodInd(ApplicationUtil.translateBoolean(indv.getSpnsr_food_sw()));//NOSONAR
                        if (indv.getSpnsr_amt() != null)
                            sponsorInfo.setHelpWIthMoneyAmt(Double.parseDouble(indv.getSpnsr_amt()));
                        sponsorInfo.setHelpWithMoneyInd(ApplicationUtil.translateBoolean(indv.getSpnsr_help_sw()));//NOSONAR
                        sponsorInfo.setHelpWithOtherInd(ApplicationUtil.translateBoolean(indv.getSpnsr_other_sw()));//NOSONAR
                        sponsorInfo.setHelpWithRentInd(ApplicationUtil.translateBoolean(indv.getSpnsr_rent_sw()));//NOSONAR
                        sponsorInfo.setSignedI134Ind(ApplicationUtil.translateBoolean(indv.getSpnsr_i134_sign_sw()));//NOSONAR
                        sponsorInfo.setSignedI864Ind(ApplicationUtil.translateBoolean(indv.getSpnsr_i864_sign_sw()));//NOSONAR
                        sponsorInfo.setSponsoredNonCitzInd(ApplicationUtil.translateBoolean(indv.getSpnsr_ctzn_ind()));//NOSONAR

                        if (indv.getSpnsr_phn_num() != null && !ApplicationSubmissionConstants.STR_EMPT.equals(indv.getSpnsr_phn_num().trim())) {
                            PhoneNumber phNum = new PhoneNumber();
                            phNum.setNumber(indv.getSpnsr_phn_num());
                            sponsorInfo.setPhoneNumber(phNum);
                        }

                        sponsors.add(sponsorInfo);
                    }
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildSponsorNonCitizenDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while buildSponsorInfo::" + e.getMessage());
        }
        return sponsors;
    }
}
