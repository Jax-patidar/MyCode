package gov.state.nextgen.application.submission.view.response;

public class DisasterAppHHSRespDetails {
	
	private String currentPageID;
	private Object nextPageID;
	private Object nextPageAction;
	private Object previousPageID;
	private Object validationMessages;
	private String appNum;
	private Object pageMap;
	private DisasterAppHHSPageCollection pageCollection;
	
	public String getCurrentPageID() {
		return currentPageID;
	}
	public void setCurrentPageID(String currentPageID) {
		this.currentPageID = currentPageID;
	}
	public Object getNextPageID() {
		return nextPageID;
	}
	public void setNextPageID(Object nextPageID) {
		this.nextPageID = nextPageID;
	}
	public Object getNextPageAction() {
		return nextPageAction;
	}
	public void setNextPageAction(Object nextPageAction) {
		this.nextPageAction = nextPageAction;
	}
	public Object getPreviousPageID() {
		return previousPageID;
	}
	public void setPreviousPageID(Object previousPageID) {
		this.previousPageID = previousPageID;
	}
	public Object getValidationMessages() {
		return validationMessages;
	}
	public void setValidationMessages(Object validationMessages) {
		this.validationMessages = validationMessages;
	}
	public String getAppNum() {
		return appNum;
	}
	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}
	public Object getPageMap() {
		return pageMap;
	}
	public void setPageMap(Object pageMap) {
		this.pageMap = pageMap;
	}
	public DisasterAppHHSPageCollection getPageCollection() {
		return pageCollection;
	}
	public void setPageCollection(DisasterAppHHSPageCollection pageCollection) {
		this.pageCollection = pageCollection;
	}
	

}
