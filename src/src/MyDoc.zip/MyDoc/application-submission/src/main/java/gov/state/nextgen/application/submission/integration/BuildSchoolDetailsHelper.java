package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.APP_IN_SCHLE_Collection;
import gov.state.nextgen.application.submission.view.payload.School;

public class BuildSchoolDetailsHelper {
	
	private BuildSchoolDetailsHelper() {}
	
	public static List<School> buildSchoolDetails(List<APP_IN_SCHLE_Collection> sourceSchools, int indvSeqNum){//NOSONAR

		List<School> schools = new ArrayList<>();
		if(sourceSchools !=null && !sourceSchools.isEmpty()) {
			for(APP_IN_SCHLE_Collection sourceSchool: sourceSchools) {

				if(sourceSchool.getIndv_seq_num() == indvSeqNum) {

					School school = new School();
					String scType = sourceSchool.getSchool_type_cd();
					if(sourceSchool.getAvg_weekly_work_hrs() != null && StringUtils.isNumeric(sourceSchool.getAvg_weekly_work_hrs()))
						school.setAvgWorkHrsPerWeek(Integer.parseInt(sourceSchool.getAvg_weekly_work_hrs()));
					school.setDegreeCode(sourceSchool.getHs_grad_stat_cd());
					school.setDropOutDate(sourceSchool.getEnd_dt());
					school.setEnrollCode(sourceSchool.getEnrl_stat_cd());
					school.setGradDate(sourceSchool.getHs_grad_dt());
					if(sourceSchool.getNo_of_units() != null && StringUtils.isNumeric(sourceSchool.getNo_of_units()))
						school.setUnitsPerWeek(Integer.parseInt(sourceSchool.getNo_of_units()));
					school.setSchoolName(sourceSchool.getSchool_name());					
					school.setSchoolTerm(sourceSchool.getEnrl_stat_cd());
					schools.add(school);
				}
			}
		}
		return schools;
	}

}
