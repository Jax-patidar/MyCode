package gov.state.nextgen.application.submission.service.impl;

import gov.state.nextgen.application.submission.framework.ExceptionsUtil;
import gov.state.nextgen.application.submission.framework.exception.ExceptionLogManager;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.integration.BuildDisasterCalFreshHelper;
import gov.state.nextgen.application.submission.service.DisasterAppFISService;
import gov.state.nextgen.application.submission.service.DisasterAppHHSService;
import gov.state.nextgen.application.submission.service.DisasterAppNFSService;
import gov.state.nextgen.application.submission.service.DisasterAppTransferService;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.payload.ApplicationSubmissionPayload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import static gov.state.nextgen.application.submission.framework.constants.ExceptionConstants.KEY_IDENTIFIER_ONE;

import java.util.concurrent.CompletableFuture;

@Service
public class DisasterAppTransferServiceImpl implements DisasterAppTransferService {
    private static final Logger logger = LoggerFactory.getLogger(DisasterAppTransferServiceImpl.class);

    @Autowired
    private DisasterAppFISService disasterAppFISService;

    @Autowired
    private DisasterAppNFSService disasterAppNFSService;

    @Autowired
    private DisasterAppHHSService disasterAppHHSService;

    @Autowired
    private ExceptionLogManager exceptionLogManager;

    @Override
    public AggregatedPayload fetchDisasterCalFresh(String appNumber) {
    	MDC.put(KEY_IDENTIFIER_ONE, appNumber);
        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "initiating fetching data from internal APIs...::");

        AggregatedPayload aggregatedPayload = buildPayload(appNumber);
        try {
            CompletableFuture.allOf(
                    disasterAppFISService.fetchDisasterCalFISData(aggregatedPayload),
                    disasterAppNFSService.fetchDisasterCalNFSData(aggregatedPayload),
                    disasterAppHHSService.fetchDisasterCalHHSData(aggregatedPayload)
            ).join();
        } catch (Exception e) {
            aggregatedPayload.setErrorWhileAccessingInternalServices(true);
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Some error while fetching data from internal services.:");
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Exception occurred due to::" + e.getMessage());
            exceptionLogManager.sendMessage(ExceptionsUtil.getExceptionCargo(this.getClass(), e, "fetchDisasterCalFresh", appNumber));
            return aggregatedPayload;
        }
        return aggregatedPayload;
    }

    @Override
    public ApplicationSubmissionPayload fetchApplicationSubmissionPayload(AggregatedPayload source) {
        ApplicationSubmissionPayload target = BuildDisasterCalFreshHelper.buildApplicant(source);
        return target;
    }

    public AggregatedPayload buildPayload(String appNum) {
        AggregatedPayload aggregatedPayload = new AggregatedPayload();
        aggregatedPayload.setAppNumber(appNum);
        return aggregatedPayload;

    }
}
