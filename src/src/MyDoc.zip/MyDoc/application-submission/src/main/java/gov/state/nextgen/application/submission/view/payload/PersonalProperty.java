package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class PersonalProperty {

	private String type;
	@JsonIgnore
	private String useCode;
	private double owedAmount;
	private double valAmount;
	private String categoryCode;
	@JsonIgnore
	private String begDate;
	private String propertyName;
	@JsonIgnore
	private String acquired;
	private Boolean availableInd;
	@JsonIgnore
	private String availableDate;
	private String purchasePrice;
	@JsonIgnore
	private String pctOwned;
	private LiquidProperty liquidProperty;
	private MotorVehicle motorVehicle;
	private RealProperty realProperty;
	private String jointAccountPersID;
	private String jointPersFirstName;
	private String jointPersLastName;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUseCode() {
		return useCode;
	}

	public void setUseCode(String useCode) {
		this.useCode = useCode;
	}

	public double getOwedAmount() {
		return owedAmount;
	}

	public void setOwedAmount(double owedAmount) {
		this.owedAmount = owedAmount;
	}

	public double getValAmount() {
		return valAmount;
	}

	public void setValAmount(double valAmount) {
		this.valAmount = valAmount;
	}

	public String getCategoryCode() {
		return categoryCode;
	}

	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}

	public String getBegDate() {
		return begDate;
	}

	public void setBegDate(String begDate) {
		this.begDate = begDate;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getAcquired() {
		return acquired;
	}

	public void setAcquired(String acquired) {
		this.acquired = acquired;
	}

	public Boolean isAvailableInd() {
		return availableInd;
	}

	public void setAvailableInd(Boolean availableInd) {
		this.availableInd = availableInd;
	}

	public String getAvailableDate() {
		return availableDate;
	}

	public void setAvailableDate(String availableDate) {
		this.availableDate = availableDate;
	}

	public String getPurchasePrice() {
		return purchasePrice;
	}

	public void setPurchasePrice(String purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

	public String getPctOwned() {
		return pctOwned;
	}

	public void setPctOwned(String pctOwned) {
		this.pctOwned = pctOwned;
	}

	public LiquidProperty getLiquidProperty() {
		return liquidProperty;
	}

	public void setLiquidProperty(LiquidProperty liquidProperty) {
		this.liquidProperty = liquidProperty;
	}

	public MotorVehicle getMotorVehicle() {
		return motorVehicle;
	}

	public void setMotorVehicle(MotorVehicle motorVehicle) {
		this.motorVehicle = motorVehicle;
	}

	public RealProperty getRealProperty() {
		return realProperty;
	}

	public void setRealProperty(RealProperty realProperty) {
		this.realProperty = realProperty;
	}

	public String getJointAccountPersID() {
		return jointAccountPersID;
	}

	public void setJointAccountPersID(String jointAccountPersID) {
		this.jointAccountPersID = jointAccountPersID;
	}

	public String getJointPersFirstName() {
		return jointPersFirstName;
	}

	public void setJointPersFirstName(String jointPersFirstName) {
		this.jointPersFirstName = jointPersFirstName;
	}

	public String getJointPersLastName() {
		return jointPersLastName;
	}

	public void setJointPersLastName(String jointPersLastName) {
		this.jointPersLastName = jointPersLastName;
	}

}