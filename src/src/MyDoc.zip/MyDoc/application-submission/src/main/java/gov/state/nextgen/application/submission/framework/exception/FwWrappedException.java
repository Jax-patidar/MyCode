package gov.state.nextgen.application.submission.framework.exception;
/*
 *
 */

import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.Optional;

/**
 * Enter the description of the class
 *
 * @author Architecture Team Creation Date Sep 27, 2004 Modified By: Modified
 *         on: PCR#
 */
public class FwWrappedException extends RuntimeException implements Serializable{

	public static final String SPACE = " ";
	
	private static final String UNKNOWN = "UNKNOWN";
	
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private FwException fwException;
	private int exceptionID;
	
	@SuppressWarnings({"squid:S1165","squid:S1948"})
	private Optional<Timestamp> exceptionTime;
	
	private String primaryKeyText = "";
	private String callingClassID = "";
	private String callingMethodID = "";
	private String currentPageID = "";
	private String previousPageID = "";
	private String ipAddress = "";
	private String wamsLoginID = "";
	private String userID = "";
	private String serverName = "";
	private boolean inTransaction = false;
	private String appNum = "";
	private String userExceptionId = "";
	


	
	
	
	/**
	 * Constructor
	 */
	
	
	/**
	 * parses the trace and returns as a String Creation Date: Sep 27, 2004
	 */
	public static String getStackTraceValue(final Throwable e) {

		final StackTraceElement[] traceElement = e.getStackTrace();
		final StringBuilder traceValue = new StringBuilder(" | Stack Trace: ");
		for (int i = 0; i < traceElement.length; i++) {
			traceValue.append(traceElement[i]).append(':');
		}
		return traceValue.toString();
	}
	
	public FwWrappedException(final Throwable t) {
		super(t);
		setExceptionTime(getTimestamp());

		try {
			setServerName(String.valueOf(InetAddress.getLocalHost()));
		} catch (final UnknownHostException uhe) {
			setServerName(UNKNOWN);
		}
	}

	public FwWrappedException() {
		super();
		setExceptionTime(getTimestamp());

		try {
			setServerName(String.valueOf(InetAddress.getLocalHost()));
		} catch (final UnknownHostException uhe) {
			setServerName(UNKNOWN);
		}
	}

	/**
	 * This constructor is used to print the full exception text in the console
	 */
	public FwWrappedException(final String exceptionText) {
		super(exceptionText);
		setExceptionTime(getTimestamp());
		try {
			setServerName(String.valueOf(InetAddress.getLocalHost()));
		} catch (final UnknownHostException uhe) {
			setServerName(UNKNOWN);
		}
	}

	public FwWrappedException(final String exceptionText, final Throwable t) {
		super(exceptionText, t);
		setExceptionTime(getTimestamp());
		try {
			setServerName(String.valueOf(InetAddress.getLocalHost()));
		} catch (final UnknownHostException uhe) {
			setServerName(UNKNOWN);
		}
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getCallingClassID() {
		return callingClassID;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getCallingMethodID() {
		return callingMethodID;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getCurrentPageID() {
		return currentPageID;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public int getExceptionID() {
		return exceptionID;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public FwException getFwException() {
		return fwException != null ? fwException : new FwException(SPACE);
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getPreviousPageID() {
		return previousPageID;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getPrimaryKeyText() {
		return primaryKeyText;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getUserID() {
		return userID;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public String getWamsLoginID() {
		return wamsLoginID;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setCallingClassID(final String aCallingClassID) {
		callingClassID = aCallingClassID != null ? aCallingClassID : SPACE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setCallingMethodID(final String aCallingMethodID) {
		callingMethodID = aCallingMethodID != null ? aCallingMethodID : SPACE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setCurrentPageID(final String aCurrentPageID) {
		currentPageID = aCurrentPageID != null ? aCurrentPageID : SPACE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setExceptionID(final int aExceptionID) {
		exceptionID = aExceptionID;
	}

	public Optional<Timestamp> getExceptionTime() {
		return this.exceptionTime;
	}

	public void setExceptionTime(final Timestamp exceptionTime) {
		this.exceptionTime = Optional.ofNullable(exceptionTime);
	}
	
	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setFwException(final FwException exception) {
		fwException = exception;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setIpAddress(final String aIpAddress) {
		ipAddress = aIpAddress != null ? aIpAddress : SPACE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setPreviousPageID(final String aPreviousPageID) {
		previousPageID = aPreviousPageID != null ? aPreviousPageID : SPACE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setPrimaryKeyText(final String aPrimaryKeyText) {
		primaryKeyText = aPrimaryKeyText != null ? aPrimaryKeyText : SPACE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setUserID(final String aUserID) {
		userID = aUserID != null ? aUserID : SPACE;
	}

	/**
	 * Enter the description of the method Creation Date: Sep 27, 2004
	 */
	public void setWamsLoginID(final String aWamsLoginID) {
		wamsLoginID = aWamsLoginID != null ? aWamsLoginID : SPACE;
	}

	
	
	public String getAppNum() {
		return appNum;
	}

	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}

	public String getUserExceptionId() {
		return userExceptionId;
	}

	public void setUserExceptionId(String userExceptionId) {
		this.userExceptionId = userExceptionId;
	}

	/**
	 * returns the all the field values in one string Creation Date: Oct 25,
	 * 2004
	 */
	public String inspectException() {

		final StringBuilder temp = new StringBuilder();
		temp.append(" | exceptionID=").append(exceptionID).append(" | exceptionTime=").append(exceptionTime).append(" | serverName=")
		.append(serverName).append(" | primaryKeyText=").append(primaryKeyText).append(" | callingClassID=").append(callingClassID)
		.append(" | callingMethodID=").append(callingMethodID).append(" | currentPageID=").append(currentPageID).append(" | previousPageID=")
				.append(previousPageID).append(" | ipAddress=").append(ipAddress).append(" | wamsLoginID=").append(wamsLoginID).append(" | userID=")
				.append(userID);
		return temp.toString();
	}

	/**
	 * Enter the description of the method Creation Date:
	 */
	public String getServerName() {
		return serverName;
	}

	/**
	 * Enter the description of the method Creation Date:
	 */
	public void setServerName(final String string) {
		serverName = string;
	}

	/**
	 * Enter the description of the method Creation Date:
	 */
	public boolean isInTransaction() {
		return inTransaction;
	}

	/**
	 * Enter the description of the method Creation Date:
	 */
	public void setInTransaction(final boolean b) {
		inTransaction = b;
	}

	public java.sql.Timestamp getTimestamp() {
		return new java.sql.Timestamp(new java.util.Date().getTime());
	}

}

