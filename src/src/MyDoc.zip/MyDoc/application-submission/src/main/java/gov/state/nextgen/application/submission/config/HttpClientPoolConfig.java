package gov.state.nextgen.application.submission.config;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 */
@Configuration
public class HttpClientPoolConfig {

	@Value("${http.pool.config.app-submission.max_total}")
	private int configMaxTotal;
	
	@Value("${http.pool.config.app-submission.max_per_route}")
	private int configMaxPerRoute;
	
	@Value("${http.pool.config.app-submission.read_timeout}")
	private int readTimeout;
	
	@Value("${http.pool.config.app-submission.connection_timeout}")
	private int connectionTimeout;
	
	@Value("${http.pool.config.app-submission.socket_timeout}")
	private int socketTimeout;
	
	
	/**
	 * <li>
	 * 		The <code>poolingHttpClientConnectionManager</code> configures the PoolingHttpClientConnectionManager
	 * </li>
	 * 
	 * @return connectionManager
	 */
	@Bean
	public PoolingHttpClientConnectionManager poolingHttpClientConnectionManager() {
		PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
		connectionManager.setMaxTotal(configMaxTotal);
		connectionManager.setDefaultMaxPerRoute(configMaxPerRoute);
		return connectionManager;
	}
	
	
	/**
	 * <li>
	 * 		The <code>defaultRequestConfig</code> configures HTTP(s) req the connectionTime settings.
	 * </li>
	 * @return
	 */
	@Bean
	public RequestConfig defaultRequestConfig() {
		return RequestConfig.custom().setConnectionRequestTimeout(readTimeout).setConnectTimeout(connectionTimeout).setSocketTimeout(socketTimeout).build();
	}
	
}
