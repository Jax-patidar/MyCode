package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class CP_APP_IN_TAX_DEPENDENTS_Collection {
	
	private String last_name;
	private String first_name;
	private String relationship;
	private int dependent_indv_seq_num;
	private int indv_seq_num;
	
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
	public int getDependent_indv_seq_num() {
		return dependent_indv_seq_num;
	}
	public void setDependent_indv_seq_num(int dependent_indv_seq_num) {
		this.dependent_indv_seq_num = dependent_indv_seq_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

}
