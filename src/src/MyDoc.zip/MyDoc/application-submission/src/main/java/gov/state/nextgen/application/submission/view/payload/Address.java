package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class Address {
	
	private String addrType;
	private String streetAddr1;
	private String streetAddr2;
	private String cityName;
	private String zipCode;
	@JsonIgnore
	private String zipCodeSuffix;
	@JsonIgnore
	private boolean districtOfficeInd;
	@JsonIgnore
	private boolean permInd;
	@JsonIgnore
	private String poBoxNum;
	private String state;
	@JsonIgnore
	private boolean commAgencyInd;

	public String getAddrType() {
		return addrType;
	}

	public void setAddrType(String addrType) {
		this.addrType = addrType;
	}

	public String getStreetAddr1() {
		return streetAddr1;
	}

	public void setStreetAddr1(String streetAddr1) {
		this.streetAddr1 = streetAddr1;
	}

	public String getStreetAddr2() {
		return streetAddr2;
	}

	public void setStreetAddr2(String streetAddr2) {
		this.streetAddr2 = streetAddr2;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getZipCodeSuffix() {
		return zipCodeSuffix;
	}

	public void setZipCodeSuffix(String zipCodeSuffix) {
		this.zipCodeSuffix = zipCodeSuffix;
	}

	public boolean isDistrictOfficeInd() {
		return districtOfficeInd;
	}

	public void setDistrictOfficeInd(boolean districtOfficeInd) {
		this.districtOfficeInd = districtOfficeInd;
	}

	public boolean isPermInd() {
		return permInd;
	}

	public void setPermInd(boolean permInd) {
		this.permInd = permInd;
	}

	public String getPoBoxNum() {
		return poBoxNum;
	}

	public void setPoBoxNum(String poBoxNum) {
		this.poBoxNum = poBoxNum;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public boolean isCommAgencyInd() {
		return commAgencyInd;
	}

	public void setCommAgencyInd(boolean commAgencyInd) {
		this.commAgencyInd = commAgencyInd;
	}
}
