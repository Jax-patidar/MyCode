package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class PageCollection {

	@JsonDeserialize(contentAs = CP_APP_IN_INCOME_TAX_DED.class)
	private List< CP_APP_IN_INCOME_TAX_DED> CP_APP_IN_INCOME_TAX_DED;


	@JsonDeserialize(contentAs = CP_ABCHS_Collection.class)
	private List<CP_ABCHS_Collection> CP_ABCHS_Collection;


	@JsonDeserialize(contentAs = CP_APP_IN_HOU_BILLS.class)
	private List<CP_APP_IN_HOU_BILLS> CP_APP_IN_HOU_BILLS;


	@JsonDeserialize(contentAs = CP_APP_IN_MED_BILLS.class)
	private List<CP_APP_IN_MED_BILLS> CP_APP_IN_MED_BILLS;


	@JsonDeserialize(contentAs = CP_APP_IN_DEDUCTION.class)
	private List<CP_APP_IN_DEDUCTION> CP_APP_IN_DEDUCTION;

	public List<CP_ABCHS_Collection> getCP_ABCHS_Collection() {
		return CP_ABCHS_Collection;
	}
	
	public void setCP_ABCHS_Collection(List<CP_ABCHS_Collection> cP_ABCHS_Collection) {
		CP_ABCHS_Collection = cP_ABCHS_Collection;
	}
	
	public List<CP_APP_IN_INCOME_TAX_DED> getCP_APP_IN_INCOME_TAX_DED() {
		return CP_APP_IN_INCOME_TAX_DED;
	}

	public void setCP_APP_IN_INCOME_TAX_DED(List<CP_APP_IN_INCOME_TAX_DED> cP_APP_IN_INCOME_TAX_DED) {
		CP_APP_IN_INCOME_TAX_DED = cP_APP_IN_INCOME_TAX_DED;
	}

	public List<CP_APP_IN_HOU_BILLS> getCP_APP_IN_HOU_BILLS() {
		return CP_APP_IN_HOU_BILLS;
	}

	public void setCP_APP_IN_HOU_BILLS(List<CP_APP_IN_HOU_BILLS> cP_APP_IN_HOU_BILLS) {
		CP_APP_IN_HOU_BILLS = cP_APP_IN_HOU_BILLS;
	}

	public List<CP_APP_IN_MED_BILLS> getCP_APP_IN_MED_BILLS() {
		return CP_APP_IN_MED_BILLS;
	}

	public void setCP_APP_IN_MED_BILLS(List<CP_APP_IN_MED_BILLS> cP_APP_IN_MED_BILLS) {
		CP_APP_IN_MED_BILLS = cP_APP_IN_MED_BILLS;
	}

	public List<CP_APP_IN_DEDUCTION> getCP_APP_IN_DEDUCTION() {
		return CP_APP_IN_DEDUCTION;
	}

	public void setCP_APP_IN_DEDUCTION(List<CP_APP_IN_DEDUCTION> cP_APP_IN_DEDUCTION) {
		CP_APP_IN_DEDUCTION = cP_APP_IN_DEDUCTION;
	}
}
