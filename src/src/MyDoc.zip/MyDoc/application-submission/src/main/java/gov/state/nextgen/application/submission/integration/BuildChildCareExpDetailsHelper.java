package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_ABCHS_Collection;
import gov.state.nextgen.application.submission.view.payload.Address;
import gov.state.nextgen.application.submission.view.payload.Expenses;

public class BuildChildCareExpDetailsHelper {
	
	private BuildChildCareExpDetailsHelper() {}
	
	public static List<Expenses> buildChildExpenses(AggregatedPayload source, int indvSeq) {//NOSONAR

		Expenses expense = null;
		List<Expenses> expenseList = new ArrayList<>();
		List<CP_ABCHS_Collection> childExpenseList = source.getFinancialExpenseSummaryDetails().getPageCollection().getCP_ABCHS_Collection();
		if(childExpenseList !=null && !childExpenseList.isEmpty()) {
			for(CP_ABCHS_Collection childExpense : childExpenseList) {
				if(indvSeq == childExpense.getIndv_seq_num()) {
					expense = new Expenses(); 
					String PrvdType = childExpense.getPrvd_type() != null ? childExpense.getPrvd_type() : "DC";
					List<String> typeCatList = BuildIncomeTypeMappingHelper.getExpenseCd(PrvdType);
					if(!typeCatList.isEmpty()) {
						expense.setCategoryCode(typeCatList.get(0));
						expense.setTypeCode(typeCatList.get(1));
					} 
					String freqCd = childExpense.getPay_freq();
					if(ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
						expense.setFreqCode(ApplicationSubmissionConstants.FRE_II);
					} else {
						expense.setFreqCode(freqCd);
					}
					
					if(childExpense.getDpnd_care_exp_amt() != null)
					{
						double depCareAmt = Double.parseDouble(childExpense.getDpnd_care_exp_amt());
						expense.setDollarAmt(depCareAmt);
					}					
					expense.setOtherDollarAmount(0); 
					expense.setRecipientName(null); 
					expense.setDescription(null);
					expense.setCareProviderName(childExpense.getPrvd_org_nam()); 
					expense.setCareProviderAddress(getAddress(childExpense));
					if(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(childExpense.getJnt_pay_resp())) {
						expense.setHsngExpnHelpInd(true); 
						expense.setHsngHlpFirstName(childExpense.getJnt_payee_first_name());
						expense.setHsngHlpLastName(childExpense.getJnt_payee_last_name()); 
						if(childExpense.getJnt_amt_paid() != null)
						{
							double depCareJntAmt = Double.parseDouble(childExpense.getJnt_amt_paid());
							expense.setHsngHlpAmt(depCareJntAmt);
						}						
						expense.setHsngHlpFreq(childExpense.getJnt_payee_pay_freq()); 
					} 
					expense.setLiheapInd(false);
					expense.setWhoWillReimburse(null); 
					expense.setReimburseAmount(0);
					expense.setNameOfChildren(null);
					expense.setTaxDeductibleAlimonyPmtInd(false);
					expense.setOtherDeductableExpenseText(null); 

					expenseList.add(expense); 

				}
			}
		}
		return expenseList;
	}


	public static Address getAddress(CP_ABCHS_Collection childEmpColl) {
		Address address = null;
		if(childEmpColl != null && (childEmpColl.getPrvd_addr_line1() != null || childEmpColl.getPrvd_addr_city() != null
				|| childEmpColl.getPrvd_addr_zip() != null || childEmpColl.getPrvd_address_state_cd() != null)) {
			address = new Address();
			address.setAddrType(ApplicationSubmissionConstants.STR_PH);
			address.setStreetAddr1(childEmpColl.getPrvd_addr_line1());
			address.setStreetAddr2(childEmpColl.getPrvd_addr_line2());
			address.setCityName(childEmpColl.getPrvd_addr_city());
			address.setZipCode(childEmpColl.getPrvd_addr_zip());
			address.setState(childEmpColl.getPrvd_address_state_cd());
		}
		return address;
	}
}