package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_UEI_Collection;
import gov.state.nextgen.application.submission.view.payload.OtherPgmAssistance;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class BuildOtherPrgDetailsHelper {
	
	private BuildOtherPrgDetailsHelper() {}
	
	public static List<OtherPgmAssistance> buildOtherPrgDetails(AggregatedPayload source, int indvSeq) {//NOSONAR

		OtherPgmAssistance othrPrrgAs = null;
		String[] progArray = new String[] { ApplicationSubmissionConstants.PRG_SI, 
				ApplicationSubmissionConstants.PRG_PA, ApplicationSubmissionConstants.PRG_FP, 
				ApplicationSubmissionConstants.PRG_CP }; 
		List<String> otherPrgList = new ArrayList<>(Arrays.asList(progArray));
		List<OtherPgmAssistance> otherPrgsList = new ArrayList<>();
		
		
		try {
			List<APP_IN_UEI_Collection> indvUnearnIncomeList = source.getFinancialIncomeSummaryDetails().getPageCollection().getaPP_IN_UEI_Collection();

			if(indvUnearnIncomeList != null && !indvUnearnIncomeList.isEmpty()) {
				List<APP_IN_UEI_Collection> unEarnExpenseList = indvUnearnIncomeList.stream().filter(unErnExp->indvSeq == unErnExp.getIndv_seq_num()).collect(Collectors.toList());

				if(unEarnExpenseList != null && !unEarnExpenseList.isEmpty()) {
					for (APP_IN_UEI_Collection unearndIncome : unEarnExpenseList) {
						othrPrrgAs = new OtherPgmAssistance();
						String uieType = unearndIncome.getUei_typ();
						if(otherPrgList.contains(uieType)) {
							if(ApplicationSubmissionConstants.PRG_SI.equals(uieType)) {
								othrPrrgAs.setProgramCode(ApplicationSubmissionConstants.PRG_SS);
							}
							if(ApplicationSubmissionConstants.PRG_PA.equals(uieType)) {
								othrPrrgAs.setProgramCode(ApplicationSubmissionConstants.PRG_FS);
							}
							if(ApplicationSubmissionConstants.PRG_FP.equals(uieType)) {
								othrPrrgAs.setProgramCode(ApplicationSubmissionConstants.PRG_FC);
							}
							if(ApplicationSubmissionConstants.PRG_CP.equals(uieType)) {
								othrPrrgAs.setProgramCode(ApplicationSubmissionConstants.PRG_CC);
							}

							othrPrrgAs.setState(unearndIncome.getState());
							othrPrrgAs.setCounty(unearndIncome.getCounty());
							othrPrrgAs.setBegDate(unearndIncome.getUei_beg_dt());
							othrPrrgAs.setAmount(unearndIncome.getUei_amt());
							String freqCd = unearndIncome.getFreq_cd();
							if(ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
								othrPrrgAs.setFrequency(ApplicationSubmissionConstants.FRE_II);
							} else {
								othrPrrgAs.setFrequency(freqCd);
							}
							othrPrrgAs.setContinueToReceiveInd(ApplicationUtil.translateBoolean(unearndIncome.getExpected_to_cont_resp()));//NOSONAR
							otherPrgsList.add(othrPrrgAs);
						}
					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildOtherPrgDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while buildOtherPrgDetails::" + e.getMessage());
		}
		return otherPrgsList;
	}
		
}
