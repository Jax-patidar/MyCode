package gov.state.nextgen.application.submission.framework.constants;

@SuppressWarnings("squid:S1214")
public interface ExceptionConstants {

    String SERVICE_NAME = "BENEFITSCAL_APP_NAME";
    String KEY_IDENTIFIER_ONE = "appNum";
    String KEY_IDENTIFIER_TWO = "formType";

}
