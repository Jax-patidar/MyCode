package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class CP_APP_IN_TAX_DEPENDENT_Collection {
	
	private String last_name;
	private String first_name;
	private String relationship;
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getRelationship() {
		return relationship;
	}
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

}
