package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.APP_IN_LQD_ASET_Collection;
import gov.state.nextgen.application.submission.view.payload.LiquidProperty;
import gov.state.nextgen.application.submission.view.payload.LiquidResource;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BuildLiquidAssetDetailsHelper {
	
	private BuildLiquidAssetDetailsHelper() {}
	
	public static List<LiquidResource> buildLiquidAssets(AggregatedPayload source, int indvSeq) {

		LiquidResource liquidResource = null;
		List<LiquidResource> liquiAsetList = new ArrayList<>();
		
		try {
			List<APP_IN_LQD_ASET_Collection> liqAssetList = source.getFinancialAssetSummaryDetails().getPageCollection().getAPP_IN_LQD_ASET_Collection();

			if(liqAssetList != null && !liqAssetList.isEmpty()) {
				List<APP_IN_LQD_ASET_Collection> indvLiqAsetList = liqAssetList.stream().filter(liqAset->indvSeq == liqAset.getIndv_seq_num()).collect(Collectors.toList());

				if(indvLiqAsetList != null && !indvLiqAsetList.isEmpty()) {
					for(APP_IN_LQD_ASET_Collection liqAsset : indvLiqAsetList) {
						String lqdStr = liqAsset.getLqd_aset_typ();
						if(lqdStr != null && !ApplicationSubmissionConstants.STR_NA.equalsIgnoreCase(lqdStr)) {
							liquidResource = new LiquidResource(); 
							liquidResource.setType(BuildIncomeTypeMappingHelper.getLiqResourceCd(lqdStr));
							liquidResource.setValAmount(liqAsset.getLqd_aset_amt());
							liquidResource.setLiquidProperty(getLiqProp(liqAsset));					
							liquidResource.setCategoryCode(ApplicationSubmissionConstants.STR_LP);
							liquiAsetList.add(liquidResource); 
						}
					}			
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildLiquidAssetDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while buildLiquidAssets::" + e.getMessage());
		}
		return liquiAsetList;
	}
	
	public static LiquidProperty getLiqProp(APP_IN_LQD_ASET_Collection liqAsset) {
		LiquidProperty liquidProperty = new LiquidProperty();
		liquidProperty.setHldrFirstName(liqAsset.getFirst_name());
		liquidProperty.setHldrLastName(liqAsset.getLast_name());
		liquidProperty.setInstName(liqAsset.getFncl_inst_nam());
		liquidProperty.setJointInd(ApplicationUtil.translateBoolean(liqAsset.getJnt_own_resp()));//NOSONAR
		liquidProperty.setAssetName(liqAsset.getAsset_name());
		return liquidProperty;		
	}
	
}
