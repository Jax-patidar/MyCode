package gov.state.nextgen.application.submission.service;

import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

@Service
public class PayloadAggregatorService {

    @Autowired
    private FinancialIncomeSummaryDetailsService financialIncomeSummaryDetailsService;
    @Autowired
    private FinancialAssetSummaryDetailsService financialAssetSummaryDetailsService;
    @Autowired
    private NonFinancialInformationDetailsService nonFinancialInformationDetailsService;
    @Autowired
    private FinancialExpenseSummaryDetailsService financialExpenseSummaryDetailsService;
    @Autowired
    private HouseholdDemographicsProfileDetailsService householdDemographicsProfileDetailsService;
    @Autowired
    private HouseholdDemographicsPersonDetailsService householdDemographicsPersonDetailsService;


    public AggregatedPayload buildPayload(AggregatedPayload aggregatedPayload) {
        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "initiating fetching data from internal APIs....");
        try {
            CompletableFuture.allOf(
                    financialAssetSummaryDetailsService.fetchFinancialAssetSummaryDetailsData(aggregatedPayload),
                    financialIncomeSummaryDetailsService.fetchFinancialIncomeSummaryDetailsData(aggregatedPayload),
                    nonFinancialInformationDetailsService.fetchNonFinancialInformationDetailsData(aggregatedPayload),
                    financialExpenseSummaryDetailsService.fetchFinancialExpenseSummaryDetailsData(aggregatedPayload),
                    householdDemographicsPersonDetailsService.fetchHouseholdDemographicsPersonDetailsData(aggregatedPayload),
                    householdDemographicsProfileDetailsService.fetchHouseholdDemographicsProfileDetailsData(aggregatedPayload)
            ).join();
        } catch (Exception e) {
            aggregatedPayload.setErrorWhileAccessingInternalServices(true);
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Some error while fetching data from internal services..");

            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Some error while fetching data from internal services.");

            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Exception occurred due to::" + e.getMessage());
            return aggregatedPayload;
        }
        return aggregatedPayload;
    }

}
