package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class CP_APP_AUTH_REP_Collection {

	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private String rep_code;
	private String seq_num;
	private String src_app_ind;
	private String appl_esign_ind;
	private String appl_fst_nam;
	private String appl_last_nam;
	private String appl_mid_init;
	private String auth_rep_esign_ind;
	private String auth_rep_fst_nam;
	private String auth_rep_last_nam;
	private String auth_rep_mid_init;
	private String ma_fs_auth_rep_nam;
	private String witn_esign_ind;
	private String witn_fst_nam;
	private String witn_last_nam;
	private String witn_mid_init;
	private String filing_rep_fst_nam;
	private String filing_rep_last_nam;
	private String filing_rep_mid_nam;
	private String brg_crd_rcv_ind;
	private String l1_adr;
	private String l2_adr;
	private String city_adr;
	private String email_adr;
	private String phn_extn_num;
	private String phn_num;
	private String sta_adr;
	private String zip_adr;
	private String auth_rep_duty_afb_ind;
	private String auth_rep_duty_benefits_ind;
	private String auth_rep_duty_other_ind;
	private String auth_rep_duty_receive_ind;
	private String auth_rep_duty_request_ind;
	private String auth_rep_medical_assist_ind;
	private String rec_cplt_ind;
	private String snap_auth_rep_ind;
	private String tanf_auth_rep_ind;
	private String auth_rep_info_share_ind;
	private String adapt_record_id;
	private String auth_rep_id_num;
	private String auth_rep_org_nam;
	private String auth_rep_nam;
	private String rel_to_auth_rep_typ_cd;
	private String auth_rep_suffix_nam;
	private String addr_zip4;
	private String appl_esign_dt;
	private String app_start_dt;
	private String authRepMedInd;
	private String auth_rep_req_ind;
	private String agreement;
	private String cbo_rep_org_name;
	private String cbo_rep_id_num;
	private String ebt_card_pick;
	private String purchase_food;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getRep_code() {
		return rep_code;
	}
	public void setRep_code(String rep_code) {
		this.rep_code = rep_code;
	}
	public String getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(String seq_num) {
		this.seq_num = seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getAppl_esign_ind() {
		return appl_esign_ind;
	}
	public void setAppl_esign_ind(String appl_esign_ind) {
		this.appl_esign_ind = appl_esign_ind;
	}
	public String getAppl_fst_nam() {
		return appl_fst_nam;
	}
	public void setAppl_fst_nam(String appl_fst_nam) {
		this.appl_fst_nam = appl_fst_nam;
	}
	public String getAppl_last_nam() {
		return appl_last_nam;
	}
	public void setAppl_last_nam(String appl_last_nam) {
		this.appl_last_nam = appl_last_nam;
	}
	public String getAppl_mid_init() {
		return appl_mid_init;
	}
	public void setAppl_mid_init(String appl_mid_init) {
		this.appl_mid_init = appl_mid_init;
	}
	public String getAuth_rep_esign_ind() {
		return auth_rep_esign_ind;
	}
	public void setAuth_rep_esign_ind(String auth_rep_esign_ind) {
		this.auth_rep_esign_ind = auth_rep_esign_ind;
	}
	public String getAuth_rep_fst_nam() {
		return auth_rep_fst_nam;
	}
	public void setAuth_rep_fst_nam(String auth_rep_fst_nam) {
		this.auth_rep_fst_nam = auth_rep_fst_nam;
	}
	public String getAuth_rep_last_nam() {
		return auth_rep_last_nam;
	}
	public void setAuth_rep_last_nam(String auth_rep_last_nam) {
		this.auth_rep_last_nam = auth_rep_last_nam;
	}
	public String getAuth_rep_mid_init() {
		return auth_rep_mid_init;
	}
	public void setAuth_rep_mid_init(String auth_rep_mid_init) {
		this.auth_rep_mid_init = auth_rep_mid_init;
	}
	public String getMa_fs_auth_rep_nam() {
		return ma_fs_auth_rep_nam;
	}
	public void setMa_fs_auth_rep_nam(String ma_fs_auth_rep_nam) {
		this.ma_fs_auth_rep_nam = ma_fs_auth_rep_nam;
	}
	public String getWitn_esign_ind() {
		return witn_esign_ind;
	}
	public void setWitn_esign_ind(String witn_esign_ind) {
		this.witn_esign_ind = witn_esign_ind;
	}
	public String getWitn_fst_nam() {
		return witn_fst_nam;
	}
	public void setWitn_fst_nam(String witn_fst_nam) {
		this.witn_fst_nam = witn_fst_nam;
	}
	public String getWitn_last_nam() {
		return witn_last_nam;
	}
	public void setWitn_last_nam(String witn_last_nam) {
		this.witn_last_nam = witn_last_nam;
	}
	public String getWitn_mid_init() {
		return witn_mid_init;
	}
	public void setWitn_mid_init(String witn_mid_init) {
		this.witn_mid_init = witn_mid_init;
	}
	public String getFiling_rep_fst_nam() {
		return filing_rep_fst_nam;
	}
	public void setFiling_rep_fst_nam(String filing_rep_fst_nam) {
		this.filing_rep_fst_nam = filing_rep_fst_nam;
	}
	public String getFiling_rep_last_nam() {
		return filing_rep_last_nam;
	}
	public void setFiling_rep_last_nam(String filing_rep_last_nam) {
		this.filing_rep_last_nam = filing_rep_last_nam;
	}
	public String getFiling_rep_mid_nam() {
		return filing_rep_mid_nam;
	}
	public void setFiling_rep_mid_nam(String filing_rep_mid_nam) {
		this.filing_rep_mid_nam = filing_rep_mid_nam;
	}
	public String getBrg_crd_rcv_ind() {
		return brg_crd_rcv_ind;
	}
	public void setBrg_crd_rcv_ind(String brg_crd_rcv_ind) {
		this.brg_crd_rcv_ind = brg_crd_rcv_ind;
	}
	public String getL1_adr() {
		return l1_adr;
	}
	public void setL1_adr(String l1_adr) {
		this.l1_adr = l1_adr;
	}
	public String getL2_adr() {
		return l2_adr;
	}
	public void setL2_adr(String l2_adr) {
		this.l2_adr = l2_adr;
	}
	public String getCity_adr() {
		return city_adr;
	}
	public void setCity_adr(String city_adr) {
		this.city_adr = city_adr;
	}
	public String getEmail_adr() {
		return email_adr;
	}
	public void setEmail_adr(String email_adr) {
		this.email_adr = email_adr;
	}
	public String getPhn_extn_num() {
		return phn_extn_num;
	}
	public void setPhn_extn_num(String phn_extn_num) {
		this.phn_extn_num = phn_extn_num;
	}
	public String getPhn_num() {
		return phn_num;
	}
	public void setPhn_num(String phn_num) {
		this.phn_num = phn_num;
	}
	public String getSta_adr() {
		return sta_adr;
	}
	public void setSta_adr(String sta_adr) {
		this.sta_adr = sta_adr;
	}
	public String getZip_adr() {
		return zip_adr;
	}
	public void setZip_adr(String zip_adr) {
		this.zip_adr = zip_adr;
	}
	public String getAuth_rep_duty_afb_ind() {
		return auth_rep_duty_afb_ind;
	}
	public void setAuth_rep_duty_afb_ind(String auth_rep_duty_afb_ind) {
		this.auth_rep_duty_afb_ind = auth_rep_duty_afb_ind;
	}
	public String getAuth_rep_duty_benefits_ind() {
		return auth_rep_duty_benefits_ind;
	}
	public void setAuth_rep_duty_benefits_ind(String auth_rep_duty_benefits_ind) {
		this.auth_rep_duty_benefits_ind = auth_rep_duty_benefits_ind;
	}
	public String getAuth_rep_duty_other_ind() {
		return auth_rep_duty_other_ind;
	}
	public void setAuth_rep_duty_other_ind(String auth_rep_duty_other_ind) {
		this.auth_rep_duty_other_ind = auth_rep_duty_other_ind;
	}
	public String getAuth_rep_duty_receive_ind() {
		return auth_rep_duty_receive_ind;
	}
	public void setAuth_rep_duty_receive_ind(String auth_rep_duty_receive_ind) {
		this.auth_rep_duty_receive_ind = auth_rep_duty_receive_ind;
	}
	public String getAuth_rep_duty_request_ind() {
		return auth_rep_duty_request_ind;
	}
	public void setAuth_rep_duty_request_ind(String auth_rep_duty_request_ind) {
		this.auth_rep_duty_request_ind = auth_rep_duty_request_ind;
	}
	public String getAuth_rep_medical_assist_ind() {
		return auth_rep_medical_assist_ind;
	}
	public void setAuth_rep_medical_assist_ind(String auth_rep_medical_assist_ind) {
		this.auth_rep_medical_assist_ind = auth_rep_medical_assist_ind;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getSnap_auth_rep_ind() {
		return snap_auth_rep_ind;
	}
	public void setSnap_auth_rep_ind(String snap_auth_rep_ind) {
		this.snap_auth_rep_ind = snap_auth_rep_ind;
	}
	public String getTanf_auth_rep_ind() {
		return tanf_auth_rep_ind;
	}
	public void setTanf_auth_rep_ind(String tanf_auth_rep_ind) {
		this.tanf_auth_rep_ind = tanf_auth_rep_ind;
	}
	public String getAuth_rep_info_share_ind() {
		return auth_rep_info_share_ind;
	}
	public void setAuth_rep_info_share_ind(String auth_rep_info_share_ind) {
		this.auth_rep_info_share_ind = auth_rep_info_share_ind;
	}
	public String getAdapt_record_id() {
		return adapt_record_id;
	}
	public void setAdapt_record_id(String adapt_record_id) {
		this.adapt_record_id = adapt_record_id;
	}
	public String getAuth_rep_id_num() {
		return auth_rep_id_num;
	}
	public void setAuth_rep_id_num(String auth_rep_id_num) {
		this.auth_rep_id_num = auth_rep_id_num;
	}
	public String getAuth_rep_org_nam() {
		return auth_rep_org_nam;
	}
	public void setAuth_rep_org_nam(String auth_rep_org_nam) {
		this.auth_rep_org_nam = auth_rep_org_nam;
	}
	public String getAuth_rep_nam() {
		return auth_rep_nam;
	}
	public void setAuth_rep_nam(String auth_rep_nam) {
		this.auth_rep_nam = auth_rep_nam;
	}
	public String getRel_to_auth_rep_typ_cd() {
		return rel_to_auth_rep_typ_cd;
	}
	public void setRel_to_auth_rep_typ_cd(String rel_to_auth_rep_typ_cd) {
		this.rel_to_auth_rep_typ_cd = rel_to_auth_rep_typ_cd;
	}
	public String getAuth_rep_suffix_nam() {
		return auth_rep_suffix_nam;
	}
	public void setAuth_rep_suffix_nam(String auth_rep_suffix_nam) {
		this.auth_rep_suffix_nam = auth_rep_suffix_nam;
	}
	public String getAddr_zip4() {
		return addr_zip4;
	}
	public void setAddr_zip4(String addr_zip4) {
		this.addr_zip4 = addr_zip4;
	}
	public String getAppl_esign_dt() {
		return appl_esign_dt;
	}
	public void setAppl_esign_dt(String appl_esign_dt) {
		this.appl_esign_dt = appl_esign_dt;
	}
	public String getApp_start_dt() {
		return app_start_dt;
	}
	public void setApp_start_dt(String app_start_dt) {
		this.app_start_dt = app_start_dt;
	}
	public String getAuthRepMedInd() {
		return authRepMedInd;
	}
	public void setAuthRepMedInd(String authRepMedInd) {
		this.authRepMedInd = authRepMedInd;
	}
	public String getAuth_rep_req_ind() {
		return auth_rep_req_ind;
	}
	public void setAuth_rep_req_ind(String auth_rep_req_ind) {
		this.auth_rep_req_ind = auth_rep_req_ind;
	}
	public String getAgreement() {
		return agreement;
	}
	public void setAgreement(String agreement) {
		this.agreement = agreement;
	}
	public String getCbo_rep_org_name() {
		return cbo_rep_org_name;
	}
	public void setCbo_rep_org_name(String cbo_rep_org_name) {
		this.cbo_rep_org_name = cbo_rep_org_name;
	}
	public String getCbo_rep_id_num() {
		return cbo_rep_id_num;
	}
	public void setCbo_rep_id_num(String cbo_rep_id_num) {
		this.cbo_rep_id_num = cbo_rep_id_num;
	}
	public String getEbt_card_pick() {
		return ebt_card_pick;
	}
	public String getPurchase_food() {
		return purchase_food;
	}
	public void setEbt_card_pick(String ebt_card_pick) {
		this.ebt_card_pick = ebt_card_pick;
	}
	public void setPurchase_food(String purchase_food) {
		this.purchase_food = purchase_food;
	}
	@Override
	public String toString() {
		return "CP_APP_AUTH_REP_Collection [user=" + user + ", cargoName=" + cargoName + ", rowAction=" + rowAction
				+ ", adaptRecordId=" + adaptRecordId + ", delete_reason_cd=" + delete_reason_cd + ", app_num=" + app_num
				+ ", rep_code=" + rep_code + ", seq_num=" + seq_num + ", src_app_ind=" + src_app_ind
				+ ", appl_esign_ind=" + appl_esign_ind + ", appl_fst_nam=" + appl_fst_nam + ", appl_last_nam="
				+ appl_last_nam + ", appl_mid_init=" + appl_mid_init + ", auth_rep_esign_ind=" + auth_rep_esign_ind
				+ ", auth_rep_fst_nam=" + auth_rep_fst_nam + ", auth_rep_last_nam=" + auth_rep_last_nam
				+ ", auth_rep_mid_init=" + auth_rep_mid_init + ", ma_fs_auth_rep_nam=" + ma_fs_auth_rep_nam
				+ ", witn_esign_ind=" + witn_esign_ind + ", witn_fst_nam=" + witn_fst_nam + ", witn_last_nam="
				+ witn_last_nam + ", witn_mid_init=" + witn_mid_init + ", filing_rep_fst_nam=" + filing_rep_fst_nam
				+ ", filing_rep_last_nam=" + filing_rep_last_nam + ", filing_rep_mid_nam=" + filing_rep_mid_nam
				+ ", brg_crd_rcv_ind=" + brg_crd_rcv_ind + ", l1_adr=" + l1_adr + ", l2_adr=" + l2_adr + ", city_adr="
				+ city_adr + ", email_adr=" + email_adr + ", phn_extn_num=" + phn_extn_num + ", phn_num=" + phn_num
				+ ", sta_adr=" + sta_adr + ", zip_adr=" + zip_adr + ", auth_rep_duty_afb_ind=" + auth_rep_duty_afb_ind
				+ ", auth_rep_duty_benefits_ind=" + auth_rep_duty_benefits_ind + ", auth_rep_duty_other_ind="
				+ auth_rep_duty_other_ind + ", auth_rep_duty_receive_ind=" + auth_rep_duty_receive_ind
				+ ", auth_rep_duty_request_ind=" + auth_rep_duty_request_ind + ", auth_rep_medical_assist_ind="
				+ auth_rep_medical_assist_ind + ", rec_cplt_ind=" + rec_cplt_ind + ", snap_auth_rep_ind="
				+ snap_auth_rep_ind + ", tanf_auth_rep_ind=" + tanf_auth_rep_ind + ", auth_rep_info_share_ind="
				+ auth_rep_info_share_ind + ", adapt_record_id=" + adapt_record_id + ", auth_rep_id_num="
				+ auth_rep_id_num + ", auth_rep_org_nam=" + auth_rep_org_nam + ", auth_rep_nam=" + auth_rep_nam
				+ ", rel_to_auth_rep_typ_cd=" + rel_to_auth_rep_typ_cd + ", auth_rep_suffix_nam=" + auth_rep_suffix_nam
				+ ", addr_zip4=" + addr_zip4 + ", appl_esign_dt=" + appl_esign_dt + ", app_start_dt=" + app_start_dt
				+ ", authRepMedInd=" + authRepMedInd + ", auth_rep_req_ind=" + auth_rep_req_ind + ", agreement="
				+ agreement + ", cbo_rep_org_name=" + cbo_rep_org_name + ", cbo_rep_id_num=" + cbo_rep_id_num + ", ebt_card_pick=" + ebt_card_pick + ", purchase_food=" + purchase_food + "]";
	}
	
	
}
