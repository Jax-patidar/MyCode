package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense;

public class CP_APP_IN_HOU_BILLS_Collection {
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int seq_num;
	private int indv_seq_num;
	private String src_app_ind;
	private String bill_type;
	private double pymt_amt;
	private String pymt_freq;
	private String jnt_pay_resp;
	private int rec_cplt_ind;
	private String paid_amt;
	private String end_dt;
	private int ecp_id;
	private String propAddrZip4;
	private String chg_dt;
	private String loopingQuestion;
	private String property_name;
	private String prop_addr_l1;
	private String prop_addr_l2;
	private String prop_addr_city;
	private String prop_addr_state_cd;
	private String prop_addr_zip;
	private String prop_phone_num;
	private String jnt_payee_first_name;
	private String jnt_payee_last_name;
	private String jnt_pymt_freq;
	private String liheap_resp;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getBill_type() {
		return bill_type;
	}
	public void setBill_type(String bill_type) {
		this.bill_type = bill_type;
	}
	public double getPymt_amt() {
		return pymt_amt;
	}
	public void setPymt_amt(double pymt_amt) {
		this.pymt_amt = pymt_amt;
	}
	public String getPymt_freq() {
		return pymt_freq;
	}
	public void setPymt_freq(String pymt_freq) {
		this.pymt_freq = pymt_freq;
	}
	public String getJnt_pay_resp() {
		return jnt_pay_resp;
	}
	public void setJnt_pay_resp(String jnt_pay_resp) {
		this.jnt_pay_resp = jnt_pay_resp;
	}
	public int getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(int rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getPaid_amt() {
		return paid_amt;
	}
	public void setPaid_amt(String paid_amt) {
		this.paid_amt = paid_amt;
	}
	public String getEnd_dt() {
		return end_dt;
	}
	public void setEnd_dt(String end_dt) {
		this.end_dt = end_dt;
	}
	public int getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(int ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getPropAddrZip4() {
		return propAddrZip4;
	}
	public void setPropAddrZip4(String propAddrZip4) {
		this.propAddrZip4 = propAddrZip4;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getLoopingQuestion() {
		return loopingQuestion;
	}
	public void setLoopingQuestion(String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}
	public String getProperty_name() {
		return property_name;
	}
	public void setProperty_name(String property_name) {
		this.property_name = property_name;
	}
	public String getProp_addr_l1() {
		return prop_addr_l1;
	}
	public void setProp_addr_l1(String prop_addr_l1) {
		this.prop_addr_l1 = prop_addr_l1;
	}
	public String getProp_addr_l2() {
		return prop_addr_l2;
	}
	public void setProp_addr_l2(String prop_addr_l2) {
		this.prop_addr_l2 = prop_addr_l2;
	}
	public String getProp_addr_city() {
		return prop_addr_city;
	}
	public void setProp_addr_city(String prop_addr_city) {
		this.prop_addr_city = prop_addr_city;
	}
	public String getProp_addr_state_cd() {
		return prop_addr_state_cd;
	}
	public void setProp_addr_state_cd(String prop_addr_state_cd) {
		this.prop_addr_state_cd = prop_addr_state_cd;
	}
	public String getProp_addr_zip() {
		return prop_addr_zip;
	}
	public void setProp_addr_zip(String prop_addr_zip) {
		this.prop_addr_zip = prop_addr_zip;
	}
	public String getProp_phone_num() {
		return prop_phone_num;
	}
	public void setProp_phone_num(String prop_phone_num) {
		this.prop_phone_num = prop_phone_num;
	}
	public String getJnt_payee_first_name() {
		return jnt_payee_first_name;
	}
	public void setJnt_payee_first_name(String jnt_payee_first_name) {
		this.jnt_payee_first_name = jnt_payee_first_name;
	}
	public String getJnt_payee_last_name() {
		return jnt_payee_last_name;
	}
	public void setJnt_payee_last_name(String jnt_payee_last_name) {
		this.jnt_payee_last_name = jnt_payee_last_name;
	}
	public String getJnt_pymt_freq() {
		return jnt_pymt_freq;
	}
	public void setJnt_pymt_freq(String jnt_pymt_freq) {
		this.jnt_pymt_freq = jnt_pymt_freq;
	}
	public String getLiheap_resp() {
		return liheap_resp;
	}
	public void setLiheap_resp(String liheap_resp) {
		this.liheap_resp = liheap_resp;
	}

}
