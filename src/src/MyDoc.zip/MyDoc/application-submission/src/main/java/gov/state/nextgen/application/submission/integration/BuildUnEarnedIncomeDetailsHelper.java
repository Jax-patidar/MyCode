package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_UEI_Collection;
import gov.state.nextgen.application.submission.view.payload.Applicant;
import gov.state.nextgen.application.submission.view.payload.Income;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class BuildUnEarnedIncomeDetailsHelper {

    private BuildUnEarnedIncomeDetailsHelper() {
    }

    public static List<Income> buildUnearnedIncome(AggregatedPayload source, int indvSeq) {//NOSONAR

        List<APP_IN_UEI_Collection> indvUnearnIncomeList = null;
        List<APP_IN_UEI_Collection> unEarnExpenseList = null;
        Income income = null;
        List<Income> incomeList = new ArrayList<>();
        String[] progArray = new String[]{ApplicationSubmissionConstants.PRG_SI,
                ApplicationSubmissionConstants.PRG_PA, ApplicationSubmissionConstants.PRG_FP,
                ApplicationSubmissionConstants.PRG_CP};
        List<String> otherPrgList = new ArrayList<>(Arrays.asList(progArray));

        try {
            indvUnearnIncomeList = source.getFinancialIncomeSummaryDetails().getPageCollection().getaPP_IN_UEI_Collection();

            if (indvUnearnIncomeList != null && !indvUnearnIncomeList.isEmpty()) {
                unEarnExpenseList = indvUnearnIncomeList.stream().filter(unErnExp -> indvSeq == unErnExp.getIndv_seq_num()).collect(Collectors.toList());

                if (unEarnExpenseList != null && !unEarnExpenseList.isEmpty()) {
                    for (APP_IN_UEI_Collection unearndIncome : unEarnExpenseList) {
                        if (!otherPrgList.contains(unearndIncome.getUei_typ())) {
                            income = new Income();
                            List<String> typeCatList = BuildIncomeTypeMappingHelper.getUnEarnTypeCatCd(unearndIncome.getUei_typ());
                            if (!typeCatList.isEmpty()) {
                                income.setCategory(typeCatList.get(0));
                                if (!ApplicationSubmissionConstants.STR_EMPT.equals(typeCatList.get(1)))
                                    income.setTypeCode(typeCatList.get(1));
                            }

                            income.setAmount(unearndIncome.getUei_amt());
                            String freqCd = unearndIncome.getFreq_cd();
                            if (ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
                                income.setFrequency(ApplicationSubmissionConstants.FRE_II);
                            } else {
                                income.setFrequency(freqCd);
                            }
                            income.setSourceName(unearndIncome.getIncome_source());
                            income.setBeginDate(unearndIncome.getUei_beg_dt());
                            income.setEndDate(unearndIncome.getUei_end_dt());
                            income.setContinueToReceiveIncomeInd(ApplicationUtil.translateBoolean(unearndIncome.getExpected_to_cont_resp()));//NOSONAR
                            income.setIncomeNotExpectedToContExpl(unearndIncome.getEnd_reason());
                            income.setState(unearndIncome.getState());
                            income.setCounty(unearndIncome.getCounty());
                            income.setServicesReceived(unearndIncome.getServices());
                            income.setEstimatedValueofService(unearndIncome.getValue_of_services());
                            incomeList.add(income);
                        }
                    }
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildUnEarnedIncomeDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while buildUnearnedIncome::" + e.getMessage());
        }
        return incomeList;
    }

    public static void setCalLrnDetails(AggregatedPayload source, int indvSeqNum, Applicant calLrnIndv) {
        List<APP_IN_UEI_Collection> indvCalLearns = null;
        List<APP_IN_UEI_Collection> indvCalLrnList = null;

        try {
            indvCalLrnList = source.getFinancialIncomeSummaryDetails().getPageCollection().getaPP_IN_UEI_Collection();

            if (indvCalLrnList != null && !indvCalLrnList.isEmpty()) {
                indvCalLearns = indvCalLrnList.stream().filter(indv -> indvSeqNum == indv.getIndv_seq_num()).collect(Collectors.toList());

                for (APP_IN_UEI_Collection calLearn : indvCalLearns) {
                    if (calLearn.getDt_services_rcvd() != null) {
                        calLrnIndv.setCalLearnInd(true);
                        calLrnIndv.setCalLearnDt(calLearn.getDt_services_rcvd());
                    }
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildUnEarnedIncomeDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while setCalLrnDetails::" + e.getMessage());
        }

    }
}
