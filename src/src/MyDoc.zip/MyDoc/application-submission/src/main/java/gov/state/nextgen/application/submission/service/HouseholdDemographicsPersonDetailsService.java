package gov.state.nextgen.application.submission.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.ExceptionsUtil;
import gov.state.nextgen.application.submission.framework.exception.ExceptionLogManager;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.HouseholdDemographicsPersonDetails;
import gov.state.nextgen.application.submission.view.request.PayLoadRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import static gov.state.nextgen.application.submission.framework.constants.ExceptionConstants.KEY_IDENTIFIER_ONE;

import java.util.concurrent.CompletableFuture;

@Service
public class HouseholdDemographicsPersonDetailsService {

    private static final Logger logger = LoggerFactory.getLogger(HouseholdDemographicsPersonDetailsService.class);

    @Autowired
    @Qualifier("appSubmissionRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    @Qualifier("appSubmissionThreadPoolTaskExecutor")
    private ThreadPoolTaskExecutor threadPoolTaskExecutor;

    @Autowired
    private LambdaInvokerServiceImpl service;

    @Autowired
    private ExceptionLogManager exceptionLogManager;

    @Async("appSubmissionThreadPoolTaskExecutor")
    public CompletableFuture<AggregatedPayload> fetchHouseholdDemographicsPersonDetailsData(AggregatedPayload payload) {
    	MDC.put(KEY_IDENTIFIER_ONE,  payload.getAppNumber());
        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "fetching Household Demographics Person Details data for case::" + payload.getAppNumber());

        String responseBody = null;
        HouseholdDemographicsPersonDetails householdDemographicsPersonDetails = null;

        PayLoadRequest payLoadRequest = new PayLoadRequest(payload.getAppNumber(), ApplicationSubmissionConstants.ABPSD, ApplicationSubmissionConstants.ABPSD_LOAD);

        HttpEntity<Object> httpEntity = new HttpEntity<>(payLoadRequest);
        try {
            String url = System.getenv(ApplicationSubmissionConstants.HOUSEHOLD_DEMOGRAPHICS_PERSON_DETAILS_URL);
            String path = "/hhdemographics/" + ApplicationSubmissionConstants.ABPSD + "/" + ApplicationSubmissionConstants.ABPSD_LOAD;
            responseBody = service.invokeLambda(url, httpEntity, path);

            ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            householdDemographicsPersonDetails = objMapper.readValue(responseBody, HouseholdDemographicsPersonDetails.class);
            payload.setHouseholdDemographicsPersonDetails(householdDemographicsPersonDetails);

            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "successfully fetched Household Demographics Person Details data for case::" + payload.getAppNumber());

        } catch (Throwable e) { //NOSONAR
            payload.setErrorWhileAccessingInternalServices(true);
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Error while fetching data from Household Demographics Person Details data for case::" + payload.getAppNumber());
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Exception occurred due to::" + e.getMessage());
            exceptionLogManager.sendMessage(ExceptionsUtil.getExceptionCargo(this.getClass(), e, "fetchHouseholdDemographicsPersonDetailsData", payload.getAppNumber()));
        }
        return CompletableFuture.completedFuture(payload);
    }

}
