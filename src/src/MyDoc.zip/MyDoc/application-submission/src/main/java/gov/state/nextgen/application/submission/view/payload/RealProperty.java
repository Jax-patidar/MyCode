package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class RealProperty {
	@JsonIgnore
    public String parcelNumber;
	@JsonIgnore
    public String bookNumnber;
	@JsonIgnore
    public String pageNumber;
	@JsonIgnore
    public String lotNumber;	
    @JsonIgnore
    public String propertyListedDate;
    @JsonIgnore
    public boolean willingToList;
    @JsonIgnore
    public boolean willingToUtilize;
    @JsonIgnore
    public String utilizationDate;
    @JsonIgnore
    public boolean willingToLien;
    @JsonIgnore
    public String dateLienSigned;
    @JsonIgnore
    public String dateLienInitiated;
    @JsonIgnore
    public String dateLienRecorded;   
    @JsonIgnore
    public String totalUnitsNumber;
    @JsonIgnore
    public boolean unitsUsedForResidence;
    @JsonIgnore
    public String returned;
    public PropertyAddress propertyAddress;
    public Boolean someoneRentingInd;
    public double rentAmount;
    public String rentFrequency;
    @JsonIgnore
    public boolean planToLiveInFutureInd;
	public String getParcelNumber() {
		return parcelNumber;
	}
	public void setParcelNumber(String parcelNumber) {
		this.parcelNumber = parcelNumber;
	}
	public String getBookNumnber() {
		return bookNumnber;
	}
	public void setBookNumnber(String bookNumnber) {
		this.bookNumnber = bookNumnber;
	}
	public String getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}
	public String getLotNumber() {
		return lotNumber;
	}
	public void setLotNumber(String lotNumber) {
		this.lotNumber = lotNumber;
	}	
	public String getPropertyListedDate() {
		return propertyListedDate;
	}
	public void setPropertyListedDate(String propertyListedDate) {
		this.propertyListedDate = propertyListedDate;
	}
	public boolean isWillingToList() {
		return willingToList;
	}
	public void setWillingToList(boolean willingToList) {
		this.willingToList = willingToList;
	}
	public boolean isWillingToUtilize() {
		return willingToUtilize;
	}
	public void setWillingToUtilize(boolean willingToUtilize) {
		this.willingToUtilize = willingToUtilize;
	}
	public String getUtilizationDate() {
		return utilizationDate;
	}
	public void setUtilizationDate(String utilizationDate) {
		this.utilizationDate = utilizationDate;
	}
	public boolean isWillingToLien() {
		return willingToLien;
	}
	public void setWillingToLien(boolean willingToLien) {
		this.willingToLien = willingToLien;
	}
	public String getDateLienSigned() {
		return dateLienSigned;
	}
	public void setDateLienSigned(String dateLienSigned) {
		this.dateLienSigned = dateLienSigned;
	}
	public String getDateLienInitiated() {
		return dateLienInitiated;
	}
	public void setDateLienInitiated(String dateLienInitiated) {
		this.dateLienInitiated = dateLienInitiated;
	}
	public String getDateLienRecorded() {
		return dateLienRecorded;
	}
	public void setDateLienRecorded(String dateLienRecorded) {
		this.dateLienRecorded = dateLienRecorded;
	}	
	public String getTotalUnitsNumber() {
		return totalUnitsNumber;
	}
	public void setTotalUnitsNumber(String totalUnitsNumber) {
		this.totalUnitsNumber = totalUnitsNumber;
	}
	public boolean isUnitsUsedForResidence() {
		return unitsUsedForResidence;
	}
	public void setUnitsUsedForResidence(boolean unitsUsedForResidence) {
		this.unitsUsedForResidence = unitsUsedForResidence;
	}
	public String getReturned() {
		return returned;
	}
	public void setReturned(String returned) {
		this.returned = returned;
	}
	public PropertyAddress getPropertyAddress() {
		return propertyAddress;
	}
	public void setPropertyAddress(PropertyAddress propertyAddress) {
		this.propertyAddress = propertyAddress;
	}
	public Boolean isSomeoneRentingInd() {
		return someoneRentingInd;
	}
	public void setSomeoneRentingInd(Boolean someoneRentingInd) {
		this.someoneRentingInd = someoneRentingInd;
	}
	public double getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(double rentAmount) {
		this.rentAmount = rentAmount;
	}
	public String getRentFrequency() {
		return rentFrequency;
	}
	public void setRentFrequency(String rentFrequency) {
		this.rentFrequency = rentFrequency;
	}
	public boolean isPlanToLiveInFutureInd() {
		return planToLiveInFutureInd;
	}
	public void setPlanToLiveInFutureInd(boolean planToLiveInFutureInd) {
		this.planToLiveInFutureInd = planToLiveInFutureInd;
	}

}
