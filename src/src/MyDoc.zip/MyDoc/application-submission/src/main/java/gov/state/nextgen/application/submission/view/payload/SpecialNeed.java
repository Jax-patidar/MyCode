package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class SpecialNeed {
	private String type;
	private String specialNeedsText;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSpecialNeedsText() {
		return specialNeedsText;
	}

	public void setSpecialNeedsText(String specialNeedsText) {
		this.specialNeedsText = specialNeedsText;
	}
}
