package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class APP_IN_OUT_ST_BNFT_Collection{
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int indv_seq_num;
	private int seq_num;
	private String src_app_ind;
	private String out_of_st_bnft_cd;
	private String out_of_st_bnft_sta_cd;
	private String curr_rcv_out_of_st_bnft_ind;
	private String rcv_out_of_st_bnft_date;
	private String end_dt;
	private String chg_dt;
	private String fst_name;
	private String first_name;
	private String last_name;
	private int age;



	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public int getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getOut_of_st_bnft_cd() {
		return out_of_st_bnft_cd;
	}
	public void setOut_of_st_bnft_cd(String out_of_st_bnft_cd) {
		this.out_of_st_bnft_cd = out_of_st_bnft_cd;
	}
	public String getOut_of_st_bnft_sta_cd() {
		return out_of_st_bnft_sta_cd;
	}
	public void setOut_of_st_bnft_sta_cd(String out_of_st_bnft_sta_cd) {
		this.out_of_st_bnft_sta_cd = out_of_st_bnft_sta_cd;
	}
	public String getCurr_rcv_out_of_st_bnft_ind() {
		return curr_rcv_out_of_st_bnft_ind;
	}
	public void setCurr_rcv_out_of_st_bnft_ind(String curr_rcv_out_of_st_bnft_ind) {
		this.curr_rcv_out_of_st_bnft_ind = curr_rcv_out_of_st_bnft_ind;
	}
	public String getRcv_out_of_st_bnft_date() {
		return rcv_out_of_st_bnft_date;
	}
	public void setRcv_out_of_st_bnft_date(String rcv_out_of_st_bnft_date) {
		this.rcv_out_of_st_bnft_date = rcv_out_of_st_bnft_date;
	}
	public String getEnd_dt() {
		return end_dt;
	}
	public void setEnd_dt(String end_dt) {
		this.end_dt = end_dt;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getFst_name() {
		return fst_name;
	}
	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

}