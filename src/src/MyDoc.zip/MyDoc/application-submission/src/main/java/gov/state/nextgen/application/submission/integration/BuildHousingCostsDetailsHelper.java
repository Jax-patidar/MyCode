package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_HOU_BILLS;
import gov.state.nextgen.application.submission.view.payload.Expenses;

import java.util.ArrayList;
import java.util.List;

public class BuildHousingCostsDetailsHelper {

    private BuildHousingCostsDetailsHelper() {
    }

    public static List<Expenses> buildHouseExpenses(AggregatedPayload source, int indvSeq) {//NOSONAR

        Expenses expense = null;
        List<Expenses> expenseList = new ArrayList<>();


        try {
            List<CP_APP_IN_HOU_BILLS> houseExpenseList = source.getFinancialExpenseSummaryDetails().getPageCollection().getCP_APP_IN_HOU_BILLS();
            if (houseExpenseList != null && !houseExpenseList.isEmpty()) {
                for (CP_APP_IN_HOU_BILLS houseExpense : houseExpenseList) {
                    if (indvSeq == houseExpense.getIndv_seq_num()) {
                        expense = new Expenses();
                        List<String> typeCatList = BuildIncomeTypeMappingHelper.getExpenseCd(houseExpense.getBill_type());
                        if (!typeCatList.isEmpty()) {
                            expense.setCategoryCode(typeCatList.get(0));
                            if (!ApplicationSubmissionConstants.STR_EMPT.equals(typeCatList.get(1)))
                                expense.setTypeCode(typeCatList.get(1));
                        }
                        String freqCd = houseExpense.getPymt_freq();
                        if (ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
                            expense.setFreqCode(ApplicationSubmissionConstants.FRE_II);
                        } else {
                            expense.setFreqCode(freqCd);
                        }
                        expense.setDollarAmt(houseExpense.getPymt_amt());
                        expense.setOtherDollarAmount(0);
                        expense.setRecipientName(null);
                        expense.setDescription(null);
                        expense.setCareProviderName(null);
                        expense.setCareProviderAddress(null);
                        expense.setHsngExpnHelpInd(false);
                        expense.setHsngHlpFirstName(houseExpense.getJnt_payee_first_name());
                        expense.setHsngHlpLastName(houseExpense.getJnt_payee_last_name());
                        if (houseExpense.getPaid_amt() != null)
                            expense.setHsngHlpAmt(Double.parseDouble(houseExpense.getPaid_amt()));
                        expense.setHsngHlpFreq(houseExpense.getJnt_pymt_freq());
                        expense.setLiheapInd(ApplicationUtil.translateBoolean(houseExpense.getLiheap_resp()));//NOSONAR
                        expense.setWhoWillReimburse(null);
                        expense.setReimburseAmount(0);
                        expense.setNameOfChildren(null);
                        expense.setTaxDeductibleAlimonyPmtInd(false);
                        expense.setOtherDeductableExpenseText(null);

                        expenseList.add(expense);
                    }
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildHousingCostsDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while loading Housing Cost Expense Details - " + e.getMessage());
        }
        return expenseList;
    }
}
