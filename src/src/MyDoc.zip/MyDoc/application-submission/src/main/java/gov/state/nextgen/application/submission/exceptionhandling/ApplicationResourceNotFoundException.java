package gov.state.nextgen.application.submission.exceptionhandling;

@SuppressWarnings("serial")
public class ApplicationResourceNotFoundException extends RuntimeException{

    public ApplicationResourceNotFoundException(String msg){
        super(msg);
    }
}
