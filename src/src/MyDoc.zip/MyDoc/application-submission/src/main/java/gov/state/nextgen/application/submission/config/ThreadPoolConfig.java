package gov.state.nextgen.application.submission.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;

@Configuration
public class ThreadPoolConfig {

	@Value("${thread-pool.app-submission.core-pool-size}")
	private int corePoolSize;
	
	@Value("${thread-pool.app-submission.max-pool-size}")
	private int maxPoolSize;
	
	@Bean(name="appSubmissionThreadPoolTaskExecutor")
	public ThreadPoolTaskExecutor appSubmissionThreadPoolTaskExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setCorePoolSize(corePoolSize);
		threadPoolTaskExecutor.setMaxPoolSize(maxPoolSize);
		threadPoolTaskExecutor.setQueueCapacity(maxPoolSize);
		threadPoolTaskExecutor.setThreadNamePrefix("appSubmissionThreadPoolTaskExecutor-");
		threadPoolTaskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		threadPoolTaskExecutor.setWaitForTasksToCompleteOnShutdown(true);
		threadPoolTaskExecutor.setAllowCoreThreadTimeOut(true);
		threadPoolTaskExecutor.afterPropertiesSet();
		return threadPoolTaskExecutor;
	}
	
	
	
}
