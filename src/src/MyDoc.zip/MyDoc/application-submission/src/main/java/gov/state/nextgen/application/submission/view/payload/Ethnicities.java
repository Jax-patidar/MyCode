package gov.state.nextgen.application.submission.view.payload;

public class Ethnicities {
	
	private Ethnicity ethnicity;

	public Ethnicity getEthnicity() {
		return ethnicity;
	}

	public void setEthnicity(Ethnicity ethnicity) {
		this.ethnicity = ethnicity;
	}

}
