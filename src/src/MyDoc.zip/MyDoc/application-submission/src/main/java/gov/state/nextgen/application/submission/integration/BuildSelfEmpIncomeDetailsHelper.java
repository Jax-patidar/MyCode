package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_SELFE_Collection;
import gov.state.nextgen.application.submission.view.payload.Income;

import java.util.ArrayList;
import java.util.List;

public class BuildSelfEmpIncomeDetailsHelper {
	
	private BuildSelfEmpIncomeDetailsHelper() {}
	
	public static List<Income> buildSelfIncome(AggregatedPayload source, int indvSeq) {//NOSONAR
		Income income = null;
		List<Income> incomeList = new ArrayList<>();
		
		try {
			List<APP_IN_SELFE_Collection> indvSelfIncomeList = source.getFinancialIncomeSummaryDetails().getPageCollection().getaPP_IN_SELFE_Collection();
			
			if(indvSelfIncomeList !=null && !indvSelfIncomeList.isEmpty()) {
				for(APP_IN_SELFE_Collection selfIncome : indvSelfIncomeList ) {
					if(indvSeq == selfIncome.getIndv_seq_num()) {
					income = new Income();
					double amt = selfIncome.getAvg_incm_amt();
					income.setAmount(amt);
					String freqCd = selfIncome.getPay_freq();
					if(ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
						income.setFrequency(ApplicationSubmissionConstants.FRE_II);
					} else {
						income.setFrequency(freqCd);
					}
					income.setTypeCode(ApplicationSubmissionConstants.STR_27);
					income.setSourceName(selfIncome.getSelf_empl_bus_nam());
					income.setBeginDate(selfIncome.getEff_begin_dt());
					income.setContinueToReceiveIncomeInd(ApplicationUtil.translateBoolean(selfIncome.getExpected_to_cont_resp()));//NOSONAR
					
					incomeList.add(income);
					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildSelfEmpIncomeDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while buildSelfIncome::" + e.getMessage());
		}
		return incomeList;
	}


}
