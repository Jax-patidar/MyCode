package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class CP_APP_IMMED_CASH_Collection {
	
	private String immed_cash_id;
	private int indv_seq_num;
	private String child_abuse;
	private String domestic_abuse;
	private String elser_abuse;
	private String emerg_desc;
	private String essential_clothing;
	private String eviction_notice;
	private String food_run_out;
	private String medical_leave;
	private String other_emergency;
	private String preg;
	private String transport_help;
	private String util_shut_off;
	private String other_emergency_explain;
	public String getImmed_cash_id() {
		return immed_cash_id;
	}
	public void setImmed_cash_id(String immed_cash_id) {
		this.immed_cash_id = immed_cash_id;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getChild_abuse() {
		return child_abuse;
	}
	public void setChild_abuse(String child_abuse) {
		this.child_abuse = child_abuse;
	}
	public String getDomestic_abuse() {
		return domestic_abuse;
	}
	public void setDomestic_abuse(String domestic_abuse) {
		this.domestic_abuse = domestic_abuse;
	}
	public String getElser_abuse() {
		return elser_abuse;
	}
	public void setElser_abuse(String elser_abuse) {
		this.elser_abuse = elser_abuse;
	}
	public String getEmerg_desc() {
		return emerg_desc;
	}
	public void setEmerg_desc(String emerg_desc) {
		this.emerg_desc = emerg_desc;
	}
	public String getEssential_clothing() {
		return essential_clothing;
	}
	public void setEssential_clothing(String essential_clothing) {
		this.essential_clothing = essential_clothing;
	}
	public String getEviction_notice() {
		return eviction_notice;
	}
	public void setEviction_notice(String eviction_notice) {
		this.eviction_notice = eviction_notice;
	}
	public String getFood_run_out() {
		return food_run_out;
	}
	public void setFood_run_out(String food_run_out) {
		this.food_run_out = food_run_out;
	}
	public String getMedical_leave() {
		return medical_leave;
	}
	public void setMedical_leave(String medical_leave) {
		this.medical_leave = medical_leave;
	}
	public String getOther_emergency() {
		return other_emergency;
	}
	public void setOther_emergency(String other_emergency) {
		this.other_emergency = other_emergency;
	}
	public String getPreg() {
		return preg;
	}
	public void setPreg(String preg) {
		this.preg = preg;
	}
	public String getTransport_help() {
		return transport_help;
	}
	public void setTransport_help(String transport_help) {
		this.transport_help = transport_help;
	}
	public String getUtil_shut_off() {
		return util_shut_off;
	}
	public void setUtil_shut_off(String util_shut_off) {
		this.util_shut_off = util_shut_off;
	}
	public String getOther_emergency_explain() {
		return other_emergency_explain;
	}
	public void setOther_emergency_explain(String other_emergency_explain) {
		this.other_emergency_explain = other_emergency_explain;
	}

}
