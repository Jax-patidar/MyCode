package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;



public class PageCollection {
	
	@JsonDeserialize(contentAs = APP_IN_LQD_ASET_Collection.class)
	private List<APP_IN_LQD_ASET_Collection> APP_IN_LQD_ASET_Collection;

	@JsonDeserialize(contentAs = APP_IN_VEH_ASET_Collection.class)
	private List<APP_IN_VEH_ASET_Collection> APP_IN_VEH_ASET_Collection;

	@JsonDeserialize(contentAs = APP_IN_P_PROP_ASET_Collection.class)
	private List<APP_IN_P_PROP_ASET_Collection> APP_IN_P_PROP_ASET_Collection;
	
	@JsonDeserialize(contentAs = APP_IN_R_PROP_ASET_Collection.class)
	private List<APP_IN_R_PROP_ASET_Collection> APP_IN_R_PROP_ASET_Collection;

	@JsonDeserialize(contentAs = CP_APP_IN_ASET_XFER_Collection.class)
	private List<CP_APP_IN_ASET_XFER_Collection> CP_APP_IN_ASET_XFER_Collection;

	public List<APP_IN_LQD_ASET_Collection> getAPP_IN_LQD_ASET_Collection() {
		return APP_IN_LQD_ASET_Collection;
	}

	public void setAPP_IN_LQD_ASET_Collection(List<APP_IN_LQD_ASET_Collection> aPP_IN_LQD_ASET_Collection) {
		APP_IN_LQD_ASET_Collection = aPP_IN_LQD_ASET_Collection;
	}

	public List<APP_IN_VEH_ASET_Collection> getAPP_IN_VEH_ASET_Collection() {
		return APP_IN_VEH_ASET_Collection;
	}

	public void setAPP_IN_VEH_ASET_Collection(List<APP_IN_VEH_ASET_Collection> aPP_IN_VEH_ASET_Collection) {
		APP_IN_VEH_ASET_Collection = aPP_IN_VEH_ASET_Collection;
	}

	public List<APP_IN_P_PROP_ASET_Collection> getAPP_IN_P_PROP_ASET_Collection() {
		return APP_IN_P_PROP_ASET_Collection;
	}

	public void setAPP_IN_P_PROP_ASET_Collection(List<APP_IN_P_PROP_ASET_Collection> aPP_IN_P_PROP_ASET_Collection) {
		APP_IN_P_PROP_ASET_Collection = aPP_IN_P_PROP_ASET_Collection;
	}

	public List<APP_IN_R_PROP_ASET_Collection> getAPP_IN_R_PROP_ASET_Collection() {
		return APP_IN_R_PROP_ASET_Collection;
	}

	public void setAPP_IN_R_PROP_ASET_Collection(List<APP_IN_R_PROP_ASET_Collection> aPP_IN_R_PROP_ASET_Collection) {
		APP_IN_R_PROP_ASET_Collection = aPP_IN_R_PROP_ASET_Collection;
	}

	public List<CP_APP_IN_ASET_XFER_Collection> getCP_APP_IN_ASET_XFER_Collection() {
		return CP_APP_IN_ASET_XFER_Collection;
	}

	public void setCP_APP_IN_ASET_XFER_Collection(List<CP_APP_IN_ASET_XFER_Collection> cP_APP_IN_ASET_XFER_Collection) {
		CP_APP_IN_ASET_XFER_Collection = cP_APP_IN_ASET_XFER_Collection;
	}
	
	
	

}
