package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class MedicalCondition {
	@JsonIgnore
	private String typeCode;
	@JsonIgnore
	private boolean accidentInd;
	@JsonIgnore
	private String startDate;
	@JsonIgnore
	private String endDate;

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public boolean isAccidentInd() {
		return accidentInd;
	}

	public void setAccidentInd(boolean accidentInd) {
		this.accidentInd = accidentInd;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
}
