package gov.state.nextgen.application.submission.handler;

import com.amazonaws.serverless.exceptions.ContainerInitializationException;
import com.amazonaws.serverless.proxy.internal.LambdaContainerHandler;
import com.amazonaws.serverless.proxy.internal.testutils.Timer;
import com.amazonaws.serverless.proxy.model.*;
import com.amazonaws.serverless.proxy.spring.SpringBootLambdaContainerHandler;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.joda.JodaModule;
import gov.state.nextgen.application.submission.ApplicationSubmissionLambdaApplication;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.framework.logging.FwLogger.Level;

import org.apache.commons.io.IOUtils;
import org.slf4j.MDC;
import org.springframework.http.MediaType;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 *
 */
public class ApplicationSubmissionLambdaHandler implements RequestStreamHandler {

    private static SpringBootLambdaContainerHandler<AwsProxyRequest, AwsProxyResponse> handler;
    private static final String USERID = "userId";
	private static final String XAUTHID = "x-auth-id";
	private static final String TRANSACTIONIDLOG = "transactionIdentifier";
    static {
        try {
            handler = SpringBootLambdaContainerHandler.getAwsProxyHandler(ApplicationSubmissionLambdaApplication.class);
        } catch (ContainerInitializationException e) {
            throw new RuntimeException("Spring Boot initialization failed due to::", e); //NOSONAR
        }
    }

    public ApplicationSubmissionLambdaHandler() {
		 // we enable the timer for debugging. This SHOULD NOT be enabled in production.
		 LambdaContainerHandler.getContainerConfig().setDefaultContentCharset("UTF-8");
		 Timer.enable();
	 }
    
    @Override
    @SuppressWarnings("unchecked")
    public void handleRequest(InputStream inputStream, OutputStream outputStream, Context context) throws IOException {//NOSONAR
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        IOUtils.copy(inputStream, bos);
        String event = bos.toString(LambdaContainerHandler.getContainerConfig().getDefaultContentCharset());
        ObjectMapper mapper = LambdaContainerHandler.getObjectMapper();
        mapper.registerModule(new JodaModule());
        AwsProxyRequest request = mapper.readValue(event, AwsProxyRequest.class);
        setUserIdInToLogs(request);
		MDC.put(TRANSACTIONIDLOG,context.getAwsRequestId());
        if (request.getHttpMethod() == null || "".equals(request.getHttpMethod())) {
            FwLogger.log(ApplicationSubmissionLambdaHandler.class, FwLogger.Level.INFO, "Parsing AWS event - " + event);
            Map<String, Object> raw = (Map<String, Object>) mapper.readValue(event, Map.class);

            // Peek inside one event
            if (raw.get("Records") instanceof List) {
                List<Map<String, Object>> events = (List<Map<String, Object>>) raw.get("Records");
                if (!events.isEmpty()) {
                    raw = events.get(0);
                } else {
                    FwLogger.log(ApplicationSubmissionLambdaHandler.class, FwLogger.Level.WARN, "Empty, dummy event records - " + events);
                }
            }

            String eventSource = (String) raw.get("source"); // CloudWatch event
            if (eventSource == null) {
                eventSource = (String) raw.get("EventSource"); // SNS
            }
            if (eventSource == null) {
                eventSource = (String) raw.get("eventSource"); // SQS!?!
            }

            if (eventSource == null) {
                FwLogger.log(ApplicationSubmissionLambdaHandler.class, FwLogger.Level.WARN, "Can`t get event type:: - " + raw);
                request = convertToRequest(raw, event, String.class.getName(), context);
                FwLogger.log(ApplicationSubmissionLambdaHandler.class, FwLogger.Level.INFO, "Converted to {} - " + request);
                AwsProxyResponse response = handler.proxy(request, context);
                FwLogger.log(ApplicationSubmissionLambdaHandler.class, FwLogger.Level.INFO, "Response via Spring Boot rest APIs - " + response);
                mapper.writeValue(outputStream, response);
            } else {
                FwLogger.log(ApplicationSubmissionLambdaHandler.class, FwLogger.Level.WARN, "\"Unhandled event type:: - " + eventSource);
            }
        } else {
            FwLogger.log(ApplicationSubmissionLambdaHandler.class, FwLogger.Level.INFO, "Handling via Spring Boot rest APIs - " + request);
            AwsProxyResponse response = handler.proxy(request, context);
            mapper.writeValue(outputStream, response);
        }
        MDC.clear();
    }


    /**
     * Delivers all event to POST /event?type=className
     */
    public static AwsProxyRequest convertToRequest(Object ev, String json, String className, Context context) {//NOSONAR
        AwsProxyRequest r = new AwsProxyRequest();
        r.setPath("/event");
        r.setResource("/event");
        r.setHttpMethod("POST");
        MultiValuedTreeMap<String, String> q = new MultiValuedTreeMap<>();
        q.putSingle("type", className);
        r.setBody(json);
        r.setMultiValueQueryStringParameters(q);
        Headers h = new Headers();
        h.putSingle("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        r.setMultiValueHeaders(h);
       
        AwsProxyRequestContext rc = new AwsProxyRequestContext();
        rc.setIdentity(new ApiGatewayRequestIdentity());
        r.setRequestContext(rc);
        return r;
    }
    private void setUserIdInToLogs(AwsProxyRequest request)
    {
    	if(!Objects.nonNull(request))
    	{
    		return;
    	}
	    Headers requestHeaders = request.getMultiValueHeaders();
	    if(Objects.nonNull(requestHeaders) && requestHeaders.containsKey(XAUTHID))
           {
	    		   List<String> xAuthIdList = requestHeaders.get(XAUTHID);
	               if(Objects.nonNull(xAuthIdList) && !xAuthIdList.isEmpty())
	               {
	                    String xAuthId = xAuthIdList.get(0);
	                    MDC.put(USERID,xAuthId);
	               }
           }
	    else
	    	{
	    		FwLogger.log(ApplicationSubmissionLambdaHandler.class, Level.INFO,  "ApplicationSubmissionLambdaHandler:: setUserIdInToLogs - Headers does not have "+XAUTHID);
	    	}
    }

}