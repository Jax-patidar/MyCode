package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class AdditionalServices {

	private Boolean moreInfo;
	private Boolean medicalServices;
	private Boolean dentalServices;
	private Boolean medServiceAppointment;
	private Boolean dentalAppointment;
	private Boolean medServiceTransportation;
	private Boolean dentalTransportation;
	private Boolean transportation;
	private Boolean immunization;
	private Boolean pregnant;
	private Boolean breastFeeding;
	private Boolean recentBirth;
	private Boolean familyPlanning;
	private Boolean otherHelp;
	private Boolean childHealthDisabilityPrvntInd;

	public Boolean isMoreInfo() {
		return moreInfo;
	}

	public void setMoreInfo(Boolean moreInfo) {
		this.moreInfo = moreInfo;
	}

	public Boolean isMedicalServices() {
		return medicalServices;
	}

	public void setMedicalServices(Boolean medicalServices) {
		this.medicalServices = medicalServices;
	}

	public Boolean isDentalServices() {
		return dentalServices;
	}

	public void setDentalServices(Boolean dentalServices) {
		this.dentalServices = dentalServices;
	}

	public Boolean isMedServiceAppointment() {
		return medServiceAppointment;
	}

	public void setMedServiceAppointment(Boolean medServiceAppointment) {
		this.medServiceAppointment = medServiceAppointment;
	}

	public Boolean isDentalAppointment() {
		return dentalAppointment;
	}

	public void setDentalAppointment(Boolean dentalAppointment) {
		this.dentalAppointment = dentalAppointment;
	}

	public Boolean isMedServiceTransportation() {
		return medServiceTransportation;
	}

	public void setMedServiceTransportation(Boolean medServiceTransportation) {
		this.medServiceTransportation = medServiceTransportation;
	}

	public Boolean isDentalTransportation() {
		return dentalTransportation;
	}

	public void setDentalTransportation(Boolean dentalTransportation) {
		this.dentalTransportation = dentalTransportation;
	}

	public Boolean isTransportation() {
		return transportation;
	}

	public void setTransportation(Boolean transportation) {
		this.transportation = transportation;
	}

	public Boolean isImmunization() {
		return immunization;
	}

	public void setImmunization(Boolean immunization) {
		this.immunization = immunization;
	}

	public Boolean isPregnant() {
		return pregnant;
	}

	public void setPregnant(Boolean pregnant) {
		this.pregnant = pregnant;
	}

	public Boolean isBreastFeeding() {
		return breastFeeding;
	}

	public void setBreastFeeding(Boolean breastFeeding) {
		this.breastFeeding = breastFeeding;
	}

	public Boolean isRecentBirth() {
		return recentBirth;
	}

	public void setRecentBirth(Boolean recentBirth) {
		this.recentBirth = recentBirth;
	}

	public Boolean isFamilyPlanning() {
		return familyPlanning;
	}

	public void setFamilyPlanning(Boolean familyPlanning) {
		this.familyPlanning = familyPlanning;
	}

	public Boolean isOtherHelp() {
		return otherHelp;
	}

	public void setOtherHelp(Boolean otherHelp) {
		this.otherHelp = otherHelp;
	}

	public Boolean isChildHealthDisabilityPrvntInd() {
		return childHealthDisabilityPrvntInd;
	}

	public void setChildHealthDisabilityPrvntInd(Boolean childHealthDisabilityPrvntInd) {
		this.childHealthDisabilityPrvntInd = childHealthDisabilityPrvntInd;
	}
}
