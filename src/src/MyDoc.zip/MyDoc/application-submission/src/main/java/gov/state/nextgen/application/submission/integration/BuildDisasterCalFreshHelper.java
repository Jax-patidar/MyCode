package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.CP_ASSETS_DISASTER_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_EXPENSE_DISASTER_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.CP_INCOME_DISASTER_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.*;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.CP_OTHER_DETAILS_DISASTER_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.CP_REPLACEMENT_DISASTER_Collection;
import gov.state.nextgen.application.submission.view.payload.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@SuppressWarnings("squid:S1126")
public class BuildDisasterCalFreshHelper {
    private BuildDisasterCalFreshHelper() {
    }

    @SuppressWarnings({"squid:S2159","squid:S3776"})
    public static ApplicationSubmissionPayload buildApplicant(AggregatedPayload source) {
        final ApplicationSubmissionPayload target = new ApplicationSubmissionPayload();

        final DisasterCalFresh disasterCalFresh = new DisasterCalFresh();
        final CalFreshAuthRep calFreshAuthRep = new CalFreshAuthRep();
        final PhoneNumber phoneNumber = new PhoneNumber();
        final Address address = new Address();
        final Applicant primaryApplicant = new Applicant();
        List<Applicant> otherApplicantsList = new ArrayList<>();
        List<Relationship> relationships = new ArrayList<>();
        List<Expenses> disasterExpenseList = new ArrayList<>();

        List<CP_HSHL_DETAILS_DISASTER_Collection> hshlDetailsDisasterList = source.getDisasterAppHHSRespDetails().getPageCollection().getCP_HSHL_DETAILS_DISASTER_Collection();
        List<CP_APP_AUTH_REP_Collection> authRepList = source.getDisasterAppHHSRespDetails().getPageCollection().getCP_APP_AUTH_REP_Collection();
        List<CP_APP_RGST_Collection> rgstList = source.getDisasterAppHHSRespDetails().getPageCollection().getCP_APP_RGST_Collection();
        List<APP_INDV_Collection> indvList = source.getDisasterAppHHSRespDetails().getPageCollection().getAPP_INDV_Collection();
        List<CP_APP_HSHL_RLT_Collection> hshlRlt = source.getDisasterAppHHSRespDetails().getPageCollection().getCP_APP_HSHL_RLT_Collection();
        List<CP_INCOME_DISASTER_Collection> incomeDstrList = source.getDisasterAppFISRespDetails().getPageCollection().getCP_INCOME_DISASTER_Collection();
        List<CP_ASSETS_DISASTER_Collection> assetsDstrList = source.getDisasterAppFISRespDetails().getPageCollection().getCP_ASSETS_DISASTER_Collection();
        List<CP_EXPENSE_DISASTER_Collection> expenseDstrList = source.getDisasterAppFISRespDetails().getPageCollection().getCP_EXPENSE_DISASTER_Collection();
        List<CP_OTHER_DETAILS_DISASTER_Collection> otherDtlsDstlList = source.getDisasterAppNFSRespDetails().getPageCollection().getCP_OTHER_DETAILS_DISASTER_Collection();
        List<CP_REPLACEMENT_DISASTER_Collection> replaceDstrList = source.getDisasterAppNFSRespDetails().getPageCollection().getCP_REPLACEMENT_DISASTER_Collection();
        List<APP_SBMS_Collection> appSMBSList = source.getDisasterAppHHSRespDetails().getPageCollection().getAPP_SBMS_Collection();

        CP_OTHER_DETAILS_DISASTER_Collection primaryAppLicantOtherDetails = null;
        CP_APP_RGST_Collection tempColl = null;
        
        if (otherDtlsDstlList != null) {
            otherDtlsDstlList.stream().forEach(i -> {
                if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(i.getCf_ind())) {
                    disasterCalFresh.setGettingCalFreshBenefits(true);
                } else {
                    disasterCalFresh.setGettingCalFreshBenefits(false);
                }
                //disasterCalFresh.setG
            });
        }
        
        if (otherDtlsDstlList != null && !otherDtlsDstlList.isEmpty()) {
            primaryAppLicantOtherDetails = otherDtlsDstlList.stream().filter(indv -> ApplicationSubmissionConstants.STR_1.equalsIgnoreCase(indv.getIndv_seq_num())).findFirst().orElse(null);
            otherDtlsDstlList = otherDtlsDstlList.stream().filter(indv -> !ApplicationSubmissionConstants.STR_1.equalsIgnoreCase(indv.getIndv_seq_num())).collect(Collectors.toList());
        }
        if (hshlDetailsDisasterList != null && !hshlDetailsDisasterList.isEmpty()) {
            hshlDetailsDisasterList.stream().forEach(i -> {

                if (ApplicationSubmissionConstants.STR_1.equals(i.getLived_ind())) {
                    disasterCalFresh.setLivedIndisasterArea(true);
                } else if(ApplicationSubmissionConstants.STR_0.equals(i.getLived_ind())){
                    disasterCalFresh.setLivedIndisasterArea(false);
                }else {
                	disasterCalFresh.setLivedIndisasterArea(null);
                }

                if (ApplicationSubmissionConstants.STR_1.equals(i.getWorked_ind())) {
                    disasterCalFresh.setWorkedIndisasterArea(true);
                } else if(ApplicationSubmissionConstants.STR_0.equals(i.getWorked_ind())){
                    disasterCalFresh.setWorkedIndisasterArea(false);
                }else {
                	disasterCalFresh.setWorkedIndisasterArea(null);
                }

                if (ApplicationSubmissionConstants.STR_1.equals(i.getNo_income_ind())) {
                    disasterCalFresh.setUnableToGetIncome(true);
                } else if(ApplicationSubmissionConstants.STR_0.equals(i.getNo_income_ind())){
                    disasterCalFresh.setUnableToGetIncome(false);
                } else {
                	disasterCalFresh.setUnableToGetIncome(null);
                }

                if (ApplicationSubmissionConstants.STR_1.equals(i.getDelayed_stop_income())) {
                    disasterCalFresh.setLoweredIncome(true);
                } else if(ApplicationSubmissionConstants.STR_0.equals(i.getDelayed_stop_income())){
                    disasterCalFresh.setLoweredIncome(false);
                } else {
                	disasterCalFresh.setLoweredIncome(null);
                }

                if (ApplicationSubmissionConstants.STR_1.equals(i.getBought_prepared_meal())) {
                    disasterCalFresh.setBuyAndPrepareMeals(true);
                } else if(ApplicationSubmissionConstants.STR_0.equals(i.getBought_prepared_meal())){
                    disasterCalFresh.setBuyAndPrepareMeals(false);
                } else {
                	disasterCalFresh.setBuyAndPrepareMeals(null);
                }
                
                //-BCUAT-2986 Changes made as per the Jira ticket
                if (ApplicationSubmissionConstants.STR_1.equals(i.getEmployed_county_ssd())) {
                    disasterCalFresh.setEmployedbyStateAgency(true);
                    disasterCalFresh.setEmployedbyWhichStateAgency(ApplicationSubmissionConstants.STR_CA);
                } else if(ApplicationSubmissionConstants.STR_0.equals(i.getEmployed_county_ssd())){
                    disasterCalFresh.setEmployedbyStateAgency(false);
                }else {
                	disasterCalFresh.setEmployedbyStateAgency(null);
                }
                //disasterCalFresh.setEmployedbyWhichStateAgency(i.getEmployed_county_ssd());
            });
        }
        if (authRepList != null && !authRepList.isEmpty()) {
            authRepList.stream().forEach(i -> {
                calFreshAuthRep.setFirstName(i.getAuth_rep_fst_nam());
                calFreshAuthRep.setLastName(i.getAuth_rep_last_nam());

                if (i.getPhn_num() != null && !ApplicationSubmissionConstants.EMP_TYPE.endsWith(i.getPhn_num())) {
                    phoneNumber.setNumber(i.getPhn_num());
                    phoneNumber.setType(ApplicationSubmissionConstants.STR_WK);
                    calFreshAuthRep.setPhoneNumber(phoneNumber);
                }

                if ((i.getL1_adr() != null && !ApplicationSubmissionConstants.EMP_TYPE.endsWith(i.getL1_adr()))
                        || (i.getL2_adr() != null && !ApplicationSubmissionConstants.EMP_TYPE.endsWith(i.getL2_adr()))) {
                    address.setStreetAddr1(i.getL1_adr());
                    address.setStreetAddr2(i.getL2_adr());
                    address.setCityName(i.getCity_adr());
                    address.setState(i.getSta_adr());
                    address.setZipCode(i.getZip_adr());
                    calFreshAuthRep.setAddress(address);
                }

                if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(i.getEbt_card_pick())) {
                    calFreshAuthRep.setPickupEBTCard(true);
                } else if(ApplicationSubmissionConstants.STR_N.equalsIgnoreCase(i.getEbt_card_pick())){
                    calFreshAuthRep.setPickupEBTCard(false);
                } else {
                	calFreshAuthRep.setPickupEBTCard(null);
                }


                if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(i.getPurchase_food())) {
                    calFreshAuthRep.setPickupEBTToPurchaseFood(true);
                } else if (ApplicationSubmissionConstants.STR_N.equalsIgnoreCase(i.getPurchase_food())){
                    calFreshAuthRep.setPickupEBTToPurchaseFood(false);
                } else {
                	calFreshAuthRep.setPickupEBTToPurchaseFood(null);
                }
            });
        }

        List<Address> addressess = new ArrayList<>();

        if (rgstList != null && !rgstList.isEmpty()) {
            for (CP_APP_RGST_Collection rgstCollectionList : rgstList) {
                if (rgstCollectionList != null && rgstCollectionList.getIndv_seq_num() == 1) {
                    tempColl = rgstCollectionList;
                }
                Address rgstAddress = new Address();
                //Address tempAddress = new Address();
                Address mailAddress = new Address();
                //Address workAddress = new Address();

                rgstAddress.setStreetAddr1(rgstCollectionList.getHshl_l1_adr());
                rgstAddress.setStreetAddr2(rgstCollectionList.getHshl_l2_adr());
                rgstAddress.setCityName(rgstCollectionList.getHshl_city_adr());
                rgstAddress.setZipCode(rgstCollectionList.getHshl_zip_adr());
                rgstAddress.setState(rgstCollectionList.getHshl_sta_adr());
                rgstAddress.setAddrType(ApplicationSubmissionConstants.STR_PH);
				
				/*tempAddress.setStreetAddr1(rgstCollectionList.getTemp_street_address());
				tempAddress.setStreetAddr2(rgstCollectionList.getTemp_l2_address());
				tempAddress.setCityName(rgstCollectionList.getTemp_city_address());
				tempAddress.setZipCode(rgstCollectionList.getTemp_zip_address());
				tempAddress.setState(rgstCollectionList.getTemp_state_address());*/
                
                if(Objects.nonNull(rgstCollectionList.getAlt_st_adr()) && 
                		!ApplicationSubmissionConstants.STR_EMPT.equals(rgstCollectionList.getAlt_st_adr().trim())) {
                	mailAddress.setStreetAddr1(rgstCollectionList.getAlt_st_adr());
                    mailAddress.setStreetAddr2(rgstCollectionList.getAlt_l2_adr());
                    mailAddress.setCityName(rgstCollectionList.getAlt_city_adr());
                    mailAddress.setZipCode(rgstCollectionList.getAlt_zip_adr());
                    mailAddress.setState(rgstCollectionList.getAlt_sta_adr());
                    mailAddress.setAddrType(ApplicationSubmissionConstants.STR_ML);
                    addressess.add(mailAddress);
                }
				
				/*workAddress.setStreetAddr1(rgstCollectionList.getWork_street_address());
				workAddress.setStreetAddr2(rgstCollectionList.getWork_l2_address());
				workAddress.setCityName(rgstCollectionList.getWork_city_address());
				workAddress.setZipCode(rgstCollectionList.getWork_zip_address());
				workAddress.setState(rgstCollectionList.getWork_state_address());*/

                addressess.add(rgstAddress);
                //addressess.add(tempAddress);
                //addressess.add(workAddress);

            }
            primaryApplicant.setAddressess(addressess);
        }


        if (primaryAppLicantOtherDetails != null) {
            primaryApplicant.setCalFreshBenefitsState(primaryAppLicantOtherDetails.getState_cd());
            primaryApplicant.setCalFreshMonthlyAllotment(primaryAppLicantOtherDetails.getReceived_amt());
            primaryApplicant.setGetsCalFreshBenefitsInd(ApplicationUtil.translateBoolean(primaryAppLicantOtherDetails.getCf_ind()));
        }
        if (indvList != null && !indvList.isEmpty()) {
        	//Set Unique Id Map for every Individual in an Household
            Map<Integer, Integer> benefitsCalIndividualIdMap = new HashMap<Integer, Integer>();
            for(APP_INDV_Collection appIndvCargo: indvList) {
            	if(appIndvCargo != null && appIndvCargo.getIndv_seq_num() != 0) {
            		benefitsCalIndividualIdMap.put(appIndvCargo.getIndv_seq_num(), appIndvCargo.getBenefitsCalIndividualId());
            	}
            }
            ApplicationUtil.setBenefitsCalIndividualIdMapValues(benefitsCalIndividualIdMap);
        	
            for (APP_INDV_Collection indv : indvList) {
                if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(indv.getPrim_prsn_sw())) {
                    getApplicantDetails(primaryApplicant, indv);
                    primaryApplicant.setPrimaryApplicantInd(true);
                } else {
                    Applicant otherApplicant = new Applicant();
                    otherApplicant.setPrimaryApplicantInd(false);
                    otherApplicant = getApplicantDetails(otherApplicant, indv);
                    if (otherDtlsDstlList != null) {
                        for (CP_OTHER_DETAILS_DISASTER_Collection otherAppcntDtlList : otherDtlsDstlList) {
                            if (otherAppcntDtlList.getIndv_seq_num().equals(String.valueOf(indv.getIndv_seq_num()))) {
                                otherApplicant.setCalFreshBenefitsState(otherAppcntDtlList.getState_cd());
                                otherApplicant.setCalFreshMonthlyAllotment(otherAppcntDtlList.getReceived_amt());
                                otherApplicant.setGetsCalFreshBenefitsInd(ApplicationUtil.translateBoolean(otherAppcntDtlList.getCf_ind())); 
                            }
                        }
                    }
                    otherApplicantsList.add(otherApplicant);
                }
            }
        }

        if (hshlRlt != null && !hshlRlt.isEmpty()) {
            hshlRlt.stream().forEach(i -> {
                Relationship rltnShip = new Relationship();
                if (Objects.nonNull(ApplicationUtil.getBenefitsCalIndividualIdValue(i.getSrc_indv_seq_num()))) {
                	rltnShip.setPersID(ApplicationUtil.getBenefitsCalIndividualIdValue(i.getSrc_indv_seq_num()));
                } else {
                	rltnShip.setPersID(i.getSrc_indv_seq_num());
                }
                if (Objects.nonNull(ApplicationUtil.getBenefitsCalIndividualIdValue(i.getSrc_indv_seq_num()))) {
                	rltnShip.setPers2ID(ApplicationUtil.getBenefitsCalIndividualIdValue(i.getRef_indv_seq_num()));
                } else {
                	rltnShip.setPers2ID(i.getRef_indv_seq_num());
                }
                if (Objects.nonNull(i.getRlt_cd())) {
                    rltnShip.setTypeCode(BuildIncomeTypeMappingHelper.getRelationType(i.getRlt_cd()));
                }
                relationships.add(rltnShip);
            });
        }

        if (incomeDstrList != null && !incomeDstrList.isEmpty()) {
            incomeDstrList.stream().forEach(i -> {
                disasterCalFresh.setTotalIncome(i.getIncome_amt());
                disasterCalFresh.setIncomeSources(i.getAdditional_info());
            });
        }

        if (assetsDstrList != null && !assetsDstrList.isEmpty()) {
            assetsDstrList.stream().forEach(i -> {
                disasterCalFresh.setSavingAccounts(i.getSaving_account_amt());
                disasterCalFresh.setCheckingAccounts(i.getChecking_account_amt());
                disasterCalFresh.setOther(i.getOther_amt());
                disasterCalFresh.setCashOnHand(i.getCash_in_hand_amt());
            });
        }

        if (expenseDstrList != null && !expenseDstrList.isEmpty()) {
            expenseDstrList.stream().forEach(i -> {
                Expenses disasterExpense = new Expenses();
                disasterExpense.setTypeCode(i.getExp_type());
                disasterExpense.setDollarAmt(i.getExp_amt());
                disasterExpenseList.add(disasterExpense);
            });
            disasterCalFresh.setDisasterExpense(disasterExpenseList);
        }

        

        if (replaceDstrList != null && !replaceDstrList.isEmpty()) {
            replaceDstrList.stream().forEach(i -> {
                if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(i.getReplacement_cf_ind())) {
                    disasterCalFresh.setReplaceBenefitsInd(true);
                    disasterCalFresh.setReplaceBenefitsAmount(i.getReplacement_amnt());
                } else {
                    disasterCalFresh.setReplaceBenefitsInd(false);
                }

            });
        }


        //TODO - Set the actual identifier
        target.setOfficeIdentif("ZZ");
        if (appSMBSList != null && !appSMBSList.isEmpty()) {
            target.setAppNumber(appSMBSList.get(0).getApp_num());
            //set Application Submit Date
            if (appSMBSList.get(0).getSbmsDt() != null) {
            	 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
    			 String formattedAppSubmitDate = dateFormat.format(appSMBSList.get(0).getSbmsDt());
    			 target.setAppSubmissionDate(formattedAppSubmitDate);
            }
            target.setSignDate(appSMBSList.get(0).getApplicant_sign_dt());
            target.setUserAgency(appSMBSList.get(0).getOrg_user_agency_name());
            String officeId = appSMBSList.get(0).getOffice_id();
            if (officeId != null)
                target.setOfficeIdentif(officeId);
        } else {
            target.setAppNumber(source.getAppNumber());
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern(ApplicationSubmissionConstants.YYYY_MM_DD);
            LocalDate date = LocalDate.now();
            target.setSignDate(date.format(dateFormat));
            target.setOfficeIdentif("ZZ");
        }
        target.setDsnapInd(true);
        //target.setAppNumber(source.getAppNumber());

        target.setDisasterCalFresh(disasterCalFresh);
        target.setCalFreshAuthRep(calFreshAuthRep);
        target.setPrimaryApplicant(primaryApplicant);
        target.setOtherApplicants(otherApplicantsList);
        target.setRelationships(relationships);
        if (tempColl != null) {
            target.setCountyCode(tempColl.getCnty_num());
        }
        return target;
    }

    public static Applicant getApplicantDetails(Applicant applicant, APP_INDV_Collection appIndv) {
        applicant.setFirstName(appIndv.getFst_nam());
        applicant.setMiddleName(appIndv.getMid_init());
        applicant.setLastName(appIndv.getLast_nam());
        applicant.setSuffix(appIndv.getSuffix_name());
        applicant.setAliasFirstName(appIndv.getAlias_fst_nam());
        applicant.setAliasLastName(appIndv.getAlias_last_nam());
        applicant.setAliasMiddleName(appIndv.getAlias_mid_nam());
        if (Objects.nonNull(appIndv.getSsn_num()) && !appIndv.getSsn_num().isBlank() &&
        		!ApplicationSubmissionConstants.STR_ZERO.equalsIgnoreCase(appIndv.getSsn_num())) {
        	applicant.setSsn(appIndv.getSsn_num());
        }
        applicant.setDob(appIndv.getBrth_dt());
        applicant.setId(appIndv.getIndv_seq_num());
        Integer idVal = ApplicationUtil.getBenefitsCalIndividualIdValue(appIndv.getIndv_seq_num());
        if (idVal != null)
        	applicant.setId(idVal.intValue());        
        List<String> programList = new ArrayList<String>();
        programList.add(ApplicationSubmissionConstants.DISASTERCAL_PGMCODE_DC);
        applicant.setProgram(programList);

        return applicant;
    }

}
