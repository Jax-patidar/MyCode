package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class TaxDependent {
	private int persId;
	private String type;
	private String dependentFirstName;
	private String dependentlastName;

	public int getPersId() {
		return persId;
	}

	public void setPersId(int persId) {
		this.persId = persId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDependentFirstName() {
		return dependentFirstName;
	}

	public void setDependentFirstName(String dependentFirstName) {
		this.dependentFirstName = dependentFirstName;
	}

	public String getDependentlastName() {
		return dependentlastName;
	}

	public void setDependentlastName(String dependentlastName) {
		this.dependentlastName = dependentlastName;
	}
}
