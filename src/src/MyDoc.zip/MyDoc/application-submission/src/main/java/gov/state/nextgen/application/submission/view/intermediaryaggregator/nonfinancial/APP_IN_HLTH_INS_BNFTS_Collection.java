package gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial;

public class APP_IN_HLTH_INS_BNFTS_Collection {

	private String user;
    private String cargoName;
    private String rowAction;
    private String adaptRecordId;
    private String delete_reason_cd;
    private String app_num;
    private int indv_seq_num;
    private int seq_num;
    private String src_app_ind;
    private String hlth_cvrg_type;
    private String plcy_hold_fst_nam;
    private String plcy_hold_last_nam;
    private String cov_ca_ind;
    private String cov_ca_case_num;
    private String looping_ind;
    private String rec_cplt_ind;
    private String ecp_id;
    private String hlt_end_dt;
    private String chg_dt;
    private String lst_dy_health_dt;
    
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public int getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getHlth_cvrg_type() {
		return hlth_cvrg_type;
	}
	public void setHlth_cvrg_type(String hlth_cvrg_type) {
		this.hlth_cvrg_type = hlth_cvrg_type;
	}
	public String getPlcy_hold_fst_nam() {
		return plcy_hold_fst_nam;
	}
	public void setPlcy_hold_fst_nam(String plcy_hold_fst_nam) {
		this.plcy_hold_fst_nam = plcy_hold_fst_nam;
	}
	public String getPlcy_hold_last_nam() {
		return plcy_hold_last_nam;
	}
	public void setPlcy_hold_last_nam(String plcy_hold_last_nam) {
		this.plcy_hold_last_nam = plcy_hold_last_nam;
	}
	public String getCov_ca_ind() {
		return cov_ca_ind;
	}
	public void setCov_ca_ind(String cov_ca_ind) {
		this.cov_ca_ind = cov_ca_ind;
	}
	public String getCov_ca_case_num() {
		return cov_ca_case_num;
	}
	public void setCov_ca_case_num(String cov_ca_case_num) {
		this.cov_ca_case_num = cov_ca_case_num;
	}
	public String getLooping_ind() {
		return looping_ind;
	}
	public void setLooping_ind(String looping_ind) {
		this.looping_ind = looping_ind;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getHlt_end_dt() {
		return hlt_end_dt;
	}
	public void setHlt_end_dt(String hlt_end_dt) {
		this.hlt_end_dt = hlt_end_dt;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getLst_dy_health_dt() {
		return lst_dy_health_dt;
	}
	public void setLst_dy_health_dt(String lst_dy_health_dt) {
		this.lst_dy_health_dt = lst_dy_health_dt;
	}
    
}