package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_DEDUCTION;
import gov.state.nextgen.application.submission.view.payload.Expenses;

import java.util.ArrayList;
import java.util.List;

public class BuildDeductionDetailsHelper {

	private BuildDeductionDetailsHelper() {
	}

	public static List<Expenses> buildDeductionExpenses(AggregatedPayload source, int indvSeq) {

		List<Expenses> expenseList = new ArrayList<>();

		try {
			List<CP_APP_IN_DEDUCTION> dedExpenseList = source.getFinancialExpenseSummaryDetails().getPageCollection().getCP_APP_IN_DEDUCTION();
			if (dedExpenseList != null && !dedExpenseList.isEmpty()) {
				for (CP_APP_IN_DEDUCTION dedExpense : dedExpenseList) {
					if (indvSeq == dedExpense.getIndv_seq_num()) {

						expenseList.add(getExpense(dedExpense));

					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildDeductionDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while loading Deductions Expense Details - " + e.getMessage());
		}
		return expenseList;
	}

	private static Expenses getExpense(CP_APP_IN_DEDUCTION dedExpense) {
		double expenseeAmt = 0;
		Expenses expense = new Expenses();
		List<String> typeCatList = BuildIncomeTypeMappingHelper.getExpenseCd(dedExpense.getExp_typ());
		if (!typeCatList.isEmpty()) {
			expense.setCategoryCode(typeCatList.get(0));
			expense.setTypeCode(typeCatList.get(1));
		}
		String freqCd = dedExpense.getPay_freq_cd();
		if (ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
			expense.setFreqCode(ApplicationSubmissionConstants.FRE_II);
		} else {
			expense.setFreqCode(freqCd);
		}
		if (dedExpense.getCourt_order_pay_amt() != null) {
			expenseeAmt = Double.parseDouble(dedExpense.getCourt_order_pay_amt());
			expense.setDollarAmt(expenseeAmt);
		}
		if (dedExpense.getExp_amt() != null) {
			expenseeAmt = Double.parseDouble(dedExpense.getExp_amt());
			expense.setDollarAmt(expenseeAmt);
		}
		expense.setOtherDollarAmount(0);
		expense.setRecipientName(null);
		expense.setDescription(null);
		expense.setCareProviderName(null);
		expense.setCareProviderAddress(null);
		expense.setHsngExpnHelpInd(false);
		expense.setHsngHlpFirstName(null);
		expense.setHsngHlpLastName(null);
		expense.setHsngHlpAmt(0);
		expense.setHsngHlpFreq(null);
		expense.setLiheapInd(false);
		expense.setWhoWillReimburse(null);
		expense.setReimburseAmount(0);
		expense.setNameOfChildren(dedExpense.getChildren_name());
		expense.setTaxDeductibleAlimonyPmtInd(false);
		expense.setOtherDeductableExpenseText(null);

		return expense;
	}
}