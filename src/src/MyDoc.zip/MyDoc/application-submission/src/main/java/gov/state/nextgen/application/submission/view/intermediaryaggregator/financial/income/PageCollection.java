package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;


public class PageCollection {
	
	@JsonDeserialize(contentAs = APP_IN_SELFE_Collection.class)
	private List<APP_IN_SELFE_Collection> APP_IN_SELFE_Collection;
	
	@JsonDeserialize(contentAs = Questionnaire.class)
	private List<Questionnaire> Questionnaire;
	
	@JsonDeserialize(contentAs = APP_IN_EMPL_Collection.class)
	private List<APP_IN_EMPL_Collection> APP_IN_EMPL_Collection;

	@JsonDeserialize(contentAs = APP_IN_UEI_Collection.class)
	private List<APP_IN_UEI_Collection> APP_IN_UEI_Collection;

	public List<APP_IN_SELFE_Collection> getaPP_IN_SELFE_Collection() {
		return APP_IN_SELFE_Collection;
	}

	public void setaPP_IN_SELFE_Collection(List<APP_IN_SELFE_Collection> aPP_IN_SELFE_Collection) {
		this.APP_IN_SELFE_Collection = aPP_IN_SELFE_Collection;
	}

	public List<Questionnaire> getQuestionnaire() {
		return Questionnaire;
	}

	public void setQuestionnaire(List<Questionnaire> questionnaire) {
		this.Questionnaire = questionnaire;
	}

	public List<APP_IN_EMPL_Collection> getaPP_IN_EMPL_Collection() {
		return APP_IN_EMPL_Collection;
	}

	public void setaPP_IN_EMPL_Collection(List<APP_IN_EMPL_Collection> aPP_IN_EMPL_Collection) {
		this.APP_IN_EMPL_Collection = aPP_IN_EMPL_Collection;
	}

	public List<APP_IN_UEI_Collection> getaPP_IN_UEI_Collection() {
		return APP_IN_UEI_Collection;
	}

	public void setaPP_IN_UEI_Collection(List<APP_IN_UEI_Collection> aPP_IN_UEI_Collection) {
		this.APP_IN_UEI_Collection = aPP_IN_UEI_Collection;
	}

}
