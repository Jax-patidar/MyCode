package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class CP_APP_PGM_RQST_Collection {
	private String user;
    private String cargoName;
    private boolean dirty;
    private String rowAction;
    private String adaptRecordId;
    private String app_num;
    private int fma_rqst_ind;
	private String fpw_rqst_ind;
    private int fs_rqst_ind;
    private String ebd_rqst_ind;
    private String hc_rqst_ind;
    private String ser_rqst_ind;
    private String edi_acceptable_sw;
    private String cc_rqst_ind;
    private String cooling_assistance_rqst_ind;
    private String crisis_assistance_rqst_ind;
    private String fuel_assistance_rqst_ind;
    private int tanf_rqst_ind;
    private String no_snap_rqst_ind;
    private String rmb_tanf_rqst_ind;
    private String rmb_snap_rqst_ind;
    private String rmb_fma_rqst_ind;
    private String rmb_other_program_ind;
    private String wic_rqst_ind;
    private String liheap_rqst_ind;
    private String peach_rqst_ind;
    private String magi_rqst_ind;
    private int capi_request_ind;
    private int ggr_ind;
    private String county_med_ind;
    private String dcalfresh_request_ind;
    private String delete_reason_cd;
    
    public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public boolean isDirty() {
		return dirty;
	}
	public void setDirty(boolean dirty) {
		this.dirty = dirty;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getFma_rqst_ind() {
		return fma_rqst_ind;
	}
	public void setFma_rqst_ind(int fma_rqst_ind) {
		this.fma_rqst_ind = fma_rqst_ind;
	}
	public String getFpw_rqst_ind() {
		return fpw_rqst_ind;
	}
	public void setFpw_rqst_ind(String fpw_rqst_ind) {
		this.fpw_rqst_ind = fpw_rqst_ind;
	}
	public int getFs_rqst_ind() {
		return fs_rqst_ind;
	}
	public void setFs_rqst_ind(int fs_rqst_ind) {
		this.fs_rqst_ind = fs_rqst_ind;
	}
	public String getEbd_rqst_ind() {
		return ebd_rqst_ind;
	}
	public void setEbd_rqst_ind(String ebd_rqst_ind) {
		this.ebd_rqst_ind = ebd_rqst_ind;
	}
	public String getHc_rqst_ind() {
		return hc_rqst_ind;
	}
	public void setHc_rqst_ind(String hc_rqst_ind) {
		this.hc_rqst_ind = hc_rqst_ind;
	}
	public String getSer_rqst_ind() {
		return ser_rqst_ind;
	}
	public void setSer_rqst_ind(String ser_rqst_ind) {
		this.ser_rqst_ind = ser_rqst_ind;
	}
	public String getEdi_acceptable_sw() {
		return edi_acceptable_sw;
	}
	public void setEdi_acceptable_sw(String edi_acceptable_sw) {
		this.edi_acceptable_sw = edi_acceptable_sw;
	}
	public String getCc_rqst_ind() {
		return cc_rqst_ind;
	}
	public void setCc_rqst_ind(String cc_rqst_ind) {
		this.cc_rqst_ind = cc_rqst_ind;
	}
	public String getCooling_assistance_rqst_ind() {
		return cooling_assistance_rqst_ind;
	}
	public void setCooling_assistance_rqst_ind(String cooling_assistance_rqst_ind) {
		this.cooling_assistance_rqst_ind = cooling_assistance_rqst_ind;
	}
	public String getCrisis_assistance_rqst_ind() {
		return crisis_assistance_rqst_ind;
	}
	public void setCrisis_assistance_rqst_ind(String crisis_assistance_rqst_ind) {
		this.crisis_assistance_rqst_ind = crisis_assistance_rqst_ind;
	}
	public String getFuel_assistance_rqst_ind() {
		return fuel_assistance_rqst_ind;
	}
	public void setFuel_assistance_rqst_ind(String fuel_assistance_rqst_ind) {
		this.fuel_assistance_rqst_ind = fuel_assistance_rqst_ind;
	}
	public int getTanf_rqst_ind() {
		return tanf_rqst_ind;
	}
	public void setTanf_rqst_ind(int tanf_rqst_ind) {
		this.tanf_rqst_ind = tanf_rqst_ind;
	}
	public String getNo_snap_rqst_ind() {
		return no_snap_rqst_ind;
	}
	public void setNo_snap_rqst_ind(String no_snap_rqst_ind) {
		this.no_snap_rqst_ind = no_snap_rqst_ind;
	}
	public String getRmb_tanf_rqst_ind() {
		return rmb_tanf_rqst_ind;
	}
	public void setRmb_tanf_rqst_ind(String rmb_tanf_rqst_ind) {
		this.rmb_tanf_rqst_ind = rmb_tanf_rqst_ind;
	}
	public String getRmb_snap_rqst_ind() {
		return rmb_snap_rqst_ind;
	}
	public void setRmb_snap_rqst_ind(String rmb_snap_rqst_ind) {
		this.rmb_snap_rqst_ind = rmb_snap_rqst_ind;
	}
	public String getRmb_fma_rqst_ind() {
		return rmb_fma_rqst_ind;
	}
	public void setRmb_fma_rqst_ind(String rmb_fma_rqst_ind) {
		this.rmb_fma_rqst_ind = rmb_fma_rqst_ind;
	}
	public String getRmb_other_program_ind() {
		return rmb_other_program_ind;
	}
	public void setRmb_other_program_ind(String rmb_other_program_ind) {
		this.rmb_other_program_ind = rmb_other_program_ind;
	}
	public String getWic_rqst_ind() {
		return wic_rqst_ind;
	}
	public void setWic_rqst_ind(String wic_rqst_ind) {
		this.wic_rqst_ind = wic_rqst_ind;
	}
	public String getLiheap_rqst_ind() {
		return liheap_rqst_ind;
	}
	public void setLiheap_rqst_ind(String liheap_rqst_ind) {
		this.liheap_rqst_ind = liheap_rqst_ind;
	}
	public String getPeach_rqst_ind() {
		return peach_rqst_ind;
	}
	public void setPeach_rqst_ind(String peach_rqst_ind) {
		this.peach_rqst_ind = peach_rqst_ind;
	}
	public String getMagi_rqst_ind() {
		return magi_rqst_ind;
	}
	public void setMagi_rqst_ind(String magi_rqst_ind) {
		this.magi_rqst_ind = magi_rqst_ind;
	}
	public int getCapi_request_ind() {
		return capi_request_ind;
	}
	public void setCapi_request_ind(int capi_request_ind) {
		this.capi_request_ind = capi_request_ind;
	}
	public int getGgr_ind() {
		return ggr_ind;
	}
	public void setGgr_ind(int ggr_ind) {
		this.ggr_ind = ggr_ind;
	}
	public String getCounty_med_ind() {
		return county_med_ind;
	}
	public void setCounty_med_ind(String county_med_ind) {
		this.county_med_ind = county_med_ind;
	}
	public String getDcalfresh_request_ind() {
		return dcalfresh_request_ind;
	}
	public void setDcalfresh_request_ind(String dcalfresh_request_ind) {
		this.dcalfresh_request_ind = dcalfresh_request_ind;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	

}
