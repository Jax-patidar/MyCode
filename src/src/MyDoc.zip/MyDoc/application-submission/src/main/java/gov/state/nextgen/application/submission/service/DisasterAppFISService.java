package gov.state.nextgen.application.submission.service;

import java.util.concurrent.CompletableFuture;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;

public interface DisasterAppFISService {
	CompletableFuture<AggregatedPayload> fetchDisasterCalFISData(AggregatedPayload payload);
}
