package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset;

public class APP_IN_P_PROP_ASET_Collection {
	
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int indv_seq_num;
	private int seq_num;
	private String jnt_own_resp;
	private double prsn_prop_amt;
	private double property_owe_amt;
	private String prsn_prop_amt_ind;
	private String prsn_prop_aset_typ;
	private String acquired_dt;
	private String business_trade_farming_ind;
	private String rec_cplt_ind;
	private String asset_end_dt;
	private String prsn_prop_dsc;
	private String loopingQuestion;
	private String ecp_id;
	private String chg_dt;
	private String wic_request_ind;
	private String sale_ind;
	private String src_app_ind;

	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public int getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}
	public String getJnt_own_resp() {
		return jnt_own_resp;
	}
	public void setJnt_own_resp(String jnt_own_resp) {
		this.jnt_own_resp = jnt_own_resp;
	}
	public double getPrsn_prop_amt() {
		return prsn_prop_amt;
	}
	public void setPrsn_prop_amt(double prsn_prop_amt) {
		this.prsn_prop_amt = prsn_prop_amt;
	}
	public double getProperty_owe_amt() {
		return property_owe_amt;
	}
	public void setProperty_owe_amt(double property_owe_amt) {
		this.property_owe_amt = property_owe_amt;
	}
	public String getPrsn_prop_amt_ind() {
		return prsn_prop_amt_ind;
	}
	public void setPrsn_prop_amt_ind(String prsn_prop_amt_ind) {
		this.prsn_prop_amt_ind = prsn_prop_amt_ind;
	}
	public String getPrsn_prop_aset_typ() {
		return prsn_prop_aset_typ;
	}
	public void setPrsn_prop_aset_typ(String prsn_prop_aset_typ) {
		this.prsn_prop_aset_typ = prsn_prop_aset_typ;
	}
	public String getAcquired_dt() {
		return acquired_dt;
	}
	public void setAcquired_dt(String acquired_dt) {
		this.acquired_dt = acquired_dt;
	}
	public String getBusiness_trade_farming_ind() {
		return business_trade_farming_ind;
	}
	public void setBusiness_trade_farming_ind(String business_trade_farming_ind) {
		this.business_trade_farming_ind = business_trade_farming_ind;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getAsset_end_dt() {
		return asset_end_dt;
	}
	public void setAsset_end_dt(String asset_end_dt) {
		this.asset_end_dt = asset_end_dt;
	}
	public String getPrsn_prop_dsc() {
		return prsn_prop_dsc;
	}
	public void setPrsn_prop_dsc(String prsn_prop_dsc) {
		this.prsn_prop_dsc = prsn_prop_dsc;
	}
	public String getLoopingQuestion() {
		return loopingQuestion;
	}
	public void setLoopingQuestion(String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getWic_request_ind() {
		return wic_request_ind;
	}
	public void setWic_request_ind(String wic_request_ind) {
		this.wic_request_ind = wic_request_ind;
	}
	public String getSale_ind() {
		return sale_ind;
	}
	public void setSale_ind(String sale_ind) {
		this.sale_ind = sale_ind;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
}