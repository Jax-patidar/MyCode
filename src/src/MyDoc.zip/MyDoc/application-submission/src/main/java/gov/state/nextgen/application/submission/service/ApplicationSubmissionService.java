package gov.state.nextgen.application.submission.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.payload.ApplicationSubmissionPayload;

@Service
public class ApplicationSubmissionService {

	@Autowired
	private PayloadAggregatorService payloadAggregatorService;
	@Autowired
	private PayloadTransformService payloadTransformService;
	
	
	public AggregatedPayload buildPayload(String appNum) {
		AggregatedPayload aggregatedPayload = new AggregatedPayload();
		aggregatedPayload.setAppNumber(appNum);
		return payloadAggregatorService.buildPayload(aggregatedPayload);
		
	}
	
	public ApplicationSubmissionPayload fromAggregatedPayload(AggregatedPayload aggregatedPayload) throws Exception {
		return payloadTransformService.fromAggregatedPayload(aggregatedPayload);
		
	}

}
