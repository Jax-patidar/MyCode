package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class SponsoredNonCitzInfo {

    private String firstName;
    private String lastName;
    private PhoneNumber phoneNumber;
    private Boolean helpWithMoneyInd;
    private double helpWIthMoneyAmt;
    private Boolean helpWithRentInd;
    private Boolean helpWithClothesInd;
    private Boolean helpWithFoodInd;
    private Boolean sponsoredNonCitzInd;
    private Boolean signedI864Ind;
    private Boolean signedI134Ind;
    private Boolean helpWithOtherInd;
    private String otherExpln;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public PhoneNumber getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(PhoneNumber phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Boolean isHelpWithMoneyInd() {
		return helpWithMoneyInd;
	}
	public void setHelpWithMoneyInd(Boolean helpWithMoneyInd) {
		this.helpWithMoneyInd = helpWithMoneyInd;
	}
	public double getHelpWIthMoneyAmt() {
		return helpWIthMoneyAmt;
	}
	public void setHelpWIthMoneyAmt(double helpWIthMoneyAmt) {
		this.helpWIthMoneyAmt = helpWIthMoneyAmt;
	}
	public Boolean isHelpWithRentInd() {
		return helpWithRentInd;
	}
	public void setHelpWithRentInd(Boolean helpWithRentInd) {
		this.helpWithRentInd = helpWithRentInd;
	}
	public Boolean isHelpWithClothesInd() {
		return helpWithClothesInd;
	}
	public void setHelpWithClothesInd(Boolean helpWithClothesInd) {
		this.helpWithClothesInd = helpWithClothesInd;
	}
	public Boolean isHelpWithFoodInd() {
		return helpWithFoodInd;
	}
	public void setHelpWithFoodInd(Boolean helpWithFoodInd) {
		this.helpWithFoodInd = helpWithFoodInd;
	}
	public Boolean isSponsoredNonCitzInd() {
		return sponsoredNonCitzInd;
	}
	public void setSponsoredNonCitzInd(Boolean sponsoredNonCitzInd) {
		this.sponsoredNonCitzInd = sponsoredNonCitzInd;
	}
	public Boolean isSignedI864Ind() {
		return signedI864Ind;
	}
	public void setSignedI864Ind(Boolean signedI864Ind) {
		this.signedI864Ind = signedI864Ind;
	}
	public Boolean isSignedI134Ind() {
		return signedI134Ind;
	}
	public void setSignedI134Ind(Boolean signedI134Ind) {
		this.signedI134Ind = signedI134Ind;
	}
	public Boolean isHelpWithOtherInd() {
		return helpWithOtherInd;
	}
	public void setHelpWithOtherInd(Boolean helpWithOtherInd) {
		this.helpWithOtherInd = helpWithOtherInd;
	}
	public String getOtherExpln() {
		return otherExpln;
	}
	public void setOtherExpln(String otherExpln) {
		this.otherExpln = otherExpln;
	}
}
