package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

public class BuildIncomeTypeMappingHelper {

    private BuildIncomeTypeMappingHelper() {
    }

    public static List<String> getUnEarnTypeCatCd(String incType) {
        List<String> incTypeCatCd = new ArrayList<>(2);
        if (incType != null) {
            switch (incType) {
                case "SD":
                    incTypeCatCd.add(0, "04");
                    incTypeCatCd.add(1, "71");
                    break;
                case "SR":
                case "SS":
                    incTypeCatCd.add(0, "04");
                    incTypeCatCd.add(1, "");
                    break;
                case "UD":
                    incTypeCatCd.add(0, "19");
                    incTypeCatCd.add(1, "79");
                    break;
                case "FA":
                case "WW":
                    incTypeCatCd.add(0, "06");
                    incTypeCatCd.add(1, "");
                    break;
                case "RD":
                    incTypeCatCd.add(0, "05");
                    incTypeCatCd.add(1, "");
                    break;
                case "TP":
                    incTypeCatCd.add(0, "14");
                    incTypeCatCd.add(1, "");
                    break;
                case "CD":
                    incTypeCatCd.add(0, "13");
                    incTypeCatCd.add(1, "EK");
                    break;
                case "CS":
                    incTypeCatCd.add(0, "07");
                    incTypeCatCd.add(1, "");
                    break;
                case "WC":
                case "DR":
                    incTypeCatCd.add(0, "03");
                    incTypeCatCd.add(1, "");
                    break;
                case "GM":
                    incTypeCatCd.add(0, "12");
                    incTypeCatCd.add(1, "06");
                    break;
                case "HP":
                    incTypeCatCd.add(0, "23");
                    incTypeCatCd.add(1, "");
                    break;
                case "RW":
                    incTypeCatCd.add(0, "18");
                    incTypeCatCd.add(1, "68");
                    break;
                case "LW":
                    incTypeCatCd.add(0, "13");
                    incTypeCatCd.add(1, "89");
                    break;
                case "PR":
                    incTypeCatCd.add(0, "16");
                    incTypeCatCd.add(1, "");
                    break;
                case "IL":
                    incTypeCatCd.add(0, "10");
                    incTypeCatCd.add(1, "45");
                    break;
                case "NF":
                    incTypeCatCd.add(0, "01");
                    incTypeCatCd.add(1, "FF");
                    break;
                case "DI":
                    incTypeCatCd.add(0, "11");
                    incTypeCatCd.add(1, "IN");
                    break;
                case "PN":
                    incTypeCatCd.add(0, "11");
                    incTypeCatCd.add(1, "40");
                    break;
                case "SB":
                    incTypeCatCd.add(0, "01");
                    incTypeCatCd.add(1, "");
                    break;
                case "RB":
                    incTypeCatCd.add(0, "17");
                    incTypeCatCd.add(1, "");
                    break;
                case "OT":
                    incTypeCatCd.add(0, "13");
                    incTypeCatCd.add(1, "EM");
                    break;
                case "HR":
                    incTypeCatCd.add(0, "08");
                    incTypeCatCd.add(1, "97");
                    break;
                case "UT":
                    incTypeCatCd.add(0, "08");
                    incTypeCatCd.add(1, "37");
                    break;
                case "FD":
                    incTypeCatCd.add(0, "08");
                    incTypeCatCd.add(1, "93");
                    break;
                case "CT":
                    incTypeCatCd.add(0, "08");
                    incTypeCatCd.add(1, "95");
                    break;
                case "VI":
                    incTypeCatCd.add(0, "09");
                    incTypeCatCd.add(1, "A12");
                    break;
                case "E":
                    incTypeCatCd.add(0, "01");
                    incTypeCatCd.add(1, "28");
                    break;
                default:
            }
        }
        return incTypeCatCd;
    }

    public static String getLiqResourceCd(String liqRsc) {

        String liqRscCd = null;
        switch (liqRsc) {
            case "CA":
                liqRscCd = "11";
                break;
            case "SA":
                liqRscCd = "21";
                break;
            case "CH":
                liqRscCd = "13";
                break;
            case "LB":
                liqRscCd = "09";
                break;
            case "SB":
                liqRscCd = "22";
                break;
            case "MM":
                liqRscCd = "25";
                break;
            case "MF":
                liqRscCd = "24";
                break;
            case "SV":
                liqRscCd = "19";
                break;
            case "CD":
                liqRscCd = "23";
                break;
            case "IR":
                liqRscCd = "66";
                break;
            case "MI":
                liqRscCd = "19";
                break;
            case "UC":
                liqRscCd = "69";
                break;
            case "SD":
                liqRscCd = "70";
                break;
            case "MG":
                liqRscCd = "30";
                break;
            case "OT":
                liqRscCd = "19";
                break;
            default:
        }
        return liqRscCd;
    }

    public static String getPersonalProCd(String personalProp) {

        String persPropCd = null;
        switch (personalProp) {
            case "JW":
                persPropCd = "15";
                break;
            case "SG":
                persPropCd = "14";
                break;
            case "PT":
                persPropCd = "14";
                break;
            case "BI":
                persPropCd = "20";
                break;
            case "BE":
                persPropCd = "14";
                break;
            case "TN":
                persPropCd = "64";
                break;
            case "CS":
                persPropCd = "47";
                break;
            case "LS":
                persPropCd = "17";
                break;
            default:
        }
        return persPropCd;
    }

    public static List<String> getExpenseCd(String expCd) {
        List<String> expenseTypeCatCd = new ArrayList<>(2);
        if (expCd != null) {
            switch (expCd) {
                case "RH":
                    expenseTypeCatCd.add(0, "02");
                    expenseTypeCatCd.add(1, "10");
                    break;
                case "PT":
                    expenseTypeCatCd.add(0, "02");
                    expenseTypeCatCd.add(1, "12");
                    break;
                case "GE":
                    expenseTypeCatCd.add(0, "03");
                    expenseTypeCatCd.add(1, "20");
                    break;
                case "TE":
                    expenseTypeCatCd.add(0, "03");
                    expenseTypeCatCd.add(1, "18");
                    break;
                case "WA":
                    expenseTypeCatCd.add(0, "03");
                    expenseTypeCatCd.add(1, "");
                    break;
                case "HO":
                    expenseTypeCatCd.add(0, "24");
                    expenseTypeCatCd.add(1, "25");
                    break;
                case "HS":
                    expenseTypeCatCd.add(0, "07");
                    expenseTypeCatCd.add(1, "30");
                    break;
                case "DM":
                    expenseTypeCatCd.add(0, "19");
                    expenseTypeCatCd.add(1, "42");
                    break;
                case "DC":
                    expenseTypeCatCd.add(0, "17");
                    expenseTypeCatCd.add(1, "40");
                    break;
                case "CC":
                    expenseTypeCatCd.add(0, "04");
                    expenseTypeCatCd.add(1, "27");
                    break;
                case "CA":
                    expenseTypeCatCd.add(0, "04");
                    expenseTypeCatCd.add(1, "54");
                    break;
                case "TD":
                    expenseTypeCatCd.add(0, "09");
                    expenseTypeCatCd.add(1, "62");
                    break;
                case "CS":
                    expenseTypeCatCd.add(0, "04");
                    expenseTypeCatCd.add(1, "27");
                    break;
                case "AL":
                    expenseTypeCatCd.add(0, "04");
                    expenseTypeCatCd.add(1, "54");
                    break;
                case "SL":
                    expenseTypeCatCd.add(0, "09");
                    expenseTypeCatCd.add(1, "62");
                    break;
                case "OD":
                    expenseTypeCatCd.add(0, "09");
                    expenseTypeCatCd.add(1, "62");
                    break;
                case "SS":
                    expenseTypeCatCd.add(0, "04");
                    expenseTypeCatCd.add(1, "54");
                    break;
                default:
            }
        }
        return expenseTypeCatCd;
    }

    public static String getSuffixName(String suffix) {
        String sufixCd = null;

        switch (suffix) {
            case "I":
                sufixCd = "01";
                break;
            case "II":
                sufixCd = "02";
                break;
            case "III":
                sufixCd = "03";
                break;
            case "IV":
                sufixCd = "04";
                break;
            case "V":
                sufixCd = "05";
                break;
            case "VI":
                sufixCd = "06";
                break;
            case "VII":
                sufixCd = "07";
                break;
            case "VIII":
                sufixCd = "08";
                break;
            case "IX":
                sufixCd = "09";
                break;
            case "X":
                sufixCd = "10";
                break;
            case "JR":
                sufixCd = "Jr.";
                break;
            case "SR":
                sufixCd = "Sr.";
                break;
            default:
        }
        return sufixCd;
    }

    /**
     * Method to calculate age based on DOB
     *
     * @param brthDt
     * @return int
     * @throws Exception
     */
    public static int calculateAge(String brthDt) throws Exception { //NOSONAR
        int age = 0;
        final Calendar birth = new GregorianCalendar();
        final Calendar today = new GregorianCalendar();

        int factor = 0;
        try {
            LocalDate locbirthDate = LocalDate.parse(brthDt);
            Date birthDate = Date.from(locbirthDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
            final Date currentDate = new Date(); // current date
            birth.setTime(birthDate);
            today.setTime(currentDate);

            if (today.get(Calendar.DAY_OF_YEAR) < birth.get(Calendar.DAY_OF_YEAR)) {
                factor = -1; // birthday not celebrated
            }
            age = (today.get(Calendar.YEAR) - birth.get(Calendar.YEAR)) + factor;
        } catch (final Exception exception) {
            throw exception;//NOSONAR
        }
        return age;
    }

    public static String getMedCovType(String medType) {

        String medCovCd = null;
        switch (medType) {
            case "MC":
                medCovCd = "MC";
                break;
            case "CH":
                medCovCd = "CH";
                break;
            case "MD":
                medCovCd = "MD";
                break;
            case "TC":
                medCovCd = "TR";
                break;
            case "VA":
                medCovCd = "VA";
                break;
            case "PG":
                medCovCd = "PC";
                break;
            case "EI":
                medCovCd = "AO";
                break;
            case "OT":
                medCovCd = "AO";
                break;
            default:
        }
        return medCovCd;
    }

    public static String addMonths(int months) {
        String retroDt = null;

        try {
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern(ApplicationSubmissionConstants.YYYY_MM_DD);
            LocalDate date = LocalDate.now();
            String strDt = date.format(dateFormat);
            retroDt = LocalDate
                    .parse(strDt)
                    .minusMonths(months).with(TemporalAdjusters.firstDayOfMonth())
                    .toString();
        } catch (Exception e) {
            FwLogger.log(BuildIncomeTypeMappingHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while getting Retro Medical date - " + e.getMessage());
        }
        return retroDt;
    }
    
    public static String getRelationType(String relVal) {
    	
    	if("SC".equalsIgnoreCase(relVal)) {
    		return "PS";
    	}
    	if("GC".equalsIgnoreCase(relVal) ) {
    		return "GP";
    	}
    	if("PS".equalsIgnoreCase(relVal)) {
    		return "SC";
    	}
    	if("GP".equalsIgnoreCase(relVal)) {
    		return "GC";
    	}
    	if("AU".equalsIgnoreCase(relVal) ) {
    		return "NN";
    	}
    	if("NN".equalsIgnoreCase(relVal)) {
    		return "AU";
    	}
    	if("PB".equalsIgnoreCase(relVal)) {
    		return "CH";
    	}
    	if("CH".equalsIgnoreCase(relVal) ) {
    		return "PB";
    	}
    	
    	return relVal;
    }
}