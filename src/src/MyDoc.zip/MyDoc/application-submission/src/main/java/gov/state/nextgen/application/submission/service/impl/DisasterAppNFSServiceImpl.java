package gov.state.nextgen.application.submission.service.impl;

import static gov.state.nextgen.application.submission.framework.constants.ExceptionConstants.KEY_IDENTIFIER_ONE;

import java.util.concurrent.CompletableFuture;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.ExceptionsUtil;
import gov.state.nextgen.application.submission.framework.exception.ExceptionLogManager;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.service.DisasterAppNFSService;
import gov.state.nextgen.application.submission.service.LambdaInvokerServiceImpl;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.request.PayLoadRequest;
import gov.state.nextgen.application.submission.view.response.DisasterAppNFSRespDetails;

@Service
public class DisasterAppNFSServiceImpl implements DisasterAppNFSService {

    @Autowired
    private LambdaInvokerServiceImpl service;

    @Autowired
    @Qualifier("appSubmissionThreadPoolTaskExecutor")
    private ThreadPoolTaskExecutor threadPoolTaskExecutor;

    @Autowired
    private ExceptionLogManager exceptionLogManager;

    @Async("appSubmissionThreadPoolTaskExecutor")
    public CompletableFuture<AggregatedPayload> fetchDisasterCalNFSData(AggregatedPayload payload) {
    	MDC.put(KEY_IDENTIFIER_ONE,  payload.getAppNumber());
        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "fetching Disaster Cal House Non Financial Details data for case::" + payload.getAppNumber());

        String responseBody = null;
        PayLoadRequest payLoadRequest = new PayLoadRequest(payload.getAppNumber(), ApplicationSubmissionConstants.DCNFS, ApplicationSubmissionConstants.DCNFS_LOAD);

        HttpEntity<Object> httpEntity = new HttpEntity<>(payLoadRequest);

        try {

            String url = System.getenv(ApplicationSubmissionConstants.DISASTER_CALS_NFS_DETAILS_URL);
            String path = ApplicationUtil.createURIPath(ApplicationSubmissionConstants.NFS_PATH, ApplicationSubmissionConstants.DCNFS, ApplicationSubmissionConstants.DCNFS_LOAD);
            responseBody = service.invokeLambda(url, httpEntity, path);

            ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            DisasterAppNFSRespDetails disasterAppNFSRespDetails = objMapper.readValue(responseBody, DisasterAppNFSRespDetails.class);

            payload.setDisasterAppNFSRespDetails(disasterAppNFSRespDetails);
            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "successfully fetched Disaster Cal Non Financial Summary Details data for case::" + payload.getAppNumber());
        } catch (Throwable e) {//NOSONAR
            payload.setErrorWhileAccessingInternalServices(true);
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Error while fetching data from Disaster Cal Non Financial Summary Details data for case ::" + payload.getAppNumber());
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Exception occurred due to::" + e.getMessage());
            exceptionLogManager.sendMessage(ExceptionsUtil.getExceptionCargo(this.getClass(), e, "fetchDisasterCalNFSData", payload.getAppNumber()));
        }
        return CompletableFuture.completedFuture(payload);
    }

}
