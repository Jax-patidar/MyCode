package gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial;

public class APP_IN_EMPL_HEALTH_Collection {
	
	private String app_num ;
    private int indv_seq_num ;
    private int empl_seq_num ;
    private String src_app_ind ;
    private String rec_cplt_ind ;
    private String hlth_ins_comp_nam ;
    private String policy_num ;
    private String cobra_cvrg ;
    private String ret_hlth_plan ;
    private String empl_cntct_name ;
    private String empl_cntct_last_name ;
    private String empl_cntct_ph_no ;
    private String empl_cntct_email ;
    private String elig_hlth_cvrg ;
    private String cvrg_start_dt ;
    private String empl_cvrg_minval_offer ;
    private String min_value_std ;
    private String premium_plan ;
    private String oft_prem_paid ;
    private String cvrg_chng ;
    private int premium_new_plan ;
    private String oft_prem_paid_new ;
    private String date_change ;
    private String emp_bnft_plan_ind ;
    private String ins_cvrg_ofr_empl ;
    private String er_provd_med_ins_ind ;
    private String empl_cvrg_end ;
    private String empl_phone_num ;
    private String empl_state ;
    private String empl_zip ;
    private String wellness_plan_ind ;
    private String lost_health_ins_name ;
    private String lost_health_ins_rsn_desc ;
    private String empl_addrline1 ;
    private String empl_city ;
    private String er_name ;
    private String applicant_name ;
    
    
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public int getEmpl_seq_num() {
		return empl_seq_num;
	}
	public void setEmpl_seq_num(int empl_seq_num) {
		this.empl_seq_num = empl_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getHlth_ins_comp_nam() {
		return hlth_ins_comp_nam;
	}
	public void setHlth_ins_comp_nam(String hlth_ins_comp_nam) {
		this.hlth_ins_comp_nam = hlth_ins_comp_nam;
	}
	public String getPolicy_num() {
		return policy_num;
	}
	public void setPolicy_num(String policy_num) {
		this.policy_num = policy_num;
	}
	public String getCobra_cvrg() {
		return cobra_cvrg;
	}
	public void setCobra_cvrg(String cobra_cvrg) {
		this.cobra_cvrg = cobra_cvrg;
	}
	public String getRet_hlth_plan() {
		return ret_hlth_plan;
	}
	public void setRet_hlth_plan(String ret_hlth_plan) {
		this.ret_hlth_plan = ret_hlth_plan;
	}
	public String getEmpl_cntct_name() {
		return empl_cntct_name;
	}
	public void setEmpl_cntct_name(String empl_cntct_name) {
		this.empl_cntct_name = empl_cntct_name;
	}
	public String getEmpl_cntct_last_name() {
		return empl_cntct_last_name;
	}
	public void setEmpl_cntct_last_name(String empl_cntct_last_name) {
		this.empl_cntct_last_name = empl_cntct_last_name;
	}
	public String getEmpl_cntct_ph_no() {
		return empl_cntct_ph_no;
	}
	public void setEmpl_cntct_ph_no(String empl_cntct_ph_no) {
		this.empl_cntct_ph_no = empl_cntct_ph_no;
	}
	public String getEmpl_cntct_email() {
		return empl_cntct_email;
	}
	public void setEmpl_cntct_email(String empl_cntct_email) {
		this.empl_cntct_email = empl_cntct_email;
	}
	public String getElig_hlth_cvrg() {
		return elig_hlth_cvrg;
	}
	public void setElig_hlth_cvrg(String elig_hlth_cvrg) {
		this.elig_hlth_cvrg = elig_hlth_cvrg;
	}
	public String getCvrg_start_dt() {
		return cvrg_start_dt;
	}
	public void setCvrg_start_dt(String cvrg_start_dt) {
		this.cvrg_start_dt = cvrg_start_dt;
	}
	public String getEmpl_cvrg_minval_offer() {
		return empl_cvrg_minval_offer;
	}
	public void setEmpl_cvrg_minval_offer(String empl_cvrg_minval_offer) {
		this.empl_cvrg_minval_offer = empl_cvrg_minval_offer;
	}
	public String getMin_value_std() {
		return min_value_std;
	}
	public void setMin_value_std(String min_value_std) {
		this.min_value_std = min_value_std;
	}
	public String getPremium_plan() {
		return premium_plan;
	}
	public void setPremium_plan(String premium_plan) {
		this.premium_plan = premium_plan;
	}
	public String getOft_prem_paid() {
		return oft_prem_paid;
	}
	public void setOft_prem_paid(String oft_prem_paid) {
		this.oft_prem_paid = oft_prem_paid;
	}
	public String getCvrg_chng() {
		return cvrg_chng;
	}
	public void setCvrg_chng(String cvrg_chng) {
		this.cvrg_chng = cvrg_chng;
	}
	public int getPremium_new_plan() {
		return premium_new_plan;
	}
	public void setPremium_new_plan(int premium_new_plan) {
		this.premium_new_plan = premium_new_plan;
	}
	public String getOft_prem_paid_new() {
		return oft_prem_paid_new;
	}
	public void setOft_prem_paid_new(String oft_prem_paid_new) {
		this.oft_prem_paid_new = oft_prem_paid_new;
	}
	public String getDate_change() {
		return date_change;
	}
	public void setDate_change(String date_change) {
		this.date_change = date_change;
	}
	public String getEmp_bnft_plan_ind() {
		return emp_bnft_plan_ind;
	}
	public void setEmp_bnft_plan_ind(String emp_bnft_plan_ind) {
		this.emp_bnft_plan_ind = emp_bnft_plan_ind;
	}
	public String getIns_cvrg_ofr_empl() {
		return ins_cvrg_ofr_empl;
	}
	public void setIns_cvrg_ofr_empl(String ins_cvrg_ofr_empl) {
		this.ins_cvrg_ofr_empl = ins_cvrg_ofr_empl;
	}
	public String getEr_provd_med_ins_ind() {
		return er_provd_med_ins_ind;
	}
	public void setEr_provd_med_ins_ind(String er_provd_med_ins_ind) {
		this.er_provd_med_ins_ind = er_provd_med_ins_ind;
	}
	public String getEmpl_cvrg_end() {
		return empl_cvrg_end;
	}
	public void setEmpl_cvrg_end(String empl_cvrg_end) {
		this.empl_cvrg_end = empl_cvrg_end;
	}
	public String getEmpl_phone_num() {
		return empl_phone_num;
	}
	public void setEmpl_phone_num(String empl_phone_num) {
		this.empl_phone_num = empl_phone_num;
	}
	public String getEmpl_state() {
		return empl_state;
	}
	public void setEmpl_state(String empl_state) {
		this.empl_state = empl_state;
	}
	public String getEmpl_zip() {
		return empl_zip;
	}
	public void setEmpl_zip(String empl_zip) {
		this.empl_zip = empl_zip;
	}
	public String getWellness_plan_ind() {
		return wellness_plan_ind;
	}
	public void setWellness_plan_ind(String wellness_plan_ind) {
		this.wellness_plan_ind = wellness_plan_ind;
	}
	public String getLost_health_ins_name() {
		return lost_health_ins_name;
	}
	public void setLost_health_ins_name(String lost_health_ins_name) {
		this.lost_health_ins_name = lost_health_ins_name;
	}
	public String getLost_health_ins_rsn_desc() {
		return lost_health_ins_rsn_desc;
	}
	public void setLost_health_ins_rsn_desc(String lost_health_ins_rsn_desc) {
		this.lost_health_ins_rsn_desc = lost_health_ins_rsn_desc;
	}
	public String getEmpl_addrline1() {
		return empl_addrline1;
	}
	public void setEmpl_addrline1(String empl_addrline1) {
		this.empl_addrline1 = empl_addrline1;
	}
	public String getEmpl_city() {
		return empl_city;
	}
	public void setEmpl_city(String empl_city) {
		this.empl_city = empl_city;
	}
	public String getEr_name() {
		return er_name;
	}
	public void setEr_name(String er_name) {
		this.er_name = er_name;
	}
	public String getApplicant_name() {
		return applicant_name;
	}
	public void setApplicant_name(String applicant_name) {
		this.applicant_name = applicant_name;
	}
}
