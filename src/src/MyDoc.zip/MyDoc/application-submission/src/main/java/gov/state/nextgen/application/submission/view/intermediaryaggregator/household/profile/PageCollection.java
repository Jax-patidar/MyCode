package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class PageCollection {

	@JsonDeserialize(contentAs = APP_IN_OUT_ST_BNFT_Collection.class)
    private List<APP_IN_OUT_ST_BNFT_Collection> APP_IN_OUT_ST_BNFT_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_FosterChild_Collection.class)
    private List<APP_IN_FosterChild_Collection> APP_IN_FosterChild_Collection;
    
    
    @JsonDeserialize(contentAs = APP_IN_Primary_Caretaker_Collection.class)
    private List<APP_IN_Primary_Caretaker_Collection> APP_IN_Primary_Caretaker_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_Teen_Parent_Collection.class)
    private List<APP_IN_Teen_Parent_Collection> APP_IN_Teen_Parent_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_BreastFeeding_Collection.class)
    private List<APP_IN_BreastFeeding_Collection> APP_IN_BreastFeeding_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_Meals_Collection.class)
    private List<APP_IN_Meals_Collection> APP_IN_Meals_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_LeavingCA_Collection.class)
    private List<APP_IN_LeavingCA_Collection> APP_IN_LeavingCA_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_FosterCare_Collection.class)
    private List<APP_IN_FosterCare_Collection> APP_IN_FosterCare_Collection;
   
    @JsonDeserialize(contentAs = APP_INDV_FOOD_PRGM_Collection.class)
    private List<APP_INDV_FOOD_PRGM_Collection> APP_INDV_FOOD_PRGM_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_Armed_Forces_Collection.class)
    private List<APP_IN_Armed_Forces_Collection> APP_IN_Armed_Forces_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_DABL_Collection.class)
    private List<APP_IN_DABL_Collection> APP_IN_DABL_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_SHLTC_Collection.class)
    private List<APP_IN_SHLTC_Collection> APP_IN_SHLTC_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_Childcare_Collection.class)
    private List<APP_IN_Childcare_Collection> APP_IN_Childcare_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_SCHLE_Collection.class)
    private List<APP_IN_SCHLE_Collection> APP_IN_SCHLE_Collection;
    
    @JsonDeserialize(contentAs = APP_IN_PREG_Collection.class)
    private List<APP_IN_PREG_Collection> APP_IN_PREG_Collection;
    
    @JsonDeserialize(contentAs = CP_APP_IN_SCHOOL_Collection.class)
    private List<CP_APP_IN_SCHOOL_Collection> CP_APP_IN_SCHOOL_Collection;
   
    @JsonDeserialize(contentAs = CP_APP_IN_TAX_RETURN_Collection.class)
    private List<CP_APP_IN_TAX_RETURN_Collection> CP_APP_IN_TAX_RETURN_Collection;    

	public List<CP_APP_IN_TAX_RETURN_Collection> getCP_APP_IN_TAX_RETURN_Collection() {
		return CP_APP_IN_TAX_RETURN_Collection;
	}

	public void setCP_APP_IN_TAX_RETURN_Collection(List<CP_APP_IN_TAX_RETURN_Collection> cP_APP_IN_TAX_RETURN_Collection) {
		CP_APP_IN_TAX_RETURN_Collection = cP_APP_IN_TAX_RETURN_Collection;
	}
	
	public List<APP_IN_OUT_ST_BNFT_Collection> getAPP_IN_OUT_ST_BNFT_Collection() {
		return APP_IN_OUT_ST_BNFT_Collection;
	}

	public void setAPP_IN_OUT_ST_BNFT_Collection(List<APP_IN_OUT_ST_BNFT_Collection> aPP_IN_OUT_ST_BNFT_Collection) {
		APP_IN_OUT_ST_BNFT_Collection = aPP_IN_OUT_ST_BNFT_Collection;
	}

	public List<APP_IN_FosterChild_Collection> getAPP_IN_FosterChild_Collection() {
		return APP_IN_FosterChild_Collection;
	}

	public void setAPP_IN_FosterChild_Collection(List<APP_IN_FosterChild_Collection> aPP_IN_FosterChild_Collection) {
		APP_IN_FosterChild_Collection = aPP_IN_FosterChild_Collection;
	}

	public List<APP_IN_Primary_Caretaker_Collection> getAPP_IN_Primary_Caretaker_Collection() {
		return APP_IN_Primary_Caretaker_Collection;
	}

	public void setAPP_IN_Primary_Caretaker_Collection(
			List<APP_IN_Primary_Caretaker_Collection> aPP_IN_Primary_Caretaker_Collection) {
		APP_IN_Primary_Caretaker_Collection = aPP_IN_Primary_Caretaker_Collection;
	}

	public List<APP_IN_Teen_Parent_Collection> getAPP_IN_Teen_Parent_Collection() {
		return APP_IN_Teen_Parent_Collection;
	}

	public void setAPP_IN_Teen_Parent_Collection(List<APP_IN_Teen_Parent_Collection> aPP_IN_Teen_Parent_Collection) {
		APP_IN_Teen_Parent_Collection = aPP_IN_Teen_Parent_Collection;
	}

	public List<APP_IN_BreastFeeding_Collection> getAPP_IN_BreastFeeding_Collection() {
		return APP_IN_BreastFeeding_Collection;
	}

	public void setAPP_IN_BreastFeeding_Collection(List<APP_IN_BreastFeeding_Collection> aPP_IN_BreastFeeding_Collection) {
		APP_IN_BreastFeeding_Collection = aPP_IN_BreastFeeding_Collection;
	}

	public List<APP_IN_Meals_Collection> getAPP_IN_Meals_Collection() {
		return APP_IN_Meals_Collection;
	}

	public void setAPP_IN_Meals_Collection(List<APP_IN_Meals_Collection> aPP_IN_Meals_Collection) {
		APP_IN_Meals_Collection = aPP_IN_Meals_Collection;
	}

	public List<APP_IN_LeavingCA_Collection> getAPP_IN_LeavingCA_Collection() {
		return APP_IN_LeavingCA_Collection;
	}

	public void setAPP_IN_LeavingCA_Collection(List<APP_IN_LeavingCA_Collection> aPP_IN_LeavingCA_Collection) {
		APP_IN_LeavingCA_Collection = aPP_IN_LeavingCA_Collection;
	}

	public List<APP_IN_FosterCare_Collection> getAPP_IN_FosterCare_Collection() {
		return APP_IN_FosterCare_Collection;
	}

	public void setAPP_IN_FosterCare_Collection(List<APP_IN_FosterCare_Collection> aPP_IN_FosterCare_Collection) {
		APP_IN_FosterCare_Collection = aPP_IN_FosterCare_Collection;
	}

	public List<APP_INDV_FOOD_PRGM_Collection> getAPP_INDV_FOOD_PRGM_Collection() {
		return APP_INDV_FOOD_PRGM_Collection;
	}

	public void setAPP_INDV_FOOD_PRGM_Collection(List<APP_INDV_FOOD_PRGM_Collection> aPP_INDV_FOOD_PRGM_Collection) {
		APP_INDV_FOOD_PRGM_Collection = aPP_INDV_FOOD_PRGM_Collection;
	}

	public List<APP_IN_Armed_Forces_Collection> getAPP_IN_Armed_Forces_Collection() {
		return APP_IN_Armed_Forces_Collection;
	}

	public void setAPP_IN_Armed_Forces_Collection(List<APP_IN_Armed_Forces_Collection> aPP_IN_Armed_Forces_Collection) {
		APP_IN_Armed_Forces_Collection = aPP_IN_Armed_Forces_Collection;
	}

	public List<APP_IN_DABL_Collection> getAPP_IN_DABL_Collection() {
		return APP_IN_DABL_Collection;
	}

	public void setAPP_IN_DABL_Collection(List<APP_IN_DABL_Collection> aPP_IN_DABL_Collection) {
		APP_IN_DABL_Collection = aPP_IN_DABL_Collection;
	}

	public List<APP_IN_SHLTC_Collection> getAPP_IN_SHLTC_Collection() {
		return APP_IN_SHLTC_Collection;
	}

	public void setAPP_IN_SHLTC_Collection(List<APP_IN_SHLTC_Collection> aPP_IN_SHLTC_Collection) {
		APP_IN_SHLTC_Collection = aPP_IN_SHLTC_Collection;
	}

	public List<APP_IN_Childcare_Collection> getAPP_IN_Childcare_Collection() {
		return APP_IN_Childcare_Collection;
	}

	public void setAPP_IN_Childcare_Collection(List<APP_IN_Childcare_Collection> aPP_IN_Childcare_Collection) {
		APP_IN_Childcare_Collection = aPP_IN_Childcare_Collection;
	}

	public List<APP_IN_SCHLE_Collection> getAPP_IN_SCHLE_Collection() {
		return APP_IN_SCHLE_Collection;
	}

	public void setAPP_IN_SCHLE_Collection(List<APP_IN_SCHLE_Collection> aPP_IN_SCHLE_Collection) {
		APP_IN_SCHLE_Collection = aPP_IN_SCHLE_Collection;
	}

	public List<APP_IN_PREG_Collection> getAPP_IN_PREG_Collection() {
		return APP_IN_PREG_Collection;
	}

	public void setAPP_IN_PREG_Collection(List<APP_IN_PREG_Collection> aPP_IN_PREG_Collection) {
		APP_IN_PREG_Collection = aPP_IN_PREG_Collection;
	}

	public List<CP_APP_IN_SCHOOL_Collection> getCP_APP_IN_SCHOOL_Collection() {
		return CP_APP_IN_SCHOOL_Collection;
	}

	public void setCP_APP_IN_SCHOOL_Collection(List<CP_APP_IN_SCHOOL_Collection> cP_APP_IN_SCHOOL_Collection) {
		CP_APP_IN_SCHOOL_Collection = cP_APP_IN_SCHOOL_Collection;
	}	
}
