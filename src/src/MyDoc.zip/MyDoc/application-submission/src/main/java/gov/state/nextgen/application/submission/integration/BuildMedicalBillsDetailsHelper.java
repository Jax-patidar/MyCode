package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_MED_BILLS;
import gov.state.nextgen.application.submission.view.payload.Applicant;
import gov.state.nextgen.application.submission.view.payload.Expenses;
import gov.state.nextgen.application.submission.view.payload.RetroMedical;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class BuildMedicalBillsDetailsHelper {

	private BuildMedicalBillsDetailsHelper() {}

	public static List<Expenses> buildMedicalExpenses(AggregatedPayload source, int indvSeq) {//NOSONAR

		Expenses expense = null;
		List<Expenses> expenseList = new ArrayList<>();
		String[] expArray = new String[] { ApplicationSubmissionConstants.EXP_HM, 
				ApplicationSubmissionConstants.EXP_SN, ApplicationSubmissionConstants.EXP_MC, 
				ApplicationSubmissionConstants.EXP_CS,ApplicationSubmissionConstants.STR_09, ApplicationSubmissionConstants.STR_19,
				ApplicationSubmissionConstants.STR_18,ApplicationSubmissionConstants.STR_08, 
				ApplicationSubmissionConstants.STR_17,ApplicationSubmissionConstants.STR_OT }; 
		List<String> otherExpList = new ArrayList<>(Arrays.asList(expArray));

		try {
			List<CP_APP_IN_MED_BILLS> medExpenseList = source.getFinancialExpenseSummaryDetails().getPageCollection().getCP_APP_IN_MED_BILLS();

			if(medExpenseList !=null && !medExpenseList.isEmpty()) {
				for(CP_APP_IN_MED_BILLS medExpense : medExpenseList) {
					if(indvSeq == medExpense.getIndv_seq_num() && !otherExpList.contains(medExpense.getMed_bill_type())) {
						expense = new Expenses(); 
						List<String> typeCatList = BuildIncomeTypeMappingHelper.getExpenseCd(medExpense.getMed_bill_type());
						if(!typeCatList.isEmpty()) {
							expense.setCategoryCode(typeCatList.get(0));
							expense.setTypeCode(typeCatList.get(1));
						} 
						String freqCd = medExpense.getPay_freq();
						if(ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
							expense.setFreqCode(ApplicationSubmissionConstants.FRE_II);
						} else {
							expense.setFreqCode(freqCd);
						}
						if(medExpense.getPayment_amt()!= null)
						{
							double expenseeAmt = Double.parseDouble(medExpense.getPayment_amt());
							expense.setDollarAmt(expenseeAmt);
						}
						expense.setOtherDollarAmount(0); 
						expense.setRecipientName(null); 
						expense.setDescription(null);
						expense.setCareProviderName(null); 
						expense.setCareProviderAddress(null);
						expense.setHsngExpnHelpInd(false);  
						expense.setLiheapInd(false);
						expense.setWhoWillReimburse(medExpense.getReimburse_name()); 
						if(medExpense.getReimburse_amt() != null)
							expense.setReimburseAmount(Double.parseDouble(medExpense.getReimburse_amt()));
						expense.setTaxDeductibleAlimonyPmtInd(false);
						expense.setOtherDeductableExpenseText(medExpense.getSpecial_needs_desc()); 

						expenseList.add(expense); 
					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildMedicalBillsDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while buildMedicalExpenses::" + e.getMessage());
		}
		return expenseList;
	}

	public static List<RetroMedical> getRetroDetails(AggregatedPayload source, int indvSeqNum) {//NOSONAR
		List<RetroMedical> retroList = new ArrayList<>(3);
		RetroMedical retro = null;
		List<CP_APP_IN_MED_BILLS> indvMedExpenses = null;
		List<CP_APP_IN_MED_BILLS> medExpenseList = null;

		try {
			medExpenseList = source.getFinancialExpenseSummaryDetails().getPageCollection().getCP_APP_IN_MED_BILLS();

			if(medExpenseList !=null && !medExpenseList.isEmpty()) {
				indvMedExpenses = medExpenseList.stream().filter(indv->indvSeqNum==indv.getIndv_seq_num()).collect(Collectors.toList());

				for(CP_APP_IN_MED_BILLS medExpense : indvMedExpenses) {
					if(medExpense.getMa_backdt_mo_1_ind() != null && StringUtils.isNumeric(medExpense.getMa_backdt_mo_1_ind())) {
						retro = new RetroMedical();
						retro.setEffectiveMonth(BuildIncomeTypeMappingHelper.addMonths(1));
						retroList.add(retro);
					}
					if(medExpense.getMa_backdt_mo_2_ind() != null && StringUtils.isNumeric(medExpense.getMa_backdt_mo_2_ind())) {
						retro = new RetroMedical();
						retro.setEffectiveMonth(BuildIncomeTypeMappingHelper.addMonths(1));
						retroList.add(retro);
						retro = new RetroMedical();
						retro.setEffectiveMonth(BuildIncomeTypeMappingHelper.addMonths(2));
						retroList.add(retro);
					}
					if(medExpense.getMa_backdt_mo_3_ind() != null && StringUtils.isNumeric(medExpense.getMa_backdt_mo_3_ind())) {
						retro = new RetroMedical();
						retro.setEffectiveMonth(BuildIncomeTypeMappingHelper.addMonths(1));
						retroList.add(retro);
						retro = new RetroMedical();
						retro.setEffectiveMonth(BuildIncomeTypeMappingHelper.addMonths(2));
						retroList.add(retro);
						retro = new RetroMedical();
						retro.setEffectiveMonth(BuildIncomeTypeMappingHelper.addMonths(3));
						retroList.add(retro);
					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildMedicalBillsDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while getRetroDetails::" + e.getMessage());
		}
		return retroList;
	}
	
	public static void setIhssDetails(AggregatedPayload source, int indvSeqNum, Applicant iHSSIndv) {
		List<CP_APP_IN_MED_BILLS> indvMedExpenses = null;
		List<CP_APP_IN_MED_BILLS> medExpenseList = null;

		try {
			medExpenseList = source.getFinancialExpenseSummaryDetails().getPageCollection().getCP_APP_IN_MED_BILLS();

			if(medExpenseList !=null && !medExpenseList.isEmpty()) {
				indvMedExpenses = medExpenseList.stream().filter(indv->indvSeqNum==indv.getIndv_seq_num()).collect(Collectors.toList());

				for(CP_APP_IN_MED_BILLS medExpense : indvMedExpenses) {
					if(ApplicationSubmissionConstants.STR_HS.equalsIgnoreCase(medExpense.getMed_bill_type())) {
						iHSSIndv.setIhssInd(true);
						iHSSIndv.setIhssMonthlyCost(medExpense.getPayment_amt());
					}
				}
			}
		}catch (Exception e) {
			FwLogger.log(BuildMedicalBillsDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while setIhssDetails::" + e.getMessage());
		}
	}
		
}
