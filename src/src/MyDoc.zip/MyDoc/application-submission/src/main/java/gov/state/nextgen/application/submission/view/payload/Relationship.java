package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class Relationship {
	private int persID;
	private int pers2ID;
	private String typeCode;
	private Boolean parentOutOfHomeInd;
	private Boolean parentUnemployedInd;
	private Boolean parentDisabledInd;
	private Boolean parentDeceasedInd;
	private Boolean parentNoneInd;

	public int getPersID() {
		return persID;
	}

	public void setPersID(int persID) {
		this.persID = persID;
	}

	public int getPers2ID() {
		return pers2ID;
	}

	public void setPers2ID(int pers2id) {
		pers2ID = pers2id;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public Boolean isParentOutOfHomeInd() {
		return parentOutOfHomeInd;
	}

	public void setParentOutOfHomeInd(Boolean parentOutOfHomeInd) {
		this.parentOutOfHomeInd = parentOutOfHomeInd;
	}

	public Boolean isParentUnemployedInd() {
		return parentUnemployedInd;
	}

	public void setParentUnemployedInd(Boolean parentUnemployedInd) {
		this.parentUnemployedInd = parentUnemployedInd;
	}

	public Boolean isParentDisabledInd() {
		return parentDisabledInd;
	}

	public void setParentDisabledInd(Boolean parentDisabledInd) {
		this.parentDisabledInd = parentDisabledInd;
	}

	public Boolean isParentDeceasedInd() {
		return parentDeceasedInd;
	}

	public void setParentDeceasedInd(Boolean parentDeceasedInd) {
		this.parentDeceasedInd = parentDeceasedInd;
	}

	public Boolean isParentNoneInd() {
		return parentNoneInd;
	}

	public void setParentNoneInd(Boolean parentNoneInd) {
		this.parentNoneInd = parentNoneInd;
	}
}
