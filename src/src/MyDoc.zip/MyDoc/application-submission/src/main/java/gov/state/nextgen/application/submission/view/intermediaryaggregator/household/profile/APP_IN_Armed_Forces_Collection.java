package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class APP_IN_Armed_Forces_Collection{
    private String user;
    private String cargoName;
    private String rowAction;
    private String adaptRecordId;
    private String delete_reason_cd;
    private String app_num;
    private int indv_seq_num;
    private String src_app_ind;
    private String aln_sponser_sw;
    private String unable_meal_dabl_sw;
    private boolean maFlag;
    private boolean snapFlag;
    private boolean tanfFlag;
    private String looping_ind;
    private String showLoopingQuestionSection;
    private String brth_dt;
    private String fst_nam;
    private String intn_res_resp;
    private String lang_cd;
    private String last_nam;
    private String live_arng_typ;
    private String mid_init;
    private String place_of_birth_city;
    private String place_of_birth_state;
    private String place_of_birth_country;
    private String mig_farm_wrkr_sw;
    private String mrtl_stat_cd;
    private String preg_resp;
    private String prim_prsn_sw;
    private int rec_cplt_ind;
    private String res_wi_sw;
    private int rlvn_ind;
    private String sex_ind;
    private String ss_num_app_dt;
    private String ssn_num;
    private String us_ctzn_sw;
    private String ai_ind;
    private String asia_ind;
    private String blk_ind;
    private String hspc_ind;
    private String pac_isl_ind;
    private String wht_ind;
    private String chld_out_home_resp;
    private String chld_trb_mbr_resp;
    private String trb_mbr_resp;
    private String non_hspc_ind;
    private String dt_leave_facty;
    private String vet_resp;
    private String vet_act_duty_resp;
    private String sps_deceased_vet_resp;
    private String chld_deceased_vet_resp;
    private String disable_vet_resp;
    private String job_commitment_resp;
    private String qualified_alien_sw;
    private String unknown_ind;
    private String left_home_reason_cd;
    private String absence_reason_cd;
    private String alien_num;
    private String alien_status_cd;
    private String entry_into_us_dt;
    private String exp_back_at_home_dt;
    private String left_home_dt;
    private String out_home_resp;
    private String people_in_home_ct;
    private String place_of_birth_cd;
    private String res_va_sw;
    private String suffix_name;
    private String tribe_cd;
    private String snap_ind;
    private String tanf_ind;
    private String ma_ind;
    private String living_arrangement_cd;
    private String req_interp_ind;
    private String comm_asst_sl_interp_ind;
    private String comm_asst_tty_ind;
    private String comm_asst_lg_print_ind;
    private String comm_asst_email_ind;
    private String comm_asst_none_ind;
    private String comm_asst_oth_ind;
    private String comm_asst_oth_dsc;
    private String res_ga_ind;
    private String cc_ind;
    private String wic_ind;
    private String liheap_ind;
    private String alias_ind;
    private String alias_fst_nam;
    private String alias_last_nam;
    private String alias_mid_nam;
    private String alias_suffix_name;
    private String hspc_dsc_cd;
    private String sexual_orientation;
    private String tribe_name;
    private String blnd_dabl_ind;
    private String parent_act_duty_resp;
    private String alien_doc_type_cd;
    private String race_white_ind;
    private String race_ai_an_ind;
    private String race_filipino_ind;
    private String race_vie_ind;
    private String race_guam_ind;
    private String race_afam_ind;
    private String race_asian_indian_ind;
    private String race_japanese_ind;
    private String race_oth_asian_ind;
    private String race_samoan_ind;
    private String race_chinese_ind;
    private String race_korean_ind;
    private String race_nhpi_ind;
    private String race_oth_pi_ind;
    private String race_oth_ind;
    private String race_oth_dsc;
    private String race_memb_fed_rec_trb_ind;
    private String live_at_same_addr_ind;
    private String alias_mid_init;
    private String tax_joint_file_ind;
    private String lang_oth_dsc;
    private String tax_dp_outside_home_ind;
    private String alien_doc_cd;
    private String chld_pa_act_duty_resp;
    private String race_cd;
    private String comm_asst_baille_ind;
    private String comm_asst_vedrel_ind;
    private String inter_oth_dsc;
    private String brst_cer_cancer_diag_ind;
    private String brst_cer_cancer_diag_dt;
    private String if_out_arrangement;
    private String ssn_info_ack_ind;
    private String comm_asst_fl_interp_ind;
    private String us_ctzn_fed_hub_ind;
    private String ssn_vrfn_fed_hub_ind;
    private String ecp_id;
    private String dob_fed_hub_ind;
    private String unearned_inc_fed_hub_ind;
    private String unearned_inc_dol_ind;
    private String earned_inc_dol_ind;
    private String earned_inc_wrk_num_ind;
    private String tax_filing_status;
    private String bst_cncr_ecp_id;
    private String race_persian_ind;
    private String race_eastasian_ind;
    private String race_unknown_ind;
    private String citizenVerifyInd;
    private String vld_immgrtn_sts;
    private String chg_dt;
    private String wic_clnc_cnty;
    private String wic_clnc_cd;
    private String tax_flr_otsd_ind;
    private String is_wic_clnc_info_new;
    private String is_child_needs_care;
    private String is_food_program;
    private String is_foster_care;
    private String is_leaving_CA;
    private String is_foster_child;
    private String disabled_resp;
    private String lang_cd_sp;
    private String alias_oth_nam;
    private String estb_dabl_resp;
    private String estb_deaf_resp;
    private String former_foster_from_dt;
    private String former_foster_to_dt;
    private String former_foster_state;
    private String in_foster_eighteenth_brth_ind;
    private String oth_hhm_care_desc;
    private String vet_dep_resp;
    private String vet_hon_discharge_ind;
    private String vet_serv_from_dt;
    private String vet_serv_to_dt;
    private String childcareIndividuals;
    private String foster_court_ord_dep_ind;
    private String foster_incl_calfresh_ind;
    private String asg_sex;
    private String ssn_applied_sw;
    private String no_ssn_reason;
    private String ssn_other_reason_desc;
    private String ssn_num_ind;
    private String ssn_absence_reason_cd;
    private String alien_doc_num;
    private String lived_in_us_con_sw;
    private String naturalized_ctzn_ind;
    private String spnsr_ctzn_ind;
    private String spnsr_i134_sign_sw;
    private String spnsr_i864_sign_sw;
    private String spnsr_phn_num;
    private String spnsr_help_sw;
    private String spnsr_amt;
    private String spnsr_rent_sw;
    private String spnsr_clothes_sw;
    private String spnsr_food_sw;
    private String spnsr_other_sw;
    private String hspc_oth_dsc;
    private String race_pref_ind;
    private String ethnicity_cd;
    private String recv_srvc_sw;
    private String jpd_ind;
    private String jpd_oth_desc;
    private String imm_wrk_hist_ind;
    private String imm_plan_ind;
    private String imm_status_value;
    private String spnsr_first_name;
    private String spnsr_last_name;
    private String spnsr_other_explanation;
    private String pers_info_change_desc;
    private String leaving_ca_rsn_desc;
    private String eligible_hs_ind;
    private String dt_entry_into_us;
    private String decease_dt;
    private String ca_ret_ind;
    private String ca_pland_ret_dt;
    private String ca_leave_thirty_ind;
    private String ca_dep_dt;
    private String estb_blnd_resp;
    private String imm_status_chg_dt;
    private String place_of_birth_reason;
    private String vaccine_ind;
    private String school_type_ind;
    private String moved_in_dt;
    private String res_la_sw;
    private String parent_status;
    private String other_food_program_name;
    private String age;
    private String other_food_program_name_desc;
    private String childcareArray;
    private String cinNumber;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getAln_sponser_sw() {
		return aln_sponser_sw;
	}
	public void setAln_sponser_sw(String aln_sponser_sw) {
		this.aln_sponser_sw = aln_sponser_sw;
	}
	public String getUnable_meal_dabl_sw() {
		return unable_meal_dabl_sw;
	}
	public void setUnable_meal_dabl_sw(String unable_meal_dabl_sw) {
		this.unable_meal_dabl_sw = unable_meal_dabl_sw;
	}
	public boolean isMaFlag() {
		return maFlag;
	}
	public void setMaFlag(boolean maFlag) {
		this.maFlag = maFlag;
	}
	public boolean isSnapFlag() {
		return snapFlag;
	}
	public void setSnapFlag(boolean snapFlag) {
		this.snapFlag = snapFlag;
	}
	public boolean isTanfFlag() {
		return tanfFlag;
	}
	public void setTanfFlag(boolean tanfFlag) {
		this.tanfFlag = tanfFlag;
	}
	public String getLooping_ind() {
		return looping_ind;
	}
	public void setLooping_ind(String looping_ind) {
		this.looping_ind = looping_ind;
	}
	public String getShowLoopingQuestionSection() {
		return showLoopingQuestionSection;
	}
	public void setShowLoopingQuestionSection(String showLoopingQuestionSection) {
		this.showLoopingQuestionSection = showLoopingQuestionSection;
	}
	public String getBrth_dt() {
		return brth_dt;
	}
	public void setBrth_dt(String brth_dt) {
		this.brth_dt = brth_dt;
	}
	public String getFst_nam() {
		return fst_nam;
	}
	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}
	public String getIntn_res_resp() {
		return intn_res_resp;
	}
	public void setIntn_res_resp(String intn_res_resp) {
		this.intn_res_resp = intn_res_resp;
	}
	public String getLang_cd() {
		return lang_cd;
	}
	public void setLang_cd(String lang_cd) {
		this.lang_cd = lang_cd;
	}
	public String getLast_nam() {
		return last_nam;
	}
	public void setLast_nam(String last_nam) {
		this.last_nam = last_nam;
	}
	public String getLive_arng_typ() {
		return live_arng_typ;
	}
	public void setLive_arng_typ(String live_arng_typ) {
		this.live_arng_typ = live_arng_typ;
	}
	public String getMid_init() {
		return mid_init;
	}
	public void setMid_init(String mid_init) {
		this.mid_init = mid_init;
	}
	public String getPlace_of_birth_city() {
		return place_of_birth_city;
	}
	public void setPlace_of_birth_city(String place_of_birth_city) {
		this.place_of_birth_city = place_of_birth_city;
	}
	public String getPlace_of_birth_state() {
		return place_of_birth_state;
	}
	public void setPlace_of_birth_state(String place_of_birth_state) {
		this.place_of_birth_state = place_of_birth_state;
	}
	public String getPlace_of_birth_country() {
		return place_of_birth_country;
	}
	public void setPlace_of_birth_country(String place_of_birth_country) {
		this.place_of_birth_country = place_of_birth_country;
	}
	public String getMig_farm_wrkr_sw() {
		return mig_farm_wrkr_sw;
	}
	public void setMig_farm_wrkr_sw(String mig_farm_wrkr_sw) {
		this.mig_farm_wrkr_sw = mig_farm_wrkr_sw;
	}
	public String getMrtl_stat_cd() {
		return mrtl_stat_cd;
	}
	public void setMrtl_stat_cd(String mrtl_stat_cd) {
		this.mrtl_stat_cd = mrtl_stat_cd;
	}
	public String getPreg_resp() {
		return preg_resp;
	}
	public void setPreg_resp(String preg_resp) {
		this.preg_resp = preg_resp;
	}
	public String getPrim_prsn_sw() {
		return prim_prsn_sw;
	}
	public void setPrim_prsn_sw(String prim_prsn_sw) {
		this.prim_prsn_sw = prim_prsn_sw;
	}
	public int getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(int rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getRes_wi_sw() {
		return res_wi_sw;
	}
	public void setRes_wi_sw(String res_wi_sw) {
		this.res_wi_sw = res_wi_sw;
	}
	public int getRlvn_ind() {
		return rlvn_ind;
	}
	public void setRlvn_ind(int rlvn_ind) {
		this.rlvn_ind = rlvn_ind;
	}
	public String getSex_ind() {
		return sex_ind;
	}
	public void setSex_ind(String sex_ind) {
		this.sex_ind = sex_ind;
	}
	public String getSs_num_app_dt() {
		return ss_num_app_dt;
	}
	public void setSs_num_app_dt(String ss_num_app_dt) {
		this.ss_num_app_dt = ss_num_app_dt;
	}
	public String getSsn_num() {
		return ssn_num;
	}
	public void setSsn_num(String ssn_num) {
		this.ssn_num = ssn_num;
	}
	public String getUs_ctzn_sw() {
		return us_ctzn_sw;
	}
	public void setUs_ctzn_sw(String us_ctzn_sw) {
		this.us_ctzn_sw = us_ctzn_sw;
	}
	public String getAi_ind() {
		return ai_ind;
	}
	public void setAi_ind(String ai_ind) {
		this.ai_ind = ai_ind;
	}
	public String getAsia_ind() {
		return asia_ind;
	}
	public void setAsia_ind(String asia_ind) {
		this.asia_ind = asia_ind;
	}
	public String getBlk_ind() {
		return blk_ind;
	}
	public void setBlk_ind(String blk_ind) {
		this.blk_ind = blk_ind;
	}
	public String getHspc_ind() {
		return hspc_ind;
	}
	public void setHspc_ind(String hspc_ind) {
		this.hspc_ind = hspc_ind;
	}
	public String getPac_isl_ind() {
		return pac_isl_ind;
	}
	public void setPac_isl_ind(String pac_isl_ind) {
		this.pac_isl_ind = pac_isl_ind;
	}
	public String getWht_ind() {
		return wht_ind;
	}
	public void setWht_ind(String wht_ind) {
		this.wht_ind = wht_ind;
	}
	public String getChld_out_home_resp() {
		return chld_out_home_resp;
	}
	public void setChld_out_home_resp(String chld_out_home_resp) {
		this.chld_out_home_resp = chld_out_home_resp;
	}
	public String getChld_trb_mbr_resp() {
		return chld_trb_mbr_resp;
	}
	public void setChld_trb_mbr_resp(String chld_trb_mbr_resp) {
		this.chld_trb_mbr_resp = chld_trb_mbr_resp;
	}
	public String getTrb_mbr_resp() {
		return trb_mbr_resp;
	}
	public void setTrb_mbr_resp(String trb_mbr_resp) {
		this.trb_mbr_resp = trb_mbr_resp;
	}
	public String getNon_hspc_ind() {
		return non_hspc_ind;
	}
	public void setNon_hspc_ind(String non_hspc_ind) {
		this.non_hspc_ind = non_hspc_ind;
	}
	public String getDt_leave_facty() {
		return dt_leave_facty;
	}
	public void setDt_leave_facty(String dt_leave_facty) {
		this.dt_leave_facty = dt_leave_facty;
	}
	public String getVet_resp() {
		return vet_resp;
	}
	public void setVet_resp(String vet_resp) {
		this.vet_resp = vet_resp;
	}
	public String getVet_act_duty_resp() {
		return vet_act_duty_resp;
	}
	public void setVet_act_duty_resp(String vet_act_duty_resp) {
		this.vet_act_duty_resp = vet_act_duty_resp;
	}
	public String getSps_deceased_vet_resp() {
		return sps_deceased_vet_resp;
	}
	public void setSps_deceased_vet_resp(String sps_deceased_vet_resp) {
		this.sps_deceased_vet_resp = sps_deceased_vet_resp;
	}
	public String getChld_deceased_vet_resp() {
		return chld_deceased_vet_resp;
	}
	public void setChld_deceased_vet_resp(String chld_deceased_vet_resp) {
		this.chld_deceased_vet_resp = chld_deceased_vet_resp;
	}
	public String getDisable_vet_resp() {
		return disable_vet_resp;
	}
	public void setDisable_vet_resp(String disable_vet_resp) {
		this.disable_vet_resp = disable_vet_resp;
	}
	public String getJob_commitment_resp() {
		return job_commitment_resp;
	}
	public void setJob_commitment_resp(String job_commitment_resp) {
		this.job_commitment_resp = job_commitment_resp;
	}
	public String getQualified_alien_sw() {
		return qualified_alien_sw;
	}
	public void setQualified_alien_sw(String qualified_alien_sw) {
		this.qualified_alien_sw = qualified_alien_sw;
	}
	public String getUnknown_ind() {
		return unknown_ind;
	}
	public void setUnknown_ind(String unknown_ind) {
		this.unknown_ind = unknown_ind;
	}
	public String getLeft_home_reason_cd() {
		return left_home_reason_cd;
	}
	public void setLeft_home_reason_cd(String left_home_reason_cd) {
		this.left_home_reason_cd = left_home_reason_cd;
	}
	public String getAbsence_reason_cd() {
		return absence_reason_cd;
	}
	public void setAbsence_reason_cd(String absence_reason_cd) {
		this.absence_reason_cd = absence_reason_cd;
	}
	public String getAlien_num() {
		return alien_num;
	}
	public void setAlien_num(String alien_num) {
		this.alien_num = alien_num;
	}
	public String getAlien_status_cd() {
		return alien_status_cd;
	}
	public void setAlien_status_cd(String alien_status_cd) {
		this.alien_status_cd = alien_status_cd;
	}
	public String getEntry_into_us_dt() {
		return entry_into_us_dt;
	}
	public void setEntry_into_us_dt(String entry_into_us_dt) {
		this.entry_into_us_dt = entry_into_us_dt;
	}
	public String getExp_back_at_home_dt() {
		return exp_back_at_home_dt;
	}
	public void setExp_back_at_home_dt(String exp_back_at_home_dt) {
		this.exp_back_at_home_dt = exp_back_at_home_dt;
	}
	public String getLeft_home_dt() {
		return left_home_dt;
	}
	public void setLeft_home_dt(String left_home_dt) {
		this.left_home_dt = left_home_dt;
	}
	public String getOut_home_resp() {
		return out_home_resp;
	}
	public void setOut_home_resp(String out_home_resp) {
		this.out_home_resp = out_home_resp;
	}
	public String getPeople_in_home_ct() {
		return people_in_home_ct;
	}
	public void setPeople_in_home_ct(String people_in_home_ct) {
		this.people_in_home_ct = people_in_home_ct;
	}
	public String getPlace_of_birth_cd() {
		return place_of_birth_cd;
	}
	public void setPlace_of_birth_cd(String place_of_birth_cd) {
		this.place_of_birth_cd = place_of_birth_cd;
	}
	public String getRes_va_sw() {
		return res_va_sw;
	}
	public void setRes_va_sw(String res_va_sw) {
		this.res_va_sw = res_va_sw;
	}
	public String getSuffix_name() {
		return suffix_name;
	}
	public void setSuffix_name(String suffix_name) {
		this.suffix_name = suffix_name;
	}
	public String getTribe_cd() {
		return tribe_cd;
	}
	public void setTribe_cd(String tribe_cd) {
		this.tribe_cd = tribe_cd;
	}
	public String getSnap_ind() {
		return snap_ind;
	}
	public void setSnap_ind(String snap_ind) {
		this.snap_ind = snap_ind;
	}
	public String getTanf_ind() {
		return tanf_ind;
	}
	public void setTanf_ind(String tanf_ind) {
		this.tanf_ind = tanf_ind;
	}
	public String getMa_ind() {
		return ma_ind;
	}
	public void setMa_ind(String ma_ind) {
		this.ma_ind = ma_ind;
	}
	public String getLiving_arrangement_cd() {
		return living_arrangement_cd;
	}
	public void setLiving_arrangement_cd(String living_arrangement_cd) {
		this.living_arrangement_cd = living_arrangement_cd;
	}
	public String getReq_interp_ind() {
		return req_interp_ind;
	}
	public void setReq_interp_ind(String req_interp_ind) {
		this.req_interp_ind = req_interp_ind;
	}
	public String getComm_asst_sl_interp_ind() {
		return comm_asst_sl_interp_ind;
	}
	public void setComm_asst_sl_interp_ind(String comm_asst_sl_interp_ind) {
		this.comm_asst_sl_interp_ind = comm_asst_sl_interp_ind;
	}
	public String getComm_asst_tty_ind() {
		return comm_asst_tty_ind;
	}
	public void setComm_asst_tty_ind(String comm_asst_tty_ind) {
		this.comm_asst_tty_ind = comm_asst_tty_ind;
	}
	public String getComm_asst_lg_print_ind() {
		return comm_asst_lg_print_ind;
	}
	public void setComm_asst_lg_print_ind(String comm_asst_lg_print_ind) {
		this.comm_asst_lg_print_ind = comm_asst_lg_print_ind;
	}
	public String getComm_asst_email_ind() {
		return comm_asst_email_ind;
	}
	public void setComm_asst_email_ind(String comm_asst_email_ind) {
		this.comm_asst_email_ind = comm_asst_email_ind;
	}
	public String getComm_asst_none_ind() {
		return comm_asst_none_ind;
	}
	public void setComm_asst_none_ind(String comm_asst_none_ind) {
		this.comm_asst_none_ind = comm_asst_none_ind;
	}
	public String getComm_asst_oth_ind() {
		return comm_asst_oth_ind;
	}
	public void setComm_asst_oth_ind(String comm_asst_oth_ind) {
		this.comm_asst_oth_ind = comm_asst_oth_ind;
	}
	public String getComm_asst_oth_dsc() {
		return comm_asst_oth_dsc;
	}
	public void setComm_asst_oth_dsc(String comm_asst_oth_dsc) {
		this.comm_asst_oth_dsc = comm_asst_oth_dsc;
	}
	public String getRes_ga_ind() {
		return res_ga_ind;
	}
	public void setRes_ga_ind(String res_ga_ind) {
		this.res_ga_ind = res_ga_ind;
	}
	public String getCc_ind() {
		return cc_ind;
	}
	public void setCc_ind(String cc_ind) {
		this.cc_ind = cc_ind;
	}
	public String getWic_ind() {
		return wic_ind;
	}
	public void setWic_ind(String wic_ind) {
		this.wic_ind = wic_ind;
	}
	public String getLiheap_ind() {
		return liheap_ind;
	}
	public void setLiheap_ind(String liheap_ind) {
		this.liheap_ind = liheap_ind;
	}
	public String getAlias_ind() {
		return alias_ind;
	}
	public void setAlias_ind(String alias_ind) {
		this.alias_ind = alias_ind;
	}
	public String getAlias_fst_nam() {
		return alias_fst_nam;
	}
	public void setAlias_fst_nam(String alias_fst_nam) {
		this.alias_fst_nam = alias_fst_nam;
	}
	public String getAlias_last_nam() {
		return alias_last_nam;
	}
	public void setAlias_last_nam(String alias_last_nam) {
		this.alias_last_nam = alias_last_nam;
	}
	public String getAlias_mid_nam() {
		return alias_mid_nam;
	}
	public void setAlias_mid_nam(String alias_mid_nam) {
		this.alias_mid_nam = alias_mid_nam;
	}
	public String getAlias_suffix_name() {
		return alias_suffix_name;
	}
	public void setAlias_suffix_name(String alias_suffix_name) {
		this.alias_suffix_name = alias_suffix_name;
	}
	public String getHspc_dsc_cd() {
		return hspc_dsc_cd;
	}
	public void setHspc_dsc_cd(String hspc_dsc_cd) {
		this.hspc_dsc_cd = hspc_dsc_cd;
	}
	public String getSexual_orientation() {
		return sexual_orientation;
	}
	public void setSexual_orientation(String sexual_orientation) {
		this.sexual_orientation = sexual_orientation;
	}
	public String getTribe_name() {
		return tribe_name;
	}
	public void setTribe_name(String tribe_name) {
		this.tribe_name = tribe_name;
	}
	public String getBlnd_dabl_ind() {
		return blnd_dabl_ind;
	}
	public void setBlnd_dabl_ind(String blnd_dabl_ind) {
		this.blnd_dabl_ind = blnd_dabl_ind;
	}
	public String getParent_act_duty_resp() {
		return parent_act_duty_resp;
	}
	public void setParent_act_duty_resp(String parent_act_duty_resp) {
		this.parent_act_duty_resp = parent_act_duty_resp;
	}
	public String getAlien_doc_type_cd() {
		return alien_doc_type_cd;
	}
	public void setAlien_doc_type_cd(String alien_doc_type_cd) {
		this.alien_doc_type_cd = alien_doc_type_cd;
	}
	public String getRace_white_ind() {
		return race_white_ind;
	}
	public void setRace_white_ind(String race_white_ind) {
		this.race_white_ind = race_white_ind;
	}
	public String getRace_ai_an_ind() {
		return race_ai_an_ind;
	}
	public void setRace_ai_an_ind(String race_ai_an_ind) {
		this.race_ai_an_ind = race_ai_an_ind;
	}
	public String getRace_filipino_ind() {
		return race_filipino_ind;
	}
	public void setRace_filipino_ind(String race_filipino_ind) {
		this.race_filipino_ind = race_filipino_ind;
	}
	public String getRace_vie_ind() {
		return race_vie_ind;
	}
	public void setRace_vie_ind(String race_vie_ind) {
		this.race_vie_ind = race_vie_ind;
	}
	public String getRace_guam_ind() {
		return race_guam_ind;
	}
	public void setRace_guam_ind(String race_guam_ind) {
		this.race_guam_ind = race_guam_ind;
	}
	public String getRace_afam_ind() {
		return race_afam_ind;
	}
	public void setRace_afam_ind(String race_afam_ind) {
		this.race_afam_ind = race_afam_ind;
	}
	public String getRace_asian_indian_ind() {
		return race_asian_indian_ind;
	}
	public void setRace_asian_indian_ind(String race_asian_indian_ind) {
		this.race_asian_indian_ind = race_asian_indian_ind;
	}
	public String getRace_japanese_ind() {
		return race_japanese_ind;
	}
	public void setRace_japanese_ind(String race_japanese_ind) {
		this.race_japanese_ind = race_japanese_ind;
	}
	public String getRace_oth_asian_ind() {
		return race_oth_asian_ind;
	}
	public void setRace_oth_asian_ind(String race_oth_asian_ind) {
		this.race_oth_asian_ind = race_oth_asian_ind;
	}
	public String getRace_samoan_ind() {
		return race_samoan_ind;
	}
	public void setRace_samoan_ind(String race_samoan_ind) {
		this.race_samoan_ind = race_samoan_ind;
	}
	public String getRace_chinese_ind() {
		return race_chinese_ind;
	}
	public void setRace_chinese_ind(String race_chinese_ind) {
		this.race_chinese_ind = race_chinese_ind;
	}
	public String getRace_korean_ind() {
		return race_korean_ind;
	}
	public void setRace_korean_ind(String race_korean_ind) {
		this.race_korean_ind = race_korean_ind;
	}
	public String getRace_nhpi_ind() {
		return race_nhpi_ind;
	}
	public void setRace_nhpi_ind(String race_nhpi_ind) {
		this.race_nhpi_ind = race_nhpi_ind;
	}
	public String getRace_oth_pi_ind() {
		return race_oth_pi_ind;
	}
	public void setRace_oth_pi_ind(String race_oth_pi_ind) {
		this.race_oth_pi_ind = race_oth_pi_ind;
	}
	public String getRace_oth_ind() {
		return race_oth_ind;
	}
	public void setRace_oth_ind(String race_oth_ind) {
		this.race_oth_ind = race_oth_ind;
	}
	public String getRace_oth_dsc() {
		return race_oth_dsc;
	}
	public void setRace_oth_dsc(String race_oth_dsc) {
		this.race_oth_dsc = race_oth_dsc;
	}
	public String getRace_memb_fed_rec_trb_ind() {
		return race_memb_fed_rec_trb_ind;
	}
	public void setRace_memb_fed_rec_trb_ind(String race_memb_fed_rec_trb_ind) {
		this.race_memb_fed_rec_trb_ind = race_memb_fed_rec_trb_ind;
	}
	public String getLive_at_same_addr_ind() {
		return live_at_same_addr_ind;
	}
	public void setLive_at_same_addr_ind(String live_at_same_addr_ind) {
		this.live_at_same_addr_ind = live_at_same_addr_ind;
	}
	public String getAlias_mid_init() {
		return alias_mid_init;
	}
	public void setAlias_mid_init(String alias_mid_init) {
		this.alias_mid_init = alias_mid_init;
	}
	public String getTax_joint_file_ind() {
		return tax_joint_file_ind;
	}
	public void setTax_joint_file_ind(String tax_joint_file_ind) {
		this.tax_joint_file_ind = tax_joint_file_ind;
	}
	public String getLang_oth_dsc() {
		return lang_oth_dsc;
	}
	public void setLang_oth_dsc(String lang_oth_dsc) {
		this.lang_oth_dsc = lang_oth_dsc;
	}
	public String getTax_dp_outside_home_ind() {
		return tax_dp_outside_home_ind;
	}
	public void setTax_dp_outside_home_ind(String tax_dp_outside_home_ind) {
		this.tax_dp_outside_home_ind = tax_dp_outside_home_ind;
	}
	public String getAlien_doc_cd() {
		return alien_doc_cd;
	}
	public void setAlien_doc_cd(String alien_doc_cd) {
		this.alien_doc_cd = alien_doc_cd;
	}
	public String getChld_pa_act_duty_resp() {
		return chld_pa_act_duty_resp;
	}
	public void setChld_pa_act_duty_resp(String chld_pa_act_duty_resp) {
		this.chld_pa_act_duty_resp = chld_pa_act_duty_resp;
	}
	public String getRace_cd() {
		return race_cd;
	}
	public void setRace_cd(String race_cd) {
		this.race_cd = race_cd;
	}
	public String getComm_asst_baille_ind() {
		return comm_asst_baille_ind;
	}
	public void setComm_asst_baille_ind(String comm_asst_baille_ind) {
		this.comm_asst_baille_ind = comm_asst_baille_ind;
	}
	public String getComm_asst_vedrel_ind() {
		return comm_asst_vedrel_ind;
	}
	public void setComm_asst_vedrel_ind(String comm_asst_vedrel_ind) {
		this.comm_asst_vedrel_ind = comm_asst_vedrel_ind;
	}
	public String getInter_oth_dsc() {
		return inter_oth_dsc;
	}
	public void setInter_oth_dsc(String inter_oth_dsc) {
		this.inter_oth_dsc = inter_oth_dsc;
	}
	public String getBrst_cer_cancer_diag_ind() {
		return brst_cer_cancer_diag_ind;
	}
	public void setBrst_cer_cancer_diag_ind(String brst_cer_cancer_diag_ind) {
		this.brst_cer_cancer_diag_ind = brst_cer_cancer_diag_ind;
	}
	public String getBrst_cer_cancer_diag_dt() {
		return brst_cer_cancer_diag_dt;
	}
	public void setBrst_cer_cancer_diag_dt(String brst_cer_cancer_diag_dt) {
		this.brst_cer_cancer_diag_dt = brst_cer_cancer_diag_dt;
	}
	public String getIf_out_arrangement() {
		return if_out_arrangement;
	}
	public void setIf_out_arrangement(String if_out_arrangement) {
		this.if_out_arrangement = if_out_arrangement;
	}
	public String getSsn_info_ack_ind() {
		return ssn_info_ack_ind;
	}
	public void setSsn_info_ack_ind(String ssn_info_ack_ind) {
		this.ssn_info_ack_ind = ssn_info_ack_ind;
	}
	public String getComm_asst_fl_interp_ind() {
		return comm_asst_fl_interp_ind;
	}
	public void setComm_asst_fl_interp_ind(String comm_asst_fl_interp_ind) {
		this.comm_asst_fl_interp_ind = comm_asst_fl_interp_ind;
	}
	public String getUs_ctzn_fed_hub_ind() {
		return us_ctzn_fed_hub_ind;
	}
	public void setUs_ctzn_fed_hub_ind(String us_ctzn_fed_hub_ind) {
		this.us_ctzn_fed_hub_ind = us_ctzn_fed_hub_ind;
	}
	public String getSsn_vrfn_fed_hub_ind() {
		return ssn_vrfn_fed_hub_ind;
	}
	public void setSsn_vrfn_fed_hub_ind(String ssn_vrfn_fed_hub_ind) {
		this.ssn_vrfn_fed_hub_ind = ssn_vrfn_fed_hub_ind;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getDob_fed_hub_ind() {
		return dob_fed_hub_ind;
	}
	public void setDob_fed_hub_ind(String dob_fed_hub_ind) {
		this.dob_fed_hub_ind = dob_fed_hub_ind;
	}
	public String getUnearned_inc_fed_hub_ind() {
		return unearned_inc_fed_hub_ind;
	}
	public void setUnearned_inc_fed_hub_ind(String unearned_inc_fed_hub_ind) {
		this.unearned_inc_fed_hub_ind = unearned_inc_fed_hub_ind;
	}
	public String getUnearned_inc_dol_ind() {
		return unearned_inc_dol_ind;
	}
	public void setUnearned_inc_dol_ind(String unearned_inc_dol_ind) {
		this.unearned_inc_dol_ind = unearned_inc_dol_ind;
	}
	public String getEarned_inc_dol_ind() {
		return earned_inc_dol_ind;
	}
	public void setEarned_inc_dol_ind(String earned_inc_dol_ind) {
		this.earned_inc_dol_ind = earned_inc_dol_ind;
	}
	public String getEarned_inc_wrk_num_ind() {
		return earned_inc_wrk_num_ind;
	}
	public void setEarned_inc_wrk_num_ind(String earned_inc_wrk_num_ind) {
		this.earned_inc_wrk_num_ind = earned_inc_wrk_num_ind;
	}
	public String getTax_filing_status() {
		return tax_filing_status;
	}
	public void setTax_filing_status(String tax_filing_status) {
		this.tax_filing_status = tax_filing_status;
	}
	public String getBst_cncr_ecp_id() {
		return bst_cncr_ecp_id;
	}
	public void setBst_cncr_ecp_id(String bst_cncr_ecp_id) {
		this.bst_cncr_ecp_id = bst_cncr_ecp_id;
	}
	public String getRace_persian_ind() {
		return race_persian_ind;
	}
	public void setRace_persian_ind(String race_persian_ind) {
		this.race_persian_ind = race_persian_ind;
	}
	public String getRace_eastasian_ind() {
		return race_eastasian_ind;
	}
	public void setRace_eastasian_ind(String race_eastasian_ind) {
		this.race_eastasian_ind = race_eastasian_ind;
	}
	public String getRace_unknown_ind() {
		return race_unknown_ind;
	}
	public void setRace_unknown_ind(String race_unknown_ind) {
		this.race_unknown_ind = race_unknown_ind;
	}
	public String getCitizenVerifyInd() {
		return citizenVerifyInd;
	}
	public void setCitizenVerifyInd(String citizenVerifyInd) {
		this.citizenVerifyInd = citizenVerifyInd;
	}
	public String getVld_immgrtn_sts() {
		return vld_immgrtn_sts;
	}
	public void setVld_immgrtn_sts(String vld_immgrtn_sts) {
		this.vld_immgrtn_sts = vld_immgrtn_sts;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getWic_clnc_cnty() {
		return wic_clnc_cnty;
	}
	public void setWic_clnc_cnty(String wic_clnc_cnty) {
		this.wic_clnc_cnty = wic_clnc_cnty;
	}
	public String getWic_clnc_cd() {
		return wic_clnc_cd;
	}
	public void setWic_clnc_cd(String wic_clnc_cd) {
		this.wic_clnc_cd = wic_clnc_cd;
	}
	public String getTax_flr_otsd_ind() {
		return tax_flr_otsd_ind;
	}
	public void setTax_flr_otsd_ind(String tax_flr_otsd_ind) {
		this.tax_flr_otsd_ind = tax_flr_otsd_ind;
	}
	public String getIs_wic_clnc_info_new() {
		return is_wic_clnc_info_new;
	}
	public void setIs_wic_clnc_info_new(String is_wic_clnc_info_new) {
		this.is_wic_clnc_info_new = is_wic_clnc_info_new;
	}
	public String getIs_child_needs_care() {
		return is_child_needs_care;
	}
	public void setIs_child_needs_care(String is_child_needs_care) {
		this.is_child_needs_care = is_child_needs_care;
	}
	public String getIs_food_program() {
		return is_food_program;
	}
	public void setIs_food_program(String is_food_program) {
		this.is_food_program = is_food_program;
	}
	public String getIs_foster_care() {
		return is_foster_care;
	}
	public void setIs_foster_care(String is_foster_care) {
		this.is_foster_care = is_foster_care;
	}
	public String getIs_leaving_CA() {
		return is_leaving_CA;
	}
	public void setIs_leaving_CA(String is_leaving_CA) {
		this.is_leaving_CA = is_leaving_CA;
	}
	public String getIs_foster_child() {
		return is_foster_child;
	}
	public void setIs_foster_child(String is_foster_child) {
		this.is_foster_child = is_foster_child;
	}
	public String getDisabled_resp() {
		return disabled_resp;
	}
	public void setDisabled_resp(String disabled_resp) {
		this.disabled_resp = disabled_resp;
	}
	public String getLang_cd_sp() {
		return lang_cd_sp;
	}
	public void setLang_cd_sp(String lang_cd_sp) {
		this.lang_cd_sp = lang_cd_sp;
	}
	public String getAlias_oth_nam() {
		return alias_oth_nam;
	}
	public void setAlias_oth_nam(String alias_oth_nam) {
		this.alias_oth_nam = alias_oth_nam;
	}
	public String getEstb_dabl_resp() {
		return estb_dabl_resp;
	}
	public void setEstb_dabl_resp(String estb_dabl_resp) {
		this.estb_dabl_resp = estb_dabl_resp;
	}
	public String getEstb_deaf_resp() {
		return estb_deaf_resp;
	}
	public void setEstb_deaf_resp(String estb_deaf_resp) {
		this.estb_deaf_resp = estb_deaf_resp;
	}
	public String getFormer_foster_from_dt() {
		return former_foster_from_dt;
	}
	public void setFormer_foster_from_dt(String former_foster_from_dt) {
		this.former_foster_from_dt = former_foster_from_dt;
	}
	public String getFormer_foster_to_dt() {
		return former_foster_to_dt;
	}
	public void setFormer_foster_to_dt(String former_foster_to_dt) {
		this.former_foster_to_dt = former_foster_to_dt;
	}
	public String getFormer_foster_state() {
		return former_foster_state;
	}
	public void setFormer_foster_state(String former_foster_state) {
		this.former_foster_state = former_foster_state;
	}
	public String getIn_foster_eighteenth_brth_ind() {
		return in_foster_eighteenth_brth_ind;
	}
	public void setIn_foster_eighteenth_brth_ind(String in_foster_eighteenth_brth_ind) {
		this.in_foster_eighteenth_brth_ind = in_foster_eighteenth_brth_ind;
	}
	public String getOth_hhm_care_desc() {
		return oth_hhm_care_desc;
	}
	public void setOth_hhm_care_desc(String oth_hhm_care_desc) {
		this.oth_hhm_care_desc = oth_hhm_care_desc;
	}
	public String getVet_dep_resp() {
		return vet_dep_resp;
	}
	public void setVet_dep_resp(String vet_dep_resp) {
		this.vet_dep_resp = vet_dep_resp;
	}
	public String getVet_hon_discharge_ind() {
		return vet_hon_discharge_ind;
	}
	public void setVet_hon_discharge_ind(String vet_hon_discharge_ind) {
		this.vet_hon_discharge_ind = vet_hon_discharge_ind;
	}
	public String getVet_serv_from_dt() {
		return vet_serv_from_dt;
	}
	public void setVet_serv_from_dt(String vet_serv_from_dt) {
		this.vet_serv_from_dt = vet_serv_from_dt;
	}
	public String getVet_serv_to_dt() {
		return vet_serv_to_dt;
	}
	public void setVet_serv_to_dt(String vet_serv_to_dt) {
		this.vet_serv_to_dt = vet_serv_to_dt;
	}
	public String getChildcareIndividuals() {
		return childcareIndividuals;
	}
	public void setChildcareIndividuals(String childcareIndividuals) {
		this.childcareIndividuals = childcareIndividuals;
	}
	public String getFoster_court_ord_dep_ind() {
		return foster_court_ord_dep_ind;
	}
	public void setFoster_court_ord_dep_ind(String foster_court_ord_dep_ind) {
		this.foster_court_ord_dep_ind = foster_court_ord_dep_ind;
	}
	public String getFoster_incl_calfresh_ind() {
		return foster_incl_calfresh_ind;
	}
	public void setFoster_incl_calfresh_ind(String foster_incl_calfresh_ind) {
		this.foster_incl_calfresh_ind = foster_incl_calfresh_ind;
	}
	public String getAsg_sex() {
		return asg_sex;
	}
	public void setAsg_sex(String asg_sex) {
		this.asg_sex = asg_sex;
	}
	public String getSsn_applied_sw() {
		return ssn_applied_sw;
	}
	public void setSsn_applied_sw(String ssn_applied_sw) {
		this.ssn_applied_sw = ssn_applied_sw;
	}
	public String getNo_ssn_reason() {
		return no_ssn_reason;
	}
	public void setNo_ssn_reason(String no_ssn_reason) {
		this.no_ssn_reason = no_ssn_reason;
	}
	public String getSsn_other_reason_desc() {
		return ssn_other_reason_desc;
	}
	public void setSsn_other_reason_desc(String ssn_other_reason_desc) {
		this.ssn_other_reason_desc = ssn_other_reason_desc;
	}
	public String getSsn_num_ind() {
		return ssn_num_ind;
	}
	public void setSsn_num_ind(String ssn_num_ind) {
		this.ssn_num_ind = ssn_num_ind;
	}
	public String getSsn_absence_reason_cd() {
		return ssn_absence_reason_cd;
	}
	public void setSsn_absence_reason_cd(String ssn_absence_reason_cd) {
		this.ssn_absence_reason_cd = ssn_absence_reason_cd;
	}
	public String getAlien_doc_num() {
		return alien_doc_num;
	}
	public void setAlien_doc_num(String alien_doc_num) {
		this.alien_doc_num = alien_doc_num;
	}
	public String getLived_in_us_con_sw() {
		return lived_in_us_con_sw;
	}
	public void setLived_in_us_con_sw(String lived_in_us_con_sw) {
		this.lived_in_us_con_sw = lived_in_us_con_sw;
	}
	public String getNaturalized_ctzn_ind() {
		return naturalized_ctzn_ind;
	}
	public void setNaturalized_ctzn_ind(String naturalized_ctzn_ind) {
		this.naturalized_ctzn_ind = naturalized_ctzn_ind;
	}
	public String getSpnsr_ctzn_ind() {
		return spnsr_ctzn_ind;
	}
	public void setSpnsr_ctzn_ind(String spnsr_ctzn_ind) {
		this.spnsr_ctzn_ind = spnsr_ctzn_ind;
	}
	public String getSpnsr_i134_sign_sw() {
		return spnsr_i134_sign_sw;
	}
	public void setSpnsr_i134_sign_sw(String spnsr_i134_sign_sw) {
		this.spnsr_i134_sign_sw = spnsr_i134_sign_sw;
	}
	public String getSpnsr_i864_sign_sw() {
		return spnsr_i864_sign_sw;
	}
	public void setSpnsr_i864_sign_sw(String spnsr_i864_sign_sw) {
		this.spnsr_i864_sign_sw = spnsr_i864_sign_sw;
	}
	public String getSpnsr_phn_num() {
		return spnsr_phn_num;
	}
	public void setSpnsr_phn_num(String spnsr_phn_num) {
		this.spnsr_phn_num = spnsr_phn_num;
	}
	public String getSpnsr_help_sw() {
		return spnsr_help_sw;
	}
	public void setSpnsr_help_sw(String spnsr_help_sw) {
		this.spnsr_help_sw = spnsr_help_sw;
	}
	public String getSpnsr_amt() {
		return spnsr_amt;
	}
	public void setSpnsr_amt(String spnsr_amt) {
		this.spnsr_amt = spnsr_amt;
	}
	public String getSpnsr_rent_sw() {
		return spnsr_rent_sw;
	}
	public void setSpnsr_rent_sw(String spnsr_rent_sw) {
		this.spnsr_rent_sw = spnsr_rent_sw;
	}
	public String getSpnsr_clothes_sw() {
		return spnsr_clothes_sw;
	}
	public void setSpnsr_clothes_sw(String spnsr_clothes_sw) {
		this.spnsr_clothes_sw = spnsr_clothes_sw;
	}
	public String getSpnsr_food_sw() {
		return spnsr_food_sw;
	}
	public void setSpnsr_food_sw(String spnsr_food_sw) {
		this.spnsr_food_sw = spnsr_food_sw;
	}
	public String getSpnsr_other_sw() {
		return spnsr_other_sw;
	}
	public void setSpnsr_other_sw(String spnsr_other_sw) {
		this.spnsr_other_sw = spnsr_other_sw;
	}
	public String getHspc_oth_dsc() {
		return hspc_oth_dsc;
	}
	public void setHspc_oth_dsc(String hspc_oth_dsc) {
		this.hspc_oth_dsc = hspc_oth_dsc;
	}
	public String getRace_pref_ind() {
		return race_pref_ind;
	}
	public void setRace_pref_ind(String race_pref_ind) {
		this.race_pref_ind = race_pref_ind;
	}
	public String getEthnicity_cd() {
		return ethnicity_cd;
	}
	public void setEthnicity_cd(String ethnicity_cd) {
		this.ethnicity_cd = ethnicity_cd;
	}
	public String getRecv_srvc_sw() {
		return recv_srvc_sw;
	}
	public void setRecv_srvc_sw(String recv_srvc_sw) {
		this.recv_srvc_sw = recv_srvc_sw;
	}
	public String getJpd_ind() {
		return jpd_ind;
	}
	public void setJpd_ind(String jpd_ind) {
		this.jpd_ind = jpd_ind;
	}
	public String getJpd_oth_desc() {
		return jpd_oth_desc;
	}
	public void setJpd_oth_desc(String jpd_oth_desc) {
		this.jpd_oth_desc = jpd_oth_desc;
	}
	public String getImm_wrk_hist_ind() {
		return imm_wrk_hist_ind;
	}
	public void setImm_wrk_hist_ind(String imm_wrk_hist_ind) {
		this.imm_wrk_hist_ind = imm_wrk_hist_ind;
	}
	public String getImm_plan_ind() {
		return imm_plan_ind;
	}
	public void setImm_plan_ind(String imm_plan_ind) {
		this.imm_plan_ind = imm_plan_ind;
	}
	public String getImm_status_value() {
		return imm_status_value;
	}
	public void setImm_status_value(String imm_status_value) {
		this.imm_status_value = imm_status_value;
	}
	public String getSpnsr_first_name() {
		return spnsr_first_name;
	}
	public void setSpnsr_first_name(String spnsr_first_name) {
		this.spnsr_first_name = spnsr_first_name;
	}
	public String getSpnsr_last_name() {
		return spnsr_last_name;
	}
	public void setSpnsr_last_name(String spnsr_last_name) {
		this.spnsr_last_name = spnsr_last_name;
	}
	public String getSpnsr_other_explanation() {
		return spnsr_other_explanation;
	}
	public void setSpnsr_other_explanation(String spnsr_other_explanation) {
		this.spnsr_other_explanation = spnsr_other_explanation;
	}
	public String getPers_info_change_desc() {
		return pers_info_change_desc;
	}
	public void setPers_info_change_desc(String pers_info_change_desc) {
		this.pers_info_change_desc = pers_info_change_desc;
	}
	public String getLeaving_ca_rsn_desc() {
		return leaving_ca_rsn_desc;
	}
	public void setLeaving_ca_rsn_desc(String leaving_ca_rsn_desc) {
		this.leaving_ca_rsn_desc = leaving_ca_rsn_desc;
	}
	public String getEligible_hs_ind() {
		return eligible_hs_ind;
	}
	public void setEligible_hs_ind(String eligible_hs_ind) {
		this.eligible_hs_ind = eligible_hs_ind;
	}
	public String getDt_entry_into_us() {
		return dt_entry_into_us;
	}
	public void setDt_entry_into_us(String dt_entry_into_us) {
		this.dt_entry_into_us = dt_entry_into_us;
	}
	public String getDecease_dt() {
		return decease_dt;
	}
	public void setDecease_dt(String decease_dt) {
		this.decease_dt = decease_dt;
	}
	public String getCa_ret_ind() {
		return ca_ret_ind;
	}
	public void setCa_ret_ind(String ca_ret_ind) {
		this.ca_ret_ind = ca_ret_ind;
	}
	public String getCa_pland_ret_dt() {
		return ca_pland_ret_dt;
	}
	public void setCa_pland_ret_dt(String ca_pland_ret_dt) {
		this.ca_pland_ret_dt = ca_pland_ret_dt;
	}
	public String getCa_leave_thirty_ind() {
		return ca_leave_thirty_ind;
	}
	public void setCa_leave_thirty_ind(String ca_leave_thirty_ind) {
		this.ca_leave_thirty_ind = ca_leave_thirty_ind;
	}
	public String getCa_dep_dt() {
		return ca_dep_dt;
	}
	public void setCa_dep_dt(String ca_dep_dt) {
		this.ca_dep_dt = ca_dep_dt;
	}
	public String getEstb_blnd_resp() {
		return estb_blnd_resp;
	}
	public void setEstb_blnd_resp(String estb_blnd_resp) {
		this.estb_blnd_resp = estb_blnd_resp;
	}
	public String getImm_status_chg_dt() {
		return imm_status_chg_dt;
	}
	public void setImm_status_chg_dt(String imm_status_chg_dt) {
		this.imm_status_chg_dt = imm_status_chg_dt;
	}
	public String getPlace_of_birth_reason() {
		return place_of_birth_reason;
	}
	public void setPlace_of_birth_reason(String place_of_birth_reason) {
		this.place_of_birth_reason = place_of_birth_reason;
	}
	public String getVaccine_ind() {
		return vaccine_ind;
	}
	public void setVaccine_ind(String vaccine_ind) {
		this.vaccine_ind = vaccine_ind;
	}
	public String getSchool_type_ind() {
		return school_type_ind;
	}
	public void setSchool_type_ind(String school_type_ind) {
		this.school_type_ind = school_type_ind;
	}
	public String getMoved_in_dt() {
		return moved_in_dt;
	}
	public void setMoved_in_dt(String moved_in_dt) {
		this.moved_in_dt = moved_in_dt;
	}
	public String getRes_la_sw() {
		return res_la_sw;
	}
	public void setRes_la_sw(String res_la_sw) {
		this.res_la_sw = res_la_sw;
	}
	public String getParent_status() {
		return parent_status;
	}
	public void setParent_status(String parent_status) {
		this.parent_status = parent_status;
	}
	public String getOther_food_program_name() {
		return other_food_program_name;
	}
	public void setOther_food_program_name(String other_food_program_name) {
		this.other_food_program_name = other_food_program_name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getOther_food_program_name_desc() {
		return other_food_program_name_desc;
	}
	public void setOther_food_program_name_desc(String other_food_program_name_desc) {
		this.other_food_program_name_desc = other_food_program_name_desc;
	}
	public String getChildcareArray() {
		return childcareArray;
	}
	public void setChildcareArray(String childcareArray) {
		this.childcareArray = childcareArray;
	}
	public String getCinNumber() {
		return cinNumber;
	}
	public void setCinNumber(String cinNumber) {
		this.cinNumber = cinNumber;
	}
    
    
    
    
    
}

