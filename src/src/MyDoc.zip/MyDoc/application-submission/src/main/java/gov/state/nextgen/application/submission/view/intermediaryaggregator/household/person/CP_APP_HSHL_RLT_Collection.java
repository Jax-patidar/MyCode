package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CP_APP_HSHL_RLT_Collection {
	
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String srcAppIndiv;
	private String change_dt;
	private String care_resp;
	private int rec_cplt_ind;
	private String phy_boe_sep_sw;
	private String change_eff_dt;
	private String pnp_tghr_sw;
	private String is_tax_dependent_of;
	private String chg_eff_dt;
	private String app_num;
	private int ref_indv_seq_num;
	private int src_indv_seq_num;
	@JsonProperty("Rlt_cd")
	private String rlt_cd;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getSrcAppIndiv() {
		return srcAppIndiv;
	}
	public void setSrcAppIndiv(String srcAppIndiv) {
		this.srcAppIndiv = srcAppIndiv;
	}
	public String getChange_dt() {
		return change_dt;
	}
	public void setChange_dt(String change_dt) {
		this.change_dt = change_dt;
	}
	public String getCare_resp() {
		return care_resp;
	}
	public void setCare_resp(String care_resp) {
		this.care_resp = care_resp;
	}
	public int getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(int rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getPhy_boe_sep_sw() {
		return phy_boe_sep_sw;
	}
	public void setPhy_boe_sep_sw(String phy_boe_sep_sw) {
		this.phy_boe_sep_sw = phy_boe_sep_sw;
	}
	public String getChange_eff_dt() {
		return change_eff_dt;
	}
	public void setChange_eff_dt(String change_eff_dt) {
		this.change_eff_dt = change_eff_dt;
	}
	public String getPnp_tghr_sw() {
		return pnp_tghr_sw;
	}
	public void setPnp_tghr_sw(String pnp_tghr_sw) {
		this.pnp_tghr_sw = pnp_tghr_sw;
	}
	public String getIs_tax_dependent_of() {
		return is_tax_dependent_of;
	}
	public void setIs_tax_dependent_of(String is_tax_dependent_of) {
		this.is_tax_dependent_of = is_tax_dependent_of;
	}
	public String getChg_eff_dt() {
		return chg_eff_dt;
	}
	public void setChg_eff_dt(String chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getRef_indv_seq_num() {
		return ref_indv_seq_num;
	}
	public void setRef_indv_seq_num(int ref_indv_seq_num) {
		this.ref_indv_seq_num = ref_indv_seq_num;
	}
	public int getSrc_indv_seq_num() {
		return src_indv_seq_num;
	}
	public void setSrc_indv_seq_num(int src_indv_seq_num) {
		this.src_indv_seq_num = src_indv_seq_num;
	}
	public String getRlt_cd() {
		return rlt_cd;
	}
	public void setRlt_cd(String rlt_cd) {
		this.rlt_cd = rlt_cd;
	}
		
	
}
