package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense;

public class CP_APP_IN_MED_INS {

}
