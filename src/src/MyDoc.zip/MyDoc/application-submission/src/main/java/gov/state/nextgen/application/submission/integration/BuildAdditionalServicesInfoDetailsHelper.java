package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_SUPPORT_SERVICES_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.APP_IN_BreastFeeding_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.APP_IN_OUT_ST_BNFT_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.APP_IN_Teen_Parent_Collection;
import gov.state.nextgen.application.submission.view.payload.AdditionalServices;
import gov.state.nextgen.application.submission.view.payload.Applicant;

import java.util.List;

public class BuildAdditionalServicesInfoDetailsHelper {

    private BuildAdditionalServicesInfoDetailsHelper() {
    }

    public static AdditionalServices buildAdditionaServices(AggregatedPayload source) {
        AdditionalServices aServicesOut = null;
        try {
            aServicesOut = getAppSupportDetails(source);
            aServicesOut = getBirthDetails(source, aServicesOut);
        } catch (Exception e) {
            FwLogger.log(BuildAdditionalServicesInfoDetailsHelper.class, FwLogger.Level.INFO, "Exception while building Additional Details#{} - " + e.getMessage());
        }
        return aServicesOut;
    }


    public static void buildTribalTanfDetails(AggregatedPayload source, int indvSeqNum, Applicant tribeIndv) {

        List<APP_IN_OUT_ST_BNFT_Collection> tribeIndvList = null;
        APP_IN_OUT_ST_BNFT_Collection indvTrb = null;
        try {
            tribeIndvList = source.getHouseholdDemographicsProfileDetails().getPageCollection().getAPP_IN_OUT_ST_BNFT_Collection();
            if (tribeIndvList != null && !tribeIndvList.isEmpty()) {
                indvTrb = tribeIndvList.stream().filter(indv -> indvSeqNum == indv.getIndv_seq_num()).findFirst().orElse(null);

                if (indvTrb != null) {
                    tribeIndv.setTribalTanfInd(true);
                    tribeIndv.setTribalTanfState(indvTrb.getOut_of_st_bnft_sta_cd());
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildAdditionalServicesInfoDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while setting Tribe Details - " + e.getMessage());
        }
    }

    public static void buildTeenDetails(AggregatedPayload source, int indvSeqNum, Applicant teenIndv) {

        List<APP_IN_Teen_Parent_Collection> teenIndvList = null;
        APP_IN_Teen_Parent_Collection indvTeen = null;
        try {
            teenIndvList = source.getHouseholdDemographicsProfileDetails().getPageCollection().getAPP_IN_Teen_Parent_Collection();
            if (teenIndvList != null && !teenIndvList.isEmpty()) {
                indvTeen = teenIndvList.stream().filter(indv -> indvSeqNum == indv.getIndv_seq_num()).findFirst().orElse(null);

                if (indvTeen != null) {
                    teenIndv.setTeenParentInd(true);
                    teenIndv.setTeenParentSchoolStatus(indvTeen.getEnrl_stat_cd());
                    teenIndv.setTeenParentSchoolStatusText(indvTeen.getNt_enrl_stat_desc());
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildAdditionalServicesInfoDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while setting Teen Details - " + e.getMessage());
        }
    }

    public static AdditionalServices getAppSupportDetails(AggregatedPayload source) {
        AdditionalServices aServicesOut = null;
        List<CP_APP_SUPPORT_SERVICES_Collection> addServicesColl = null;
        try {
            addServicesColl = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_SUPPORT_SERVICES_Collection();

            if (addServicesColl != null && !addServicesColl.isEmpty()) {
                aServicesOut = new AdditionalServices();
                CP_APP_SUPPORT_SERVICES_Collection addServiceIn = addServicesColl.get(0);
                if(ApplicationSubmissionConstants.STR_IS.equalsIgnoreCase(addServiceIn.getFree_vaccines())) {
                	aServicesOut.setImmunization(true);//NOSONAR
                }
                if(ApplicationSubmissionConstants.STR_FP.equalsIgnoreCase(addServiceIn.getFamily_planning())) {
                	aServicesOut.setFamilyPlanning(true);//NOSONAR
                }
                if(ApplicationSubmissionConstants.STR_CH.equalsIgnoreCase(addServiceIn.getChild_health_disability())) {
                	aServicesOut.setChildHealthDisabilityPrvntInd(true);//NOSONAR
                }
                aServicesOut.setDentalAppointment(false);
                aServicesOut.setDentalTransportation(false);
                aServicesOut.setMedicalServices(false);
                aServicesOut.setMedServiceAppointment(false);
                aServicesOut.setMedServiceTransportation(false);
                aServicesOut.setMoreInfo(false);
                aServicesOut.setOtherHelp(false);
            }
        } catch (Exception e) {
            FwLogger.log(BuildAdditionalServicesInfoDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while setting Additional Details - " + e.getMessage());
        }
        return aServicesOut;
    }

    public static AdditionalServices getBirthDetails(AggregatedPayload source, AdditionalServices aServicesOut) {

        List<APP_IN_BreastFeeding_Collection> brFeedingColl = null;
        try {
            brFeedingColl = source.getHouseholdDemographicsProfileDetails().getPageCollection().getAPP_IN_BreastFeeding_Collection();
            if (brFeedingColl != null && !brFeedingColl.isEmpty()) {
                if (aServicesOut == null)
                    aServicesOut = new AdditionalServices();
                APP_IN_BreastFeeding_Collection pregColl = brFeedingColl.get(0);
                aServicesOut.setPregnant(ApplicationUtil.translateBoolean(pregColl.getIs_pregnant()));//NOSONAR
                aServicesOut.setBreastFeeding(ApplicationUtil.translateBoolean(pregColl.getIs_breast_feeding()));//NOSONAR
                aServicesOut.setRecentBirth(ApplicationUtil.translateBoolean(pregColl.getBirth_in_twelv_mnths()));//NOSONAR
            }
        } catch (Exception e) {
            FwLogger.log(BuildAdditionalServicesInfoDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while setting Birth Details - " + e.getMessage());
        }
        return aServicesOut;
    }

}