package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

import java.util.Date;

public class APP_IN_Teen_Parent_Collection {
	private String app_num;

	private int indv_seq_num;

	private String src_app_ind;

	private int seq_num;

	private int chld_care_ind;

	private String educ_cd;
	private String enrl_stat_cd;
	private Date hs_grad_dt;

	private String hs_grad_stat_cd;

	private int isfc_dy_care_ind;
	private int rec_cplt_ind;

	private int schl_plcm_ind;
	private String work_stdy_ind;
	private String school_name;
	private String immunization_received_ind;

	private String adapt_record_id;

	private String fed_fund_wrk_study_prg_ind;
	private String school_type_cd;

	private String school_city_adr;

	private String school_sta_adr;

	private String fed_sta_fund_wrk_study_prg_ind;

	private String school_l1_adr;

	private String school_sta_adr_cd;

	private String school_l2_adr;

	private String school_zip_adr;
	private Date end_dt;

	private int ecp_id;

	private String addr_zip4;
	private Date change_dt;

	private String nt_enrl_stat_desc;
	private String no_of_units;
	private String avg_weekly_work_hrs;

	private String first_name;

	private String last_name;

	private int age;

	public String getApp_num() {
		return app_num;
	}

	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}

	public int getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public int getSeq_num() {
		return seq_num;
	}

	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}

	public int getChld_care_ind() {
		return chld_care_ind;
	}

	public void setChld_care_ind(int chld_care_ind) {
		this.chld_care_ind = chld_care_ind;
	}

	public String getEduc_cd() {
		return educ_cd;
	}

	public void setEduc_cd(String educ_cd) {
		this.educ_cd = educ_cd;
	}

	public String getEnrl_stat_cd() {
		return enrl_stat_cd;
	}

	public void setEnrl_stat_cd(String enrl_stat_cd) {
		this.enrl_stat_cd = enrl_stat_cd;
	}

	public Date getHs_grad_dt() {
		return hs_grad_dt;
	}

	public void setHs_grad_dt(Date hs_grad_dt) {
		this.hs_grad_dt = hs_grad_dt;
	}

	public String getHs_grad_stat_cd() {
		return hs_grad_stat_cd;
	}

	public void setHs_grad_stat_cd(String hs_grad_stat_cd) {
		this.hs_grad_stat_cd = hs_grad_stat_cd;
	}

	public int getIsfc_dy_care_ind() {
		return isfc_dy_care_ind;
	}

	public void setIsfc_dy_care_ind(int isfc_dy_care_ind) {
		this.isfc_dy_care_ind = isfc_dy_care_ind;
	}

	public int getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	public void setRec_cplt_ind(int rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	public int getSchl_plcm_ind() {
		return schl_plcm_ind;
	}

	public void setSchl_plcm_ind(int schl_plcm_ind) {
		this.schl_plcm_ind = schl_plcm_ind;
	}

	public String getWork_stdy_ind() {
		return work_stdy_ind;
	}

	public void setWork_stdy_ind(String work_stdy_ind) {
		this.work_stdy_ind = work_stdy_ind;
	}

	public String getSchool_name() {
		return school_name;
	}

	public void setSchool_name(String school_name) {
		this.school_name = school_name;
	}

	public String getImmunization_received_ind() {
		return immunization_received_ind;
	}

	public void setImmunization_received_ind(String immunization_received_ind) {
		this.immunization_received_ind = immunization_received_ind;
	}

	public String getAdapt_record_id() {
		return adapt_record_id;
	}

	public void setAdapt_record_id(String adapt_record_id) {
		this.adapt_record_id = adapt_record_id;
	}

	public String getFed_fund_wrk_study_prg_ind() {
		return fed_fund_wrk_study_prg_ind;
	}

	public void setFed_fund_wrk_study_prg_ind(String fed_fund_wrk_study_prg_ind) {
		this.fed_fund_wrk_study_prg_ind = fed_fund_wrk_study_prg_ind;
	}

	public String getSchool_type_cd() {
		return school_type_cd;
	}

	public void setSchool_type_cd(String school_type_cd) {
		this.school_type_cd = school_type_cd;
	}

	public String getSchool_city_adr() {
		return school_city_adr;
	}

	public void setSchool_city_adr(String school_city_adr) {
		this.school_city_adr = school_city_adr;
	}

	public String getSchool_sta_adr() {
		return school_sta_adr;
	}

	public void setSchool_sta_adr(String school_sta_adr) {
		this.school_sta_adr = school_sta_adr;
	}

	public String getFed_sta_fund_wrk_study_prg_ind() {
		return fed_sta_fund_wrk_study_prg_ind;
	}

	public void setFed_sta_fund_wrk_study_prg_ind(String fed_sta_fund_wrk_study_prg_ind) {
		this.fed_sta_fund_wrk_study_prg_ind = fed_sta_fund_wrk_study_prg_ind;
	}

	public String getSchool_l1_adr() {
		return school_l1_adr;
	}

	public void setSchool_l1_adr(String school_l1_adr) {
		this.school_l1_adr = school_l1_adr;
	}

	public String getSchool_sta_adr_cd() {
		return school_sta_adr_cd;
	}

	public void setSchool_sta_adr_cd(String school_sta_adr_cd) {
		this.school_sta_adr_cd = school_sta_adr_cd;
	}

	public String getSchool_l2_adr() {
		return school_l2_adr;
	}

	public void setSchool_l2_adr(String school_l2_adr) {
		this.school_l2_adr = school_l2_adr;
	}

	public String getSchool_zip_adr() {
		return school_zip_adr;
	}

	public void setSchool_zip_adr(String school_zip_adr) {
		this.school_zip_adr = school_zip_adr;
	}

	public Date getEnd_dt() {
		return end_dt;
	}

	public void setEnd_dt(Date end_dt) {
		this.end_dt = end_dt;
	}

	public int getEcp_id() {
		return ecp_id;
	}

	public void setEcp_id(int ecp_id) {
		this.ecp_id = ecp_id;
	}

	public String getAddr_zip4() {
		return addr_zip4;
	}

	public void setAddr_zip4(String addr_zip4) {
		this.addr_zip4 = addr_zip4;
	}

	public Date getChange_dt() {
		return change_dt;
	}

	public void setChange_dt(Date change_dt) {
		this.change_dt = change_dt;
	}

	public String getNt_enrl_stat_desc() {
		return nt_enrl_stat_desc;
	}

	public void setNt_enrl_stat_desc(String nt_enrl_stat_desc) {
		this.nt_enrl_stat_desc = nt_enrl_stat_desc;
	}

	public String getNo_of_units() {
		return no_of_units;
	}

	public void setNo_of_units(String no_of_units) {
		this.no_of_units = no_of_units;
	}

	public String getAvg_weekly_work_hrs() {
		return avg_weekly_work_hrs;
	}

	public void setAvg_weekly_work_hrs(String avg_weekly_work_hrs) {
		this.avg_weekly_work_hrs = avg_weekly_work_hrs;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}


}
