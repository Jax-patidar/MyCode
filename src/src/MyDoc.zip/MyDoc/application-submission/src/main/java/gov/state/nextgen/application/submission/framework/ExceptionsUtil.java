package gov.state.nextgen.application.submission.framework;

import gov.state.nextgen.application.submission.framework.exception.FwWrappedException;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.framework.model.CP_WEB_EXCP_Cargo;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.MDC;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Objects;

import static gov.state.nextgen.application.submission.framework.constants.ExceptionConstants.*;

public class ExceptionsUtil {

    public static CP_WEB_EXCP_Cargo getExceptionCargo(Class classRef, Throwable t, String methodId, String uniqueIdentifier) {
        CP_WEB_EXCP_Cargo cargo = new CP_WEB_EXCP_Cargo();
        String stackTraceValue = FwWrappedException.getStackTraceValue(t);
        cargo.setCls_id(classRef.getName());
        cargo.setCur_page_id("NA");
        cargo.setUnique_excp_id(generateUserExceptionId(classRef));
        cargo.setExcp_tms(new java.sql.Timestamp(new java.util.Date().getTime()));
        cargo.setExcp_txt(t.getMessage() != null ? (t.getMessage().length() > 300 ? t.getMessage().substring(0, 300) : t.getMessage()) : null);//NOSONAR
        cargo.setMthd_id(methodId);
        cargo.setParm_txt("FormType - " + MDC.get(KEY_IDENTIFIER_TWO));
        cargo.setSrvc_nam(System.getenv(SERVICE_NAME));
        cargo.setStak_trc_txt(stackTraceValue.length() > 10000 ? stackTraceValue.substring(0, 10000) : stackTraceValue);
        cargo.setUser_id("NA");
        if(Objects.nonNull(MDC.get(KEY_IDENTIFIER_ONE)) && (MDC.get(KEY_IDENTIFIER_ONE)).isEmpty()){
        cargo.setApp_num(Integer.parseInt(MDC.get(KEY_IDENTIFIER_ONE)));
        }
        return cargo;
    }

    /**
     * Generate User Exception Id
     *
     * @return userExceptionId
     */
    public static String generateUserExceptionId(Class classRef) {
        FwLogger.log(classRef, FwLogger.Level.ERROR, "Exception Id Creation Start");
        SecureRandom sr;
        String dig = "";
        try {
            sr = SecureRandom.getInstance("SHA1PRNG");
            dig = (sr.nextInt(9000000) + 1000000) + "";
        } catch (NoSuchAlgorithmException e) {
            FwLogger.log(classRef, FwLogger.Level.ERROR, "Exception Id Creation Using RandomStringUtils");
            dig = RandomStringUtils.randomNumeric(7);
        }
        String chars = RandomStringUtils.randomAlphabetic(3).toUpperCase();
        return chars + dig;

    }
}
