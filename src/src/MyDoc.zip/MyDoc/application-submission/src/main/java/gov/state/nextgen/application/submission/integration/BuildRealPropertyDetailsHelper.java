package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.APP_IN_R_PROP_ASET_Collection;
import gov.state.nextgen.application.submission.view.payload.PropertyAddress;
import gov.state.nextgen.application.submission.view.payload.RealProperties;
import gov.state.nextgen.application.submission.view.payload.RealProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BuildRealPropertyDetailsHelper {
	
	private BuildRealPropertyDetailsHelper() {}
	
	public static List<RealProperties> buildRealProperty(AggregatedPayload source, int indvSeq) {

		RealProperties realProps = null;
		List<RealProperties> realAsetList = new ArrayList<>();
		
		try {
			List<APP_IN_R_PROP_ASET_Collection> reAsetList = source.getFinancialAssetSummaryDetails().getPageCollection().getAPP_IN_R_PROP_ASET_Collection();
			
			if(reAsetList != null && !reAsetList.isEmpty()) {
				List<APP_IN_R_PROP_ASET_Collection> indvreAsetList = reAsetList.stream().filter(reAset->indvSeq == reAset.getIndv_seq_num()).collect(Collectors.toList());

				if(indvreAsetList != null && !indvreAsetList.isEmpty()) {
					for(APP_IN_R_PROP_ASET_Collection inRealProp : indvreAsetList) {
						realProps = new RealProperties();
						realProps.setAcquired(inRealProp.getAsset_acquired_dt());
						realProps.setAvailableDate(inRealProp.getAsset_acquired_dt());
						realProps.setBegDate(inRealProp.getAsset_acquired_dt());
						realProps.setCategoryCode("RP");
						realProps.setType("33");
						realProps.setRealProperty(getRealProperty(inRealProp));
						if( inRealProp.getProp_fmv_amt() != null) 
							realProps.setValAmount(Double.parseDouble(inRealProp.getProp_fmv_amt()));
						realProps.setPurchasePrice(inRealProp.getProp_fmv_amt());
						realAsetList.add(realProps); 
					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildRealPropertyDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while buildRealProperty::" + e.getMessage());
		}
		return realAsetList;
	}
	
	public static PropertyAddress getAddress(APP_IN_R_PROP_ASET_Collection realPropAddrs) {
		PropertyAddress address = null;
		if(realPropAddrs != null && (realPropAddrs.getProp_l1_adr() != null || realPropAddrs.getProp_city_adr() != null
				|| realPropAddrs.getProp_sta_adr() != null || realPropAddrs.getProp_zip_adr() != null)) {
			address = new PropertyAddress();
			address.setAddrType(ApplicationSubmissionConstants.STR_PH);
			address.setStreetAddr1(realPropAddrs.getProp_l1_adr());
			address.setStreetAddr2(realPropAddrs.getProp_l2_adr());
			address.setCityName(realPropAddrs.getProp_city_adr());
			address.setZipCode(realPropAddrs.getProp_zip_adr());
			address.setState(realPropAddrs.getProp_sta_adr());
		}
		return address;
	}
	
	public static RealProperty getRealProperty(APP_IN_R_PROP_ASET_Collection inRealProp) {
		
		RealProperty realProperty = null;
		
		try {
			realProperty = new RealProperty();			
			realProperty.setPropertyAddress(getAddress(inRealProp));
			if(inRealProp.getRent_amt() != null)
				realProperty.setRentAmount(Double.parseDouble(inRealProp.getRent_amt())); 
			String freqCd = inRealProp.getHow_often_rent_paid();
			if(ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
				realProperty.setRentFrequency(ApplicationSubmissionConstants.FRE_II);
			} else {
				realProperty.setRentFrequency(freqCd);
			}
			
			realProperty.setSomeoneRentingInd(ApplicationUtil.translateBoolean(inRealProp.getProperty_currently_rented_ind()));//NOSONAR
		} catch (Exception e) {
			FwLogger.log(BuildRealPropertyDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while getRealProperty::" + e.getMessage());
		}
        return realProperty;
	}
}
