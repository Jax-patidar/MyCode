package gov.state.nextgen.application.submission.service;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.payload.ApplicationSubmissionPayload;

public interface DisasterAppTransferService {
	
	AggregatedPayload fetchDisasterCalFresh(String appNumber);
	ApplicationSubmissionPayload fetchApplicationSubmissionPayload(AggregatedPayload aggregatedPayload);

}
