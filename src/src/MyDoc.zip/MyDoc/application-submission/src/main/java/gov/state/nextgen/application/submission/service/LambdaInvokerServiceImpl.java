package gov.state.nextgen.application.submission.service;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.payload.ServiceResponseCargo;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Service;

@Service
public class LambdaInvokerServiceImpl implements LambdaInvokerService {

    public String invokeLambda(String url, HttpEntity<Object> httpentity, String path) throws Exception {//NOSONAR
        try {
            String responsePayload = null;
            String payload = null;
            String body = null;

            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "Begin invokeLambda");

            // (1) Define the AWS Region in which the function is to be invoked
            Regions region = Regions.fromName(System.getenv("REGION"));
            // (2) Instantiate AWSLambdaClientBuilder to build the Lambda client
            AWSLambdaClientBuilder builder = AWSLambdaClientBuilder.standard().withRegion(region);
            // (3) Build the client, which will ultimately invoke the function
            AWSLambda client = builder.build();

            String httpMethod = "POST";
            payload = ApplicationUtil.prepareAWSRequest(httpMethod, path, path, httpentity.getBody());

            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "payload::" + payload);

            InvokeRequest req = new InvokeRequest().withFunctionName(url).withPayload(payload); // optional
            // (5) Invoke the function and capture response
            InvokeResult result = client.invoke(req);

            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "result::" + result);

            if (result != null && result.getStatusCode() == 200) {

                FwLogger.log(this.getClass(),
                        FwLogger.Level.INFO,
                        "result status code::" + result.getStatusCode());

                FwLogger.log(this.getClass(),
                        FwLogger.Level.INFO,
                        "payload::" + result.getPayload());

                responsePayload = new String(result.getPayload().array());
            } else {
                throw new Exception("Status Code not 200");
            }

            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "responsePayload::responsePayload::" + responsePayload);

            if (responsePayload != null) {
                ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

                ServiceResponseCargo responseObj = objMapper.readValue(responsePayload, ServiceResponseCargo.class);

                FwLogger.log(this.getClass(),
                        FwLogger.Level.INFO,
                        "responseObj::" + responseObj);

                body = responseObj.getBody();

                FwLogger.log(this.getClass(),
                        FwLogger.Level.INFO,
                        "body::" + body);
            }

            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "body::" + body);

            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "End invokeLambda");

            return body;
        } catch (JsonProcessingException e) {
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Error occured in LambdaInvokerServiceImpl.invokeLambda()");
            throw e;
        }

    }
}
