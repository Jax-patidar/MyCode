package gov.state.nextgen.application.submission.view.response;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.CP_ASSETS_DISASTER_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_EXPENSE_DISASTER_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.CP_INCOME_DISASTER_Collection;

public class DisasterAppFISPageCollection {
	
	@JsonDeserialize(contentAs = CP_EXPENSE_DISASTER_Collection.class)
	private List<CP_EXPENSE_DISASTER_Collection> CP_EXPENSE_DISASTER_Collection;
	
	@JsonDeserialize(contentAs = CP_INCOME_DISASTER_Collection.class)
	private List<CP_INCOME_DISASTER_Collection> CP_INCOME_DISASTER_Collection;
	
	@JsonDeserialize(contentAs = CP_ASSETS_DISASTER_Collection.class)
	private List<CP_ASSETS_DISASTER_Collection> CP_ASSETS_DISASTER_Collection;
	
	public List<CP_EXPENSE_DISASTER_Collection> getCP_EXPENSE_DISASTER_Collection() {
		return CP_EXPENSE_DISASTER_Collection;
	}

	public void setCP_EXPENSE_DISASTER_Collection(List<CP_EXPENSE_DISASTER_Collection> cP_EXPENSE_DISASTER_Collection) {
		CP_EXPENSE_DISASTER_Collection = cP_EXPENSE_DISASTER_Collection;
	}

	public List<CP_INCOME_DISASTER_Collection> getCP_INCOME_DISASTER_Collection() {
		return CP_INCOME_DISASTER_Collection;
	}

	public void setCP_INCOME_DISASTER_Collection(List<CP_INCOME_DISASTER_Collection> cP_INCOME_DISASTER_Collection) {
		CP_INCOME_DISASTER_Collection = cP_INCOME_DISASTER_Collection;
	}

	public List<CP_ASSETS_DISASTER_Collection> getCP_ASSETS_DISASTER_Collection() {
		return CP_ASSETS_DISASTER_Collection;
	}

	public void setCP_ASSETS_DISASTER_Collection(List<CP_ASSETS_DISASTER_Collection> cP_ASSETS_DISASTER_Collection) {
		CP_ASSETS_DISASTER_Collection = cP_ASSETS_DISASTER_Collection;
	}

	
}
