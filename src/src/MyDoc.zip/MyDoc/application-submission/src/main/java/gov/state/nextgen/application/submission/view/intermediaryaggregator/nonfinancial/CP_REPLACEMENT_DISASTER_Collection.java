package gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial;

public class CP_REPLACEMENT_DISASTER_Collection {
	
	private String app_num;
	private String src_app_ind;
	private double replacement_amnt;
	private String replacement_cf_ind;
	
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public double getReplacement_amnt() {
		return replacement_amnt;
	}
	public void setReplacement_amnt(double replacement_amnt) {
		this.replacement_amnt = replacement_amnt;
	}
	public String getReplacement_cf_ind() {
		return replacement_cf_ind;
	}
	public void setReplacement_cf_ind(String replacement_cf_ind) {
		this.replacement_cf_ind = replacement_cf_ind;
	}

}
