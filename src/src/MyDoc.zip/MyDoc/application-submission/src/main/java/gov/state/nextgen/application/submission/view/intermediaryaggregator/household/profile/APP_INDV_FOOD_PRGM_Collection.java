package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class APP_INDV_FOOD_PRGM_Collection {

}
