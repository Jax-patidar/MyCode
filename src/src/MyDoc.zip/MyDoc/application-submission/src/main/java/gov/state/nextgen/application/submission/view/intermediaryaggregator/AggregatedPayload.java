package gov.state.nextgen.application.submission.view.intermediaryaggregator;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.FinancialAssetSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.FinancialExpenseSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.FinancialIncomeSummaryDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.HouseholdDemographicsPersonDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.HouseholdDemographicsProfileDetails;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.NonFinancialInformationDetails;
import gov.state.nextgen.application.submission.view.response.DisasterAppFISRespDetails;
import gov.state.nextgen.application.submission.view.response.DisasterAppHHSRespDetails;
import gov.state.nextgen.application.submission.view.response.DisasterAppNFSRespDetails;

public class AggregatedPayload {

	private String appNumber;
	private boolean errorWhileAccessingInternalServices;
	private HouseholdDemographicsPersonDetails householdDemographicsPersonDetails;
	private FinancialIncomeSummaryDetails financialIncomeSummaryDetails;
	private FinancialAssetSummaryDetails financialAssetSummaryDetails;
	private NonFinancialInformationDetails nonFinancialInformationDetails;
	private FinancialExpenseSummaryDetails financialExpenseSummaryDetails;
	private HouseholdDemographicsProfileDetails householdDemographicsProfileDetails;
	private DisasterAppFISRespDetails disasterAppFISRespDetails;
	private DisasterAppHHSRespDetails disasterAppHHSRespDetails;
	private DisasterAppNFSRespDetails disasterAppNFSRespDetails;
	
	public String getAppNumber() {
		return appNumber;
	}
	public void setAppNumber(String appNumber) {
		this.appNumber = appNumber;
	}
	public HouseholdDemographicsPersonDetails getHouseholdDemographicsPersonDetails() {
		if(householdDemographicsPersonDetails==null) {
			householdDemographicsPersonDetails= new HouseholdDemographicsPersonDetails();
		}
		return householdDemographicsPersonDetails;
	}
	public void setHouseholdDemographicsPersonDetails(
			HouseholdDemographicsPersonDetails householdDemographicsPersonDetails) {
		this.householdDemographicsPersonDetails = householdDemographicsPersonDetails;
	}
	public FinancialIncomeSummaryDetails getFinancialIncomeSummaryDetails() {
		if(financialIncomeSummaryDetails==null) {
			financialIncomeSummaryDetails = new FinancialIncomeSummaryDetails();
		}
		return financialIncomeSummaryDetails;
	}
	public void setFinancialIncomeSummaryDetails(FinancialIncomeSummaryDetails financialIncomeSummaryDetails) {
		this.financialIncomeSummaryDetails = financialIncomeSummaryDetails;
	}
	public FinancialAssetSummaryDetails getFinancialAssetSummaryDetails() {
		if(financialAssetSummaryDetails==null) {
			financialAssetSummaryDetails = new FinancialAssetSummaryDetails();
		}
		return financialAssetSummaryDetails;
	}
	public void setFinancialAssetSummaryDetails(FinancialAssetSummaryDetails financialAssetSummaryDetails) {
		this.financialAssetSummaryDetails = financialAssetSummaryDetails;
	}
	public NonFinancialInformationDetails getNonFinancialInformationDetails() {
		if(nonFinancialInformationDetails == null) {
			nonFinancialInformationDetails = new NonFinancialInformationDetails();
		}
		return nonFinancialInformationDetails;
	}
	public void setNonFinancialInformationDetails(NonFinancialInformationDetails nonFinancialInformationDetails) {
		this.nonFinancialInformationDetails = nonFinancialInformationDetails;
	}
	public FinancialExpenseSummaryDetails getFinancialExpenseSummaryDetails() {
		if(financialExpenseSummaryDetails==null) {
			financialExpenseSummaryDetails = new FinancialExpenseSummaryDetails();
		}
		return financialExpenseSummaryDetails;
	}
	public void setFinancialExpenseSummaryDetails(FinancialExpenseSummaryDetails financialExpenseSummaryDetails) {
		this.financialExpenseSummaryDetails = financialExpenseSummaryDetails;
	}
	public HouseholdDemographicsProfileDetails getHouseholdDemographicsProfileDetails() {
		if(householdDemographicsProfileDetails==null) {
			householdDemographicsProfileDetails = new HouseholdDemographicsProfileDetails();
		}
		return householdDemographicsProfileDetails;
	}
	public void setHouseholdDemographicsProfileDetails(
			HouseholdDemographicsProfileDetails householdDemographicsProfileDetails) {
		this.householdDemographicsProfileDetails = householdDemographicsProfileDetails;
	}
	
	public boolean isErrorWhileAccessingInternalServices() {
		return errorWhileAccessingInternalServices;
	}
	public void setErrorWhileAccessingInternalServices(boolean errorWhileAccessingInternalServices) {
		this.errorWhileAccessingInternalServices = errorWhileAccessingInternalServices;
	}
	
	public DisasterAppFISRespDetails getDisasterAppFISRespDetails() {
		return disasterAppFISRespDetails;
	}
	public void setDisasterAppFISRespDetails(DisasterAppFISRespDetails disasterAppFISRespDetails) {
		this.disasterAppFISRespDetails = disasterAppFISRespDetails;
	}
	public DisasterAppHHSRespDetails getDisasterAppHHSRespDetails() {
		return disasterAppHHSRespDetails;
	}
	public void setDisasterAppHHSRespDetails(DisasterAppHHSRespDetails disasterAppHHSRespDetails) {
		this.disasterAppHHSRespDetails = disasterAppHHSRespDetails;
	}
	public DisasterAppNFSRespDetails getDisasterAppNFSRespDetails() {
		return disasterAppNFSRespDetails;
	}
	public void setDisasterAppNFSRespDetails(DisasterAppNFSRespDetails disasterAppNFSRespDetails) {
		this.disasterAppNFSRespDetails = disasterAppNFSRespDetails;
	}

	
}
