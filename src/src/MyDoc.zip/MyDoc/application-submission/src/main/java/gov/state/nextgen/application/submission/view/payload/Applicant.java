package gov.state.nextgen.application.submission.view.payload;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class Applicant {
	private List<String> program;
	private int id;
	private boolean primaryApplicantInd; // Mandatory Field
	private String ssn;
	private Boolean ssnApplyingInd;
	private String noSSNReason;
	private String firstName;
	private String lastName;
	private String middleName;
	private String suffix;
	private String dob;
	private String genderCode;
	private Boolean helpwithTransportationInd;
	private Boolean getsCalFreshBenefitsInd;//Accenture not accepting these fields
	private String calFreshBenefitsCounty;
	private String calFreshBenefitsState;
	private String calFreshMonthlyAllotment;
	private Boolean deafInd;
	private String genderIdentity;
	private String sexualOrientationCode;
	private String arrivalDate;
	private String departureDate;
	private String expectedReturnDate;
	private String actualReturnDate;
	private String maritalStatusCode;
	@JsonIgnore
	private String maritalStatusDate;
	@JsonIgnore
	private String marriageDate;
	private Boolean calLearnInd;
	private String calLearnDt;
	private String calLearnCounty;
	@JsonIgnore
	private String atin;
	@JsonIgnore
	private String itin;
	private Boolean tempStayInd;
	@JsonIgnore
	private String beginStayDate;
	private String householdStatus;
	private String prefContactCode;
	private String birthCountryCode;
	private String aliasFirstName;
	private String aliasLastName;
	private String aliasMiddleName;
	private String aliasSuffix;
	private String tribe;
	private Boolean homelessStatus;
	private String homelessCountyCode;
	@JsonIgnore
	private String identificationNo;
	@JsonIgnore
	private String providerName;
	private String hoursReceived;
	@JsonIgnore
	private String occupation;
	@JsonIgnore
	private String skill01;
	@JsonIgnore
	private String skill02;
	@JsonIgnore
	private String skill03;
	private Boolean ethnicInd;
	private String ethnicOrigin;
	private Boolean disabilityInd;
	private DisabilityDetails disabilityDetails;
	private Boolean hhGrossIncomeLessThan150Ind;
	private Boolean utilitiesShutOffInd;
	private Boolean hhGrossIncomeLessRentUtilitiesInd;
	private Boolean migrantInd;
	private Boolean noFoodInd;
	private Boolean evictionNoticeInd;
	@JsonIgnore
	private Boolean elderlyInd;
	@JsonIgnore
	private Boolean minorConsentInd;
	private Boolean pregnantInd;
	private Boolean houseHoldHeadInd;
	private Boolean destituteInd;
	@JsonIgnore
	private String lifeEventCode;
	@JsonIgnore
	private String lifeEventDt;
	private Boolean temporarilyOutOfStateInd;
	@JsonIgnore
	private Boolean fosterCare18thInd;//Accenture not accepting these fields
	@JsonIgnore
	private Boolean fosterChildinHomeInd;//Accenture not accepting these fields
	private Boolean fullTimeStudentInd;
	@JsonIgnore
	private Boolean incomechangemonthtomonthInd;//Accenture not accepting these fields
	private String totalIncomeThisYear;
	private String totalIncomeNextYear;
	private String fosterCareBeginDate;
	private String fosterCareEndDate;
	private Boolean indianCostSharingInd;
	private Boolean federallyRecognizedTribeInd;
	private Boolean sameAddressAsPrimaryInd;
	private String emailAddr;
	private String projectedHouseHoldIncome;
	private Boolean hispanicEthnicInd;
	private String otherEthnicText;
	private Boolean tribeHealthPgmInd;
	private Boolean eligTribalserviceInd;
	private Boolean receivedTribalServiceInd;
	private String pdjIdentif;
	private Boolean shotsUpToDateInd;
	private Boolean unableToFixMealsInd;
	private Boolean caredForByAnotherHHMemInd;
	private String requiresCareText;
	private Boolean teenParentInd;
	private Boolean ihssInd;
	private String ihssMonthlyCost;
	private String teenParentSchoolStatus;
	private String teenParentSchoolStatusText;
	private Boolean fcChildOrderOfCourtInd;
	private Boolean countFCChildInCFCaseInd;
	private Boolean guiltOfTradingSNAPBeneInd;
	private Boolean guiltOfGunsAmmunitionInd;
	private Boolean convictedOfSNAPBenefitsInd;
	private Boolean leaveCalifFor30Ind;
	private Boolean expectToContinueToLiveinCalInd;
	private String leftCall;
	private String whenToLeave;
	private Boolean returnPlanToCaliInd;
	private String whenToReturn;
	private Boolean fraudDuplicateSnapInd;
	private Boolean cashFraudInd;
	private String cashFraudDate;
	private String cashFraudCountyCode;
	private String cashFruadState;
	private String failedToCooperateState;
	@JsonIgnore
	private Boolean failedToCooperateInd;//Accenture not accepting these fields
	private String failedToCooperateCounty;
	private String failedToCooperateDate;
	private String failedToCooperateExpl;
	private Boolean paroleViolationInd;
	private Boolean fleeingFelon;
	private String fosterChildState;
	private Boolean thirdPartyLiabilityInd;
	private List<RetroMedical> retroMedical;
	private String writtenLangCode;
	private String spokenLangCode;
	private Boolean interprReqInd;
	private Boolean essentialInd;
	@JsonIgnore
	private Boolean lookWorkHourInd;
	private Boolean taxDependentInd;
	@JsonIgnore
	private Boolean travelInd;
	@JsonIgnore
	private Boolean insuranceOfferedInd;
	private Boolean tribalTanfInd;
	private String tribalTanfState;
	private String tribalTanfCounty;
	private List<Address> addressess;
	private List<PhoneNumber> phoneNumbers;
	private List<Income> incomes;
	private List<Expenses> expenses;
	private List<PersonalProperty> personalProperties;
	private List<SoldAsset> soldAssets;
	private List<School> schools;
	private List<Job> jobs;
	private List<Ethnicities> ethnicities;
	private List<LiquidResource> liquidResource;
	private List<RealProperties> realProperties;
	private List<Vehicle> vehicles;
	private Veteran veteran;	
	private List<Strike> strike;
	@JsonIgnore
	private List<Hardship> hardship;//Accenture not accepting these fields
	@JsonIgnore
	private List<NonCompliance> nonCompliance;
	@JsonIgnore
	private List<PurchaseAndPrepare> purchaseAndPrepare;//Accenture not accepting these fields
	private List<SpecialNeed> specialNeeds;
	private Medicare medicare;
	private Citizenship citizenship;
	private List<HealthCoverage> healthCoverage;
	private VitalStatistics vitalStatistics;
	private Residence residence;
	private PregnancyDetail pregnancyDetail;
	private List<HouseholdSituation> householdSituations;
	private List<MedicalCondition> medicalConditions;
	private List<Race> races;
	private List<LivingArrangement> livingArrangements;
	private List<OtherPgmAssistance> otherPgmAssistances;
	private List<TaxHousehold> taxHousehold;

	public List<String> getProgram() {
		if(program == null) {
			program =  new ArrayList<>();
		}
		return program;
	}

	public void setProgram(List<String> program) {
		this.program = program;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isPrimaryApplicantInd() {
		return primaryApplicantInd;
	}

	public void setPrimaryApplicantInd(boolean primaryApplicantInd) {
		this.primaryApplicantInd = primaryApplicantInd;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public Boolean isSsnApplyingInd() {
		return ssnApplyingInd;
	}

	public void setSsnApplyingInd(Boolean ssnApplyingInd) {
		this.ssnApplyingInd = ssnApplyingInd;
	}

	public String getNoSSNReason() {
		return noSSNReason;
	}

	public void setNoSSNReason(String noSSNReason) {
		this.noSSNReason = noSSNReason;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getGenderCode() {
		return genderCode;
	}

	public void setGenderCode(String genderCode) {
		this.genderCode = genderCode;
	}

	public Boolean isHelpwithTransportationInd() {
		return helpwithTransportationInd;
	}

	public void setHelpwithTransportationInd(Boolean helpwithTransportationInd) {
		this.helpwithTransportationInd = helpwithTransportationInd;
	}

	public Boolean isGetsCalFreshBenefitsInd() {
		return getsCalFreshBenefitsInd;
	}

	public void setGetsCalFreshBenefitsInd(Boolean getsCalFreshBenefitsInd) {
		this.getsCalFreshBenefitsInd = getsCalFreshBenefitsInd;
	}

	public String getCalFreshBenefitsCounty() {
		return calFreshBenefitsCounty;
	}

	public void setCalFreshBenefitsCounty(String calFreshBenefitsCounty) {
		this.calFreshBenefitsCounty = calFreshBenefitsCounty;
	}

	public String getCalFreshBenefitsState() {
		return calFreshBenefitsState;
	}

	public void setCalFreshBenefitsState(String calFreshBenefitsState) {
		this.calFreshBenefitsState = calFreshBenefitsState;
	}

	public String getCalFreshMonthlyAllotment() {
		return calFreshMonthlyAllotment;
	}

	public void setCalFreshMonthlyAllotment(String calFreshMonthlyAllotment) {
		this.calFreshMonthlyAllotment = calFreshMonthlyAllotment;
	}

	public Boolean isDeafInd() {
		return deafInd;
	}

	public void setDeafInd(Boolean deafInd) {
		this.deafInd = deafInd;
	}

	public String getGenderIdentity() {
		return genderIdentity;
	}

	public void setGenderIdentity(String genderIdentity) {
		this.genderIdentity = genderIdentity;
	}

	public String getSexualOrientationCode() {
		return sexualOrientationCode;
	}

	public void setSexualOrientationCode(String sexualOrientationCode) {
		this.sexualOrientationCode = sexualOrientationCode;
	}

	public String getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public String getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}

	public String getExpectedReturnDate() {
		return expectedReturnDate;
	}

	public void setExpectedReturnDate(String expectedReturnDate) {
		this.expectedReturnDate = expectedReturnDate;
	}

	public String getActualReturnDate() {
		return actualReturnDate;
	}

	public void setActualReturnDate(String actualReturnDate) {
		this.actualReturnDate = actualReturnDate;
	}

	public String getMaritalStatusCode() {
		return maritalStatusCode;
	}

	public void setMaritalStatusCode(String maritalStatusCode) {
		this.maritalStatusCode = maritalStatusCode;
	}

	public String getMaritalStatusDate() {
		return maritalStatusDate;
	}

	public void setMaritalStatusDate(String maritalStatusDate) {
		this.maritalStatusDate = maritalStatusDate;
	}

	public String getMarriageDate() {
		return marriageDate;
	}

	public void setMarriageDate(String marriageDate) {
		this.marriageDate = marriageDate;
	}

	public Boolean isCalLearnInd() {
		return calLearnInd;
	}

	public void setCalLearnInd(Boolean calLearnInd) {
		this.calLearnInd = calLearnInd;
	}

	public String getCalLearnDt() {
		return calLearnDt;
	}

	public void setCalLearnDt(String calLearnDt) {
		this.calLearnDt = calLearnDt;
	}

	public String getCalLearnCounty() {
		return calLearnCounty;
	}

	public void setCalLearnCounty(String calLearnCounty) {
		this.calLearnCounty = calLearnCounty;
	}

	public String getAtin() {
		return atin;
	}

	public void setAtin(String atin) {
		this.atin = atin;
	}

	public String getItin() {
		return itin;
	}

	public void setItin(String itin) {
		this.itin = itin;
	}

	public Boolean isTempStayInd() {
		return tempStayInd;
	}

	public void setTempStayInd(Boolean tempStayInd) {
		this.tempStayInd = tempStayInd;
	}

	public String getBeginStayDate() {
		return beginStayDate;
	}

	public void setBeginStayDate(String beginStayDate) {
		this.beginStayDate = beginStayDate;
	}

	public String getHouseholdStatus() {
		return householdStatus;
	}

	public void setHouseholdStatus(String householdStatus) {
		this.householdStatus = householdStatus;
	}

	public String getPrefContactCode() {
		return prefContactCode;
	}

	public void setPrefContactCode(String prefContactCode) {
		this.prefContactCode = prefContactCode;
	}

	public String getBirthCountryCode() {
		return birthCountryCode;
	}

	public void setBirthCountryCode(String birthCountryCode) {
		this.birthCountryCode = birthCountryCode;
	}

	public String getAliasFirstName() {
		return aliasFirstName;
	}

	public void setAliasFirstName(String aliasFirstName) {
		this.aliasFirstName = aliasFirstName;
	}

	public String getAliasLastName() {
		return aliasLastName;
	}

	public void setAliasLastName(String aliasLastName) {
		this.aliasLastName = aliasLastName;
	}

	public String getAliasMiddleName() {
		return aliasMiddleName;
	}

	public void setAliasMiddleName(String aliasMiddleName) {
		this.aliasMiddleName = aliasMiddleName;
	}

	public String getAliasSuffix() {
		return aliasSuffix;
	}

	public void setAliasSuffix(String aliasSuffix) {
		this.aliasSuffix = aliasSuffix;
	}

	public String getTribe() {
		return tribe;
	}

	public void setTribe(String tribe) {
		this.tribe = tribe;
	}

	public Boolean isHomelessStatus() {
		return homelessStatus;
	}

	public void setHomelessStatus(Boolean homelessStatus) {
		this.homelessStatus = homelessStatus;
	}

	public String getHomelessCountyCode() {
		return homelessCountyCode;
	}

	public void setHomelessCountyCode(String homelessCountyCode) {
		this.homelessCountyCode = homelessCountyCode;
	}

	public String getIdentificationNo() {
		return identificationNo;
	}

	public void setIdentificationNo(String identificationNo) {
		this.identificationNo = identificationNo;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public String getHoursReceived() {
		return hoursReceived;
	}

	public void setHoursReceived(String hoursReceived) {
		this.hoursReceived = hoursReceived;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getSkill01() {
		return skill01;
	}

	public void setSkill01(String skill01) {
		this.skill01 = skill01;
	}

	public String getSkill02() {
		return skill02;
	}

	public void setSkill02(String skill02) {
		this.skill02 = skill02;
	}

	public String getSkill03() {
		return skill03;
	}

	public void setSkill03(String skill03) {
		this.skill03 = skill03;
	}

	public Boolean isEthnicInd() {
		return ethnicInd;
	}

	public void setEthnicInd(Boolean ethnicInd) {
		this.ethnicInd = ethnicInd;
	}

	public String getEthnicOrigin() {
		return ethnicOrigin;
	}

	public void setEthnicOrigin(String ethnicOrigin) {
		this.ethnicOrigin = ethnicOrigin;
	}

	public Boolean isDisabilityInd() {
		return disabilityInd;
	}

	public void setDisabilityInd(Boolean disabilityInd) {
		this.disabilityInd = disabilityInd;
	}

	public DisabilityDetails getDisabilityDetails() {
		return disabilityDetails;
	}

	public void setDisabilityDetails(DisabilityDetails disabilityDetails) {
		this.disabilityDetails = disabilityDetails;
	}

	public Boolean isHhGrossIncomeLessThan150Ind() {
		return hhGrossIncomeLessThan150Ind;
	}

	public void setHhGrossIncomeLessThan150Ind(Boolean hhGrossIncomeLessThan150Ind) {
		this.hhGrossIncomeLessThan150Ind = hhGrossIncomeLessThan150Ind;
	}

	public Boolean isUtilitiesShutOffInd() {
		return utilitiesShutOffInd;
	}

	public void setUtilitiesShutOffInd(Boolean utilitiesShutOffInd) {
		this.utilitiesShutOffInd = utilitiesShutOffInd;
	}

	public Boolean isHhGrossIncomeLessRentUtilitiesInd() {
		return hhGrossIncomeLessRentUtilitiesInd;
	}

	public void setHhGrossIncomeLessRentUtilitiesInd(Boolean hhGrossIncomeLessRentUtilitiesInd) {
		this.hhGrossIncomeLessRentUtilitiesInd = hhGrossIncomeLessRentUtilitiesInd;
	}

	public Boolean isMigrantInd() {
		return migrantInd;
	}

	public void setMigrantInd(Boolean migrantInd) {
		this.migrantInd = migrantInd;
	}

	public Boolean isNoFoodInd() {
		return noFoodInd;
	}

	public void setNoFoodInd(Boolean noFoodInd) {
		this.noFoodInd = noFoodInd;
	}

	public Boolean isEvictionNoticeInd() {
		return evictionNoticeInd;
	}

	public void setEvictionNoticeInd(Boolean evictionNoticeInd) {
		this.evictionNoticeInd = evictionNoticeInd;
	}

	public Boolean isElderlyInd() {
		return elderlyInd;
	}

	public void setElderlyInd(Boolean elderlyInd) {
		this.elderlyInd = elderlyInd;
	}

	public Boolean isMinorConsentInd() {
		return minorConsentInd;
	}

	public void setMinorConsentInd(Boolean minorConsentInd) {
		this.minorConsentInd = minorConsentInd;
	}

	public Boolean isPregnantInd() {
		return pregnantInd;
	}

	public void setPregnantInd(Boolean pregnantInd) {
		this.pregnantInd = pregnantInd;
	}

	public Boolean isHouseHoldHeadInd() {
		return houseHoldHeadInd;
	}

	public void setHouseHoldHeadInd(Boolean houseHoldHeadInd) {
		this.houseHoldHeadInd = houseHoldHeadInd;
	}

	public Boolean isDestituteInd() {
		return destituteInd;
	}

	public void setDestituteInd(Boolean destituteInd) {
		this.destituteInd = destituteInd;
	}

	public String getLifeEventCode() {
		return lifeEventCode;
	}

	public void setLifeEventCode(String lifeEventCode) {
		this.lifeEventCode = lifeEventCode;
	}

	public String getLifeEventDt() {
		return lifeEventDt;
	}

	public void setLifeEventDt(String lifeEventDt) {
		this.lifeEventDt = lifeEventDt;
	}

	public Boolean isTemporarilyOutOfStateInd() {
		return temporarilyOutOfStateInd;
	}

	public void setTemporarilyOutOfStateInd(Boolean temporarilyOutOfStateInd) {
		this.temporarilyOutOfStateInd = temporarilyOutOfStateInd;
	}

	public Boolean isFosterCare18thInd() {
		return fosterCare18thInd;
	}

	public void setFosterCare18thInd(Boolean fosterCare18thInd) {
		this.fosterCare18thInd = fosterCare18thInd;
	}

	public Boolean isFosterChildinHomeInd() {
		return fosterChildinHomeInd;
	}

	public void setFosterChildinHomeInd(Boolean fosterChildinHomeInd) {
		this.fosterChildinHomeInd = fosterChildinHomeInd;
	}

	public Boolean isFullTimeStudentInd() {
		return fullTimeStudentInd;
	}

	public void setFullTimeStudentInd(Boolean fullTimeStudentInd) {
		this.fullTimeStudentInd = fullTimeStudentInd;
	}

	public Boolean isIncomechangemonthtomonthInd() {
		return incomechangemonthtomonthInd;
	}

	public void setIncomechangemonthtomonthInd(Boolean incomechangemonthtomonthInd) {
		this.incomechangemonthtomonthInd = incomechangemonthtomonthInd;
	}

	public String getTotalIncomeThisYear() {
		return totalIncomeThisYear;
	}

	public void setTotalIncomeThisYear(String totalIncomeThisYear) {
		this.totalIncomeThisYear = totalIncomeThisYear;
	}

	public String getTotalIncomeNextYear() {
		return totalIncomeNextYear;
	}

	public void setTotalIncomeNextYear(String totalIncomeNextYear) {
		this.totalIncomeNextYear = totalIncomeNextYear;
	}

	public String getFosterCareBeginDate() {
		return fosterCareBeginDate;
	}

	public void setFosterCareBeginDate(String fosterCareBeginDate) {
		this.fosterCareBeginDate = fosterCareBeginDate;
	}

	public String getFosterCareEndDate() {
		return fosterCareEndDate;
	}

	public void setFosterCareEndDate(String fosterCareEndDate) {
		this.fosterCareEndDate = fosterCareEndDate;
	}

	public Boolean isIndianCostSharingInd() {
		return indianCostSharingInd;
	}

	public void setIndianCostSharingInd(Boolean indianCostSharingInd) {
		this.indianCostSharingInd = indianCostSharingInd;
	}

	public Boolean isFederallyRecognizedTribeInd() {
		return federallyRecognizedTribeInd;
	}

	public void setFederallyRecognizedTribeInd(Boolean federallyRecognizedTribeInd) {
		this.federallyRecognizedTribeInd = federallyRecognizedTribeInd;
	}

	public Boolean isSameAddressAsPrimaryInd() {
		return sameAddressAsPrimaryInd;
	}

	public void setSameAddressAsPrimaryInd(Boolean sameAddressAsPrimaryInd) {
		this.sameAddressAsPrimaryInd = sameAddressAsPrimaryInd;
	}

	public String getEmailAddr() {
		return emailAddr;
	}

	public void setEmailAddr(String emailAddr) {
		this.emailAddr = emailAddr;
	}

	public String getProjectedHouseHoldIncome() {
		return projectedHouseHoldIncome;
	}

	public void setProjectedHouseHoldIncome(String projectedHouseHoldIncome) {
		this.projectedHouseHoldIncome = projectedHouseHoldIncome;
	}

	public Boolean isHispanicEthnicInd() {
		return hispanicEthnicInd;
	}

	public void setHispanicEthnicInd(Boolean hispanicEthnicInd) {
		this.hispanicEthnicInd = hispanicEthnicInd;
	}

	public String getOtherEthnicText() {
		return otherEthnicText;
	}

	public void setOtherEthnicText(String otherEthnicText) {
		this.otherEthnicText = otherEthnicText;
	}

	public Boolean isTribeHealthPgmInd() {
		return tribeHealthPgmInd;
	}

	public void setTribeHealthPgmInd(Boolean tribeHealthPgmInd) {
		this.tribeHealthPgmInd = tribeHealthPgmInd;
	}

	public Boolean isEligTribalserviceInd() {
		return eligTribalserviceInd;
	}

	public void setEligTribalserviceInd(Boolean eligTribalserviceInd) {
		this.eligTribalserviceInd = eligTribalserviceInd;
	}

	public Boolean isReceivedTribalServiceInd() {
		return receivedTribalServiceInd;
	}

	public void setReceivedTribalServiceInd(Boolean receivedTribalServiceInd) {
		this.receivedTribalServiceInd = receivedTribalServiceInd;
	}

	public String getPdjIdentif() {
		return pdjIdentif;
	}

	public void setPdjIdentif(String pdjIdentif) {
		this.pdjIdentif = pdjIdentif;
	}

	public Boolean isShotsUpToDateInd() {
		return shotsUpToDateInd;
	}

	public void setShotsUpToDateInd(Boolean shotsUpToDateInd) {
		this.shotsUpToDateInd = shotsUpToDateInd;
	}

	public Boolean isUnableToFixMealsInd() {
		return unableToFixMealsInd;
	}

	public void setUnableToFixMealsInd(Boolean unableToFixMealsInd) {
		this.unableToFixMealsInd = unableToFixMealsInd;
	}

	public Boolean isCaredForByAnotherHHMemInd() {
		return caredForByAnotherHHMemInd;
	}

	public void setCaredForByAnotherHHMemInd(Boolean caredForByAnotherHHMemInd) {
		this.caredForByAnotherHHMemInd = caredForByAnotherHHMemInd;
	}

	public String getRequiresCareText() {
		return requiresCareText;
	}

	public void setRequiresCareText(String requiresCareText) {
		this.requiresCareText = requiresCareText;
	}

	public Boolean isTeenParentInd() {
		return teenParentInd;
	}

	public void setTeenParentInd(Boolean teenParentInd) {
		this.teenParentInd = teenParentInd;
	}

	public Boolean isIhssInd() {
		return ihssInd;
	}

	public void setIhssInd(Boolean ihssInd) {
		this.ihssInd = ihssInd;
	}

	public String getIhssMonthlyCost() {
		return ihssMonthlyCost;
	}

	public void setIhssMonthlyCost(String ihssMonthlyCost) {
		this.ihssMonthlyCost = ihssMonthlyCost;
	}

	public String getTeenParentSchoolStatus() {
		return teenParentSchoolStatus;
	}

	public void setTeenParentSchoolStatus(String teenParentSchoolStatus) {
		this.teenParentSchoolStatus = teenParentSchoolStatus;
	}

	public String getTeenParentSchoolStatusText() {
		return teenParentSchoolStatusText;
	}

	public void setTeenParentSchoolStatusText(String teenParentSchoolStatusText) {
		this.teenParentSchoolStatusText = teenParentSchoolStatusText;
	}

	public Boolean isFcChildOrderOfCourtInd() {
		return fcChildOrderOfCourtInd;
	}

	public void setFcChildOrderOfCourtInd(Boolean fcChildOrderOfCourtInd) {
		this.fcChildOrderOfCourtInd = fcChildOrderOfCourtInd;
	}

	public Boolean isCountFCChildInCFCaseInd() {
		return countFCChildInCFCaseInd;
	}

	public void setCountFCChildInCFCaseInd(Boolean countFCChildInCFCaseInd) {
		this.countFCChildInCFCaseInd = countFCChildInCFCaseInd;
	}

	public Boolean isGuiltOfTradingSNAPBeneInd() {
		return guiltOfTradingSNAPBeneInd;
	}

	public void setGuiltOfTradingSNAPBeneInd(Boolean guiltOfTradingSNAPBeneInd) {
		this.guiltOfTradingSNAPBeneInd = guiltOfTradingSNAPBeneInd;
	}

	public Boolean isGuiltOfGunsAmmunitionInd() {
		return guiltOfGunsAmmunitionInd;
	}

	public void setGuiltOfGunsAmmunitionInd(Boolean guiltOfGunsAmmunitionInd) {
		this.guiltOfGunsAmmunitionInd = guiltOfGunsAmmunitionInd;
	}

	public Boolean isConvictedOfSNAPBenefitsInd() {
		return convictedOfSNAPBenefitsInd;
	}

	public void setConvictedOfSNAPBenefitsInd(Boolean convictedOfSNAPBenefitsInd) {
		this.convictedOfSNAPBenefitsInd = convictedOfSNAPBenefitsInd;
	}

	public Boolean isLeaveCalifFor30Ind() {
		return leaveCalifFor30Ind;
	}

	public void setLeaveCalifFor30Ind(Boolean leaveCalifFor30Ind) {
		this.leaveCalifFor30Ind = leaveCalifFor30Ind;
	}

	public Boolean isExpectToContinueToLiveinCalInd() {
		return expectToContinueToLiveinCalInd;
	}

	public void setExpectToContinueToLiveinCalInd(Boolean expectToContinueToLiveinCalInd) {
		this.expectToContinueToLiveinCalInd = expectToContinueToLiveinCalInd;
	}

	public String getLeftCall() {
		return leftCall;
	}

	public void setLeftCall(String leftCall) {
		this.leftCall = leftCall;
	}

	public String getWhenToLeave() {
		return whenToLeave;
	}

	public void setWhenToLeave(String whenToLeave) {
		this.whenToLeave = whenToLeave;
	}

	public Boolean isReturnPlanToCaliInd() {
		return returnPlanToCaliInd;
	}

	public void setReturnPlanToCaliInd(Boolean returnPlanToCaliInd) {
		this.returnPlanToCaliInd = returnPlanToCaliInd;
	}

	public String getWhenToReturn() {
		return whenToReturn;
	}

	public void setWhenToReturn(String whenToReturn) {
		this.whenToReturn = whenToReturn;
	}

	public Boolean isFraudDuplicateSnapInd() {
		return fraudDuplicateSnapInd;
	}

	public void setFraudDuplicateSnapInd(Boolean fraudDuplicateSnapInd) {
		this.fraudDuplicateSnapInd = fraudDuplicateSnapInd;
	}

	public Boolean isCashFraudInd() {
		return cashFraudInd;
	}

	public void setCashFraudInd(Boolean cashFraudInd) {
		this.cashFraudInd = cashFraudInd;
	}

	public String getCashFraudDate() {
		return cashFraudDate;
	}

	public void setCashFraudDate(String cashFraudDate) {
		this.cashFraudDate = cashFraudDate;
	}

	public String getCashFraudCountyCode() {
		return cashFraudCountyCode;
	}

	public void setCashFraudCountyCode(String cashFraudCountyCode) {
		this.cashFraudCountyCode = cashFraudCountyCode;
	}

	public String getCashFruadState() {
		return cashFruadState;
	}

	public void setCashFruadState(String cashFruadState) {
		this.cashFruadState = cashFruadState;
	}

	public String getFailedToCooperateState() {
		return failedToCooperateState;
	}

	public void setFailedToCooperateState(String failedToCooperateState) {
		this.failedToCooperateState = failedToCooperateState;
	}

	public Boolean isFailedToCooperateInd() {
		return failedToCooperateInd;
	}

	public void setFailedToCooperateInd(Boolean failedToCooperateInd) {
		this.failedToCooperateInd = failedToCooperateInd;
	}

	public String getFailedToCooperateCounty() {
		return failedToCooperateCounty;
	}

	public void setFailedToCooperateCounty(String failedToCooperateCounty) {
		this.failedToCooperateCounty = failedToCooperateCounty;
	}

	public String getFailedToCooperateDate() {
		return failedToCooperateDate;
	}

	public void setFailedToCooperateDate(String failedToCooperateDate) {
		this.failedToCooperateDate = failedToCooperateDate;
	}

	public String getFailedToCooperateExpl() {
		return failedToCooperateExpl;
	}

	public void setFailedToCooperateExpl(String failedToCooperateExpl) {
		this.failedToCooperateExpl = failedToCooperateExpl;
	}

	public Boolean isParoleViolationInd() {
		return paroleViolationInd;
	}

	public void setParoleViolationInd(Boolean paroleViolationInd) {
		this.paroleViolationInd = paroleViolationInd;
	}

	public Boolean isFleeingFelon() {
		return fleeingFelon;
	}

	public void setFleeingFelon(Boolean fleeingFelon) {
		this.fleeingFelon = fleeingFelon;
	}

	public String getFosterChildState() {
		return fosterChildState;
	}

	public void setFosterChildState(String fosterChildState) {
		this.fosterChildState = fosterChildState;
	}

	public Boolean isThirdPartyLiabilityInd() {
		return thirdPartyLiabilityInd;
	}

	public void setThirdPartyLiabilityInd(Boolean thirdPartyLiabilityInd) {
		this.thirdPartyLiabilityInd = thirdPartyLiabilityInd;
	}

	public List<RetroMedical> getRetroMedical() {
		return retroMedical;
	}

	public void setRetroMedical(List<RetroMedical> retroMedical) {
		this.retroMedical = retroMedical;
	}

	public String getWrittenLangCode() {
		return writtenLangCode;
	}

	public void setWrittenLangCode(String writtenLangCode) {
		this.writtenLangCode = writtenLangCode;
	}

	public String getSpokenLangCode() {
		return spokenLangCode;
	}

	public void setSpokenLangCode(String spokenLangCode) {
		this.spokenLangCode = spokenLangCode;
	}

	public Boolean isInterprReqInd() {
		return interprReqInd;
	}

	public void setInterprReqInd(Boolean interprReqInd) {
		this.interprReqInd = interprReqInd;
	}

	public Boolean isEssentialInd() {
		return essentialInd;
	}

	public void setEssentialInd(Boolean essentialInd) {
		this.essentialInd = essentialInd;
	}

	public Boolean isLookWorkHourInd() {
		return lookWorkHourInd;
	}

	public void setLookWorkHourInd(Boolean lookWorkHourInd) {
		this.lookWorkHourInd = lookWorkHourInd;
	}

	public Boolean isTaxDependentInd() {
		return taxDependentInd;
	}

	public void setTaxDependentInd(Boolean taxDependentInd) {
		this.taxDependentInd = taxDependentInd;
	}

	public Boolean isTravelInd() {
		return travelInd;
	}

	public void setTravelInd(Boolean travelInd) {
		this.travelInd = travelInd;
	}

	public Boolean isInsuranceOfferedInd() {
		return insuranceOfferedInd;
	}

	public void setInsuranceOfferedInd(Boolean insuranceOfferedInd) {
		this.insuranceOfferedInd = insuranceOfferedInd;
	}

	public Boolean isTribalTanfInd() {
		return tribalTanfInd;
	}

	public void setTribalTanfInd(Boolean tribalTanfInd) {
		this.tribalTanfInd = tribalTanfInd;
	}

	public String getTribalTanfState() {
		return tribalTanfState;
	}

	public void setTribalTanfState(String tribalTanfState) {
		this.tribalTanfState = tribalTanfState;
	}

	public String getTribalTanfCounty() {
		return tribalTanfCounty;
	}

	public void setTribalTanfCounty(String tribalTanfCounty) {
		this.tribalTanfCounty = tribalTanfCounty;
	}

	public List<Address> getAddressess() {
		
		return addressess;
	}

	public void setAddressess(List<Address> addressess) {
		this.addressess = addressess;
	}

	public List<PhoneNumber> getPhoneNumbers() {
		return phoneNumbers;
	}

	public void setPhoneNumbers(List<PhoneNumber> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}

	public List<Income> getIncomes() {
		return incomes;
	}

	public void setIncomes(List<Income> incomes) {
		this.incomes = incomes;
	}

	public List<Expenses> getExpenses() {
		return expenses;
	}

	public void setExpenses(List<Expenses> expenses) {
		this.expenses = expenses;
	}

	public List<PersonalProperty> getPersonalProperties() {
		return personalProperties;
	}

	public void setPersonalProperties(List<PersonalProperty> personalProperties) {
		this.personalProperties = personalProperties;
	}

	public List<SoldAsset> getSoldAssets() {
		return soldAssets;
	}

	public void setSoldAssets(List<SoldAsset> soldAssets) {
		this.soldAssets = soldAssets;
	}

	public List<School> getSchools() {
		return schools;
	}

	public void setSchools(List<School> schools) {
		this.schools = schools;
	}

	public List<Job> getJobs() {
		return jobs;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}

	public List<Ethnicities> getEthnicities() {
		return ethnicities;
	}

	public void setEthnicities(List<Ethnicities> ethnicities) {
		this.ethnicities = ethnicities;
	}

	public List<LiquidResource> getLiquidResource() {
		return liquidResource;
	}

	public void setLiquidResource(List<LiquidResource> liquidResource) {
		this.liquidResource = liquidResource;
	}

	public List<RealProperties> getRealProperties() {
		return realProperties;
	}

	public void setRealProperties(List<RealProperties> realProperties) {
		this.realProperties = realProperties;
	}

	public List<Vehicle> getVehicles() {
		return vehicles;
	}

	public void setVehicles(List<Vehicle> vehicles) {
		this.vehicles = vehicles;
	}

	public Veteran getVeteran() {
		return veteran;
	}

	public void setVeteran(Veteran veteran) {
		this.veteran = veteran;
	}

	public List<Strike> getStrike() {
		return strike;
	}

	public void setStrike(List<Strike> strike) {
		this.strike = strike;
	}

	public List<Hardship> getHardship() {
		return hardship;
	}

	public void setHardship(List<Hardship> hardship) {
		this.hardship = hardship;
	}

	public List<NonCompliance> getNonCompliance() {
		return nonCompliance;
	}

	public void setNonCompliance(List<NonCompliance> nonCompliance) {
		this.nonCompliance = nonCompliance;
	}

	public List<PurchaseAndPrepare> getPurchaseAndPrepare() {
		return purchaseAndPrepare;
	}

	public void setPurchaseAndPrepare(List<PurchaseAndPrepare> purchaseAndPrepare) {
		this.purchaseAndPrepare = purchaseAndPrepare;
	}

	public List<SpecialNeed> getSpecialNeeds() {
		return specialNeeds;
	}

	public void setSpecialNeeds(List<SpecialNeed> specialNeeds) {
		this.specialNeeds = specialNeeds;
	}

	public Medicare getMedicare() {
		return medicare;
	}

	public void setMedicare(Medicare medicare) {
		this.medicare = medicare;
	}

	public Citizenship getCitizenship() {
		if(citizenship == null) {
			citizenship = new Citizenship();
		}
		return citizenship;
	}

	public void setCitizenship(Citizenship citizenship) {
		this.citizenship = citizenship;
	}

	public List<HealthCoverage> getHealthCoverage() {
		return healthCoverage;
	}

	public void setHealthCoverage(List<HealthCoverage> healthCoverage) {
		this.healthCoverage = healthCoverage;
	}

	public VitalStatistics getVitalStatistics() {
		return vitalStatistics;
	}

	public void setVitalStatistics(VitalStatistics vitalStatistics) {
		this.vitalStatistics = vitalStatistics;
	}

	public Residence getResidence() {
		return residence;
	}

	public void setResidence(Residence residence) {
		this.residence = residence;
	}

	public PregnancyDetail getPregnancyDetail() {
		return pregnancyDetail;
	}

	public void setPregnancyDetail(PregnancyDetail pregnancyDetail) {
		this.pregnancyDetail = pregnancyDetail;
	}

	public List<HouseholdSituation> getHouseholdSituations() {
		return householdSituations;
	}

	public void setHouseholdSituations(List<HouseholdSituation> householdSituations) {
		this.householdSituations = householdSituations;
	}

	public List<MedicalCondition> getMedicalConditions() {
		return medicalConditions;
	}

	public void setMedicalConditions(List<MedicalCondition> medicalConditions) {
		this.medicalConditions = medicalConditions;
	}

	public List<Race> getRaces() {
		return races;
	}

	public void setRaces(List<Race> races) {
		this.races = races;
	}

	public List<LivingArrangement> getLivingArrangements() {
		return livingArrangements;
	}

	public void setLivingArrangements(List<LivingArrangement> livingArrangements) {
		this.livingArrangements = livingArrangements;
	}

	public List<OtherPgmAssistance> getOtherPgmAssistances() {
		return otherPgmAssistances;
	}

	public void setOtherPgmAssistances(List<OtherPgmAssistance> otherPgmAssistances) {
		this.otherPgmAssistances = otherPgmAssistances;
	}

	public List<TaxHousehold> getTaxHousehold() {
		return taxHousehold;
	}

	public void setTaxHousehold(List<TaxHousehold> taxHousehold) {
		this.taxHousehold = taxHousehold;
	}

}
