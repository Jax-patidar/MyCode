package gov.state.nextgen.application.submission.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.integration.BuildAdditionalServicesInfoDetailsHelper;
import gov.state.nextgen.application.submission.integration.BuildAuthRepDetails;
import gov.state.nextgen.application.submission.integration.BuildIncomeTypeMappingHelper;
import gov.state.nextgen.application.submission.integration.BuildIndividualDetailsHelper;
import gov.state.nextgen.application.submission.integration.BuildSponsorNonCitizenDetailsHelper;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_MED_BILLS;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.APP_ABS_PRNT_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.APP_SBMS_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.APP_USER_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_HSHL_RLT_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_IMMED_CASH_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_PGM_RQST_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_RGST_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.APP_IN_HLTH_INS_BNFTS_Collection;
import gov.state.nextgen.application.submission.view.payload.AdditionalServices;
import gov.state.nextgen.application.submission.view.payload.ApplicationSubmissionPayload;
import gov.state.nextgen.application.submission.view.payload.CalFreshAuthRep;
import gov.state.nextgen.application.submission.view.payload.CfBeneficiaryDetails;
import gov.state.nextgen.application.submission.view.payload.HlthRepInfo;
import gov.state.nextgen.application.submission.view.payload.HtlhRepAgentInfo;
import gov.state.nextgen.application.submission.view.payload.HtlhRepSig;
import gov.state.nextgen.application.submission.view.payload.Relationship;
import gov.state.nextgen.application.submission.view.payload.SponsoredNonCitzInfo;


@Service
public class PayloadTransformService {


    public ApplicationSubmissionPayload fromAggregatedPayload(AggregatedPayload source) throws Exception {//NOSONAR

        ApplicationSubmissionPayload target = BuildIndividualDetailsHelper.buildApplicant(source);
        List<APP_SBMS_Collection> sbmsColl = source.getHouseholdDemographicsPersonDetails().getPageCollection().getAPP_SBMS_Collection();
        String appNum = null;
        target.setOfficeIdentif("ZZ");
        if (sbmsColl != null && !sbmsColl.isEmpty()) {
            appNum = sbmsColl.get(0).getApp_num();
            target.setAppNumber(appNum);
            
            //set Application Submit Date
            if (sbmsColl.get(0).getSbmsDt() != null) {
            	 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
    			 String formattedAppSubmitDate = dateFormat.format(sbmsColl.get(0).getSbmsDt());
    			 target.setAppSubmissionDate(formattedAppSubmitDate);
            }
            
            target.setSignDate(sbmsColl.get(0).getSign_dt());
            String officeId = sbmsColl.get(0).getOffice_id();
            target.setUserAgency(sbmsColl.get(0).getOrg_user_agency_name());
            if (officeId != null)
                target.setOfficeIdentif(officeId);
        } else {
            target.setAppNumber(source.getAppNumber());
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern(ApplicationSubmissionConstants.YYYY_MM_DD);
            LocalDate date = LocalDate.now();
            target.setSignDate(date.format(dateFormat));
            target.setOfficeIdentif("ZZ");
        }
        target.setCountyCode(ApplicationSubmissionConstants.STR_19);
        List<CP_APP_RGST_Collection> appRgstColl = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_RGST_Collection();
        if (appRgstColl != null && !appRgstColl.isEmpty()) {
            CP_APP_RGST_Collection tempColl = null;
            for (CP_APP_RGST_Collection rgstColl : appRgstColl) {
                if (rgstColl != null && rgstColl.getIndv_seq_num() == 1) {
                    tempColl = rgstColl;
                    break;
                }
            }
            if (null != tempColl) {
                target.setOtherArrangeDisbInd(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(tempColl.getOther_assistance_sw()));//NOSONAR
            }


            if (null != tempColl && tempColl.getCnty_num() != null) {

                target.setCountyCode(tempColl.getCnty_num());
            }
            if (null != tempColl && null != tempColl.getPref_cntc_ind() && ApplicationSubmissionConstants.STR_1.equalsIgnoreCase(tempColl.getPref_cntc_ind())) {
                target.setCfInPersonIntviewInd(true);
            }
        }
        List<APP_IN_HLTH_INS_BNFTS_Collection> apphlthColl = source.getNonFinancialInformationDetails().getPageCollection().getAPP_IN_HLTH_INS_BNFTS_Collection();
        if (apphlthColl != null && !apphlthColl.isEmpty())
            target.setCalheersCaseNo(apphlthColl.get(0).getCov_ca_case_num());

        target.setDsnapInd(false);

        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "*************************************Before loading Auth Rep Info************************************************");

        CfBeneficiaryDetails cfAuthRepSig = BuildAuthRepDetails.buildCfAuthRepInfo(source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_AUTH_REP_Collection());

        if (cfAuthRepSig != null)
            target.setCfBeneficiaryDetails(cfAuthRepSig);

        CalFreshAuthRep snapAuthRepSig = BuildAuthRepDetails.buildSnapdAuthRepInfo(source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_AUTH_REP_Collection());

        if (snapAuthRepSig != null)
            target.setCalFreshAuthRep(snapAuthRepSig);

        HtlhRepSig htlhRepSig = BuildAuthRepDetails.buildAuthRepInfo(source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_AUTH_REP_Collection());

        if (htlhRepSig != null)
            target.setHtlhRepSig(htlhRepSig);

        HlthRepInfo hlthRepInfo = BuildAuthRepDetails.buildGeneralAuthRepInfo(source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_AUTH_REP_Collection());

        if (hlthRepInfo != null)
            target.setHlthRepInfo(hlthRepInfo);


        HtlhRepAgentInfo hlthRepAgentInfo = BuildAuthRepDetails.buildAuthRepInfo3(source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_AUTH_REP_Collection());

        if (hlthRepAgentInfo != null)
            target.setHtlhRepAgentInfo(hlthRepAgentInfo);
        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "*************************************Successfully loadedAuth Rep Info************************************************");

        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "*************************************Before loading Sponsor Info************************************************");

        List<SponsoredNonCitzInfo> sponsorsList = BuildSponsorNonCitizenDetailsHelper.buildSponsorInfo(source);
        if (sponsorsList != null && !sponsorsList.isEmpty())
            target.setSponsoredNonCitzInfo(sponsorsList);
        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "*************************************Successfully loaded Sponsor Info************************************************");

        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "*************************************Before loading Additional Services Info************************************************");

        AdditionalServices addServices = BuildAdditionalServicesInfoDetailsHelper.buildAdditionaServices(source);
        target.setAdditionalServices(addServices);
        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "*************************************Successfully loaded Additional Services Info************************************************");

        try {
            List<APP_USER_Collection> usrCollList = source.getHouseholdDemographicsPersonDetails().getPageCollection().getAPP_USER_Collection();
            if (usrCollList != null && !usrCollList.isEmpty()) {
                APP_USER_Collection userColl = usrCollList.get(0);
                String strAcsId = userColl.getAcs_id();
                if (strAcsId != null && !ApplicationSubmissionConstants.DUMMY_USER.equalsIgnoreCase(strAcsId))
                    target.setLoginInfoId(strAcsId);
            }

            List<CP_APP_IMMED_CASH_Collection> immCashColl = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_IMMED_CASH_Collection();
            if (immCashColl != null && !immCashColl.isEmpty()) {
                CP_APP_IMMED_CASH_Collection immedCash = immCashColl.get(0);
                target.setAbuseInd(ApplicationUtil.translateBoolean(immedCash.getChild_abuse()));//NOSONAR
                target.setElderAbuseInd(ApplicationUtil.translateBoolean(immedCash.getElser_abuse()));//NOSONAR
                target.setDomesticAbuseInd(ApplicationUtil.translateBoolean(immedCash.getDomestic_abuse()));//NOSONAR
                target.setImmediateMedicalInd(ApplicationUtil.translateBoolean(immedCash.getMedical_leave()));//NOSONAR
                target.setOtherEmergencyInd(ApplicationUtil.translateBoolean(immedCash.getOther_emergency()));//NOSONAR
                target.setImmediateNeedInd(true);
                target.setEmergencyRequestsInd(true);
            }
        } catch (Exception e) {
            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "Exception while fetching data from Immediate Cash Collection::" + e.getMessage());
        }

        List<CP_APP_PGM_RQST_Collection> appPgmColl = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_PGM_RQST_Collection();
        if (appPgmColl != null && !appPgmColl.isEmpty() && appPgmColl.get(0) != null)
            target.setCmspInd(ApplicationSubmissionConstants.STR_1.equalsIgnoreCase(appPgmColl.get(0).getCounty_med_ind()));//NOSONAR

        target.setInitialApplicationInd(true);

        try {
            List<CP_APP_IN_MED_BILLS> othrSpclColl = source.getFinancialExpenseSummaryDetails().getPageCollection().getCP_APP_IN_MED_BILLS();
            if (othrSpclColl != null && !othrSpclColl.isEmpty() && othrSpclColl.get(0) != null
                    && ApplicationSubmissionConstants.STR_OT.equalsIgnoreCase(othrSpclColl.get(0).getMed_bill_type())) {
                target.setOtherSpecialNeedsInd(true);
                target.setOtherSpecialNeedsExpl(othrSpclColl.get(0).getSpecial_needs_desc());
            }
        } catch (Exception e) {
            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "Exception while fetching data from Medical Bills Collection::" + e.getMessage());
        }

        target.setRelationships(buildRelationships(source));

        if (target != null && target.getPrimaryApplicant() != null && ((target.getPrimaryApplicant().isHhGrossIncomeLessThan150Ind() != null
        		&& target.getPrimaryApplicant().isHhGrossIncomeLessThan150Ind()) ||
        		(target.getPrimaryApplicant().isHhGrossIncomeLessRentUtilitiesInd() != null && target.getPrimaryApplicant().isHhGrossIncomeLessRentUtilitiesInd())))
            target.setExpediteInd(true);

        return target;

    }

    public List<Relationship> buildRelationships(AggregatedPayload source) {//NOSONAR

        Relationship relations = null;
        List<Relationship> relList = new ArrayList<>();
        List<CP_APP_HSHL_RLT_Collection> relCollList = null;
        List<APP_ABS_PRNT_Collection> absPrntCollList = null;
        String[] strArr = null;

        try {
            relCollList = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_HSHL_RLT_Collection();
            absPrntCollList = source.getHouseholdDemographicsPersonDetails().getPageCollection().getAPP_ABS_PRNT_Collection();
            if (relCollList != null && !relCollList.isEmpty()) {
                for (CP_APP_HSHL_RLT_Collection persRel : relCollList) {
                    relations = new Relationship();
                    relations.setPersID(ApplicationUtil.getBenefitsCalIndividualIdValue(persRel.getSrc_indv_seq_num()));
                    relations.setPers2ID(ApplicationUtil.getBenefitsCalIndividualIdValue(persRel.getRef_indv_seq_num()));
                    relations.setTypeCode(BuildIncomeTypeMappingHelper.getRelationType(persRel.getRlt_cd()));

                    if (absPrntCollList != null && !absPrntCollList.isEmpty()) {
                        APP_ABS_PRNT_Collection indvAbsPrnt = absPrntCollList.stream().filter(absPrnt -> persRel.getRef_indv_seq_num() == absPrnt.getIndv_seq_num()).findFirst().orElse(null);
                        if (indvAbsPrnt != null && indvAbsPrnt.getAp_absn_rsn_cd() != null) {
                            strArr = indvAbsPrnt.getAp_absn_rsn_cd().split(ApplicationSubmissionConstants.STR_COMMA);

                            for (String absRsn : strArr) {
                                if (ApplicationSubmissionConstants.STR_DE.equalsIgnoreCase(absRsn)) {
                                    relations.setParentDeceasedInd(true);
                                } else if (ApplicationSubmissionConstants.STR_NO.equalsIgnoreCase(absRsn)) {
                                    relations.setParentNoneInd(true);
                                } else if (ApplicationSubmissionConstants.STR_DI.equalsIgnoreCase(absRsn)) {
                                    relations.setParentDisabledInd(true);
                                } else if (ApplicationSubmissionConstants.STR_NH.equalsIgnoreCase(absRsn)) {
                                    relations.setParentOutOfHomeInd(true);
                                } else if (ApplicationSubmissionConstants.STR_UE.equalsIgnoreCase(absRsn)) {
                                    relations.setParentUnemployedInd(true);
                                }
                            }
                        }
                    }
                    relList.add(relations);
                }
            }

        } catch (Exception ex) {
            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "Exception while preparing relationship details::" + ex.getMessage());
        }
        return relList;
    }
}

