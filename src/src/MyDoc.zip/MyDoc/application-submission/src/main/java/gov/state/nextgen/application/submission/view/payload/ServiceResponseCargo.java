package gov.state.nextgen.application.submission.view.payload;

import java.util.Map;

public class ServiceResponseCargo {
	
	private String statusCode;
	private Map<String,Object> multiValueHeaders;
	private String body;
	private String isBase64Encoded;
	
	public ServiceResponseCargo() {
		
	}

	public ServiceResponseCargo(String statusCode, Map<String, Object> multiValueHeaders, String body,
			String isBase64Encoded) {
		super();
		this.statusCode = statusCode;
		this.multiValueHeaders = multiValueHeaders;
		this.body = body;
		this.isBase64Encoded = isBase64Encoded;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public Map<String, Object> getMultiValueHeaders() {
		return multiValueHeaders;
	}

	public void setMultiValueHeaders(Map<String, Object> multiValueHeaders) {
		this.multiValueHeaders = multiValueHeaders;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getIsBase64Encoded() {
		return isBase64Encoded;
	}

	public void setIsBase64Encoded(String isBase64Encoded) {
		this.isBase64Encoded = isBase64Encoded;
	}

	@Override
	public String toString() {
		return "ServiceResponseCargo [statusCode=" + statusCode + ", multiValueHeaders=" + multiValueHeaders + ", body="
				+ body + ", isBase64Encoded=" + isBase64Encoded + "]";
	}


}
