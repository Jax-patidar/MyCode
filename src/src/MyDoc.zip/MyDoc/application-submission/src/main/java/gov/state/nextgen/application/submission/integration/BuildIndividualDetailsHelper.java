package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_MED_BILLS;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_EMPL_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.*;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.*;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.APP_IN_PNLT_FRD_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.CP_APP_IN_CSHAID_STP_Collection;
import gov.state.nextgen.application.submission.view.payload.*;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class BuildIndividualDetailsHelper {

    private BuildIndividualDetailsHelper() {
    }

    public static ApplicationSubmissionPayload buildApplicant(AggregatedPayload source) {//NOSONAR
        final ApplicationSubmissionPayload target = new ApplicationSubmissionPayload();
        CP_APP_RGST_Collection primaryIndvRGstInfo = null;
        List<APP_INDV_Collection> otherApplicants = null;
        APP_INDV_Collection primaryIndividual = null;
        final List<CP_APP_PGM_RQST_Collection> caseAppProgRqst = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_PGM_RQST_Collection();
        final List<APP_INDV_Collection> indvList = source.getHouseholdDemographicsPersonDetails().getPageCollection().getAPP_INDV_Collection();
        final List<CP_APP_RGST_Collection> rgstList = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_RGST_Collection();
        final List<CP_APP_INDV_ADDI_INFO_Collection> indvAddInfoList = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_INDV_ADDI_INFO_Collection();
        CP_APP_INDV_ADDI_INFO_Collection addnlInfo = null;

        if (indvList != null && !indvList.isEmpty()) {
            primaryIndividual = indvList.stream().filter(indv -> ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(indv.getPrim_prsn_sw())).findFirst().orElse(null);
            otherApplicants = indvList.stream().filter(indv -> !ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(indv.getPrim_prsn_sw())).collect(Collectors.toList());
            if (indvAddInfoList != null && !indvAddInfoList.isEmpty()) {
                addnlInfo = indvAddInfoList.get(0);
            }
            
          //Set Unique Id Map for every Individual in an Household
            Map<Integer, Integer> benefitsCalIndividualIdMap = new HashMap<Integer, Integer>();
            for(APP_INDV_Collection appIndvCargo: indvList) {
            	if(appIndvCargo != null && appIndvCargo.getIndv_seq_num() != 0) {
            		benefitsCalIndividualIdMap.put(appIndvCargo.getIndv_seq_num(), appIndvCargo.getBenefitsCalIndividualId());
            	}
            }
            ApplicationUtil.setBenefitsCalIndividualIdMapValues(benefitsCalIndividualIdMap);
        }

        if (primaryIndividual != null) {

            final APP_INDV_Collection local = primaryIndividual;

            if (rgstList != null && !rgstList.isEmpty()) {
                primaryIndvRGstInfo = rgstList.stream().filter(indv -> local.getIndv_seq_num() == indv.getIndv_seq_num()).findFirst().orElse(null);
            }

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************Before loading primary Applicant************************************************");

            final Applicant primaryApplicant = BuildIndividualDetailsHelper.buildPrimaryApplicantDetails(source, primaryIndividual, primaryIndvRGstInfo, addnlInfo, caseAppProgRqst);
            target.setPrimaryApplicant(primaryApplicant);

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************Successfully loaded primary Applicant************************************************");
        } else {
            target.setContractFulfilled(false);
        }

        FwLogger.log(BuildIndividualDetailsHelper.class,
                FwLogger.Level.INFO,
                "*************************************Before loading other Applicants************************************************");
        if (otherApplicants != null && !otherApplicants.isEmpty()) {

            for (final APP_INDV_Collection otherIndv : otherApplicants) {

                CP_APP_RGST_Collection otherPersonRGST = null;

                if (rgstList != null && !rgstList.isEmpty()) {
                    otherPersonRGST = rgstList.stream().filter(indv -> otherIndv.getIndv_seq_num() == indv.getIndv_seq_num()).findFirst().orElse(rgstList.get(0));
                }

                final Applicant otherApplilcant = BuildIndividualDetailsHelper.buildPrimaryApplicantDetails(source, otherIndv, otherPersonRGST, addnlInfo, null);
                if (otherApplilcant != null) {
                    target.getOtherApplicants().add(otherApplilcant);
                }
            }
        }

        FwLogger.log(BuildIndividualDetailsHelper.class,
                FwLogger.Level.INFO,
                "*************************************Successfully loaded other Applicants************************************************");
        return target;

    }


    public static Applicant buildPrimaryApplicantDetails(AggregatedPayload source, APP_INDV_Collection individual, CP_APP_RGST_Collection rgstInfo, CP_APP_INDV_ADDI_INFO_Collection indvAddInfo, List<CP_APP_PGM_RQST_Collection> caseAppProgRqst) {//NOSONAR

        final Applicant applicant = new Applicant();

        //for primary applicant
        if (caseAppProgRqst != null && !caseAppProgRqst.isEmpty()) {
            applicant.setHouseHoldHeadInd(true);
            if (caseAppProgRqst.get(0).getFma_rqst_ind() == 1) {
                applicant.getProgram().add(ApplicationSubmissionConstants.PRG_MC);
            }

            if (caseAppProgRqst.get(0).getFs_rqst_ind() == 1) {
                applicant.getProgram().add(ApplicationSubmissionConstants.PRG_FS);
            }

            if (caseAppProgRqst.get(0).getTanf_rqst_ind() == 1) {
                applicant.getProgram().add(ApplicationSubmissionConstants.PRG_CW);
            }
            
            if (caseAppProgRqst.get(0).getGgr_ind() == 1) {
                applicant.getProgram().add(ApplicationSubmissionConstants.PRG_GA);
            }
        }

        //	progs for other applicants
        if (ApplicationSubmissionConstants.STR_N.equalsIgnoreCase(individual.getPrim_prsn_sw())) {
            final List<CP_APP_PGM_INDV_Collection> caseAppindvProg = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_PGM_INDV_Collection();

            if (caseAppindvProg != null && !caseAppindvProg.isEmpty()) {
                List<CP_APP_PGM_INDV_Collection> indvPrgList = caseAppindvProg.stream().filter(indvPrg -> individual.getIndv_seq_num() == indvPrg.getIndv_seq_num()).collect(Collectors.toList());
                if (indvPrgList != null && !indvPrgList.isEmpty()) {
                    for (CP_APP_PGM_INDV_Collection indvPrg : indvPrgList) {
                        if (indvPrg.getFma_rqst_ind() == 1) {
                            applicant.getProgram().add(ApplicationSubmissionConstants.PRG_MC);
                        }
                        if (indvPrg.getFs_rqst_ind() == 1) {
                            applicant.getProgram().add(ApplicationSubmissionConstants.PRG_FS);
                        }
                        if (indvPrg.getTanf_rqst_ind() == 1) {
                            applicant.getProgram().add(ApplicationSubmissionConstants.PRG_CW);
                        }
                        
                        if (indvPrg.getGgr_ind() == 1) {
                            applicant.getProgram().add(ApplicationSubmissionConstants.PRG_GA);
                        }

                    }
                }
            }
        }
        applicant.setId(ApplicationUtil.getBenefitsCalIndividualIdValue(individual.getIndv_seq_num()));
        applicant.setPrimaryApplicantInd(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(individual.getPrim_prsn_sw()));//NOSONAR
        String strSsn = individual.getSsn_num();
        if (strSsn != null && !ApplicationSubmissionConstants.STR_ZERO.equalsIgnoreCase(strSsn))
            applicant.setSsn(strSsn);
        applicant.setSsnApplyingInd(ApplicationUtil.translateBoolean(individual.getSsn_applied_sw()));//NOSONAR
        applicant.setNoSSNReason(individual.getSsn_absence_reason_cd());
        applicant.setFirstName(individual.getFst_nam());
        applicant.setLastName(individual.getLast_nam());
        applicant.setMiddleName(individual.getMid_init());
        applicant.setSuffix(individual.getSuffix_name());
        applicant.setDob(individual.getBrth_dt());
        if (!ApplicationSubmissionConstants.STR_NA.equalsIgnoreCase(individual.getAsg_sex()))
            applicant.setGenderCode(individual.getAsg_sex());
        applicant.setWrittenLangCode(individual.getLang_cd());
        applicant.setSpokenLangCode(individual.getLang_cd_sp());
        applicant.setPregnantInd(false);
        applicant.setDeafInd(ApplicationUtil.translateBoolean(individual.getEstb_deaf_resp()));//NOSONAR
        applicant.setGenderIdentity(individual.getSex_ind());
        applicant.setSexualOrientationCode(individual.getSexual_orientation());//524 - This category references the Person sexual orientation. AN: Another Sexual Orientation, BI: Bisexual, DS: Decline to State, GL: Gay or Lesbian, QU: Queer, SH: Straight or Heterosexual, UN: Unknown

        applicant.setArrivalDate(individual.getDt_entry_into_us());
        applicant.setDepartureDate(individual.getCa_dep_dt());
        applicant.setExpectedReturnDate(individual.getCa_pland_ret_dt());

        if (individual.getMrtl_stat_cd() != null && !ApplicationSubmissionConstants.STR_EMPT.equals(individual.getMrtl_stat_cd().trim()))
            applicant.setMaritalStatusCode(individual.getMrtl_stat_cd().trim());

        applicant.setHouseholdStatus(individual.getLiving_arrangement_cd());
        applicant.setSameAddressAsPrimaryInd(true);

		if (rgstInfo != null) {
			if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(rgstInfo.getPref_cont_method_cd())
					|| ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(rgstInfo.getPref_cont_method_case_cd())) {
				applicant.setPrefContactCode(ApplicationSubmissionConstants.STR_EM);
			} else if (ApplicationSubmissionConstants.STR_N.equalsIgnoreCase(rgstInfo.getPref_cont_method_cd())
					&& ApplicationSubmissionConstants.STR_N.equalsIgnoreCase(rgstInfo.getPref_cont_method_case_cd())) {
				applicant.setPrefContactCode(ApplicationSubmissionConstants.STR_RM);
			}

            applicant.setHomelessStatus(ApplicationUtil.translateBoolean(rgstInfo.getHless_sw()));//NOSONAR
            applicant.setHomelessCountyCode(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(rgstInfo.getHless_sw()) ? rgstInfo.getCnty_num() : null);//NOSONAR
            applicant.setEmailAddr(rgstInfo.getHshl_email_adr());


            if (!ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(individual.getPrim_prsn_sw()) && individual.getLiving_arrangement_cd() != null && !ApplicationSubmissionConstants.STR_IH.equals(individual.getLiving_arrangement_cd())) {

                applicant.setSameAddressAsPrimaryInd(false);

            }

        }
        if (individual.getPlace_of_birth_country() != null && !ApplicationSubmissionConstants.STR_EMPT.equalsIgnoreCase(individual.getPlace_of_birth_country().trim())) {
            applicant.setBirthCountryCode(individual.getPlace_of_birth_country());
        }
        if ((individual.getPlace_of_birth_state() != null && !ApplicationSubmissionConstants.STR_EMPT.equalsIgnoreCase(individual.getPlace_of_birth_state().trim()))
                || (individual.getPlace_of_birth_city() != null && !ApplicationSubmissionConstants.STR_EMPT.equalsIgnoreCase(individual.getPlace_of_birth_city().trim()))) {
            VitalStatistics vitalStatistics = new VitalStatistics();
            vitalStatistics.setBirthCityName(individual.getPlace_of_birth_city());
            vitalStatistics.setBirthStateCode(individual.getPlace_of_birth_state());
            applicant.setVitalStatistics(vitalStatistics);
        }

        applicant.setHouseholdStatus(individual.getLiving_arrangement_cd());
        applicant.setAliasFirstName(individual.getAlias_fst_nam());
        applicant.setAliasLastName(individual.getAlias_last_nam());
        applicant.setAliasMiddleName(individual.getAlias_mid_init());
        applicant.setAliasSuffix(individual.getAlias_suffix_name());
        applicant.setTribe(individual.getTribe_name());
        applicant.setHispanicEthnicInd(ApplicationUtil.translateBoolean(individual.getHspc_ind()));//NOSONAR
        applicant.setEthnicInd(ApplicationUtil.translateBoolean(individual.getHspc_ind()));//NOSONAR
        applicant.setEthnicOrigin(individual.getEthnicity_cd());
        applicant.setDisabilityInd(ApplicationUtil.translateBoolean(individual.getEstb_dabl_resp()));//NOSONAR
        applicant.setDeafInd(ApplicationUtil.translateBoolean(individual.getEstb_deaf_resp()));//NOSONAR
        DisabilityDetails disabilityDetails = getDisabilityDetails(source, individual.getIndv_seq_num());
        if (disabilityDetails != null) {
            applicant.setDisabilityInd(true);
            applicant.setDisabilityDetails(disabilityDetails);
        }

        if (indvAddInfo != null) {

            applicant.setHhGrossIncomeLessThan150Ind(ApplicationUtil.translateBoolean(indvAddInfo.getGross_income_less()));//NOSONAR
            applicant.setMigrantInd(ApplicationUtil.translateBoolean(indvAddInfo.getMig_farm_wrkr_resp()));//NOSONAR
            applicant.setDestituteInd(ApplicationUtil.translateBoolean(indvAddInfo.getMig_farm_wrkr_resp()));//NOSONAR
            applicant.setHhGrossIncomeLessRentUtilitiesInd(ApplicationUtil.translateBoolean(indvAddInfo.getCombined_gross_income()));//NOSONAR
        }

        final List<CP_APP_IMMED_CASH_Collection> indvImmCashList = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_IMMED_CASH_Collection();
        if (indvImmCashList != null && !indvImmCashList.isEmpty()) {
            applicant.setUtilitiesShutOffInd(ApplicationUtil.translateBoolean(indvImmCashList.get(0).getUtil_shut_off()));//NOSONAR
            applicant.setNoFoodInd(ApplicationUtil.translateBoolean(indvImmCashList.get(0).getFood_run_out()));//NOSONAR
            applicant.setEvictionNoticeInd(ApplicationUtil.translateBoolean(indvImmCashList.get(0).getEviction_notice()));//NOSONAR
            applicant.setEssentialInd(ApplicationUtil.translateBoolean(indvImmCashList.get(0).getEssential_clothing()));//NOSONAR
            applicant.setHelpwithTransportationInd(ApplicationUtil.translateBoolean(indvImmCashList.get(0).getTransport_help()));//NOSONAR
        }

        final List<APP_IN_Primary_Caretaker_Collection> indvPriCrList = source.getHouseholdDemographicsProfileDetails().getPageCollection().getAPP_IN_Primary_Caretaker_Collection();
        if (indvPriCrList != null && !indvPriCrList.isEmpty()) {
            List<APP_IN_Primary_Caretaker_Collection> indvPriList = indvPriCrList.stream().filter(indvPriCare -> individual.getIndv_seq_num() == indvPriCare.getIndv_seq_num()).collect(Collectors.toList());
            if (indvPriList != null && !indvPriList.isEmpty()) {
                for (APP_IN_Primary_Caretaker_Collection priCare : indvPriList) {
                    applicant.setFosterCare18thInd(ApplicationUtil.translateBoolean(priCare.getIn_foster_eighteenth_brth_ind()));//NOSONAR
                    applicant.setFosterChildinHomeInd(ApplicationUtil.translateBoolean(priCare.getFoster_court_ord_dep_ind()));//NOSONAR
                }
            }
        }
        applicant.setFullTimeStudentInd(ApplicationUtil.translateBoolean(individual.getSchool_type_ind()));//NOSONAR
        applicant.setFcChildOrderOfCourtInd(ApplicationUtil.translateBoolean(individual.getFoster_court_ord_dep_ind()));//NOSONAR
        applicant.setCountFCChildInCFCaseInd(ApplicationUtil.translateBoolean(individual.getFoster_incl_calfresh_ind()));//NOSONAR
        applicant.setFosterChildState(individual.getFormer_foster_state());
        applicant.setFosterCareBeginDate(individual.getFormer_foster_from_dt());
        applicant.setFosterCareEndDate(individual.getFormer_foster_to_dt());
        applicant.setFederallyRecognizedTribeInd(ApplicationUtil.translateBoolean(individual.getRace_memb_fed_rec_trb_ind()));//NOSONAR

        applicant.setProjectedHouseHoldIncome(null);
        applicant.setOtherEthnicText(individual.getHspc_dsc_cd() != null ? individual.getHspc_dsc_cd() : individual.getHspc_oth_dsc());//NOSONAR
        applicant.setTribeHealthPgmInd(ApplicationUtil.translateBoolean(individual.getEligible_hs_ind()));//NOSONAR
        applicant.setEligTribalserviceInd(ApplicationUtil.translateBoolean(individual.getEligible_hs_ind()));//NOSONAR
        applicant.setReceivedTribalServiceInd(ApplicationUtil.translateBoolean(individual.getRecv_srvc_sw()));//NOSONAR
        applicant.setPdjIdentif(individual.getJpd_oth_desc());
        applicant.setUnableToFixMealsInd(ApplicationUtil.translateBoolean(individual.getUnable_meal_dabl_sw()));//NOSONAR
        applicant.setRequiresCareText(null);
        applicant.setShotsUpToDateInd(ApplicationUtil.translateBoolean(individual.getVaccine_ind()));//NOSONAR
        applicant.setLeaveCalifFor30Ind(ApplicationUtil.translateBoolean(individual.getCa_leave_thirty_ind()));//NOSONAR
        applicant.setExpectToContinueToLiveinCalInd(ApplicationUtil.translateBoolean(individual.getCa_ret_ind()));//NOSONAR
        applicant.setLeftCall(individual.getLeaving_ca_rsn_desc());
        applicant.setWhenToLeave(individual.getCa_dep_dt());
        applicant.setWhenToReturn(individual.getCa_pland_ret_dt());
        applicant.setReturnPlanToCaliInd(ApplicationUtil.translateBoolean(individual.getCa_ret_ind()));//NOSONAR

        List<Address> addresses = BuildAddressDetailsHelper.buildAddressDetails(rgstInfo);
        if (addresses != null && !addresses.isEmpty())
            applicant.setAddressess(addresses);

        List<PhoneNumber> phoneNumbers = BuildContactInfoDetailsHelper.buildPhoneNumber(rgstInfo);
        if (phoneNumbers != null && !phoneNumbers.isEmpty())
            applicant.setPhoneNumbers(phoneNumbers);

        if (source.getHouseholdDemographicsProfileDetails() != null) {
            List<APP_IN_SCHLE_Collection> schoolList = source.getHouseholdDemographicsProfileDetails().getPageCollection().getAPP_IN_SCHLE_Collection();
            if (schoolList != null && !schoolList.isEmpty()) {
                FwLogger.log(BuildIndividualDetailsHelper.class,
                        FwLogger.Level.INFO,
                        "*************************************Before loading School Info************************************************");
                final List<School> schools = BuildSchoolDetailsHelper.buildSchoolDetails(schoolList, individual.getIndv_seq_num());
                applicant.setSchools(schools);
                FwLogger.log(BuildIndividualDetailsHelper.class,
                        FwLogger.Level.INFO,
                        "*************************************Successfully loaded School Info************************************************");
            }
        }

        if (source.getFinancialIncomeSummaryDetails() != null) {
            final List<Income> incomesList = new ArrayList<>();

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************Before loading Earned Income Info************************************************");
            final List<Income> empIncomes = BuildEarnedIncomeDetailsHelper.buildEarnedIncome(source, individual.getIndv_seq_num());
            incomesList.addAll(empIncomes);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************Successfully loaded Earned Income Info************************************************");


            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************Before loading Self Employment Info************************************************");
            final List<Income> selfIncomes = BuildSelfEmpIncomeDetailsHelper.buildSelfIncome(source, individual.getIndv_seq_num());
            incomesList.addAll(selfIncomes);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************Successfully loaded Self Employment Info************************************************");

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************Before loading Unearned Income Info************************************************");
            final List<Income> unearnIncomes = BuildUnEarnedIncomeDetailsHelper.buildUnearnedIncome(source, individual.getIndv_seq_num());
            incomesList.addAll(unearnIncomes);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************Successfully loaded Unearned Income Info************************************************");
            if (incomesList != null && !incomesList.isEmpty())
                applicant.setIncomes(incomesList);

            final List<APP_IN_EMPL_Collection> indvyrIncomeList = source.getFinancialIncomeSummaryDetails().getPageCollection().getaPP_IN_EMPL_Collection();
            if (indvyrIncomeList != null && !indvyrIncomeList.isEmpty()) {
                List<APP_IN_EMPL_Collection> indvIncomeList = indvyrIncomeList.stream().filter(indvYrIncome -> individual.getIndv_seq_num() == indvYrIncome.getIndv_seq_num()).collect(Collectors.toList());
                if (indvIncomeList != null && !indvIncomeList.isEmpty()) {
                    for (APP_IN_EMPL_Collection yrIncome : indvIncomeList) {
						if(yrIncome.getYearly_income_current_year() != null || yrIncome.getYearly_income_next_year() != null) {
							applicant.setTotalIncomeThisYear(yrIncome.getYearly_income_current_year());
							applicant.setTotalIncomeNextYear(yrIncome.getYearly_income_next_year());
						}
					}
                }
            }

            final List<Job> jobs = BuildJobsDetailsHelper.buildJobDetails(source, individual.getIndv_seq_num());
            if (jobs != null && !jobs.isEmpty())
                applicant.setJobs(jobs);

            final List<Strike> strike = BuildEarnedIncomeDetailsHelper.getStrikeDetails(source, individual.getIndv_seq_num());
            if (strike != null && !strike.isEmpty())
                applicant.setStrike(strike);

            BuildUnEarnedIncomeDetailsHelper.setCalLrnDetails(source, individual.getIndv_seq_num(), applicant);

            final List<OtherPgmAssistance> otherPgmAssistances = BuildOtherPrgDetailsHelper.buildOtherPrgDetails(source, individual.getIndv_seq_num());
            if (otherPgmAssistances != null && !otherPgmAssistances.isEmpty())
                applicant.setOtherPgmAssistances(otherPgmAssistances);
        }

        if (source.getFinancialExpenseSummaryDetails() != null) {
            final List<Expenses> expensesList = new ArrayList<>();

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before buildHouseExpenses************************************************");
            final List<Expenses> houseExpenses = BuildHousingCostsDetailsHelper.buildHouseExpenses(source, individual.getIndv_seq_num());
            expensesList.addAll(houseExpenses);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after buildHouseExpenses************************************************");

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before buildIncomeTaxExpenses************************************************");
            final List<Expenses> taxExpenses = BuildIncomeTaxDetailsHelper.buildIncomeTaxExpenses(source, individual.getIndv_seq_num());
            expensesList.addAll(taxExpenses);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after buildIncomeTaxExpenses************************************************");

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before buildMedicalExpenses************************************************");
            final List<Expenses> medExpenses = BuildMedicalBillsDetailsHelper.buildMedicalExpenses(source, individual.getIndv_seq_num());
            expensesList.addAll(medExpenses);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after buildMedicalExpenses************************************************");

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before buildDeductionExpenses************************************************");
            final List<Expenses> dedExpenses = BuildDeductionDetailsHelper.buildDeductionExpenses(source, individual.getIndv_seq_num());
            expensesList.addAll(dedExpenses);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after buildDeductionExpenses************************************************");

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before buildChildExpenses************************************************");
            final List<Expenses> childExpenses = BuildChildCareExpDetailsHelper.buildChildExpenses(source, individual.getIndv_seq_num());
            expensesList.addAll(childExpenses);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after buildChildExpenses************************************************");
            if (expensesList != null && !expensesList.isEmpty())
                applicant.setExpenses(expensesList);

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before getRetroDetails************************************************");
            final List<RetroMedical> retroMedical = BuildMedicalBillsDetailsHelper.getRetroDetails(source, individual.getIndv_seq_num());
            if (retroMedical != null && !retroMedical.isEmpty())
                applicant.setRetroMedical(retroMedical);

            final List<SpecialNeed> specialNeeds = getSpecialNeeds(source, individual.getIndv_seq_num());
            if (specialNeeds != null && !specialNeeds.isEmpty())
                applicant.setSpecialNeeds(specialNeeds);

            BuildMedicalBillsDetailsHelper.setIhssDetails(source, individual.getIndv_seq_num(), applicant);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after getRetroDetails************************************************");
        }
        if (source.getFinancialAssetSummaryDetails() != null) {
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before buildPersonalProperties************************************************");
            final List<PersonalProperty> personAsetsList = BuildPersonalPropDetailsHelper.buildPersonalProperties(source, individual.getIndv_seq_num());
            if (personAsetsList != null && !personAsetsList.isEmpty())
                applicant.setPersonalProperties(personAsetsList);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after buildPersonalProperties************************************************");

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before buildTransferRecords************************************************");
            final List<SoldAsset> soldAssetsList = BuildSoldAssetInfoDetailsHelper.buildTransferRecords(source.getFinancialAssetSummaryDetails().getPageCollection().getCP_APP_IN_ASET_XFER_Collection(), individual.getIndv_seq_num());
            if (soldAssetsList != null && !soldAssetsList.isEmpty())
                applicant.setSoldAssets(soldAssetsList);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after buildTransferRecords************************************************");

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before buildLiquidAssets************************************************");
            final List<LiquidResource> liquidResourceList = BuildLiquidAssetDetailsHelper.buildLiquidAssets(source, individual.getIndv_seq_num());
            if (liquidResourceList != null && !liquidResourceList.isEmpty())
                applicant.setLiquidResource(liquidResourceList);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after buildLiquidAssets************************************************");

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before buildRealProperty************************************************");
            final List<RealProperties> realPropList = BuildRealPropertyDetailsHelper.buildRealProperty(source, individual.getIndv_seq_num());
            if (realPropList != null && !realPropList.isEmpty())
                applicant.setRealProperties(realPropList);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after buildRealProperty************************************************");

            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************before buildvehicle************************************************");
            final List<Vehicle> vehiclesList = BuildVehicleDetailsHelper.buildvehicle(source, individual.getIndv_seq_num());
            if (vehiclesList != null && !vehiclesList.isEmpty())
                applicant.setVehicles(vehiclesList);
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "*************************************after buildvehicle************************************************");
        }
        if (source.getNonFinancialInformationDetails() != null) {
            final List<HealthCoverage> hlthCovList = BuildHealthInsurDetailsHelper.buildHealthInsurDetails(source, individual.getIndv_seq_num());
            if (hlthCovList != null && !hlthCovList.isEmpty()) {
                applicant.setHealthCoverage(hlthCovList);
            }

            setCashFraudDetails(source, individual.getIndv_seq_num(), applicant);
            setParoleDetails(source, individual.getIndv_seq_num(), applicant);
        }

        Ethnicities ethnicities = null;
        List<Ethnicities> ethnicList = new ArrayList<>(); 
        String raceStr = individual.getRace_cd();
		if(raceStr != null && !ApplicationSubmissionConstants.STR_EMPT.equals(raceStr.trim())
				&& !ApplicationSubmissionConstants.STR_NA.equalsIgnoreCase(raceStr)) {		
		  Ethnicity ethncity = new Ethnicity(); 		  
		  ethncity.setRace(raceStr);
		  if(ApplicationSubmissionConstants.STR_AS.equalsIgnoreCase(raceStr))
			  ethncity.setRace(ApplicationSubmissionConstants.STR_04);
		  if(ApplicationSubmissionConstants.STR_04.equals(raceStr)
				  || ApplicationSubmissionConstants.STR_19.equals(raceStr))
			  ethncity.setEthnicOriginText(individual.getRace_oth_dsc()); 
		  if(individual.getTribe_name() != null && !ApplicationSubmissionConstants.STR_EMPT.equals(individual.getTribe_name().trim()))
			  ethncity.setTribe(individual.getTribe_name()); 
		  ethnicities = new Ethnicities();
		  ethnicities.setEthnicity(ethncity);		 
		  ethnicList.add(ethnicities);
		}

        String hspcInd = individual.getHspc_ind();
		if(hspcInd != null && ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(hspcInd)) {
			String hspcDesc = individual.getHspc_dsc_cd();
			Ethnicity ethncty = new Ethnicity(); 
			if(individual.getTribe_name() != null && !ApplicationSubmissionConstants.STR_EMPT.equals(individual.getTribe_name().trim()))
				  ethncty.setTribe(individual.getTribe_name());  
			if(hspcDesc != null && !ApplicationSubmissionConstants.STR_EMPT.equals(hspcDesc.trim())) {
				if("C".equalsIgnoreCase(hspcDesc.trim()))
					ethncty.setRace("CB");
				else if("M".equalsIgnoreCase(hspcDesc.trim()))
					ethncty.setRace("MX");
				else if("P".equalsIgnoreCase(hspcDesc.trim()))
					ethncty.setRace("PR");
				else if("S".equalsIgnoreCase(hspcDesc.trim()))
					ethncty.setRace("SV");
				else if("G".equalsIgnoreCase(hspcDesc.trim()))
					ethncty.setRace("GU");
				else if("O".equalsIgnoreCase(hspcDesc.trim())) {
					ethncty.setRace("OH");
					ethncty.setEthnicOriginText(individual.getHspc_oth_dsc());
				}
				
				ethnicities = new Ethnicities();
				ethnicities.setEthnicity(ethncty);
				ethnicList.add(ethnicities);
			}			
		}
		
				
		String ethnicCd = individual.getEthnicity_cd(); 		
		if(ethnicCd != null && !ApplicationSubmissionConstants.STR_EMPT.equals(ethnicCd.trim()) && !"SEL".equalsIgnoreCase(ethnicCd)) {
			Ethnicity ethcty = new Ethnicity(); 	
			ethnicities = new Ethnicities();
			ethcty.setRace(ethnicCd);
			if(individual.getTribe_name() != null && !ApplicationSubmissionConstants.STR_EMPT.equals(individual.getTribe_name().trim()))
				ethcty.setTribe(individual.getTribe_name()); 
			ethnicities.setEthnicity(ethcty);	
			ethnicList.add(ethnicities);  
		}
		
        if(ethnicList != null && ethnicList.size() > 0)
        	applicant.setEthnicities(ethnicList); 		

        if (individual.getUs_ctzn_sw() != null && ApplicationSubmissionConstants.STR_Y.equals(individual.getUs_ctzn_sw())) {
            final Citizenship citizenship = new Citizenship();
            citizenship.setUsCitzOrNationalInd(true);
            applicant.setCitizenship(citizenship);
        } else if (individual.getUs_ctzn_sw() != null && ApplicationSubmissionConstants.STR_N.equals(individual.getUs_ctzn_sw())) {
            final Citizenship citizenship = new Citizenship();
            citizenship.setUsCitzOrNationalInd(false);
            citizenship.setAlienNumber(individual.getAlien_num());
            citizenship.setApplyForVisaInd(ApplicationUtil.translateBoolean(individual.getImm_plan_ind()));//NOSONAR
            citizenship.setCitznCertificateNumber(null);
            citizenship.setCitznEligibleImmigrationInd(ApplicationUtil.translateBoolean(individual.getVld_immgrtn_sts()));//NOSONAR
            citizenship.setCtznReceiveDate(null);
            citizenship.setDateOfChange(individual.getImm_status_chg_dt());
            citizenship.setDocumentNumber(individual.getAlien_doc_num());
            citizenship.setEntryDate(individual.getDt_entry_into_us());
            citizenship.setFirstNamePerDocument(null);
            citizenship.setIdenReceiveDate(null);
            citizenship.setIdentityDocCode(individual.getAlien_doc_type_cd());
            citizenship.setImmigrationChangedin12Ind(ApplicationUtil.translateBoolean(individual.getAlien_status_cd()));//NOSONAR
            citizenship.setInUSSince1996Ind(ApplicationUtil.translateBoolean(individual.getLived_in_us_con_sw()));//NOSONAR
            citizenship.setLastNamePerDocument(null);
            citizenship.setMiddleNamePerDocument(null);
            citizenship.setNameSuffixPerDocument(null);
            citizenship.setNaturalizationNumber(null);
            citizenship.setNaturalizedCitzInd(ApplicationUtil.translateBoolean(individual.getNaturalized_ctzn_ind()));//NOSONAR
            citizenship.setTenYearWorkHistoryInd(ApplicationUtil.translateBoolean(individual.getImm_wrk_hist_ind()));//NOSONAR
            citizenship.setTypeCode(individual.getAlien_doc_cd());
            citizenship.setWhatChanged(individual.getImm_status_value());
            
            applicant.setCitizenship(citizenship);
        }

        PregnancyDetail pregnancyDetail = getPregnancyDetails(source, individual.getIndv_seq_num());
        if (pregnancyDetail != null) {
            applicant.setPregnantInd(true);
            applicant.setPregnancyDetail(pregnancyDetail);
        }

        List<LivingArrangement> livingArrangements = getLivingArngmntsDetails(source, individual.getIndv_seq_num());
        if (livingArrangements != null && !livingArrangements.isEmpty())
            applicant.setLivingArrangements(livingArrangements);

        Veteran veteran = getVeteranDetails(individual);
        if (veteran != null)
            applicant.setVeteran(veteran);
        FwLogger.log(BuildIndividualDetailsHelper.class,
                FwLogger.Level.INFO,
                "*************************************before buildTribalTanfDetails************************************************");
        BuildAdditionalServicesInfoDetailsHelper.buildTribalTanfDetails(source, individual.getIndv_seq_num(), applicant);
        BuildAdditionalServicesInfoDetailsHelper.buildTeenDetails(source, individual.getIndv_seq_num(), applicant);
        BuildHealthInsurDetailsHelper.setThirdPartyInd(source, individual.getIndv_seq_num(), applicant);
        FwLogger.log(BuildIndividualDetailsHelper.class,
                FwLogger.Level.INFO,
                "*************************************after buildTribalTanfDetails************************************************");

        setConvictionDetails(source, individual.getIndv_seq_num(), applicant);

        List<TaxHousehold> taxHouseholdList = BuildIncomeTaxDetailsHelper.getTaxDetails(source, individual.getIndv_seq_num());
        if (taxHouseholdList != null && !taxHouseholdList.isEmpty()) {
            applicant.setTaxHousehold(taxHouseholdList);
            if (taxHouseholdList.get(0).getTaxDependents() != null && !taxHouseholdList.get(0).getTaxDependents().isEmpty())
                applicant.setTaxDependentInd(true);
        }


        return applicant;
    }

    public static DisabilityDetails getDisabilityDetails(AggregatedPayload source, int indvSeqNum) {//NOSONAR
        DisabilityDetails disbDetails = null;
        List<APP_IN_DABL_Collection> indvsDisbList = null;
        try {
            indvsDisbList = source.getHouseholdDemographicsProfileDetails().getPageCollection().getAPP_IN_DABL_Collection();
            if (indvsDisbList != null && !indvsDisbList.isEmpty()) {
                List<APP_IN_DABL_Collection> indvDisbList = indvsDisbList.stream().filter(indvDisb -> indvSeqNum == indvDisb.getIndv_seq_num()).collect(Collectors.toList());

                if (indvDisbList != null && !indvDisbList.isEmpty()) {
                    for (APP_IN_DABL_Collection indvDisb : indvDisbList) {
                        disbDetails = new DisabilityDetails();
                        disbDetails.setLimitActivitiesInd(ApplicationUtil.translateBoolean(indvDisb.getDabl_lim_activity_ind()));//NOSONAR
                        disbDetails.setNeedsCareFromHHMember(false);
                        disbDetails.setInFacilityOrNursingHomeInd(ApplicationUtil.translateBoolean(indvDisb.getNursing_care_ind()));//NOSONAR
                        disbDetails.setFacilityOrHomeName(indvDisb.getNur_hspc_prvd_nm());
                        disbDetails.setNeedsCareFromHHMember(ApplicationUtil.translateBoolean(indvDisb.getNeed_care_other_hhm()));//NOSONAR
                        disbDetails.setCareSoOtherCanWorkInd(ApplicationUtil.translateBoolean(indvDisb.getNeed_care_work_schl_ind()));//NOSONAR
                        if (ApplicationSubmissionConstants.STR_TH.equalsIgnoreCase(indvDisb.getDabl_more_than_one_yr_ind().trim()))
                            disbDetails.setLessThanOneYearInd(true);
                        if (ApplicationSubmissionConstants.STR_TW.equalsIgnoreCase(indvDisb.getDabl_more_than_one_yr_ind().trim()))
                            disbDetails.setMoreThanOneYearInd(true);
                        disbDetails.setNeedsCareFromHHMemberText(indvDisb.getNeed_care_other_hhm_desc());
                        disbDetails.setNeedsHelpText(indvDisb.getDabl_caring_desc());
                        disbDetails.setNeedsHelpWithDailyLivingInd(ApplicationUtil.translateBoolean(indvDisb.getCaring_disabled_resp()));//NOSONAR
                        disbDetails.setNeedToWorkForMedExnsInd(ApplicationUtil.translateBoolean(indvDisb.getDabl_med_expens_work_ind()));//NOSONAR
                        disbDetails.setNeedToWorkForMedExnsText(indvDisb.getDabl_med_expens_work_desc());
                    }
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while getDisabilityDetails::" + e.getMessage());
        }

        return disbDetails;
    }

    public static List<SpecialNeed> getSpecialNeeds(AggregatedPayload source, int indvSeqNum) {//NOSONAR

        SpecialNeed spclDetails = null;
        List<CP_APP_IN_MED_BILLS> indvsSpclList = null;
        List<SpecialNeed> spclPrgList = new ArrayList<>();
        String[] progArray = new String[]{ApplicationSubmissionConstants.STR_09, ApplicationSubmissionConstants.STR_19,
                ApplicationSubmissionConstants.STR_18, ApplicationSubmissionConstants.STR_08,
                ApplicationSubmissionConstants.STR_17, ApplicationSubmissionConstants.STR_OT};
        List<String> otherPrgList = new ArrayList<>(Arrays.asList(progArray));
        try {
            indvsSpclList = source.getFinancialExpenseSummaryDetails().getPageCollection().getCP_APP_IN_MED_BILLS();
            if (indvsSpclList != null && !indvsSpclList.isEmpty()) {
                List<CP_APP_IN_MED_BILLS> indvSpclList = indvsSpclList.stream().filter(indvDisb -> indvSeqNum == indvDisb.getIndv_seq_num()).collect(Collectors.toList());

                if (indvSpclList != null && !indvSpclList.isEmpty()) {
                    for (CP_APP_IN_MED_BILLS indvSpcl : indvSpclList) {
                        spclDetails = new SpecialNeed();
                        if (otherPrgList.contains(indvSpcl.getMed_bill_type())) {
                            spclDetails.setType(indvSpcl.getMed_bill_type());
                            spclDetails.setSpecialNeedsText(indvSpcl.getSpecial_needs_desc());
                            spclPrgList.add(spclDetails);
                        }
                    }
                }
            }

        } catch (Exception e) {
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while getSpecialNeeds::" + e.getMessage());
        }
        return spclPrgList;
    }

    public static List<LivingArrangement> getLivingArngmntsDetails(AggregatedPayload source, int indvSeqNum) {//NOSONAR
        LivingArrangement lvngArr = null;
        List<APP_IN_SHLTC_Collection> indvsLvngList = null;
        List<LivingArrangement> livingArmntList = new ArrayList<>();
        try {
            indvsLvngList = source.getHouseholdDemographicsProfileDetails().getPageCollection().getAPP_IN_SHLTC_Collection();
            if (indvsLvngList != null && !indvsLvngList.isEmpty()) {
                List<APP_IN_SHLTC_Collection> indvLvngList = indvsLvngList.stream().filter(indvLivng -> indvSeqNum == indvLivng.getIndv_seq_num()).collect(Collectors.toList());
                if (indvLvngList != null && !indvLvngList.isEmpty()) {
                    for (APP_IN_SHLTC_Collection indvDisb : indvLvngList) {
                        if (indvDisb.getShlt_typ() != null || indvDisb.getShelt_name() != null) {
                            lvngArr = new LivingArrangement();
                            if (indvDisb.getShlt_typ() != null)
                                lvngArr.setTypeCode(indvDisb.getShlt_typ());
                            lvngArr.setBegDate(indvDisb.getChg_eff_dt());
                            lvngArr.setEndDate(indvDisb.getRelease_dt());
                            lvngArr.setShelterName(indvDisb.getShelt_name());
                            livingArmntList.add(lvngArr);
                        }
                    }
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while getLivingArngmntsDetails::" + e.getMessage());
        }
        return livingArmntList;
    }

    public static PregnancyDetail getPregnancyDetails(AggregatedPayload source, int indvSeqNum) {//NOSONAR
        PregnancyDetail pregnancyDetail = null;
        List<APP_IN_PREG_Collection> indvsPregList = null;
        try {
            indvsPregList = source.getHouseholdDemographicsProfileDetails().getPageCollection().getAPP_IN_PREG_Collection();

            if (indvsPregList != null && !indvsPregList.isEmpty()) {
                List<APP_IN_PREG_Collection> indvPregList = indvsPregList.stream().filter(indvPreg -> indvSeqNum == indvPreg.getIndv_seq_num()).collect(Collectors.toList());

                if (indvPregList != null && !indvPregList.isEmpty()) {
                    for (APP_IN_PREG_Collection pregnancy : indvPregList) {
                        pregnancyDetail = new PregnancyDetail();
                        pregnancyDetail.setDueDate(pregnancy.getPreg_due_dt());
                        if (pregnancy.getBaby_ct() != null && StringUtils.isNumeric(pregnancy.getBaby_ct()))
                            pregnancyDetail.setNumberUnborn(Integer.parseInt(pregnancy.getBaby_ct()));
                        pregnancyDetail.setPresumptiveEligCardInd(ApplicationUtil.translateBoolean(pregnancy.getPresump_elig_card_ind()));//NOSONAR
                        pregnancyDetail.setSchoolStatusCode(pregnancy.getEnrl_stat_cd());
                        pregnancyDetail.setSchoolStatusExplain(pregnancy.getNt_enrl_stat_desc());
                    }
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while getPregnancyDetails::" + e.getMessage());
        }
        return pregnancyDetail;
    }

    public static Veteran getVeteranDetails(APP_INDV_Collection veteran) {//NOSONAR
        Veteran vetaranDetail = null;
        try {
            if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(veteran.getVet_resp())
                    || ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(veteran.getVet_dep_resp())
                    || ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(veteran.getVet_act_duty_resp())) {
                vetaranDetail = new Veteran();
                vetaranDetail.setActiveInd(ApplicationUtil.translateBoolean(veteran.getVet_act_duty_resp()));//NOSONAR
                vetaranDetail.setBegDate(veteran.getVet_serv_from_dt());
                vetaranDetail.setCampusBenefitInd(false);
                vetaranDetail.setEndDate(veteran.getVet_serv_to_dt());
                vetaranDetail.setFirstName(veteran.getFst_nam());
                vetaranDetail.setHonorableDischargeInd(ApplicationUtil.translateBoolean(veteran.getVet_hon_discharge_ind()));
                vetaranDetail.setLastName(veteran.getLast_nam());
                vetaranDetail.setMiddleName(veteran.getMid_init());
                if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(veteran.getVet_dep_resp()))
                    vetaranDetail.setVeteranStatus(ApplicationSubmissionConstants.STR_DM);
                if (ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(veteran.getVet_resp()))
                    vetaranDetail.setVeteranStatus(ApplicationSubmissionConstants.STR_MV);
            }

        } catch (Exception e) {
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while getVeteranDetails::" + e.getMessage());
        }
        return vetaranDetail;
    }

    public static void setCashFraudDetails(AggregatedPayload source, int indvSeqNum, Applicant cashFraud) {//NOSONAR

    	List<CP_APP_IN_CSHAID_STP_Collection> cashFraudList =  null;
		List<CP_APP_IN_CSHAID_STP_Collection> cashFraudIndvList =  null;
		try {
			cashFraudList = source.getNonFinancialInformationDetails().getPageCollection().getCP_APP_IN_CSHAID_STP_Collection();
			if(cashFraudList != null && !cashFraudList.isEmpty()) {
				cashFraudIndvList = cashFraudList.stream().filter(indvFraud->indvSeqNum == indvFraud.getIndv_seq_num()).collect(Collectors.toList());	

				for(CP_APP_IN_CSHAID_STP_Collection cashFrColl : cashFraudIndvList) {
					if(ApplicationSubmissionConstants.STR_WF.equalsIgnoreCase(cashFrColl.getType_cd())) {
						cashFraud.setCashFraudCountyCode(cashFrColl.getCounty());
						cashFraud.setCashFraudDate(cashFrColl.getStopped_dt());
						cashFraud.setCashFruadState(cashFrColl.getState_cd());
						cashFraud.setCashFraudInd(true);
					} 
					if(ApplicationSubmissionConstants.STR_NC.equalsIgnoreCase(cashFrColl.getType_cd())) {
						cashFraud.setFailedToCooperateDate(cashFrColl.getStopped_dt());
						cashFraud.setFailedToCooperateCounty(cashFrColl.getCounty());
						cashFraud.setFailedToCooperateState(cashFrColl.getState_cd());
					}
				}
			}
        } catch (Exception e) {
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while setCashFraudDetails::" + e.getMessage());
        }
    }

    public static void setConvictionDetails(AggregatedPayload source, int indvSeqNum, Applicant convIndv) {//NOSONAR

        List<OTHER_HOUSEHOLD_DETAILS_Collection> convIndvList = null;
        try {
            convIndvList = source.getHouseholdDemographicsPersonDetails().getPageCollection().getOTHER_HOUSEHOLD_DETAILS_Collection();
            if (convIndvList != null && !convIndvList.isEmpty()) {
                OTHER_HOUSEHOLD_DETAILS_Collection convColl = convIndvList.stream().filter(indvConv -> indvSeqNum == indvConv.getIndv_seq_num()).findFirst().orElse(null);
                if (convColl != null) {
                	if(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(convColl.getDup_food_assisstance())) {
                		convIndv.setFraudDuplicateSnapInd(true);
                	}
                	if(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(convColl.getSell_ebt_card())) {
                		convIndv.setConvictedOfSNAPBenefitsInd(true);
                	}
                	if(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(convColl.getCnvct_of_tr_fs_gun_resp())) {
                		convIndv.setGuiltOfGunsAmmunitionInd(true);
                	}
                	if(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(convColl.getCnvct_of_tr_fs_drg_resp())) {
                		convIndv.setGuiltOfTradingSNAPBeneInd(true);
                	}
                 }
            }
        } catch (Exception e) {
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while setConvictionDetails::" + e.getMessage());
        }
    }

    public static void setParoleDetails(AggregatedPayload source, int indvSeqNum, Applicant paroleIndv) {//NOSONAR

        List<APP_IN_PNLT_FRD_Collection> parolIndvList = null;
        List<APP_IN_PNLT_FRD_Collection> indvParList = null;
        try {
            parolIndvList = source.getNonFinancialInformationDetails().getPageCollection().getAPP_IN_PNLT_FRD_Collection();
            if (parolIndvList != null && !parolIndvList.isEmpty()) {
                indvParList = parolIndvList.stream().filter(indv -> indvSeqNum == indv.getIndv_seq_num()).collect(Collectors.toList());

                for (APP_IN_PNLT_FRD_Collection parolColl : indvParList) {
                    if (ApplicationSubmissionConstants.STR_ABJOF.equalsIgnoreCase(parolColl.getType())) {
                        paroleIndv.setFleeingFelon(true);
                    }
                    if (ApplicationSubmissionConstants.STR_ABPRV.equalsIgnoreCase(parolColl.getType())) {
                        paroleIndv.setParoleViolationInd(true);
                    }
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildIndividualDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while setParoleDetails::" + e.getMessage());
        }
    }

}