package gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial;

public class CP_APP_IN_WORKERS_COMP_Collection {
	private int indv_seq_num;

	public int getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
}
