package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class PregnancyDetail {

	private Boolean presumptiveEligCardInd;
	private String dueDate;
	private int numberUnborn;
	private String schoolStatusCode;
	private String schoolStatusExplain;

	public Boolean isPresumptiveEligCardInd() {
		return presumptiveEligCardInd;
	}

	public void setPresumptiveEligCardInd(Boolean presumptiveEligCardInd) {
		this.presumptiveEligCardInd = presumptiveEligCardInd;
	}

	public String getDueDate() {
		return dueDate;
	}

	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}

	public int getNumberUnborn() {
		return numberUnborn;
	}

	public void setNumberUnborn(int numberUnborn) {
		this.numberUnborn = numberUnborn;
	}

	public String getSchoolStatusCode() {
		return schoolStatusCode;
	}

	public void setSchoolStatusCode(String schoolStatusCode) {
		this.schoolStatusCode = schoolStatusCode;
	}

	public String getSchoolStatusExplain() {
		return schoolStatusExplain;
	}

	public void setSchoolStatusExplain(String schoolStatusExplain) {
		this.schoolStatusExplain = schoolStatusExplain;
	}
}
