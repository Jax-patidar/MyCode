package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_EMPL_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income.APP_IN_SELFE_Collection;
import gov.state.nextgen.application.submission.view.payload.Address;
import gov.state.nextgen.application.submission.view.payload.Job;
import gov.state.nextgen.application.submission.view.payload.PhoneNumber;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BuildJobsDetailsHelper {
	
	private BuildJobsDetailsHelper() {}
	
	public static List<Job> buildJobDetails(AggregatedPayload source, int indvSeq) {//NOSONAR

		Job job = null;
		List<Job> jobArrList = new ArrayList<>();
		
		try {
			List<APP_IN_EMPL_Collection> jobEmpList = source.getFinancialIncomeSummaryDetails().getPageCollection().getaPP_IN_EMPL_Collection();

			if(jobEmpList != null && !jobEmpList.isEmpty()) {
				List<APP_IN_EMPL_Collection> indvJobEmpList = jobEmpList.stream().filter(liqAset->indvSeq == liqAset.getIndv_seq_num()).collect(Collectors.toList());

				if(indvJobEmpList != null && !indvJobEmpList.isEmpty()) {
					for(APP_IN_EMPL_Collection jobEmpColl : indvJobEmpList) {
						if(!ApplicationSubmissionConstants.STR_IK.equalsIgnoreCase(jobEmpColl.getEmpl_type())) {
							job = new Job();
							job.setChangein60daysInd(ApplicationUtil.translateBoolean(jobEmpColl.getLast_60_days_ind()));//NOSONAR
							job.setChangeInLastYearInd(false);
							job.setCountyHelpedInd(ApplicationUtil.translateBoolean(jobEmpColl.getCounty_help_job_ind()));//NOSONAR
							job.setEmployerAddress(getAddress(jobEmpColl));
							job.setEmployerName(jobEmpColl.getEr_name());
							if(jobEmpColl.getEr_phone_num() != null) {
								PhoneNumber phNum = new PhoneNumber();
								phNum.setNumber(jobEmpColl.getEr_phone_num());
								phNum.setType(ApplicationSubmissionConstants.STR_WK);
								job.setEmployerPhone(phNum);
							}
							job.setEndDate(jobEmpColl.getEmpl_end_dt());
							job.setExplainJobChange(jobEmpColl.getJob_termination_reason());					
							job.setHoursPerMonth(getNoOfMonths(jobEmpColl.getNum_of_hours()));
							job.setJobTitle(jobEmpColl.getEmpl_addtl_info());
							job.setLastPayDate(jobEmpColl.getLast_payck_dt());				
							job.setHireDate(jobEmpColl.getEmpl_begin_dt());
							job.setEndDate(jobEmpColl.getEmpl_end_dt());
							jobArrList.add(job);
						}
					}
				}
			}

			List<APP_IN_SELFE_Collection> jobSelfList = source.getFinancialIncomeSummaryDetails().getPageCollection().getaPP_IN_SELFE_Collection();

			if(jobSelfList != null && !jobSelfList.isEmpty()) {
				List<APP_IN_SELFE_Collection> indvJobSelEmpList = jobSelfList.stream().filter(liqAset->indvSeq == liqAset.getIndv_seq_num()).collect(Collectors.toList());

				if(indvJobSelEmpList != null && !indvJobSelEmpList.isEmpty()) {
					for(APP_IN_SELFE_Collection jobSelfEmpColl : indvJobSelEmpList) {
						job = new Job();
						job.setTypeCode(ApplicationSubmissionConstants.STR_SE);
						job.setSelfEmpBusName(jobSelfEmpColl.getSelf_empl_bus_nam());
						job.setSelfEmpBusStartDate(jobSelfEmpColl.getSelf_empl_beg_mo());
						job.setSelfEmpBusType(jobSelfEmpColl.getSelf_empl_typ());
						job.setSelfEmpGrossMnthlyAmt(jobSelfEmpColl.getAvg_incm_amt());
						job.setSelfEmployedInd(true);
						jobArrList.add(job);
					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildJobsDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while buildJobDetails::" + e.getMessage());
		}
		return jobArrList;
	}
	
	public static Address getAddress(APP_IN_EMPL_Collection jobEmpColl) {
		Address address = null;
		if(jobEmpColl.getEr_l1_address() != null || jobEmpColl.getEr_city_address() != null 
				|| jobEmpColl.getEr_zip_address() != null || jobEmpColl.getEr_st_address() != null) {
			address = new Address();
			address.setAddrType(ApplicationSubmissionConstants.STR_PH);
			address.setStreetAddr1(jobEmpColl.getEr_l1_address());
			address.setStreetAddr2(jobEmpColl.getEr_l2_address());
			address.setCityName(jobEmpColl.getEr_city_address());
			address.setZipCode(jobEmpColl.getEr_zip_address());
			address.setState(jobEmpColl.getEr_st_address());	
		}
		return address;
	}
	
	public static int getNoOfMonths(String hrsPerWeek) {
		int hrsPerMnth = 0;
		if(hrsPerWeek != null && StringUtils.isNumeric(hrsPerWeek)) {
			int tmpWkhrs = Integer.parseInt(hrsPerWeek);
			hrsPerMnth = Math.toIntExact(Math.round(tmpWkhrs*4.345));
		}
		return hrsPerMnth;
	}
}
