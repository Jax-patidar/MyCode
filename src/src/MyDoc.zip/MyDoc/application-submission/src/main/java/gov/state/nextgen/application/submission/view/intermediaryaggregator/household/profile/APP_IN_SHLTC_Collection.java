package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class APP_IN_SHLTC_Collection {
	
	private String shlt_typ;
	private String shelt_name;
	private String chg_eff_dt;
	private String release_dt;
	private int indv_seq_num;
	
	public String getShlt_typ() {
		return shlt_typ;
	}
	public void setShlt_typ(String shlt_typ) {
		this.shlt_typ = shlt_typ;
	}
	public String getShelt_name() {
		return shelt_name;
	}
	public void setShelt_name(String shelt_name) {
		this.shelt_name = shelt_name;
	}
	public String getChg_eff_dt() {
		return chg_eff_dt;
	}
	public void setChg_eff_dt(String chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}
	public String getRelease_dt() {
		return release_dt;
	}
	public void setRelease_dt(String release_dt) {
		this.release_dt = release_dt;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

}
