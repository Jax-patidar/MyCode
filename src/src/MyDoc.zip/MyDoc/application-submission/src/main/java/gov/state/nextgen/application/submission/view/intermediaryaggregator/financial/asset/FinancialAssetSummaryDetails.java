package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset;

public class FinancialAssetSummaryDetails {   
    private String validationMessages;
    private String pageCollectionResp;
    private String appNum;
    private PageCollection pageCollection;
    private String beforeCollection;
	public String getValidationMessages() {
		return validationMessages;
	}
	public void setValidationMessages(String validationMessages) {
		this.validationMessages = validationMessages;
	}
	public String getPageCollectionResp() {
		return pageCollectionResp;
	}
	public void setPageCollectionResp(String pageCollectionResp) {
		this.pageCollectionResp = pageCollectionResp;
	}
	public String getAppNum() {
		return appNum;
	}
	public void setAppNum(String appNum) {
		this.appNum = appNum;
	}
	public PageCollection getPageCollection() {
		if(pageCollection==null) {
			pageCollection = new PageCollection();
		}
		return pageCollection;
	}
	public void setPageCollection(PageCollection pageCollection) {
		this.pageCollection = pageCollection;
	}
	public String getBeforeCollection() {
		return beforeCollection;
	}
	public void setBeforeCollection(String beforeCollection) {
		this.beforeCollection = beforeCollection;
	}
    

}
