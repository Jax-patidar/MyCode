package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class APP_ABS_PRNT_Collection {
	
	private String user;
    private String cargoName;
    private String rowAction;
    private String adaptRecordId;
    private String ap_mid_init;
    private String ap_absn_dt;
    private String ap_absn_rsn_cd;
    private String rec_cplt_ind;
    private String absent_parent_deceased_ind;
    private String suffix_name;
    private String chld_sup_payee_nam;
    private int indv_seq_num;
    private String parentOneFirstName;
    private String parentOneLastName;
    private String parentTwoFirstName;
    private String parentTwoLastName;
    private String app_num;
    private String ap_seq_num;
    private String AP_FST_NAM;
    private String AP_LAST_NAM;
    private String ap_sex_ind;
    private String case_gdcs_clm_sw;
    private String src_app_ind;
    private String court_order_pay_chld_sup_ind;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getAp_mid_init() {
		return ap_mid_init;
	}
	public void setAp_mid_init(String ap_mid_init) {
		this.ap_mid_init = ap_mid_init;
	}
	public String getAp_absn_dt() {
		return ap_absn_dt;
	}
	public void setAp_absn_dt(String ap_absn_dt) {
		this.ap_absn_dt = ap_absn_dt;
	}
	public String getAp_absn_rsn_cd() {
		return ap_absn_rsn_cd;
	}
	public void setAp_absn_rsn_cd(String ap_absn_rsn_cd) {
		this.ap_absn_rsn_cd = ap_absn_rsn_cd;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getAbsent_parent_deceased_ind() {
		return absent_parent_deceased_ind;
	}
	public void setAbsent_parent_deceased_ind(String absent_parent_deceased_ind) {
		this.absent_parent_deceased_ind = absent_parent_deceased_ind;
	}
	public String getSuffix_name() {
		return suffix_name;
	}
	public void setSuffix_name(String suffix_name) {
		this.suffix_name = suffix_name;
	}
	public String getChld_sup_payee_nam() {
		return chld_sup_payee_nam;
	}
	public void setChld_sup_payee_nam(String chld_sup_payee_nam) {
		this.chld_sup_payee_nam = chld_sup_payee_nam;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getParentOneFirstName() {
		return parentOneFirstName;
	}
	public void setParentOneFirstName(String parentOneFirstName) {
		this.parentOneFirstName = parentOneFirstName;
	}
	public String getParentOneLastName() {
		return parentOneLastName;
	}
	public void setParentOneLastName(String parentOneLastName) {
		this.parentOneLastName = parentOneLastName;
	}
	public String getParentTwoFirstName() {
		return parentTwoFirstName;
	}
	public void setParentTwoFirstName(String parentTwoFirstName) {
		this.parentTwoFirstName = parentTwoFirstName;
	}
	public String getParentTwoLastName() {
		return parentTwoLastName;
	}
	public void setParentTwoLastName(String parentTwoLastName) {
		this.parentTwoLastName = parentTwoLastName;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getAp_seq_num() {
		return ap_seq_num;
	}
	public void setAp_seq_num(String ap_seq_num) {
		this.ap_seq_num = ap_seq_num;
	}
	public String getAP_FST_NAM() {
		return AP_FST_NAM;
	}
	public void setAP_FST_NAM(String aP_FST_NAM) {
		AP_FST_NAM = aP_FST_NAM;
	}
	public String getAP_LAST_NAM() {
		return AP_LAST_NAM;
	}
	public void setAP_LAST_NAM(String aP_LAST_NAM) {
		AP_LAST_NAM = aP_LAST_NAM;
	}
	public String getAp_sex_ind() {
		return ap_sex_ind;
	}
	public void setAp_sex_ind(String ap_sex_ind) {
		this.ap_sex_ind = ap_sex_ind;
	}
	public String getCase_gdcs_clm_sw() {
		return case_gdcs_clm_sw;
	}
	public void setCase_gdcs_clm_sw(String case_gdcs_clm_sw) {
		this.case_gdcs_clm_sw = case_gdcs_clm_sw;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getCourt_order_pay_chld_sup_ind() {
		return court_order_pay_chld_sup_ind;
	}
	public void setCourt_order_pay_chld_sup_ind(String court_order_pay_chld_sup_ind) {
		this.court_order_pay_chld_sup_ind = court_order_pay_chld_sup_ind;
	}
	@Override
	public String toString() {
		return "APP_ABS_PRNT_Collection [user=" + user + ", cargoName=" + cargoName + ", rowAction=" + rowAction
				+ ", adaptRecordId=" + adaptRecordId + ", ap_mid_init=" + ap_mid_init + ", ap_absn_dt=" + ap_absn_dt
				+ ", ap_absn_rsn_cd=" + ap_absn_rsn_cd + ", rec_cplt_ind=" + rec_cplt_ind
				+ ", absent_parent_deceased_ind=" + absent_parent_deceased_ind + ", suffix_name=" + suffix_name
				+ ", chld_sup_payee_nam=" + chld_sup_payee_nam + ", indv_seq_num=" + indv_seq_num
				+ ", parentOneFirstName=" + parentOneFirstName + ", parentOneLastName=" + parentOneLastName
				+ ", parentTwoFirstName=" + parentTwoFirstName + ", parentTwoLastName=" + parentTwoLastName
				+ ", app_num=" + app_num + ", ap_seq_num=" + ap_seq_num + ", AP_FST_NAM=" + AP_FST_NAM
				+ ", AP_LAST_NAM=" + AP_LAST_NAM + ", ap_sex_ind=" + ap_sex_ind + ", case_gdcs_clm_sw="
				+ case_gdcs_clm_sw + ", src_app_ind=" + src_app_ind + ", court_order_pay_chld_sup_ind="
				+ court_order_pay_chld_sup_ind + "]";
	}   
    
    
    
}
