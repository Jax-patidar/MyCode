package gov.state.nextgen.application.submission.service.impl;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.ExceptionsUtil;
import gov.state.nextgen.application.submission.framework.exception.ExceptionLogManager;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.service.DisasterAppFISService;
import gov.state.nextgen.application.submission.service.LambdaInvokerServiceImpl;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.request.PayLoadRequest;
import gov.state.nextgen.application.submission.view.response.DisasterAppFISRespDetails;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import static gov.state.nextgen.application.submission.framework.constants.ExceptionConstants.KEY_IDENTIFIER_ONE;

import java.util.concurrent.CompletableFuture;

@Service
public class DisasterAppFISServiceImpl implements DisasterAppFISService {

    @Autowired
    private LambdaInvokerServiceImpl service;

    @Autowired
    @Qualifier("appSubmissionThreadPoolTaskExecutor")
    private ThreadPoolTaskExecutor threadPoolTaskExecutor;

    @Autowired
    private ExceptionLogManager exceptionLogManager;

    @Async("appSubmissionThreadPoolTaskExecutor")
    public CompletableFuture<AggregatedPayload> fetchDisasterCalFISData(AggregatedPayload payload) {
    	MDC.put(KEY_IDENTIFIER_ONE,  payload.getAppNumber());
        FwLogger.log(this.getClass(),
                FwLogger.Level.INFO,
                "fetching Disaster Cal Financial Summary Details data for case::" + payload.getAppNumber());
        
        String responseBody = null;
        PayLoadRequest payLoadRequest = new PayLoadRequest(payload.getAppNumber(), ApplicationSubmissionConstants.DCFIS, ApplicationSubmissionConstants.DCFIS_LOAD);

        HttpEntity<Object> httpEntity = new HttpEntity<>(payLoadRequest);

        try {

            String url = System.getenv(ApplicationSubmissionConstants.DISASTER_CALS_FIS_DETAILS_URL);
            String path = ApplicationUtil.createURIPath(ApplicationSubmissionConstants.FIS_PATH, ApplicationSubmissionConstants.DCFIS, ApplicationSubmissionConstants.DCFIS_LOAD);
            responseBody = service.invokeLambda(url, httpEntity, path);

            ObjectMapper objMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

            DisasterAppFISRespDetails disasterAppFISRespDetails = objMapper.readValue(responseBody, DisasterAppFISRespDetails.class);

            payload.setDisasterAppFISRespDetails(disasterAppFISRespDetails);
			/*disasterAppFISRespDetails = restTemplate.postForObject(System.getenv(ApplicationSubmissionConstants.DISASTER_CALS_FIS_DETAILS_URL), httpEntity, DisasterAppFISRespDetails.class);
			payload.setDisasterAppFISRespDetails(disasterAppFISRespDetails);*/

            FwLogger.log(this.getClass(),
                    FwLogger.Level.INFO,
                    "successfully fetched Disaster Cal Financial Asset Summary Details data for case::" + payload.getAppNumber());

        } catch (Throwable e) {//NOSONAR
            payload.setErrorWhileAccessingInternalServices(true);
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Error while fetching data from Disaster Cal Financial Asset Summary Details data for case::" + payload.getAppNumber());
            FwLogger.log(this.getClass(),
                    FwLogger.Level.ERROR,
                    "Exception occurred due to::" + e.getMessage());
            exceptionLogManager.sendMessage(ExceptionsUtil.getExceptionCargo(this.getClass(), e, "fetchDisasterCalFISData", payload.getAppNumber()));
        }
        return CompletableFuture.completedFuture(payload);
    }


}
