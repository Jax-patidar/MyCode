package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.CP_APP_IN_ASET_XFER_Collection;
import gov.state.nextgen.application.submission.view.payload.SoldAsset;

public class BuildSoldAssetInfoDetailsHelper {
	
	private BuildSoldAssetInfoDetailsHelper() {}

	public static List<SoldAsset> buildTransferRecords(List<CP_APP_IN_ASET_XFER_Collection> xferColl, int indvSeqNum){
		
		List<SoldAsset> transferRecords = new ArrayList<>();
		
		if(xferColl != null && !xferColl.isEmpty()) {
			
			for(CP_APP_IN_ASET_XFER_Collection xfer: xferColl) {

				if(xfer.getIndv_seq_num() == indvSeqNum) {
					SoldAsset soldAsset = new SoldAsset();
					soldAsset.setAssetVal(xfer.getAsset_val_amt());
					soldAsset.setSellDate(xfer.getAsset_xfer_dt());
					soldAsset.setTradeOrGiveExplainText(xfer.getAsset_xfer_rsn_cd());
					soldAsset.setSellVal(xfer.getAsset_xfer_amt());
					soldAsset.setItemDescr(xfer.getComments());
					transferRecords.add(soldAsset);
				}
			}		
		}
		return transferRecords;		
	}
}
