package gov.state.nextgen.application.submission.service;

import org.springframework.http.HttpEntity;

import com.fasterxml.jackson.core.JsonProcessingException;

public interface LambdaInvokerService {

	public String invokeLambda(String url, HttpEntity<Object> httpentity, String path) throws Exception;
}
