package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.APP_IN_EMPL_HEALTH_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.APP_IN_HLTH_INS_BNFTS_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.CP_APP_IN_MED_INS_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial.CP_APP_IN_WORKERS_COMP_Collection;
import gov.state.nextgen.application.submission.view.payload.Address;
import gov.state.nextgen.application.submission.view.payload.Applicant;
import gov.state.nextgen.application.submission.view.payload.HealthCoverage;

public class BuildHealthInsurDetailsHelper {
	
	private BuildHealthInsurDetailsHelper() {}
	
	public static List<HealthCoverage> buildHealthInsurDetails(AggregatedPayload source, int indvSeq) {//NOSONAR
		List<HealthCoverage> hltCoverageArrList = new ArrayList<>();
		HealthCoverage healthCoverage = null;
		List<CP_APP_IN_MED_INS_Collection> medinsurList = null;
		APP_IN_EMPL_HEALTH_Collection empHlthColl = null;
		APP_IN_HLTH_INS_BNFTS_Collection hlthBenColl = null;

		try {
			List<APP_IN_EMPL_HEALTH_Collection> healthCoverageEmpList = source.getNonFinancialInformationDetails().getPageCollection().getAPP_IN_EMPL_HEALTH_Collection();
			List<APP_IN_HLTH_INS_BNFTS_Collection> hlthBenefitsList = source.getNonFinancialInformationDetails().getPageCollection().getAPP_IN_HLTH_INS_BNFTS_Collection();
			List<CP_APP_IN_MED_INS_Collection> medInsurList = source.getNonFinancialInformationDetails().getPageCollection().getCP_APP_IN_MED_INS_Collection();

			if(medInsurList != null && !medInsurList.isEmpty()) {
				medinsurList = medInsurList.stream().filter(indv->indvSeq == indv.getIndv_seq_num()).collect(Collectors.toList());	
				for(CP_APP_IN_MED_INS_Collection insurBenColl : medinsurList) {
					if(insurBenColl != null) {
						healthCoverage = new HealthCoverage();
						healthCoverage.setTypeCode(BuildIncomeTypeMappingHelper.getMedCovType(insurBenColl.getHealth_ins_type()));
						healthCoverage.setCobraInd(ApplicationUtil.translateBoolean(insurBenColl.getIns_cobra_ind()));//NOSONAR
						healthCoverage.setProviderName(insurBenColl.getHealth_insurance_name());
						healthCoverage.setRetireeHealthPlanInd(ApplicationUtil.translateBoolean(insurBenColl.getIns_retiree_plan_ind()));//NOSONAR
						healthCoverage.setPolicyHolderNumber(insurBenColl.getPolicy_num());
						healthCoverage.setLimitedBenefitPlanInd(ApplicationUtil.translateBoolean(insurBenColl.getIns_limited_benefit_plan_ind()));//NOSONAR
						healthCoverage.setStateEmpBenefitPlanInd(ApplicationUtil.translateBoolean(insurBenColl.getState_emp_benefit_ind()));//NOSONAR
						healthCoverage.setInsuranceEndsin90Ind(ApplicationUtil.translateBoolean(insurBenColl.getHealth_cvrg_exp_to_end_ind()));//NOSONAR
						if(hlthBenefitsList != null && !hlthBenefitsList.isEmpty()) {
							hlthBenColl = hlthBenefitsList.stream().filter(indv->indvSeq==indv.getIndv_seq_num()).findFirst().orElse(null);

							if(hlthBenColl != null) { 
								healthCoverage.setPolicyHolderFirstName(hlthBenColl.getPlcy_hold_fst_nam());
								healthCoverage.setPolicyHolderLastName(hlthBenColl.getPlcy_hold_last_nam());
								healthCoverage.setPolicyHolderNumber(hlthBenColl.getCov_ca_case_num());
							}
						}
						hltCoverageArrList.add(healthCoverage);
					}
				}
			}

			if(healthCoverageEmpList != null && !healthCoverageEmpList.isEmpty()) {
				empHlthColl = healthCoverageEmpList.stream().filter(empHlth->indvSeq == empHlth.getIndv_seq_num()).findFirst().orElse(null);
				if(empHlthColl != null) {
					healthCoverage = new HealthCoverage();
					healthCoverage.setEmployerInd(true);
					healthCoverage.setAddress(getAddress(empHlthColl)); 
					healthCoverage.setBeginDate(empHlthColl.getCvrg_start_dt());
					healthCoverage.setCobraInd(ApplicationUtil.translateBoolean(empHlthColl.getCobra_cvrg()));//NOSONAR
					healthCoverage.setCompanyCode(empHlthColl.getHlth_ins_comp_nam());
					healthCoverage.setEmployeeContactName(empHlthColl.getEmpl_cntct_name());
					healthCoverage.setEmployerEmailAddress(empHlthColl.getEmpl_cntct_email());
					healthCoverage.setEmployerIdentificationNumber(null);
					healthCoverage.setEmployerName(empHlthColl.getEmpl_cntct_name());
					healthCoverage.setEmpPlanChangeDate(empHlthColl.getDate_change());
					healthCoverage.setEmpWellnessPgmInd(ApplicationUtil.translateBoolean(empHlthColl.getWellness_plan_ind()));//NOSONAR
					healthCoverage.setEndDate(empHlthColl.getEmpl_cvrg_end());
					healthCoverage.setInsurCoverageEndReason(empHlthColl.getLost_health_ins_rsn_desc());
					healthCoverage.setEnrollmentDate(empHlthColl.getCvrg_start_dt());
					healthCoverage.setInsurCompanyName(empHlthColl.getHlth_ins_comp_nam());
					healthCoverage.setMinimumStandardValue(ApplicationUtil.translateBoolean(empHlthColl.getMin_value_std()));//NOSONAR
					if(hlthBenefitsList != null && !hlthBenefitsList.isEmpty()) {
						hlthBenColl = hlthBenefitsList.stream().filter(indv->indvSeq==indv.getIndv_seq_num()).findFirst().orElse(null);

						if(hlthBenColl != null) { 
							healthCoverage.setPolicyHolderFirstName(hlthBenColl.getPlcy_hold_fst_nam());
							healthCoverage.setPolicyHolderLastName(hlthBenColl.getPlcy_hold_last_nam());
							healthCoverage.setPolicyHolderNumber(hlthBenColl.getCov_ca_case_num());
						}
					}
					hltCoverageArrList.add(healthCoverage);
				}
			}

			
		} catch (Exception e) {
			FwLogger.log(BuildHealthInsurDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while loading Health Insurance Details - " + e.getMessage());
		}
		return hltCoverageArrList;
	}

	public static Address getAddress(APP_IN_EMPL_HEALTH_Collection hlthCvrgEmpColl) {
		Address address = null;
		if(hlthCvrgEmpColl != null && (hlthCvrgEmpColl.getEmpl_addrline1() != null || hlthCvrgEmpColl.getEmpl_city() != null
				|| hlthCvrgEmpColl.getEmpl_zip() != null || hlthCvrgEmpColl.getEmpl_state() != null)) {	
			address = new Address();
			address.setAddrType(ApplicationSubmissionConstants.STR_PH);
			address.setStreetAddr1(hlthCvrgEmpColl.getEmpl_addrline1());
			address.setCityName(hlthCvrgEmpColl.getEmpl_city());
			address.setZipCode(hlthCvrgEmpColl.getEmpl_zip());
			address.setState(hlthCvrgEmpColl.getEmpl_state());
		}
		return address;
	}
	
	public static void setThirdPartyInd(AggregatedPayload source, int indvSeqNum, Applicant thirdParIndv) {

		List<CP_APP_IN_WORKERS_COMP_Collection> parIndvList =  null;
		CP_APP_IN_WORKERS_COMP_Collection  thirdParty =  null;
		try {
			parIndvList = source.getNonFinancialInformationDetails().getPageCollection().getCP_APP_IN_WORKERS_COMP_Collection();
			if(parIndvList != null && !parIndvList.isEmpty()) {
				thirdParty = parIndvList.stream().filter(indv->indvSeqNum == indv.getIndv_seq_num()).findFirst().orElse(null);	

				if(thirdParty != null) {
					thirdParIndv.setThirdPartyLiabilityInd(true);
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildHealthInsurDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while loading Third Party Liability Details - " + e.getMessage());
		}
	}

}
