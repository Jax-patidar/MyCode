package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class CP_APP_INDV_ADDI_INFO_Collection {
	    private String user;
	    private String cargoName;
	    private boolean dirty;
	    private String rowAction;
	    private String adaptRecordId;
	    private String app_num;
	    private String indv_seq_num;
	    private String gross_income_less;
	    private String combined_gross_income;
	    private String mig_farm_wrkr_resp;
	    private String src_app_ind;
	    private String delete_reason_cd;
	    public String getUser() {
			return user;
		}
		public void setUser(String user) {
			this.user = user;
		}
		public String getCargoName() {
			return cargoName;
		}
		public void setCargoName(String cargoName) {
			this.cargoName = cargoName;
		}
		public boolean isDirty() {
			return dirty;
		}
		public void setDirty(boolean dirty) {
			this.dirty = dirty;
		}
		public String getRowAction() {
			return rowAction;
		}
		public void setRowAction(String rowAction) {
			this.rowAction = rowAction;
		}
		public String getAdaptRecordId() {
			return adaptRecordId;
		}
		public void setAdaptRecordId(String adaptRecordId) {
			this.adaptRecordId = adaptRecordId;
		}
		public String getApp_num() {
			return app_num;
		}
		public void setApp_num(String app_num) {
			this.app_num = app_num;
		}
		public String getIndv_seq_num() {
			return indv_seq_num;
		}
		public void setIndv_seq_num(String indv_seq_num) {
			this.indv_seq_num = indv_seq_num;
		}
		public String getGross_income_less() {
			return gross_income_less;
		}
		public void setGross_income_less(String gross_income_less) {
			this.gross_income_less = gross_income_less;
		}
		public String getCombined_gross_income() {
			return combined_gross_income;
		}
		public void setCombined_gross_income(String combined_gross_income) {
			this.combined_gross_income = combined_gross_income;
		}
		public String getMig_farm_wrkr_resp() {
			return mig_farm_wrkr_resp;
		}
		public void setMig_farm_wrkr_resp(String mig_farm_wrkr_resp) {
			this.mig_farm_wrkr_resp = mig_farm_wrkr_resp;
		}
		public String getSrc_app_ind() {
			return src_app_ind;
		}
		public void setSrc_app_ind(String src_app_ind) {
			this.src_app_ind = src_app_ind;
		}
		public String getDelete_reason_cd() {
			return delete_reason_cd;
		}
		public void setDelete_reason_cd(String delete_reason_cd) {
			this.delete_reason_cd = delete_reason_cd;
		}
		

}
