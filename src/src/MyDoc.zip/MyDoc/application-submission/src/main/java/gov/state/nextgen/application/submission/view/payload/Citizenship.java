package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class Citizenship {
	
    private Boolean usCitzOrNationalInd;
    private Boolean naturalizedCitzInd;
    private Boolean inUSSince1996Ind;
    private Boolean tenYearWorkHistoryInd;
    private Boolean applyForVisaInd;
    private Boolean immigrationChangedin12Ind;
    private String whatChanged;
    private String dateOfChange;
    private String typeCode;
    private String identityDocCode;
    private String alienNumber;
    private String documentNumber;
    @JsonIgnore
    private String ctznReceiveDate;
    @JsonIgnore
    private String idenReceiveDate;
    @JsonIgnore
    private String naturalizationNumber;
    @JsonIgnore
    private String citznCertificateNumber;
    private Boolean citznEligibleImmigrationInd;
    private String entryDate;
    @JsonIgnore
    private String firstNamePerDocument;
    @JsonIgnore
    private String lastNamePerDocument;
    @JsonIgnore
    private String middleNamePerDocument;
    @JsonIgnore
    private String nameSuffixPerDocument;
	public Boolean isUsCitzOrNationalInd() {
		return usCitzOrNationalInd;
	}
	public void setUsCitzOrNationalInd(Boolean usCitzOrNationalInd) {
		this.usCitzOrNationalInd = usCitzOrNationalInd;
	}
	public Boolean isNaturalizedCitzInd() {
		return naturalizedCitzInd;
	}
	public void setNaturalizedCitzInd(Boolean naturalizedCitzInd) {
		this.naturalizedCitzInd = naturalizedCitzInd;
	}
	public Boolean isInUSSince1996Ind() {
		return inUSSince1996Ind;
	}
	public void setInUSSince1996Ind(Boolean inUSSince1996Ind) {
		this.inUSSince1996Ind = inUSSince1996Ind;
	}
	public Boolean isTenYearWorkHistoryInd() {
		return tenYearWorkHistoryInd;
	}
	public void setTenYearWorkHistoryInd(Boolean tenYearWorkHistoryInd) {
		this.tenYearWorkHistoryInd = tenYearWorkHistoryInd;
	}
	public Boolean isApplyForVisaInd() {
		return applyForVisaInd;
	}
	public void setApplyForVisaInd(Boolean applyForVisaInd) {
		this.applyForVisaInd = applyForVisaInd;
	}
	public Boolean isImmigrationChangedin12Ind() {
		return immigrationChangedin12Ind;
	}
	public void setImmigrationChangedin12Ind(Boolean immigrationChangedin12Ind) {
		this.immigrationChangedin12Ind = immigrationChangedin12Ind;
	}
	public String getWhatChanged() {
		return whatChanged;
	}
	public void setWhatChanged(String whatChanged) {
		this.whatChanged = whatChanged;
	}
	public String getDateOfChange() {
		return dateOfChange;
	}
	public void setDateOfChange(String dateOfChange) {
		this.dateOfChange = dateOfChange;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getIdentityDocCode() {
		return identityDocCode;
	}
	public void setIdentityDocCode(String identityDocCode) {
		this.identityDocCode = identityDocCode;
	}
	public String getAlienNumber() {
		return alienNumber;
	}
	public void setAlienNumber(String alienNumber) {
		this.alienNumber = alienNumber;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getCtznReceiveDate() {
		return ctznReceiveDate;
	}
	public void setCtznReceiveDate(String ctznReceiveDate) {
		this.ctznReceiveDate = ctznReceiveDate;
	}
	public String getIdenReceiveDate() {
		return idenReceiveDate;
	}
	public void setIdenReceiveDate(String idenReceiveDate) {
		this.idenReceiveDate = idenReceiveDate;
	}
	public String getNaturalizationNumber() {
		return naturalizationNumber;
	}
	public void setNaturalizationNumber(String naturalizationNumber) {
		this.naturalizationNumber = naturalizationNumber;
	}
	public String getCitznCertificateNumber() {
		return citznCertificateNumber;
	}
	public void setCitznCertificateNumber(String citznCertificateNumber) {
		this.citznCertificateNumber = citznCertificateNumber;
	}
	public Boolean isCitznEligibleImmigrationInd() {
		return citznEligibleImmigrationInd;
	}
	public void setCitznEligibleImmigrationInd(Boolean citznEligibleImmigrationInd) {
		this.citznEligibleImmigrationInd = citznEligibleImmigrationInd;
	}
	public String getEntryDate() {
		return entryDate;
	}
	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}
	public String getFirstNamePerDocument() {
		return firstNamePerDocument;
	}
	public void setFirstNamePerDocument(String firstNamePerDocument) {
		this.firstNamePerDocument = firstNamePerDocument;
	}
	public String getLastNamePerDocument() {
		return lastNamePerDocument;
	}
	public void setLastNamePerDocument(String lastNamePerDocument) {
		this.lastNamePerDocument = lastNamePerDocument;
	}
	public String getMiddleNamePerDocument() {
		return middleNamePerDocument;
	}
	public void setMiddleNamePerDocument(String middleNamePerDocument) {
		this.middleNamePerDocument = middleNamePerDocument;
	}
	public String getNameSuffixPerDocument() {
		return nameSuffixPerDocument;
	}
	public void setNameSuffixPerDocument(String nameSuffixPerDocument) {
		this.nameSuffixPerDocument = nameSuffixPerDocument;
	}

}
