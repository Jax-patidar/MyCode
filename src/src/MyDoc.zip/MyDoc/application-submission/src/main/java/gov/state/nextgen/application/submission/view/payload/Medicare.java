package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class Medicare {

	@JsonIgnore
	private String claimNumber;
	@JsonIgnore
	private String payAType;
	@JsonIgnore
	private String payBType;

	public String getClaimNumber() {
		return claimNumber;
	}

	public void setClaimNumber(String claimNumber) {
		this.claimNumber = claimNumber;
	}

	public String getPayAType() {
		return payAType;
	}

	public void setPayAType(String payAType) {
		this.payAType = payAType;
	}

	public String getPayBType() {
		return payBType;
	}

	public void setPayBType(String payBType) {
		this.payBType = payBType;
	}
}
