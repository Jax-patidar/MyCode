package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset;

public class APP_IN_R_PROP_ASET_Collection {
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private String ecp_id;
	private int indv_seq_num;
	private int seq_num;
	private String individual_live_ind;
	private String indv_plan_live_ind;
	private String num_acres;
	private String prop_fmv_amt;
	private String prop_owe_amt;
	private String jnt_own_resp;
	private String property_currently_rented_ind;
	private String property_producing_income_ind;
	private String property_rented_for_sale_ind;
	private String property_change_ownership_ind;
	private String asset_acquired_dt;
	private String rec_cplt_ind;
	private String src_app_ind;
	private String intn_ret_sw;
	private String prop_adr_ind;
	private String prop_city_adr;
	private String prop_fmv_amt_ind;
	private String prop_l1_adr;
	private String prop_l2_adr;
	private String prop_owe_amt_ind;
	private String prop_sta_adr;
	private String prop_zip_adr;
	private String real_prop_aset_typ;
	private String res_sw;
	private String rlt_cd;
	private String sale_agr_sw;
	private String sps_live_sw;
	private String asset_end_dt;
	private String loopingQuestion;
	private String propAddrZip4;
	private String chg_dt;
	private String how_often_rent_paid;
	private String rent_amt;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public int getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}
	public String getIndividual_live_ind() {
		return individual_live_ind;
	}
	public void setIndividual_live_ind(String individual_live_ind) {
		this.individual_live_ind = individual_live_ind;
	}
	public String getIndv_plan_live_ind() {
		return indv_plan_live_ind;
	}
	public void setIndv_plan_live_ind(String indv_plan_live_ind) {
		this.indv_plan_live_ind = indv_plan_live_ind;
	}
	public String getNum_acres() {
		return num_acres;
	}
	public void setNum_acres(String num_acres) {
		this.num_acres = num_acres;
	}
	public String getProp_fmv_amt() {
		return prop_fmv_amt;
	}
	public void setProp_fmv_amt(String prop_fmv_amt) {
		this.prop_fmv_amt = prop_fmv_amt;
	}
	public String getProp_owe_amt() {
		return prop_owe_amt;
	}
	public void setProp_owe_amt(String prop_owe_amt) {
		this.prop_owe_amt = prop_owe_amt;
	}
	public String getJnt_own_resp() {
		return jnt_own_resp;
	}
	public void setJnt_own_resp(String jnt_own_resp) {
		this.jnt_own_resp = jnt_own_resp;
	}
	public String getProperty_currently_rented_ind() {
		return property_currently_rented_ind;
	}
	public void setProperty_currently_rented_ind(String property_currently_rented_ind) {
		this.property_currently_rented_ind = property_currently_rented_ind;
	}
	public String getProperty_producing_income_ind() {
		return property_producing_income_ind;
	}
	public void setProperty_producing_income_ind(String property_producing_income_ind) {
		this.property_producing_income_ind = property_producing_income_ind;
	}
	public String getProperty_rented_for_sale_ind() {
		return property_rented_for_sale_ind;
	}
	public void setProperty_rented_for_sale_ind(String property_rented_for_sale_ind) {
		this.property_rented_for_sale_ind = property_rented_for_sale_ind;
	}
	public String getProperty_change_ownership_ind() {
		return property_change_ownership_ind;
	}
	public void setProperty_change_ownership_ind(String property_change_ownership_ind) {
		this.property_change_ownership_ind = property_change_ownership_ind;
	}
	public String getAsset_acquired_dt() {
		return asset_acquired_dt;
	}
	public void setAsset_acquired_dt(String asset_acquired_dt) {
		this.asset_acquired_dt = asset_acquired_dt;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getIntn_ret_sw() {
		return intn_ret_sw;
	}
	public void setIntn_ret_sw(String intn_ret_sw) {
		this.intn_ret_sw = intn_ret_sw;
	}
	public String getProp_adr_ind() {
		return prop_adr_ind;
	}
	public void setProp_adr_ind(String prop_adr_ind) {
		this.prop_adr_ind = prop_adr_ind;
	}
	public String getProp_city_adr() {
		return prop_city_adr;
	}
	public void setProp_city_adr(String prop_city_adr) {
		this.prop_city_adr = prop_city_adr;
	}
	public String getProp_fmv_amt_ind() {
		return prop_fmv_amt_ind;
	}
	public void setProp_fmv_amt_ind(String prop_fmv_amt_ind) {
		this.prop_fmv_amt_ind = prop_fmv_amt_ind;
	}
	public String getProp_l1_adr() {
		return prop_l1_adr;
	}
	public void setProp_l1_adr(String prop_l1_adr) {
		this.prop_l1_adr = prop_l1_adr;
	}
	public String getProp_l2_adr() {
		return prop_l2_adr;
	}
	public void setProp_l2_adr(String prop_l2_adr) {
		this.prop_l2_adr = prop_l2_adr;
	}
	public String getProp_owe_amt_ind() {
		return prop_owe_amt_ind;
	}
	public void setProp_owe_amt_ind(String prop_owe_amt_ind) {
		this.prop_owe_amt_ind = prop_owe_amt_ind;
	}
	public String getProp_sta_adr() {
		return prop_sta_adr;
	}
	public void setProp_sta_adr(String prop_sta_adr) {
		this.prop_sta_adr = prop_sta_adr;
	}
	public String getProp_zip_adr() {
		return prop_zip_adr;
	}
	public void setProp_zip_adr(String prop_zip_adr) {
		this.prop_zip_adr = prop_zip_adr;
	}
	public String getReal_prop_aset_typ() {
		return real_prop_aset_typ;
	}
	public void setReal_prop_aset_typ(String real_prop_aset_typ) {
		this.real_prop_aset_typ = real_prop_aset_typ;
	}
	public String getRes_sw() {
		return res_sw;
	}
	public void setRes_sw(String res_sw) {
		this.res_sw = res_sw;
	}
	public String getRlt_cd() {
		return rlt_cd;
	}
	public void setRlt_cd(String rlt_cd) {
		this.rlt_cd = rlt_cd;
	}
	public String getSale_agr_sw() {
		return sale_agr_sw;
	}
	public void setSale_agr_sw(String sale_agr_sw) {
		this.sale_agr_sw = sale_agr_sw;
	}
	public String getSps_live_sw() {
		return sps_live_sw;
	}
	public void setSps_live_sw(String sps_live_sw) {
		this.sps_live_sw = sps_live_sw;
	}
	public String getAsset_end_dt() {
		return asset_end_dt;
	}
	public void setAsset_end_dt(String asset_end_dt) {
		this.asset_end_dt = asset_end_dt;
	}
	public String getLoopingQuestion() {
		return loopingQuestion;
	}
	public void setLoopingQuestion(String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}
	public String getPropAddrZip4() {
		return propAddrZip4;
	}
	public void setPropAddrZip4(String propAddrZip4) {
		this.propAddrZip4 = propAddrZip4;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getHow_often_rent_paid() {
		return how_often_rent_paid;
	}
	public void setHow_often_rent_paid(String how_often_rent_paid) {
		this.how_often_rent_paid = how_often_rent_paid;
	}
	public String getRent_amt() {
		return rent_amt;
	}
	public void setRent_amt(String rent_amt) {
		this.rent_amt = rent_amt;
	}

}
