package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset.APP_IN_VEH_ASET_Collection;
import gov.state.nextgen.application.submission.view.payload.MotorVehicle;
import gov.state.nextgen.application.submission.view.payload.Vehicle;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class BuildVehicleDetailsHelper {

    private BuildVehicleDetailsHelper() {
    }

    public static List<Vehicle> buildvehicle(AggregatedPayload source, int indvSeq) {//NOSONAR

        Vehicle vehicle = null;
        List<Vehicle> vehicleAsetList = new ArrayList<>();

        try {
            List<APP_IN_VEH_ASET_Collection> vehAsetList = source.getFinancialAssetSummaryDetails().getPageCollection().getAPP_IN_VEH_ASET_Collection();

            if (vehAsetList != null && !vehAsetList.isEmpty()) {
                List<APP_IN_VEH_ASET_Collection> indvVehAsetList = vehAsetList.stream().filter(vehAset -> indvSeq == vehAset.getIndv_seq_num()).collect(Collectors.toList());

                if (indvVehAsetList != null && !indvVehAsetList.isEmpty()) {
                    for (APP_IN_VEH_ASET_Collection vehAset : indvVehAsetList) {
                        vehicle = new Vehicle();
                        vehicle.setAcquired(vehAset.getVehicle_acquired_dt());
                        vehicle.setAvailableDate(vehAset.getChg_eff_dt());
                        vehicle.setAvailableInd(false);
                        vehicle.setBegDate(vehAset.getChg_eff_dt());
                        vehicle.setCategoryCode(ApplicationSubmissionConstants.STR_MV);
                        vehicle.setJointPersFirstName(null);
                        vehicle.setJointPersLastName(null);
                        vehicle.setLiquidProperty(null);
                        vehicle.setMotorVehicle(getMotorVehicle(vehAset));
                        vehicle.setPctOwned(vehAset.getJnt_own_resp());
                        vehicle.setPropertyName("Vehicle");
                        //vehicle.setPurchasePrice(vehAset.getVeh_fmv_amt());
                        vehicle.setRealProperty(null);
                        vehicle.setUseCode(null);
                        try {
							if(vehAset.getVeh_fmv_amt() != null) {
								double vehAmt = Double.parseDouble(vehAset.getVeh_fmv_amt());
								vehicle.setValAmount(vehAmt);
							}							

							if(vehAset.getVeh_owe_amt_ind() != null) {
								double oweAmt = Double.parseDouble(vehAset.getVeh_owe_amt_ind());
								vehicle.setOwedAmount(oweAmt);
							} else if(vehAset.getMv_owe_amt() != null) {
								double oweAmt = Double.parseDouble(vehAset.getMv_owe_amt());
								vehicle.setOwedAmount(oweAmt);
							} else if(vehAset.getVeh_owe_amt() > 0) {
								vehicle.setOwedAmount(vehAset.getVeh_owe_amt());
							} else if(vehAset.getMv_owe_amt_ind() != null ) {
								double oweAmt = Double.parseDouble(vehAset.getMv_owe_amt_ind());
								vehicle.setOwedAmount(oweAmt);
							}
						} catch(Exception e) {
							FwLogger.log(BuildVehicleDetailsHelper.class,
				                    FwLogger.Level.INFO,
				                    "Exception while buildvehicle Owed amount::" + e.getMessage());
						}
                        
                        if (ApplicationSubmissionConstants.STR_TN.equalsIgnoreCase(vehAset.getVeh_aset_typ()))
                            vehicle.setType(ApplicationSubmissionConstants.STR_64);
                        if (ApplicationSubmissionConstants.EXP_CS.equalsIgnoreCase(vehAset.getVeh_aset_typ()))
                            vehicle.setType(ApplicationSubmissionConstants.STR_47);

                        vehicleAsetList.add(vehicle);
                    }
                }
            }
        } catch (Exception e) {
            FwLogger.log(BuildVehicleDetailsHelper.class,
                    FwLogger.Level.INFO,
                    "Exception while buildvehicle::" + e.getMessage());
        }
        return vehicleAsetList;
    }

    public static MotorVehicle getMotorVehicle(APP_IN_VEH_ASET_Collection vehAset) {

        String[] strArr = null;
        MotorVehicle mVehicle = new MotorVehicle();
        mVehicle.setEstimatedValue(vehAset.getVeh_fmv_amt());
        mVehicle.setMake(vehAset.getVeh_make_txt());
        mVehicle.setModel(vehAset.getVeh_modl_txt());
        if (vehAset.getVeh_yr() != null && StringUtils.isNumeric(vehAset.getVeh_yr()))
            mVehicle.setYear(Integer.parseInt(vehAset.getVeh_yr()));
        mVehicle.setLicenseNumber(vehAset.getLic_plate_txt());

        if (vehAset.getHow_it_is_used() != null && !ApplicationSubmissionConstants.STR_EMPT.equalsIgnoreCase(vehAset.getHow_it_is_used())) {
            strArr = vehAset.getHow_it_is_used().split(ApplicationSubmissionConstants.STR_COMMA);
            for (String vehUse : strArr) {
                if (ApplicationSubmissionConstants.VEH_AH.equalsIgnoreCase(vehUse))
                    mVehicle.setUseAsHomeInd(true);
                if (ApplicationSubmissionConstants.VEH_FW.equalsIgnoreCase(vehUse))
                    mVehicle.setUseForWorkInd(true);
            }
        }

        mVehicle.setHowAmountOwedFound(vehAset.getVeh_rgst_rqr_sw());
        mVehicle.setHowEstimated(vehAset.getVeh_find_value());
        mVehicle.setWasGiftOrDonationInd(ApplicationUtil.translateBoolean(vehAset.getVeh_gift_ind()));//NOSONAR
        mVehicle.setHowVehicleObtained(vehAset.getVeh_gift_how());
        mVehicle.setLeaseInd(ApplicationUtil.translateBoolean(vehAset.getLeased_ind()));//NOSONAR

        return mVehicle;
    }
}
