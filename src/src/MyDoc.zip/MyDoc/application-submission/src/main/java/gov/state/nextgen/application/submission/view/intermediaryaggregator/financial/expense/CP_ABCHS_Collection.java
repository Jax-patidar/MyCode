package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense;

public class CP_ABCHS_Collection {
	
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int indv_seq_num;
	private String seq_num;
	private String dpnd_care_exp_amt;
	private String dpnd_care_exp_ind;
	private String prvd_first_name;
	private String prvd_in_seq_num;
	private String prvd_last_name;
	private String prvd_name_org_ind;
	private String prvd_org_nam;
	private String prvd_type;
	private String rec_cplt_ind;
	private String pay_freq;
	private String dependent_care_exp_end_dt;
	private String src_app_ind;
	private String prvd_address_state_cd;
	private String prvd_addr_zip;
	private String dpnd_care_exp_rsn_cd;
	private String dependent_care_exp_start_dt;
	private String dep_care_pay_rsn_cd;
	private String dep_care_pay_amt;
	private String dep_care_pay_start_dt;
	private String prvd_addr_line1;
	private String prvd_addr_line2;
	private String prvd_phone_num;
	private String prvd_addr_city;
	private String addrZip4;
	private String chg_dt;
	private String jnt_amt_paid;
	private String jnt_pay_resp;
	private String jnt_payee_first_name;
	private String jnt_payee_last_name;
	private String first_name;
	private String paid_in_seq_num;
	private String totalAmount;
	private String frequency;
	private String loopingInd;
	private String ecp_id;
	private String jnt_payee_pay_freq;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(String seq_num) {
		this.seq_num = seq_num;
	}
	public String getDpnd_care_exp_amt() {
		return dpnd_care_exp_amt;
	}
	public void setDpnd_care_exp_amt(String dpnd_care_exp_amt) {
		this.dpnd_care_exp_amt = dpnd_care_exp_amt;
	}
	public String getDpnd_care_exp_ind() {
		return dpnd_care_exp_ind;
	}
	public void setDpnd_care_exp_ind(String dpnd_care_exp_ind) {
		this.dpnd_care_exp_ind = dpnd_care_exp_ind;
	}
	public String getPrvd_first_name() {
		return prvd_first_name;
	}
	public void setPrvd_first_name(String prvd_first_name) {
		this.prvd_first_name = prvd_first_name;
	}
	public String getPrvd_in_seq_num() {
		return prvd_in_seq_num;
	}
	public void setPrvd_in_seq_num(String prvd_in_seq_num) {
		this.prvd_in_seq_num = prvd_in_seq_num;
	}
	public String getPrvd_last_name() {
		return prvd_last_name;
	}
	public void setPrvd_last_name(String prvd_last_name) {
		this.prvd_last_name = prvd_last_name;
	}
	public String getPrvd_name_org_ind() {
		return prvd_name_org_ind;
	}
	public void setPrvd_name_org_ind(String prvd_name_org_ind) {
		this.prvd_name_org_ind = prvd_name_org_ind;
	}
	public String getPrvd_org_nam() {
		return prvd_org_nam;
	}
	public void setPrvd_org_nam(String prvd_org_nam) {
		this.prvd_org_nam = prvd_org_nam;
	}
	public String getPrvd_type() {
		return prvd_type;
	}
	public void setPrvd_type(String prvd_type) {
		this.prvd_type = prvd_type;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getPay_freq() {
		return pay_freq;
	}
	public void setPay_freq(String pay_freq) {
		this.pay_freq = pay_freq;
	}
	public String getDependent_care_exp_end_dt() {
		return dependent_care_exp_end_dt;
	}
	public void setDependent_care_exp_end_dt(String dependent_care_exp_end_dt) {
		this.dependent_care_exp_end_dt = dependent_care_exp_end_dt;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getPrvd_address_state_cd() {
		return prvd_address_state_cd;
	}
	public void setPrvd_address_state_cd(String prvd_address_state_cd) {
		this.prvd_address_state_cd = prvd_address_state_cd;
	}
	public String getPrvd_addr_zip() {
		return prvd_addr_zip;
	}
	public void setPrvd_addr_zip(String prvd_addr_zip) {
		this.prvd_addr_zip = prvd_addr_zip;
	}
	public String getDpnd_care_exp_rsn_cd() {
		return dpnd_care_exp_rsn_cd;
	}
	public void setDpnd_care_exp_rsn_cd(String dpnd_care_exp_rsn_cd) {
		this.dpnd_care_exp_rsn_cd = dpnd_care_exp_rsn_cd;
	}
	public String getDependent_care_exp_start_dt() {
		return dependent_care_exp_start_dt;
	}
	public void setDependent_care_exp_start_dt(String dependent_care_exp_start_dt) {
		this.dependent_care_exp_start_dt = dependent_care_exp_start_dt;
	}
	public String getDep_care_pay_rsn_cd() {
		return dep_care_pay_rsn_cd;
	}
	public void setDep_care_pay_rsn_cd(String dep_care_pay_rsn_cd) {
		this.dep_care_pay_rsn_cd = dep_care_pay_rsn_cd;
	}
	public String getDep_care_pay_amt() {
		return dep_care_pay_amt;
	}
	public void setDep_care_pay_amt(String dep_care_pay_amt) {
		this.dep_care_pay_amt = dep_care_pay_amt;
	}
	public String getDep_care_pay_start_dt() {
		return dep_care_pay_start_dt;
	}
	public void setDep_care_pay_start_dt(String dep_care_pay_start_dt) {
		this.dep_care_pay_start_dt = dep_care_pay_start_dt;
	}
	public String getPrvd_addr_line1() {
		return prvd_addr_line1;
	}
	public void setPrvd_addr_line1(String prvd_addr_line1) {
		this.prvd_addr_line1 = prvd_addr_line1;
	}
	public String getPrvd_addr_line2() {
		return prvd_addr_line2;
	}
	public void setPrvd_addr_line2(String prvd_addr_line2) {
		this.prvd_addr_line2 = prvd_addr_line2;
	}
	public String getPrvd_phone_num() {
		return prvd_phone_num;
	}
	public void setPrvd_phone_num(String prvd_phone_num) {
		this.prvd_phone_num = prvd_phone_num;
	}
	public String getPrvd_addr_city() {
		return prvd_addr_city;
	}
	public void setPrvd_addr_city(String prvd_addr_city) {
		this.prvd_addr_city = prvd_addr_city;
	}
	public String getAddrZip4() {
		return addrZip4;
	}
	public void setAddrZip4(String addrZip4) {
		this.addrZip4 = addrZip4;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getJnt_amt_paid() {
		return jnt_amt_paid;
	}
	public void setJnt_amt_paid(String jnt_amt_paid) {
		this.jnt_amt_paid = jnt_amt_paid;
	}
	public String getJnt_pay_resp() {
		return jnt_pay_resp;
	}
	public void setJnt_pay_resp(String jnt_pay_resp) {
		this.jnt_pay_resp = jnt_pay_resp;
	}
	public String getJnt_payee_first_name() {
		return jnt_payee_first_name;
	}
	public void setJnt_payee_first_name(String jnt_payee_first_name) {
		this.jnt_payee_first_name = jnt_payee_first_name;
	}
	public String getJnt_payee_last_name() {
		return jnt_payee_last_name;
	}
	public void setJnt_payee_last_name(String jnt_payee_last_name) {
		this.jnt_payee_last_name = jnt_payee_last_name;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getPaid_in_seq_num() {
		return paid_in_seq_num;
	}
	public void setPaid_in_seq_num(String paid_in_seq_num) {
		this.paid_in_seq_num = paid_in_seq_num;
	}
	public String getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getLoopingInd() {
		return loopingInd;
	}
	public void setLoopingInd(String loopingInd) {
		this.loopingInd = loopingInd;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getJnt_payee_pay_freq() {
		return jnt_payee_pay_freq;
	}
	public void setJnt_payee_pay_freq(String jnt_payee_pay_freq) {
		this.jnt_payee_pay_freq = jnt_payee_pay_freq;
	}
	@Override
	public String toString() {
		return "CP_ABCHS_Collection [user=" + user + ", cargoName=" + cargoName + ", rowAction=" + rowAction
				+ ", adaptRecordId=" + adaptRecordId + ", delete_reason_cd=" + delete_reason_cd + ", app_num=" + app_num
				+ ", indv_seq_num=" + indv_seq_num + ", seq_num=" + seq_num + ", dpnd_care_exp_amt=" + dpnd_care_exp_amt
				+ ", dpnd_care_exp_ind=" + dpnd_care_exp_ind + ", prvd_first_name=" + prvd_first_name
				+ ", prvd_in_seq_num=" + prvd_in_seq_num + ", prvd_last_name=" + prvd_last_name + ", prvd_name_org_ind="
				+ prvd_name_org_ind + ", prvd_org_nam=" + prvd_org_nam + ", prvd_type=" + prvd_type + ", rec_cplt_ind="
				+ rec_cplt_ind + ", pay_freq=" + pay_freq + ", dependent_care_exp_end_dt=" + dependent_care_exp_end_dt
				+ ", src_app_ind=" + src_app_ind + ", prvd_address_state_cd=" + prvd_address_state_cd
				+ ", prvd_addr_zip=" + prvd_addr_zip + ", dpnd_care_exp_rsn_cd=" + dpnd_care_exp_rsn_cd
				+ ", dependent_care_exp_start_dt=" + dependent_care_exp_start_dt + ", dep_care_pay_rsn_cd="
				+ dep_care_pay_rsn_cd + ", dep_care_pay_amt=" + dep_care_pay_amt + ", dep_care_pay_start_dt="
				+ dep_care_pay_start_dt + ", prvd_addr_line1=" + prvd_addr_line1 + ", prvd_addr_line2="
				+ prvd_addr_line2 + ", prvd_phone_num=" + prvd_phone_num + ", prvd_addr_city=" + prvd_addr_city
				+ ", addrZip4=" + addrZip4 + ", chg_dt=" + chg_dt + ", jnt_amt_paid=" + jnt_amt_paid + ", jnt_pay_resp="
				+ jnt_pay_resp + ", jnt_payee_first_name=" + jnt_payee_first_name + ", jnt_payee_last_name="
				+ jnt_payee_last_name + ", first_name=" + first_name + ", paid_in_seq_num=" + paid_in_seq_num
				+ ", totalAmount=" + totalAmount + ", frequency=" + frequency + ", loopingInd=" + loopingInd
				+ ", ecp_id=" + ecp_id + ", jnt_payee_pay_freq=" + jnt_payee_pay_freq + "]";
	}
	
	
	

}
