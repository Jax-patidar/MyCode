package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class APP_SBMS_Collection {
	
	private String user;
    private String cargoName;
    private String rowAction;
    private String adaptRecordId;
    private String delete_reason_cd;
    private String app_num;
    private int indv_seq_num;
    private String bus_hr_exmp_ind;
    private String care_exmp_ind;
    private String cc_exmp_ind;
    private String e_sign_ind;
    private String edb_exmp_ind;
    private String fs_ivw_resp;
    private String fst_nam;
    private String ilns_exmp_ind;
    private String last_nam;
    private String mid_init;
    private String othr_exmp_ind;
    private String sps_esign_ind;
    private String sps_sign_dt;
    private String sps_mid_init;
    private String trnsp_exmp_ind;
    private String ucmft_exmp_ind;
    private String work_exmp_ind;
    private String wthr_exmp_ind;
    private String othr_rsn_txt;
    private String direct_pay_sw;
    private String info_exchange_consent_ind;
    private String electronically_sign_ind;
    private String unable_sign_ind;
    private String voter_registration_sw;
    private String suffix_name;
    private String applicant_first_name;
    private String applicant_last_name;
    private String applicant_mid_name;
    private String sign_dt;
    private String applicant_suffix_name;
    private String application_my_certi;
    private String application_other_certi;
    private String apply_medicaid;
    private String renewal_of_coverage;
    private String expedited_fap_sw;
    private String medicaid_abd_sw;
    private String pregnant_sw;
    private String new_born_sw;
    private String citizenship_sign;
    private String authrep_citizenship_sign;
    private String e_sign_ind1;
    private String sps_esign_ind1;
    private String office_id;
    private String esignArr;
    private String phone_num;
    private String address;
    private String case_num;
    private String form_type;
	private String sps_first_name;
    private String sps_last_name;
    private String org_user_agency_name;
    private String applicant_sign_dt;
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonProperty("sbms_dt")
    private Date sbmsDt;
    
    
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getBus_hr_exmp_ind() {
		return bus_hr_exmp_ind;
	}
	public void setBus_hr_exmp_ind(String bus_hr_exmp_ind) {
		this.bus_hr_exmp_ind = bus_hr_exmp_ind;
	}
	public String getCare_exmp_ind() {
		return care_exmp_ind;
	}
	public void setCare_exmp_ind(String care_exmp_ind) {
		this.care_exmp_ind = care_exmp_ind;
	}
	public String getCc_exmp_ind() {
		return cc_exmp_ind;
	}
	public void setCc_exmp_ind(String cc_exmp_ind) {
		this.cc_exmp_ind = cc_exmp_ind;
	}
	public String getE_sign_ind() {
		return e_sign_ind;
	}
	public void setE_sign_ind(String e_sign_ind) {
		this.e_sign_ind = e_sign_ind;
	}
	public String getEdb_exmp_ind() {
		return edb_exmp_ind;
	}
	public void setEdb_exmp_ind(String edb_exmp_ind) {
		this.edb_exmp_ind = edb_exmp_ind;
	}
	public String getFs_ivw_resp() {
		return fs_ivw_resp;
	}
	public void setFs_ivw_resp(String fs_ivw_resp) {
		this.fs_ivw_resp = fs_ivw_resp;
	}
	public String getFst_nam() {
		return fst_nam;
	}
	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}
	public String getIlns_exmp_ind() {
		return ilns_exmp_ind;
	}
	public void setIlns_exmp_ind(String ilns_exmp_ind) {
		this.ilns_exmp_ind = ilns_exmp_ind;
	}
	public String getLast_nam() {
		return last_nam;
	}
	public void setLast_nam(String last_nam) {
		this.last_nam = last_nam;
	}
	public String getMid_init() {
		return mid_init;
	}
	public void setMid_init(String mid_init) {
		this.mid_init = mid_init;
	}
	public String getOthr_exmp_ind() {
		return othr_exmp_ind;
	}
	public void setOthr_exmp_ind(String othr_exmp_ind) {
		this.othr_exmp_ind = othr_exmp_ind;
	}
	public String getSps_esign_ind() {
		return sps_esign_ind;
	}
	public void setSps_esign_ind(String sps_esign_ind) {
		this.sps_esign_ind = sps_esign_ind;
	}
	public String getSps_sign_dt() {
		return sps_sign_dt;
	}
	public void setSps_sign_dt(String sps_sign_dt) {
		this.sps_sign_dt = sps_sign_dt;
	}
	public String getSps_mid_init() {
		return sps_mid_init;
	}
	public void setSps_mid_init(String sps_mid_init) {
		this.sps_mid_init = sps_mid_init;
	}
	public String getTrnsp_exmp_ind() {
		return trnsp_exmp_ind;
	}
	public void setTrnsp_exmp_ind(String trnsp_exmp_ind) {
		this.trnsp_exmp_ind = trnsp_exmp_ind;
	}
	public String getUcmft_exmp_ind() {
		return ucmft_exmp_ind;
	}
	public void setUcmft_exmp_ind(String ucmft_exmp_ind) {
		this.ucmft_exmp_ind = ucmft_exmp_ind;
	}
	public String getWork_exmp_ind() {
		return work_exmp_ind;
	}
	public void setWork_exmp_ind(String work_exmp_ind) {
		this.work_exmp_ind = work_exmp_ind;
	}
	public String getWthr_exmp_ind() {
		return wthr_exmp_ind;
	}
	public void setWthr_exmp_ind(String wthr_exmp_ind) {
		this.wthr_exmp_ind = wthr_exmp_ind;
	}
	public String getOthr_rsn_txt() {
		return othr_rsn_txt;
	}
	public void setOthr_rsn_txt(String othr_rsn_txt) {
		this.othr_rsn_txt = othr_rsn_txt;
	}
	public String getDirect_pay_sw() {
		return direct_pay_sw;
	}
	public void setDirect_pay_sw(String direct_pay_sw) {
		this.direct_pay_sw = direct_pay_sw;
	}
	public String getInfo_exchange_consent_ind() {
		return info_exchange_consent_ind;
	}
	public void setInfo_exchange_consent_ind(String info_exchange_consent_ind) {
		this.info_exchange_consent_ind = info_exchange_consent_ind;
	}
	public String getElectronically_sign_ind() {
		return electronically_sign_ind;
	}
	public void setElectronically_sign_ind(String electronically_sign_ind) {
		this.electronically_sign_ind = electronically_sign_ind;
	}
	public String getUnable_sign_ind() {
		return unable_sign_ind;
	}
	public void setUnable_sign_ind(String unable_sign_ind) {
		this.unable_sign_ind = unable_sign_ind;
	}
	public String getVoter_registration_sw() {
		return voter_registration_sw;
	}
	public void setVoter_registration_sw(String voter_registration_sw) {
		this.voter_registration_sw = voter_registration_sw;
	}
	public String getSuffix_name() {
		return suffix_name;
	}
	public void setSuffix_name(String suffix_name) {
		this.suffix_name = suffix_name;
	}
	public String getApplicant_first_name() {
		return applicant_first_name;
	}
	public void setApplicant_first_name(String applicant_first_name) {
		this.applicant_first_name = applicant_first_name;
	}
	public String getApplicant_last_name() {
		return applicant_last_name;
	}
	public void setApplicant_last_name(String applicant_last_name) {
		this.applicant_last_name = applicant_last_name;
	}
	public String getApplicant_mid_name() {
		return applicant_mid_name;
	}
	public void setApplicant_mid_name(String applicant_mid_name) {
		this.applicant_mid_name = applicant_mid_name;
	}
	public String getSign_dt() {
		return sign_dt;
	}
	public void setSign_dt(String sign_dt) {
		this.sign_dt = sign_dt;
	}
	public String getApplicant_suffix_name() {
		return applicant_suffix_name;
	}
	public void setApplicant_suffix_name(String applicant_suffix_name) {
		this.applicant_suffix_name = applicant_suffix_name;
	}
	public String getApplication_my_certi() {
		return application_my_certi;
	}
	public void setApplication_my_certi(String application_my_certi) {
		this.application_my_certi = application_my_certi;
	}
	public String getApplication_other_certi() {
		return application_other_certi;
	}
	public void setApplication_other_certi(String application_other_certi) {
		this.application_other_certi = application_other_certi;
	}
	public String getApply_medicaid() {
		return apply_medicaid;
	}
	public void setApply_medicaid(String apply_medicaid) {
		this.apply_medicaid = apply_medicaid;
	}
	public String getRenewal_of_coverage() {
		return renewal_of_coverage;
	}
	public void setRenewal_of_coverage(String renewal_of_coverage) {
		this.renewal_of_coverage = renewal_of_coverage;
	}
	public String getExpedited_fap_sw() {
		return expedited_fap_sw;
	}
	public void setExpedited_fap_sw(String expedited_fap_sw) {
		this.expedited_fap_sw = expedited_fap_sw;
	}
	public String getMedicaid_abd_sw() {
		return medicaid_abd_sw;
	}
	public void setMedicaid_abd_sw(String medicaid_abd_sw) {
		this.medicaid_abd_sw = medicaid_abd_sw;
	}
	public String getPregnant_sw() {
		return pregnant_sw;
	}
	public void setPregnant_sw(String pregnant_sw) {
		this.pregnant_sw = pregnant_sw;
	}
	public String getNew_born_sw() {
		return new_born_sw;
	}
	public void setNew_born_sw(String new_born_sw) {
		this.new_born_sw = new_born_sw;
	}
	public String getCitizenship_sign() {
		return citizenship_sign;
	}
	public void setCitizenship_sign(String citizenship_sign) {
		this.citizenship_sign = citizenship_sign;
	}
	public String getAuthrep_citizenship_sign() {
		return authrep_citizenship_sign;
	}
	public void setAuthrep_citizenship_sign(String authrep_citizenship_sign) {
		this.authrep_citizenship_sign = authrep_citizenship_sign;
	}
	public String getE_sign_ind1() {
		return e_sign_ind1;
	}
	public void setE_sign_ind1(String e_sign_ind1) {
		this.e_sign_ind1 = e_sign_ind1;
	}
	public String getSps_esign_ind1() {
		return sps_esign_ind1;
	}
	public void setSps_esign_ind1(String sps_esign_ind1) {
		this.sps_esign_ind1 = sps_esign_ind1;
	}
	public String getOffice_id() {
		return office_id;
	}
	public void setOffice_id(String office_id) {
		this.office_id = office_id;
	}
	public String getEsignArr() {
		return esignArr;
	}
	public void setEsignArr(String esignArr) {
		this.esignArr = esignArr;
	}
	public String getPhone_num() {
		return phone_num;
	}
	public void setPhone_num(String phone_num) {
		this.phone_num = phone_num;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCase_num() {
		return case_num;
	}
	public void setCase_num(String case_num) {
		this.case_num = case_num;
	}
	public String getForm_type() {
		return form_type;
	}
	public void setForm_type(String form_type) {
		this.form_type = form_type;
	}
	public String getSps_first_name() {
		return sps_first_name;
	}
	public void setSps_first_name(String sps_first_name) {
		this.sps_first_name = sps_first_name;
	}
	public String getSps_last_name() {
		return sps_last_name;
	}
	public void setSps_last_name(String sps_last_name) {
		this.sps_last_name = sps_last_name;
	}
	public String getApplicant_sign_dt() {
		return applicant_sign_dt;
	}
	
	public String getOrg_user_agency_name() {
		return org_user_agency_name;
	}
	public void setOrg_user_agency_name(String org_user_agency_name) {
		this.org_user_agency_name = org_user_agency_name;
	}
	
	public void setApplicant_sign_dt(String applicant_sign_dt) {
		this.applicant_sign_dt = applicant_sign_dt;
	}
	
	
	
	@Override
	public String toString() {
		return "APP_SBMS_Collection [user=" + user + ", cargoName=" + cargoName + ", rowAction=" + rowAction
				+ ", adaptRecordId=" + adaptRecordId + ", delete_reason_cd=" + delete_reason_cd + ", app_num=" + app_num
				+ ", indv_seq_num=" + indv_seq_num + ", bus_hr_exmp_ind=" + bus_hr_exmp_ind + ", care_exmp_ind="
				+ care_exmp_ind + ", cc_exmp_ind=" + cc_exmp_ind + ", e_sign_ind=" + e_sign_ind + ", edb_exmp_ind="
				+ edb_exmp_ind + ", fs_ivw_resp=" + fs_ivw_resp + ", fst_nam=" + fst_nam + ", ilns_exmp_ind="
				+ ilns_exmp_ind + ", last_nam=" + last_nam + ", mid_init=" + mid_init + ", othr_exmp_ind="
				+ othr_exmp_ind + ", sps_esign_ind=" + sps_esign_ind + ", sps_sign_dt=" + sps_sign_dt
				+ ", sps_mid_init=" + sps_mid_init + ", trnsp_exmp_ind=" + trnsp_exmp_ind + ", ucmft_exmp_ind="
				+ ucmft_exmp_ind + ", work_exmp_ind=" + work_exmp_ind + ", wthr_exmp_ind=" + wthr_exmp_ind
				+ ", othr_rsn_txt=" + othr_rsn_txt + ", direct_pay_sw=" + direct_pay_sw + ", info_exchange_consent_ind="
				+ info_exchange_consent_ind + ", electronically_sign_ind=" + electronically_sign_ind
				+ ", unable_sign_ind=" + unable_sign_ind + ", voter_registration_sw=" + voter_registration_sw
				+ ", suffix_name=" + suffix_name + ", applicant_first_name=" + applicant_first_name
				+ ", applicant_last_name=" + applicant_last_name + ", applicant_mid_name=" + applicant_mid_name
				+ ", sign_dt=" + sign_dt + ", applicant_suffix_name=" + applicant_suffix_name
				+ ", application_my_certi=" + application_my_certi + ", application_other_certi="
				+ application_other_certi + ", apply_medicaid=" + apply_medicaid + ", renewal_of_coverage="
				+ renewal_of_coverage + ", expedited_fap_sw=" + expedited_fap_sw + ", medicaid_abd_sw="
				+ medicaid_abd_sw + ", pregnant_sw=" + pregnant_sw + ", new_born_sw=" + new_born_sw
				+ ", citizenship_sign=" + citizenship_sign + ", authrep_citizenship_sign=" + authrep_citizenship_sign
				+ ", e_sign_ind1=" + e_sign_ind1 + ", sps_esign_ind1=" + sps_esign_ind1 + ", office_id=" + office_id
				+ ", esignArr=" + esignArr + ", phone_num=" + phone_num + ", address=" + address + ", case_num="
				+ case_num + ", form_type=" + form_type + ", sps_first_name=" + sps_first_name + ", sps_last_name="
				+ sps_last_name + ", org_user_agency_name=" + org_user_agency_name + ", applicant_sign_dt=\" + applicant_sign_dt + \"]";
	}
	public Date getSbmsDt() {
		return (Date)sbmsDt.clone();
	}
	public void setSbmsDt(Date sbmsDt) {
		this.sbmsDt = (Date)sbmsDt.clone();
	}
    
    
    
    

}
