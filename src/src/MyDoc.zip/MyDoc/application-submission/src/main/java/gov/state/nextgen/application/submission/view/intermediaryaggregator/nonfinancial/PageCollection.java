package gov.state.nextgen.application.submission.view.intermediaryaggregator.nonfinancial;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class PageCollection {
	
	@JsonDeserialize(contentAs = CP_APP_IN_CSHAID_STP_Collection.class)
	private List<CP_APP_IN_CSHAID_STP_Collection> CP_APP_IN_CSHAID_STP_Collection;
	
	
	@JsonDeserialize(contentAs = APP_IN_EMPL_HEALTH_Collection.class)
	private List<APP_IN_EMPL_HEALTH_Collection> APP_IN_EMPL_HEALTH_Collection;
	
	@JsonDeserialize(contentAs = APP_IN_HLTH_INS_BNFTS_Collection.class)
	private List<APP_IN_HLTH_INS_BNFTS_Collection> APP_IN_HLTH_INS_BNFTS_Collection;
	
	@JsonDeserialize(contentAs = APP_IN_PNLT_FRD_Collection.class)
	private List<APP_IN_PNLT_FRD_Collection> APP_IN_PNLT_FRD_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_IN_MED_INS_Collection.class)
	private List<CP_APP_IN_MED_INS_Collection> CP_APP_IN_MED_INS_Collection;
	
	@JsonDeserialize(contentAs = CP_APP_IN_WORKERS_COMP_Collection.class)
	private List<CP_APP_IN_WORKERS_COMP_Collection> CP_APP_IN_WORKERS_COMP_Collection;

	public List<APP_IN_EMPL_HEALTH_Collection> getAPP_IN_EMPL_HEALTH_Collection() {
		return APP_IN_EMPL_HEALTH_Collection;
	}

	public void setAPP_IN_EMPL_HEALTH_Collection(List<APP_IN_EMPL_HEALTH_Collection> aPP_IN_EMPL_HEALTH_Collection) {
		APP_IN_EMPL_HEALTH_Collection = aPP_IN_EMPL_HEALTH_Collection;
	}

	public List<APP_IN_HLTH_INS_BNFTS_Collection> getAPP_IN_HLTH_INS_BNFTS_Collection() {
		return APP_IN_HLTH_INS_BNFTS_Collection;
	}

	public void setAPP_IN_HLTH_INS_BNFTS_Collection(
			List<APP_IN_HLTH_INS_BNFTS_Collection> aPP_IN_HLTH_INS_BNFTS_Collection) {
		APP_IN_HLTH_INS_BNFTS_Collection = aPP_IN_HLTH_INS_BNFTS_Collection;
	}

	public List<CP_APP_IN_CSHAID_STP_Collection> getCP_APP_IN_CSHAID_STP_Collection() {
		return CP_APP_IN_CSHAID_STP_Collection;
	}

	public void setCP_APP_IN_CSHAID_STP_Collection(List<CP_APP_IN_CSHAID_STP_Collection> cP_APP_IN_CSHAID_STP_Collection) {
		CP_APP_IN_CSHAID_STP_Collection = cP_APP_IN_CSHAID_STP_Collection;
	}

	public List<APP_IN_PNLT_FRD_Collection> getAPP_IN_PNLT_FRD_Collection() {
		return APP_IN_PNLT_FRD_Collection;
	}

	public void setAPP_IN_PNLT_FRD_Collection(List<APP_IN_PNLT_FRD_Collection> aPP_IN_PNLT_FRD_Collection) {
		APP_IN_PNLT_FRD_Collection = aPP_IN_PNLT_FRD_Collection;
	}

	public List<CP_APP_IN_MED_INS_Collection> getCP_APP_IN_MED_INS_Collection() {
		return CP_APP_IN_MED_INS_Collection;
	}

	public void setCP_APP_IN_MED_INS_Collection(List<CP_APP_IN_MED_INS_Collection> cP_APP_IN_MED_INS_Collection) {
		CP_APP_IN_MED_INS_Collection = cP_APP_IN_MED_INS_Collection;
	}

	public List<CP_APP_IN_WORKERS_COMP_Collection> getCP_APP_IN_WORKERS_COMP_Collection() {
		return CP_APP_IN_WORKERS_COMP_Collection;
	}

	public void setCP_APP_IN_WORKERS_COMP_Collection(
			List<CP_APP_IN_WORKERS_COMP_Collection> cP_APP_IN_WORKERS_COMP_Collection) {
		CP_APP_IN_WORKERS_COMP_Collection = cP_APP_IN_WORKERS_COMP_Collection;
	}
		
}

