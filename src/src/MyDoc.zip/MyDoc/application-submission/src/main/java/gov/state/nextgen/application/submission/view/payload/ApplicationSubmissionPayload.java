package gov.state.nextgen.application.submission.view.payload;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class ApplicationSubmissionPayload {

	private String countyCode;
	private String appNumber;
	private String calheersCaseNo;
	private String signDate;
	private String representativePerson;
	private boolean dsnapInd; // Mandatory Field
	private String disasterEndDate;
	private String officeIdentif;
	private String loginInfoId;
	private String loginUserName;
	private boolean cmspInd; // Mandatory Field
	private Boolean otherPersonApplyInd;
	private boolean renewalInd; //Mandatory Field
	private String voterRegStatusCode;
	private Boolean abuseInd;
	private Boolean domesticAbuseInd;
	private Boolean elderAbuseInd;
	private Boolean emergencyRequestsInd;
	private Boolean immediateNeedInd;
	private Boolean immediateMedicalInd;
	private Boolean indianReservationInd;
	private Boolean otherEmergencyInd;
	private String userAgency;
	private Boolean initialApplicationInd;
	private Boolean cfInPersonIntviewInd;
	private List<WhoElseCovered> whoElseCovered;
	private Boolean otherArrangeDisbInd;
	@JsonIgnore
	private Boolean consentForVerifInd;
	@JsonIgnore
	private int yearsMaintainingVerif;
	@JsonIgnore
	private Boolean applyFinancialAidInd;
	private DisasterCalFresh disasterCalFresh;
	private CalFreshAuthRep calFreshAuthRep;
	private CfBeneficiaryDetails cfBeneficiaryDetails;
	private HlthRepInfo hlthRepInfo;
	private HtlhRepAgentInfo htlhRepAgentInfo;
	private HtlhRepSig htlhRepSig;
	private Applicant primaryApplicant;
	private List<Applicant> otherApplicants = new ArrayList<>();
	private List<RootQuestion> rootQuestions;
	private List<Relationship> relationships;
	private AdditionalServices additionalServices;
	private TaxInformation taxInformation;
	private List<SponsoredNonCitzInfo> sponsoredNonCitzInfo;
	@JsonIgnore
	private String oldAppNumber;
	private Date appDate;
	private String workerIdentifier;
	@JsonIgnore
	private String category;
	@JsonIgnore
	private String emergencyRequestType;
	private boolean expediteInd; // Mandatory Field
	@JsonIgnore
	private String assignDate;
	private Boolean otherSpecialNeedsInd;
	private String otherSpecialNeedsExpl;
	private String errorMessage;
	@JsonIgnore
	private Boolean contractFulfilled = true;
	private String appSubmissionDate; // Mandatory Field

	

	public String getCountyCode() {
		return countyCode;
	}

	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}

	public String getAppNumber() {
		return appNumber;
	}

	public void setAppNumber(String appNumber) {
		this.appNumber = appNumber;
	}

	public String getCalheersCaseNo() {
		return calheersCaseNo;
	}

	public void setCalheersCaseNo(String calheersCaseNo) {
		this.calheersCaseNo = calheersCaseNo;
	}

	public String getSignDate() {
		return signDate;
	}

	public void setSignDate(String signDate) {
		this.signDate = signDate;
	}

	public String getRepresentativePerson() {
		return representativePerson;
	}

	public void setRepresentativePerson(String representativePerson) {
		this.representativePerson = representativePerson;
	}

	public boolean isDsnapInd() {
		return dsnapInd;
	}

	public void setDsnapInd(boolean dsnapInd) {
		this.dsnapInd = dsnapInd;
	}

	public String getDisasterEndDate() {
		return disasterEndDate;
	}

	public void setDisasterEndDate(String disasterEndDate) {
		this.disasterEndDate = disasterEndDate;
	}

	public String getOfficeIdentif() {
		return officeIdentif;
	}

	public void setOfficeIdentif(String officeIdentif) {
		this.officeIdentif = officeIdentif;
	}

	public String getLoginInfoId() {
		return loginInfoId;
	}

	public void setLoginInfoId(String loginInfoId) {
		this.loginInfoId = loginInfoId;
	}

	public String getLoginUserName() {
		return loginUserName;
	}

	public void setLoginUserName(String loginUserName) {
		this.loginUserName = loginUserName;
	}

	public boolean isCmspInd() {
		return cmspInd;
	}

	public void setCmspInd(boolean cmspInd) {
		this.cmspInd = cmspInd;
	}

	public Boolean isOtherPersonApplyInd() {
		return otherPersonApplyInd;
	}

	public void setOtherPersonApplyInd(Boolean otherPersonApplyInd) {
		this.otherPersonApplyInd = otherPersonApplyInd;
	}

	public boolean isRenewalInd() {
		return renewalInd;
	}

	public void setRenewalInd(boolean renewalInd) {
		this.renewalInd = renewalInd;
	}

	public String getVoterRegStatusCode() {
		return voterRegStatusCode;
	}

	public void setVoterRegStatusCode(String voterRegStatusCode) {
		this.voterRegStatusCode = voterRegStatusCode;
	}

	public Boolean isAbuseInd() {
		return abuseInd;
	}

	public void setAbuseInd(Boolean abuseInd) {
		this.abuseInd = abuseInd;
	}

	public Boolean isDomesticAbuseInd() {
		return domesticAbuseInd;
	}

	public void setDomesticAbuseInd(Boolean domesticAbuseInd) {
		this.domesticAbuseInd = domesticAbuseInd;
	}

	public Boolean isElderAbuseInd() {
		return elderAbuseInd;
	}

	public void setElderAbuseInd(Boolean elderAbuseInd) {
		this.elderAbuseInd = elderAbuseInd;
	}

	public Boolean isEmergencyRequestsInd() {
		return emergencyRequestsInd;
	}

	public void setEmergencyRequestsInd(Boolean emergencyRequestsInd) {
		this.emergencyRequestsInd = emergencyRequestsInd;
	}

	public Boolean isImmediateNeedInd() {
		return immediateNeedInd;
	}

	public void setImmediateNeedInd(Boolean immediateNeedInd) {
		this.immediateNeedInd = immediateNeedInd;
	}

	public Boolean isImmediateMedicalInd() {
		return immediateMedicalInd;
	}

	public void setImmediateMedicalInd(Boolean immediateMedicalInd) {
		this.immediateMedicalInd = immediateMedicalInd;
	}

	public Boolean isIndianReservationInd() {
		return indianReservationInd;
	}

	public void setIndianReservationInd(Boolean indianReservationInd) {
		this.indianReservationInd = indianReservationInd;
	}

	public Boolean isOtherEmergencyInd() {
		return otherEmergencyInd;
	}

	public void setOtherEmergencyInd(Boolean otherEmergencyInd) {
		this.otherEmergencyInd = otherEmergencyInd;
	}

	public String getUserAgency() {
		return userAgency;
	}

	public void setUserAgency(String userAgency) {
		this.userAgency = userAgency;
	}

	public Boolean isInitialApplicationInd() {
		return initialApplicationInd;
	}

	public void setInitialApplicationInd(Boolean initialApplicationInd) {
		this.initialApplicationInd = initialApplicationInd;
	}

	public Boolean isCfInPersonIntviewInd() {
		return cfInPersonIntviewInd;
	}

	public void setCfInPersonIntviewInd(Boolean cfInPersonIntviewInd) {
		this.cfInPersonIntviewInd = cfInPersonIntviewInd;
	}

	public List<WhoElseCovered> getWhoElseCovered() {
		return whoElseCovered;
	}

	public void setWhoElseCovered(List<WhoElseCovered> whoElseCovered) {
		this.whoElseCovered = whoElseCovered;
	}

	public Boolean isOtherArrangeDisbInd() {
		return otherArrangeDisbInd;
	}

	public void setOtherArrangeDisbInd(Boolean otherArrangeDisbInd) {
		this.otherArrangeDisbInd = otherArrangeDisbInd;
	}

	public Boolean isConsentForVerifInd() {
		return consentForVerifInd;
	}

	public void setConsentForVerifInd(Boolean consentForVerifInd) {
		this.consentForVerifInd = consentForVerifInd;
	}

	public int getYearsMaintainingVerif() {
		return yearsMaintainingVerif;
	}

	public void setYearsMaintainingVerif(int yearsMaintainingVerif) {
		this.yearsMaintainingVerif = yearsMaintainingVerif;
	}

	public Boolean isApplyFinancialAidInd() {
		return applyFinancialAidInd;
	}

	public void setApplyFinancialAidInd(Boolean applyFinancialAidInd) {
		this.applyFinancialAidInd = applyFinancialAidInd;
	}

	public DisasterCalFresh getDisasterCalFresh() {
		return disasterCalFresh;
	}

	public void setDisasterCalFresh(DisasterCalFresh disasterCalFresh) {
		this.disasterCalFresh = disasterCalFresh;
	}

	public CalFreshAuthRep getCalFreshAuthRep() {
		return calFreshAuthRep;
	}

	public void setCalFreshAuthRep(CalFreshAuthRep calFreshAuthRep) {
		this.calFreshAuthRep = calFreshAuthRep;
	}

	public CfBeneficiaryDetails getCfBeneficiaryDetails() {
		return cfBeneficiaryDetails;
	}

	public void setCfBeneficiaryDetails(CfBeneficiaryDetails cfBeneficiaryDetails) {
		this.cfBeneficiaryDetails = cfBeneficiaryDetails;
	}

	public HlthRepInfo getHlthRepInfo() {
		return hlthRepInfo;
	}

	public void setHlthRepInfo(HlthRepInfo hlthRepInfo) {
		this.hlthRepInfo = hlthRepInfo;
	}

	public HtlhRepAgentInfo getHtlhRepAgentInfo() {
		return htlhRepAgentInfo;
	}

	public void setHtlhRepAgentInfo(HtlhRepAgentInfo htlhRepAgentInfo) {
		this.htlhRepAgentInfo = htlhRepAgentInfo;
	}

	public HtlhRepSig getHtlhRepSig() {
		return htlhRepSig;
	}

	public void setHtlhRepSig(HtlhRepSig htlhRepSig) {
		this.htlhRepSig = htlhRepSig;
	}

	public Applicant getPrimaryApplicant() {
		return primaryApplicant;
	}

	public void setPrimaryApplicant(Applicant primaryApplicant) {
		this.primaryApplicant = primaryApplicant;
	}

	public List<Applicant> getOtherApplicants() {
		if(otherApplicants == null) {
			otherApplicants= new ArrayList<>();
		}
		return otherApplicants;
	}

	public void setOtherApplicants(List<Applicant> otherApplicants) {
		this.otherApplicants = otherApplicants;
	}

	public List<RootQuestion> getRootQuestions() {
		return rootQuestions;
	}

	public void setRootQuestions(List<RootQuestion> rootQuestions) {
		this.rootQuestions = rootQuestions;
	}

	public List<Relationship> getRelationships() {
		return relationships;
	}

	public void setRelationships(List<Relationship> relationships) {
		this.relationships = relationships;
	}

	public AdditionalServices getAdditionalServices() {
		return additionalServices;
	}

	public void setAdditionalServices(AdditionalServices additionalServices) {
		this.additionalServices = additionalServices;
	}

	public TaxInformation getTaxInformation() {
		return taxInformation;
	}

	public void setTaxInformation(TaxInformation taxInformation) {
		this.taxInformation = taxInformation;
	}

	public List<SponsoredNonCitzInfo> getSponsoredNonCitzInfo() {
		if(sponsoredNonCitzInfo == null) {
			sponsoredNonCitzInfo = new ArrayList<>();
		}
		return sponsoredNonCitzInfo;
	}

	public void setSponsoredNonCitzInfo(List<SponsoredNonCitzInfo> sponsoredNonCitzInfo) {
		this.sponsoredNonCitzInfo = sponsoredNonCitzInfo;
	}

	public String getOldAppNumber() {
		return oldAppNumber;
	}

	public void setOldAppNumber(String oldAppNumber) {
		this.oldAppNumber = oldAppNumber;
	}

	public Date getAppDate() {
		return appDate;
	}

	public void setAppDate(Date appDate) {
		this.appDate = appDate;
	}

	public String getWorkerIdentifier() {
		return workerIdentifier;
	}

	public void setWorkerIdentifier(String workerIdentifier) {
		this.workerIdentifier = workerIdentifier;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getEmergencyRequestType() {
		return emergencyRequestType;
	}

	public void setEmergencyRequestType(String emergencyRequestType) {
		this.emergencyRequestType = emergencyRequestType;
	}

	public boolean isExpediteInd() {
		return expediteInd;
	}

	public void setExpediteInd(boolean expediteInd) {
		this.expediteInd = expediteInd;
	}

	public String getAssignDate() {
		return assignDate;
	}

	public void setAssignDate(String assignDate) {
		this.assignDate = assignDate;
	}

	public Boolean isOtherSpecialNeedsInd() {
		return otherSpecialNeedsInd;
	}

	public void setOtherSpecialNeedsInd(Boolean otherSpecialNeedsInd) {
		this.otherSpecialNeedsInd = otherSpecialNeedsInd;
	}

	public String getOtherSpecialNeedsExpl() {
		return otherSpecialNeedsExpl;
	}

	public void setOtherSpecialNeedsExpl(String otherSpecialNeedsExpl) {
		this.otherSpecialNeedsExpl = otherSpecialNeedsExpl;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Boolean isContractFulfilled() {
		return contractFulfilled;
	}

	public void setContractFulfilled(Boolean contractFulfilled) {
		this.contractFulfilled = contractFulfilled;
	}

	public String getAppSubmissionDate() {
		return appSubmissionDate;
	}

	public void setAppSubmissionDate(String appSubmissionDate) {
		this.appSubmissionDate = appSubmissionDate;
	}
}
