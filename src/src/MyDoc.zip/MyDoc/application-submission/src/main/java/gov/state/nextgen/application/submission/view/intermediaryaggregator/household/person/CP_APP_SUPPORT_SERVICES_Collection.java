package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class CP_APP_SUPPORT_SERVICES_Collection {
	
	
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private String src_app_ind;
	private String indv_seq_num;
	private String child_health_disability;
	private String family_planning;
	private String free_vaccines;
	private String wic_flag;
	private String personal_care_ind;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(String indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getChild_health_disability() {
		return child_health_disability;
	}
	public void setChild_health_disability(String child_health_disability) {
		this.child_health_disability = child_health_disability;
	}
	public String getFamily_planning() {
		return family_planning;
	}
	public void setFamily_planning(String family_planning) {
		this.family_planning = family_planning;
	}
	public String getFree_vaccines() {
		return free_vaccines;
	}
	public void setFree_vaccines(String free_vaccines) {
		this.free_vaccines = free_vaccines;
	}
	public String getWic_flag() {
		return wic_flag;
	}
	public void setWic_flag(String wic_flag) {
		this.wic_flag = wic_flag;
	}
	public String getPersonal_care_ind() {
		return personal_care_ind;
	}
	public void setPersonal_care_ind(String personal_care_ind) {
		this.personal_care_ind = personal_care_ind;
	}
	
	@Override
	public String toString() {
		return "CP_APP_SUPPORT_SERVICES_Collection [user=" + user + ", cargoName=" + cargoName + ", rowAction="
				+ rowAction + ", adaptRecordId=" + adaptRecordId + ", delete_reason_cd=" + delete_reason_cd
				+ ", app_num=" + app_num + ", src_app_ind=" + src_app_ind + ", indv_seq_num=" + indv_seq_num
				+ ", child_health_disability=" + child_health_disability + ", family_planning=" + family_planning
				+ ", free_vaccines=" + free_vaccines + ", wic_flag=" + wic_flag + ", personal_care_ind="
				+ personal_care_ind + "]";
	}
	
	
	

}
