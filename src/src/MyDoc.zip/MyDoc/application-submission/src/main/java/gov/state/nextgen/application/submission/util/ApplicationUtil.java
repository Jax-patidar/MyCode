package gov.state.nextgen.application.submission.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.function.BiFunction;

import org.springframework.http.MediaType;

import com.amazonaws.serverless.proxy.model.ApiGatewayRequestIdentity;
import com.amazonaws.serverless.proxy.model.AwsProxyRequest;
import com.amazonaws.serverless.proxy.model.AwsProxyRequestContext;
import com.amazonaws.serverless.proxy.model.Headers;
import com.amazonaws.serverless.proxy.model.MultiValuedTreeMap;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.model.ErrorMessageModel;
import gov.state.nextgen.application.submission.model.NameValuePairModel;

public class ApplicationUtil {
	
	private static Map<Integer, Integer> benefitsCalIndividualIdMap = new HashMap<Integer, Integer>();

	private ApplicationUtil() {}
	
    public static BiFunction<String,String,ErrorMessageModel> buildErrorMessageModelFn(){
        return (origin, message) ->{
            ErrorMessageModel errorMessageModel = new ErrorMessageModel();
            errorMessageModel.setMessage(message);
            errorMessageModel.setOrigin(origin);
            return errorMessageModel;
        };
    }

    public static BiFunction<String, String, NameValuePairModel> buildNVPModelFn(){
        return (key,value) ->{
            NameValuePairModel nvp = new NameValuePairModel();
            nvp.setKey(key);
            nvp.setValue(value);
            return nvp;
        };
    }
    
     /**
     * Delivers all event to POST /event?type=className
     */
    public static AwsProxyRequest convertToRequest(String json, String url) {
        AwsProxyRequest r = new AwsProxyRequest();
        r.setPath(url);
        r.setResource(url);
        r.setHttpMethod("POST");
        MultiValuedTreeMap<String, String> q = new MultiValuedTreeMap<>();
        r.setBody(json);
        r.setMultiValueQueryStringParameters(q);
        Headers h = new Headers();
        h.putSingle("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        r.setMultiValueHeaders(h);
        AwsProxyRequestContext rc = new AwsProxyRequestContext();
        rc.setIdentity(new ApiGatewayRequestIdentity());
        r.setRequestContext(rc);
        return r;
    }
    
    public static String prepareAWSRequest(String httpMethod, String resource, String path, Object payload) throws JsonProcessingException {
		long epoch = System.currentTimeMillis();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss z");
		sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
		
		ObjectMapper obj = new ObjectMapper();
		
		StringBuffer sb = new StringBuffer();
		sb.append("{   \"resource\": \"");
		sb.append(resource);
		sb.append("\",   \"path\": \"");
		sb.append(path);
		sb.append("\",   \"httpMethod\": \"");
		sb.append(httpMethod);
		sb.append("\",   \"headers\": {     \"Accept\": \"*/*\",     \"Accept-Encoding\": \"gzip, deflate, br\",     \"Content-Type\": \"application/json\"  ,  \"x-auth-id\":  \"\" },   \"multiValueHeaders\": {     \"Accept\": [ \"*/*\" ],     \"Accept-Encoding\": [ \"gzip, deflate, br\" ],     \"Content-Type\": [ \"application/json\" ],     \"Host\": [ \"\" ],     \"Postman-Token\": [ \"\" ],     \"User-Agent\": [ \"LambdaToLambda\" ],     \"X-Amzn-Trace-Id\": [ \"\" ],     \"X-Forwarded-For\": [ \"\" ],     \"X-Forwarded-Port\": [ \"443\" ],     \"X-Forwarded-Proto\": [ \"https\" ] ,  \"x-auth-id\":  [\"\"]  },   \"queryStringParameters\": null,   \"multiValueQueryStringParameters\": null,   \"pathParameters\": {},   \"stageVariables\": null,   \"requestContext\": {     \"resourceId\": \"\",     \"resourcePath\": \"");
		sb.append(resource);
		sb.append("\",     \"httpMethod\": \"");
		sb.append(httpMethod);
		sb.append("\",     \"extendedRequestId\": \"\",     \"requestTime\": \"");
		sb.append(sdf.format(new Date(epoch)));
		sb.append("\",     \"path\": \"");
		sb.append(path);
		sb.append("\",     \"accountId\": \"\",     \"protocol\": \"HTTP/1.1\",     \"stage\": \"\",     \"domainPrefix\": \"\",     \"requestTimeEpoch\": ");
		sb.append(epoch);
		sb.append(",     \"requestId\": \"\",     \"identity\": {       \"cognitoIdentityPoolId\": null,       \"accountId\": null,       \"cognitoIdentityId\": null,       \"caller\": null,       \"sourceIp\": \"\",       \"principalOrgId\": null,       \"accessKey\": null,       \"cognitoAuthenticationType\": null,       \"cognitoAuthenticationProvider\": null,       \"userArn\": null,       \"userAgent\": \"PostmanRuntime/7.26.5\",       \"user\": null     },     \"domainName\": \"\",     \"apiId\": \"\"   },   \"body\": \"");
		sb.append(obj.writeValueAsString(payload).replaceAll("\"", "\\\\\""));
		sb.append( "\",   \"isBase64Encoded\": false }");
		
		
		return sb.toString();
	}
    
    public static String createURIPath(String path, String name, String nameLoad)
    {
    	
    	String uriPath = ApplicationSubmissionConstants.PATH_SEPERATOR + path + ApplicationSubmissionConstants.PATH_SEPERATOR + name + ApplicationSubmissionConstants.PATH_SEPERATOR  + nameLoad;
    	return uriPath;
    	
    }
    
    public static Boolean translateBoolean(String varName)
    {
    	Boolean flag = null;
    	if(varName != null) {
    		if(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(varName) || ApplicationSubmissionConstants.STR_1.equalsIgnoreCase(varName)) {
    			flag = true;
    		} else if(ApplicationSubmissionConstants.STR_N.equalsIgnoreCase(varName)) {
    			flag = false;
    		}
    	}
    	return flag;	
    }
    
    public static void setBenefitsCalIndividualIdMapValues(Map<Integer, Integer> setBenefitsCalIndividualIdMap) {
    	benefitsCalIndividualIdMap = setBenefitsCalIndividualIdMap;
    }
    
    /**
     * Fetch value based on indv_seq_num
     * 
     * @param indvSeqNum
     * @return
     */
    public static Integer getBenefitsCalIndividualIdValue(Integer indvSeqNum) {
    	Integer benefitsCalIndividualId = null;
    	benefitsCalIndividualId = benefitsCalIndividualIdMap.get(indvSeqNum);
    	return benefitsCalIndividualId;
    }
    
}
