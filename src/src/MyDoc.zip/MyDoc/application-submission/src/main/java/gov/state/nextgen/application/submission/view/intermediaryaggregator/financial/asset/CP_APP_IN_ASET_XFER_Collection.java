package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.asset;

public final class CP_APP_IN_ASET_XFER_Collection {
	private String user;
    private String cargoName;
    private String rowAction;
    private String adaptRecordId;
    private String delete_reason_cd;
    private String app_num;
    private int asset_seq_num;
    private int indv_seq_num;
    private String src_app_ind;
    private String asset_acq_dt;
    private String asset_type;
    private double asset_val_amt;
    private double asset_xfer_amt;
    private String asset_xfer_dt;
    private String asset_xfer_rsn_cd;
    private String first_name;
    private String last_name;
    private String asset_st_ind;
    private String rec_cplt_ind;
    private String loopingInd;
    private String ecp_id;
    private String chg_dt;
    private String comments;
    private int seq_num;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public int getAsset_seq_num() {
		return asset_seq_num;
	}
	public void setAsset_seq_num(int asset_seq_num) {
		this.asset_seq_num = asset_seq_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getAsset_acq_dt() {
		return asset_acq_dt;
	}
	public void setAsset_acq_dt(String asset_acq_dt) {
		this.asset_acq_dt = asset_acq_dt;
	}
	public String getAsset_type() {
		return asset_type;
	}
	public void setAsset_type(String asset_type) {
		this.asset_type = asset_type;
	}
	public double getAsset_val_amt() {
		return asset_val_amt;
	}
	public void setAsset_val_amt(double asset_val_amt) {
		this.asset_val_amt = asset_val_amt;
	}
	public double getAsset_xfer_amt() {
		return asset_xfer_amt;
	}
	public void setAsset_xfer_amt(double asset_xfer_amt) {
		this.asset_xfer_amt = asset_xfer_amt;
	}
	public String getAsset_xfer_dt() {
		return asset_xfer_dt;
	}
	public void setAsset_xfer_dt(String asset_xfer_dt) {
		this.asset_xfer_dt = asset_xfer_dt;
	}
	public String getAsset_xfer_rsn_cd() {
		return asset_xfer_rsn_cd;
	}
	public void setAsset_xfer_rsn_cd(String asset_xfer_rsn_cd) {
		this.asset_xfer_rsn_cd = asset_xfer_rsn_cd;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getAsset_st_ind() {
		return asset_st_ind;
	}
	public void setAsset_st_ind(String asset_st_ind) {
		this.asset_st_ind = asset_st_ind;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getLoopingInd() {
		return loopingInd;
	}
	public void setLoopingInd(String loopingInd) {
		this.loopingInd = loopingInd;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public int getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}
	
		
	

}
