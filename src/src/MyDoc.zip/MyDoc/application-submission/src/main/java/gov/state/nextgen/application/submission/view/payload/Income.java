package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class Income {

    private double amount;
    private String frequency;
    private String typeCode;
    private String sourceCode;
    private String sourceName;
    private String category;
    private String beginDate;
    private String endDate;
    private Boolean continueToReceiveIncomeInd;
    private String inKindFreeOrWork;
    private double inKindItemVal;
    private String inKindGivenBy;
    private String incomeNotExpectedToContExpl;
    private String state;
    private String county;
    private String servicesReceived;
    private String estimatedValueofService;
    
    
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getSourceCode() {
		return sourceCode;
	}
	public void setSourceCode(String sourceCode) {
		this.sourceCode = sourceCode;
	}
	public String getSourceName() {
		return sourceName;
	}
	public void setSourceName(String sourceName) {
		this.sourceName = sourceName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(String beginDate) {
		this.beginDate = beginDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public Boolean isContinueToReceiveIncomeInd() {
		return continueToReceiveIncomeInd;
	}
	public void setContinueToReceiveIncomeInd(Boolean continueToReceiveIncomeInd) {
		this.continueToReceiveIncomeInd = continueToReceiveIncomeInd;
	}
	public String getInKindFreeOrWork() {
		return inKindFreeOrWork;
	}
	public void setInKindFreeOrWork(String inKindFreeOrWork) {
		this.inKindFreeOrWork = inKindFreeOrWork;
	}
	public double getInKindItemVal() {
		return inKindItemVal;
	}
	public void setInKindItemVal(double inKindItemVal) {
		this.inKindItemVal = inKindItemVal;
	}
	public String getInKindGivenBy() {
		return inKindGivenBy;
	}
	public void setInKindGivenBy(String inKindGivenBy) {
		this.inKindGivenBy = inKindGivenBy;
	}
	public String getIncomeNotExpectedToContExpl() {
		return incomeNotExpectedToContExpl;
	}
	public void setIncomeNotExpectedToContExpl(String incomeNotExpectedToContExpl) {
		this.incomeNotExpectedToContExpl = incomeNotExpectedToContExpl;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getServicesReceived() {
		return servicesReceived;
	}
	public void setServicesReceived(String servicesReceived) {
		this.servicesReceived = servicesReceived;
	}
	public void setEstimatedValueofService(String estimatedValueofService) {
		this.estimatedValueofService = estimatedValueofService;
	}
	public String getEstimatedValueofService() {
		return estimatedValueofService;
	}
}
