package gov.state.nextgen.application.submission.framework.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FwLogger {

    /**
     * This class cannot be instantiated, why would you want to?
     */

    private FwLogger() {
        // Unreachable
    }

    /**
     * Log at the specified level. If the "logger" is null, nothing is logged.
     * If the "level" is null, nothing is logged. If the "txt" is null,
     * behaviour depends on the SLF4J implementation.
     */

    public static void log(Class className, Level level, String txt) {
    	Logger logger = LoggerFactory.getLogger(className);
        logMessage(level, txt, logger);
    }

    /**
     * Log at the specified level, with a Throwable on top. If the "logger" is null,
     * nothing is logged. If the "level" is null, nothing is logged. If the "format" or
     * the "argArray" or the "throwable" are null, behaviour depends on the SLF4J-backing
     * implementation.
     */

    public static void log(Class className, Level level, String txt, Throwable throwable) {
        Logger logger = LoggerFactory.getLogger(className);
        logMessage(level, txt, throwable, logger);
    }
    
    /**
     *
     *
     * @param level          Log level
     * @param message        message to log
     * @param logger         instance of logger
     */
    @SuppressWarnings("squid:S3776")
    private static void logMessage(Level level, String message, Logger logger) {
        try {
            Level systemLogLevel = getLogLevel();
            if (logger != null) {
                if (level == Level.ERROR && (systemLogLevel == Level.TRACE || systemLogLevel == Level.DEBUG || systemLogLevel == Level.INFO || systemLogLevel == Level.WARN || systemLogLevel == Level.ERROR)) {
                    logger.error(message);
                } else if (level == Level.WARN && (systemLogLevel == Level.TRACE || systemLogLevel == Level.DEBUG || systemLogLevel == Level.INFO || systemLogLevel == Level.WARN)) {
                    logger.warn(message);
                } else if (level == Level.INFO && (systemLogLevel == Level.TRACE || systemLogLevel == Level.DEBUG || systemLogLevel == Level.INFO)) {
                    logger.info(message);
                } else if (level == Level.DEBUG && (systemLogLevel == Level.TRACE || systemLogLevel == Level.DEBUG)) {
                    logger.debug(message);
                } else if (level == Level.TRACE && systemLogLevel == Level.TRACE) {
                    logger.trace(message);
                }
            }
        } catch (Exception exception) {
        	FwLogger.log(FwLogger.class, FwLogger.Level.ERROR, "Error occured in FwLogger.logMessage()", exception);
        }
    }

    /**
     *
     *
     * @param level          Log level
     * @param logger         instance of logger
     */
    @SuppressWarnings("squid:S3776")
    private static void logMessage(Level level, String txt, Throwable throwable, Logger logger) {
        try {
            Level systemLogLevel = getLogLevel();
            if (logger != null) {
                if (level == Level.ERROR && (systemLogLevel == Level.TRACE || systemLogLevel == Level.DEBUG || systemLogLevel == Level.INFO || systemLogLevel == Level.WARN || systemLogLevel == Level.ERROR)) {
                    logger.error(txt, throwable);
                } else if (level == Level.WARN && (systemLogLevel == Level.TRACE || systemLogLevel == Level.DEBUG || systemLogLevel == Level.INFO || systemLogLevel == Level.WARN)) {

                    logger.warn(txt, throwable);
                } else if (level == Level.INFO && (systemLogLevel == Level.TRACE || systemLogLevel == Level.DEBUG || systemLogLevel == Level.INFO)) {
                    logger.info(txt, throwable);
                } else if (level == Level.DEBUG && (systemLogLevel == Level.TRACE || systemLogLevel == Level.DEBUG)) {
                    logger.debug(txt, throwable);
                } else if (level == Level.TRACE && systemLogLevel == Level.TRACE) {
                    logger.trace(txt, throwable);
                }
            }
        } catch (Exception exception) {
        	FwLogger.log(FwLogger.class, FwLogger.Level.ERROR, "Error occured in FwLogger.logMessage()", exception);
        }
    }

    /**
     * Determines the log level for the application based on the environment setting.
     * If the env variable 'LOG_LEVEL' is set with one of the allowed values TRACE, DEBUG, INFO, WARN, or ERROR(case-sensitive in nature),  the routine returns the corresponding enum value.
     * Otherwise, it is defaulted to DEBUG.
     * @return  LogLevel(  TRACE, DEBUG, INFO, WARN, ERROR)
     */
    public static Level getLogLevel(){
        String logLevel = System.getenv("LOG_LEVEL");
        if(logLevel == null || logLevel.isEmpty()) return  Level.ERROR;
        Level level;
        try{
            level = Level.valueOf(logLevel);
        }catch(Exception exception){
            level = Level.ERROR;
        }
        return  level;
    }




    /**
     * Allowed levels, as an enum. Import using "import [package].LogLevel.Level"
     * Every logging implementation has something like this except SLF4J.
     */

    public enum Level {
        TRACE, DEBUG, INFO, WARN, ERROR
    }
    
}
