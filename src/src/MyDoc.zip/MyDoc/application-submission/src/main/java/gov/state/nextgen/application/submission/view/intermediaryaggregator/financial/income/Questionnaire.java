package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income;

public class Questionnaire {
	private String user;
    private String cargoName;
    private String rowAction;
    private String adaptRecordId;
    private String delete_reason_cd;
    private String earnedIncome;
    private String unearnedIncome;
    private String unearnedIncomeA;
    private String unearnedIncomeB;
    private String incomeInKind;
    private String incomeInKindA;
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getEarnedIncome() {
		return earnedIncome;
	}
	public void setEarnedIncome(String earnedIncome) {
		this.earnedIncome = earnedIncome;
	}
	public String getUnearnedIncome() {
		return unearnedIncome;
	}
	public void setUnearnedIncome(String unearnedIncome) {
		this.unearnedIncome = unearnedIncome;
	}
	public String getUnearnedIncomeA() {
		return unearnedIncomeA;
	}
	public void setUnearnedIncomeA(String unearnedIncomeA) {
		this.unearnedIncomeA = unearnedIncomeA;
	}
	public String getUnearnedIncomeB() {
		return unearnedIncomeB;
	}
	public void setUnearnedIncomeB(String unearnedIncomeB) {
		this.unearnedIncomeB = unearnedIncomeB;
	}
	public String getIncomeInKind() {
		return incomeInKind;
	}
	public void setIncomeInKind(String incomeInKind) {
		this.incomeInKind = incomeInKind;
	}
	public String getIncomeInKindA() {
		return incomeInKindA;
	}
	public void setIncomeInKindA(String incomeInKindA) {
		this.incomeInKindA = incomeInKindA;
	}
}
