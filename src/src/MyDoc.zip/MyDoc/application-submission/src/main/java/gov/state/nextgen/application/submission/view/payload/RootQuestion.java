package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class RootQuestion {

	@JsonIgnore
	private String questionCode;
	@JsonIgnore
	private boolean answerInd;

	public String getQuestionCode() {
		return questionCode;
	}

	public void setQuestionCode(String questionCode) {
		this.questionCode = questionCode;
	}

	public boolean isAnswerInd() {
		return answerInd;
	}

	public void setAnswerInd(boolean answerInd) {
		this.answerInd = answerInd;
	}
}
