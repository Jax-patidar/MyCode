package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class DisabilityDetails {

    private Boolean limitActivitiesInd;
    private Boolean inFacilityOrNursingHomeInd;
    private String facilityOrHomeName;
    private Boolean needsHelpWithDailyLivingInd;
    private String needsHelpText;
    private Boolean lessThanOneYearInd;
    private Boolean moreThanOneYearInd;
    private Boolean careSoOtherCanWorkInd;
    private Boolean needsCareFromHHMember;
    private String needsCareFromHHMemberText;
    private Boolean needToWorkForMedExnsInd;
    private String needToWorkForMedExnsText;
	public Boolean isLimitActivitiesInd() {
		return limitActivitiesInd;
	}
	public void setLimitActivitiesInd(Boolean limitActivitiesInd) {
		this.limitActivitiesInd = limitActivitiesInd;
	}
	public Boolean isInFacilityOrNursingHomeInd() {
		return inFacilityOrNursingHomeInd;
	}
	public void setInFacilityOrNursingHomeInd(Boolean inFacilityOrNursingHomeInd) {
		this.inFacilityOrNursingHomeInd = inFacilityOrNursingHomeInd;
	}
	public String getFacilityOrHomeName() {
		return facilityOrHomeName;
	}
	public void setFacilityOrHomeName(String facilityOrHomeName) {
		this.facilityOrHomeName = facilityOrHomeName;
	}
	public Boolean isNeedsHelpWithDailyLivingInd() {
		return needsHelpWithDailyLivingInd;
	}
	public void setNeedsHelpWithDailyLivingInd(Boolean needsHelpWithDailyLivingInd) {
		this.needsHelpWithDailyLivingInd = needsHelpWithDailyLivingInd;
	}
	public String getNeedsHelpText() {
		return needsHelpText;
	}
	public void setNeedsHelpText(String needsHelpText) {
		this.needsHelpText = needsHelpText;
	}
	public Boolean isLessThanOneYearInd() {
		return lessThanOneYearInd;
	}
	public void setLessThanOneYearInd(Boolean lessThanOneYearInd) {
		this.lessThanOneYearInd = lessThanOneYearInd;
	}
	public Boolean isMoreThanOneYearInd() {
		return moreThanOneYearInd;
	}
	public void setMoreThanOneYearInd(Boolean moreThanOneYearInd) {
		this.moreThanOneYearInd = moreThanOneYearInd;
	}
	public Boolean isCareSoOtherCanWorkInd() {
		return careSoOtherCanWorkInd;
	}
	public void setCareSoOtherCanWorkInd(Boolean careSoOtherCanWorkInd) {
		this.careSoOtherCanWorkInd = careSoOtherCanWorkInd;
	}
	public Boolean isNeedsCareFromHHMember() {
		return needsCareFromHHMember;
	}
	public void setNeedsCareFromHHMember(Boolean needsCareFromHHMember) {
		this.needsCareFromHHMember = needsCareFromHHMember;
	}
	public String getNeedsCareFromHHMemberText() {
		return needsCareFromHHMemberText;
	}
	public void setNeedsCareFromHHMemberText(String needsCareFromHHMemberText) {
		this.needsCareFromHHMemberText = needsCareFromHHMemberText;
	}
	public Boolean isNeedToWorkForMedExnsInd() {
		return needToWorkForMedExnsInd;
	}
	public void setNeedToWorkForMedExnsInd(Boolean needToWorkForMedExnsInd) {
		this.needToWorkForMedExnsInd = needToWorkForMedExnsInd;
	}
	public String getNeedToWorkForMedExnsText() {
		return needToWorkForMedExnsText;
	}
	public void setNeedToWorkForMedExnsText(String needToWorkForMedExnsText) {
		this.needToWorkForMedExnsText = needToWorkForMedExnsText;
	}
}
