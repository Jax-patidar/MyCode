package gov.state.nextgen.application.submission.view.payload;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class MotorVehicle {

	private int year;
	private String make;
	private String model;
	private String licenseNumber;
	private int yearFirstSold;
	@JsonIgnore
	private String vehicleClass;
	@JsonIgnore
	private Boolean regInd;
	private Boolean leaseInd;
	private String howEstimated;
	private String estimatedValue;
	private String howAmountOwedFound;
	private List<OtherUser> otherUsers;
	private Boolean useAsHomeInd;
	private Boolean useForWorkInd;
	private Boolean useToDriveDisabledInd;
	private Boolean useToGetFuelWaterInd;
	private Boolean useOtherInd;
	private Boolean wasGiftOrDonationInd;
	private String howVehicleObtained;

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getLicenseNumber() {
		return licenseNumber;
	}

	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}

	public int getYearFirstSold() {
		return yearFirstSold;
	}

	public void setYearFirstSold(int yearFirstSold) {
		this.yearFirstSold = yearFirstSold;
	}

	public String getVehicleClass() {
		return vehicleClass;
	}

	public void setVehicleClass(String vehicleClass) {
		this.vehicleClass = vehicleClass;
	}

	public Boolean isRegInd() {
		return regInd;
	}

	public void setRegInd(Boolean regInd) {
		this.regInd = regInd;
	}

	public Boolean isLeaseInd() {
		return leaseInd;
	}

	public void setLeaseInd(Boolean leaseInd) {
		this.leaseInd = leaseInd;
	}

	public String getHowEstimated() {
		return howEstimated;
	}

	public void setHowEstimated(String howEstimated) {
		this.howEstimated = howEstimated;
	}

	public String getEstimatedValue() {
		return estimatedValue;
	}

	public void setEstimatedValue(String estimatedValue) {
		this.estimatedValue = estimatedValue;
	}

	public String getHowAmountOwedFound() {
		return howAmountOwedFound;
	}

	public void setHowAmountOwedFound(String howAmountOwedFound) {
		this.howAmountOwedFound = howAmountOwedFound;
	}

	public List<OtherUser> getOtherUsers() {
		return otherUsers;
	}

	public void setOtherUsers(List<OtherUser> otherUsers) {
		this.otherUsers = otherUsers;
	}

	public Boolean isUseAsHomeInd() {
		return useAsHomeInd;
	}

	public void setUseAsHomeInd(Boolean useAsHomeInd) {
		this.useAsHomeInd = useAsHomeInd;
	}

	public Boolean isUseForWorkInd() {
		return useForWorkInd;
	}

	public void setUseForWorkInd(Boolean useForWorkInd) {
		this.useForWorkInd = useForWorkInd;
	}

	public Boolean isUseToDriveDisabledInd() {
		return useToDriveDisabledInd;
	}

	public void setUseToDriveDisabledInd(Boolean useToDriveDisabledInd) {
		this.useToDriveDisabledInd = useToDriveDisabledInd;
	}

	public Boolean isUseToGetFuelWaterInd() {
		return useToGetFuelWaterInd;
	}

	public void setUseToGetFuelWaterInd(Boolean useToGetFuelWaterInd) {
		this.useToGetFuelWaterInd = useToGetFuelWaterInd;
	}

	public Boolean isUseOtherInd() {
		return useOtherInd;
	}

	public void setUseOtherInd(Boolean useOtherInd) {
		this.useOtherInd = useOtherInd;
	}

	public Boolean isWasGiftOrDonationInd() {
		return wasGiftOrDonationInd;
	}

	public void setWasGiftOrDonationInd(Boolean wasGiftOrDonationInd) {
		this.wasGiftOrDonationInd = wasGiftOrDonationInd;
	}

	public String getHowVehicleObtained() {
		return howVehicleObtained;
	}

	public void setHowVehicleObtained(String howVehicleObtained) {
		this.howVehicleObtained = howVehicleObtained;
	}
}
