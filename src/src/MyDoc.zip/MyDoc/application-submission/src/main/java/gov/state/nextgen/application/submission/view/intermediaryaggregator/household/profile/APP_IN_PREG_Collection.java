package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile;

public class APP_IN_PREG_Collection {

	private int indv_seq_num;
	
	private String preg_due_dt;
	
	private String baby_ct;
	
	private String presump_elig_card_ind;
	
	private String enrl_stat_cd;
	
	private String  nt_enrl_stat_desc;

	public int getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public String getPreg_due_dt() {
		return preg_due_dt;
	}

	public void setPreg_due_dt(String preg_due_dt) {
		this.preg_due_dt = preg_due_dt;
	}

	public String getBaby_ct() {
		return baby_ct;
	}

	public void setBaby_ct(String baby_ct) {
		this.baby_ct = baby_ct;
	}

	public String getPresump_elig_card_ind() {
		return presump_elig_card_ind;
	}

	public void setPresump_elig_card_ind(String presump_elig_card_ind) {
		this.presump_elig_card_ind = presump_elig_card_ind;
	}

	public String getEnrl_stat_cd() {
		return enrl_stat_cd;
	}

	public void setEnrl_stat_cd(String enrl_stat_cd) {
		this.enrl_stat_cd = enrl_stat_cd;
	}

	public String getNt_enrl_stat_desc() {
		return nt_enrl_stat_desc;
	}

	public void setNt_enrl_stat_desc(String nt_enrl_stat_desc) {
		this.nt_enrl_stat_desc = nt_enrl_stat_desc;
	}
	
}
