package gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person;

public class CP_HSHL_DETAILS_DISASTER_Collection {
	
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private Integer indv_seq_num;
	private String src_app_ind;
	private String lived_ind;
	private String worked_ind;
	private String no_income_ind;
	private String delayed_stop_income;
	private String bought_prepared_meal;
	private String employed_county_ssd;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getCargoName() {
		return cargoName;
	}
	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}
	public String getRowAction() {
		return rowAction;
	}
	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}
	public String getAdaptRecordId() {
		return adaptRecordId;
	}
	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}
	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}
	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getLived_ind() {
		return lived_ind;
	}
	public void setLived_ind(String lived_ind) {
		this.lived_ind = lived_ind;
	}
	public String getWorked_ind() {
		return worked_ind;
	}
	public void setWorked_ind(String worked_ind) {
		this.worked_ind = worked_ind;
	}
	public String getNo_income_ind() {
		return no_income_ind;
	}
	public void setNo_income_ind(String no_income_ind) {
		this.no_income_ind = no_income_ind;
	}
	public String getDelayed_stop_income() {
		return delayed_stop_income;
	}
	public void setDelayed_stop_income(String delayed_stop_income) {
		this.delayed_stop_income = delayed_stop_income;
	}
	public String getBought_prepared_meal() {
		return bought_prepared_meal;
	}
	public void setBought_prepared_meal(String bought_prepared_meal) {
		this.bought_prepared_meal = bought_prepared_meal;
	}
	public String getEmployed_county_ssd() {
		return employed_county_ssd;
	}
	public void setEmployed_county_ssd(String employed_county_ssd) {
		this.employed_county_ssd = employed_county_ssd;
	}

}
