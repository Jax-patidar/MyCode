package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class Ethnicity {
	public String race;
	public String ethnicOriginText;
	public String tribe;

	public String getRace() {
		return race;
	}

	public void setRace(String race) {
		this.race = race;
	}

	public String getTribe() {
		return tribe;
	}

	public void setTribe(String tribe) {
		this.tribe = tribe;
	}

	public String getEthnicOriginText() {
		return ethnicOriginText;
	}

	public void setEthnicOriginText(String ethnicOriginText) {
		this.ethnicOriginText = ethnicOriginText;
	}
}
