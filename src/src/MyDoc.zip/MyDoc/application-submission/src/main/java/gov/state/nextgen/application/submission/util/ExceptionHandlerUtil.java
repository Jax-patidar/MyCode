package gov.state.nextgen.application.submission.util;

import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.model.ApplicationResponse;
import gov.state.nextgen.application.submission.model.ApplicationStatusResponse;

public class ExceptionHandlerUtil {


    /**
     * @param responseCode
     * @param message
     * @param responseStatus
     * @return
     */
    public static ApplicationResponse<ApplicationStatusResponse> buildApplicationResponse(Exception ex, String responseCode, String message, String responseStatus) {
        ApplicationResponse<ApplicationStatusResponse> response = new ApplicationResponse<>();
        ApplicationStatusResponse applicationStatusResponse = new ApplicationStatusResponse();
        applicationStatusResponse.setResponseCode(responseCode);
        applicationStatusResponse.setResponseDescription(message);
        applicationStatusResponse.setResponseStatus(responseStatus);
        response.setStatus("error");
        response.setData(applicationStatusResponse);

        FwLogger.log(ExceptionHandlerUtil.class,
                FwLogger.Level.ERROR,
                "globalExceptionHandler - Exception v due to::" + ex.getMessage());

        return response;
    }
}
