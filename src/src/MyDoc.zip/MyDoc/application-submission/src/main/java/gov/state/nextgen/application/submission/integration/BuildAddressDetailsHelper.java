package gov.state.nextgen.application.submission.integration;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_RGST_Collection;
import gov.state.nextgen.application.submission.view.payload.Address;

import java.util.ArrayList;
import java.util.List;

public class BuildAddressDetailsHelper {
	
	private BuildAddressDetailsHelper() {}
	
	public static List<Address> buildAddressDetails(CP_APP_RGST_Collection rgstInfo) {
		Address address = null;
		List<Address> addrList = new ArrayList<>();
		
		try {
			if(rgstInfo !=null) {
				if(rgstInfo.getHshl_l1_adr()!= null && !ApplicationSubmissionConstants.STR_EMPT.equals(rgstInfo.getHshl_l1_adr().trim())) {
					address = new Address();
					address.setAddrType(ApplicationSubmissionConstants.STR_PH); 
					address.setCityName(rgstInfo.getHshl_city_adr());
					address.setState(rgstInfo.getHshl_sta_adr());
					address.setStreetAddr1(rgstInfo.getHshl_l1_adr());
					address.setStreetAddr2(rgstInfo.getHshl_l2_adr());
					address.setZipCode(rgstInfo.getHshl_zip_adr());
					address.setZipCodeSuffix(rgstInfo.getHshl_addr_zip4());
					addrList.add(address);
				}

				if(rgstInfo.getAlt_st_adr()!= null && !ApplicationSubmissionConstants.STR_EMPT.equals(rgstInfo.getAlt_st_adr().trim())) {
					address = new Address();
					address.setAddrType(ApplicationSubmissionConstants.STR_ML); 
					address.setCityName(rgstInfo.getAlt_city_adr());
					address.setState(rgstInfo.getAlt_sta_adr());
					address.setStreetAddr1(rgstInfo.getAlt_st_adr());
					address.setStreetAddr2(rgstInfo.getAlt_l2_adr());
					address.setZipCode(rgstInfo.getAlt_zip_adr());
					address.setZipCodeSuffix(rgstInfo.getAlt_addr_zip4());
					addrList.add(address);
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildAddressDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while building Address Details - " + e.getMessage());
		}
		return addrList;
	}
}
