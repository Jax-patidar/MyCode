package gov.state.nextgen.application.submission.config;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 */
@Configuration
public class ServiceRestTemplateClientConfig {

	@Value("${http.pool.config.app-submission.read_timeout}")
	private int readTimeout;
	

	/**
	 * @param defaultRequestConfig
	 * @param connectionManager
	 * @return
	 */
	@Bean
	public RestTemplate appSubmissionRestTemplate(@Qualifier("defaultRequestConfig") RequestConfig defaultRequestConfig, @Qualifier("poolingHttpClientConnectionManager") HttpClientConnectionManager connectionManager) {
		final RequestConfig requestConfig = RequestConfig.copy(defaultRequestConfig).setSocketTimeout(readTimeout).build();
		final HttpClient httpClient = HttpClientBuilder.create().setConnectionManager(connectionManager).setDefaultRequestConfig(requestConfig).build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		requestFactory.setReadTimeout(readTimeout);
		return new RestTemplate(new BufferingClientHttpRequestFactory(requestFactory));
	}
	
}
