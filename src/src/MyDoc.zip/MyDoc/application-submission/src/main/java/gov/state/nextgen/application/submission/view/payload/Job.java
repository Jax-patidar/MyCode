package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_EMPTY )
public class Job {
	private String employerName;
	private int hoursPerMonth;
	@JsonIgnore
	private String jobTitle;
	private Boolean selfEmployedInd;
	@JsonIgnore
	private Boolean workTrainingInd;
	private String typeCode;
	@JsonIgnore
	private Boolean termInd;
	private String endDate;
	private String hireDate;
	private Address employerAddress;
	private PhoneNumber employerPhone;
	private String selfEmpBusName;
	private String selfEmpBusType;
	private String selfEmpBusStartDate;
	private double selfEmpGrossMnthlyAmt;
	private String lastPayDate;
	private Boolean changein60daysInd;
	private Boolean changeInLastYearInd;
	private Boolean countyHelpedInd;
	private String explainJobChange;

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public int getHoursPerMonth() {
		return hoursPerMonth;
	}

	public void setHoursPerMonth(int hoursPerMonth) {
		this.hoursPerMonth = hoursPerMonth;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public Boolean isSelfEmployedInd() {
		return selfEmployedInd;
	}

	public void setSelfEmployedInd(Boolean selfEmployedInd) {
		this.selfEmployedInd = selfEmployedInd;
	}

	public Boolean isWorkTrainingInd() {
		return workTrainingInd;
	}

	public void setWorkTrainingInd(Boolean workTrainingInd) {
		this.workTrainingInd = workTrainingInd;
	}

	public String getTypeCode() {
		return typeCode;
	}

	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}

	public Boolean isTermInd() {
		return termInd;
	}

	public void setTermInd(Boolean termInd) {
		this.termInd = termInd;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getHireDate() {
		return hireDate;
	}

	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	}

	public Address getEmployerAddress() {
		return employerAddress;
	}

	public void setEmployerAddress(Address employerAddress) {
		this.employerAddress = employerAddress;
	}

	public PhoneNumber getEmployerPhone() {
		return employerPhone;
	}

	public void setEmployerPhone(PhoneNumber employerPhone) {
		this.employerPhone = employerPhone;
	}

	public String getSelfEmpBusName() {
		return selfEmpBusName;
	}

	public void setSelfEmpBusName(String selfEmpBusName) {
		this.selfEmpBusName = selfEmpBusName;
	}

	public String getSelfEmpBusType() {
		return selfEmpBusType;
	}

	public void setSelfEmpBusType(String selfEmpBusType) {
		this.selfEmpBusType = selfEmpBusType;
	}

	public String getSelfEmpBusStartDate() {
		return selfEmpBusStartDate;
	}

	public void setSelfEmpBusStartDate(String selfEmpBusStartDate) {
		this.selfEmpBusStartDate = selfEmpBusStartDate;
	}

	public double getSelfEmpGrossMnthlyAmt() {
		return selfEmpGrossMnthlyAmt;
	}

	public void setSelfEmpGrossMnthlyAmt(double selfEmpGrossMnthlyAmt) {
		this.selfEmpGrossMnthlyAmt = selfEmpGrossMnthlyAmt;
	}

	public String getLastPayDate() {
		return lastPayDate;
	}

	public void setLastPayDate(String lastPayDate) {
		this.lastPayDate = lastPayDate;
	}

	public Boolean isChangein60daysInd() {
		return changein60daysInd;
	}

	public void setChangein60daysInd(Boolean changein60daysInd) {
		this.changein60daysInd = changein60daysInd;
	}

	public Boolean isChangeInLastYearInd() {
		return changeInLastYearInd;
	}

	public void setChangeInLastYearInd(Boolean changeInLastYearInd) {
		this.changeInLastYearInd = changeInLastYearInd;
	}

	public Boolean isCountyHelpedInd() {
		return countyHelpedInd;
	}

	public void setCountyHelpedInd(Boolean countyHelpedInd) {
		this.countyHelpedInd = countyHelpedInd;
	}

	public String getExplainJobChange() {
		return explainJobChange;
	}

	public void setExplainJobChange(String explainJobChange) {
		this.explainJobChange = explainJobChange;
	}
}
