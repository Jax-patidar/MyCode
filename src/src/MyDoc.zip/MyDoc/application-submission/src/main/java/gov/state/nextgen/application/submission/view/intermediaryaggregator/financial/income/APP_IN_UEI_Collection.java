package gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.income;

public class APP_IN_UEI_Collection {
	private String user;
	private String cargoName;
	private String rowAction;
	private String adaptRecordId;
	private String delete_reason_cd;
	private String app_num;
	private int indv_seq_num;
	private int seq_num;
	private String src_app_ind;
	private String ecp_id;
	private String chg_eff_dt;
	private int rec_cplt_ind;
	private double uei_amt;
	private String uei_amt_ind;
	private String uei_beg_dt;
	private String uei_typ;
	private String rsdi_income_expected_sw;
	private String othr_incm_src;
	private String expected_to_cont_resp;
	private String uei_end_dt;
	private String loopingQuestion;
	private String money_providing_person_name;
	private String money_direct_ind;
	private String loan_ind;
	private String money_pay_back_ind;
	private String freq_cd;
	private String uei_claim_num;
	private String uei_Sub_Type;
	private String chg_dt;
	private String fst_nam;
	private String loopingFlag;
	private String income_receipt_end_dt;
	private String uei_another_resp;
	private String end_ind;
	private String end_reason;
	private String state;
	private String county;
	private String services;
	private String value_of_services;
	private String dt_services_rcvd;
	private String comments;
	private String income_source;
	private String divorce_dt;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getCargoName() {
		return cargoName;
	}

	public void setCargoName(String cargoName) {
		this.cargoName = cargoName;
	}

	public String getRowAction() {
		return rowAction;
	}

	public void setRowAction(String rowAction) {
		this.rowAction = rowAction;
	}

	public String getAdaptRecordId() {
		return adaptRecordId;
	}

	public void setAdaptRecordId(String adaptRecordId) {
		this.adaptRecordId = adaptRecordId;
	}

	public String getDelete_reason_cd() {
		return delete_reason_cd;
	}

	public void setDelete_reason_cd(String delete_reason_cd) {
		this.delete_reason_cd = delete_reason_cd;
	}

	public String getApp_num() {
		return app_num;
	}

	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}

	public int getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public int getSeq_num() {
		return seq_num;
	}

	public void setSeq_num(int seq_num) {
		this.seq_num = seq_num;
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public String getEcp_id() {
		return ecp_id;
	}

	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}

	public String getChg_eff_dt() {
		return chg_eff_dt;
	}

	public void setChg_eff_dt(String chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}

	public int getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	public void setRec_cplt_ind(int rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	public double getUei_amt() {
		return uei_amt;
	}

	public void setUei_amt(double uei_amt) {
		this.uei_amt = uei_amt;
	}

	public String getUei_amt_ind() {
		return uei_amt_ind;
	}

	public void setUei_amt_ind(String uei_amt_ind) {
		this.uei_amt_ind = uei_amt_ind;
	}

	public String getUei_beg_dt() {
		return uei_beg_dt;
	}

	public void setUei_beg_dt(String uei_beg_dt) {
		this.uei_beg_dt = uei_beg_dt;
	}

	public String getUei_typ() {
		return uei_typ;
	}

	public void setUei_typ(String uei_typ) {
		this.uei_typ = uei_typ;
	}

	public String getRsdi_income_expected_sw() {
		return rsdi_income_expected_sw;
	}

	public void setRsdi_income_expected_sw(String rsdi_income_expected_sw) {
		this.rsdi_income_expected_sw = rsdi_income_expected_sw;
	}

	public String getOthr_incm_src() {
		return othr_incm_src;
	}

	public void setOthr_incm_src(String othr_incm_src) {
		this.othr_incm_src = othr_incm_src;
	}

	public String getExpected_to_cont_resp() {
		return expected_to_cont_resp;
	}

	public void setExpected_to_cont_resp(String expected_to_cont_resp) {
		this.expected_to_cont_resp = expected_to_cont_resp;
	}

	public String getUei_end_dt() {
		return uei_end_dt;
	}

	public void setUei_end_dt(String uei_end_dt) {
		this.uei_end_dt = uei_end_dt;
	}

	public String getLoopingQuestion() {
		return loopingQuestion;
	}

	public void setLoopingQuestion(String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}

	public String getMoney_providing_person_name() {
		return money_providing_person_name;
	}

	public void setMoney_providing_person_name(String money_providing_person_name) {
		this.money_providing_person_name = money_providing_person_name;
	}

	public String getMoney_direct_ind() {
		return money_direct_ind;
	}

	public void setMoney_direct_ind(String money_direct_ind) {
		this.money_direct_ind = money_direct_ind;
	}

	public String getLoan_ind() {
		return loan_ind;
	}

	public void setLoan_ind(String loan_ind) {
		this.loan_ind = loan_ind;
	}

	public String getMoney_pay_back_ind() {
		return money_pay_back_ind;
	}

	public void setMoney_pay_back_ind(String money_pay_back_ind) {
		this.money_pay_back_ind = money_pay_back_ind;
	}

	public String getFreq_cd() {
		return freq_cd;
	}

	public void setFreq_cd(String freq_cd) {
		this.freq_cd = freq_cd;
	}

	public String getUei_claim_num() {
		return uei_claim_num;
	}

	public void setUei_claim_num(String uei_claim_num) {
		this.uei_claim_num = uei_claim_num;
	}

	public String getUei_Sub_Type() {
		return uei_Sub_Type;
	}

	public void setUei_Sub_Type(String uei_Sub_Type) {
		this.uei_Sub_Type = uei_Sub_Type;
	}

	public String getChg_dt() {
		return chg_dt;
	}

	public void setChg_dt(String chg_dt) {
		this.chg_dt = chg_dt;
	}

	public String getFst_nam() {
		return fst_nam;
	}

	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}

	public String getLoopingFlag() {
		return loopingFlag;
	}

	public void setLoopingFlag(String loopingFlag) {
		this.loopingFlag = loopingFlag;
	}

	public String getIncome_receipt_end_dt() {
		return income_receipt_end_dt;
	}

	public void setIncome_receipt_end_dt(String income_receipt_end_dt) {
		this.income_receipt_end_dt = income_receipt_end_dt;
	}

	public String getUei_another_resp() {
		return uei_another_resp;
	}

	public void setUei_another_resp(String uei_another_resp) {
		this.uei_another_resp = uei_another_resp;
	}

	public String getEnd_ind() {
		return end_ind;
	}

	public void setEnd_ind(String end_ind) {
		this.end_ind = end_ind;
	}

	public String getEnd_reason() {
		return end_reason;
	}

	public void setEnd_reason(String end_reason) {
		this.end_reason = end_reason;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getServices() {
		return services;
	}

	public void setServices(String services) {
		this.services = services;
	}

	public String getValue_of_services() {
		return value_of_services;
	}

	public void setValue_of_services(String value_of_services) {
		this.value_of_services = value_of_services;
	}

	public String getDt_services_rcvd() {
		return dt_services_rcvd;
	}

	public void setDt_services_rcvd(String dt_services_rcvd) {
		this.dt_services_rcvd = dt_services_rcvd;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getIncome_source() {
		return income_source;
	}

	public void setIncome_source(String income_source) {
		this.income_source = income_source;
	}

	public String getDivorce_dt() {
		return divorce_dt;
	}

	public void setDivorce_dt(String divorce_dt) {
		this.divorce_dt = divorce_dt;
	}

}
