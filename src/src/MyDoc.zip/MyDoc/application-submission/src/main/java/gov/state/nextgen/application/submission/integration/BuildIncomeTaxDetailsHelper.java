package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import gov.state.nextgen.application.submission.framework.logging.FwLogger;
import gov.state.nextgen.application.submission.util.ApplicationUtil;
import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.AggregatedPayload;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.financial.expense.CP_APP_IN_INCOME_TAX_DED;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_IN_TAX_DEPENDENTS_Collection;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.profile.CP_APP_IN_TAX_RETURN_Collection;
import gov.state.nextgen.application.submission.view.payload.Expenses;
import gov.state.nextgen.application.submission.view.payload.TaxDependent;
import gov.state.nextgen.application.submission.view.payload.TaxHousehold;

public class BuildIncomeTaxDetailsHelper {
	
	private BuildIncomeTaxDetailsHelper() {}
	
	public static List<Expenses> buildIncomeTaxExpenses(AggregatedPayload source, int indvSeq) {//NOSONAR

		Expenses expense = null;
		List<Expenses> expenseList = new ArrayList<>();
		
		try {
			List<CP_APP_IN_INCOME_TAX_DED> taxExpenseList = source.getFinancialExpenseSummaryDetails().getPageCollection().getCP_APP_IN_INCOME_TAX_DED();
			if(taxExpenseList !=null && !taxExpenseList.isEmpty()) {
				for(CP_APP_IN_INCOME_TAX_DED taxExpense : taxExpenseList) {
					if(indvSeq == taxExpense.getIndv_seq_num()) {
						expense = new Expenses(); 
						List<String> typeCatList = BuildIncomeTypeMappingHelper.getExpenseCd(taxExpense.getExp_type());
						if(!typeCatList.isEmpty()) {
							expense.setCategoryCode(typeCatList.get(0));
							expense.setTypeCode(typeCatList.get(1));
						}
						String freqCd = taxExpense.getPay_freq();
						if(ApplicationSubmissionConstants.FRE_OT.equalsIgnoreCase(freqCd)) {
							expense.setFreqCode(ApplicationSubmissionConstants.FRE_II);
						} else {
							expense.setFreqCode(freqCd);
						}
						if(taxExpense.getDeductible_self_exp()!= null)
						{
							double expenseeAmt = Double.parseDouble(taxExpense.getDeductible_self_exp());
							expense.setDollarAmt(expenseeAmt);
						}
						expense.setOtherDollarAmount(0); 
						expense.setRecipientName(null); 
						expense.setDescription(null);
						expense.setCareProviderName(null); 
						expense.setCareProviderAddress(null);
						expense.setHsngExpnHelpInd(false); 
						expense.setHsngHlpFirstName(taxExpense.getFst_name());
						expense.setHsngHlpLastName(null); 
						expense.setHsngHlpAmt(0);
						expense.setHsngHlpFreq(null); 
						expense.setLiheapInd(false);
						expense.setWhoWillReimburse(null); 
						expense.setReimburseAmount(0);
						expense.setNameOfChildren(null); 
						expense.setTaxDeductibleAlimonyPmtInd(taxExpense.getAlimony_exp() != null);//NOSONAR
						expense.setOtherDeductableExpenseText(taxExpense.getExp_pay_desc()); 

						expenseList.add(expense); 
					}
				}
			}
		} catch (Exception e) {
			FwLogger.log(BuildIncomeTaxDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while loading Tax Deduction Expense Details - " + e.getMessage());
		}
		return expenseList;
	}
	
	public static List<TaxHousehold> getTaxDetails(AggregatedPayload source, int indvSeq) {//NOSONAR
		TaxHousehold taxHouseHold = null;
		List<TaxHousehold> taxHouseholdList = new ArrayList<>();
		List<CP_APP_IN_TAX_RETURN_Collection> indvsTaxList =  null;
		List<CP_APP_IN_TAX_DEPENDENTS_Collection> indvsTaxDepList =  null;
		List<TaxDependent> taxDependents = new ArrayList<>(); 
		TaxDependent taxDep = null;
		
		try {
			indvsTaxList = source.getHouseholdDemographicsProfileDetails().getPageCollection().getCP_APP_IN_TAX_RETURN_Collection();
			indvsTaxDepList = source.getHouseholdDemographicsPersonDetails().getPageCollection().getCP_APP_IN_TAX_DEPENDENTS_Collection();
			
			if(indvsTaxList != null && !indvsTaxList.isEmpty()) {
				for(CP_APP_IN_TAX_RETURN_Collection hhTax : indvsTaxList) {	
					if(indvSeq == hhTax.getIndv_seq_num()) {
						taxHouseHold = new TaxHousehold();
						if(hhTax.getSpouse_indv_id() >0)
							taxHouseHold.setSpousePersId(String.valueOf(ApplicationUtil.getBenefitsCalIndividualIdValue(hhTax.getSpouse_indv_id()))); 
						taxHouseHold.setSpouseFirstName(hhTax.getSpouse_first_name());
						taxHouseHold.setSpouseMiddleName(hhTax.getSpouse_mid_nam());
						taxHouseHold.setSpouseLastName(hhTax.getSpouse_last_name()); 
						taxHouseHold.setAutoEnrollNumYears(hhTax.getYears());	
						taxHouseHold.setExpectFileInd(ApplicationUtil.translateBoolean(hhTax.getTax_auto_enrl_ind()));//NOSONAR
						taxHouseHold.setPrimaryTaxFilerInd(ApplicationSubmissionConstants.STR_Y.equalsIgnoreCase(hhTax.getPrimary_filer_sw())?true:false);//NOSONAR 

						if(indvsTaxDepList != null && !indvsTaxDepList.isEmpty()) {
							List<CP_APP_IN_TAX_DEPENDENTS_Collection> taxDepList = indvsTaxDepList.stream().filter(indvTax->hhTax.getIndv_seq_num() == indvTax.getIndv_seq_num()).collect(Collectors.toList());

							for(CP_APP_IN_TAX_DEPENDENTS_Collection hhTaxDep : taxDepList) {
								taxDep = new TaxDependent(); 
								taxDep.setPersId(ApplicationUtil.getBenefitsCalIndividualIdValue(hhTaxDep.getDependent_indv_seq_num()));
								taxDep.setType("DP");
								taxDep.setDependentFirstName(hhTaxDep.getFirst_name());
								taxDep.setDependentlastName(hhTaxDep.getLast_name());
								taxDependents.add(taxDep);
							}	
						}
						taxHouseHold.setTaxDependents(taxDependents); 
						taxHouseholdList.add(taxHouseHold);
					}
				}	
			}
		} catch (Exception e) {
			FwLogger.log(BuildIncomeTaxDetailsHelper.class,
					FwLogger.Level.INFO,
					"Exception while loading Tax Details - " + e.getMessage());
		}
		return taxHouseholdList;		
	}

}
