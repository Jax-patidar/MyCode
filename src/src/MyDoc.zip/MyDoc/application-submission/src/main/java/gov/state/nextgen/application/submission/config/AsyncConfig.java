package gov.state.nextgen.application.submission.config;

import java.util.concurrent.Executor;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class AsyncConfig {

	ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
	
	 @Bean
	  public Executor taskExecutor() {
	    executor.setCorePoolSize(6);
	    executor.setMaxPoolSize(8);
	    executor.setQueueCapacity(500);
	    executor.setThreadNamePrefix("app-sub-");
	    executor.initialize();
	    return executor;
	  }
}
