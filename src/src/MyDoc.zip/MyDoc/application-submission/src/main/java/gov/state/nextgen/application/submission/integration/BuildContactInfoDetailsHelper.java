package gov.state.nextgen.application.submission.integration;

import java.util.ArrayList;
import java.util.List;

import gov.state.nextgen.application.submission.constants.ApplicationSubmissionConstants;
import gov.state.nextgen.application.submission.view.intermediaryaggregator.household.person.CP_APP_RGST_Collection;
import gov.state.nextgen.application.submission.view.payload.PhoneNumber;

public class BuildContactInfoDetailsHelper {
	
	private BuildContactInfoDetailsHelper() {}
	
	public static List<PhoneNumber> buildPhoneNumber(CP_APP_RGST_Collection rgstInfo) {
	
		List<PhoneNumber> phNums = new ArrayList<>();
		
		if(rgstInfo !=null && rgstInfo.getHshl_cell_phn_num()!=null && !rgstInfo.getHshl_cell_phn_num().isEmpty()) {
			PhoneNumber phNumber = new PhoneNumber();
			phNumber.setNumber(rgstInfo.getHshl_cell_phn_num());
			phNumber.setType(ApplicationSubmissionConstants.STR_CE);
			phNums.add(phNumber);
		}
		
		if(rgstInfo !=null && rgstInfo.getHshl_home_phn_num()!=null && !rgstInfo.getHshl_home_phn_num().isEmpty()) {
			PhoneNumber phNumber = new PhoneNumber();
			phNumber.setNumber(rgstInfo.getHshl_home_phn_num());
			phNumber.setType(ApplicationSubmissionConstants.STR_HO);
			phNums.add(phNumber);
		}
		
		if(rgstInfo !=null && rgstInfo.getHshl_work_phn_num()!=null && !rgstInfo.getHshl_work_phn_num().isEmpty()) {
			PhoneNumber phNumber = new PhoneNumber();
			phNumber.setNumber(rgstInfo.getHshl_work_phn_num());
			phNumber.setType(ApplicationSubmissionConstants.STR_WK);
			phNums.add(phNumber);
		}
		
		return phNums;
	}

}
