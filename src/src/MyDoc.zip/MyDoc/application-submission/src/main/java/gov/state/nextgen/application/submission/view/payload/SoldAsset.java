package gov.state.nextgen.application.submission.view.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_EMPTY )
public class SoldAsset {

	private String sellDate;
	private String itemDescr;
	private double assetVal;
	private double sellVal;
	private String tradeOrGiveExplainText;

	public String getSellDate() {
		return sellDate;
	}

	public void setSellDate(String sellDate) {
		this.sellDate = sellDate;
	}

	public String getItemDescr() {
		return itemDescr;
	}

	public void setItemDescr(String itemDescr) {
		this.itemDescr = itemDescr;
	}

	public double getAssetVal() {
		return assetVal;
	}

	public void setAssetVal(double assetVal) {
		this.assetVal = assetVal;
	}

	public double getSellVal() {
		return sellVal;
	}

	public void setSellVal(double sellVal) {
		this.sellVal = sellVal;
	}

	public String getTradeOrGiveExplainText() {
		return tradeOrGiveExplainText;
	}

	public void setTradeOrGiveExplainText(String tradeOrGiveExplainText) {
		this.tradeOrGiveExplainText = tradeOrGiveExplainText;
	}
}
