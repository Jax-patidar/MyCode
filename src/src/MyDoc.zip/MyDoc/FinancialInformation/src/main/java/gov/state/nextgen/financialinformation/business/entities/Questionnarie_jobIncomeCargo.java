package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class Questionnarie_jobIncomeCargo extends AbstractCargo{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String earnedIncome;
	private String unearnedIncome;
	private String unearnedIncomeA;
	private String unearnedIncomeB;
	private String incomeInKind;
	private String incomeInKindA;
	/**
	 * @return the earnedIncome
	 */
	public String getEarnedIncome() {
		return earnedIncome;
	}
	/**
	 * @param earnedIncome the earnedIncome to set
	 */
	public void setEarnedIncome(String earnedIncome) {
		this.earnedIncome = earnedIncome;
	}
	/**
	 * @return the unearnedIncome
	 */
	public String getUnearnedIncome() {
		return unearnedIncome;
	}
	/**
	 * @param unearnedIncome the unearnedIncome to set
	 */
	public void setUnearnedIncome(String unearnedIncome) {
		this.unearnedIncome = unearnedIncome;
	}
	/**
	 * @return the unearnedIncomeA
	 */
	public String getUnearnedIncomeA() {
		return unearnedIncomeA;
	}
	/**
	 * @param unearnedIncomeA the unearnedIncomeA to set
	 */
	public void setUnearnedIncomeA(String unearnedIncomeA) {
		this.unearnedIncomeA = unearnedIncomeA;
	}
	/**
	 * @return the unearnedIncomeB
	 */
	public String getUnearnedIncomeB() {
		return unearnedIncomeB;
	}
	/**
	 * @param unearnedIncomeB the unearnedIncomeB to set
	 */
	public void setUnearnedIncomeB(String unearnedIncomeB) {
		this.unearnedIncomeB = unearnedIncomeB;
	}
	/**
	 * @return the incomeInKind
	 */
	public String getIncomeInKind() {
		return incomeInKind;
	}
	/**
	 * @param incomeInKind the incomeInKind to set
	 */
	public void setIncomeInKind(String incomeInKind) {
		this.incomeInKind = incomeInKind;
	}
	/**
	 * @return the incomeInKindA
	 */
	public String getIncomeInKindA() {
		return incomeInKindA;
	}
	/**
	 * @param incomeInKindA the incomeInKindA to set
	 */
	public void setIncomeInKindA(String incomeInKindA) {
		this.incomeInKindA = incomeInKindA;
	}

}
