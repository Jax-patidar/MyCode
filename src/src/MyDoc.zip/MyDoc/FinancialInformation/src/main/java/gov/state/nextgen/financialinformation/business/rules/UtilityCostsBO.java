/*
 * 
 */
package gov.state.nextgen.financialinformation.business.rules;




import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UTILC_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UTILC_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppInJntOwnRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInUtilcRepository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * UtilityCostsBO - Business Object skeleton auto generated - Architecture Team
 *
 * Creation Date :Mon Feb 05 19:01:10 CST 2007 Modified By: Modified on:
 */
@Service("UtilityCostsBO")
public class UtilityCostsBO extends AbstractBO {

	
	private AppInUtilcRepository appInUtilcRepository;
	
	@Autowired
	private AppInJntOwnRepository appInJntOwnRepository;
	
	/**
	 * Constructor
	 */

	/**
	 * Method description here
	 */
	public void insertExistingUtilityDetails(final APP_IN_UTILC_Collection appInUtilityBillColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.insertExistingUtilityDetails- START");
		try {
			if (null!=appInUtilityBillColl && !appInUtilityBillColl.isEmpty()) {
				appInUtilcRepository.saveAll(appInUtilityBillColl);
			}
			
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.insertExistingUtilityDetails - END , Time Taken : " + (System.currentTimeMillis() - startTime)
				);
	}

	public int getMaxUtilitySeqNumber(final String aAppNum, final Integer indvSeqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.getMaxUtilitySeqNumber- START");

		int maxSeqNum = 0;
		try {

			final List res = appInUtilcRepository.getMaxUtilitySeqNumber(aAppNum, indvSeqNum);
			
			final Map temp = res!=null? (Map) res.get(0):null;
			if (null!=temp && temp.get("MAX_SEQ_NUM") != null) {
				maxSeqNum = Integer.parseInt((String) temp.get("MAX_SEQ_NUM"));
			}
			FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.getMaxUtilitySeqNumber - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
			return maxSeqNum;
		} catch (final Exception e) {
			throw e;
		}

	}

	public void storeUtilityDetails(final APP_IN_UTILC_Collection appInUtilColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.storeUtilityDetails- START");
		try {
			if (null!=appInUtilColl && !appInUtilColl.isEmpty()) {
				appInUtilcRepository.saveAll(appInUtilColl);
			}

		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.storeUtilityDetails - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
	}

	public APP_IN_UTILC_Cargo splitUtilityColl(final APP_IN_UTILC_Collection utilityColl, final String recordIndicator) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.splitUtilityColl- START");
		try {
			if ((utilityColl != null) && (!utilityColl.isEmpty())) {
				final int utilityCollSize = utilityColl.size();
				APP_IN_UTILC_Cargo utilityCargo = null;
				for (int i = 0; i < utilityCollSize; i++) {
					utilityCargo = utilityColl.getCargo(i);
					if (utilityCargo.getSrc_app_ind().equals(recordIndicator)) {
						FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.splitUtilityColl - END , Time Taken : " + (System.currentTimeMillis() - startTime)
								);
						return utilityColl.getCargo(i);
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.splitUtilityColl - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
			return null;
		} catch (final Exception e) {
			throw e;
		}

	}

	public APP_IN_UTILC_Cargo settingUtilityDefaultValues(final APP_IN_UTILC_Cargo utilityCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.settingUtilityDefaultValues- START");
		try {
			if (utilityCargo != null && utilityCargo.getMo_oblg_amt() == null) {
				
					utilityCargo.setMo_oblg_amt(0.00);
				

			}
			FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.settingUtilityDefaultValues - END , Time Taken : " + (System.currentTimeMillis() - startTime)
					);
			return utilityCargo;
		} catch (final Exception e) {
			throw e;
		}
	}

	

	public boolean isDifferentUtilityBill(final APP_IN_UTILC_Cargo newUtilityCargo, final APP_IN_UTILC_Cargo aUtilityCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.isDifferentUtilityBill- START");
		boolean flag = false;
		try {
			if (!((aUtilityCargo.getIndv_seq_num() == null) && (newUtilityCargo.getIndv_seq_num() == null))
					&& !((aUtilityCargo.getIndv_seq_num() != null) && aUtilityCargo.getIndv_seq_num().equals(newUtilityCargo.getIndv_seq_num()))) {
				flag = true;
			}
			if (!flag && !((aUtilityCargo.getSeq_num() == null) && (newUtilityCargo.getSeq_num() == null))
					&& !((aUtilityCargo.getSeq_num() != null) && aUtilityCargo.getSeq_num().equals(newUtilityCargo.getSeq_num()))) {
				flag = true;
			}
			if (!flag && !((aUtilityCargo.getUtil_typ() == null) && (newUtilityCargo.getUtil_typ() == null))
					&& !((aUtilityCargo.getUtil_typ() != null) && aUtilityCargo.getUtil_typ().equals(newUtilityCargo.getUtil_typ()))) {
				flag = true;
			}
			FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.isDifferentUtilityBill - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
			return flag;
		} catch (final Exception e) {
			throw e;
		}
	}


	
	/**
	 * compares the given cargo with this cargo and returns the changed
	 * attribute-value Map.
	 */
	public boolean isDifferentUtility(final APP_IN_UTILC_Cargo newCargo, final APP_IN_UTILC_Cargo aCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.isDifferentUtility- START");
		boolean flag = false;
		try {
		if (!((aCargo.getIndv_seq_num() == null) && (newCargo.getIndv_seq_num() == null))
				&& !((aCargo.getIndv_seq_num() != null) && aCargo.getIndv_seq_num().equals(newCargo.getIndv_seq_num()))) {
			flag = true;
		}
		if (!flag && !((aCargo.getSeq_num() == null) && (newCargo.getSeq_num() == null))
				&& !((aCargo.getSeq_num() != null) && aCargo.getSeq_num().equals(newCargo.getSeq_num()))) {
			flag = true;
		}
		if (!flag && !((aCargo.getUtil_typ() == null) && (newCargo.getUtil_typ() == null))
				&& !((aCargo.getUtil_typ() != null) && aCargo.getUtil_typ().equals(newCargo.getUtil_typ()))) {
			flag = true;
		}
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.isDifferentUtility - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
		return flag;
		} catch (final Exception e) {
			throw e;
		}
	}

	


	/**
	 * Method description here
	 */
	public void storeJointOwnerDetails(final APP_IN_JNT_OWN_Collection appInJntColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.storeJointOwnerDetails- START");
		try {
			if ((appInJntColl != null) && (!appInJntColl.isEmpty())) {
				int size = appInJntColl.size();
				APP_IN_JNT_OWN_Cargo appInJntOwnCargo = null;
				final APP_IN_JNT_OWN_Collection deleteColl = new APP_IN_JNT_OWN_Collection();
				for (int i = 0; i < size; i++) {
					appInJntOwnCargo = appInJntColl.getCargo(i);
					if (FwConstants.ROWACTION_DELETE.equals(appInJntOwnCargo.getRowAction())) {
						deleteColl.addCargo(appInJntOwnCargo);
						appInJntColl.remove(i);
						i--;
						size--;
					}
				}
				if (!deleteColl.isEmpty()) {
					appInJntOwnRepository.saveAll(deleteColl);
				}
				
				if (!appInJntColl.isEmpty()) {
					appInJntOwnRepository.saveAll(appInJntColl);
				}
			}
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.storeJointOwnerDetails - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
	}

	public APP_IN_UTILC_Collection getNonCWUtilityColl(final APP_IN_UTILC_Collection utilityDetails) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHousingBillsBO.splitHousingCollection- START");
		try {
			final APP_IN_UTILC_Collection updatedColl = new APP_IN_UTILC_Collection();
			if ((utilityDetails != null) && (!utilityDetails.isEmpty())) {
				final int vehAstCollSize = utilityDetails.size();
				APP_IN_UTILC_Cargo vehAstCargo = null;
				for (int i = 0; i < vehAstCollSize; i++) {
					vehAstCargo = utilityDetails.getCargo(i);
					if (!"CW".equals(vehAstCargo.getSrc_app_ind())) {
						updatedColl.add(vehAstCargo);

					}
				}
				FwLogger.log(this.getClass(), Level.INFO, "ABHousingBillsBO.getNonCWCargoes- START - END , Time Taken : " + (System.currentTimeMillis() - startTime)
						);
				return updatedColl;
			}
			return null;
		} catch (final Exception e) {
			throw e;
		}

	}
	
	public APP_IN_UTILC_Collection loadUtilityBillDetails(final String appNumber, final Integer indvSeqNum, final Integer seqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.loadUtilityBillDetails- START");
		try {
			final APP_IN_UTILC_Collection appInUtilityIndvSelColl = appInUtilcRepository.loadUtilityBillDetails(appNumber, indvSeqNum, seqNum);
			FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.loadUtilityBillDetails - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
			return appInUtilityIndvSelColl;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public APP_IN_JNT_OWN_Collection loadJointOwnerDetails(final String appNumber, final Integer indvSeqNum, final String type, final String subType,
			final Integer seqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.loadJointOwnerDetails- START");
		try {
			final APP_IN_JNT_OWN_Collection appInHouseIndvSelColl = appInJntOwnRepository.loadIndividualJointOwnerDetails(Integer.parseInt(appNumber), indvSeqNum, type, subType, seqNum);
			FwLogger.log(this.getClass(), Level.INFO, "UtilityCostsBO.loadJointOwnerDetails - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
			return appInHouseIndvSelColl;
		} catch (final Exception e) {
			throw e;
		}
	}

}
