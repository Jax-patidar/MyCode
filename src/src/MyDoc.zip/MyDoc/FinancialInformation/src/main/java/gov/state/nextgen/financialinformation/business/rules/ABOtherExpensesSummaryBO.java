package gov.state.nextgen.financialinformation.business.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.access.management.references.ReferenceTableManager;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInPrflRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInMedBillsRepository;



@Service(value="ABOtherExpensesSummaryBO")
public class ABOtherExpensesSummaryBO extends AbstractBO {
	@Autowired
	CpAppInMedBillsRepository cpAppInMedBillsRepository;
	
	AppInPrflRepository appInPrflRepo;
	
	@Autowired
	private IReferenceTableManager iref;
	/**
	 * Constructor
	 */
	/* Get Medical Bills details */
	public CP_APP_IN_MED_BILLS_Collection getMedicalExpenseDetail(
			final String appNum, final int indvSeqNum, final int seqNum,
			final String type) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesSummaryBO.getMedicalBillsDetails():START");

		try {
			
			CP_APP_IN_MED_BILLS_Collection helpColl ;

			helpColl = cpAppInMedBillsRepository.getAllDetails(Integer.parseInt(appNum),indvSeqNum,seqNum,type);

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherExpensesSummaryBO.getMedicalBillsDetails() - END, Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ " milliseconds"); 
		return helpColl;
		}
		catch (final Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
			throw e;
		}
	}
	
	public CP_APP_IN_MED_BILLS_Collection loadDetails(String appNum) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherExpensesSummaryBO.loadDetails() - START");
		try {
			CP_APP_IN_MED_BILLS_Collection appPgmRequestColl = new CP_APP_IN_MED_BILLS_Collection();
			if(appNum != null) {
				appPgmRequestColl = cpAppInMedBillsRepository.getDetails(Integer.parseInt(appNum));
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABOtherExpensesSummaryBO.loadAllDetails() - END");
			return appPgmRequestColl;

		}catch (final Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
			throw e;
		}
	}
	public CP_APP_IN_MED_BILLS_Collection getMedDetailsByyMedBillType(String appNum, int seqNum, 
			String billType) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherExpensesSummaryBO.getMedDetailsByyMedBillType() - START");
		try {
			CP_APP_IN_MED_BILLS_Collection appPgmRequestColl = new CP_APP_IN_MED_BILLS_Collection();
			if(null == billType) {
				billType="DA";//// Setting columns values to default bcz which should not be null
			}
			if(appNum != null) {
				appPgmRequestColl = cpAppInMedBillsRepository.getMedDetailsByyMedBillType(Integer.parseInt(appNum),seqNum,billType);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABOtherExpensesSummaryBO.getMedDetailsByyMedBillType() - END");
			return appPgmRequestColl;

		}catch (final Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
			throw e;
		}
	}
	
	/* Validating validateMedicalBillDetails */

	public FwMessageList validateMedicalBillDetails(final Double pymntAmnt,
			final String payFreq, final String type, final String langCD,
			final String firstName) {
		
		FwMessageList messageList = new FwMessageList();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherExpensesSummaryBO.validateMedicalBillDetails() - START");
		final String typeDesc = iref.getColumnValue("MDTY", 2834, type, langCD);
		final String[] typeAndUser = new String[] { typeDesc, firstName };
		final String[] userandType = new String[] { firstName, typeDesc };
		try {

			if (pymntAmnt == null || "".equals(pymntAmnt.toString().trim())) {
				this.addMessageWithFieldValues(FinancialInfoConstants.AMT_MSG_CD, typeAndUser);
			} 
			else if (!appMgr.isValidAmountLimit(pymntAmnt.toString())) {
				messageList.addMessageToList(addMessageCode(FinancialInfoConstants.MSG_10034));
			}  
			if (payFreq == null || FinancialInfoConstants.DEF_SEL_VALUE.equals(payFreq)) {
				this.addMessageWithFieldValues(FinancialInfoConstants.FREQ_MSG_CD, userandType);
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherExpensesSummaryBO.validateMedicalBillDetails() - END");
		return messageList;
	}
	
	public CP_APP_IN_MED_BILLS_Collection storeMedicalExpenseDetails(
			final CP_APP_IN_MED_BILLS_Collection appInColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherExpensesSummaryBO.storeMedicalExpenseDetails() - START");
		try {
			if (null!=appInColl && !appInColl.isEmpty()) {
				CP_APP_IN_MED_BILLS_Cargo cargo;
				cargo = appInColl.getCargo(0);
				cpAppInMedBillsRepository.save(cargo);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABOtherExpensesSummaryBO.storeMedicalExpenseDetails() - END");
			return appInColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
			throw e;
		}
	}
	
	public void deleteMedBillsCargo(CP_APP_IN_MED_BILLS_Cargo existingCargo) {
		FwLogger.log(this.getClass(), Level.INFO,"ABOtherExpensesSummaryBO.deleteMedBillsCargo) - START");

		try {
			cpAppInMedBillsRepository.delete(existingCargo);
		}
		catch (final Exception e) {
				FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
				throw e;
			}
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesSummaryBO.deleteMedBillsCargo() - END");
	}
	
}
