package gov.state.nextgen.financialinformation.business.entities;

import java.rmi.RemoteException;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class CP_ASSETS_DISASTER_Collection extends AbstractCollection{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6133155588838935539L;
	
	private static final String PACKAGE = "gov.state.nextgen.financialinformation.business.entities.CP_ASSETS_DISASTER";

	@Override
	public void setGenericResults(Object obj) throws RemoteException {
		if (obj instanceof CP_ASSETS_DISASTER_Cargo[]) {
			final CP_ASSETS_DISASTER_Cargo[] cbArray = (CP_ASSETS_DISASTER_Cargo[]) obj;
			setResults(cbArray);
		}
		
	}

	/**
	 * Sets cargo array into collection.
	 */
	private void setResults(CP_ASSETS_DISASTER_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}
	
	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CP_ASSETS_DISASTER_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CP_ASSETS_DISASTER_Cargo aCargo) {
		set(idx, aCargo);
	}
	
	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CP_ASSETS_DISASTER_Cargo[] getResults() {
		final CP_ASSETS_DISASTER_Cargo[] cbArray = new CP_ASSETS_DISASTER_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}
	
	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CP_ASSETS_DISASTER_Cargo getCargo(final int idx) {
		return (CP_ASSETS_DISASTER_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public CP_ASSETS_DISASTER_Cargo[] cloneResults() {
		final CP_ASSETS_DISASTER_Cargo[] rescargo = new CP_ASSETS_DISASTER_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_ASSETS_DISASTER_Cargo cargo = getCargo(i);
			rescargo[i] = new CP_ASSETS_DISASTER_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setCash_in_hand_amt(cargo.getCash_in_hand_amt());
			rescargo[i].setChecking_account_amt(cargo.getChecking_account_amt());
			rescargo[i].setSaving_account_amt(cargo.getChecking_account_amt());
			rescargo[i].setOther_amt(cargo.getOther_amt());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
		}
		return rescargo;
	}
}
