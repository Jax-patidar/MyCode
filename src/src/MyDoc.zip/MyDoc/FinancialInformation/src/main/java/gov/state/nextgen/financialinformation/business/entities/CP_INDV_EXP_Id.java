/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CP_INDV_EXP_Id implements Serializable {

	private static final long serialVersionUID = -1184867010602687081L;
	
	private Integer hshl_id;
	private Integer indv_id;
	private String exp_type;
	

	public CP_INDV_EXP_Id() {
		super();
	}

	public CP_INDV_EXP_Id(Integer hshl_id, Integer indv_id, String exp_type) {
		super();
		this.hshl_id = hshl_id;
		this.indv_id = indv_id;
		this.exp_type = exp_type;
	}

	
	/**
	 * @return the hshl_id
	 */
	public Integer getHshl_id() {
		return hshl_id;
	}

	/**
	 * @param hshl_id the hshl_id to set
	 */
	public void setHshl_id(Integer hshl_id) {
		this.hshl_id = hshl_id;
	}
	
	

	/**
	 * @return the indv_id
	 */
	public Integer getIndv_id() {
		return indv_id;
	}

	/**
	 * @param indv_id the indv_id to set
	 */
	public void setIndv_id(Integer indv_id) {
		this.indv_id = indv_id;
	}

	/**
	 * @return the exp_type
	 */
	public String getExp_type() {
		return exp_type;
	}

	/**
	 * @param exp_type the exp_type to set
	 */
	public void setExp_type(String exp_type) {
		this.exp_type = exp_type;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((exp_type == null) ? 0 : exp_type.hashCode());
		result = prime * result + ((hshl_id == null) ? 0 : hshl_id.hashCode());
		result = prime * result + ((indv_id == null) ? 0 : indv_id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CP_INDV_EXP_Id other = (CP_INDV_EXP_Id) obj;
		if (exp_type == null) {
			if (other.exp_type != null)
				return false;
		} else if (!exp_type.equals(other.exp_type))
			return false;
		if (hshl_id == null) {
			if (other.hshl_id != null)
				return false;
		} else if (!hshl_id.equals(other.hshl_id))
			return false;
		if (indv_id == null) {
			if (other.indv_id != null)
				return false;
		} else if (!indv_id.equals(other.indv_id))
			return false;
		return true;
	}



}
