package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_DC_E_LIST_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.rules.ABEmploymentBO;
import gov.state.nextgen.financialinformation.business.rules.ABJobIncomeBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherExpensesQuestionsBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherExpensesSummaryBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherIncomeBO;
import gov.state.nextgen.financialinformation.business.rules.CareCostBO;
import gov.state.nextgen.financialinformation.business.rules.ExpenseSummaryBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.framework.business.model.UserDetails;


/**
 * CF37 Financial Service
 * 
 * @author Syed Khadarvali
 *
 */

@Service("CF37FinancialInformationDetailsService")
public class CF37FinancialInformationDetailsServiceImpl implements FinancialServInterface{
    @Autowired
	ExpenseSummaryBO  expenseSummaryBO;
    
    @Autowired
	private ABJobIncomeBO abJobIncomeBO;
    
    @Autowired
    private ABEmploymentBO abEmploymentBO;
    
    @Autowired
    private ABOtherIncomeBO abOtherIncomeBO;
    
    @Autowired
    ABOtherExpensesQuestionsBO abOtherExpensesQuestionsBO;
    
    @Autowired
    CareCostBO careCostBO; 
    
    @Autowired
    ABOtherExpensesSummaryBO abOtherExpensesSummaryBO;
    
    private static final String INDV_ID = "indvIds";
    
	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {

		switch (methodName) {
		case FinancialInfoConstants.GETCF37FINANCIALINFORMATIONDETAILS:
			this.getCF37FinancialInformationDetails(txnBean);
			break;
		default:
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"No Service called");
		}
	}
	
	public void getCF37FinancialInformationDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CF37FinancialInformationDetailsServiceImpl.getCF37FinancialInformationDetails() - START", fwTxn);
		final Map<String,Object> pageCollection = fwTxn.getPageCollection();
		UserDetails userDetails = fwTxn.getUserDetails();
		String appNumber = userDetails.getAppNumber();
		
		try {		
			ExpenseSummaryServiceImpl obj = new ExpenseSummaryServiceImpl();
			List<String> indvIdList = new ArrayList<String>();
			APP_INDV_Collection appIndvCollection=obj.getIndvList(fwTxn);
			if(appIndvCollection != null && !appIndvCollection.isEmpty() && appIndvCollection.size() > 0) {
				for (int i = 0; i < appIndvCollection.size(); i++) {
					APP_INDV_Cargo appIndvCargo1 = (APP_INDV_Cargo) appIndvCollection.get(i);
					FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CF37FinancialInformationDetailsServiceImpl.getCF37FinancialInformationDetails() end - Move Out="+appIndvCargo1.getMove_out_ind());
					FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CF37FinancialInformationDetailsServiceImpl.getCF37FinancialInformationDetails() end - Passed Away="+appIndvCargo1.getDeceased_ind());
					if((appIndvCargo1.getMove_out_ind()==null ||  !"Y".equals(appIndvCargo1.getMove_out_ind())) && (appIndvCargo1.getDeceased_ind()==null || !"Y".equals(appIndvCargo1.getDeceased_ind()))) {
					indvIdList.add(appIndvCargo1.getIndv_seq_num().toString());
					}
				}	
				pageCollection.put(INDV_ID, indvIdList);
			}
			
			APP_IN_SELFE_Collection  appInSelfCollection=abJobIncomeBO.getSelfEmploymentDetails(appNumber);
			pageCollection.put(FinancialInfoConstants.APP_IN_SELFE_COLL, appInSelfCollection);
			
			APP_IN_EMPL_Collection   appInEmplCollection=abEmploymentBO.getEmploymentDetailsByAppNum(appNumber);
			pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_COLL, appInEmplCollection);
			
			APP_IN_UEI_Collection   appInUeiCollection=abOtherIncomeBO.loadOtherIncomesDetail(appNumber);
			pageCollection.put(FinancialInfoConstants.APP_IN_UEI_COLL, appInUeiCollection);
			
			APP_IN_HOU_BILLS_Collection appInHouBillsCollection = expenseSummaryBO.getHouseBillsCollection(appNumber);
			pageCollection.put(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION, appInHouBillsCollection);
			
			CP_APP_IN_DEDUCTION_Collection   cpAppInDeductionCollection=abOtherExpensesQuestionsBO.getAppInDeductionDetails(appNumber);
			pageCollection.put(FinancialInfoConstants.CP_APP_IN_DEDUCTION_COLLECTION, cpAppInDeductionCollection);
			
			CP_ABCHS_Collection  cpAbchsCollection=careCostBO.loadCareCostDetails(appNumber);
			pageCollection.put(FinancialInfoConstants.CP_ABCHS_COLLECTION, cpAbchsCollection);
			
			CP_APP_IN_MED_BILLS_Collection   cpAppInMedBillsCollection=abOtherExpensesSummaryBO.loadDetails(appNumber);
			pageCollection.put(FinancialInfoConstants.CP_APP_IN_MED_BILLS_COLLECTION, cpAppInMedBillsCollection);	
			
			APP_IN_DC_E_LIST_Collection   appInDcEListCollection=careCostBO.fetchDependentCareList(appNumber);
			pageCollection.put(FinancialInfoConstants.DEPENDENT_LIST_COLLECTION, appInDcEListCollection);	
			
			
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in CF37FinancialInformationDetailsServiceImpl.getCF37FinancialInformationDetails()", fwTxn);
			pageCollection.put(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION, null);
			pageCollection.put(FinancialInfoConstants.APP_IN_SELFE_COLL, null);
			pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_COLL, null);
			pageCollection.put(FinancialInfoConstants.APP_IN_UEI_COLL, null);
			pageCollection.put(FinancialInfoConstants.CP_ABCHS_COLLECTION, null);
			pageCollection.put(FinancialInfoConstants.CP_APP_IN_MED_BILLS_COLLECTION, null);
			pageCollection.put(FinancialInfoConstants.CP_APP_IN_DEDUCTION_COLLECTION, null);
			pageCollection.put(FinancialInfoConstants.DEPENDENT_LIST_COLLECTION, null);
			FwExceptionManager.handleException(e,this.getClass().getName(),
					FinancialInfoConstants.GETCF37FINANCIALINFORMATIONDETAILS, fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);

		}

		fwTxn.setPageCollection(pageCollection);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CF37FinancialInformationDetailsServiceImpl.getCF37FinancialInformationDetails() - END", fwTxn);		
 
	}
}	
