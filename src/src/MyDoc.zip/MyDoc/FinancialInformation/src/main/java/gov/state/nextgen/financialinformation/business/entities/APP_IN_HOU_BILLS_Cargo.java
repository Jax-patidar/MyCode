/**
 *
 */
package gov.state.nextgen.financialinformation.business.entities;



import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;


@Entity
@IdClass(APP_IN_HOU_BILLS_Id.class)
@Table(name = "CP_APP_IN_HOU_BILLS")
public class APP_IN_HOU_BILLS_Cargo extends AbstractCargo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Transient
	private String app_num;
	@Id
	@Column(name = "app_num")
	private int app_number;
	@Id
	private Integer seq_num;
	@Id
	private int indv_seq_num;
	
	private String src_app_ind;
	@Id
	private String bill_type;
	private Double pymt_amt ;
	private String pymt_freq ;
	private String jnt_pay_resp ;
	
	private Integer rec_cplt_ind ;
	private Double paid_amt ;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date end_dt;
	@Transient
	private int ecp_id ;
	@Transient
	private String propAddrZip4;
	@Transient
	private String bill;
	
	@Column(name = "bill_type_desc")
	private String billTypeDesc;
	
	public String getBill() {
		return bill;
	}
	public void setBill(String bill) {
		this.bill = bill;
	}
	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="change_dt")
	private Date chg_dt;
	
	@Transient
	private String loopingQuestion ;
	@Transient
	private String property_name ;
	@Transient
	private String prop_addr_l1 ;
	@Transient
	private String prop_addr_l2 ;
	@Transient
	private String prop_addr_city ;
	@Transient
	private String prop_addr_state_cd ;
	@Transient
	private String prop_addr_zip ;
	@Transient
	private String prop_phone_num ;
	
	private String jnt_payee_first_name;
	private String jnt_payee_last_name;
	private String jnt_pymt_freq;
	private String liheap_resp;
	
	
	private String pr_select ;
    @Transient
    private String utilities_pr_select ;
	@Transient
	private Double pr_pymnt_amt;
	
	@Column(name = "hou_bills_calsaws_object")
	private String houBillsCalsawsObject;
	
    public String getUtilities_pr_select() {
		return utilities_pr_select;
	}
	public void setUtilities_pr_select(String utilities_pr_select) {
		this.utilities_pr_select = utilities_pr_select;
	}
	public String getPr_select() {
		return pr_select;
	}
	public void setPr_select(String pr_select) {
		this.pr_select = pr_select;
	}
	public Double getPr_pymnt_amt() {
		return pr_pymnt_amt;
	}
	public void setPr_pymnt_amt(Double pr_pymnt_amt) {
		this.pr_pymnt_amt = pr_pymnt_amt;
	}
@Transient
	private String expense_trash;
	public String getExpense_trash() {
		return expense_trash;
	}
	public void setExpense_trash(String expense_trash) {
		this.expense_trash = expense_trash;
	}
	public String getExpense_heating() {
		return expense_heating;
	}
	public void setExpense_heating(String expense_heating) {
		this.expense_heating = expense_heating;
	}
	public String getExpense_electric() {
		return expense_electric;
	}
	public void setExpense_electric(String expense_electric) {
		this.expense_electric = expense_electric;
	}
	public String getExpense_water() {
		return expense_water;
	}
	public void setExpense_water(String expense_water) {
		this.expense_water = expense_water;
	}
	public String getExpense_phone() {
		return expense_phone;
	}
	public void setExpense_phone(String expense_phone) {
		this.expense_phone = expense_phone;
	}
	public String getExpense_rent() {
		return expense_rent;
	}
	public void setExpense_rent(String expense_rent) {
		this.expense_rent = expense_rent;
	}
	public String getExpense_property() {
		return expense_property;
	}
	public void setExpense_property(String expense_property) {
		this.expense_property = expense_property;
	}
	@Transient
	private String expense_heating;
	@Transient
	private String expense_electric;
	@Transient
	private String expense_water;
	@Transient
	private String expense_phone;
	@Transient
	private String expense_rent;
	@Transient
	private String expense_property;
		
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	public Integer getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	public int getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getBill_type() {
		return bill_type;
	}
	public void setBill_type(String bill_type) {
		this.bill_type = bill_type;
	}
	public Double getPymt_amt() {
		return pymt_amt;
	}
	public void setPymt_amt(Double pymt_amt) {
		this.pymt_amt = pymt_amt;
	}
	public String getPymt_freq() {
		return pymt_freq;
	}
	public void setPymt_freq(String pymt_freq) {
		this.pymt_freq = pymt_freq;
	}
	public String getJnt_pay_resp() {
		return jnt_pay_resp;
	}
	public void setJnt_pay_resp(String jnt_pay_resp) {
		this.jnt_pay_resp = jnt_pay_resp;
	}
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public Double getPaid_amt() {
		return paid_amt;
	}
	public void setPaid_amt(Double paid_amt) {
		this.paid_amt = paid_amt;
	}
	public Date getEnd_dt() {
		return end_dt;
	}
	public void setEnd_dt(Date end_dt) {
		this.end_dt = end_dt;
	}
	public int getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(int ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getPropAddrZip4() {
		return propAddrZip4;
	}
	public void setPropAddrZip4(String propAddrZip4) {
		this.propAddrZip4 = propAddrZip4;
	}
	public Date getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(Date chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getLoopingQuestion() {
		return loopingQuestion;
	}
	public void setLoopingQuestion(String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}
	public String getProperty_name() {
		return property_name;
	}
	public void setProperty_name(String property_name) {
		this.property_name = property_name;
	}
	public String getProp_addr_l1() {
		return prop_addr_l1;
	}
	public void setProp_addr_l1(String prop_addr_l1) {
		this.prop_addr_l1 = prop_addr_l1;
	}
	public String getProp_addr_l2() {
		return prop_addr_l2;
	}
	public void setProp_addr_l2(String prop_addr_l2) {
		this.prop_addr_l2 = prop_addr_l2;
	}
	public String getProp_addr_city() {
		return prop_addr_city;
	}
	public void setProp_addr_city(String prop_addr_city) {
		this.prop_addr_city = prop_addr_city;
	}
	public String getProp_addr_state_cd() {
		return prop_addr_state_cd;
	}
	public void setProp_addr_state_cd(String prop_addr_state_cd) {
		this.prop_addr_state_cd = prop_addr_state_cd;
	}
	public String getProp_addr_zip() {
		return prop_addr_zip;
	}
	public void setProp_addr_zip(String prop_addr_zip) {
		this.prop_addr_zip = prop_addr_zip;
	}
	public String getProp_phone_num() {
		return prop_phone_num;
	}
	public void setProp_phone_num(String prop_phone_num) {
		this.prop_phone_num = prop_phone_num;
	}
	public String getJnt_payee_first_name() {
		return jnt_payee_first_name;
	}
	public void setJnt_payee_first_name(String jnt_payee_first_name) {
		this.jnt_payee_first_name = jnt_payee_first_name;
	}
	public String getJnt_payee_last_name() {
		return jnt_payee_last_name;
	}
	public void setJnt_payee_last_name(String jnt_payee_last_name) {
		this.jnt_payee_last_name = jnt_payee_last_name;
	}
	public String getJnt_pymt_freq() {
		return jnt_pymt_freq;
	}
	public void setJnt_pymt_freq(String jnt_pymt_freq) {
		this.jnt_pymt_freq = jnt_pymt_freq;
	}
	public String getLiheap_resp() {
		return liheap_resp;
	}
	public void setLiheap_resp(String liheap_resp) {
		this.liheap_resp = liheap_resp;
	}
	
	public String getHouBillsCalsawsObject() {
		return houBillsCalsawsObject;
	}
	public void setHouBillsCalsawsObject(String houBillsCalsawsObject) {
		this.houBillsCalsawsObject = houBillsCalsawsObject;
	}
	public String getBillTypeDesc() {
		return billTypeDesc;
	}
	public void setBillTypeDesc(String billTypeDesc) {
		this.billTypeDesc = billTypeDesc;
	}

}
