package gov.state.nextgen.financialinformation.business.entities;

import java.rmi.RemoteException;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_IN_HOU_BILLS_Collection extends AbstractCollection {

	
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_IN_HOU_BILLS";

	

	public void setGenericResults(final Object obj) throws RemoteException {
		if (obj instanceof APP_IN_HOU_BILLS_Cargo[]) {
			final APP_IN_HOU_BILLS_Cargo[] cbArray = (APP_IN_HOU_BILLS_Cargo[]) obj;
			setResults(cbArray);
		}

	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_HOU_BILLS_Cargo[] cargos) {
		clear();
		for (int index = 0, length = cargos.length; index < length; index++) {
			add(cargos[index]);
		}
	}

	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	public boolean addCargo(final APP_IN_HOU_BILLS_Cargo cargo) {
		return add(cargo);
	}

	public APP_IN_HOU_BILLS_Cargo getCargo(final int index) {
		return (APP_IN_HOU_BILLS_Cargo) get(index);
	}
}

