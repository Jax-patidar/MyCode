/**
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * @author khuskumari
 * Key class for APP_IN_L_INS_ASET
 *
 */
@Embeddable
public class APP_IN_L_INS_ASET_Key implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String app_num;
	private Integer indv_seq_num;
	private Integer seq_num;
	private String src_app_ind;
	
	public APP_IN_L_INS_ASET_Key() {
		
	}

	/**
	 * @param app_num
	 * @param indv_seq_num
	 * @param seq_num
	 * @param src_app_ind
	 */
	public APP_IN_L_INS_ASET_Key(String app_num, Integer indv_seq_num, Integer seq_num, String src_app_ind) {
		super();
		app_num = app_num;
		this.indv_seq_num = indv_seq_num;
		this.seq_num = seq_num;
		this.src_app_ind = src_app_ind;
	}
	
	

}
