package gov.state.nextgen.financialinformation.business.rules;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_VEH_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_VEH_ASET_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppInJntOwnRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInVehAssetRepository;

@Service("VehicleAssetBO")
public class VehicleAssetBO extends AbstractBO {

	@Autowired
	private AppInVehAssetRepository appInVehAssetRepository;
	
	@Autowired
	private AppInJntOwnRepository appInJntOwnRepository;
	
	public APP_IN_JNT_OWN_Collection loadIndividualJointOwnerDetails(String appNumber, Integer indvSeqNum,
			String jointOwnerTypeInsuranceAsset, String subType, Integer seq_num) {
		try
		{
		return appInJntOwnRepository.loadIndividualJointOwnerDetails(Integer.parseInt(appNumber), indvSeqNum, jointOwnerTypeInsuranceAsset, subType, seq_num);
		} catch (final Exception e) {
			throw e;
		}
	}

	public void storeJointOwnerDetails(APP_IN_JNT_OWN_Collection appInJntOwnNewColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "VehicleAssetBO.storeJointOwnerDetails() - START");
		
		try {
			if(null != appInJntOwnNewColl && !appInJntOwnNewColl.isEmpty()) {
				for(int i = 0; i<appInJntOwnNewColl.size(); i++) {
					APP_IN_JNT_OWN_Cargo cargo = appInJntOwnNewColl.getCargo(i);
					if(FwConstants.ROWACTION_DELETE.equalsIgnoreCase(cargo.getRowAction())){
						appInJntOwnRepository.delete(cargo);
					}else {
						appInJntOwnRepository.save(cargo);
					}	
				}
			}
			
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "VehicleAssetBO.storeJointOwnerDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + " milliseconds");
		
	}

	public APP_IN_VEH_ASET_Collection loadIndividualVehicleAsetDetails(final String appNumber, final Integer indvSeqNum,
			final Integer seqNum) {
		APP_IN_VEH_ASET_Collection appInVehAsetColl = null;
		try {
			appInVehAsetColl = appInVehAssetRepository.getByAppumSeqNumVehType(Integer.parseInt(appNumber), indvSeqNum, seqNum);

		}catch (final Exception e) {
			throw e;
		}
		return appInVehAsetColl;
	}

	public APP_IN_VEH_ASET_Collection storeVehicleAssetDetails(APP_IN_VEH_ASET_Collection appInColl) {
		APP_IN_VEH_ASET_Cargo appInCargo = new APP_IN_VEH_ASET_Cargo();
		APP_IN_VEH_ASET_Collection coll = new APP_IN_VEH_ASET_Collection();

		try {
			if (null != appInColl && !appInColl.isEmpty()) {
				appInCargo = appInVehAssetRepository.save(appInColl.getCargo(0));
			}
			coll.add(appInCargo);
			return coll;
		} catch (final Exception e) {
			throw e;
		}
	}

	public void validateAnotherCar(APP_IN_VEH_ASET_Collection appInVAsetColl) {
		try {
		final APP_IN_VEH_ASET_Cargo appInVehAsetCargo = appInVAsetColl.getCargo(0);
		if ((null != appInVehAsetCargo.getLoopingQuestion())
				&& FwConstants.EMPTY_STRING.equals(appInVehAsetCargo.getLoopingQuestion().trim())) {
			addMessageCode("00261");
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	/*
	 * Created as part of CSPM-1876 Assets_UseVehicleService 
	 */
	public APP_IN_VEH_ASET_Collection getExistingUseVehicleAssetDetails(String appNumber, int indvSeqNum,
			int catSeqNum) {
		try {
		return appInVehAssetRepository.getExistingUseVehicleAssetDetails(Integer.parseInt(appNumber),indvSeqNum,catSeqNum);
		} catch (final Exception e) {
			throw e;
		}
	}
	/*
	 * Created as part of CSPM-1876 Assets_UseVehicleService
	 */
	public void saveUseVehicleDetails(APP_IN_VEH_ASET_Collection updatedUseVehicleColl) {
		try {
			APP_IN_VEH_ASET_Cargo cargo = null;
			if (updatedUseVehicleColl != null && !updatedUseVehicleColl.isEmpty()) {
				cargo = updatedUseVehicleColl.getCargo(0);
				appInVehAssetRepository.save(cargo);
			}
		} catch (final Exception exception) {
            throw exception;
        }	
		
	}
	
	/*
	 * Created as part of CSPM-1876 Assets_UseVehicleService
	 */
	public int getMaxVehicleAssetSeqNumber(String appNumber, int indvSeqNum) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "VehicleAssetBO.getMaxVehicleAssetSeqNumber() - START");
		int maxSeqNum = 0;
		try {
		Integer result = appInVehAssetRepository.findByMaxVehicleSeqNum(Integer.parseInt(appNumber), indvSeqNum);
		if (result != null) {
			maxSeqNum = result;
		}
		FwLogger.log(this.getClass(),FwLogger.Level.INFO, "VehicleAssetBO.getMaxVehicleAssetSeqNumber() - END");
		return maxSeqNum;
		} catch (final Exception e) {
			throw e;
		}
	}

	/*
	 * Created as part of CSPM-1876 Assets_UseVehicleService
	 */
	public APP_IN_VEH_ASET_Collection loadUseVehicleAssetDetails(String appNumber, String vehAssetType, List<Integer> indvIds) {
		try {
		return appInVehAssetRepository.loadVehicleAssetDetails(Integer.parseInt(appNumber),vehAssetType, indvIds);
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public APP_IN_VEH_ASET_Collection loadUseVehicleAssetDetails(String appNumber) {
		try {
		return appInVehAssetRepository.loadUseVehicleAssetDetails(Integer.parseInt(appNumber));
		} catch (final Exception e) {
			throw e;
		}
	}

	public APP_IN_VEH_ASET_Collection loadOwnVehicleSummary(String appNum, List<Integer> indvIds) {
		try {
		return appInVehAssetRepository.loadOwnVehicleSummary(Integer.parseInt(appNum), indvIds);
		} catch (final Exception e) {
			throw e;
		}
	}
	
	/*
	 * Created as part of CSPM-3249 to remove item
	 */
	public void removeVehicleDetails(String appNumber, Integer indvSeqNum, Integer seqNum, String vehAssetType) {
		try {
			appInVehAssetRepository.deleteVehicleDetails(Integer.parseInt(appNumber),indvSeqNum,seqNum,vehAssetType);
		} catch (final Exception exception) {
            throw exception;
        }	
		
	}
	public APP_IN_VEH_ASET_Collection loadVehicleAssetDetails(String appNumber) {
		try {
		return appInVehAssetRepository.loadVehicleAssetDetails(Integer.parseInt(appNumber));
		} catch (Exception e) {
			FwException fe = new FwException();
        	fe = FwExceptionManager.createFwException(this.getClass().getName(), fe.getStackTrace()[0].getMethodName(), e);
        	throw fe;
		}
	}
}
