package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;


/**
 * The persistent class for the cp_app_in_empl_pay_stub database table.
 * 
 */
@Entity
@Table(name = "CP_APP_IN_DC_E_LIST")
@IdClass(AppInDcEListPK.class)
@NamedQuery(name = "APP_IN_DC_E_LIST_Cargo.findAll", query = "SELECT c FROM APP_IN_DC_E_LIST_Cargo c")
public class APP_IN_DC_E_LIST_Cargo extends AbstractCargo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Transient
	private String appNum;
	
	@Id
	@Column(name = "app_num")
	private int app_number;

	@Id
	private Integer indvSeqNum;

	@Id
	private Integer seqNum;

	@Id
	private Integer stubSeqNum;
	
	private Integer dependentIndvSeqNum;
	
	private String inHouseholdIndicator;


	
	public String getInHouseholdIndicator() {
		return inHouseholdIndicator;
	}

	public void setInHouseholdIndicator(String inHouseholdIndicator) {
		this.inHouseholdIndicator = inHouseholdIndicator;
	}

	private String firstName;

	private String lastName;

	public String getAppNum() {
		return String.valueOf(app_number);
	}

	public void setAppNum(String appNum) {
		this.app_number = Integer.parseInt(appNum);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.appNum = String.valueOf(app_number);
	}
	public Integer getIndvSeqNum() {
		return indvSeqNum;
	}

	public void setIndvSeqNum(Integer indvSeqNum) {
		this.indvSeqNum = indvSeqNum;
	}

	public Integer getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}

	public Integer getStubSeqNum() {
		return stubSeqNum;
	}

	public void setStubSeqNum(Integer stubSeqNum) {
		this.stubSeqNum = stubSeqNum;
	}


	public Integer getDependentIndvSeqNum() {
		return dependentIndvSeqNum;
	}

	public void setDependentIndvSeqNum(Integer dependentIndvSeqNum) {
		this.dependentIndvSeqNum = dependentIndvSeqNum;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



}