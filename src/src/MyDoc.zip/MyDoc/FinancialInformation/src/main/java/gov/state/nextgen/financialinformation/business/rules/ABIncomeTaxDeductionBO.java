// NextGen  NG-6481 Phase 3 updates to ACA Streamline changes - start
package gov.state.nextgen.financialinformation.business.rules;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.CpAppInIncomeTaxDedRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("ABIncomeTaxDeductionBO")
public class ABIncomeTaxDeductionBO extends AbstractBO {

	@Autowired
	private CpAppInIncomeTaxDedRepository cpAppInIncomeTaxDedRepository;


	public CP_APP_IN_INCOME_TAX_DED_Collection loadIndividualIncomeTaxDedInsAFB(final String appNumber,
			final Integer indevSeqNum) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.DEBUG, "ABIncomeTaxDeductionBO.loadIndividualIncomeTaxDedInsAFB() - START");
		try {
			final CP_APP_IN_INCOME_TAX_DED_Collection appInColl = cpAppInIncomeTaxDedRepository
					.loadIndividualIncomeTaxDedInsAFB(Integer.parseInt(appNumber), indevSeqNum);

			FwLogger.log(this.getClass(), Level.DEBUG,
					"ABIncomeTaxDeductionBO.loadIndividualIncomeTaxDedInsAFB() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) );

			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	public CP_APP_IN_INCOME_TAX_DED_Cargo splitTaxDeduColl(final CP_APP_IN_INCOME_TAX_DED_Collection taxDedColl,
			final String recordIndicator) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.DEBUG, "ABIncomeTaxDeductionBO.splitTaxDeduColl() - START");
		try {
			if (taxDedColl != null && !taxDedColl.isEmpty()) {
				final int taxDedCollSize = taxDedColl.size();
				CP_APP_IN_INCOME_TAX_DED_Cargo taxDedCargo = null;
				for (int i = 0; i < taxDedCollSize; i++) {
					taxDedCargo = taxDedColl.getResult(i);
					if (taxDedCargo.getSrc_app_ind().equals(recordIndicator)) {
						return taxDedCargo;
					}
				}

			}
			FwLogger.log(this.getClass(), Level.DEBUG, "ABIncomeTaxDeductionBO.splitTaxDeduColl() - END , Time Taken : "
					+ (System.currentTimeMillis() - startTime) );
			return null;
		}catch (final Exception e) {
			throw e;
		}

	}

	public void storeTaxDeductDetails(final CP_APP_IN_INCOME_TAX_DED_Collection appInTaxDeductColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.DEBUG, "ABIncomeTaxDeductionBO.storeTaxDeductDetails() - START");
		try {
			if (!appInTaxDeductColl.isEmpty()) {
				cpAppInIncomeTaxDedRepository.saveAll(appInTaxDeductColl);
			}
		}  catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), Level.DEBUG,
				"ABIncomeTaxDeductionBO.storeTaxDeductDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) );
	}

	public void storeIncomeTaxDedInsDetails(final CP_APP_IN_INCOME_TAX_DED_Collection appInLstColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.DEBUG, "ABIncomeTaxDeductionBO.storeIncomeTaxDedInsDetails() - START");
		try {
			if (appInLstColl != null) {
				cpAppInIncomeTaxDedRepository.saveAll(appInLstColl);
			}
		}catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), Level.DEBUG,
				"ABIncomeTaxDeductionBO.storeIncomeTaxDedInsDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) );
	}

	public CP_APP_IN_INCOME_TAX_DED_Cargo settingDefaultValues(final CP_APP_IN_INCOME_TAX_DED_Cargo taxDeductionCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.DEBUG, "ABIncomeTaxDeductionBO.settingDefaultValues() - START");
		try {
			if (taxDeductionCargo != null) {

				setTaxDeductionData(taxDeductionCargo);

			}
			FwLogger.log(this.getClass(), Level.DEBUG,
					"ABIncomeTaxDeductionBO.settingDefaultValues() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) );
			return taxDeductionCargo;
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * @param taxDeductionCargo
	 */
	private void setTaxDeductionData(final CP_APP_IN_INCOME_TAX_DED_Cargo taxDeductionCargo) {
		try {
		if (taxDeductionCargo.getSrc_app_ind() == null) {
			taxDeductionCargo.setSrc_app_ind(FwConstants.EMPTY_STRING);
		}
		if (taxDeductionCargo.getAlimony_exp() == null) {
			taxDeductionCargo.setAlimony_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getBusiness_exp() == null) {
			taxDeductionCargo.setBusiness_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getDeductible_self_exp() == null) {
			taxDeductionCargo.setDeductible_self_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getDomestic_exp() == null) {
			taxDeductionCargo.setDomestic_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getEducator_exp() == null) {
			taxDeductionCargo.setEducator_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getHealth_saving_exp() == null) {
			taxDeductionCargo.setHealth_saving_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getIra_exp() == null) {
			taxDeductionCargo.setIra_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getMoving_exp() == null) {
			taxDeductionCargo.setMoving_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getPenalty_exp() == null) {
			taxDeductionCargo.setPenalty_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getSelf_health_exp() == null) {
			taxDeductionCargo.setSelf_health_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getSelf_sep_exp() == null) {
			taxDeductionCargo.setSelf_sep_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getStudent_loan_exp() == null) {
			taxDeductionCargo.setStudent_loan_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		if (taxDeductionCargo.getTution_exp() == null) {
			taxDeductionCargo.setTution_exp(FinancialInfoConstants.ZERO_DOUBLE);
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	public CP_APP_IN_INCOME_TAX_DED_Collection loadTaxDedResponse(final String appNumber, final Integer indvSeqNum,
			final Integer seqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.DEBUG, "ABIncomeTaxDeductionBO.loadTaxDedResponse() - START");
		try {
			final CP_APP_IN_INCOME_TAX_DED_Collection appInTaxColl = cpAppInIncomeTaxDedRepository
					.loadTaxDedResponse(Integer.parseInt(appNumber), indvSeqNum, seqNum);
			FwLogger.log(this.getClass(), Level.DEBUG,
					"ABIncomeTaxDeductionBO.loadTaxDedResponse() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) );
			return appInTaxColl;

		}catch (final Exception e) {
			throw e;
		}

	}

	public int getMaxIncTaxDedSeqNumber(String appNum, int indvSeqNum) {
		FwLogger.log(this.getClass(), Level.INFO, "ABBeforeTaxDeductionBO.getMaxIncBefTaxSeqNumber() - START");
		int maxSeqNum = 0;
		try {

			Integer maxSeq = cpAppInIncomeTaxDedRepository.getMaxIncBefTaxSeqNumber(Integer.parseInt(appNum), indvSeqNum);

			if (maxSeq != null) {
				maxSeqNum = maxSeq;
			}

			return maxSeqNum;

		} catch (final Exception e) {
			throw e;
		}
	}
}
