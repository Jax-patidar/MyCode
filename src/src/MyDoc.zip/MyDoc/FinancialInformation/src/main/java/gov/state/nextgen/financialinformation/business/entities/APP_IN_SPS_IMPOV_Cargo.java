package gov.state.nextgen.financialinformation.business.entities;


import java.io.Serializable;

import javax.persistence.Id;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class APP_IN_SPS_IMPOV_Cargo extends AbstractCargo implements Serializable{

	private static final long serialVersionUID = 6181287483384906131L;
	
	@Id
	private String app_num;
	
	@Id
	private Integer indv_seq_num;
	
	@Id
	private String src_app_ind;
	
	private String sps_city_adr;
	private String sps_l1_adr;
	private String sps_l2_adr;
	private String sps_sta_adr;
	private String sps_zip_adr;
	private String spouse_out_of_home_ind;
	private String spouse_name;
	
	private String spouse_living_arrg_cd;
	private String spouse_living_arrg_oth;
	
	
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getSps_city_adr() {
		return sps_city_adr;
	}
	public void setSps_city_adr(String sps_city_adr) {
		this.sps_city_adr = sps_city_adr;
	}
	public String getSps_l1_adr() {
		return sps_l1_adr;
	}
	public void setSps_l1_adr(String sps_l1_adr) {
		this.sps_l1_adr = sps_l1_adr;
	}
	public String getSps_l2_adr() {
		return sps_l2_adr;
	}
	public void setSps_l2_adr(String sps_l2_adr) {
		this.sps_l2_adr = sps_l2_adr;
	}
	public String getSps_sta_adr() {
		return sps_sta_adr;
	}
	public void setSps_sta_adr(String sps_sta_adr) {
		this.sps_sta_adr = sps_sta_adr;
	}
	public String getSps_zip_adr() {
		return sps_zip_adr;
	}
	public void setSps_zip_adr(String sps_zip_adr) {
		this.sps_zip_adr = sps_zip_adr;
	}
	public String getSpouse_out_of_home_ind() {
		return spouse_out_of_home_ind;
	}
	public void setSpouse_out_of_home_ind(String spouse_out_of_home_ind) {
		this.spouse_out_of_home_ind = spouse_out_of_home_ind;
	}
	public String getSpouse_name() {
		return spouse_name;
	}
	public void setSpouse_name(String spouse_name) {
		this.spouse_name = spouse_name;
	}
	public String getSpouse_living_arrg_cd() {
		return spouse_living_arrg_cd;
	}
	public void setSpouse_living_arrg_cd(String spouse_living_arrg_cd) {
		this.spouse_living_arrg_cd = spouse_living_arrg_cd;
	}
	public String getSpouse_living_arrg_oth() {
		return spouse_living_arrg_oth;
	}
	public void setSpouse_living_arrg_oth(String spouse_living_arrg_oth) {
		this.spouse_living_arrg_oth = spouse_living_arrg_oth;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((spouse_living_arrg_cd == null) ? 0 : spouse_living_arrg_cd.hashCode());
		result = prime * result + ((spouse_living_arrg_oth == null) ? 0 : spouse_living_arrg_oth.hashCode());
		result = prime * result + ((spouse_name == null) ? 0 : spouse_name.hashCode());
		result = prime * result + ((spouse_out_of_home_ind == null) ? 0 : spouse_out_of_home_ind.hashCode());
		result = prime * result + ((sps_city_adr == null) ? 0 : sps_city_adr.hashCode());
		result = prime * result + ((sps_l1_adr == null) ? 0 : sps_l1_adr.hashCode());
		result = prime * result + ((sps_l2_adr == null) ? 0 : sps_l2_adr.hashCode());
		result = prime * result + ((sps_sta_adr == null) ? 0 : sps_sta_adr.hashCode());
		result = prime * result + ((sps_zip_adr == null) ? 0 : sps_zip_adr.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}
	
	@Override
	public String toString() {
		return "APP_IN_SPS_IMPOV_Cargo [app_num=" + app_num + ", indv_seq_num=" + indv_seq_num + ", src_app_ind="
				+ src_app_ind + ", sps_city_adr=" + sps_city_adr + ", sps_l1_adr=" + sps_l1_adr + ", sps_l2_adr="
				+ sps_l2_adr + ", sps_sta_adr=" + sps_sta_adr + ", sps_zip_adr=" + sps_zip_adr
				+ ", spouse_out_of_home_ind=" + spouse_out_of_home_ind + ", spouse_name=" + spouse_name
				+ ", spouse_living_arrg_cd=" + spouse_living_arrg_cd + ", spouse_living_arrg_oth="
				+ spouse_living_arrg_oth + "]";
	}	
	
	
	
	

}
