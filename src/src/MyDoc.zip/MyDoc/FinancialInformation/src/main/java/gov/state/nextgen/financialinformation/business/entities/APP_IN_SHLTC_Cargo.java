/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(APP_IN_SHLTC_Id.class)
@Table(name = "CP_APP_IN_SHLTC")
public class APP_IN_SHLTC_Cargo extends AbstractCargo implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3520102069923502966L;

	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private String indv_seq_num;
	@Id
	private String seq_num;
	
	private String src_app_ind;
	@Column(name="change_eff_dt")
	private String chg_eff_dt;
	private String rec_cplt_ind;
	@Transient
	private String shlt_oblg_amt;
	@Transient
	private String shlt_oblg_ind;
	@Column(name="shlt_type")
	private String shlt_typ;
	private String pay_freq;
	private Integer other_housing_payment_amt;
	@Column(name="other_housing_payments")
	private String Other_Housing_paymts;
	// EDSP CP Starts - Housing Bills - Shelter Expense
	@Transient
	private String someone_else_rent_pay_ind;
	@Transient
	private String not_living_reason_cd;
	@Transient
	private String intend_to_return_ind;
	@Transient
	private String someone_else_living_ind;
	private String housing_bill_ind;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date release_dt;
	private String shelt_name;

	public String getHousing_bill_ind() {
		return housing_bill_ind;
	}

	public void setHousing_bill_ind(final String housing_bill_ind) {
		this.housing_bill_ind = housing_bill_ind;
	}

	/**
	 * returns the someone_else_living_ind value.
	 */
	public String getSomeone_else_living_ind() {
		return someone_else_living_ind;
	}

	/**
	 * sets the someone_else_living_ind value.
	 */
	public void setSomeone_else_living_ind(final String someone_else_living_ind) {
		this.someone_else_living_ind = someone_else_living_ind;
	}

	/**
	 * returns the intend_to_return_ind value.
	 */
	public String getIntend_to_return_ind() {
		return intend_to_return_ind;
	}

	/**
	 * sets the intend_to_return_ind value.
	 */
	public void setIntend_to_return_ind(final String intend_to_return_ind) {
		this.intend_to_return_ind = intend_to_return_ind;
	}

	/**
	 * returns the not_living_reason_cd value.
	 */
	public String getNot_living_reason_cd() {
		return not_living_reason_cd;
	}

	/**
	 * sets the not_living_reason_cd value.
	 */
	public void setNot_living_reason_cd(final String not_living_reason_cd) {
		this.not_living_reason_cd = not_living_reason_cd;
	}

	/**
	 * returns the someone_else_rent_pay_ind value.
	 */
	public String getSomeone_else_rent_pay_ind() {
		return someone_else_rent_pay_ind;
	}

	/**
	 * sets the someone_else_rent_pay_ind value.
	 */
	public void setSomeone_else_rent_pay_ind(final String someone_else_rent_pay_ind) {
		this.someone_else_rent_pay_ind = someone_else_rent_pay_ind;
	}

	// EDSP CP ends - Housing Bills
	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public String getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public String getSeq_num() {
		return seq_num;
	}

	/**
	 * returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * returns the chg_eff_dt value.
	 */
	public String getChg_eff_dt() {
		return chg_eff_dt;
	}

	/**
	 * returns the rec_cplt_ind value.
	 */
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * returns the shlt_oblg_amt value.
	 */
	public String getShlt_oblg_amt() {
		return displayFormatter.getNumberFormat(shlt_oblg_amt);
	}

	/**
	 * returns the shlt_oblg_ind value.
	 */
	public String getShlt_oblg_ind() {
		return shlt_oblg_ind;
	}

	/**
	 * returns the shlt_typ value.
	 */
	public String getShlt_typ() {
		return shlt_typ;
	}

	/**
	 * returns the pay_freq value.
	 */
	public String getPay_freq() {
		return pay_freq;
	}

	/**
	 * returns the othr_housing_paymt value.
	 */
	public String getOther_Housing_paymts() {
		return Other_Housing_paymts;
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final String indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final String seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * sets the chg_eff_dt value.
	 */
	public void setChg_eff_dt(final String chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}

	/**
	 * sets the rec_cplt_ind value.
	 */
	public void setRec_cplt_ind(final String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * sets the shlt_oblg_amt value.
	 */
	public void setShlt_oblg_amt(final String shlt_oblg_amt) {
		this.shlt_oblg_amt = shlt_oblg_amt;
	}

	/**
	 * sets the shlt_oblg_ind value.
	 */
	public void setShlt_oblg_ind(final String shlt_oblg_ind) {
		this.shlt_oblg_ind = shlt_oblg_ind;
	}

	/**
	 * sets the shlt_typ value.
	 */
	public void setShlt_typ(final String shlt_typ) {
		this.shlt_typ = shlt_typ;
	}

	/**
	 * sets the pay_freq value.
	 */
	public void setPay_freq(final String pay_freq) {
		this.pay_freq = pay_freq;
	}

	/**
	 * sets the othr_housing_paymt value.
	 */
	public void setOther_Housing_paymts(final String Other_Housing_paymts) {
		this.Other_Housing_paymts = Other_Housing_paymts;
	}

	public Integer getOther_housing_payment_amt() {
		return other_housing_payment_amt;
	}

	public void setOther_housing_payment_amt(Integer other_housing_payment_amt) {
		this.other_housing_payment_amt = other_housing_payment_amt;
	}

	public Date getRelease_dt() {
		return release_dt;
	}

	public void setRelease_dt(Date release_dt) {
		this.release_dt = release_dt;
	}

	public String getShelt_name() {
		return shelt_name;
	}

	public void setShelt_name(String shelt_name) {
		this.shelt_name = shelt_name;
	}

	/**
	 * returns the string value of cargo.
	 */
	public String inspectCargo() {
		return new StringBuilder().append("APP_IN_SHLTC: ").append("app_num=").append(app_num).append("indv_seq_num=")
				.append(indv_seq_num).append("seq_num=").append(seq_num).append("src_app_ind=").append(src_app_ind)
				.append("chg_eff_dt=").append(chg_eff_dt).append("rec_cplt_ind=").append(rec_cplt_ind)
				.append("shlt_oblg_amt=").append(shlt_oblg_amt).append("shlt_oblg_ind=").append(shlt_oblg_ind)
				.append("shlt_typ=").append(shlt_typ).append("pay_freq=").append(pay_freq).append("othr_housing_paymt=")
				.append(Other_Housing_paymts).append(release_dt).append(shelt_name).toString();
	}
	

	
}