package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class CP_ABCHS_Collection extends AbstractCollection {

	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.CP_ABCHS";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CP_ABCHS_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CP_ABCHS_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CP_ABCHS_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CP_ABCHS_Cargo[] getResults() {
		final CP_ABCHS_Cargo[] cbArray = new CP_ABCHS_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CP_ABCHS_Cargo getCargo(final int idx) {
		return (CP_ABCHS_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public CP_ABCHS_Cargo[] cloneResults() {
		final CP_ABCHS_Cargo[] rescargo = new CP_ABCHS_Cargo[size()];

		for (int i = 0; i < size(); i++) {
			final CP_ABCHS_Cargo cargo = getCargo(i);

			rescargo[i] = new CP_ABCHS_Cargo();

			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setSeq_num(cargo.getSeq_num());
			rescargo[i].setPrvd_org_nam(cargo.getPrvd_org_nam());
			rescargo[i].setPrvd_addr_line1(cargo.getPrvd_addr_line1());
			rescargo[i].setPrvd_addr_line2(cargo.getPrvd_addr_line2());
			rescargo[i].setPrvd_addr_city(cargo.getPrvd_addr_city());
			
			rescargo[i].setPrvd_addr_zip(cargo.getPrvd_addr_zip());
			rescargo[i].setPrvd_phone_num(cargo.getPrvd_phone_num());
			rescargo[i].setDpnd_care_exp_rsn_cd(cargo.getDpnd_care_exp_rsn_cd());
			rescargo[i].setDependent_care_exp_start_dt(cargo.getDependent_care_exp_start_dt());
			rescargo[i].setDependent_care_exp_end_dt(cargo.getDependent_care_exp_end_dt());
			rescargo[i].setPay_freq(cargo.getPay_freq());
			rescargo[i].setDpnd_care_exp_amt(cargo.getDpnd_care_exp_amt());
			rescargo[i].setPaid_in_seq_num(cargo.getPaid_in_seq_num());
			rescargo[i].setPaid_in_seq_num(cargo.getPaid_in_seq_num());
			rescargo[i].setRec_cplt_ind((cargo.getRec_cplt_ind()));
			rescargo[i].setEcp_id(cargo.getEcp_id());
			// AFB Changes End
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
			rescargo[i].setChg_dt(cargo.getChg_dt());

		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_ABCHS_Cargo[]) {
			final CP_ABCHS_Cargo[] cbArray = (CP_ABCHS_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
