package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;


public class CP_APP_IN_BEF_TAX_DED_Cargo extends AbstractCargo implements Serializable {

	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	private String app_num;
	@Id
	private Integer indv_seq_num;
	@Id
	private String src_app_ind;
	@Id
	private Integer seq_num;
	private Integer ecp_id;

	private Double medical_ins;
	private Double dental_ins;
	private Double vision_ins;
	private Double flexi_spend_account;
	private Double deferred_comp;
	private Double pre_tax_life_ins;
	private Double other_exp;
	
	@Transient
	private String fst_name;

	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date btd_end_dt;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_dt;

	public String getApp_num() {
		return app_num;
	}

	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}

	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public Integer getEcp_id() {
		return ecp_id;
	}

	public void setEcp_id(Integer ecp_id) {
		this.ecp_id = ecp_id;
	}

	public Date getBtd_end_dt() {
        return this.btd_end_dt!= null ? new Date(btd_end_dt.getTime()) : null;

	}

	public void setBtd_end_dt(Date btd_end_dt) {
		this.btd_end_dt = (btd_end_dt == null) ? null : new Date(btd_end_dt.getTime());
	}

	public Double getMedical_ins() {
		return medical_ins;
	}

	public void setMedical_ins(Double medical_ins) {
		this.medical_ins = medical_ins;
	}

	public Double getDental_ins() {
		return dental_ins;
	}

	public void setDental_ins(Double dental_ins) {
		this.dental_ins = dental_ins;
	}

	public Double getVision_ins() {
		return vision_ins;
	}

	public void setVision_ins(Double vision_ins) {
		this.vision_ins = vision_ins;
	}

	public Double getFlexi_spend_account() {
		return flexi_spend_account;
	}

	public void setFlexi_spend_account(Double flexi_spend_account) {
		this.flexi_spend_account = flexi_spend_account;
	}

	public Double getDeferred_comp() {
		return deferred_comp;
	}

	public void setDeferred_comp(Double deferred_comp) {
		this.deferred_comp = deferred_comp;
	}

	public Double getPre_tax_life_ins() {
		return pre_tax_life_ins;
	}

	public void setPre_tax_life_ins(Double pre_tax_life_ins) {
		this.pre_tax_life_ins = pre_tax_life_ins;
	}

	public Double getOther_exp() {
		return other_exp;
	}

	public void setOther_exp(Double other_exp) {
		this.other_exp = other_exp;
	}

	public Date getChg_dt() {
        return this.chg_dt!= null ? new Date(chg_dt.getTime()) : null;
	}

	public void setChg_dt(Date chg_dt) {
		this.chg_dt = (chg_dt == null) ? null : new Date(chg_dt.getTime());

	}

	public Integer getSeq_num() {
		return seq_num;
	}

	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}

	public String getFst_name() {
		return fst_name;
	}

	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((btd_end_dt == null) ? 0 : btd_end_dt.hashCode());
		result = prime * result + ((chg_dt == null) ? 0 : chg_dt.hashCode());
		result = prime * result + ((deferred_comp == null) ? 0 : deferred_comp.hashCode());
		result = prime * result + ((dental_ins == null) ? 0 : dental_ins.hashCode());
		result = prime * result + ((ecp_id == null) ? 0 : ecp_id.hashCode());
		result = prime * result + ((flexi_spend_account == null) ? 0 : flexi_spend_account.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((medical_ins == null) ? 0 : medical_ins.hashCode());
		result = prime * result + ((other_exp == null) ? 0 : other_exp.hashCode());
		result = prime * result + ((pre_tax_life_ins == null) ? 0 : pre_tax_life_ins.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		result = prime * result + ((vision_ins == null) ? 0 : vision_ins.hashCode());
		return result;
	}

	

}