package gov.state.nextgen.financialinformation.business.rules;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_SNP_Cargo;
import gov.state.nextgen.financialinformation.data.db2.CpAppInMedBillsRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInSnpRepository;

@Service("SpecialNeedsBO")
public class SpecialNeedsBO extends AbstractBO {
	
	@Autowired
	CpAppInMedBillsRepository  cpAppInMedBillsRepository;
	

	
	@Autowired
	CpAppInSnpRepository cpAppInSnpRepository;


	public CP_APP_IN_MED_BILLS_Collection getSpecialNeeds(String appnum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.getSpecialNeeds() - START");
        try {
        	List<String> SNEX = new ArrayList<String>();
        	SNEX.add("09");
        	SNEX.add("19");
        	SNEX.add("18");
        	SNEX.add("08");
        	SNEX.add("17");
        	SNEX.add("OT");
        	CP_APP_IN_MED_BILLS_Collection medColl;
        	CP_APP_IN_MED_BILLS_Collection result1 = new CP_APP_IN_MED_BILLS_Collection();
        	if(appnum != null) {
        		CP_APP_IN_MED_BILLS_Cargo[] medCargoArray  = cpAppInMedBillsRepository.getByAppNumAndIndvs(Integer.parseInt(appnum), indvIds);
        		if (medCargoArray.length > 0) {
        			for(CP_APP_IN_MED_BILLS_Cargo cargo:medCargoArray) {
        				if(SNEX.contains(cargo.getMed_bill_type())) {
        					result1.addCargo(cargo);
        				}
        			}
        			
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.getSpecialNeeds() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return result1;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}


	public CP_APP_IN_MED_BILLS_Collection loadSpecialNeedsDtls(String appNum, Integer indv_seq_num) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.loadSpecialNeedsDtls() - START");
        try {
        	CP_APP_IN_MED_BILLS_Collection medColl = new CP_APP_IN_MED_BILLS_Collection();
        	if(appNum != null && indv_seq_num != null ) {
        		CP_APP_IN_MED_BILLS_Cargo[] medCargoArray  = cpAppInMedBillsRepository.loadSpecialNeedsDtls(Integer.parseInt(appNum),indv_seq_num);
        		if (medCargoArray.length > 0) {
        			medColl.setResults(medCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.loadSpecialNeedsDtls() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return medColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}

	public void storeSpecialNeedsDetails(CP_APP_IN_MED_BILLS_Collection medColl) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.storeSpecialNeedsDetails() - START");
        try {  	
        	if (medColl != null){
        		CP_APP_IN_MED_BILLS_Cargo medCargo = medColl.getCargo(0);
        		cpAppInMedBillsRepository.save(medCargo);
            }
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.storeSpecialNeedsDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	public void deleteSpecialNeedsDtls(String appNum, Integer indv_seq_num, String medBillType) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.deleteSpecialNeedsDtls() - START");
        try {
        	if(appNum != null && indv_seq_num != null && medBillType != null ) {
        		 cpAppInMedBillsRepository.deleteSpecialNeedsDtls(Integer.parseInt(appNum),indv_seq_num, medBillType);
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.deleteSpecialNeedsDtls() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	public void deleteSpecialNeedsData(String appNum, Integer indv_seq_num,List<String> medBillTypesList) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.deleteSpecialNeedsData() - START");
        try {
        	if(appNum != null && indv_seq_num != null ) {
        		 cpAppInMedBillsRepository.deleteSpecialNeedsData(Integer.parseInt(appNum),indv_seq_num,medBillTypesList);
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.deleteSpecialNeedsData() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
		
	
	public void updateSpecialNeedsDsec(String desc, String appNum, Integer indv_seq_num, String medBillType) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.updateSpecialNeedsDsec() - START");
        try {
        	if(desc != null && appNum != null && indv_seq_num != null && medBillType != null ) {
        		cpAppInMedBillsRepository.updateSpecialNeedDesc(desc, Integer.parseInt(appNum),indv_seq_num, medBillType);
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.updateSpecialNeedsDsec() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	public CP_APP_IN_MED_BILLS_Cargo getSpecialNeedByMedBillType(String appNum, Integer indv_seq_num, String medBillType) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.getSpecialNeedByMedBillType() - START");
        try {
        	CP_APP_IN_MED_BILLS_Cargo medCargo = new CP_APP_IN_MED_BILLS_Cargo();
        	if(appNum != null && indv_seq_num != null && medBillType != null) {
        		 medCargo  = cpAppInMedBillsRepository.getSpecialNeedByMedBillType(Integer.parseInt(appNum),indv_seq_num, medBillType);
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.getSpecialNeedByMedBillType() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return medCargo;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}


	public void deleteSpecialNeeds(String appNum, Integer indivSeqNumInt, Integer medSeqNum) {
		try {
		cpAppInMedBillsRepository.deleteSpecialNeed(Integer.parseInt(appNum),indivSeqNumInt, medSeqNum);
		} catch (final Exception e) {
			throw e;
		}
	}


	public void storeSpecialNeedPayment(CP_APP_IN_SNP_Cargo snpCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.storeSpecialNeedPayment() - START");
		try{
			cpAppInSnpRepository.save(snpCargo);
					
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			  throw e; 
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SpecialNeedsBO.storeSpecialNeedPayment() - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) );
		
		
	}


	
}
