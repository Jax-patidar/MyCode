package gov.state.nextgen.financialinformation.business.rules;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_SHLTC_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_SHLTC_Collection;
import gov.state.nextgen.financialinformation.data.db2.CpAppInShltcRepository;

@Service("ABFacilityInformationBO")
public class ABFacilityInformationBO extends AbstractBO {

	@Autowired
	private CpAppInShltcRepository shltcRepo;


	/*
	 * Created as part of CSPM-6365 to get Facility Information using appNum 
	 */
	public CP_APP_IN_SHLTC_Collection loadFacilityInformation(String appNum, List<Integer> indvIds) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABFacilityInformationBO.loadFacilityInformation() - START");
		try {
			CP_APP_IN_SHLTC_Collection appInShltcColl = new CP_APP_IN_SHLTC_Collection();
			if (appNum != null) {
				CP_APP_IN_SHLTC_Cargo[] appInShltcCargoArray = shltcRepo.findByAppNum(Integer.parseInt(appNum), indvIds);
				if (appInShltcCargoArray.length > 0) {
					appInShltcColl.setResults(appInShltcCargoArray);
				}
			}


			return appInShltcColl;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}

	/*
	 * Created as part of CSPM-6365 to store Facility Information 
	 */
	public void storeFacilityInformations(CP_APP_IN_SHLTC_Collection appInShltcColl) {


		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABFacilityInformationBO.storeFacilityInformations() - START");
		try {
			if ((appInShltcColl != null) && (!appInShltcColl.isEmpty()) && (appInShltcColl.size() > 0)) {
				CP_APP_IN_SHLTC_Cargo shltcCargo = appInShltcColl.getCargo(0);
				shltcRepo.save(shltcCargo);
			}
		}  catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}

	}

	/*
	 * Created as part of CSPM-6365 to get Facility Information using appNum and indv_seq_num
	 */
	public CP_APP_IN_SHLTC_Collection loadFacilityInformation(String appNum, Integer indv_seq_num) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABFacilityInformationBO.loadFacilityInformation() - START");
		try {
			CP_APP_IN_SHLTC_Collection appInShltcColl = new CP_APP_IN_SHLTC_Collection();
			if (appNum != null && indv_seq_num != null) {
				CP_APP_IN_SHLTC_Cargo[] appInShltcCargoArray = shltcRepo.findByAppNumIndvNum(Integer.parseInt(appNum), indv_seq_num);
				if (appInShltcCargoArray.length > 0) {
					appInShltcColl.setResults(appInShltcCargoArray);
				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABFacilityInformationBO.loadFacilityInformation() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + " milliseconds");

			return appInShltcColl;
		}catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}

	/*
	 * Created as part of CSPM-6365 to remove item on click of remove icon in HouseholdDetails Facility Summary screen
	 */
	public void deleteFacilityInformation(String appNum, Integer indvSeqNumber, String src_app_ind, Integer seq_num) {
		try {
			shltcRepo.deleteFacilityInformation(Integer.parseInt(appNum), indvSeqNumber,src_app_ind,seq_num);
		} catch (final Exception exception) {
            throw exception;
        }
	}

}
