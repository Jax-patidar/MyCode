/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;


/**
 * This java bean contains the primary keys for the table APP_IN_BURY_ASET
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Thu Feb 01 09:37:17 CST 2007 Modified By: Modified on: PCR#
 */
public class APP_IN_BURY_ASET_PrimaryKey implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private String app_num;
	private Integer indv_seq_num;
	private Integer seq_num;
	private String bury_aset_typ;

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return app_num;
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_num = app_num;
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * returns the bury_aset_typ value.
	 */
	public String getBury_aset_typ() {
		return bury_aset_typ;
	}

	/**
	 * sets the bury_aset_typ value.
	 */
	public void setBury_aset_typ(final String bury_aset_typ) {
		this.bury_aset_typ = bury_aset_typ;
	}

	/**
	 * returns the string value of cargo.
	 */
	public String inspectPrimaryKey() {
		return new StringBuilder().append("APP_IN_BURY_ASET: ").append("app_num=").append(app_num).append("indv_seq_num=").append(indv_seq_num)
				.append("seq_num=").append(seq_num).append("bury_aset_typ=").append(bury_aset_typ).toString();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((app_num == null) ? 0 : app_num.trim().hashCode());
		result = (prime * result) + ((bury_aset_typ == null) ? 0 : bury_aset_typ.trim().hashCode());
		result = (prime * result) + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = (prime * result) + ((seq_num == null) ? 0 : seq_num.hashCode());
		return result;
	}

	

}