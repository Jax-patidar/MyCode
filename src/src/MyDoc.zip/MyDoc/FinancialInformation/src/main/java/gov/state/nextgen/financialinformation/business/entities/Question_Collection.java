package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class Question_Collection extends AbstractCollection{
	
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_HSHL_RLT";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final Question_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final Question_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final Question_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public Question_Cargo[] getResults() {
		final Question_Cargo[] cbArray = new Question_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public Question_Cargo getCargo(final int idx) {
		return (Question_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public Question_Cargo[] cloneResults() {
		final Question_Cargo[] rescargo = new Question_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			rescargo[i] = new Question_Cargo();
			
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof Question_Cargo[]) {
			final Question_Cargo[] cbArray = (Question_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
