/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;


/**
 * This java bean contains the primary keys for the table APP_IN_P_PROP_ASET
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Thu Feb 01 09:37:05 CST 2007 Modified By: Modified on: PCR#
 */
public class APP_IN_P_PROP_ASET_PrimaryKey implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private Integer app_number;
	private Integer indv_seq_num;
	private Integer seq_num;
	private String prsn_prop_aset_typ;
	


	public Integer getApp_number() {
		return app_number;
	}

	public void setApp_number(final Integer app_number) {
		this.app_number = app_number;
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * returns the prsn_prop_aset_typ value.
	 */
	public String getPrsn_prop_aset_typ() {
		return prsn_prop_aset_typ;
	}

	/**
	 * sets the prsn_prop_aset_typ value.
	 */
	public void setPrsn_prop_aset_typ(final String prsn_prop_aset_typ) {
		this.prsn_prop_aset_typ = prsn_prop_aset_typ;
	}
	

	/**
	 * returns the string value of cargo.
	 */
	public String inspectPrimaryKey() {
		return new StringBuilder().append("APP_IN_P_PROP_ASET: ").append("app_num=").append(app_number).append("indv_seq_num=").append(indv_seq_num)
				.append("seq_num=").append(seq_num).append("prsn_prop_aset_typ=").append(prsn_prop_aset_typ).toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((prsn_prop_aset_typ == null) ? 0 : prsn_prop_aset_typ.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		
		return result;
	}
@SuppressWarnings("squid:S3776")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		APP_IN_P_PROP_ASET_PrimaryKey other = (APP_IN_P_PROP_ASET_PrimaryKey) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		if (prsn_prop_aset_typ == null) {
			if (other.prsn_prop_aset_typ != null)
				return false;
		} else if (!prsn_prop_aset_typ.equals(other.prsn_prop_aset_typ))
			return false;
		if (seq_num == null) {
			if (other.seq_num != null)
				return false;
		} else if (!seq_num.equals(other.seq_num))
			return false;
		
		return true;
	}

	

}