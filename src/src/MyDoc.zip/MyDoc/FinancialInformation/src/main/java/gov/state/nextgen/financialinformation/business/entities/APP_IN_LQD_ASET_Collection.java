package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_IN_LQD_ASET_Collection extends AbstractCollection {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7989700777371180547L;
	/**
	 *
	 */

	private static final String PACKAGE = "gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_LQD_ASET_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_LQD_ASET_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_LQD_ASET_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_LQD_ASET_Cargo[] getResults() {
		final APP_IN_LQD_ASET_Cargo[] cbArray = new APP_IN_LQD_ASET_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_LQD_ASET_Cargo getCargo(final int idx) {
		return (APP_IN_LQD_ASET_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_LQD_ASET_Cargo[] cloneResults() {
		final APP_IN_LQD_ASET_Cargo[] rescargo = new APP_IN_LQD_ASET_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_LQD_ASET_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_LQD_ASET_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setSeq_num(cargo.getSeq_num());
			rescargo[i].setAcct_num(cargo.getAcct_num());
			rescargo[i].setBury_dsgt_sw(cargo.getBury_dsgt_sw());
			rescargo[i].setFncl_inst_city_adr(cargo.getFncl_inst_city_adr());
			rescargo[i].setFncl_inst_l1_adr(cargo.getFncl_inst_l1_adr());
			rescargo[i].setFncl_inst_l2_adr(cargo.getFncl_inst_l2_adr());
			rescargo[i].setFncl_inst_nam(cargo.getFncl_inst_nam());
			rescargo[i].setFncl_inst_sta_adr(cargo.getFncl_inst_sta_adr());
			rescargo[i].setFncl_inst_zip_adr(cargo.getFncl_inst_zip_adr());
			rescargo[i].setJnt_own_resp(cargo.getJnt_own_resp());
			rescargo[i].setLqd_aset_amt(cargo.getLqd_aset_amt());
			rescargo[i].setLqd_aset_amt_ind(cargo.getLqd_aset_amt_ind());
			rescargo[i].setLqd_aset_typ(cargo.getLqd_aset_typ());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setSchool_expenses_ind(cargo.getSchool_expenses_ind());
			rescargo[i].setFirst_name(cargo.getFirst_name());
			rescargo[i].setLast_name(cargo.getLast_name());
			rescargo[i].setAccount_maintainence_reason_cd(cargo.getAccount_maintainence_reason_cd());
			rescargo[i].setBusiness_trade_farming_ind(cargo.getBusiness_trade_farming_ind());
			rescargo[i].setAccount_acquired_dt(cargo.getAccount_acquired_dt());
			rescargo[i].setLiquid_asset_sub_type_cd(cargo.getLiquid_asset_sub_type_cd());
			rescargo[i].setEcp_id(cargo.getEcp_id());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
			rescargo[i].setChg_dt(cargo.getChg_dt());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_LQD_ASET_Cargo[]) {
			final APP_IN_LQD_ASET_Cargo[] cbArray = (APP_IN_LQD_ASET_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
