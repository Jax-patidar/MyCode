package gov.state.nextgen.financialinformation.business.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_P_PROP_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_P_PROP_ASET_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppInPPropAssetRepository;

@Service("OtherAssetBO")
public class OtherAssetBO {

	@Autowired
	private AppInPPropAssetRepository appInPPropAssetRepository;

	public APP_IN_P_PROP_ASET_Collection loadOtherAssetDetails(String appNumber, Integer indivSeqNum, Integer seqNum,
			String type) {

		try {
			final APP_IN_P_PROP_ASET_Collection appOtherColl = appInPPropAssetRepository
					.getByAppNum_IndSeq_SeqNum_Type(Integer.parseInt(appNumber), indivSeqNum, seqNum, type);

			return appOtherColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	public void storeOtherResourcesDetails(APP_IN_P_PROP_ASET_Collection appInShltcColl) {

		try {
			if (null != appInShltcColl && !appInShltcColl.isEmpty()) {
				appInPPropAssetRepository.save(appInShltcColl.getCargo(0));
			}
		} catch (final Exception e) {
			throw e;
		}

	}
	
	

	public void validateJntOwnerPerc(APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		// TODO Auto-generated method stub

	}

	public void validatePageContents(APP_IN_P_PROP_ASET_Cargo shltcCargoReq, String langCD, boolean updatePage) {
		// TODO Auto-generated method stub

	}
	
	public APP_IN_P_PROP_ASET_Collection loadPPropertyAssetDetails(String appNumber) {

		try {
			return appInPPropAssetRepository.getPPropByAppNum(Integer.parseInt(appNumber));

		} catch (final Exception e) {
			throw e;
		}
	}
	
	public APP_IN_P_PROP_ASET_Collection loadPersonalPropertyDetails(String type, String appNum) {
		FwLogger.log(this.getClass(), Level.INFO, "OtherAssetBO.loadPersonalPropertyDetails() - START");
		APP_IN_P_PROP_ASET_Collection appInPPropAsetColl = new APP_IN_P_PROP_ASET_Collection();
		APP_IN_P_PROP_ASET_Cargo[] appInPPropAsetCargoArr = null;
		try {
			if ((null != appNum && !appNum.isEmpty()) && (null != type && !type.isEmpty())) {
				appInPPropAsetCargoArr = appInPPropAssetRepository.getByPAppNumPropAssetType(Integer.parseInt(appNum), type);
			} else {
				appInPPropAsetCargoArr = appInPPropAssetRepository.getByPAppNum(Integer.parseInt(appNum));
			}
			if (null != appInPPropAsetCargoArr && appInPPropAsetCargoArr.length > 0) {
				appInPPropAsetColl.setResults(appInPPropAsetCargoArr);
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetBO.loadPersonalPropertyDetails() - END");
		return appInPPropAsetColl;
	}
	
	public void savePersonalPropertyDetails(APP_IN_P_PROP_ASET_Cargo propAsetCargo) {
		FwLogger.log(this.getClass(), Level.INFO, "OtherAssetBO.savePersonalPropertyDetails() - START");
		try {
			if (null != propAsetCargo) {
				appInPPropAssetRepository.save(propAsetCargo);
			}
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetBO.savePersonalPropertyDetails() - END");
	}
	
	public void removePersonalPropertyDetails(String personalPropertyAssetType, String appNum) {
		FwLogger.log(this.getClass(), Level.INFO, "OtherAssetBO.removePersonalPropertyDetails() - START");
		try {
			appInPPropAssetRepository.deletePropertyDetailsByAppNumType(personalPropertyAssetType, Integer.parseInt(appNum));
		} catch (FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			throw fe;
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetBO.removePersonalPropertyDetails() - END");
	}

}
