/*
 * 
 */
package gov.state.nextgen.financialinformation.business.rules;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.access.management.references.ReferenceTableManager;
import gov.state.nextgen.access.management.util.FWUtils;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_R_PROP_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_R_PROP_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SPS_IMPOV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SPS_IMPOV_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInJntOwnRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInRealPropertyRepository;


@Service("RealPropertyBO")
public class RealPropertyBO extends AbstractBO{

	
	@Autowired
	private AppInJntOwnRepository appInJntOwnRepository;
	
	
	@Autowired
	private AppInRealPropertyRepository appInRealPropertyRepository;
	/**
	 * Constructor
	 */



	public int getMaxJntSeqNumber(final String aAppNum, final Integer indvSeqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "RealPropertyBO.getMaxJntSeqNumber) - START");
		int maxSeqNum = 0;
		
		try {
			final List res = appInJntOwnRepository.getMaxJntSeqNumber(Integer.parseInt(aAppNum), indvSeqNum);			
			
			if (null!=res && res.size()>0 && null!=res.get(0)) {
				maxSeqNum = Integer.parseInt(res.get(0).toString());
			}
		
			FwLogger.log(this.getClass(), Level.INFO, "RealPropertyBO.getMaxJntSeqNumber - END , Time Taken : " + (System.currentTimeMillis() - startTime) + " milliseconds");
			return maxSeqNum;
		}  catch (final Exception e) {
			throw e;
		}

	}
	
	public static FwException createFwException(final String className, final String methodName, final Exception e) {
		final FwException fe = FwExceptionManager.createFwException(className, methodName, e);
		return fe;
	}



	public APP_IN_R_PROP_ASET_Collection loadIndividualRealPropertyDetails(String appNumber, Integer indivSeqNum,
			Integer seqNum) {


		try {
			final APP_IN_R_PROP_ASET_Collection appInColl= appInRealPropertyRepository.getByAppNum_IndSeq(Integer.parseInt(appNumber), indivSeqNum, seqNum);

			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}



	public APP_IN_R_PROP_ASET_Collection storeRealPropertyDetails(APP_IN_R_PROP_ASET_Collection appInRPropAsetColl) {


		APP_IN_R_PROP_ASET_Collection appInUpColl = new APP_IN_R_PROP_ASET_Collection();
		try {
			if (null!=appInRPropAsetColl && !appInRPropAsetColl.isEmpty()) {
				APP_IN_R_PROP_ASET_Cargo cargo = appInRealPropertyRepository.save(appInRPropAsetColl.getCargo(0));
				appInUpColl.add(cargo);
			}

			return appInUpColl;
		} catch (final Exception e) {
			throw e;
		}
	}



	public String completenessCheck(APP_IN_R_PROP_ASET_Cargo iCargo) {


			String completeIndicator = "0";
			String landIndicator = "1";

			if (((iCargo != null)
					&& ("HO".equals(iCargo.getReal_prop_aset_typ()) || "LD".equals(iCargo.getReal_prop_aset_typ()) || "OR".equals(iCargo.getReal_prop_aset_typ())))
					&& (((iCargo.getProperty_currently_rented_ind() == null) || FinancialInfoConstants.SPACE.equals(iCargo.getProperty_currently_rented_ind()))
							&& ((iCargo.getProperty_producing_income_ind() == null) || FinancialInfoConstants.SPACE.equals(iCargo.getProperty_producing_income_ind()))
							&& ((iCargo.getProperty_rented_for_sale_ind() == null) ||FinancialInfoConstants.SPACE.equals(iCargo.getProperty_rented_for_sale_ind())))) {
				
					landIndicator = "0";
				
			}
			if ((iCargo != null) && null!=iCargo.getNum_acres() && (!"0".equals(iCargo.getNum_acres().toString().trim())) && "1".equals(landIndicator)) {
				completeIndicator = "1";
			}

			return completeIndicator;
	}


	public boolean isValidSpouseAddress(final APP_IN_SPS_IMPOV_Collection aAppInSpsColl) {


			boolean spsAddrFlg = false;
			if ((aAppInSpsColl != null) && (!aAppInSpsColl.isEmpty())) {
				final APP_IN_SPS_IMPOV_Cargo appInSpsCargo = aAppInSpsColl.getCargo(0);
				if ((appInSpsCargo.getSps_l1_adr() != null) && (appInSpsCargo.getSps_l1_adr().trim().length() > 0)) {
					spsAddrFlg = true;
				}
			}

			return spsAddrFlg;
	}
	
	public FwMessageList validateRealPropertyDetails(final APP_IN_R_PROP_ASET_Collection appInRAsetColl,
			final APP_IN_R_PROP_ASET_Collection appInRPropAsetBeforeColl, String dob, final Map request) {

		try {
			final APP_IN_R_PROP_ASET_Cargo appInPCargo = appInRAsetColl.getCargo(0);
			appInPCargo.getReal_prop_aset_typ();

			
			dob = dateRoutine.convertSimpleDateFormat(dob);
			final StringBuilder dateConverter = new StringBuilder();
			final String sAppDate = dob;
			dateConverter.append(sAppDate.substring(6, 10)).append("-").append(sAppDate.substring(0, 2)).append("-").append(sAppDate.substring(3, 5));
		
			final IReferenceTableManager iref = ReferenceTableManager
					.getInstance();
			final String language = (String) request.get(AppConstants.LANGUAGE);
			final String propertyTypeCode = appInRPropAsetBeforeColl.size()>0?appInRPropAsetBeforeColl.getCargo(0).getReal_prop_aset_typ():null;
			final Object[] propertyType =null!=propertyTypeCode? new Object[] { FWUtils
					.getHtmlString(iref.getColumnValue("TROP", 101,
							propertyTypeCode, language)) }:null;
			
			validateRealAcrs(appInPCargo);

				

			validateRealDet(appInPCargo, propertyType);

			// Please enter only letters for
			// City.
			if (!appMgr.isFieldEmpty(appInPCargo.getProp_city_adr()) && !appMgr.isAlphaWithSpace(appInPCargo.getProp_city_adr())) {
				addMessageCode("00018");
			}
			// Please select State.
			if (appMgr.isFieldEmpty(appInPCargo.getProp_sta_adr()) || "AA".equalsIgnoreCase(appInPCargo.getProp_sta_adr())
					|| FwConstants.DEFAULT_DROPDOWN_SEL.equalsIgnoreCase(appInPCargo.getProp_sta_adr())) {

				addMessageCode("00028");
			}
			// Please enter numeric Zip Code & Zip Code cannot be all zeros.
			if (appMgr.isFieldEmpty(appInPCargo.getProp_zip_adr())) {

				addMessageCode("00019");
			} else {
				if (!appMgr.isInteger(appInPCargo.getProp_zip_adr())) {
					addMessageCode("00019");
				} else if (!(appInPCargo.getProp_zip_adr().length() == 5)) {
					addMessageCode("10501");
				} else if (("00000".equals(appInPCargo.getProp_zip_adr()) || "000000000".equals(appInPCargo.getProp_zip_adr()))) {
					addMessageCode("00022");
				}
			}			

		} catch (final Exception e) {
			throw e;
		}
		return null;
	}

	public void validateRealDet(final APP_IN_R_PROP_ASET_Cargo appInPCargo, final Object[] propertyType) {
		try {
		if (appMgr.isFieldEmpty(appInPCargo.getIndividual_live_ind())) {
			this.addMessageWithFieldValues("00606", propertyType);
		}

		if ((appMgr.isFieldEmpty(appInPCargo.getProp_l1_adr()))) {
			addMessageCode("00026");
		}
		if (appMgr.isFieldEmpty(appInPCargo.getProp_city_adr())) {
			addMessageCode("00027");
		}

		if (!appMgr.isFieldEmpty(appInPCargo.getProp_l1_adr())
				&& !appMgr.isSpecialAlphaNumeric(appInPCargo.getProp_l1_adr(), FinancialInfoConstants.SPECIAL_CHAR_FOR_ADDR)) {

			addMessageCode("00017");
		}
		if (!appMgr.isFieldEmpty(appInPCargo.getProp_l2_adr())
				&& !appMgr.isSpecialAlphaNumeric(appInPCargo.getProp_l2_adr(), FinancialInfoConstants.SPECIAL_CHAR_FOR_ADDR)) {

			addMessageCode("00017");
		}
		} catch (final Exception e) {
			throw e;
		}
	}
	@SuppressWarnings("squid:S3776")
	public void validateRealAcrs(final APP_IN_R_PROP_ASET_Cargo appInPCargo) {
		try {
		if (null!=(appInPCargo.getNum_acres())) {
			if (!appMgr.isCurrency(appInPCargo.getNum_acres())) {
				addMessageCode("98034");
			} else if (((appInPCargo.getNum_acres()) < 0) || ((appInPCargo.getNum_acres()) > 9999999.99)) {
				addMessageCode("98035");
			} 
		}
		if (null==appInPCargo.getProp_fmv_amt()) {
			if (!appMgr.isCurrency(appInPCargo.getProp_fmv_amt())) {
				final Object[] error = new Object[] { new FwMessageTextLabel("3018224") };
				this.addMessageWithFieldValues("10241", error);
			} else if (((appInPCargo.getProp_fmv_amt()) < 0)
					|| ((appInPCargo.getProp_fmv_amt()) > 9999999.99)) {					
				addMessageCode("98028");
			}
		}

		if (null==appInPCargo.getProp_owe_amt()) {
			if (!appMgr.isCurrency(appInPCargo.getProp_owe_amt())) {
				final Object[] error = new Object[] { new FwMessageTextLabel("3018226") };
				this.addMessageWithFieldValues("10241", error);
			} else if (((appInPCargo.getProp_owe_amt()) < 0)
					|| ((appInPCargo.getProp_owe_amt()) > 9999999.99)) {
				addMessageCode("98033");
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public APP_IN_R_PROP_ASET_Collection loadRealPropertyDetails(String appNumber) {

		try {
			return appInRealPropertyRepository.getRealPropertyByAppNum(Integer.parseInt(appNumber));

		} catch (final Exception e) {
			throw e;
		}
	}
	
	public void saveOwnPropertyDetails(APP_IN_R_PROP_ASET_Collection propAsetColl) {
		try {
			if (propAsetColl != null && !propAsetColl.isEmpty()) {
				appInRealPropertyRepository.save(propAsetColl.getCargo(0));
			}
		}catch (final Exception exception) {
            throw exception;
        }	
		
	}
	
	public void removeOwnPropertyDetails(String appNumber, Integer indvSeqNum, Integer seqNum, String ownAssetType) {
		try {
			appInRealPropertyRepository.deletePropertyDetails(Integer.parseInt(appNumber),indvSeqNum,seqNum,ownAssetType);
		} catch (final Exception exception) {
            throw exception;
        }	
		
	}
	public APP_IN_R_PROP_ASET_Collection loadPropertyDetails(String appNumber) {

		try {
			return appInRealPropertyRepository.getPropertyByAppNum(Integer.parseInt(appNumber));

		} catch (Exception e) {
			FwException fe = new FwException();
        	fe = FwExceptionManager.createFwException(this.getClass().getName(), fe.getStackTrace()[0].getMethodName(), e);
        	throw fe;
		}
	}
	/***
	 * Method for getting real property details based on appNum.
	 * @param appNumber
	 * @return
	 */
	public APP_IN_R_PROP_ASET_Collection loadRealPropertyDetailsMC(String appNumber) {

		try {
			return appInRealPropertyRepository.getRealPropertyByAppNumMC(Integer.parseInt(appNumber));

		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(), "loadRealPropertyDetailsMC", e);
		}
	}
	/***
	 * Method to fetch individual real property detail based on appNum, IndvSeqNum, SeqNum.
	 * @param appNumber
	 * @param indvSeqNum
	 * @param seqNum
	 * @return
	 */
	public APP_IN_R_PROP_ASET_Collection loadIndividualRealPropertyDetailsMC(String appNumber, Integer indvSeqNum, Integer seqNum) {

		try { 
			final APP_IN_R_PROP_ASET_Collection appInColl = new APP_IN_R_PROP_ASET_Collection(); 
			final APP_IN_R_PROP_ASET_Cargo[] appInCargoArray = appInRealPropertyRepository.getIndividualRealPropertyDetails(Integer.parseInt(appNumber),indvSeqNum,seqNum); 
			if(appInCargoArray != null && appInCargoArray.length > 0) { 
				appInColl.setResults(appInCargoArray); 
			} 
			return appInColl;

		} catch (final Exception e) {
			throw createFwException(this.getClass().getName(),"loadIndividualRealPropertyDetails", e); 
		}

	}
	 
}
