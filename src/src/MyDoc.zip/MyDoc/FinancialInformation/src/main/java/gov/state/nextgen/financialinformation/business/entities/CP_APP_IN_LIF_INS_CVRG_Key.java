/**
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * @author khuskumari
 * Key class for CP_APP_IN_LIF_INS_CVRG
 *
 */
@Embeddable
public class CP_APP_IN_LIF_INS_CVRG_Key implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String app_num;
	private Integer indv_seq_num;
	private Integer seq_num;
	private String src_app_ind;
	private Integer covered_seq_num;
	
	public CP_APP_IN_LIF_INS_CVRG_Key() {
		
	}

	/**
	 * @param app_num
	 * @param indv_seq_num
	 * @param seq_num
	 * @param src_app_ind
	 * @param covered_seq_num
	 */
	public CP_APP_IN_LIF_INS_CVRG_Key(String app_num, Integer indv_seq_num, Integer seq_num, String src_app_ind,
			Integer covered_seq_num) {
		super();
		this.app_num = app_num;
		this.indv_seq_num = indv_seq_num;
		this.seq_num = seq_num;
		this.src_app_ind = src_app_ind;
		this.covered_seq_num = covered_seq_num;
	}

}
