package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.RedetMCExpensesIndvDetails_Cargo;
import gov.state.nextgen.financialinformation.business.entities.RedetMCExpensesIndvDetails_Collection;
import gov.state.nextgen.financialinformation.business.entities.RedetMCExpensesReviewDetails;
import gov.state.nextgen.financialinformation.business.rules.CareCostBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInHouRepository;
import gov.state.nextgen.financialinformation.data.db2.CP_ABCHS_Repository;
import gov.state.nextgen.financialinformation.data.db2.CP_APP_IN_DEDUCTION_Repository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInIncomeTaxDedRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInMedBillsRepository;
import gov.state.nextgen.framework.business.model.IndividualCategorySequenceDetails;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.framework.business.model.UserDetails;

/**
 * Redetermination MC flow Expenses Service Implementation
 * 
 * @author Saravanan Balasubramaniam
 *
 */

@Service("RedetMCExpensesServiceImpl")
public class RedetMCExpensesServiceImpl implements FinancialServInterface {

	@Autowired
	CareCostBO careCostBO;

	@Autowired
	CpAppInIncomeTaxDedRepository cpAppInIncomeTaxDedRepository;

	@Autowired
	AppInHouRepository appInHouRepository;

	@Autowired
	CpAppInMedBillsRepository cpAppInMedBillsRepository;

	@Autowired
	private CP_APP_IN_DEDUCTION_Repository cpAppIndeductionRepository;

	@Autowired
	private CP_ABCHS_Repository careCostRepository;

	private static final String LOAD_EXPENSE_REVIEW = "loadRedetMCExpenseReviewData";

	private static final String STORE_EXPENSE_DETAILS = "storeRedetMCExpenseDetails";

	private static final String LOAD_EXPENSE_SUMMARY = "loadRedetMCExpenseSummaryData";

	private static final String REMOVE_EXPENSE_DETAILS = "removeRedetMCExpenseDetails";

	private static final String COMMA_SEPERATOR = ",";

	private static final String HOUSING_BILLS_EXPENSE = "HOUSING_BILLS_EXPENSE";

	private static final String MED_BILLS_EXPENSE = "MED_BILLS_EXPENSE";

	private static final String APP_IN_DEDUCTION_EXPENSE = "APP_IN_DEDUCTION_EXPENSE";

	private static final String CARE_COST_EXPENSE = "CARE_COST_EXPENSE";

	private static final String INCOME_TAX_DED_EXPENSE = "INCOME_TAX_DED_EXPENSE";

	private static final String REDET_MC_INDV_COLLECTION = "RedetMCExpensesIndvDetails_Collection";

	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {
		switch (methodName) {
		case LOAD_EXPENSE_REVIEW:
			this.loadRedetMCExpenseReviewData(txnBean);
			break;
		case STORE_EXPENSE_DETAILS:
			this.storeRedetMCExpenseDetails(txnBean);
			break;
		case LOAD_EXPENSE_SUMMARY:
			this.loadRedetMCExpenseSummaryData(txnBean);
			break;
		case REMOVE_EXPENSE_DETAILS:
			this.removeRedetMCExpenseDetails(txnBean);
			break;
		default:
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "No Service called");
		}

	}

	/**
	 * loadRedetMCExpenseReviewData method is used to process and fetch all the
	 * Expenses related data for the specified appNum
	 * 
	 * @param txnBean
	 */
	public void loadRedetMCExpenseReviewData(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "RedetMCExpensesServiceImpl.loadRedetMCExpenseReviewData() - START");
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			List<Integer> indvIdList = new ArrayList<>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("indvIds");
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList = new ArrayList<>();

			getHousingBillsDetails(appNum, reviewIndvDetailsList, indvIdList);
			getAppInDeductionDetails(appNum, reviewIndvDetailsList, indvIdList);
			getMedBillsDetails(appNum, reviewIndvDetailsList, indvIdList);
			getCareCostDetails(appNum, reviewIndvDetailsList, indvIdList);
			getIncomeTaxDedDetails(appNum, reviewIndvDetailsList, indvIdList);

			Map<String, List<RedetMCExpensesIndvDetails_Cargo>> resultData = reviewIndvDetailsList.stream()
					.collect(Collectors.groupingBy(RedetMCExpensesIndvDetails_Cargo::getExpenseType));

			List<RedetMCExpensesReviewDetails> reviewDetailsList = new ArrayList<>();
			resultData.forEach((key, value) -> {
				RedetMCExpensesReviewDetails reviewDetails = new RedetMCExpensesReviewDetails();
				reviewDetails.setExpenseType(key);
				reviewDetails.setIndvDetails(value);
				reviewDetailsList.add(reviewDetails);
			});

			pageCollection.put("APP_IN_EXPENSE_Collection", reviewDetailsList);
			pageCollection.put("ExpenseMaxSeqNum", reviewIndvDetailsList.size());

			FwLogger.log(this.getClass(), Level.INFO,
					"RedetMCExpensesServiceImpl::loadRedetMCExpenseReviewData() - End");

		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(), LOAD_EXPENSE_REVIEW,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO,
				"RedetMCExpensesServiceImpl::loadRedetMCExpenseReviewData() - End , Time Taken : "
						+ (System.currentTimeMillis() - startTime));

	}

	/**
	 * getHousingBillsDetails method is used to fetch data from
	 * APP_IN_HOU_BILLS_Cargo and set it in RedetMCExpensesReviewIndvDetails class
	 * 
	 * @param appNum
	 * @param reviewIndvDetailsList
	 * @param indvIdList 
	 */
	private void getHousingBillsDetails(String appNum, List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList, List<Integer> indvIdList) {
		try {
			APP_IN_HOU_BILLS_Collection housingExpenseColl = appInHouRepository.getHouBillsExpenseReviewDetails(Integer.parseInt(appNum), indvIdList);
			generateHousingBillsIndvDetails(reviewIndvDetailsList, housingExpenseColl);
		} catch (final Exception e) {
			throw e;
		}
	}

	private void generateHousingBillsIndvDetails(List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList,
			APP_IN_HOU_BILLS_Collection housingExpenseColl) {
		try {
			for (int i = 0; i < housingExpenseColl.size(); i++) {
				APP_IN_HOU_BILLS_Cargo housingBillsCargo = housingExpenseColl.getCargo(i);
				RedetMCExpensesIndvDetails_Cargo reviewDetails = new RedetMCExpensesIndvDetails_Cargo();
				reviewDetails.setIndvSeqNum(housingBillsCargo.getIndv_seq_num());
				reviewDetails.setPaymentAmount(getPaymentAmount(housingBillsCargo.getPymt_amt()));
				reviewDetails.setPaymentFrequency(housingBillsCargo.getPymt_freq());
				reviewDetails.setExpenseType(housingBillsCargo.getBill_type());
				reviewDetails.setSeqNum(housingBillsCargo.getSeq_num());
				reviewIndvDetailsList.add(reviewDetails);
			}
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * getAppInDeductionDetails method is used to fetch data from
	 * CP_APP_IN_DEDUCTION_Cargo and set it in RedetMCExpensesReviewIndvDetails
	 * class
	 * 
	 * @param appNum
	 * @param reviewIndvDetailsList
	 * @param indvIdList 
	 */
	private void getAppInDeductionDetails(String appNum, List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList, List<Integer> indvIdList) {
		try {
			CP_APP_IN_DEDUCTION_Collection appInDeductionColl = cpAppIndeductionRepository
					.getDeductionExpenseReviewDetails(Integer.parseInt(appNum), indvIdList);
			generateAppInDeductionIndvDetails(reviewIndvDetailsList, appInDeductionColl);
		} catch (final Exception e) {
			throw e;
		}
	}

	private void generateAppInDeductionIndvDetails(List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList,
			CP_APP_IN_DEDUCTION_Collection appInDeductionColl) {
		try {
			for (int i = 0; i < appInDeductionColl.size(); i++) {
				CP_APP_IN_DEDUCTION_Cargo appInDeductionCargo = appInDeductionColl.getCargo(i);
				RedetMCExpensesIndvDetails_Cargo reviewDetails = new RedetMCExpensesIndvDetails_Cargo();
				reviewDetails.setIndvSeqNum(appInDeductionCargo.getIndv_seq_num());
				reviewDetails.setSeqNum(appInDeductionCargo.getSeq_num());
				reviewDetails.setPaymentAmount(getPaymentAmount(appInDeductionCargo.getExp_amt()));
				reviewDetails.setPaymentFrequency(appInDeductionCargo.getPay_freq_cd());
				reviewDetails.setExpenseType(appInDeductionCargo.getExp_typ());
				if ("CA".equals(appInDeductionCargo.getExp_typ())) {
					reviewDetails.setDivorceDate(appInDeductionCargo.getDivorce_dt());
				}
				if ("OT".equals(appInDeductionCargo.getExp_typ())) {
					reviewDetails.setOtherExpenseType(appInDeductionCargo.getOtherExpenseType());
				}
				reviewIndvDetailsList.add(reviewDetails);
			}
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * getMedBillsDetails method is used to fetch data from
	 * CP_APP_IN_MED_BILLS_Cargo and set it in RedetMCExpensesReviewIndvDetails
	 * class
	 * 
	 * @param appNum
	 * @param reviewIndvDetailsList
	 * @param indvIdList 
	 */
	private void getMedBillsDetails(String appNum, List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList, List<Integer> indvIdList) {
		try {
			CP_APP_IN_MED_BILLS_Collection appInMedBillsColl = cpAppInMedBillsRepository
					.getMedBillsExpenseReviewDetails(Integer.parseInt(appNum), indvIdList);
			generateMedBillsIndvDetails(reviewIndvDetailsList, appInMedBillsColl);
		} catch (final Exception e) {
			throw e;
		}
	}

	private void generateMedBillsIndvDetails(List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList,
			CP_APP_IN_MED_BILLS_Collection appInMedBillsColl) {
		try {
			for (int i = 0; i < appInMedBillsColl.size(); i++) {
				CP_APP_IN_MED_BILLS_Cargo appInMedBillsCargo = appInMedBillsColl.getCargo(i);
				RedetMCExpensesIndvDetails_Cargo reviewDetails = new RedetMCExpensesIndvDetails_Cargo();
				reviewDetails.setIndvSeqNum(appInMedBillsCargo.getIndv_seq_num());
				reviewDetails.setSeqNum(appInMedBillsCargo.getMedical_seq_num());
				reviewDetails.setPaymentAmount(getPaymentAmount(appInMedBillsCargo.getPayment_amt()));
				reviewDetails.setPaymentFrequency(appInMedBillsCargo.getPay_freq());
				reviewDetails.setExpenseType(appInMedBillsCargo.getMed_bill_type());
				reviewIndvDetailsList.add(reviewDetails);
			}
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * getCareCostDetails method is used to fetch data from CP_ABCHS_Cargo and set
	 * it in RedetMCExpensesReviewIndvDetails class
	 * 
	 * @param appNum
	 * @param reviewIndvDetailsList
	 * @param indvIdList 
	 */
	private void getCareCostDetails(String appNum, List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList, List<Integer> indvIdList) {
		try {
			CP_ABCHS_Collection careCostColl = careCostRepository.getCareCostExpenseReviewDetails(Integer.parseInt(appNum), indvIdList);
			generateCareCostIndvDetails(reviewIndvDetailsList, careCostColl);
		} catch (final Exception e) {
			throw e;
		}
	}

	private void generateCareCostIndvDetails(List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList,
			CP_ABCHS_Collection careCostColl) {
		try {
			for (int i = 0; i < careCostColl.size(); i++) {
				CP_ABCHS_Cargo careCostCargo = careCostColl.getCargo(i);
				RedetMCExpensesIndvDetails_Cargo reviewDetails = new RedetMCExpensesIndvDetails_Cargo();
				reviewDetails.setIndvSeqNum(careCostCargo.getIndv_seq_num());
				reviewDetails.setSeqNum(careCostCargo.getSeq_num());
				reviewDetails.setPaymentAmount(getPaymentAmount(careCostCargo.getDpnd_care_exp_amt()));
				reviewDetails.setPaymentFrequency(careCostCargo.getPay_freq());
				reviewDetails.setExpenseType(StringUtils.isNotEmpty(careCostCargo.getDpnd_care_exp_ind())
						? careCostCargo.getDpnd_care_exp_ind()
						: FinancialInfoConstants.DC_E_TYPE);
				reviewIndvDetailsList.add(reviewDetails);
			}
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * getIncomeTaxDedDetails method is used to fetch data from
	 * CP_APP_IN_INCOME_TAX_DED_Cargo and set it in RedetMCExpensesReviewIndvDetails
	 * class
	 * 
	 * @param appNum
	 * @param reviewIndvDetailsList
	 * @param indvIdList 
	 */
	private void getIncomeTaxDedDetails(String appNum, List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList, List<Integer> indvIdList) {
		try {
			CP_APP_IN_INCOME_TAX_DED_Collection incomeTaxDedColl = cpAppInIncomeTaxDedRepository
					.getIncomeDedExpenseReviewDetails(Integer.parseInt(appNum), indvIdList);

			generateIncomeTaxDedIndvDetails(reviewIndvDetailsList, incomeTaxDedColl);
		} catch (final Exception e) {
			throw e;
		}
	}

	private void generateIncomeTaxDedIndvDetails(List<RedetMCExpensesIndvDetails_Cargo> reviewIndvDetailsList,
			CP_APP_IN_INCOME_TAX_DED_Collection incomeTaxDedColl) {
		try {
			for (int i = 0; i < incomeTaxDedColl.size(); i++) {
				CP_APP_IN_INCOME_TAX_DED_Cargo incomeTaxDedCargo = incomeTaxDedColl.getCargo(i);
				RedetMCExpensesIndvDetails_Cargo reviewDetails = new RedetMCExpensesIndvDetails_Cargo();
				reviewDetails.setIndvSeqNum(incomeTaxDedCargo.getIndv_seq_num());
				reviewDetails.setSeqNum(incomeTaxDedCargo.getSeq_num());
				reviewDetails.setPaymentAmount(getPaymentAmount(incomeTaxDedCargo.getAlimony_exp()));
				reviewDetails.setPaymentFrequency(incomeTaxDedCargo.getPay_freq());
				reviewDetails.setExpenseType(incomeTaxDedCargo.getExp_type());
				reviewIndvDetailsList.add(reviewDetails);
			}
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * getPaymentAmount method is used to validate whether the amount is not null
	 * 
	 * @param paymentAmount
	 * @return Double
	 */
	private Double getPaymentAmount(Double paymentAmount) {
		return Objects.nonNull(paymentAmount) ? paymentAmount : 0;
	}

	/**
	 * storeRedetMCExpenseDetails method is used to process the data based on the
	 * expense type and store in respective tables
	 * 
	 * @param txnBean
	 */
	public void storeRedetMCExpenseDetails(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "RedetMCExpensesServiceImpl.storeRedetMCExpenseDetails() - START");

		try {
			final Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String appNum = userDetails.getAppNumber();
			Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			RedetMCExpensesIndvDetails_Collection collections = (RedetMCExpensesIndvDetails_Collection) pageCollection
					.get(REDET_MC_INDV_COLLECTION);
			RedetMCExpensesIndvDetails_Cargo reviewDetails = collections.getCargo(0);
			txnBean.setPageCollection(new HashMap<>());
			String specifiedExpenseCargo = getSpecifiedExpenseCargo(reviewDetails.getExpenseType());
			switch (specifiedExpenseCargo) {
			case HOUSING_BILLS_EXPENSE:
				storeHousingBillsData(appNum, indvSeqNum, seqNum, reviewDetails);
				break;
			case MED_BILLS_EXPENSE:
				storeMedBillsData(appNum, indvSeqNum, seqNum, reviewDetails);
				break;
			case APP_IN_DEDUCTION_EXPENSE:
				storeAppInDeductionData(appNum, indvSeqNum, seqNum, reviewDetails);
				break;
			case CARE_COST_EXPENSE:
				storeCareCostData(appNum, indvSeqNum, seqNum, reviewDetails);
				break;
			case INCOME_TAX_DED_EXPENSE:
				storeIncomeTaxDedData(appNum, indvSeqNum, seqNum, reviewDetails);
				break;
			default:
				break;
			}

		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(), STORE_EXPENSE_DETAILS,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO,
				"RedetMCExpensesServiceImpl::storeRedetMCExpenseDetails() - End , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}

	private String getSpecifiedExpenseCargo(String expenseType) {
		try {
			List<String> housingBillTypeList = Arrays
					.asList(FinancialInfoConstants.HOUSING_BILLS_TYPE.split(COMMA_SEPERATOR));
			List<String> medBillsTypeList = Arrays.asList(FinancialInfoConstants.MED_BILLS_TYPE.split(COMMA_SEPERATOR));
			List<String> deductionTypeList = Arrays
					.asList(FinancialInfoConstants.DEDUCTION_TYPE.split(COMMA_SEPERATOR));
			List<String> dcETypeList = Arrays.asList(FinancialInfoConstants.DC_E_TYPE.split(COMMA_SEPERATOR));
			List<String> incomeTaxDedTypeList = Arrays
					.asList(FinancialInfoConstants.INCOME_TAX_DED_TYPE.split(COMMA_SEPERATOR));

			if (housingBillTypeList.contains(expenseType)) {
				return HOUSING_BILLS_EXPENSE;
			} else if (medBillsTypeList.contains(expenseType)) {
				return MED_BILLS_EXPENSE;
			} else if (deductionTypeList.contains(expenseType)) {
				return APP_IN_DEDUCTION_EXPENSE;
			} else if (dcETypeList.contains(expenseType)) {
				return CARE_COST_EXPENSE;
			} else if (incomeTaxDedTypeList.contains(expenseType)) {
				return INCOME_TAX_DED_EXPENSE;
			}
			return StringUtils.EMPTY;
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * storeHousingBillsData method is used to store expenses data in
	 * APP_IN_HOU_BILLS_Cargo
	 * 
	 * @param appNum
	 * @param indvSeqNum
	 * @param seqNum
	 * @param reviewDetails
	 */
	private void storeHousingBillsData(String appNum, Integer indvSeqNum, Integer seqNum,
			RedetMCExpensesIndvDetails_Cargo reviewDetails) {
		APP_IN_HOU_BILLS_Cargo housingBillsCargo = null;

		housingBillsCargo = appInHouRepository.getHousingBillExpenseDetail(Integer.parseInt(appNum), indvSeqNum,
				seqNum);

		if (Objects.isNull(housingBillsCargo)) {
			housingBillsCargo = new APP_IN_HOU_BILLS_Cargo();
		}
		housingBillsCargo.setApp_num(appNum);
		housingBillsCargo.setIndv_seq_num(indvSeqNum);
		housingBillsCargo.setSeq_num(seqNum);
		housingBillsCargo.setSrc_app_ind(FinancialInfoConstants.SRC_APP_AFB);
		housingBillsCargo.setBill_type(reviewDetails.getExpenseType());
		housingBillsCargo.setPymt_amt(reviewDetails.getPaymentAmount());
		housingBillsCargo.setPymt_freq(reviewDetails.getPaymentFrequency());
		housingBillsCargo.setChg_dt(new Date());
		appInHouRepository.save(housingBillsCargo);

	}

	/**
	 * storeHousingBillsData method is used to store expenses data in
	 * CP_APP_IN_MED_BILLS_Cargo
	 * 
	 * @param appNum
	 * @param indvSeqNum
	 * @param seqNum
	 * @param reviewDetails
	 */
	private void storeMedBillsData(String appNum, Integer indvSeqNum, Integer seqNum,
			RedetMCExpensesIndvDetails_Cargo reviewDetails) {
		CP_APP_IN_MED_BILLS_Cargo appInMedBillsCargo = null;

		appInMedBillsCargo = cpAppInMedBillsRepository.getMedBillExpenseDetail(Integer.parseInt(appNum), indvSeqNum,
				seqNum);

		if (Objects.isNull(appInMedBillsCargo)) {
			appInMedBillsCargo = new CP_APP_IN_MED_BILLS_Cargo();
		}
		appInMedBillsCargo.setApp_num(appNum);
		appInMedBillsCargo.setIndv_seq_num(indvSeqNum);
		appInMedBillsCargo.setMedical_seq_num(seqNum);
		appInMedBillsCargo.setSrc_app_ind(FinancialInfoConstants.SRC_APP_AFB);
		appInMedBillsCargo.setMed_bill_type(reviewDetails.getExpenseType());
		appInMedBillsCargo.setPayment_amt(reviewDetails.getPaymentAmount());
		appInMedBillsCargo.setPay_freq(reviewDetails.getPaymentFrequency());
		appInMedBillsCargo.setChange_dt(new Date());
		cpAppInMedBillsRepository.save(appInMedBillsCargo);

	}

	/**
	 * storeHousingBillsData method is used to store expenses data in
	 * CP_APP_IN_DEDUCTION_Cargo
	 * 
	 * @param appNum
	 * @param indvSeqNum
	 * @param seqNum
	 * @param reviewDetails
	 */
	private void storeAppInDeductionData(String appNum, Integer indvSeqNum, Integer seqNum,
			RedetMCExpensesIndvDetails_Cargo reviewDetails) {
		CP_APP_IN_DEDUCTION_Cargo appInDeductionCargo = null;

		appInDeductionCargo = cpAppIndeductionRepository.getDeductionExpenseDetail(Integer.parseInt(appNum), indvSeqNum,
				seqNum);

		if (Objects.isNull(appInDeductionCargo)) {
			appInDeductionCargo = new CP_APP_IN_DEDUCTION_Cargo();
		}
		appInDeductionCargo.setApp_num(appNum);
		appInDeductionCargo.setIndv_seq_num(indvSeqNum);
		appInDeductionCargo.setSeq_num(seqNum);
		appInDeductionCargo.setSrc_app_ind(FinancialInfoConstants.SRC_APP_AFB);
		appInDeductionCargo.setExp_typ(reviewDetails.getExpenseType());
		appInDeductionCargo.setExp_amt(reviewDetails.getPaymentAmount());
		appInDeductionCargo.setPay_freq_cd(reviewDetails.getPaymentFrequency());
		appInDeductionCargo.setChg_dt(new Date());
		if ("CA".equals(reviewDetails.getExpenseType())) {
			appInDeductionCargo.setDivorce_dt(reviewDetails.getDivorceDate());
		}
		if ("OT".equals(reviewDetails.getExpenseType())) {
			appInDeductionCargo.setOtherExpenseType(reviewDetails.getOtherExpenseType());
		}
		cpAppIndeductionRepository.save(appInDeductionCargo);

	}

	/**
	 * storeHousingBillsData method is used to store expenses data in CP_ABCHS_Cargo
	 * 
	 * @param appNum
	 * @param indvSeqNum
	 * @param seqNum
	 * @param reviewDetails
	 */
	private void storeCareCostData(String appNum, Integer indvSeqNum, Integer seqNum,
			RedetMCExpensesIndvDetails_Cargo reviewDetails) {
		CP_ABCHS_Cargo careCostCargo = null;

		careCostCargo = careCostBO.getCareCostExpenseDetail(Integer.parseInt(appNum), indvSeqNum, seqNum);

		if (Objects.isNull(careCostCargo)) {
			careCostCargo = new CP_ABCHS_Cargo();
		}
		careCostCargo.setApp_num(appNum);
		careCostCargo.setIndv_seq_num(indvSeqNum);
		careCostCargo.setSeq_num(seqNum);
		careCostCargo.setSrc_app_ind(FinancialInfoConstants.SRC_APP_AFB);
		careCostCargo.setDpnd_care_exp_ind(reviewDetails.getExpenseType());
		careCostCargo.setDpnd_care_exp_amt(reviewDetails.getPaymentAmount());
		careCostCargo.setPay_freq(reviewDetails.getPaymentFrequency());
		careCostCargo.setChg_dt(new Date());
		careCostBO.storeCareCostData(careCostCargo);

	}

	/**
	 * storeHousingBillsData method is used to store expenses data in
	 * CP_APP_IN_INCOME_TAX_DED_Cargo
	 * 
	 * @param appNum
	 * @param indvSeqNum
	 * @param seqNum
	 * @param reviewDetails
	 */
	private void storeIncomeTaxDedData(String appNum, Integer indvSeqNum, Integer seqNum,
			RedetMCExpensesIndvDetails_Cargo reviewDetails) {
		CP_APP_IN_INCOME_TAX_DED_Cargo incomeTaxDedCargo = null;

		incomeTaxDedCargo = cpAppInIncomeTaxDedRepository.getIncomeTaxDedExpenseDetail(Integer.parseInt(appNum),
				indvSeqNum, seqNum);

		if (Objects.isNull(incomeTaxDedCargo)) {
			incomeTaxDedCargo = new CP_APP_IN_INCOME_TAX_DED_Cargo();
		}
		incomeTaxDedCargo.setApp_num(appNum);
		incomeTaxDedCargo.setIndv_seq_num(indvSeqNum);
		incomeTaxDedCargo.setSeq_num(seqNum);
		incomeTaxDedCargo.setSrc_app_ind(FinancialInfoConstants.SRC_APP_AFB);
		incomeTaxDedCargo.setExp_type(reviewDetails.getExpenseType());
		incomeTaxDedCargo.setAlimony_exp(reviewDetails.getPaymentAmount());
		incomeTaxDedCargo.setPay_freq(reviewDetails.getPaymentFrequency());
		incomeTaxDedCargo.setChg_dt(new Date());
		cpAppInIncomeTaxDedRepository.save(incomeTaxDedCargo);

	}

	/**
	 * loadRedetMCExpenseReviewData method is used to process and fetch all the
	 * Expenses related data for the specified appNum
	 * 
	 * @param txnBean
	 */
	public void loadRedetMCExpenseSummaryData(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "RedetMCExpensesServiceImpl.loadRedetMCExpenseSummaryData() - START");
		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String expenseType = categorySequenceDetails.getCategoryType();

			List<Integer> indvIdList = new ArrayList<>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("indvIds");
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			List<RedetMCExpensesIndvDetails_Cargo> summaryIndvDetailsList = new ArrayList<>();
			String specifiedExpenseCargo = getSpecifiedExpenseCargo(expenseType);
			switch (specifiedExpenseCargo) {
			case HOUSING_BILLS_EXPENSE:
				APP_IN_HOU_BILLS_Collection housingBillsColl = appInHouRepository
						.loadHousingExpenseSummaryDetails(Integer.parseInt(appNum), expenseType, indvIdList);
				generateHousingBillsIndvDetails(summaryIndvDetailsList, housingBillsColl);
				break;
			case MED_BILLS_EXPENSE:
				CP_APP_IN_MED_BILLS_Collection medBillsCollection = cpAppInMedBillsRepository
						.getMedBillsSummaryDetails(Integer.parseInt(appNum), expenseType, indvIdList);
				generateMedBillsIndvDetails(summaryIndvDetailsList, medBillsCollection);
				break;
			case APP_IN_DEDUCTION_EXPENSE:
				CP_APP_IN_DEDUCTION_Collection appInDedCollection = cpAppIndeductionRepository
						.getDeductionSummaryDetails(Integer.parseInt(appNum), expenseType, indvIdList);
				generateAppInDeductionIndvDetails(summaryIndvDetailsList, appInDedCollection);
				break;
			case CARE_COST_EXPENSE:
				CP_ABCHS_Collection careCostCollection = careCostRepository.getCareCostDetailsByType(Integer.parseInt(appNum),
						expenseType, indvIdList);
				generateCareCostIndvDetails(summaryIndvDetailsList, careCostCollection);
				break;
			case INCOME_TAX_DED_EXPENSE:
				CP_APP_IN_INCOME_TAX_DED_Collection incomeTaxDedColl = cpAppInIncomeTaxDedRepository
						.getIncomeTaxDedSummaryDetails(Integer.parseInt(appNum), expenseType, indvIdList);
				generateIncomeTaxDedIndvDetails(summaryIndvDetailsList, incomeTaxDedColl);
				break;
			default:
				break;
			}

			pageCollection.put(REDET_MC_INDV_COLLECTION, summaryIndvDetailsList);

			FwLogger.log(this.getClass(), Level.INFO,
					"RedetMCExpensesServiceImpl::loadRedetMCExpenseSummaryData() - End");

		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(), LOAD_EXPENSE_SUMMARY,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO,
				"RedetMCExpensesServiceImpl::loadRedetMCExpenseSummaryData() - End , Time Taken : "
						+ (System.currentTimeMillis() - startTime));

	}

	public void removeRedetMCExpenseDetails(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "RedetMCExpensesServiceImpl::removeRedetMCExpenseDetails() - START");

		try {
			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			
			String expenseType = categorySequenceDetails.getCategoryType();
			Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence()) ;
			Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			Date endDate = new Date(System.currentTimeMillis());
			String srcAppInd = FinancialInfoConstants.SRC_APP_AFB;
			txnBean.setPageCollection(new HashMap<>());
			String specifiedExpenseCargo = getSpecifiedExpenseCargo(expenseType);
			switch (specifiedExpenseCargo) {
			case HOUSING_BILLS_EXPENSE:
				appInHouRepository.updateEndDate(Integer.parseInt(appNum), indvSeqNum, seqNum, srcAppInd, expenseType, endDate);
				break;
			case MED_BILLS_EXPENSE:
				cpAppInMedBillsRepository.updateEndDate(Integer.parseInt(appNum), indvSeqNum, seqNum, srcAppInd, expenseType, endDate);
				break;
			case APP_IN_DEDUCTION_EXPENSE:
				cpAppIndeductionRepository.updateEndDate(Integer.parseInt(appNum), indvSeqNum, seqNum, srcAppInd, expenseType, endDate);
				break;
			case CARE_COST_EXPENSE:
				careCostRepository.updateEndDate(Integer.parseInt(appNum), indvSeqNum, seqNum, srcAppInd, expenseType, endDate);
				break;
			case INCOME_TAX_DED_EXPENSE:
				cpAppInIncomeTaxDedRepository.updateEndDate(Integer.parseInt(appNum), indvSeqNum, seqNum, srcAppInd, expenseType,
						endDate);
				break;
			default:
				break;
			}
		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(), REMOVE_EXPENSE_DETAILS,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"RedetMCExpensesServiceImpl::removeRedetMCExpenseDetails() - End , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}

}
