/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import javax.persistence.Id;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * This java bean contains the entities of APP_IN_EMPL_A_WAGE
 *
 * @author Architecture Team Creation Date Thu Jun 22 15:09:24 CDT 2006 Modified
 *         By: Modified on: PCR#
 */


public class APP_IN_EMPL_A_WAGE_Cargo extends AbstractCargo implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	private String app_num;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer empl_seq_num;
	@Id
	private Integer adtl_pay_seq_num;
	@Id
	private String src_app_ind;
	private Integer adtl_hrs_qty;
	private Integer adtl_pay_amt;
	private Double adtl_pay_ind;
	private String adtl_pay_typ;
	private String adtl_pay_freq_cd;
	private Double rec_complete_ind;

	public String getApp_num() {
		return app_num;
	}

	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}

	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public Integer getEmpl_seq_num() {
		return empl_seq_num;
	}

	public void setEmpl_seq_num(Integer empl_seq_num) {
		this.empl_seq_num = empl_seq_num;
	}

	public Integer getAdtl_pay_seq_num() {
		return adtl_pay_seq_num;
	}

	public void setAdtl_pay_seq_num(Integer adtl_pay_seq_num) {
		this.adtl_pay_seq_num = adtl_pay_seq_num;
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public Integer getAdtl_hrs_qty() {
		return adtl_hrs_qty;
	}

	public void setAdtl_hrs_qty(Integer adtl_hrs_qty) {
		this.adtl_hrs_qty = adtl_hrs_qty;
	}

	public Integer getAdtl_pay_amt() {
		return adtl_pay_amt;
	}

	public void setAdtl_pay_amt(Integer adtl_pay_amt) {
		this.adtl_pay_amt = adtl_pay_amt;
	}

	public Double getAdtl_pay_ind() {
		return adtl_pay_ind;
	}

	public void setAdtl_pay_ind(Double adtl_pay_ind) {
		this.adtl_pay_ind = adtl_pay_ind;
	}

	public String getAdtl_pay_typ() {
		return adtl_pay_typ;
	}

	public void setAdtl_pay_typ(String adtl_pay_typ) {
		this.adtl_pay_typ = adtl_pay_typ;
	}

	public String getAdtl_pay_freq_cd() {
		return adtl_pay_freq_cd;
	}

	public void setAdtl_pay_freq_cd(String adtl_pay_freq_cd) {
		this.adtl_pay_freq_cd = adtl_pay_freq_cd;
	}

	public Double getRec_complete_ind() {
		return rec_complete_ind;
	}

	public void setRec_complete_ind(Double rec_complete_ind) {
		this.rec_complete_ind = rec_complete_ind;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adtl_hrs_qty == null) ? 0 : adtl_hrs_qty.hashCode());
		result = prime * result + ((adtl_pay_amt == null) ? 0 : adtl_pay_amt.hashCode());
		result = prime * result + ((adtl_pay_freq_cd == null) ? 0 : adtl_pay_freq_cd.hashCode());
		result = prime * result + ((adtl_pay_ind == null) ? 0 : adtl_pay_ind.hashCode());
		result = prime * result + ((adtl_pay_seq_num == null) ? 0 : adtl_pay_seq_num.hashCode());
		result = prime * result + ((adtl_pay_typ == null) ? 0 : adtl_pay_typ.hashCode());
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((empl_seq_num == null) ? 0 : empl_seq_num.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((rec_complete_ind == null) ? 0 : rec_complete_ind.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}
}