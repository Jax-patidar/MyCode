/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.management.constants.FwConstants;

@Entity
@IdClass(APP_IN_EMPL_Id.class)
@Table(name = "CP_APP_IN_EMPL")
public class APP_IN_EMPL_Cargo extends AbstractCargo implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Transient
	private String app_num = FwConstants.SPACE;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer empl_seq_num;
	
	private String src_app_ind;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date change_eff_dt;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date empl_begin_dt;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date empl_end_dt;
	
	private String er_city_address;
	private String er_l1_address;
	private String er_l2_address;
	private String er_name;
	private String er_phone_num;
	private String er_st_address;
	private String er_zip_address;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date first_payck_dt;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date last_payck_dt;
	private String pay_freq_cd;
	private Integer rec_cplt_ind;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date strike_begin_dt;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date strike_end_dt;
	
	private String ref_job_sw;
	private String job_termination_reason;
	private String on_strike_sw;
	private String expected_to_cont_resp;
	@Transient
	private String er_Typ;
	
	private String pay_day_week_cd;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date next_paycheck_dt;
	private Double hourly_pay_amt;
	private Integer num_of_hours;
	private Double gross_pay_amt;
	private Double last_paycheck_amt;
	@Transient
	private String empl_loss_gdcs_cd;
	
	private String empl_addtl_info;
	@Transient
	private String looping_ind;

	private String ik_empl_name;
	
	private Date ik_job_start_dt;
	private Date ik_job_end_dt;
	
	private Double ik_amt_each_month;
	@Transient
	private String ik_loopingInd;
	
	@Transient
	private String fst_nam;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date end_dt;
	
	private String address_zip4;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date change_dt;
	
	//Added for Income summary screen (CSPM -3028)
	@Id
	private String ik_income_type;
	private String ik_recv_type;
	private String er_prvd_med_ins_ind;
	private Integer mthly_est_val_gs_rcvd;
	@JsonProperty("yearly_income_current_year") 
	private String yearly_income_current_year;
	@JsonProperty("yearly_income_next_year") 
	private String yearly_income_next_year;
	private Integer ik_amt;
	private String ik_freq;
	private String upcmng_job_chng_ind;
	private String employment_county_job;

	private String empl_type;
	
	@Column(name="last_60_days_ind")
	private String last_60_days_ind;
	private String next_year_income_change_ind;

	
	private String county_help_job_ind;
	
	@Column(name="LOST_JOB_IND")
	private String lostJobInd;
	
	@Column(name="income_source")
	private String incomeSource;
	
	@Column(name= "empl_calsaws_object")
	private String emplCalsawsObject;
	
	@Transient
	private String IncomeTypeList;
	
	@Transient
	private String rentIncomeInd;
	
	@Transient
	private String foodIncomeInd;
	
	@Transient
	private String utilitiesIncomeInd;
	
	@Transient
	private String rentExchInd;
	
	@Transient
	private String foodExchInd;
	
	@Transient
	private String utilitiesExchInd;
	
	public String getLostJobInd() {
		return lostJobInd;
	}

	public void setLostJobInd(String lostJobInd) {
		this.lostJobInd = lostJobInd;
	}

	public String getNext_year_income_change_ind() {
		return next_year_income_change_ind;
	}

	public void setNext_year_income_change_ind(String next_year_income_change_ind) {
		this.next_year_income_change_ind = next_year_income_change_ind;
	}


	public String getIk_recv_type() {
		return ik_recv_type;
	}

	public void setIk_recv_type(String ik_recv_type) {
		this.ik_recv_type = ik_recv_type;
	}

	public String getFst_nam() {
		return fst_nam;
	}

	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}

	public String getApp_num() {
		return String.valueOf(app_number);
	}

	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public Integer getEmpl_seq_num() {
		return empl_seq_num;
	}

	public void setEmpl_seq_num(Integer empl_seq_num) {
		this.empl_seq_num = empl_seq_num;
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public Date getEmpl_end_dt() {
        return this.empl_end_dt!= null ? new Date(empl_end_dt.getTime()) : null;

	}

	public void setEmpl_end_dt(Date empl_end_dt) {
		this.empl_end_dt = (empl_end_dt == null) ? null : new Date(empl_end_dt.getTime());
	}

	public Date getLast_payck_dt() {
        return this.last_payck_dt!= null ? new Date(last_payck_dt.getTime()) : null;

	}

	public void setLast_payck_dt(Date last_payck_dt) {
		this.last_payck_dt = (last_payck_dt == null) ? null : new Date(last_payck_dt.getTime());

	}

	public String getPay_freq_cd() {
		return pay_freq_cd;
	}

	public void setPay_freq_cd(String pay_freq_cd) {
		this.pay_freq_cd = pay_freq_cd;
	}

	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	public String getRef_job_sw() {
		return ref_job_sw;
	}

	public void setRef_job_sw(String ref_job_sw) {
		this.ref_job_sw = ref_job_sw;
	}

	public String getJob_termination_reason() {
		return job_termination_reason;
	}

	public void setJob_termination_reason(String job_termination_reason) {
		this.job_termination_reason = job_termination_reason;
	}

	public String getOn_strike_sw() {
		return on_strike_sw;
	}

	public void setOn_strike_sw(String on_strike_sw) {
		this.on_strike_sw = on_strike_sw;
	}

	public String getExpected_to_cont_resp() {
		return expected_to_cont_resp;
	}

	public void setExpected_to_cont_resp(String expected_to_cont_resp) {
		this.expected_to_cont_resp = expected_to_cont_resp;
	}

	public String getEr_Typ() {
		return er_Typ;
	}

	public void setEr_Typ(String er_Typ) {
		this.er_Typ = er_Typ;
	}

	public String getPay_day_week_cd() {
		return pay_day_week_cd;
	}

	public void setPay_day_week_cd(String pay_day_week_cd) {
		this.pay_day_week_cd = pay_day_week_cd;
	}

	public Date getNext_paycheck_dt() {
        return this.next_paycheck_dt!= null ? new Date(next_paycheck_dt.getTime()) : null;

	}

	public void setNext_paycheck_dt(Date next_paycheck_dt) {
		this.next_paycheck_dt = (next_paycheck_dt == null) ? null : new Date(next_paycheck_dt.getTime());

	}

	public Double getHourly_pay_amt() {
		return hourly_pay_amt;
	}

	public void setHourly_pay_amt(Double hourly_pay_amt) {
		this.hourly_pay_amt = hourly_pay_amt;
	}

	public Integer getNum_of_hours() {
		return num_of_hours;
	}

	public void setNum_of_hours(Integer num_of_hours) {
		this.num_of_hours = num_of_hours;
	}

	public Double getGross_pay_amt() {
		return gross_pay_amt;
	}

	public void setGross_pay_amt(Double gross_pay_amt) {
		this.gross_pay_amt = gross_pay_amt;
	}

	public Double getLast_paycheck_amt() {
		return last_paycheck_amt;
	}

	public void setLast_paycheck_amt(Double last_paycheck_amt) {
		this.last_paycheck_amt = last_paycheck_amt;
	}

	public String getEmpl_loss_gdcs_cd() {
		return empl_loss_gdcs_cd;
	}

	public void setEmpl_loss_gdcs_cd(String empl_loss_gdcs_cd) {
		this.empl_loss_gdcs_cd = empl_loss_gdcs_cd;
	}

	public String getEmpl_addtl_info() {
		return empl_addtl_info;
	}

	public void setEmpl_addtl_info(String empl_addtl_info) {
		this.empl_addtl_info = empl_addtl_info;
	}

	public String getLooping_ind() {
		return looping_ind;
	}

	public void setLooping_ind(String looping_ind) {
		this.looping_ind = looping_ind;
	}


	public Double getIk_amt_each_month() {
		return ik_amt_each_month;
	}

	public void setIk_amt_each_month(Double ik_amt_each_month) {
		this.ik_amt_each_month = ik_amt_each_month;
	}

	public String getIk_loopingInd() {
		return ik_loopingInd;
	}

	public void setIk_loopingInd(String ik_loopingInd) {
		this.ik_loopingInd = ik_loopingInd;
	}

	/**
	 * @return the change_eff_dt
	 */
	public Date getChange_eff_dt() {
		return change_eff_dt;
	}

	/**
	 * @param change_eff_dt the change_eff_dt to set
	 */
	public void setChange_eff_dt(Date change_eff_dt) {
		this.change_eff_dt = change_eff_dt;
	}

	/**
	 * @return the empl_begin_dt
	 */
	public Date getEmpl_begin_dt() {
		return empl_begin_dt;
	}

	/**
	 * @param empl_begin_dt the empl_begin_dt to set
	 */
	public void setEmpl_begin_dt(Date empl_begin_dt) {
		this.empl_begin_dt = empl_begin_dt;
	}

	/**
	 * @return the er_city_address
	 */
	public String getEr_city_address() {
		return er_city_address;
	}

	/**
	 * @param er_city_address the er_city_address to set
	 */
	public void setEr_city_address(String er_city_address) {
		this.er_city_address = er_city_address;
	}

	/**
	 * @return the er_l1_address
	 */
	public String getEr_l1_address() {
		return er_l1_address;
	}

	/**
	 * @param er_l1_address the er_l1_address to set
	 */
	public void setEr_l1_address(String er_l1_address) {
		this.er_l1_address = er_l1_address;
	}

	/**
	 * @return the er_name
	 */
	public String getEr_name() {
		return er_name;
	}

	/**
	 * @param er_name the er_name to set
	 */
	public void setEr_name(String er_name) {
		this.er_name = er_name;
	}

	/**
	 * @return the er_phone_num
	 */
	public String getEr_phone_num() {
		return er_phone_num;
	}

	/**
	 * @param er_phone_num the er_phone_num to set
	 */
	public void setEr_phone_num(String er_phone_num) {
		this.er_phone_num = er_phone_num;
	}

	/**
	 * @return the er_st_address
	 */
	public String getEr_st_address() {
		return er_st_address;
	}

	/**
	 * @param er_st_address the er_st_address to set
	 */
	public void setEr_st_address(String er_st_address) {
		this.er_st_address = er_st_address;
	}

	/**
	 * @return the er_zip_address
	 */
	public String getEr_zip_address() {
		return er_zip_address;
	}

	/**
	 * @param er_zip_address the er_zip_address to set
	 */
	public void setEr_zip_address(String er_zip_address) {
		this.er_zip_address = er_zip_address;
	}

	/**
	 * @return the first_payck_dt
	 */
	public Date getFirst_payck_dt() {
		return first_payck_dt;
	}

	/**
	 * @param first_payck_dt the first_payck_dt to set
	 */
	public void setFirst_payck_dt(Date first_payck_dt) {
		this.first_payck_dt = first_payck_dt;
	}

	/**
	 * @return the strike_begin_dt
	 */
	public Date getStrike_begin_dt() {
		return strike_begin_dt;
	}

	/**
	 * @param strike_begin_dt the strike_begin_dt to set
	 */
	public void setStrike_begin_dt(Date strike_begin_dt) {
		this.strike_begin_dt = strike_begin_dt;
	}

	/**
	 * @return the strike_end_dt
	 */
	public Date getStrike_end_dt() {
		return strike_end_dt;
	}

	/**
	 * @param strike_end_dt the strike_end_dt to set
	 */
	public void setStrike_end_dt(Date strike_end_dt) {
		this.strike_end_dt = strike_end_dt;
	}

	/**
	 * @return the ik_empl_name
	 */
	public String getIk_empl_name() {
		return ik_empl_name;
	}

	/**
	 * @param ik_empl_name the ik_empl_name to set
	 */
	public void setIk_empl_name(String ik_empl_name) {
		this.ik_empl_name = ik_empl_name;
	}

	/**
	 * @return the ik_job_start_dt
	 */
	public Date getIk_job_start_dt() {
		return ik_job_start_dt;
	}

	/**
	 * @param ik_job_start_dt the ik_job_start_dt to set
	 */
	public void setIk_job_start_dt(Date ik_job_start_dt) {
		this.ik_job_start_dt = ik_job_start_dt;
	}

	/**
	 * @return the ik_job_end_dt
	 */
	public Date getIk_job_end_dt() {
		return ik_job_end_dt;
	}

	/**
	 * @param ik_job_end_dt the ik_job_end_dt to set
	 */
	public void setIk_job_end_dt(Date ik_job_end_dt) {
		this.ik_job_end_dt = ik_job_end_dt;
	}

	/**
	 * @return the address_zip4
	 */
	public String getAddress_zip4() {
		return address_zip4;
	}

	/**
	 * @param address_zip4 the address_zip4 to set
	 */
	public void setAddress_zip4(String address_zip4) {
		this.address_zip4 = address_zip4;
	}

	/**
	 * @return the change_dt
	 */
	public Date getChange_dt() {
		return change_dt;
	}

	/**
	 * @param change_dt the change_dt to set
	 */
	public void setChange_dt(Date change_dt) {
		this.change_dt = change_dt;
	}

	/**
	 * @return the ik_income_type
	 */
	public String getIk_income_type() {
		return ik_income_type;
	}

	/**
	 * @param ik_income_type the ik_income_type to set
	 */
	public void setIk_income_type(String ik_income_type) {
		this.ik_income_type = ik_income_type;
	}

	
	/**
	 * @return the er_l2_address
	 */
	public String getEr_l2_address() {
		return er_l2_address;
	}

	/**
	 * @param er_l2_address the er_l2_address to set
	 */
	public void setEr_l2_address(String er_l2_address) {
		this.er_l2_address = er_l2_address;
	}

	/**
	 * @return the er_prvd_med_ins_ind
	 */
	public String getEr_prvd_med_ins_ind() {
		return er_prvd_med_ins_ind;
	}

	/**
	 * @param er_prvd_med_ins_ind the er_prvd_med_ins_ind to set
	 */
	public void setEr_prvd_med_ins_ind(String er_prvd_med_ins_ind) {
		this.er_prvd_med_ins_ind = er_prvd_med_ins_ind;
	}

	/**
	 * @return the mthly_est_val_gs_rcvd
	 */
	public Integer getMthly_est_val_gs_rcvd() {
		return mthly_est_val_gs_rcvd;
	}

	/**
	 * @param mthly_est_val_gs_rcvd the mthly_est_val_gs_rcvd to set
	 */
	public void setMthly_est_val_gs_rcvd(Integer mthly_est_val_gs_rcvd) {
		this.mthly_est_val_gs_rcvd = mthly_est_val_gs_rcvd;
	}

	/**
	 * @return the ik_amt
	 */
	public Integer getIk_amt() {
		return ik_amt;
	}

	public String getYearly_income_current_year() {
		return yearly_income_current_year;
	}

	public void setYearly_income_current_year(String yearly_income_current_year) {
		this.yearly_income_current_year = yearly_income_current_year;
	}

	public String getYearly_income_next_year() {
		return yearly_income_next_year;
	}

	public void setYearly_income_next_year(String yearly_income_next_year) {
		this.yearly_income_next_year = yearly_income_next_year;
	}

	/**
	 * @param ik_amt the ik_amt to set
	 */
	public void setIk_amt(Integer ik_amt) {
		this.ik_amt = ik_amt;
	}

	/**
	 * @return the ik_freq
	 */
	public String getIk_freq() {
		return ik_freq;
	}

	/**
	 * @param ik_freq the ik_freq to set
	 */
	public void setIk_freq(String ik_freq) {
		this.ik_freq = ik_freq;
	}

	/**
	 * @return the upcmng_job_chng_ind
	 */
	public String getUpcmng_job_chng_ind() {
		return upcmng_job_chng_ind;
	}

	/**
	 * @param upcmng_job_chng_ind the upcmng_job_chng_ind to set
	 */
	public void setUpcmng_job_chng_ind(String upcmng_job_chng_ind) {
		this.upcmng_job_chng_ind = upcmng_job_chng_ind;
	}

	/**
	 * @return the employment_county_job
	 */
	public String getEmployment_county_job() {
		return employment_county_job;
	}

	/**
	 * @param employment_county_job the employment_county_job to set
	 */
	public void setEmployment_county_job(String employment_county_job) {
		this.employment_county_job = employment_county_job;
	}

	/**
	 * @return the empl_type
	 */
	public String getEmpl_type() {
		return empl_type;
	}

	/**
	 * @param empl_type the empl_type to set
	 */
	public void setEmpl_type(String empl_type) {
		this.empl_type = empl_type;
	}

	public String getlast_60_days_ind() {
		return last_60_days_ind;
	}

	public void setlast_60_days_ind(String last_60_days_ind) {
		this.last_60_days_ind = last_60_days_ind;
	}

	public String getCounty_help_job_ind() {
		return county_help_job_ind;
	}

	public void setCounty_help_job_ind(String county_help_job_ind) {
		this.county_help_job_ind = county_help_job_ind;
	}

	public String getIncomeSource() {
		return incomeSource;
	}

	public void setIncomeSource(String incomeSource) {
		this.incomeSource = incomeSource;
	}
	
	public String getEmplCalsawsObject() {
		return emplCalsawsObject;
	}

	public void setEmplCalsawsObject(String emplCalsawsObject) {
		this.emplCalsawsObject = emplCalsawsObject;
	}

	public Date getEnd_dt() {
		return end_dt;
	}

	public void setEnd_dt(Date end_dt) {
		this.end_dt = end_dt;
	}

	public String getIncomeTypeList() {
		return IncomeTypeList;
	}

	public void setIncomeTypeList(String incomeTypeList) {
		IncomeTypeList = incomeTypeList;
	}

	public String getRentIncomeInd() {
		return rentIncomeInd;
	}

	public void setRentIncomeInd(String rentIncomeInd) {
		this.rentIncomeInd = rentIncomeInd;
	}

	public String getFoodIncomeInd() {
		return foodIncomeInd;
	}

	public void setFoodIncomeInd(String foodIncomeInd) {
		this.foodIncomeInd = foodIncomeInd;
	}

	public String getUtilitiesIncomeInd() {
		return utilitiesIncomeInd;
	}

	public void setUtilitiesIncomeInd(String utilitiesIncomeInd) {
		this.utilitiesIncomeInd = utilitiesIncomeInd;
	}

	public String getRentExchInd() {
		return rentExchInd;
	}

	public void setRentExchInd(String rentExchInd) {
		this.rentExchInd = rentExchInd;
	}

	public String getFoodExchInd() {
		return foodExchInd;
	}

	public void setFoodExchInd(String foodExchInd) {
		this.foodExchInd = foodExchInd;
	}

	public String getUtilitiesExchInd() {
		return utilitiesExchInd;
	}

	public void setUtilitiesExchInd(String utilitiesExchInd) {
		this.utilitiesExchInd = utilitiesExchInd;
	}
}