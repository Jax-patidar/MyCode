/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;


public class APP_IN_JNT_OWN_Collection extends AbstractCollection {

	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_IN_JNT_OWN";

	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_JNT_OWN_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_JNT_OWN_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_JNT_OWN_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_JNT_OWN_Cargo[] getResults() {
		final APP_IN_JNT_OWN_Cargo[] cbArray = new APP_IN_JNT_OWN_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_JNT_OWN_Cargo getCargo(final int idx) {
		return (APP_IN_JNT_OWN_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_JNT_OWN_Cargo[] cloneResults() {
		final APP_IN_JNT_OWN_Cargo[] rescargo = new APP_IN_JNT_OWN_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_JNT_OWN_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_JNT_OWN_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setEcp_id(cargo.getEcp_id());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setSeq_num(cargo.getSeq_num());
			rescargo[i].setAset_typ(cargo.getAset_typ());
			rescargo[i].setJnt_own_seq_num(cargo.getJnt_own_seq_num());
			rescargo[i].setAset_sub_typ(cargo.getAset_sub_typ());
			rescargo[i].setJnt_indv_seq_num(cargo.getJnt_indv_seq_num());
			rescargo[i].setJnt_own_fst_nam(cargo.getJnt_own_fst_nam());
			rescargo[i].setJnt_own_last_nam(cargo.getJnt_own_last_nam());
			rescargo[i].setOtsd_ind(cargo.getOtsd_ind());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_JNT_OWN_Cargo[]) {
			final APP_IN_JNT_OWN_Cargo[] cbArray = (APP_IN_JNT_OWN_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}