package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

public class CP_EXPENSE_DISASTER_Key implements Serializable {

	private static final long serialVersionUID = -6548849487644215639L;
	
	private Integer app_number;
	private String exp_type;
	
	public CP_EXPENSE_DISASTER_Key() {
		
	}

	public CP_EXPENSE_DISASTER_Key(Integer app_num, String exp_type) {
		super();
		this.app_number = app_num;
		this.exp_type = exp_type;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((exp_type == null) ? 0 : exp_type.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CP_EXPENSE_DISASTER_Key other = (CP_EXPENSE_DISASTER_Key) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (exp_type == null) {
			if (other.exp_type != null)
				return false;
		} else if (!exp_type.equals(other.exp_type))
			return false;
		
		return true;
	}
	
	
	
	
}
