package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClient;
import com.amazonaws.services.lambda.model.InvocationType;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.amazonaws.util.CollectionUtils;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.business.entities.ServiceResponseCargo;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.access.management.util.ServiceChainUtil;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_DABL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_HEALTH_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_LST_HLTH_INS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_INS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_SNP_Collection;
import gov.state.nextgen.financialinformation.business.rules.ExpenseSummaryBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.model.DriverPageResponse;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.framework.business.model.UserDetails;

@Service("ExpenseSummaryServiceImpl")
public class ExpenseSummaryServiceImpl implements FinancialServInterface {

	@Autowired
	ExpenseSummaryBO expenseSummaryBO;
	
	private static final String GET_PERF_DATA = "getPrflData";
	
	private static final String GET_SERVICE_CLLAS = "getServiceClass";
	
	private static final String GET_HOUSE_SUMM = "getHousingSummary";
	
	private static final String GET_STUD_LOAN_REVIEW = "getStudentLoanReview";
	
	private static final String GET_COURT_ORDERED_SUMM = "getCourtOrderedSummary";
	
	private static final String INDV_ID = "indvIds";
	
	private static final String GET_MEDI_SUMM = "getMedicalSummary";
	
	private static final String CP_APP_IN_LST_HLTH_INS_COLL = "CP_APP_IN_LST_HLTH_INS_Collection";
	
	private static final String CP_APP_IN_MED_INS_COLL = "CP_APP_IN_MED_INS_Collection";
	
	private static final String APP_IN_EMPL_HEALTH_COLL = "APP_IN_EMPL_HEALTH_Collection";
	
	private static final String GET_HEAL_SUMM = "getHeathInsuranceSummary";
	
	private static final String GET_SPL_NEED_PAY_DATA = "getSpecialNeedsPayData";
	
	private static final String ERROR_MESSAGE = "Error occured in ExpenseSummaryServiceImpl.getIndvList()";
	
	@SuppressWarnings("squid:S2229")
	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {
		if(FinancialInfoConstants.GET_PERF_DATA.equals(methodName)) {
			getPrflData(fwTxn);
		}

	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	public void getPrflData(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getPrflData() - START", fwTxn);

		try {
			
			Map pageCollection = fwTxn.getPageCollection();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			if (CollectionUtils.isNullOrEmpty(indvIds)) {
				List<String> indvIdList = new ArrayList<String>();
				APP_INDV_Collection appIndvCollection=getIndvList(fwTxn);
				if(appIndvCollection != null && !appIndvCollection.isEmpty() && appIndvCollection.size() > 0) {
					for (int i = 0; i < appIndvCollection.size(); i++) {
						APP_INDV_Cargo appIndvCargo1 = (APP_INDV_Cargo) appIndvCollection.get(i);
						indvIdList.add(appIndvCargo1.getIndv_seq_num().toString());
					}	
					pageCollection.put(INDV_ID, indvIdList);
					fwTxn.setPageCollection(pageCollection);
				}
			}
			
			getHousingSummary(fwTxn);
			getMedicalSummary(fwTxn);
			getStudentLoanReview(fwTxn);
			getCareCostSummary(fwTxn);
			getCourtOrderedSummary(fwTxn);
			getSpecialNeedsPayData(fwTxn);
			getOtherExpenseDetails(fwTxn);
			
		}  catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getPrflData()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_PERF_DATA);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwExceptionManager.handleException(e,this.getClass().getName(),
					FinancialInfoConstants.GET_PERF_DATA, fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.getPrflData() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );
	}
	
	
	
	private void getOtherExpenseDetails(FwTransaction fwTxn) throws Exception {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getOtherExpenseDetails() - START", fwTxn);
		if(null!=fwTxn.getCurrentActionDetails() && null!=fwTxn.getCurrentActionDetails().getPageId() && ("ABESU".equals(fwTxn.getCurrentActionDetails().getPageId()) || "ABAS".equals(fwTxn.getCurrentActionDetails().getPageId()))) {
			try {
				getHeathInsuranceSummary(fwTxn);
			}catch(Exception e) {
				FwLogger.log(this.getClass(), Level.ERROR, "Failed in Non-fin lambda call for health insurance", fwTxn);
				throw e;
			}	
		}
		if(null!=fwTxn.getCurrentActionDetails() && null!=fwTxn.getCurrentActionDetails().getPageId() && "ABEVC".equals(fwTxn.getCurrentActionDetails().getPageId())) {
			try {
			
				Map pageDisCollection = fwTxn.getPageCollection();
				pageDisCollection.put("APP_IN_DABL_Collection", getHousholdDisabilityList(fwTxn));
				fwTxn.setPageCollection(pageDisCollection);
			
			}catch(Exception e) {
				FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getOtherExpenseDetails()", fwTxn);
				throw e;
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getOtherExpenseDetails() - END", fwTxn);
	}
	private List<Integer> getIndvsList(Map pageCollection) {
		List<Integer> indvIdList = new ArrayList<Integer>();
		ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
		if (!CollectionUtils.isNullOrEmpty(indvIds)) {
			indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
		}
		
		return indvIdList;
	}

	private void getHousingSummary(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getHousingSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			List<Integer> indvIdList = getIndvsList(pageCollection);
			
			APP_IN_HOU_BILLS_Collection appInHousingColl = expenseSummaryBO.getHousingSummaryDetails(appnum, indvIdList);
			if (appInHousingColl.size() > 0) {
				pageCollection.put("APP_IN_HOU_BILLS_Collection", appInHousingColl);
			} else {
				APP_IN_HOU_BILLS_Collection emptyCollection = new APP_IN_HOU_BILLS_Collection();
				pageCollection.put("APP_IN_HOU_BILLS_Collection", emptyCollection);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getHousingSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLLAS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.getHousingSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );

	}
	
	
	private void getSpecialNeedsPayData(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getSpecialNeedsPayData() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			
			CP_APP_IN_SNP_Collection specialNeedPayColl = expenseSummaryBO.getSplNeedPayData(appnum);
			if (specialNeedPayColl != null && !specialNeedPayColl.isEmpty()) {
				pageCollection.put("CP_APP_IN_SNP_Collection", specialNeedPayColl);
			} else {
				CP_APP_IN_SNP_Collection emptyCollection = new CP_APP_IN_SNP_Collection();
				pageCollection.put("CP_APP_IN_SNP_Collection", emptyCollection);

			}

		}catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getSpecialNeedsPayData()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLLAS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.getSpecialNeedsPayData() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );

	}
	
	
	
	

	private void getCareCostSummary(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getCareCostSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			List<Integer> indvIdList = getIndvsList(pageCollection);
			
			CP_ABCHS_Collection appInCareCostColl = expenseSummaryBO.getCareCostSummaryDetails(appnum, indvIdList);
			if (appInCareCostColl.size() > 0) {
				pageCollection.put("CP_ABCHS_Collection", appInCareCostColl);
			} else {
				CP_ABCHS_Collection emptyCollection = new CP_ABCHS_Collection();
				pageCollection.put("CP_ABCHS_Collection", emptyCollection);

			}

		}  catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getCareCostSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLLAS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, "getCareCostSummary", fe);
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.getCareCostSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );

	}

	private void getStudentLoanReview(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getStudentLoanReview() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			List<Integer> indvIdList = getIndvsList(pageCollection);
			
			CP_APP_IN_INCOME_TAX_DED_Collection appInCareCostColl = expenseSummaryBO
					.getStudentLoanReviewDetails(appnum, indvIdList);
			if (appInCareCostColl.size() > 0) {
				pageCollection.put("CP_APP_IN_INCOME_TAX_DED_Collection", appInCareCostColl);
			} else {
				CP_APP_IN_INCOME_TAX_DED_Collection emptyCollection = new CP_APP_IN_INCOME_TAX_DED_Collection();
				pageCollection.put("CP_APP_IN_INCOME_TAX_DED_Collection", emptyCollection);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getStudentLoanReview()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLLAS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.getStudentLoanReview() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	private void getCourtOrderedSummary(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.getCourtOrderedSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			List<Integer> indvIdList = getIndvsList(pageCollection);
			
			CP_APP_IN_DEDUCTION_Collection appInDedColl = expenseSummaryBO.getCourtOrderedSummaryDetails(appnum, indvIdList);
			if (appInDedColl.size() > 0) {
				pageCollection.put("CP_APP_IN_DEDUCTION_Collection", appInDedColl);
			} else {
				CP_APP_IN_DEDUCTION_Collection emptyCollection = new CP_APP_IN_DEDUCTION_Collection();
				pageCollection.put("CP_APP_IN_DEDUCTION_Collection", emptyCollection);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getCourtOrderedSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLLAS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.getCourtOrderedSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );

	}

	private void getMedicalSummary(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getMedicalSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appnum = userDetails.getAppNumber();
			List<Integer> indvIdList = getIndvsList(pageCollection);
			CP_APP_IN_MED_BILLS_Collection appInMedColl = expenseSummaryBO.getMedicalSummaryDetails(appnum, indvIdList);
			if (appInMedColl!= null && !appInMedColl.isEmpty()) {
				pageCollection.put("CP_APP_IN_MED_BILLS_Collection", appInMedColl);
			} else {
				CP_APP_IN_MED_BILLS_Collection emptyCollection = new CP_APP_IN_MED_BILLS_Collection();
				pageCollection.put("CP_APP_IN_MED_BILLS_Collection", emptyCollection);

			}

		}catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getMedicalSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLLAS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.getMedicalSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );

	}

	private void getHeathInsuranceSummary(FwTransaction fwTxn) throws Exception {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.getHeathInsuranceSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();




			
			CP_APP_IN_LST_HLTH_INS_Collection lstHlthColl = getHealthInsuranceDetails(fwTxn);
			if(lstHlthColl != null && !lstHlthColl.isEmpty()) {
				pageCollection.put(CP_APP_IN_LST_HLTH_INS_COLL, lstHlthColl);
			}else {
				pageCollection.put(CP_APP_IN_LST_HLTH_INS_COLL, new CP_APP_IN_LST_HLTH_INS_Collection());
			}

			CP_APP_IN_MED_INS_Collection appInInsColl = getCurrentlyEnrolledDetails(fwTxn);
			if (appInInsColl != null && !appInInsColl.isEmpty()) {
				pageCollection.put(CP_APP_IN_MED_INS_COLL, appInInsColl);
			} else {
				pageCollection.put(CP_APP_IN_MED_INS_COLL, new CP_APP_IN_MED_INS_Collection());
			}
			
			APP_IN_EMPL_HEALTH_Collection emplHealthColl = getEmplHelathDetails(fwTxn);
			if (emplHealthColl != null && !emplHealthColl.isEmpty()) {
				pageCollection.put(APP_IN_EMPL_HEALTH_COLL, emplHealthColl);
			} else {
				pageCollection.put(APP_IN_EMPL_HEALTH_COLL, new APP_IN_EMPL_HEALTH_Collection());
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getHeathInsuranceSummary()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERVICE_CLLAS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, GET_HEAL_SUMM, fe);
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.getHeathInsuranceSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );

	}
	
	public APP_INDV_Collection getIndvList(FwTransaction fwTx) throws Exception{
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getIndvList() - START", fwTx);
        try {
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, ""+fwTx.getCurrentActionDetails().getPageAction());
        FwTransaction lamdaFwTransaction =  prepareTxnBeanForLambdaCall(fwTx,"INDIB","INDIBLoad");

        String payload = ServiceChainUtil.prepareAWSRequest(FwConstants.POST, FwConstants.HH_INDV_LIST_URL, FwConstants.HH_INDV_LIST_URL, lamdaFwTransaction);
        
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Gateway indvlist complete");
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Payload received for indvlist "+payload);
        
        AWSLambda  client = AWSLambdaClient.builder().withRegion(System.getenv(FwConstants.REGION_SYS_ENV)).build();
        
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, ""+System.getenv(FwConstants.HOUSEHOLD_FUNC_SYS_ENV));

      InvokeRequest request = new InvokeRequest();
      request.setInvocationType(InvocationType.RequestResponse);
      request.setFunctionName(System.getenv(FwConstants.HOUSEHOLD_FUNC_SYS_ENV));
      request.setPayload(payload);
      
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Invoking indvlist client");
        InvokeResult invoke = client.invoke(request);
        String response = null;
        DriverPageResponse pageResponse;
        APP_INDV_Collection indvColl = new APP_INDV_Collection();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Status code indvlist: "+invoke.getStatusCode());
               
               if(invoke.getStatusCode() == 200) { 
                      response = new String(invoke.getPayload().array(), FwConstants.ENCODING_UTF); 
                      FwLogger.log(this.getClass(),
               FwLogger.Level.INFO, "Indvlist Response received : "+response);
               
                }
               
        
         if(response !=null) {
               ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
               try{
                     FwLogger.log(this.getClass(), FwLogger.Level.INFO, "");
                     
                      ServiceResponseCargo responseObj = mapper.readValue(response, ServiceResponseCargo.class);

                     String body = responseObj.getBody();
                     
                     
                      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "IndvList Body Received: "+body);

                     pageResponse= mapper.readValue(body, DriverPageResponse.class);
                     Map pageObject = pageResponse.getPageCollection();
                     indvColl  = (APP_INDV_Collection) pageResponse.getCollectionData(pageObject, FwConstants.APP_INDV_COLLECTION);
                     
                      
                      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "IndvList Object fetched");

               }
               catch (Exception e) {
                    FwLogger.log(this.getClass(), FwLogger.Level.ERROR, ERROR_MESSAGE, fwTx);
   				 throw e;
                    
               }
        }
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Inside getIndvList*** returned indvColl is: "+indvColl);
        return indvColl;
        } catch (final Exception e) {
        	FwLogger.log(this.getClass(), FwLogger.Level.ERROR, ERROR_MESSAGE, fwTx);
			throw e;
		}

  }
	public APP_IN_DABL_Collection getHousholdDisabilityList(FwTransaction fwTx) throws Exception {  FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Inside getHousholdDisabilityList method");
    
    FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Preparing getHousholdDisabilityList Object");
    try {
    FwLogger.log(this.getClass(), FwLogger.Level.INFO, ""+fwTx.getCurrentActionDetails().getPageAction());
    FwTransaction lamdaFwTransaction =  prepareTxnBeanForLambdaCall(fwTx,"ABDSU","ABDSULoad");
    String payload = ServiceChainUtil.prepareAWSRequest("POST", "/hhdemographics/ABDSU/ABDSULoad", "/hhdemographics/ABDSU/ABDSULoad", lamdaFwTransaction);
    
    FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Gateway indvlist complete");
    FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Payload received for indvlist "+payload);
    
    AWSLambda  client = AWSLambdaClient.builder().withRegion(System.getenv(FwConstants.REGION_SYS_ENV)).build();
    
    FwLogger.log(this.getClass(), FwLogger.Level.INFO, ""+System.getenv(FwConstants.HOUSEHOLD_FUNC_SYS_ENV));

  InvokeRequest request = new InvokeRequest();
  request.setInvocationType(InvocationType.RequestResponse);
  request.setFunctionName(System.getenv(FwConstants.HOUSEHOLD_FUNC_SYS_ENV));
  request.setPayload(payload);
  
    FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Invoking indvlist client");
    InvokeResult invoke = client.invoke(request);
    String response = null;
    DriverPageResponse pageResponse;
    APP_IN_DABL_Collection indvDisablColl = new APP_IN_DABL_Collection();
    FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Status code indvlist: "+invoke.getStatusCode());
           
    if(invoke.getStatusCode() == 200) 
    { response = new
           String(invoke.getPayload().array(), FwConstants.ENCODING_UTF); FwLogger.log(this.getClass(),
           FwLogger.Level.INFO, "Indvlist Response received : "+response);
     }
           
    
     if(response !=null) {
           ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
           try{
                 FwLogger.log(this.getClass(), FwLogger.Level.INFO, "");
                 
                  ServiceResponseCargo responseObj = mapper.readValue(response, ServiceResponseCargo.class);

                 String body = responseObj.getBody();
                 
                 
                  FwLogger.log(this.getClass(), FwLogger.Level.INFO, "IndvList Body Received: "+body);

                 pageResponse= mapper.readValue(body, DriverPageResponse.class);
                 Map pageObject = pageResponse.getPageCollection();
                 indvDisablColl  = (APP_IN_DABL_Collection) pageResponse.getCollectionData(pageObject, "APP_IN_DABL_Collection");
                 
                  
                  FwLogger.log(this.getClass(), FwLogger.Level.INFO, "IndvList Object fetched");

           }
           catch (Exception e) {
        	   FwLogger.log(this.getClass(), FwLogger.Level.ERROR, ERROR_MESSAGE, fwTx);

                throw e;
           }
    }
     FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getIndvList() - END", fwTx);
    return indvDisablColl;
    } catch (final Exception e) {
    	FwLogger.log(this.getClass(), FwLogger.Level.ERROR, ERROR_MESSAGE, fwTx);
		throw e;
	}
  }

	public CP_APP_IN_LST_HLTH_INS_Collection getHealthInsuranceDetails(FwTransaction fwTxn) throws Exception{
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getHealthInsuranceDetails() - START", fwTxn);
	      try {
	    	 FwTransaction lamdaFwTransaction =  prepareTxnBeanForLambdaCall(fwTxn,"ABLHI","ABLHILoad");
	      
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, ""+fwTxn.getCurrentActionDetails().getPageAction());

	      String payload = ServiceChainUtil.prepareAWSRequest("POST", "/nonfinancialinfo/ABLHI/ABLHILoad", "/nonfinancialinfo/ABLHI/ABLHILoad", lamdaFwTransaction);
	      
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Gateway healthInsuranceDetails complete");
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Payload received for healthInsuranceDetails "+payload);
	      
	      AWSLambda  client = AWSLambdaClient.builder().withRegion(System.getenv(FwConstants.REGION_SYS_ENV)).build();
	      
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, ""+System.getenv(FwConstants.NONFIN_FUNC_SYS_ENV));

	      InvokeRequest request = new InvokeRequest();
	      request.setInvocationType(InvocationType.RequestResponse);
	      request.setFunctionName(System.getenv(FwConstants.NONFIN_FUNC_SYS_ENV));
	      request.setPayload(payload);
	    
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Invoking healthInsuranceDetails client");
	      InvokeResult invoke = client.invoke(request);
	      String response = null;
	      DriverPageResponse pageResponse;
	      CP_APP_IN_LST_HLTH_INS_Collection hlthInsColl = new CP_APP_IN_LST_HLTH_INS_Collection();
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Status code healthInsuranceDetails: "+invoke.getStatusCode());
	             
	      if(invoke.getStatusCode() == 200) { response = new
	      String(invoke.getPayload().array(), FwConstants.ENCODING_UTF); FwLogger.log(this.getClass(),
	      FwLogger.Level.INFO, "HealthInsuranceDetails Response received : "+response);     
	      }
	             
	       if(response !=null) {
	    	   ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	           try{
	        	   	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "");
	                ServiceResponseCargo responseObj = mapper.readValue(response, ServiceResponseCargo.class);
	                String body = responseObj.getBody();
	                
	                FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HealthInsuranceDetails Body Received: "+body);
	                pageResponse= mapper.readValue(body, DriverPageResponse.class);
	                Map pageObject = pageResponse.getPageCollection();
	                hlthInsColl  = (CP_APP_IN_LST_HLTH_INS_Collection) pageResponse.getCollectionData(pageObject, CP_APP_IN_LST_HLTH_INS_COLL);
	          
	                FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HealthInsuranceDetails Object fetched");
	             }
	             catch (Exception e) {
	                 // e.printStackTrace();
	            	 FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getHealthInsuranceDetails()", fwTxn);
	                  throw e;
	             }
	      }
	       FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getHealthInsuranceDetails() - END", fwTxn);
	       return hlthInsColl;
	      }
	      catch (Exception e) {
	    	  FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getHealthInsuranceDetails()", fwTxn);
             throw e;
         }
	    }
	
	public CP_APP_IN_MED_INS_Collection getCurrentlyEnrolledDetails(FwTransaction fwTxn) throws Exception{
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getCurrentlyEnrolledDetails() - START", fwTxn);
	      try {
	    	  FwTransaction lamdaFwTransaction =  prepareTxnBeanForLambdaCall(fwTxn,"ABCER","ABCERLoad");
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, ""+fwTxn.getCurrentActionDetails().getPageAction());

	      String payload = ServiceChainUtil.prepareAWSRequest("POST", "/nonfinancialinfo/ABCER/ABCERLoad", "/nonfinancialinfo/ABCER/ABCERLoad", lamdaFwTransaction);
	      
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Gateway currentlyEnrolledDetails complete");
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Payload received for currentlyEnrolledDetails "+payload);
	      
	      AWSLambda  client = AWSLambdaClient.builder().withRegion(System.getenv(FwConstants.REGION_SYS_ENV)).build();
	      
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, ""+System.getenv(FwConstants.NONFIN_FUNC_SYS_ENV));

	      InvokeRequest request = new InvokeRequest();
	      request.setInvocationType(InvocationType.RequestResponse);
	      request.setFunctionName(System.getenv(FwConstants.NONFIN_FUNC_SYS_ENV));
	      request.setPayload(payload);
	    
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Invoking currentlyEnrolledDetails client");
	      InvokeResult invoke = client.invoke(request);
	      String response = null;
	      DriverPageResponse pageResponse;
	      CP_APP_IN_MED_INS_Collection curntlyEnroldColl = new CP_APP_IN_MED_INS_Collection();
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Status code currentlyEnrolledDetails: "+invoke.getStatusCode());
	             
	      if(invoke.getStatusCode() == 200) { response = new
	      String(invoke.getPayload().array(), FwConstants.ENCODING_UTF); FwLogger.log(this.getClass(),
	      FwLogger.Level.INFO, "currentlyEnrolledDetails Response received : "+response);     
	      }
	             
	       if(response !=null) {
	    	   ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	           try{
	        	   	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "");
	                ServiceResponseCargo responseObj = mapper.readValue(response, ServiceResponseCargo.class);
	                String body = responseObj.getBody();
	               
	                FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CurrentlyEnrolledDetails Body Received: "+body);
	                pageResponse= mapper.readValue(body, DriverPageResponse.class);
	                Map pageObject = pageResponse.getPageCollection();
	                curntlyEnroldColl  = (CP_APP_IN_MED_INS_Collection) pageResponse.getCollectionData(pageObject, CP_APP_IN_MED_INS_COLL);
	          
	                FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CurrentlyEnrolledDetails Object fetched");
	             }
	             catch (Exception e) {
	                 // e.printStackTrace();
	            	 FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getCurrentlyEnrolledDetails()", fwTxn);
	                
	                  throw e;
	             }
	      }
	       FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getCurrentlyEnrolledDetails() - END", fwTxn);
	       return curntlyEnroldColl;
	      }
	      catch (final Exception e) {
	    	  FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getCurrentlyEnrolledDetails()", fwTxn);
				throw e;
	      }
	     
      }
	
	public APP_IN_EMPL_HEALTH_Collection getEmplHelathDetails(FwTransaction fwTxn) throws Exception{
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getEmplHelathDetails() - START", fwTxn);
	      try {
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, ""+fwTxn.getCurrentActionDetails().getPageAction());
	      FwTransaction lamdaFwTransaction =  prepareTxnBeanForLambdaCall(fwTxn,"ABECS","ABECSLoad");
	      String payload = ServiceChainUtil.prepareAWSRequest("POST", "/nonfinancialinfo/ABECS/ABECSLoad", "/nonfinancialinfo/ABECS/ABECSLoad", lamdaFwTransaction);
	      
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Gateway EmplHelathDetails complete");
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Payload received for EmplHelathDetails "+payload);
	      
	      AWSLambda  client = AWSLambdaClient.builder().withRegion(System.getenv(FwConstants.REGION_SYS_ENV)).build();
	      
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, ""+System.getenv(FwConstants.NONFIN_FUNC_SYS_ENV));

	      InvokeRequest request = new InvokeRequest();
	      request.setInvocationType(InvocationType.RequestResponse);
	      request.setFunctionName(System.getenv(FwConstants.NONFIN_FUNC_SYS_ENV));
	      request.setPayload(payload);
	    
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Invoking EmplHelathDetails client");
	      InvokeResult invoke = client.invoke(request);
	      String response = null;
	      DriverPageResponse pageResponse;
	      APP_IN_EMPL_HEALTH_Collection emplHlthColl = new APP_IN_EMPL_HEALTH_Collection();
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Status code EmplHelathDetails: "+invoke.getStatusCode());
	             
	      if(invoke.getStatusCode() == 200) { response = new
	      String(invoke.getPayload().array(), FwConstants.ENCODING_UTF); FwLogger.log(this.getClass(),
	      FwLogger.Level.INFO, "EmplHelathDetails Response received : "+response);     
	      }
	             
	       if(response !=null) {
	    	   ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	           try{
	        	   	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "");
	                ServiceResponseCargo responseObj = mapper.readValue(response, ServiceResponseCargo.class);
	                String body = responseObj.getBody();
	               
	                FwLogger.log(this.getClass(), FwLogger.Level.INFO, "EmplHelathDetails Body Received: "+body);
	                pageResponse= mapper.readValue(body, DriverPageResponse.class);
	                Map pageObject = pageResponse.getPageCollection();
	                emplHlthColl  = (APP_IN_EMPL_HEALTH_Collection) pageResponse.getCollectionData(pageObject, APP_IN_EMPL_HEALTH_COLL);
	          
	                FwLogger.log(this.getClass(), FwLogger.Level.INFO, "EmplHelathDetails Object fetched");
	             }
	             catch (Exception e) {
	                
	            	 FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getEmplHelathDetails()",fwTxn);
	                  throw e;
	             }
	      }
	       FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryServiceImpl.getEmplHelathDetails() - END", fwTxn);
	       return emplHlthColl;
	      }
	      catch (final Exception e) {
	    	  FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in ExpenseSummaryServiceImpl.getEmplHelathDetails()", fwTxn);
				throw e;
		}
	     
	    } 
	
	public FwTransaction prepareTxnBeanForLambdaCall(FwTransaction fwTrx,String pageId, String pageAction) {
		FwTransaction lambdaFwTransaction = new FwTransaction();
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ExpenseSummaryServiceImpl.prepareTxnBeanForLambdaCall() - START");
			Map inputPageCollection = fwTrx.getPageCollection();		
			PageActionDetails pageActionDetails = new PageActionDetails();
			Map pageCollection = new HashMap<Object, Object>();			
			lambdaFwTransaction.setUserDetails(fwTrx.getUserDetails());
			pageActionDetails.setPageAction(pageAction);
			pageActionDetails.setPageId(pageId);
			lambdaFwTransaction.setCurrentActionDetails(pageActionDetails);	
			ArrayList<String> indvIds = (ArrayList<String>) inputPageCollection.get(INDV_ID);
			pageCollection.put(INDV_ID, indvIds);
			lambdaFwTransaction.setPageCollection(pageCollection);
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, "prepareTxnBeanForLambdaCall", e);
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ExpenseSummaryServiceImpl.prepareTxnBeanForLambdaCall() - END");
		return lambdaFwTransaction;
	}
	}