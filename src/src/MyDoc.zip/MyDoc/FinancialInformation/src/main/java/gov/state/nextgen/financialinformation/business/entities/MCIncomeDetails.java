package gov.state.nextgen.financialinformation.business.entities;

import java.util.List;

public class MCIncomeDetails {


private String incomeCd;
private List<MCIncomeIndividual_Cargo> incomeIndvList;

public String getIncomeCd() {
	return incomeCd;
}
public void setIncomeCd(String incomeCd) {
	this.incomeCd = incomeCd;
}

public List<MCIncomeIndividual_Cargo> getIncomeIndvList() {
	return incomeIndvList;
}
public void setIncomeIndvList(List<MCIncomeIndividual_Cargo> incomeIndvList) {
	this.incomeIndvList = incomeIndvList;
}

}