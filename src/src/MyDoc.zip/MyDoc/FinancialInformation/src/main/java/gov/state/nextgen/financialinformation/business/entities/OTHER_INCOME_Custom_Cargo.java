/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.management.util.FWUtils;

public class OTHER_INCOME_Custom_Cargo {

	private long[] pins;
	private long[] seqs;
	private APP_IN_UEI_Collection ueColl;
	private String caseNum = null;
	private APP_IN_RM_BRD_INCM_Collection rmBrdColl;
	private String[] types;

	public String getCaseNum() {
		return caseNum;
	}

	public void setCaseNum(final String caseNum) {
		this.caseNum = caseNum;
	}

	/**
	 * @return Returns the pins.
	 */
	public long[] getPins() {
		return pins.clone();
	}

	/**
	 * @param pins The pins to set.
	 */
	public void setPins(final long[] pins) {
		this.pins = FWUtils.arrayCopy(pins);
	}

	/**
	 * @return Returns the ueColl.
	 */
	public APP_IN_UEI_Collection getUeColl() {
		return ueColl;
	}

	/**
	 * @param ueColl The ueColl to set.
	 */
	public void setUeColl(final APP_IN_UEI_Collection ueColl) {
		this.ueColl = ueColl;
	}

	/**
	 * @return Returns the ueColl.
	 */
	public APP_IN_RM_BRD_INCM_Collection getRmBrdColl() {
		return rmBrdColl;
	}

	/**
	 * @param rmBrdColl The rmBrdColl to set.
	 */
	public void setRmBrdColl(final APP_IN_RM_BRD_INCM_Collection rmBrdColl) {
		this.rmBrdColl = rmBrdColl;
	}

	public long[] getSeqs() {
		return seqs.clone();
	}

	public void setSeqs(final long[] seqs) {
		this.seqs = FWUtils.arrayCopy(seqs);
	}

	/**
	 * @return Returns the types.
	 */
	public String[] getTypes() {
		return types.clone();
	}

	/**
	 * @param types The types to set.
	 */
	public void setTypes(final String[] types) {
		this.types = FWUtils.arrayCopy(types);
	}
}