/*
 * 
 */
package gov.state.nextgen.financialinformation.business.rules;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SHLTC_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SHLTC_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppInHouRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInShltcRepository;

/**
 * ABHousingBillsBO - Business Object skeleton auto generated - Architecture
 * Team
 *
 * Creation Date :Wed Dec 21 19:15:13 CST 2005 Modified By: Saravana Muppuru
 *           Modified on: Mon Feb 13 2006
 */
@Service("ARHousingBillDetailsBO")
public class ARHousingBillDetailsBO extends AbstractBO {
	
	@Autowired
	private AppInHouRepository appInHouRepository;
	
	private AppInShltcRepository appInShltcRepository;
	

	/**
	 * Constructor
	 */

	public APP_IN_SHLTC_Collection loadHouseBillDetails(final String appNumber) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,  "ARHousingBillDetailsBO.loadHouseBillDetails- START");
		try {

			final APP_IN_SHLTC_Collection appHousingBillIndvSelColl = new APP_IN_SHLTC_Collection();

			final APP_IN_SHLTC_Cargo[] appInHouseBillCargoArray = (APP_IN_SHLTC_Cargo[]) appInShltcRepository.getShltcByAppNumSorted(appNumber).stream().toArray(APP_IN_SHLTC_Cargo[] ::new);
			appHousingBillIndvSelColl.setResults(appInHouseBillCargoArray);
			FwLogger.log(this.getClass(), Level.INFO,  "ARHousingBillDetailsBO.loadHouseBillDetails - END , Time Taken : " + (System.currentTimeMillis() - startTime)
					);
			return appHousingBillIndvSelColl;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
	}

	
	public APP_IN_HOU_BILLS_Cargo splitOtherIncColl(final APP_IN_HOU_BILLS_Collection emplColl, final String recordIndicator) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,  "OtherIncomeBO.splitOtherIncColl() - START");
		try {
			if ((emplColl != null) && !emplColl.isEmpty()) {
				final int emplCollSize = emplColl.size();
				APP_IN_HOU_BILLS_Cargo emplCargo = null;
				for (int i = 0; i < emplCollSize; i++) {
					emplCargo = emplColl.getCargo(i);
					if (emplCargo.getSrc_app_ind().equals(recordIndicator)) {
						return emplColl.getCargo(i);
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO,  "OtherIncomeBO.splitOtherIncColl() - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
			return null;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

	}

	
	public void insertExistingDetails(final APP_IN_HOU_BILLS_Collection appInHouseBillColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,  "ARHousingBillDetailsBO.insertExistingDetails- START");

		    try {
            APP_IN_HOU_BILLS_Cargo appInHouBillsCargo = null;
            if (null!=appInHouseBillColl && !appInHouseBillColl.isEmpty()) {
                
            	appInHouBillsCargo = appInHouseBillColl.getCargo(0);
            	appInHouRepository.save(appInHouBillsCargo);
            }
        } catch (final FwException fe) {
            throw fe;
        } catch (final Exception e) {
            throw e;
        }
    
		FwLogger.log(this.getClass(), Level.INFO,  "ARHousingBillDetailsBO.insertExistingDetails - END , Time Taken : " + (System.currentTimeMillis() - startTime)
				);
	}



	public int getMaxSeqNumber(final String aAppNum, final int indvSeqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,  "OtherIncomeBO.getMaxEmplSeqNumber() - START");

		int maxSeqNum = 0;
		
		try {
			
			final List res = (List)appInHouRepository.getMaxSeqNum(Integer.parseInt(aAppNum), indvSeqNum);
			if (null!=res && !res.isEmpty() && null!=res.get(0)) {
				maxSeqNum = Integer.parseInt(res.get(0).toString());
			}
			
			FwLogger.log(this.getClass(), Level.INFO,  "OtherIncomeBO.getMaxEmplSeqNumber() - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
			return maxSeqNum;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

	}

	


	

	
	public APP_IN_HOU_BILLS_Cargo settingDefaultValues(final APP_IN_HOU_BILLS_Cargo houseCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,  "ARHousingBillDetailsBO.settingDefaultValues- START");
		try {
			if (houseCargo != null && houseCargo.getPymt_amt() == null) {
				// initialize date fields
				
					houseCargo.setPymt_amt(0.00);
				

			}
			FwLogger.log(this.getClass(), Level.INFO,  "ARHousingBillDetailsBO.settingDefaultValues - END , Time Taken : " + (System.currentTimeMillis() - startTime)
					);
			return houseCargo;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
	}

}
