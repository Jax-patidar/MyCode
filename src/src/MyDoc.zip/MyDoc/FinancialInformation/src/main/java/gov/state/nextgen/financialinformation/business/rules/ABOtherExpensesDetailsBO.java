package gov.state.nextgen.financialinformation.business.rules;

import java.sql.Date;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessage;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.access.management.util.AppValidationManager;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;

import gov.state.nextgen.financialinformation.data.db2.CP_ABCHS_Repository;

@Service("ABOtherExpensesDetailsBO")
public class ABOtherExpensesDetailsBO extends AbstractBO {

	@Autowired
	private CP_ABCHS_Repository careRepository;



	@Autowired
	private AppValidationManager appMgrs;

	private static final String TILDE = "~";
	private static final String MSG_30075 = "30075";
	
	private static final String ERROR_00019 = "00019";
	
	private static final String ERROR_00091 = "00091";
	
	private static final String ERROR_00032 = "00032";
	
	private static final String MILLI = " milliseconds";

	public boolean checkBackToMyAccessSelected(final Map request) {
		try {
		if (request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON) == null) {
			return false;
		}
		final String reqWarningMsgs = (String) request.get(FwConstants.WARNING_MSG_DETAILS);
		if ((reqWarningMsgs != null) && (reqWarningMsgs.trim().length() > 0)) {
			// Tokenizing the request warrning message and putting into a
			// list
			final StringTokenizer tokenizer = new StringTokenizer(reqWarningMsgs, TILDE);
			final List reqMsgList = new ArrayList();
			while (tokenizer.hasMoreElements()) {
				reqMsgList.add(tokenizer.nextElement());
			}
			if (reqMsgList.contains(MSG_30075)) {
				return true;
			}
		}
		final FwMessageList messageList = new FwMessageList();

		messageList.addMessageToList(addMessageCode(MSG_30075));
		request.put(FwConstants.MESSAGE_LIST, messageList);
		return true;
		} catch (final Exception e) {
			throw e;
		}
	}

	public void storeAppInCldIns(CP_ABCHS_Collection cpAppInCldCarePersistColl) {

		try {
		for (CP_ABCHS_Cargo data : cpAppInCldCarePersistColl.getResults()) {
			careRepository.save(data);
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	public int getMaxSeqNumber(String appNumber, int indvSeqNum) {
		int seqNum = 0;
		try {
		Integer result = careRepository.findMaxSeqNum(Integer.parseInt(appNumber), indvSeqNum);
		if (result != null) {
			seqNum = result;
		}
		return seqNum;
		} catch (final Exception e) {
			throw e;
		}
	}

	public CP_ABCHS_Cargo splitChildCareCargo(final CP_ABCHS_Collection cldInfoColl, final String recordIndicator) {
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.splitChildCareCargo() - START");
		try {
		if (cldInfoColl != null && !cldInfoColl.isEmpty()) {
			final int cldInfoCollSize = cldInfoColl.size();
			CP_ABCHS_Cargo cldInfoCargo = null;
			for (int i = 0; i < cldInfoCollSize; i++) {
				cldInfoCargo = cldInfoColl.getCargo(i);
				if (cldInfoCargo.getSrc_app_ind().equals(recordIndicator)) {
					return cldInfoCargo;
				}
			}
		}
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.splitChildCareCargo() - END");
		return null;
	}

	public APP_INDV_Cargo getIndividual() {
		return null;
	}

	public FwMessageList validateRMBChildStatus(CP_ABCHS_Cargo appCldCargo, String pagemode,
			String showLoopingQuestionFlag) {

		FwLogger.log(this.getClass(), Level.INFO, "HealthCareCoverageBO.validateRMBChildStatus() - START");
		FwMessageList validationInfo = new FwMessageList();

		try {
			final char[] specialChars = { '-', '\'', '.', ' ' };
			StringBuilder oneHundred20yearsAgo = null;
			final Calendar now = Calendar.getInstance();
			final int thisYear = now.get(Calendar.YEAR);
			oneHundred20yearsAgo = new StringBuilder(String.valueOf(thisYear - 120));
			oneHundred20yearsAgo = oneHundred20yearsAgo.append("-01-01");

			if (pagemode != null && "E".equals(pagemode)) {
				validateDependentCareDetails(appCldCargo, validationInfo, oneHundred20yearsAgo);
			} else {
				validatePrvdDetails(appCldCargo, showLoopingQuestionFlag, validationInfo, specialChars,
						oneHundred20yearsAgo);
			}

			FwLogger.log(this.getClass(), Level.INFO, "HealthCareCoverageBO.validateRMBPolicyHolder() - END");

			return validationInfo;

		} catch (final Exception e) {
			throw e;

		}

	}
	@SuppressWarnings("squid:S3776")
	private void validatePrvdDetails(CP_ABCHS_Cargo appCldCargo, String showLoopingQuestionFlag,
			FwMessageList validationInfo, final char[] specialChars, StringBuilder oneHundred20yearsAgo) {
		// Provider Name
		try {
		if (!appMgrs.isFieldEmpty(appCldCargo.getPrvd_org_nam())) {
			if (!appMgrs.isSpecialAlphaNumeric(appCldCargo.getPrvd_org_nam(), specialChars)) {
				final Object[] error = new Object[] { new FwMessageTextLabel("800000281") };
				validationInfo.addMessageToList(addMessageWithFieldValues("10446", error));
			}
		} else {
			validationInfo.addMessageToList(addMessageCode("00165"));
		}

		// validate addressLine1 and addressLine2
		FwMessageList messageList = validateAddressLine12(appCldCargo.getPrvd_addr_line1(),
				appCldCargo.getPrvd_addr_line2());
		if (messageList.hasMessages()) {
			validationInfo.addMessageToList(messageList);
		}

		// for the city
		if (StringUtils.isNotBlank(appCldCargo.getPrvd_addr_city()) && !appMgrs.isAlphaWithSpace(appCldCargo.getPrvd_addr_city())) {

			validationInfo.addMessageToList(addMessageCode("00018"));
			
		}

		// for Zip Address
		validateAddrDetail(appCldCargo, validationInfo);

		
		if (appMgrs.isFieldEmpty(Integer.toString(appCldCargo.getPaid_in_seq_num()))) {
			validationInfo.addMessageToList(addMessageCode("00163"));
		}
		// Payment Start Dt

		if (!appMgrs.isFieldEmpty((appCldCargo.getDependent_care_exp_start_dt()).toString())) {

			if (!appMgrs.validateDate(appCldCargo.getDependent_care_exp_start_dt())) {
				validationInfo.addMessageToList(addMessageCode(ERROR_00032));
			} else if (!appMgrs.futureDate(appCldCargo.getDependent_care_exp_start_dt())) {
				validationInfo.addMessageToList(addMessageCode("00033"));
			} else if (appMgrs.isDateBeforeDate(appCldCargo.getDependent_care_exp_start_dt(),
					Date.valueOf(oneHundred20yearsAgo.toString()))) {
				validationInfo.addMessageToList(addMessageCode(ERROR_00032));
			}
		} else {
			validationInfo.addMessageToList(addMessageCode("28043"));
		}

		/* Pay Frequency */
		validateIncDetail(appCldCargo, validationInfo);

		// Other Adult or Child Care //DEFECT 19409
		if ("Y".equalsIgnoreCase(showLoopingQuestionFlag)) {
			validationInfo.addMessageToList(validateAnotherChildCareQuestion(appCldCargo.getLoopingInd()));
		}
		validateChgDate(appCldCargo, validationInfo, oneHundred20yearsAgo);
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateChgDate(CP_ABCHS_Cargo appCldCargo, FwMessageList validationInfo,
			StringBuilder oneHundred20yearsAgo) {
		try {
		if (appCldCargo.getChg_dt() != null) {
			if (appMgrs.isFieldEmpty((appCldCargo.getChg_dt()).toString())) {
				validationInfo.addMessageToList(addMessageCode("99368"));
			}
			if (!appMgrs.isFieldEmpty((appCldCargo.getChg_dt()).toString())
					&& !appMgrs.validateDate(appCldCargo.getChg_dt())) {
				validationInfo.addMessageToList(addMessageCode("99365"));
			}
			if (appCldCargo.getChg_dt().before(Date.valueOf(oneHundred20yearsAgo.toString()))) {
				validationInfo.addMessageToList(addMessageCode("99366"));
			}
			java.util.Date nxtMnthLastDt = getNxtMnthlastDt();

			if (appCldCargo.getChg_dt().after(nxtMnthLastDt)) {
				validationInfo.addMessageToList(addMessageCode("99367"));
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateIncDetail(CP_ABCHS_Cargo appCldCargo, FwMessageList validationInfo) {
		try {
		if (appMgrs.isFieldEmpty(appCldCargo.getPay_freq())
				|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appCldCargo.getPay_freq())) {
			validationInfo.addMessageToList(addMessageCode("00153"));
		}

		/* How Much */
		if (!appMgrs.isFieldEmpty(Double.toString(appCldCargo.getDpnd_care_exp_amt()))) {

			if (!appMgrs.isCurrency(appCldCargo.getDpnd_care_exp_amt())) {
				validationInfo.addMessageToList(addMessageCode("00152"));

			} else if (appCldCargo.getDpnd_care_exp_amt() < 0
					|| appCldCargo.getDpnd_care_exp_amt() > 9999999.99) {
				validationInfo.addMessageToList(addMessageCode("99322"));

			}
		} else {
			validationInfo.addMessageToList(addMessageCode("28045"));

		}
		} catch (final Exception e) {
			throw e;
		}
	}
	@SuppressWarnings("squid:S3776")
	private void validateAddrDetail(CP_ABCHS_Cargo appCldCargo, FwMessageList validationInfo) {
		try {
		if (StringUtils.isNotBlank(appCldCargo.getPrvd_addr_zip())) {
			if (!appMgrs.isInteger(appCldCargo.getPrvd_addr_zip())) {
				validationInfo.addMessageToList(addMessageCode(ERROR_00019));
			} else if (!appMgrs.isZero(appCldCargo.getPrvd_addr_zip())) {
				validationInfo.addMessageToList(addMessageCode("00022"));
			} else if (!(appCldCargo.getPrvd_addr_zip().length() == 5
					|| appCldCargo.getPrvd_addr_zip().length() == 9)) {
				validationInfo.addMessageToList(addMessageCode("90748"));
			}
		}
		if (!validationInfo.containsMessage(ERROR_00019) && appCldCargo.getAddrZip4() != null
				&& !"".equals(appCldCargo.getAddrZip4().trim()) && !appCldCargo.getAddrZip4().matches("\\d+")) {
			validationInfo.addMessageToList(addMessageCode(ERROR_00019));

		}

		if (StringUtils.isNotBlank(appCldCargo.getPrvd_phone_num())) {
			if (!appMgrs.isInteger(appCldCargo.getPrvd_phone_num())) {
				validationInfo.addMessageToList(addMessageCode(ERROR_00091));
			} else if (!appMgrs.validatePhone(appCldCargo.getPrvd_phone_num())) {
				validationInfo.addMessageToList(addMessageCode(ERROR_00091));
			} else if (appCldCargo.getPrvd_phone_num().charAt(0) == '0') {
				validationInfo.addMessageToList(addMessageCode("10238"));
			}
		}
		if (appMgrs.isFieldEmpty(appCldCargo.getDpnd_care_exp_rsn_cd())
				|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appCldCargo.getDpnd_care_exp_rsn_cd())) {
			validationInfo.addMessageToList(addMessageCode("00162"));
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateDependentCareDetails(CP_ABCHS_Cargo appCldCargo, FwMessageList validationInfo,
			StringBuilder oneHundred20yearsAgo) {
		try {
		if (appMgrs.isFieldEmpty((appCldCargo.getDependent_care_exp_end_dt()).toString())) {
			validationInfo.addMessageToList(addMessageCode("99091"));
		}

		if (!appMgrs.isFieldEmpty((appCldCargo.getDependent_care_exp_end_dt()).toString())) {
			 if ((!appMgrs.futureDate(appCldCargo.getDependent_care_exp_end_dt())) || (appMgrs.isDateBeforeDate(appCldCargo.getDependent_care_exp_end_dt(),
					Date.valueOf(oneHundred20yearsAgo.toString())))) {
				validationInfo.addMessageToList(addMessageCode("00147"));
			} 
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	// validate addressline1 and 2 : 00017
	private FwMessageList validateAddressLine12(final String addrLine1, final String addrLine2) {
		FwMessageList messageList = new FwMessageList();
		boolean msgAdded = false;
		final char[] specialCharsForAddress = { '-', '\'', '.', '#', '/', ',', '&', ' ' };
		try {
		if (!appMgrs.isFieldEmpty(addrLine1) && !appMgrs.isSpecialAlphaNumeric(addrLine1, specialCharsForAddress)) {

			    messageList.addMessageToList(addMessageCode("00017"));
				msgAdded = true;
			
		}

		if (!msgAdded && !appMgrs.isFieldEmpty(addrLine2) && !appMgrs.isSpecialAlphaNumeric(addrLine2, specialCharsForAddress)) {

			     messageList.addMessageToList(addMessageCode("00017"));
			
		}

		return messageList;
		} catch (final Exception e) {
			throw e;
		}

	}

	private FwMessageList validateAnotherChildCareQuestion(final String question) {
		FwMessageList messageList = new FwMessageList();
		try {
		if (question == null || FwConstants.EMPTY_STRING.equals(question)) {
			messageList.addMessageToList(addMessageCode("00164"));
		}
		return messageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	public CP_ABCHS_Collection getCareCollection(String appNumber, int indvSeqNum) {

		return careRepository.findByAppNumIndv(Integer.parseInt(appNumber), indvSeqNum);
	}

	public FwMessageList validateChildSupportExpenses(final CP_ABCHS_Cargo cargo, final String loopingQuestion) {
		FwMessageList valInfo = new FwMessageList();
		try {
		valInfo.addMessageToList(validateProviderName(cargo.getPrvd_org_nam()));
		valInfo.addMessageToList(validateAddressLine12(cargo.getPrvd_addr_line1(), cargo.getPrvd_addr_line2()));
		valInfo.addMessageToList(validateCity(cargo.getPrvd_addr_city()));
		valInfo.addMessageToList(validateZIP(cargo.getPrvd_addr_zip()));
		valInfo.addMessageToList(validateZIP4(cargo.getAddrZip4(), valInfo.containsMessage(ERROR_00019)));
		valInfo.addMessageToList(validatePhoneNumber(cargo.getPrvd_phone_num()));
		valInfo.addMessageToList(validateStartDate(cargo.getDependent_care_exp_start_dt()));
		valInfo.addMessageToList(validatePayFrequency(cargo.getPay_freq()));
		valInfo.addMessageToList(validateAmount(cargo.getDpnd_care_exp_amt().toString()));
		valInfo.addMessageToList(validateChildCareReasonCode(cargo.getDpnd_care_exp_rsn_cd()));
		valInfo.addMessageToList(validateOtherPerson(cargo.getPaid_in_seq_num().toString()));
		valInfo.addMessageToList(validateAnotherChildCareQuestion(loopingQuestion));

		FwMessageList validationInfo = new FwMessageList();

		List<FwMessage> messages = valInfo.getMessageList();

		for (FwMessage message : messages) {
			if (message != null) {
				validationInfo.addMessageToList(message);
			}
		}

		return validationInfo;
		} catch (final Exception e) {
			throw e;
		}
	}

	private FwMessageList validateProviderName(final String name) {
		FwMessageList messageList = new FwMessageList();
		try {
		if (name == null || FwConstants.EMPTY_STRING.equals(name.trim())) {
			messageList.addMessageToList(addMessageCode("00165"));
		}
		if (!appMgrs.isAlphaWithSpace(name)) {
			messageList.addMessageToList(addMessageCode("99237"));
		}

		return messageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	// validate city : 00018
	private FwMessageList validateCity(final String city) {
		FwMessageList messageList = new FwMessageList();
		try {
		if (StringUtils.isNotBlank(city) && !appMgrs.isAlphaWithSpace(city)) {

			messageList.addMessageToList(addMessageCode("00018"));
			
		}
		return messageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	// validate 00019 : Please enter numeric Zip Code.
	// validate zip : "00022": Zip Code cannot be all zeros.

	private FwMessageList validateZIP(final String apZipAdr) {
		FwMessageList messageList = new FwMessageList();
		try {
		if (!appMgrs.isFieldEmpty(apZipAdr)) {
			if (!appMgrs.isInteger(apZipAdr)) {
				messageList.addMessageToList(addMessageCode(ERROR_00019));
			} else if (!appMgrs.isZero(apZipAdr)) {
				messageList.addMessageToList(addMessageCode("00022"));
			}
		}
		return messageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	private FwMessageList validateZIP4(final String apZipAdr, boolean containsMsg) {
		FwMessageList messageList = new FwMessageList();
		try {
		if (!containsMsg && apZipAdr != null && !"".equals(apZipAdr.trim()) && !apZipAdr.matches("\\d+")) {
			messageList.addMessageToList(addMessageCode(ERROR_00019));
		}
		return messageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	// validate phone : 00020 : Please enter 10 numbers for Home Phone.

	// validate phone : 00091 : Please enter 10 numbers for Phone Number.

	private FwMessageList validatePhoneNumber(final String apPhoneNum) {
		FwMessageList messageList = new FwMessageList();
		try {
		if (!appMgrs.isFieldEmpty(apPhoneNum)) {
			if (!appMgrs.isInteger(apPhoneNum) || apPhoneNum.length() != 10) {
				messageList.addMessageToList(addMessageCode(ERROR_00091));
			} else if (apPhoneNum.charAt(0) == '0') {
				messageList.addMessageToList(addMessageCode("00092"));
			}
		}
		return messageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	private FwMessageList validatePayFrequency(final String payfreq) {
		FwMessageList messageList = new FwMessageList();
		try {
		if ((payfreq == null) || (FwConstants.DEFAULT_DROPDOWN_SEL.equals(payfreq))) {
			messageList.addMessageToList(addMessageCode("00153"));
		}
		return messageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	private FwMessageList validateChildCareReasonCode(final String code) {
		FwMessageList messageList = new FwMessageList();
		try {
		if (FwConstants.DEFAULT_DROPDOWN_SEL.equals(code.trim())) {
			messageList.addMessageToList(addMessageCode("00162"));
		}
		return messageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	// radio button validation
	private FwMessageList validateOtherPerson(final String select) {
		FwMessageList messageList = new FwMessageList();
		try {
		if (select == null) {
			messageList.addMessageToList(addMessageCode("00163"));
		}
		return messageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	// ERROR_00032 Start date is invalid.
	// 00033 : Start date cannot be greater than today.

	private FwMessageList validateStartDate(final java.util.Date startDate) {
		FwMessageList messageList = new FwMessageList();
		try {
		if (startDate != null && !appMgrs.isFieldEmpty(startDate.toString())) {
			if (!appMgrs.validateDate(startDate)) {
				messageList.addMessageToList(addMessageCode(ERROR_00032));
			} else if (!appMgrs.isFieldEmpty(startDate.toString()) && !appMgrs.futureDate(startDate)) {
				messageList.addMessageToList(addMessageCode("00033"));
			}
		} else {
			messageList.addMessageToList(addMessageCode("28043"));
		}
		return messageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	// 00152 : Please enter numeric amount.
	private FwMessageList validateAmount(final String howMuch) {
		FwMessageList messageList = new FwMessageList();
		try {
		if (!appMgrs.isFieldEmpty(howMuch)) {
			if (!appMgrs.isCurrency(howMuch)) {
				messageList.addMessageToList(addMessageCode("00152"));
			} else if (!appMgrs.isValidAmountLimit(howMuch)) {
				messageList.addMessageToList(addMessageCode("10034"));
			}
		} else {
			messageList.addMessageToList(addMessageCode("28045"));
		}
		return messageList;
		} catch (final Exception e) {
			throw e;
		}

	}

	public CP_ABCHS_Collection loadChildSupportExpenses(String appNum, Integer indvSeqNum, Integer seqNum) {
		try
		{
		final CP_ABCHS_Collection coll = careRepository.loadChildSupportExpenses(Integer.parseInt(appNum), indvSeqNum, seqNum);
		return coll;
		} catch (final Exception e) {
			throw e;
		}
	}

	public CP_ABCHS_Collection loadCldCareIns(final String appNumber, final Integer indvSeqNum, final Integer seqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.loadCldCareIns() - START");

		try {
			CP_ABCHS_Collection appcldcareColl = careRepository.loadCldCareIns(Integer.parseInt(appNumber), indvSeqNum, seqNum);
			FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.loadCldCareIns() - END , Time Taken : "
					+ (System.currentTimeMillis() - startTime) + MILLI);
			return appcldcareColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	public CP_ABCHS_Cargo settingDefaultValues(final CP_ABCHS_Cargo cldCareInfoCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.settingDefaultValues() - START");
		try {
			if (cldCareInfoCargo != null && cldCareInfoCargo.getSrc_app_ind() == null) {

				cldCareInfoCargo.setSrc_app_ind(FwConstants.EMPTY_STRING);
				
			}
			FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesDetailsBO.settingDefaultValues() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLI);
			return cldCareInfoCargo;
		}catch (final Exception e) {
			throw e;
		}
	}

	public CP_ABCHS_Collection loadChildcareCoverageIndv(final String appNumber, final Integer indvSeqNum,
			final Integer seqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.loadChildcareCoverageIndv() - START");
		try {
			final CP_ABCHS_Collection appInChildIndvColl = careRepository.loadChildcareCoverageIndv(Integer.parseInt(appNumber),
					indvSeqNum, seqNum);

			FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesDetailsBO.loadChildcareCoverageIndv() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLI);
			return appInChildIndvColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	public CP_ABCHS_Collection splitCldCareCargo(final CP_ABCHS_Collection cldInfoColl, final String recordIndicator) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.splitCldCareCargo() - START");

		try {
			final CP_ABCHS_Collection returnColl = new CP_ABCHS_Collection();
			if (cldInfoColl != null && !cldInfoColl.isEmpty()) {
				final int cldinfoCollSize = cldInfoColl.size();
				CP_ABCHS_Cargo cldInfoCargo = null;
				for (int i = 0; i < cldinfoCollSize; i++) {
					cldInfoCargo = cldInfoColl.getCargo(i);
					if (cldInfoCargo.getSrc_app_ind().equals(recordIndicator)) {
						returnColl.addCargo(cldInfoCargo);
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesDetailsBO.splitCldCareCargo() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLI);
			return returnColl;

		}catch (final Exception e) {
			throw e;
		}

	}

	public CP_ABCHS_Collection splitCldCareCargo(final CP_ABCHS_Collection cldInfoColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.splitCldCareCargo() - START");

		try {
			final CP_ABCHS_Collection returnColl = new CP_ABCHS_Collection();
			if (cldInfoColl != null && !cldInfoColl.isEmpty()) {
				final int cldinfoCollSize = cldInfoColl.size();
				CP_ABCHS_Cargo cldInfoCargo = null;
				for (int i = 0; i < cldinfoCollSize; i++) {
					cldInfoCargo = cldInfoColl.getCargo(i);
					if (AppConstants.CWW_RECORD_IND.equals(cldInfoCargo.getSrc_app_ind())
							|| AppConstants.RMC_MODIFIED_RECORD_IND.equals(cldInfoCargo.getSrc_app_ind())) {
						returnColl.addCargo(cldInfoCargo);
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesDetailsBO.splitCldCareCargo() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLI);
			return returnColl;

		}catch (final Exception e) {
			throw e;
		}

	}
	
	public CP_ABCHS_Cargo getMatchingCargo(
			final CP_ABCHS_Collection appIncldInsColl, final Integer paidInSeqNum) {
		final long startTime = System.currentTimeMillis();
		try {
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.getMatchingCargo() - START");
		if (appIncldInsColl == null || appIncldInsColl.isEmpty()) {
			return null;
		}
		final int appInCldInsCollSize = appIncldInsColl.size();
		CP_ABCHS_Cargo appInCldInsCargo = null;
		for (int i = 0; i < appInCldInsCollSize; i++) {
			appInCldInsCargo = appIncldInsColl.getCargo(i);
			if (appInCldInsCargo.getPaid_in_seq_num() != null
					&& appInCldInsCargo.getPaid_in_seq_num().equals(
							paidInSeqNum)) {
				return appInCldInsCargo;
			}
		}
		FwLogger.log(this.getClass(), Level.INFO,
				"HealthCareCoverageBO.getMatchingCargo() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						+ MILLI);
		return null;
		} catch (final Exception e) {
			throw e;
		}
	}
}
