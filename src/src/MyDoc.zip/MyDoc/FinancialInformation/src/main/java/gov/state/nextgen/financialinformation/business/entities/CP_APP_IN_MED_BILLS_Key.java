package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CP_APP_IN_MED_BILLS_Key implements Serializable {

	private static final long serialVersionUID = -5856912111725728238L;
	private Integer app_number;
	private Integer indv_seq_num;
	private Integer medical_seq_num;
	private String med_bill_type;
	
	public CP_APP_IN_MED_BILLS_Key(Integer app_num, Integer indv_seq_num, Integer medical_seq_num, String med_bill_type) {
		super();
		this.app_number = app_num;
		this.indv_seq_num = indv_seq_num;
		this.medical_seq_num = medical_seq_num;
		this.med_bill_type = med_bill_type;
		
	}
	public CP_APP_IN_MED_BILLS_Key() {

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((med_bill_type == null) ? 0 : med_bill_type.hashCode());
		result = prime * result + ((medical_seq_num == null) ? 0 : medical_seq_num.hashCode());
		return result;
	}
	@SuppressWarnings("squid:S3776")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CP_APP_IN_MED_BILLS_Key other = (CP_APP_IN_MED_BILLS_Key) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		if (med_bill_type == null) {
			if (other.med_bill_type != null)
				return false;
		} else if (!med_bill_type.equals(other.med_bill_type))
			return false;
		if (medical_seq_num == null) {
			if (other.medical_seq_num != null)
				return false;
		} else if (!medical_seq_num.equals(other.medical_seq_num))
			return false;

		return true;
	}

	
}
