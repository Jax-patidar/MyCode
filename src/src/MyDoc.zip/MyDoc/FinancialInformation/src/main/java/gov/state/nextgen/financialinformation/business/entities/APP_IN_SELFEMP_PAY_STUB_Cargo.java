package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;


/**
 * The persistent class for the cp_app_in_selfemp_pay_stub database table.
 * 
 */
@Entity
@Table(name="cp_app_in_selfemp_pay_stub")
@IdClass(CpAppInSelfempPayStubPK.class)
public class APP_IN_SELFEMP_PAY_STUB_Cargo extends AbstractCargo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Transient
	private String appNum;
	
	@Id
	@Column(name = "app_num")
	private int app_number;

	@Id
	private Integer indvSeqNum;

	@Id
	private Integer seqNum;

	public Integer getPayStubSeqNum() {
		return payStubSeqNum;
	}

	public void setPayStubSeqNum(Integer payStubSeqNum2) {
		this.payStubSeqNum = payStubSeqNum2;
	}

	@Id
	private Integer payStubSeqNum;
	
	public String getAppNum() {
		return String.valueOf(app_number);
	}

	public void setAppNum(String appNum) {
		this.app_number = Integer.parseInt(appNum);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.appNum = String.valueOf(app_number);
	}
	
	public Integer getIndvSeqNum() {
		return indvSeqNum;
	}

	public void setIndvSeqNum(Integer indvSeqNum) {
		this.indvSeqNum = indvSeqNum;
	}

	public Integer getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(Integer emplSeqNum) {
		this.seqNum = emplSeqNum;
	}

	@Column(name="payment_amt")
	private Double paymentAmt;

	@Column(name="payment_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate paymentDt;

	public APP_IN_SELFEMP_PAY_STUB_Cargo() {
		//Default constructor
	}


	public Double getPaymentAmt() {
		return this.paymentAmt;
	}

	public void setPaymentAmt(Double paymentAmt) {
		this.paymentAmt = paymentAmt;
	}

	public LocalDate getPaymentDt() {
		return this.paymentDt;
	}

	public void setPaymentDt(LocalDate paymentDt) {
		this.paymentDt = paymentDt;
	}

}