package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Id;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * This class contains the entities of CP_APP_INDV_ADDI_INFO
 *
 * Created by @DeloitteUSI team Creation Date Mon Jan 25 11:34:07 IST 2021
 */

public class CP_APP_INDV_ADDI_INFO_Cargo extends AbstractCargo implements Serializable {

	private static final long serialVersionUID = 6421274135373604777L;

	@Id
	@Column (name="app_num")
	private String app_num;
	@Column (name="indv_seq_num")
	private Integer indv_seq_num;
	@Column (name="gross_income_less")
	private String gross_income_less;
	@Column (name="combined_gross_income")
	private String combined_gross_income;
	@Column (name="mig_farm_worker_resp")
	private String mig_farm_wrkr_resp;
	@Column (name="src_app_ind")
	private String src_app_ind;
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public String getGross_income_less() {
		return gross_income_less;
	}
	public void setGross_income_less(String gross_income_less) {
		this.gross_income_less = gross_income_less;
	}
	public String getCombined_gross_income() {
		return combined_gross_income;
	}
	public void setCombined_gross_income(String combined_gross_income) {
		this.combined_gross_income = combined_gross_income;
	}
	public String getMig_farm_wrkr_resp() {
		return mig_farm_wrkr_resp;
	}
	public void setMig_farm_wrkr_resp(String mig_farm_wrkr_resp) {
		this.mig_farm_wrkr_resp = mig_farm_wrkr_resp;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((combined_gross_income == null) ? 0 : combined_gross_income.hashCode());
		result = prime * result + ((gross_income_less == null) ? 0 : gross_income_less.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((mig_farm_wrkr_resp == null) ? 0 : mig_farm_wrkr_resp.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}
	
	
}
