/*
 *
 */
package gov.state.nextgen.financialinformation.business.rules;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.financialinformation.business.entities.NO_ONE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.NO_ONE_Collection;

import java.util.Map;

import org.springframework.stereotype.Service;

/**
 * ABHousingTypeBO - Business Object skeleton auto generated - Architecture Team
 *
 * Creation Date :Wed Dec 21 19:15:13 CST 2005 Modified By: Modified on:
 */
@Service("ABHousingTypeBO")
public class ABHousingTypeBO extends AbstractBO {

	private static final String NONE_SEL_MSG_CD = "10255";

	/**
	 * Constructor
	 */

	public FwMessageList validateNoOneSheterType(final APP_IN_PRFL_Collection pageColl,final Map beforeFirstNamesList) {

		FwMessageList fwMessageList = new FwMessageList();


		FwLogger.log(this.getClass(), Level.INFO, "ABHousingBillsSummaryBO.validateNoOneSheterType) - START");
		try {
			String otherBill = null;
			String rentResp = null;
			String mtgeResp = null;
			String realResp = null;
			String homeResp = null;
			String disaster = null;
			String prevent = null;
			String other = null;
			if (null != pageColl) {
				for (int index = 0, size = pageColl.size(); index < size; index++) {
					final APP_IN_PRFL_Cargo appInPrflCargo = (APP_IN_PRFL_Cargo) pageColl.get(index);
					otherBill = appInPrflCargo.getOther_housing_bill_resp();
					rentResp = appInPrflCargo.getSu_cst_rent_resp();
					mtgeResp = appInPrflCargo.getSu_cst_mtge_resp();
					realResp = appInPrflCargo.getReal_estate_tax_resp();
					homeResp = appInPrflCargo.getSu_cst_home_resp();
					disaster = appInPrflCargo.getDisaster_repair_resp();
					prevent = appInPrflCargo.getPrevent_eviction_resp();
					other = appInPrflCargo.getOther_housing_resp();

					if (otherBill == null && rentResp == null && mtgeResp == null && realResp == null
							&& homeResp == null && disaster == null && prevent == null && other == null) {
						fwMessageList.addMessageToList(addMessageCode("99032"));
					}
					if (FwConstants.YES.equals(otherBill) && (FwConstants.YES.equals(rentResp) || FwConstants.YES.equals(mtgeResp)
								|| FwConstants.YES.equals(realResp) || FwConstants.YES.equals(homeResp)
								|| FwConstants.YES.equals(disaster) || FwConstants.YES.equals(prevent)
								|| FwConstants.YES.equals(other))) {

						
							fwMessageList.addMessageToList(addMessageCode(NONE_SEL_MSG_CD));
						}
						
				}
			}

			return fwMessageList;

		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * Compare AppInPrflBeforeColl and PageCollection and returns updated
	 * pageCollection with dummy cargo if not found in session
	 */
	public APP_IN_PRFL_Collection compareAppInPrflColl(final APP_IN_PRFL_Collection appInPrflCollSession,
			final APP_IN_PRFL_Collection pageColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHousingBillsSummaryBO.compareAppInPrflColl) - START");
		try {
			final int pageCollSize = pageColl.size();
			final int sessionSize = appInPrflCollSession.size();
			APP_IN_PRFL_Cargo beforeCargo = null;
			APP_IN_PRFL_Cargo afterCargo = null;
			boolean found = false;
			final APP_IN_PRFL_Collection appInPrflCollRequest = new APP_IN_PRFL_Collection();
			for (int i = 0; i < sessionSize; i++) {
				found = false;
				beforeCargo = appInPrflCollSession.getCargo(i);
				for (int j = 0; j < pageCollSize; j++) {
					afterCargo = pageColl.getCargo(j);
					if (beforeCargo.getIndv_seq_num().equals(afterCargo.getIndv_seq_num())) {
						appInPrflCollRequest.add(afterCargo);
						found = true;
						break;
					}
				}
				if (!found) {
					afterCargo = new APP_IN_PRFL_Cargo();
					afterCargo.setIndv_seq_num(beforeCargo.getIndv_seq_num());
					appInPrflCollRequest.add(afterCargo);
				}
			}

			FwLogger.log(this.getClass(), Level.INFO,
					"ABHousingBillsSummaryBO.compareAppInPrflColl - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + " milliseconds");
			return appInPrflCollRequest;

		} catch (final Exception e) {
			throw e;
		}

	}

	/**
	 * Compare NoOneCollectionSession and NoOnePageCollection and returns updated
	 * pageCollection with dummy cargo if not found in session
	 */
	public NO_ONE_Collection compareNoOneCollection(final NO_ONE_Collection noOneBeforeColl,
			final NO_ONE_Collection noOneAfterColl) {

		FwLogger.log(this.getClass(), Level.INFO, "ABHousingBillsSummaryBO.compareNoOneCollection) - START");
		try {
			final int noOneBeforeSize = noOneBeforeColl == null ? 0 : noOneBeforeColl.size();
			final int noOneAfterCollSize = noOneAfterColl == null ? 0 : noOneAfterColl.size();
			String noOneBeforeName = null;
			String noOneBeforeValue = null;
			String noOneAfterName = null;
			final NO_ONE_Collection newNoOneColl = new NO_ONE_Collection();
			NO_ONE_Cargo beforeNoOneCargo;
			NO_ONE_Cargo afterNoOneCargo;
			boolean found = false;

			for (int i = 0; i < noOneBeforeSize; i++) {
				found = false;
				beforeNoOneCargo = noOneBeforeColl.getResult(i);
				noOneBeforeName = beforeNoOneCargo.getNo_one_name();
				noOneBeforeValue = beforeNoOneCargo.getNo_one_value();

				for (int j = 0; j < noOneAfterCollSize; j++) {
					afterNoOneCargo = noOneAfterColl.getResult(j);
					noOneAfterName = afterNoOneCargo.getNo_one_name();
					if (noOneBeforeName.equals(noOneAfterName)) {
						newNoOneColl.add(afterNoOneCargo);
						found = true;
						break;
					}
				}
				if (!found) {
					afterNoOneCargo = new NO_ONE_Cargo();
					afterNoOneCargo.setNo_one_name(noOneBeforeName);
					afterNoOneCargo.setNo_one_value(noOneBeforeValue);
					newNoOneColl.add(afterNoOneCargo);

				}
			}
			return newNoOneColl;

		}  catch (final Exception e) {
			throw e;
		}

	}

}
