/**
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * @author khuskumari
 * Entity class for APP_IN_L_INS_ASET
 *
 */

public class APP_IN_L_INS_ASET_Cargo extends AbstractCargo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String app_num;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	@Id
	private String src_app_ind;
	private String ins_co_city_adr;
	private String ins_co_l1_adr;
	private String ins_co_l2_adr;
	private String ins_co_nam;
	private String ins_co_sta_adr;
	private String ins_co_zip_adr;
	private String life_ins_aset_typ;
	private Integer life_ins_f_amt_ind;
	private float life_ins_face_amt;
	private String life_ins_plcy_num;
	private Integer life_ins_s_amt_ind;
	private float life_ins_surr_amt;
	private String rec_cplt_ind;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date acquired_dt;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date asset_end_dt;
	private String cvrg_resp;
	private String insurance_company_phone_number;
	private String jnt_own_resp;
	private String adapt_record_id;
	private String ecp_id;
	private String addr_zip4;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date chg_dt;
	@Transient
	private String first_name;
	@Transient
	private String looping_ind;
	@Transient
	private String fst_nam;

	public String getFst_nam() {
		return fst_nam;
	}

	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}
	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return app_num;
	}
	/**
	 * @param app_num the app_num to set
	 */
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	/**
	 * @return the seq_num
	 */
	public Integer getSeq_num() {
		return seq_num;
	}
	/**
	 * @param seq_num the seq_num to set
	 */
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	/**
	 * @return the ins_co_city_adr
	 */
	public String getIns_co_city_adr() {
		return ins_co_city_adr;
	}
	/**
	 * @param ins_co_city_adr the ins_co_city_adr to set
	 */
	public void setIns_co_city_adr(String ins_co_city_adr) {
		this.ins_co_city_adr = ins_co_city_adr;
	}
	/**
	 * @return the ins_co_l1_adr
	 */
	public String getIns_co_l1_adr() {
		return ins_co_l1_adr;
	}
	/**
	 * @param ins_co_l1_adr the ins_co_l1_adr to set
	 */
	public void setIns_co_l1_adr(String ins_co_l1_adr) {
		this.ins_co_l1_adr = ins_co_l1_adr;
	}
	/**
	 * @return the ins_co_l2_adr
	 */
	public String getIns_co_l2_adr() {
		return ins_co_l2_adr;
	}
	/**
	 * @param ins_co_l2_adr the ins_co_l2_adr to set
	 */
	public void setIns_co_l2_adr(String ins_co_l2_adr) {
		this.ins_co_l2_adr = ins_co_l2_adr;
	}
	/**
	 * @return the ins_co_nam
	 */
	public String getIns_co_nam() {
		return ins_co_nam;
	}
	/**
	 * @param ins_co_nam the ins_co_nam to set
	 */
	public void setIns_co_nam(String ins_co_nam) {
		this.ins_co_nam = ins_co_nam;
	}
	/**
	 * @return the ins_co_sta_adr
	 */
	public String getIns_co_sta_adr() {
		return ins_co_sta_adr;
	}
	/**
	 * @param ins_co_sta_adr the ins_co_sta_adr to set
	 */
	public void setIns_co_sta_adr(String ins_co_sta_adr) {
		this.ins_co_sta_adr = ins_co_sta_adr;
	}
	/**
	 * @return the ins_co_zip_adr
	 */
	public String getIns_co_zip_adr() {
		return ins_co_zip_adr;
	}
	/**
	 * @param ins_co_zip_adr the ins_co_zip_adr to set
	 */
	public void setIns_co_zip_adr(String ins_co_zip_adr) {
		this.ins_co_zip_adr = ins_co_zip_adr;
	}
	/**
	 * @return the life_ins_aset_typ
	 */
	public String getLife_ins_aset_typ() {
		return life_ins_aset_typ;
	}
	/**
	 * @param life_ins_aset_typ the life_ins_aset_typ to set
	 */
	public void setLife_ins_aset_typ(String life_ins_aset_typ) {
		this.life_ins_aset_typ = life_ins_aset_typ;
	}
	/**
	 * @return the life_ins_f_amt_ind
	 */
	public Integer getLife_ins_f_amt_ind() {
		return life_ins_f_amt_ind;
	}
	/**
	 * @param life_ins_f_amt_ind the life_ins_f_amt_ind to set
	 */
	public void setLife_ins_f_amt_ind(Integer life_ins_f_amt_ind) {
		this.life_ins_f_amt_ind = life_ins_f_amt_ind;
	}
	/**
	 * @return the life_ins_face_amt
	 */
	public float getLife_ins_face_amt() {
		return life_ins_face_amt;
	}
	/**
	 * @param life_ins_face_amt the life_ins_face_amt to set
	 */
	public void setLife_ins_face_amt(float life_ins_face_amt) {
		this.life_ins_face_amt = life_ins_face_amt;
	}
	/**
	 * @return the life_ins_plcy_num
	 */
	public String getLife_ins_plcy_num() {
		return life_ins_plcy_num;
	}
	/**
	 * @param life_ins_plcy_num the life_ins_plcy_num to set
	 */
	public void setLife_ins_plcy_num(String life_ins_plcy_num) {
		this.life_ins_plcy_num = life_ins_plcy_num;
	}
	/**
	 * @return the life_ins_s_amt_ind
	 */
	public Integer getLife_ins_s_amt_ind() {
		return life_ins_s_amt_ind;
	}
	/**
	 * @param life_ins_s_amt_ind the life_ins_s_amt_ind to set
	 */
	public void setLife_ins_s_amt_ind(Integer life_ins_s_amt_ind) {
		this.life_ins_s_amt_ind = life_ins_s_amt_ind;
	}
	/**
	 * @return the life_ins_surr_amt
	 */
	public float getLife_ins_surr_amt() {
		return life_ins_surr_amt;
	}
	/**
	 * @param life_ins_surr_amt the life_ins_surr_amt to set
	 */
	public void setLife_ins_surr_amt(float life_ins_surr_amt) {
		this.life_ins_surr_amt = life_ins_surr_amt;
	}
	/**
	 * @return the rec_cplt_ind
	 */
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	/**
	 * @param rec_cplt_ind the rec_cplt_ind to set
	 */
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	/**
	 * @return the acquired_dt
	 */
	public Date getAcquired_dt() {
		return acquired_dt;
	}
	/**
	 * @param acquired_dt the acquired_dt to set
	 */
	public void setAcquired_dt(Date acquired_dt) {
		this.acquired_dt = acquired_dt;
	}
	/**
	 * @return the asset_end_dt
	 */
	public Date getAsset_end_dt() {
		return asset_end_dt;
	}
	/**
	 * @param asset_end_dt the asset_end_dt to set
	 */
	public void setAsset_end_dt(Date asset_end_dt) {
		this.asset_end_dt = asset_end_dt;
	}
	/**
	 * @return the cvrg_resp
	 */
	public String getCvrg_resp() {
		return cvrg_resp;
	}
	/**
	 * @param cvrg_resp the cvrg_resp to set
	 */
	public void setCvrg_resp(String cvrg_resp) {
		this.cvrg_resp = cvrg_resp;
	}
	/**
	 * @return the insurance_company_phone_number
	 */
	public String getInsurance_company_phone_number() {
		return insurance_company_phone_number;
	}
	/**
	 * @param insurance_company_phone_number the insurance_company_phone_number to set
	 */
	public void setInsurance_company_phone_number(String insurance_company_phone_number) {
		this.insurance_company_phone_number = insurance_company_phone_number;
	}
	/**
	 * @return the jnt_own_resp
	 */
	public String getJnt_own_resp() {
		return jnt_own_resp;
	}
	/**
	 * @param jnt_own_resp the jnt_own_resp to set
	 */
	public void setJnt_own_resp(String jnt_own_resp) {
		this.jnt_own_resp = jnt_own_resp;
	}
	/**
	 * @return the adapt_record_id
	 */
	public String getAdapt_record_id() {
		return adapt_record_id;
	}
	/**
	 * @param adapt_record_id the adapt_record_id to set
	 */
	public void setAdapt_record_id(String adapt_record_id) {
		this.adapt_record_id = adapt_record_id;
	}
	/**
	 * @return the ecp_id
	 */
	public String getEcp_id() {
		return ecp_id;
	}
	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	/**
	 * @return the addr_zip4
	 */
	public String getAddr_zip4() {
		return addr_zip4;
	}
	/**
	 * @param addr_zip4 the addr_zip4 to set
	 */
	public void setAddr_zip4(String addr_zip4) {
		this.addr_zip4 = addr_zip4;
	}
	/**
	 * @return the chg_dt
	 */
	public Date getChg_dt() {
		return chg_dt;
	}
	/**
	 * @param chg_dt the chg_dt to set
	 */
	public void setChg_dt(Date chg_dt) {
		this.chg_dt = chg_dt;
	}
	/**
	 * @return the first_name
	 */
	public String getFirst_name() {
		return first_name;
	}
	/**
	 * @param first_name the first_name to set
	 */
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	/**
	 * @return the looping_ind
	 */
	public String getLooping_ind() {
		return looping_ind;
	}
	/**
	 * @param looping_ind the looping_ind to set
	 */
	public void setLooping_ind(String looping_ind) {
		this.looping_ind = looping_ind;
	}
	
	
}
