package gov.state.nextgen.financialinformation.business.entities;


import java.util.Collection;

import gov.state.nextgen.access.business.entities.AbstractCollection;
import gov.state.nextgen.access.exceptions.FwException;

public class APP_RGST_Collection extends AbstractCollection {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8653237098010167069L;
	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.APP_RGST";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_RGST_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_RGST_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_RGST_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_RGST_Cargo[] getResults() {
		final APP_RGST_Cargo[] cbArray = new APP_RGST_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_RGST_Cargo getCargo(final int idx) {
		return (APP_RGST_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_RGST_Cargo[] cloneResults() {
		final APP_RGST_Cargo[] rescargo = new APP_RGST_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_RGST_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_RGST_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setEcp_id(cargo.getEcp_id());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setAlt_city_adr(cargo.getAlt_city_adr());
			rescargo[i].setAlt_l2_adr(cargo.getAlt_l2_adr());
			rescargo[i].setAlt_st_adr(cargo.getAlt_st_adr());
			rescargo[i].setAlt_sta_adr(cargo.getAlt_sta_adr());
			rescargo[i].setAlt_zip_adr(cargo.getAlt_zip_adr());
			rescargo[i].setChg_eff_dt(cargo.getChg_eff_dt());
			rescargo[i].setCnty_num(cargo.getCnty_num());
			rescargo[i].setHless_sw(cargo.getHless_sw());
			rescargo[i].setHshl_cell_phn_num(cargo.getHshl_cell_phn_num());
			rescargo[i].setHshl_city_adr(cargo.getHshl_city_adr());
			rescargo[i].setHshl_email_adr(cargo.getHshl_email_adr());
			rescargo[i].setHshl_home_phn_num(cargo.getHshl_home_phn_num());
			rescargo[i].setHshl_indv_ct(cargo.getHshl_indv_ct());
			rescargo[i].setHshl_l1_adr(cargo.getHshl_l1_adr());
			rescargo[i].setHshl_l2_adr(cargo.getHshl_l2_adr());
			rescargo[i].setHshl_sta_adr(cargo.getHshl_sta_adr());
			rescargo[i].setHshl_work_phn_num(cargo.getHshl_work_phn_num());
			rescargo[i].setHshl_zip_adr(cargo.getHshl_zip_adr());
			rescargo[i].setLang_cd(cargo.getLang_cd());
			rescargo[i].setMsg_phn_extn_num(cargo.getMsg_phn_extn_num());
			rescargo[i].setMsg_phn_num(cargo.getMsg_phn_num());
			rescargo[i].setPhn_num_typ(cargo.getPhn_num_typ());
			rescargo[i].setPref_cntc_ind(cargo.getPref_cntc_ind());
			rescargo[i].setPref_cntc_tm_txt(cargo.getPref_cntc_tm_txt());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setWork_phn_extn_num(cargo.getWork_phn_extn_num());
			rescargo[i].setDays_at_address_num(cargo.getDays_at_address_num());
			
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setLiving_arrangement_cd(cargo.getLiving_arrangement_cd());
			rescargo[i].setPast_state_cd(cargo.getPast_state_cd());
			rescargo[i].setPast_county_cd(cargo.getPast_county_cd());
			rescargo[i].setHshl_past_addr_ind(cargo.getHshl_past_addr_ind());
			rescargo[i].setPref_cont_method_cd(cargo.getPref_cont_method_cd());
			rescargo[i].setPref_deaf_cont_method_cd(cargo.getPref_deaf_cont_method_cd());
			rescargo[i].setPref_cont_time_cd(cargo.getPref_cont_time_cd());
			rescargo[i].setHome_addr_chg_begin_dt(cargo.getHome_addr_chg_begin_dt());
			rescargo[i].setChg_dt(cargo.getChg_dt());
			rescargo[i].setDirty(cargo.isDirty());
			rescargo[i].setWic_clnc_cnty(cargo.getWic_clnc_cnty());
			rescargo[i].setWic_clnc_cd(cargo.getWic_clnc_cd());
			rescargo[i].setWic_dsclsr(cargo.getWic_dsclsr());
			rescargo[i].setIs_cc_renewal(cargo.getIs_cc_renewal());
			rescargo[i].setCaps_id(cargo.getCaps_id());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_RGST_Cargo[]) {
			final APP_RGST_Cargo[] cbArray = (APP_RGST_Cargo[]) obj;
			setResults(cbArray);
		}
	}

	public APP_RGST_Cargo getResult(final int idx) {
		return (APP_RGST_Cargo) get(idx);
	}

	/**
	 * persist method. Pass the peristent type and instet/update args as a Map
	 *
	 * @param aPersist_type
	 *            java.lang.String
	 */
	public Collection persist(final String aPersist_type) throws FwException {

		return null;
	}
	

}
