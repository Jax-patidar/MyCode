/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;


public class APP_IN_EMPL_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_IN_EMPL";

	
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_EMPL_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_EMPL_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_EMPL_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_EMPL_Cargo[] getResults() {
		final APP_IN_EMPL_Cargo[] cbArray = new APP_IN_EMPL_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_EMPL_Cargo getCargo(final int idx) {
		return (APP_IN_EMPL_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_EMPL_Cargo[] cloneResults() {
		final APP_IN_EMPL_Cargo[] rescargo = new APP_IN_EMPL_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_EMPL_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_EMPL_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setEmpl_seq_num(cargo.getEmpl_seq_num());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());


			rescargo[i].setEmpl_end_dt(cargo.getEmpl_end_dt());
			rescargo[i].setEmpl_type(cargo.getEmpl_type());







			rescargo[i].setLast_payck_dt(cargo.getLast_payck_dt());
			rescargo[i].setPay_freq_cd(cargo.getPay_freq_cd());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());




			rescargo[i].setRef_job_sw(cargo.getRef_job_sw());
			rescargo[i].setJob_termination_reason(cargo.getJob_termination_reason());
			rescargo[i].setOn_strike_sw(cargo.getOn_strike_sw());
			rescargo[i].setExpected_to_cont_resp(cargo.getExpected_to_cont_resp());


		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_EMPL_Cargo[]) {
			final APP_IN_EMPL_Cargo[] cbArray = (APP_IN_EMPL_Cargo[]) obj;
			setResults(cbArray);
		}
	}

	public APP_IN_EMPL_Cargo getResult(final int idx) {
		return (APP_IN_EMPL_Cargo) get(idx);
	}
}