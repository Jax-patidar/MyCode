/*
 *
 */
package gov.state.nextgen.financialinformation.business.rules;

import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInUieRepository;
import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "ABOtherIncomeBO")
public class ABOtherIncomeBO extends AbstractBO {

	@Autowired
	private AppInUieRepository appInUieRepository;

	private static final String EMPTY_STRING = FwConstants.EMPTY_STRING;

	private static final String BEG_DT_MSG_CD = "00293";

	private static final String H_MUCH_MSG_CD = "00325";
	private static final String H_MUCH_AMT_MSG_CD = "00326";

	private static final String VA_TYPE_CD = "00335";

	private static final String DATE_PATTEN = "MM/dd/yyyy";
	private SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(DATE_PATTEN);

	private static final String DEF_SEL_VAL = FwConstants.DEFAULT_DROPDOWN_SEL;

	/**
	 * Constructor
	 */
	/**
	 * Loads individual other income details
	 *
	 * @param appNumber
	 * @param indvSeqNum
	 * @param seqNum
	 * @return APP_IN_UEI_Collection
	 */
	public APP_IN_UEI_Collection loadIndividualOtherIncomeDetails(final String appNumber, final Integer indvSeqNum,
			final Integer seqNum, final String type) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherIncomeBO.loadIndividualOtherIncomeDetails() - START");

		try {
			final APP_IN_UEI_Collection appInColl = appInUieRepository.loadIndividualOtherIncomeDetails(Integer.parseInt(appNumber),
					indvSeqNum, seqNum, type);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABOtherIncomeBO.loadIndividualOtherIncomeDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime));

			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	public APP_IN_UEI_Collection loadIndividualOtherIncomeDetails(final String appNumber, final Integer indvSeqNum,
			final String type) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherIncomeBO.loadIndividualOtherIncomeDetails() - START");

		try {
			final APP_IN_UEI_Collection appInColl = appInUieRepository.loadIndividualOtherIncomeDetails(Integer.parseInt(appNumber),indvSeqNum, type);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABOtherIncomeBO.loadIndividualOtherIncomeDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime));

			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * Load other income details
	 *
	 * @param appNumber
	 * @return APP_IN_UEI_Collection
	 */
	public APP_IN_UEI_Collection loadOtherIncomeDetails(final String appNumber, List<Integer> indvIds) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherIncomeBO.loadOtherIncomeDetails() - START");

		try {
			final APP_IN_UEI_Collection appInColl = appInUieRepository.loadOtherIncomeDetails(Integer.parseInt(appNumber), indvIds);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABOtherIncomeBO.loadOtherIncomeDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime));

			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * Load other income details
	 *
	 * @param appNumber,type
	 * @return APP_IN_UEI_Collection
	 */
	public APP_IN_UEI_Collection loadOtherIncomeDetails(final String appNumber, final String type,
			List<Integer> indvIds) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherIncomeBO.loadOtherIncomeDetails() - START");

		try {
			if(type==null) {
				APP_IN_UEI_Collection appInColl= loadOtherIncomeDetails(appNumber, indvIds);
				return appInColl;
			}
			final APP_IN_UEI_Collection appInColl = appInUieRepository.loadOtherIncomeDetails(Integer.parseInt(appNumber), type, indvIds);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABOtherIncomeBO.loadOtherIncomeDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime));

			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * Stores other income details
	 *
	 * @param appInColl
	 */
	public void storeOtherIncomeDetails(final APP_IN_UEI_Collection appInColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherIncomeBO.storeOtherIncomeDetails() - START");

		try {
			if (null != appInColl && !appInColl.isEmpty()) {
				appInUieRepository.saveAll(appInColl);
			}

		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherIncomeBO.storeOtherIncomeDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}

	/**
	 * Validate Page Contents
	 *
	 * @param cargo      incomes cargo
	 * @param firstName  user first name
	 * @param typeStatus status type
	 */
	public FwMessageList validatePageContents(final APP_IN_UEI_Cargo cargo) {
		FwMessageList fwMessageList = new FwMessageList();

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherIncomeBO.validatePageContents() - START");
		try {
			final String otherIncomeType = cargo.getUei_typ();
			String value;

			validateOtherIncType(cargo, fwMessageList, otherIncomeType);

			value = cargo.getUei_amt().toString();
			if (value == null || EMPTY_STRING.equals(value.trim())) {
				fwMessageList.addMessageToList(addMessageCode(H_MUCH_MSG_CD));
			} else if (!appMgr.isValidAmountLimit(value)) {
				fwMessageList.addMessageToList(addMessageCode("10034"));

			} else {
				try {
					Double.parseDouble(value);
				} catch (final Exception e) {
					fwMessageList.addMessageToList(addMessageCode(H_MUCH_AMT_MSG_CD));
				}
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherIncomeBO.validatePageContents() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime));

		return fwMessageList;
	}	


	private void validateOtherIncType(final APP_IN_UEI_Cargo cargo, FwMessageList fwMessageList,
			final String otherIncomeType) {
		String value;
		try {
		if (FinancialInfoConstants.VE.equals(otherIncomeType)) {
			value = cargo.getUei_Sub_Type();
			if (value == null || EMPTY_STRING.equals(value) || DEF_SEL_VAL.equals(value)) {
				fwMessageList.addMessageToList(addMessageCode(VA_TYPE_CD));
			}
		}
		if (Objects.nonNull(cargo.getDt_services_rcvd())) {
			value = DATE_FORMAT.format(cargo.getDt_services_rcvd());
			if (value == null || EMPTY_STRING.equals(value.trim())) {
				addMessageCode(BEG_DT_MSG_CD);
			} else {
				if (!appMgr.validateDate(value) || !appMgr.futureDate(value)) {
					fwMessageList.addMessageToList(addMessageCode(BEG_DT_MSG_CD));
				}
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}


	
	public APP_IN_UEI_Collection loadOtherIncomesDetail(final String appNumber) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherIncomeBO.loadOtherIncomesDetail() - START");

		try {
			final APP_IN_UEI_Collection appInColl = appInUieRepository.loadOtherIncomesDetail(Integer.parseInt(appNumber));

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABOtherIncomeBO.loadOtherIncomesDetail() - END , Time Taken : "+ (System.currentTimeMillis() - startTime)+ FinancialInfoConstants.MILLISECONDS);

			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public APP_IN_UEI_Collection loadActiveOtherIncomesDetail(final String appNumber) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherIncomeBO.loadOtherIncomesDetail() - START");

		try {
			final APP_IN_UEI_Collection appInColl = appInUieRepository.loadActiveOtherIncomeDetails(Integer.parseInt(appNumber));

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABOtherIncomeBO.loadOtherIncomesDetail() - END , Time Taken : "+ (System.currentTimeMillis() - startTime)+ FinancialInfoConstants.MILLISECONDS);

			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * changes as per CSPM-41333.
	 * 
	 * @param appNumber as Integer
	 * @param indvSeqNum as Integer
	 * @param seqNum as Integer
	 * @param type as String
	 * @return as APP_IN_UEI_Collection
	 */
	public APP_IN_UEI_Collection loadIndividualOtherIncomeDetail(final String appNumber, Integer indvSeqNum,
			Integer seqNum, String type) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherIncomeBO.loadIndividualOtherIncomeDetail() - START");

		final APP_IN_UEI_Collection appInColl = appInUieRepository
				.loadIndividualOtherIncomeDetails(Integer.parseInt(appNumber), indvSeqNum, seqNum, type);

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABOtherIncomeBO.loadIndividualOtherIncomeDetail() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + FinancialInfoConstants.MILLISECONDS);
		return appInColl;
	}
}
