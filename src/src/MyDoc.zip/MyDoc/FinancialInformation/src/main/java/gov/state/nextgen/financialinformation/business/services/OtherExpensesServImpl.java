package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessage;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_BEF_TAX_DED_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_BEF_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.NO_ONE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.NO_ONE_Collection;
import gov.state.nextgen.financialinformation.business.rules.ABBeforeTaxDeductionBO;
import gov.state.nextgen.financialinformation.business.rules.ABIncomeTaxDeductionBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherExpensesDetailsBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherExpensesQuestionsBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherExpensesSummaryBO;
import gov.state.nextgen.financialinformation.business.validator.ABITDValidator;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInPrflRepository;
import gov.state.nextgen.financialinformation.data.db2.CP_APP_IN_DEDUCTION_Repository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInBefTaxDedRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInIncomeTaxDedRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInMedBillsRepository;
import gov.state.nextgen.financialinformation.model.CheckBoxData;
import gov.state.nextgen.framework.business.model.IndividualCategorySequenceDetails;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.framework.business.model.UserDetails;

@SuppressWarnings("squid:S2229")
@Service("OtherExpensesService")
public class OtherExpensesServImpl implements FinancialServInterface {

	@Autowired
	private ABOtherExpensesDetailsBO otherExpensesBO;

	@Autowired
	private ABOtherExpensesQuestionsBO othBo;

	@Autowired
	private ABBeforeTaxDeductionBO abBeforeTaxDeductionBO;

	@Autowired
	private ABIncomeTaxDeductionBO abIncomeTaxBO;

	private CpAppInBefTaxDedRepository cpAppInBefTaxDedRepository;

	@Autowired
	private CpAppInIncomeTaxDedRepository cpAppInIncomeTaxDedRepository;

	@Autowired
	private CpAppInMedBillsRepository cpAppInMedBillsRepository;

	@Autowired
	private CP_APP_IN_DEDUCTION_Repository dedRepository;

	private AppInPrflRepository appInPrflRepository;

	@Autowired
	private ABITDValidator abitdValidator;

	@Autowired
	private IReferenceTableManager iref;

	@Autowired
	private ABOtherExpensesSummaryBO abOtherExpensesSummaryBO;

	@Autowired
	private RestTemplate restTemplate;

	private static final String CP_ABCHS_COLL = "CP_ABCHS_Collection";

	private static final String LOOP_QUESTION = "loopingQuestion";

	private static final String STORE_CHILD_SUPP_EXP = "storeChildSupportExpense";

	private static final String STORE_DEP_CARE_DET = "storeDependentCareDetail";

	private static final String GET_DEP_CARE_DET = "getDependentCareDetail";

	private static final String GET_BEFORE_TAX_DET = "getBeforeTaxDetail";

	private static final String PAGE_MODE = "PAGE_MODE";

	private static final String CP_APP_IN_INCOME_TAX_DED_COLL = "CP_APP_IN_INCOME_TAX_DED_Collection";

	private static final String STORE_INC_TAX_DED_DET = "storeIncomeTaxDeductionDetails";

	private static final String GET_DIS_DET = "getDisabilityDetails";

	private static final String GET_MEDI_BILL_TYPE = "getMedicalBillsType";

	private static final String STORE_MED_BILL = "storeMedicalBillsType";

	private static final String INDV_IDS = "indvIds";

	private static final String CP_APP_IN_MED_BILLS_COLL = "CP_APP_IN_MED_BILLS_Collection";

	private static final String SAVE_ALI_ST_LOAN_DET = "saveAlimonyStLoanDetails";

	private static final String LOAD_ALI_ST_LOAN_DET = "loadAlimonyStLoanDetails";

	private static final String DEL_ALI_ST_LOAN_DET = "deleteAlimonyStLoanDetails";
	
	private static final String PRCSR = "PRCSR"; 

	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {
		switch (methodName) {
		case FinancialInfoConstants.STORE_CHILD_SUPP_EXP:
			this.storeChildSupportExpense(txnBean);
			break;
		case FinancialInfoConstants.GET_CHILD_SUPP_EXP:
			this.getChildSupportExpense(txnBean);
			break;
		case FinancialInfoConstants.STORE_DEP_CARE_DET:
			this.storeDependentCareDetail(txnBean);
			break;
		case FinancialInfoConstants.GET_DEP_CARE_DET:
			this.getDependentCareDetail(txnBean);
			break;
		case FinancialInfoConstants.DEL_DEP_CARE_DET:
			this.deleteDependentCareDetails(txnBean);
			break;
		case FinancialInfoConstants.STORE_BEFORE_TAX_DET:
			this.storeBeforeTaxDetail(txnBean);
			break;
		case FinancialInfoConstants.STORE_INC_TAX_DED_DET:
			this.storeIncomeTaxDeductionDetails(txnBean);
			break;
		case FinancialInfoConstants.GET_BEFORE_TAX_DET:
			this.getBeforeTaxDetail(txnBean);
			break;
		case FinancialInfoConstants.GET_INC_TAX_DED_DET:
			this.getIncomeTaxDeductionDetails(txnBean);
			break;
		case FinancialInfoConstants.GET_MED_BILL_TYPE:
			this.getMedicalBillsType(txnBean);
			break;
		case FinancialInfoConstants.STORE_MED_BILL_TYPE:
			this.storeMedicalBillsType(txnBean);
			break;
		case FinancialInfoConstants.STORE_MEDI_EXP_DET:
			this.storeMedicalExpenseDetails(txnBean);
			break;
		case FinancialInfoConstants.GET_MEDI_EXP_DET:
			this.getMedicalExpenseDetails(txnBean);
			break;
		case FinancialInfoConstants.DEL_MEDI_EXP_DET:
			this.deleteMedicalExpenseDetails(txnBean);
			break;
		// Added as part of CSPM-3115
		case FinancialInfoConstants.STORE_60OR_DIS_DET:
			this.store60OrDisabilityDetails(txnBean);
			break;
		case FinancialInfoConstants.GET_60OR_DIS_DET:
			this.get60OrDisabilityDetails(txnBean);
			break;
		case FinancialInfoConstants.DEL_60OR_DIS_DET:
			this.delete60OrDisabilityDetails(txnBean);
			break;
		// Added as part of CSPM-3136
		case FinancialInfoConstants.STORE_PAY_BILL_DET:
			this.storeBillPayHelpSelectionDetails(txnBean);
			break;
		case FinancialInfoConstants.GET_BILL_PAY_HELP_SEL_DET:
			this.getBillPayHelpSelectionDetails(txnBean);
			break;
		case FinancialInfoConstants.DELETE_BILL_SEL_DET:
			this.deleteBillPayHelpSelectionDetails(txnBean);
			break;

		// Service methods for Alimony, Student and Other Expenses - Start
		case FinancialInfoConstants.SAVE_ALIMONY_ST_LOAN_DETAILS:
			this.saveAlimonyStLoanDetails(txnBean);
			break;

		case FinancialInfoConstants.LOAD_ALIMONY_ST_LOAN_DETAILS:
			this.loadAlimonyStLoanDetails(txnBean);
			break;

		case FinancialInfoConstants.DELETE_ALIMONY_ST_LOAN_DETAILS:
			this.deleteAlimonyStLoanDetails(txnBean);
			break;
		default:
			// Service methods for Alimony, Student and Other Expenses - End
		}
	}

	/**
	 * Store child support expense.
	 *
	 * @param txnBean the txn bean
	 */
	@Transactional
	public void storeChildSupportExpense(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.storeChildSupportExpense() - START",
				txnBean);
		try {

			final Map pageCollection = txnBean.getPageCollection();
			final Map request = txnBean.getRequest();

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final String appNumber = userDetails.getAppNumber();
			final Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			final Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			// get Details aset Collection and Cargo
			CP_ABCHS_Collection childCareColl = (CP_ABCHS_Collection) pageCollection.get(CP_ABCHS_COLL);
			CP_ABCHS_Cargo appInChildCareCargo = childCareColl.getCargo(0);
			final String loopingInd = appInChildCareCargo.getLoopingInd();

			appInChildCareCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);

			// get the Aset collection from Before Collection
			final CP_ABCHS_Collection appInChildCareBeforeColl = otherExpensesBO.loadChildSupportExpenses(appNumber,
					indvSeqNum, seqNum);
			CP_ABCHS_Cargo appInChildCareBeforeCargo = null;
			String showLoopingQuestionFlag = (String) request.get(LOOP_QUESTION);

			// get details joint owner collection
			/*
			 * VG SONAR Cleanup - 09/2/2015 Deleted 3,4,1 lines Commented Code in this block
			 */

			// get the joint owner collection from before collection

			final Object loop = loopingInd;
			String s = null;
			if (null != loop) {
				s = (String) loop;
			}
			if ((appInChildCareBeforeColl != null) && (!appInChildCareBeforeColl.isEmpty())) {
				appInChildCareBeforeCargo = appInChildCareBeforeColl.getCargo(0);
				appInChildCareCargo.setApp_num(appNumber);
				appInChildCareCargo.setIndv_seq_num(appInChildCareBeforeCargo.getIndv_seq_num());

				appInChildCareCargo.setSeq_num(appInChildCareBeforeCargo.getSeq_num());

				if ((Integer) appInChildCareCargo.getSeq_num() == null) {
					appInChildCareCargo.setRowAction(FwConstants.ROWACTION_INSERT);
				} else {
					appInChildCareCargo.setRowAction(FwConstants.ROWACTION_UPDATE);
					s = FwConstants.NO;
				}

				if ((Integer) appInChildCareCargo.getSeq_num() == null) {
					appInChildCareCargo.setSeq_num(FinancialInfoConstants.ZERO);
				}
				if ((appInChildCareCargo.getRec_cplt_ind() == null)
						|| (appInChildCareCargo.getRec_cplt_ind().toString().length() == 0)) {
					appInChildCareCargo.setRec_cplt_ind(FinancialInfoConstants.ONE);
				}

			}

			FwMessageList validationInfo = otherExpensesBO.validateChildSupportExpenses(appInChildCareCargo, s);
			if (null != validationInfo && validationInfo.hasMessages()) {
				request.put(FwConstants.MESSAGE_LIST, validationInfo.getMessageList());
				/*
				 * VG SONAR Cleanup - 09/2/2015 Deleted 1,1,1,1 lines Commented Code in this
				 * block
				 */

				// put the first Name into request to avoid null pointer in JSP
				pageCollection.put(AppConstants.FIRST_NAME, request.get(AppConstants.FIRST_NAME));
				pageCollection.put("ShowLoopingQuestionFlag", showLoopingQuestionFlag);
				pageCollection.put(CP_ABCHS_COLL, childCareColl);

				return;
			}
			// date conversion

			// completeness check

			// PersistData if the cargo is dirty
			appInChildCareCargo.setApp_num(appNumber);
			otherExpensesBO.storeAppInCldIns(childCareColl);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeChildSupportExpense()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STORE_CHILD_SUPP_EXP, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.storeChildSupportExpense() - END",
				txnBean);
	}

	/**
	 * Comment here.
	 *
	 * @param txnBean the txn bean
	 */
	@Transactional
	public void storeDependentCareDetail(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.storeDependentCareDetail() - START",
				txnBean);
		try {

			CP_APP_IN_DEDUCTION_Collection collection = null;
			CP_APP_IN_DEDUCTION_Collection beforeCollection = null;
			CP_APP_IN_DEDUCTION_Cargo cargo = new CP_APP_IN_DEDUCTION_Cargo();
			CP_APP_IN_DEDUCTION_Cargo beforeCargo = null;

			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String appNumber = userDetails.getAppNumber();
			Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			collection = (CP_APP_IN_DEDUCTION_Collection) pageCollection.get("CP_APP_IN_DEDUCTION_Collection");

			if ((collection != null) && (!collection.isEmpty())) {
				cargo = (CP_APP_IN_DEDUCTION_Cargo) collection.get(0);
			}
			cargo.setApp_num(appNumber);
			beforeCollection = othBo.loadIndividualDeductionDetails(appNumber, indvSeqNum, seqNum, cargo.getExp_typ());
			if ((beforeCollection != null) && (!beforeCollection.isEmpty())) {
				beforeCargo = (CP_APP_IN_DEDUCTION_Cargo) beforeCollection.get(0);
			}

			if (beforeCargo != null) {
				cargo.setSeq_num(beforeCargo.getSeq_num());
				cargo.setIndv_seq_num(beforeCargo.getIndv_seq_num());
				cargo.setSrc_app_ind(beforeCargo.getSrc_app_ind());
				cargo.setExp_typ(beforeCargo.getExp_typ());
			} else {
				cargo.setSeq_num(seqNum);
				cargo.setIndv_seq_num(indvSeqNum);
			}
			if (cargo.getSrc_app_ind() == null) {
				cargo.setSrc_app_ind("AB");
			}
			pageCollection.put("Cp_App_In_Deduction_Collection", collection);
			othBo.storeAppInOblgIns(collection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeDependentCareDetail()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_DEP_CARE_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.storeDependentCareDetail() - END",
				txnBean);
	}

	@Transactional
	public void getDependentCareDetail(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getDependentCareDetail() - START",
				txnBean);
		try {

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesEJBBean::getDependentCareDetail:Start");

			Map pageCollection = txnBean.getPageCollection();
			String mode = (String) pageCollection.get(FinancialInfoConstants.MODE);
			String appNum = txnBean.getUserDetails().getAppNumber();
			String expType = null;
			if (null != txnBean.getCurrentActionDetails().getPageId()) {
				if (txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase("ABCSR") || txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase(PRCSR))
					expType = FinancialInfoConstants.CHILDSUPPORT;
				else if (txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase("ABSSR"))
					expType = FinancialInfoConstants.SPOUSALSUPPORT;
			}
			CP_APP_IN_DEDUCTION_Collection appInDedColl;
			
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			if (txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase(PRCSR) && (null == mode || !mode.equals(FinancialInfoConstants.RAC))) {
				appInDedColl = othBo.loadIndividualDeductionDetailsForRenewels(appNum, expType,indvIdList);
			}
			else if (null == mode || !mode.equals(FinancialInfoConstants.RAC)) {

				appInDedColl = othBo.loadIndividualDeductionDetails(appNum, expType);

			} else {

				appInDedColl = othBo.getAppInDeductionDetails(appNum);

			}
			pageCollection.put("CP_APP_IN_DEDUCTION_Collection", appInDedColl);
			txnBean.setPageCollection(pageCollection);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getDependentCareDetail()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_DEP_CARE_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getDependentCareDetail() - END",
				txnBean);
	}

	@Transactional
	public void deleteDependentCareDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.deleteDependentCareDetails() - START",
				fwTxn);
		try {
			String expType = null;
			String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			if (null != fwTxn.getCurrentActionDetails().getPageId()) {
				if (fwTxn.getCurrentActionDetails().getPageId().equalsIgnoreCase("ABCSR") || fwTxn.getCurrentActionDetails().getPageId().equalsIgnoreCase(PRCSR))
					expType = FinancialInfoConstants.CHILDSUPPORT;
				else if (fwTxn.getCurrentActionDetails().getPageId().equalsIgnoreCase("ABSSR"))
					expType = FinancialInfoConstants.SPOUSALSUPPORT;
			}
			CP_APP_IN_DEDUCTION_Collection cpAppInDedColl = othBo.loadIndividualDeductionDetails(appNum, indv_seq_num,
					seq_num, expType);
			CP_APP_IN_DEDUCTION_Cargo cpAppInDedCargo = cpAppInDedColl.getCargo(0);
			dedRepository.delete(cpAppInDedCargo);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in deleteDependentCareDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.DEL_DEP_CARE_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.deleteDependentCareDetails() - END",
				fwTxn);
	}

	@Transactional
	public void getChildSupportExpense(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getChildSupportExpense() - START",
				txnBean);
		try {

			final Map request = txnBean.getRequest();
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			final Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());
			request.put(LOOP_QUESTION, FwConstants.NO);
			// EDSP

			/*
			 * VG SONAR Cleanup - 09/2/2015 Deleted 1,2,2,1 lines Commented Code in this
			 * block
			 */

			// When user hits the Back button or comes from the Summary Page
			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {
				// get PersonalProperty details from PersonalProperty details
				// table in database

				pageCollection = new HashMap();
				// get Details_Collection from DataBase and set to
				// PageCollection

				final CP_ABCHS_Collection appChildCareColl = otherExpensesBO.loadChildSupportExpenses(appNum,
						indvSeqNum, seqNum);

				pageCollection.put(CP_ABCHS_COLL, appChildCareColl);

			} else {
				pageCollection = new HashMap();

				final CP_ABCHS_Collection appCareColl = otherExpensesBO.loadChildSupportExpenses(appNum, indvSeqNum,
						seqNum);

				int sizeColl = 0;
				CP_ABCHS_Cargo appCareCargo = null;
				if ((appCareColl != null) && (!appCareColl.isEmpty())) {
					sizeColl = appCareColl.size();
				}
				if (sizeColl > 0) {
					appCareCargo = appCareColl.getCargo(sizeColl - 1);
				} else {
					appCareCargo = new CP_ABCHS_Cargo();
					appCareCargo.setIndv_seq_num(indvSeqNum);
					appCareCargo.setSeq_num(seqNum);
				}
				final CP_ABCHS_Collection temp = new CP_ABCHS_Collection();
				temp.addCargo(appCareCargo);
				pageCollection.put(CP_ABCHS_COLL, temp);
			}

			txnBean.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getChildSupportExpense()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_CHILD_SUPP_EXP,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getChildSupportExpense() - END",
				txnBean);
	}

	@Transactional
	public void getBeforeTaxDetail(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getBeforeTaxDetail() - START",
				txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();

			String appNum = userDetails.getAppNumber();
			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			int seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {

				pageCollection = new HashMap();
				// get Details_Collection from DataBase and set to

				pageCollection.put(FinancialInfoConstants.CP_APP_IN_BEF_TAX_DED_COLL,
						abBeforeTaxDeductionBO.loadIndividualBeforeTaxDetails(appNum, indvSeqNum, seqNum));

			} else {

				pageCollection = new HashMap();
				final CP_APP_IN_BEF_TAX_DED_Collection appInHouBillsCollection = abBeforeTaxDeductionBO
						.loadIndividualBeforeTaxDetails(appNum, indvSeqNum, seqNum);

				CP_APP_IN_BEF_TAX_DED_Cargo appInHouBillsCargo = null;
				int sizeColl = 0;

				if ((appInHouBillsCollection != null) && (!appInHouBillsCollection.isEmpty())) {
					sizeColl = appInHouBillsCollection.size();
				}
				if (sizeColl > 0) {
					appInHouBillsCargo = appInHouBillsCollection.getCargo(0);
				} else {
					appInHouBillsCargo = new CP_APP_IN_BEF_TAX_DED_Cargo();
					appInHouBillsCargo.setApp_num(appNum);
					appInHouBillsCargo.setIndv_seq_num(indvSeqNum);
					appInHouBillsCargo.setSeq_num(seqNum);
				}
				final CP_APP_IN_BEF_TAX_DED_Collection temp = new CP_APP_IN_BEF_TAX_DED_Collection();
				temp.addCargo(appInHouBillsCargo);
				pageCollection.put(FinancialInfoConstants.CP_APP_IN_BEF_TAX_DED_COLL, temp);
			}

			txnBean.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getBeforeTaxDetail()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_BEFORE_TAX_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getBeforeTaxDetail() - END", txnBean);
	}

	@Transactional
	public void storeBeforeTaxDetail(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.storeBeforeTaxDetail() - START",
				txnBean);
		try {

			final Map pageCollection = txnBean.getPageCollection();
			final Map request = txnBean.getRequest();

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final String appNumber = userDetails.getAppNumber();
			Integer indvSeqNumber = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			Integer seqNumber = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			final String firstName = userDetails.getFirstName();

			FwMessageList validateMsg = new FwMessageList();

			// Common Collection & Cargo
			CP_APP_IN_BEF_TAX_DED_Collection appColl = null;
			CP_APP_IN_BEF_TAX_DED_Cargo appCargo = new CP_APP_IN_BEF_TAX_DED_Cargo();

			CP_APP_IN_BEF_TAX_DED_Collection appBeforeColl = null;
			CP_APP_IN_BEF_TAX_DED_Cargo appBeforeCargo = null;

			appBeforeColl = abBeforeTaxDeductionBO.loadIndividualBeforeTaxDetails(appNumber, indvSeqNumber, seqNumber);

			appBeforeCargo = setBeforeCargoDetails(appNumber, appBeforeColl, appBeforeCargo);
			if (pageCollection.containsKey("CP_APP_IN_BEF_TAX_DED_Collection")) {
				appColl = (CP_APP_IN_BEF_TAX_DED_Collection) pageCollection.get("CP_APP_IN_BEF_TAX_DED_Collection");
			}

			if ((appColl != null) && !appColl.isEmpty()) {
				appCargo = appColl.getCargo(0);
				appCargo.setApp_num(appNumber);
			}

			final String backToMyAccess = (String) request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON);

			if (backToMyAccess == null) {
				validateMsg = abBeforeTaxDeductionBO.validateBeforeTaxDedDetailsCheck(appCargo);
			}

			if (checkBackToMyAccessSelected(request) || ((validateMsg != null) && validateMsg.hasMessages())) {

				if (backToMyAccess == null) {
					request.put(FwConstants.MESSAGE_LIST, validateMsg);
				}

				pageCollection.put(AppConstants.FIRST_NAME, firstName);
				pageCollection.put(AppConstants.CP_APP_IN_BEF_TAX_DED_COLLECTION, appColl);
				pageCollection.put(PAGE_MODE, request.get(PAGE_MODE));
				return;
			}
			boolean blNewCargo = false;
			blNewCargo = newCargoCheckBeforeTaxDed(appBeforeCargo);

			setAppCargoForTax(appColl, appCargo, appBeforeColl, appBeforeCargo, blNewCargo);

			cpAppInBefTaxDedRepository.saveAll(appColl);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeBeforeTaxDetail()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STORE_BEFORE_TAX_DET, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.storeBeforeTaxDetail() - END",
				txnBean);
	}

	private CP_APP_IN_BEF_TAX_DED_Cargo setBeforeCargoDetails(final String appNumber,
			CP_APP_IN_BEF_TAX_DED_Collection appBeforeColl, CP_APP_IN_BEF_TAX_DED_Cargo appBeforeCargo) {
		Integer indvSeqNumber;
		
			if ((appBeforeColl != null) && appBeforeColl.size() > 0) {
				appBeforeCargo = appBeforeColl.getCargo(0);
				if (null != appBeforeCargo) {
					appBeforeCargo.setApp_num(appNumber);
					indvSeqNumber = appBeforeCargo.getIndv_seq_num();
					appBeforeCargo.setIndv_seq_num(indvSeqNumber);
				}
			}
			return appBeforeCargo;
		
	}

	private void setAppCargoForTax(CP_APP_IN_BEF_TAX_DED_Collection appColl, CP_APP_IN_BEF_TAX_DED_Cargo appCargo,
			CP_APP_IN_BEF_TAX_DED_Collection appBeforeColl, CP_APP_IN_BEF_TAX_DED_Cargo appBeforeCargo,
			boolean blNewCargo) {
		
			Integer indvSeqNumber;
			if ((appBeforeColl != null) && !appBeforeColl.isEmpty() && (blNewCargo == false)) {
				// here we need to check data hasa been change or not
				appBeforeCargo = appBeforeColl.getCargo(0);
				appCargo.setRowAction(FwConstants.ROWACTION_UPDATE);
				appCargo.setSeq_num(appBeforeCargo.getSeq_num());
				// PersistData if the cargo is dirty
			} else if ((appColl != null) && !appColl.isEmpty()) {
				appCargo.setRowAction(FwConstants.ROWACTION_INSERT);
				appCargo.setDirty(true);
			}

			if ((appBeforeColl != null) && appBeforeColl.size() > 0 && (appBeforeCargo != null)) {
				indvSeqNumber = appBeforeCargo.getIndv_seq_num();
				appCargo.setIndv_seq_num(indvSeqNumber);
			}

			if ((appCargo.getSrc_app_ind() == null) || (appCargo.getSrc_app_ind().trim().length() == 0)) {
				appCargo.setSrc_app_ind("AB");
			}
		
	}

	@Transactional
	public void storeIncomeTaxDeductionDetails(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesService.storeIncomeTaxDeductionDetails() - START", txnBean);
		try {

			final Map pageCollection = txnBean.getPageCollection();
			final Map request = txnBean.getRequest();

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final String appNumber = userDetails.getAppNumber();
			Integer indvSeqNumber = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			Integer seqNumber = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			FwMessageList validateMsg = new FwMessageList();

			// Common Collection & Cargo
			CP_APP_IN_INCOME_TAX_DED_Collection appColl = null;
			CP_APP_IN_INCOME_TAX_DED_Cargo appCargo = new CP_APP_IN_INCOME_TAX_DED_Cargo();

			CP_APP_IN_INCOME_TAX_DED_Collection appBeforeColl = null;
			CP_APP_IN_INCOME_TAX_DED_Cargo appBeforeCargo = null;

			appBeforeColl = cpAppInIncomeTaxDedRepository.getBeforeColl(Integer.parseInt(appNumber), indvSeqNumber, seqNumber);

			if ((appBeforeColl != null) && !appBeforeColl.isEmpty()) {
				appBeforeCargo = appBeforeColl.getCargo(0);
				if (null != appBeforeCargo) {
					appBeforeCargo.setApp_num(appNumber);
					indvSeqNumber = appBeforeCargo.getIndv_seq_num();
					appBeforeCargo.setIndv_seq_num(indvSeqNumber);
				}
			}
			if (pageCollection.containsKey(CP_APP_IN_INCOME_TAX_DED_COLL)) {
				appColl = (CP_APP_IN_INCOME_TAX_DED_Collection) pageCollection.get(CP_APP_IN_INCOME_TAX_DED_COLL);
			}

			if ((appColl != null) && !appColl.isEmpty()) {
				appCargo = appColl.getCargo(0);
				appCargo.setApp_num(appNumber);
			}

			final String backToMyAccess = (String) request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON);

			if (backToMyAccess == null) {
				validateMsg = abitdValidator.validateIncomeTaxDedDetailsCheck(appCargo);
			}

			if (checkBackToMyAccessSelected(request) || ((validateMsg != null) && validateMsg.hasMessages())) {

				if (backToMyAccess == null) {
					request.put(FwConstants.MESSAGE_LIST, validateMsg.getMessageList());
				}

				pageCollection.put(AppConstants.CP_APP_IN_INCOME_TAX_DED_COLLECTION, appColl);
				pageCollection.put(PAGE_MODE, request.get(PAGE_MODE));
				return;
			}

			boolean blNewCargo = false;
			blNewCargo = newcargocheckIncomeTaxDed(appBeforeCargo);

			setIncomeTaxAppCargo(appColl, appCargo, appBeforeColl, appBeforeCargo, blNewCargo);
			/*
			 * VG SONAR Cleanup - 09/2/2015 Deleted 1,1 lines Commented Code in this block
			 */

			abIncomeTaxBO.storeIncomeTaxDedInsDetails(appColl);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeIncomeTaxDeductionDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STORE_INC_TAX_DED_DET, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesService.storeIncomeTaxDeductionDetails() - END", txnBean);
	}

	private void setIncomeTaxAppCargo(CP_APP_IN_INCOME_TAX_DED_Collection appColl,
			CP_APP_IN_INCOME_TAX_DED_Cargo appCargo, CP_APP_IN_INCOME_TAX_DED_Collection appBeforeColl,
			CP_APP_IN_INCOME_TAX_DED_Cargo appBeforeCargo, boolean blNewCargo) {
		
			Integer indvSeqNumber;
			if ((appBeforeColl != null) && !appBeforeColl.isEmpty() && (blNewCargo == false)) {
				appCargo.setRowAction(FwConstants.ROWACTION_UPDATE);

				// PersistData if the cargo is dirty
			} else if ((appColl != null) && !appColl.isEmpty()) {

				appCargo.setRowAction(FwConstants.ROWACTION_INSERT);
				appCargo.setDirty(true);
			}

			if ((appBeforeColl != null) && !appBeforeColl.isEmpty() && (appBeforeCargo != null)) {
				indvSeqNumber = appBeforeCargo.getIndv_seq_num();
				appCargo.setIndv_seq_num(indvSeqNumber);
				appCargo.setSeq_num(appBeforeCargo.getSeq_num());
			}

			if ((appCargo.getSrc_app_ind() == null) || (appCargo.getSrc_app_ind().trim().length() == 0)) {
				appCargo.setSrc_app_ind("AB");
			}
		
	}

	private boolean newCargoCheckBeforeTaxDed(final CP_APP_IN_BEF_TAX_DED_Cargo appBeforeCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.DEBUG, "OtherExpensesEJBBean.newCargoCheckBeforeTaxDed() - START");
		boolean result = false;
		
			if (appBeforeCargo != null && ((appBeforeCargo.getDeferred_comp() == null)
					&& (appBeforeCargo.getDental_ins() == null) && (appBeforeCargo.getFlexi_spend_account() == null)
					&& (appBeforeCargo.getMedical_ins() == null) && (appBeforeCargo.getOther_exp() == null)
					&& (appBeforeCargo.getPre_tax_life_ins() == null) && (appBeforeCargo.getVision_ins() == null))) {

				result = true;

			}
			FwLogger.log(this.getClass(), FwLogger.Level.DEBUG, "OtherExpensesEJBBean.Newcargocheck() - END , Time Taken : "
					+ (System.currentTimeMillis() - startTime));
			return result;
		
	}

	public boolean checkBackToMyAccessSelected(final Map request) {
		try {
			if (request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON) == null) {
				return false;
			}
			final String reqWarningMsgs = (String) request.get(FwConstants.WARNING_MSG_DETAILS);
			if ((reqWarningMsgs != null) && (reqWarningMsgs.trim().length() > 0)) {
				// Tokenizing the request warrning message and putting into a
				// list
				final StringTokenizer tokenizer = new StringTokenizer(reqWarningMsgs, FinancialInfoConstants.TILDE);
				final List reqMsgList = new ArrayList();
				while (tokenizer.hasMoreElements()) {
					reqMsgList.add(tokenizer.nextElement());
				}
				if (reqMsgList.contains(FinancialInfoConstants.MSG_30075)) {
					return true;
				}
			}
			final FwMessageList messageList = new FwMessageList();
			final FwMessage message = new FwMessage();
			message.addMessageCode(FinancialInfoConstants.MSG_30075);
			messageList.addMessageToList(message);
			request.put(FwConstants.MESSAGE_LIST, messageList);
			return true;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in checkBackToMyAccessSelected()", e);
			throw e;
		}
	}

	public FwException createFwException(final String className, final String methodName, final Exception e) {
		return FwExceptionManager.createFwException(className, methodName, e);
	}

	private boolean newcargocheckIncomeTaxDed(final CP_APP_IN_INCOME_TAX_DED_Cargo appInIncomeTaxDedCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.DEBUG, "OtherExpensesEJBBean.NewcargocheckTax() - START");
		
			boolean result = false;
			if (appInIncomeTaxDedCargo != null && ((appInIncomeTaxDedCargo.getAlimony_exp() == null)
					&& (appInIncomeTaxDedCargo.getBusiness_exp() == null)
					&& (appInIncomeTaxDedCargo.getDeductible_self_exp() == null)
					&& (appInIncomeTaxDedCargo.getDomestic_exp() == null)
					&& (appInIncomeTaxDedCargo.getEducator_exp() == null)
					&& (appInIncomeTaxDedCargo.getHealth_saving_exp() == null)
					&& (appInIncomeTaxDedCargo.getIra_exp() == null) && (appInIncomeTaxDedCargo.getMoving_exp() == null)
					&& (appInIncomeTaxDedCargo.getPenalty_exp() == null)
					&& (appInIncomeTaxDedCargo.getSelf_health_exp() == null)
					&& (appInIncomeTaxDedCargo.getSelf_sep_exp() == null)
					&& (appInIncomeTaxDedCargo.getStudent_loan_exp() == null)
					&& (appInIncomeTaxDedCargo.getTution_exp() == null))) {

				result = true;

			}

			FwLogger.log(this.getClass(), FwLogger.Level.DEBUG, "OtherExpensesEJBBean.Newcargocheck() - END , Time Taken : "
					+ (System.currentTimeMillis() - startTime));
			return result;
		
	}

	@Transactional
	public void getIncomeTaxDeductionDetails(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesService.getIncomeTaxDeductionDetails() - START", txnBean);
		try {

			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();

			String appNum = userDetails.getAppNumber();
			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			int seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {

				pageCollection = new HashMap();
				// get Details_Collection from DataBase and set to

				pageCollection.put(FinancialInfoConstants.CP_APP_IN_BEF_TAX_DED_COLL,
						abIncomeTaxBO.loadIndividualIncomeTaxDedInsAFB(appNum, indvSeqNum));

			} else {

				pageCollection = new HashMap();
				final CP_APP_IN_INCOME_TAX_DED_Collection cp_APP_IN_INCOME_TAX_DED_Collection = abIncomeTaxBO
						.loadTaxDedResponse(appNum, indvSeqNum, seqNum);

				CP_APP_IN_INCOME_TAX_DED_Cargo cargo = null;
				int sizeColl = 0;

				if ((cp_APP_IN_INCOME_TAX_DED_Collection != null) && (!cp_APP_IN_INCOME_TAX_DED_Collection.isEmpty())) {
					sizeColl = cp_APP_IN_INCOME_TAX_DED_Collection.size();
				}
				if (sizeColl > 0) {
					cargo = cp_APP_IN_INCOME_TAX_DED_Collection.getCargo(0);
				} else {
					cargo = new CP_APP_IN_INCOME_TAX_DED_Cargo();
					cargo.setApp_num(appNum);
					cargo.setIndv_seq_num(indvSeqNum);
					cargo.setSeq_num(seqNum);
				}
				final CP_APP_IN_INCOME_TAX_DED_Collection temp = new CP_APP_IN_INCOME_TAX_DED_Collection();
				temp.addCargo(cargo);
				pageCollection.put(FinancialInfoConstants.CP_APP_IN_INCOME_TAX_DED_COLL, temp);

			}

			txnBean.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getIncomeTaxDeductionDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_INC_TAX_DED_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getIncomeTaxDeductionDetails() - END",
				txnBean);
	}

	@Transactional
	public void getMedicalBillsType(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getMedicalBillsType() - START",
				txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();

			String appNum = userDetails.getAppNumber();

			APP_IN_PRFL_Collection appInPrflColl = appInPrflRepository.getAppInPrflByAppNum(appNum);

			final NO_ONE_Collection noOneCollection = new NO_ONE_Collection();
			final NO_ONE_Cargo noOneOtherIncCargo = new NO_ONE_Cargo();

			for (int i = 0; i < appInPrflColl.size(); i++) {
				APP_IN_PRFL_Cargo appInPrflCargo = (APP_IN_PRFL_Cargo) appInPrflColl.get(i);

				if (null != appInPrflCargo.getMed_exp_resp()
						&& FinancialInfoConstants.STATUS_NOT_REQUIRED == appInPrflCargo.getMed_exp_resp().charAt(0)) {
					noOneOtherIncCargo.setNo_one_name(appInPrflCargo.getIndv_seq_num().toString());
					noOneOtherIncCargo.setNo_one_value(String.valueOf(FinancialInfoConstants.STATUS_NOT_REQUIRED));
					noOneCollection.addCargo(noOneOtherIncCargo);
				}
			}

			pageCollection.put("APP_IN_PRFL_Collection", appInPrflColl);
			pageCollection.put("NO_ONE_COLLECTION", noOneCollection);

			txnBean.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getMedicalBillsType()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_MED_BILL_TYPE,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getMedicalBillsType() - END", txnBean);
	}

	@Transactional
	public void storeMedicalBillsType(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.storeMedicalBillsType() - START",
				txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();

			String appNum = userDetails.getAppNumber();
			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());

			final APP_IN_PRFL_Collection appInPrflCollRequest = (APP_IN_PRFL_Collection) pageCollection
					.get("APP_IN_PRFL_Collection");
			APP_IN_PRFL_Cargo cargo = null;
			for (int i = 0; i < appInPrflCollRequest.size(); i++) {
				cargo = (APP_IN_PRFL_Cargo) appInPrflCollRequest.get(i);
				cargo = mapDetailsToCargo(cargo);

				appInPrflRepository.storeMedicalBillTypes(appNum, indvSeqNum, cargo.getMedtyp_hsa_contrib(),
						cargo.getMedtyp_dental(), cargo.getMedtyp_attendant_care(), cargo.getMedtyp_doctor(),
						cargo.getMedtyp_med_equip(), cargo.getMedtyp_hosp_bills(), cargo.getMedtyp_insur_premium(),
						cargo.getMedtyp_rx_cost(), cargo.getMedtyp_trans_med(), cargo.getMedtyp_other(),
						cargo.getMedicare_part_a(), cargo.getMedicare_part_b(), cargo.getMedicare_part_c(),
						cargo.getMedicare_part_d(), cargo.getCcsp_provider_payment(),
						cargo.getAnimals_to_assist_disabled(), cargo.getFuneral_death_expense(),
						cargo.getBlind_work_expense(), cargo.getImpairment_work_expense());
			}

			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeMedicalBillsType()", txnBean);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeMedicalBillsType()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_MED_BILL_TYPE,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.storeMedicalBillsType() - END",
				txnBean);

	}
	@SuppressWarnings("squid:S3776")
	private APP_IN_PRFL_Cargo mapDetailsToCargo(APP_IN_PRFL_Cargo cargo) {
		try {
			List<CheckBoxData> checkBoxData = cargo.getCheckboxdata();
			for (CheckBoxData selectedCheckBox : checkBoxData) {
				if ((selectedCheckBox.getCodes().equals("DR") && selectedCheckBox.getStatus().equals("Y"))) {
					cargo.setMedtyp_doctor("Y");
				}
				if (selectedCheckBox.getCodes().equals("AC") && selectedCheckBox.getStatus().equals("Y")) {
					cargo.setMedtyp_attendant_care("Y");
				}
				if (selectedCheckBox.getCodes().equals("DN") && selectedCheckBox.getStatus().equals("Y")) {
					cargo.setMedtyp_dental("Y");
				}
				if (selectedCheckBox.getCodes().equals("EQ") && selectedCheckBox.getStatus().equals("Y")) {
					cargo.setMedtyp_med_equip("Y");
				}
				if (selectedCheckBox.getCodes().equals("HS") && selectedCheckBox.getStatus().equals("Y")) {
					cargo.setMedtyp_hosp_bills("Y");
				}
				setRemainingValues(cargo, selectedCheckBox);

			}
			return cargo;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in mapDetailsToCargo()", e);
			throw e;
		}
	}

	private void setRemainingValues(APP_IN_PRFL_Cargo cargo, CheckBoxData selectedCheckBox) {

		
			setCodeMedType(cargo, selectedCheckBox);

			if (selectedCheckBox.getCodes().equals("BWE") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setBlind_work_expense("Y");
			}
			if (selectedCheckBox.getCodes().equals("IRW") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setImpairment_work_expense("Y");
			}
			if (selectedCheckBox.getCodes().equals("PS") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setMedtyp_rx_cost("Y");
			}
			if (selectedCheckBox.getCodes().equals("TM") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setMedtyp_trans_med("Y");
			}
			if (selectedCheckBox.getCodes().equals("OT") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setMedtyp_other("Y");
			}
			if (selectedCheckBox.getCodes().equals("MPA") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setMedicare_part_a("Y");
			}
			if (selectedCheckBox.getCodes().equals("MPB") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setMedicare_part_b("Y");
			}
		
	}

	private void setCodeMedType(APP_IN_PRFL_Cargo cargo, CheckBoxData selectedCheckBox) {
		
			if (selectedCheckBox.getCodes().equals("HIP") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setMedtyp_insur_premium("Y");
			}
			if (selectedCheckBox.getCodes().equals("MPC") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setMedicare_part_c("Y");
			}
			if (selectedCheckBox.getCodes().equals("MPD") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setMedicare_part_d("Y");
			}
			if (selectedCheckBox.getCodes().equals("CS") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setCcsp_provider_payment("Y");
			}
			if (selectedCheckBox.getCodes().equals("AN") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setAnimals_to_assist_disabled("Y");
			}
			if (selectedCheckBox.getCodes().equals("FDE") && selectedCheckBox.getStatus().equals("Y")) {
				cargo.setFuneral_death_expense("Y");
			}
		
	}

	@Transactional
	public void getMedicalExpenseDetails(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getMedicalExpenseDetails() - START",
				txnBean);
		try {

			String app_num = txnBean.getUserDetails().getAppNumber();
			int seq_num = 0;
			int indv_seq_num = 0;
			Map pageCollection = txnBean.getPageCollection();
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			String type = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			final Map request = txnBean.getRequest();
			// make loopingQuestion value NO in the request
			request.put(LOOP_QUESTION, FwConstants.NO);

			// Added as part of CSPM-3094 Creating name indv id map from fw_request objcet
			APP_INDV_Collection appIndvCollFromRequest = null;
			Map<Integer, String> indvIdNameMap = new HashMap<Integer, String>();
			appIndvCollFromRequest = (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection");
			if (Objects.nonNull(appIndvCollFromRequest)) {
				APP_INDV_Cargo[] appIndvArray = appIndvCollFromRequest.getResults();
				for (APP_INDV_Cargo indvCargo : appIndvArray) {
					if (!indvIdNameMap.containsKey(indvCargo.getIndv_seq_num())) {
						indvIdNameMap.put(indvCargo.getIndv_seq_num(),
								indvCargo.getFst_nam() + " " + indvCargo.getLast_nam());
					}
				}
			}

			pageCollection = backButtonForMedicalExpense(app_num, seq_num, indv_seq_num, pageCollection, indvIdList,
					type);
			final CP_APP_IN_MED_BILLS_Collection medBillColl = (CP_APP_IN_MED_BILLS_Collection) pageCollection
					.get(CP_APP_IN_MED_BILLS_COLL);
			if ((medBillColl != null) && (!medBillColl.isEmpty())) {
				final CP_APP_IN_MED_BILLS_Cargo medBillCargo = medBillColl.getCargo(0);
				medBillCargo.getMed_bill_type();
				medBillCargo.getIndv_seq_num();
			}

			// put the Current Individual Sequence Number in the pageCollection
			if ((medBillColl != null) && (!medBillColl.isEmpty())) {
				final CP_APP_IN_MED_BILLS_Cargo medBillCargo = medBillColl.getCargo(0);
				final String indvSeqNum = medBillCargo.getIndv_seq_num().toString();
				pageCollection.put(AppConstants.CURRENT_INDIV_SEQ_NUM, indvSeqNum);
			}

			txnBean.setPageCollection(pageCollection);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getMedicalExpenseDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_MEDI_EXP_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.getMedicalExpenseDetails() - END",
				txnBean);
	}
	@SuppressWarnings("squid:S3776")
	private Map backButtonForMedicalExpense(String app_num, int seq_num, int indv_seq_num, Map pageCollection,
			List<Integer> indvIdList, String type) {
		try {
			String mode = (String) pageCollection.get(FinancialInfoConstants.MODE);
			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {
				if (null == mode || !mode.equals(FinancialInfoConstants.RAC)) {
					pageCollection = new HashMap();
				}
				CP_APP_IN_MED_BILLS_Collection coll = abOtherExpensesSummaryBO.getMedicalExpenseDetail(app_num,
						indv_seq_num, seq_num, type);
				pageCollection.put(CP_APP_IN_MED_BILLS_COLL, coll);
			} else {
				if (null == mode || !mode.equals(FinancialInfoConstants.RAC)) {
					pageCollection = new HashMap();
				}
				CP_APP_IN_MED_BILLS_Cargo[] appIndvArrayFromDB = null;
				CP_APP_IN_MED_BILLS_Collection appIndvCollToRequest = null;
				appIndvArrayFromDB = cpAppInMedBillsRepository.getByAppNumAndIndvs(Integer.parseInt(app_num), indvIdList);
				if (null != appIndvArrayFromDB && appIndvArrayFromDB.length > 0) {
					appIndvCollToRequest = new CP_APP_IN_MED_BILLS_Collection();
					for (CP_APP_IN_MED_BILLS_Cargo cargo : appIndvArrayFromDB) {
						if (Objects.nonNull(cargo.getPayment_amt()) && null != cargo.getMed_bill_type()
								&& cargo.getMed_bill_type().equalsIgnoreCase("HS")) {

							appIndvCollToRequest.addCargo(cargo);

						}
					}
					if (null != mode && mode.equals(FinancialInfoConstants.RAC)) {
						CP_APP_IN_MED_BILLS_Collection existingColl = (CP_APP_IN_MED_BILLS_Collection) pageCollection
								.get(CP_APP_IN_MED_BILLS_COLL);
						if (null != existingColl && !existingColl.isEmpty()) {
							appIndvCollToRequest.addAll(existingColl);
						}
					}
					pageCollection.put(CP_APP_IN_MED_BILLS_COLL, appIndvCollToRequest);
				}
			}
			return pageCollection;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in backButtonForMedicalExpense()", e);
			throw e;
		}
	}

	/**
	 * Store medical expense detail.
	 *
	 * @param txnBean the txn bean
	 */
	/* Store method for Medical Expense Details */
	@Transactional
	public void storeMedicalExpenseDetails(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.storeMedicalExpenseDetails() - START",
				txnBean);
		try {

			final Map pageCollection = txnBean.getPageCollection();

			String appNumber = txnBean.getUserDetails().getAppNumber();
			int seq_num = 0;
			int indv_seq_num = 0;
			if (Objects.nonNull(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence())) {
				indv_seq_num = Integer.parseInt(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.getIndividualSequence());
			}
			if (Objects.nonNull(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence())) {
				seq_num = Integer.parseInt(
						txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}
			// Murali

			String medBillType = "HS"; // Setting columns values to default bcz which should not be null

			// get Details aset Collection and Cargo
			CP_APP_IN_MED_BILLS_Cargo appInMedBillsCargoFromReq = new CP_APP_IN_MED_BILLS_Cargo();
			CP_APP_IN_MED_BILLS_Collection appInMedBillsCollFromReq = (CP_APP_IN_MED_BILLS_Collection) pageCollection
					.get(CP_APP_IN_MED_BILLS_COLL);
			if (Objects.nonNull(appInMedBillsCollFromReq)) {
				appInMedBillsCargoFromReq = appInMedBillsCollFromReq.getCargo(0);
			}

			// get the Aset collection from Before Collection
			final CP_APP_IN_MED_BILLS_Collection appInMedBillsCollFromDB = abOtherExpensesSummaryBO
					.getMedDetailsByyMedBillType(appNumber, indv_seq_num, medBillType);
			boolean isIndvPresent = false;
			if ((appInMedBillsCollFromDB != null) && (!appInMedBillsCollFromDB.isEmpty())) {
				for (CP_APP_IN_MED_BILLS_Cargo fromDb : appInMedBillsCollFromDB.getResults()) {
					isIndvPresent = persistSingleMedExpenseCargo(pageCollection, seq_num, appInMedBillsCargoFromReq,
							appInMedBillsCollFromReq, isIndvPresent, fromDb);
				}

			}
			if (!isIndvPresent) {
				updateExistingMedBillsCargo(pageCollection, appNumber, seq_num, indv_seq_num, medBillType,
						appInMedBillsCargoFromReq, appInMedBillsCollFromReq);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeMedicalExpenseDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_MEDI_EXP_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.storeMedicalExpenseDetails() - END",
				txnBean);
	}

	private void updateExistingMedBillsCargo(final Map pageCollection, String appNumber, int seq_num, int indv_seq_num,
			String medBillType, CP_APP_IN_MED_BILLS_Cargo appInMedBillsCargoFromReq,
			CP_APP_IN_MED_BILLS_Collection appInMedBillsCollFromReq) {
		
		appInMedBillsCargoFromReq.setMedical_seq_num(seq_num);
		appInMedBillsCargoFromReq.setIndv_seq_num(indv_seq_num);
		appInMedBillsCargoFromReq.setApp_num(appNumber);
		// Setting columns values to default bcz which should not be null
		appInMedBillsCargoFromReq.setMed_bill_type(medBillType);
		appInMedBillsCargoFromReq.setSrc_app_ind(FinancialInfoConstants.SRC_APP_AFB);
		cpAppInMedBillsRepository.save(appInMedBillsCargoFromReq);
		pageCollection.replace(CP_APP_IN_MED_BILLS_COLL, appInMedBillsCollFromReq);
		
	}

	private boolean persistSingleMedExpenseCargo(final Map pageCollection, int seq_num,
			CP_APP_IN_MED_BILLS_Cargo appInMedBillsCargoFromReq,
			CP_APP_IN_MED_BILLS_Collection appInMedBillsCollFromReq, boolean isIndvPresent,
			CP_APP_IN_MED_BILLS_Cargo fromDb) {
		try {
			if (fromDb.getMedical_seq_num() == seq_num) {
				fromDb.setPayment_amt(appInMedBillsCargoFromReq.getPayment_amt());
				cpAppInMedBillsRepository.save(fromDb);
				if (null != appInMedBillsCollFromReq) {
					appInMedBillsCollFromReq.set(0, fromDb);
				}
				pageCollection.replace(CP_APP_IN_MED_BILLS_COLL, appInMedBillsCollFromReq);
				isIndvPresent = true;
			}
			return isIndvPresent;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in persistSingleMedExpenseCargo()", e);
			throw e;
		}
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void deleteMedicalExpenseDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.deleteMedicalExpenseDetails() - START",
				txnBean);
		try {

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String appNum = userDetails.getAppNumber();
			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			int seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());
			String medBillType = "HS";// For inhome support
			CP_APP_IN_MED_BILLS_Collection existingMedBillsColl = abOtherExpensesSummaryBO
					.getMedicalExpenseDetail(appNum, indvSeqNum, seqNum, medBillType);
			if (Objects.nonNull(existingMedBillsColl) && !existingMedBillsColl.isEmpty()) {
				CP_APP_IN_MED_BILLS_Cargo existingCargo = existingMedBillsColl.getCargo(0);
				if (Objects.nonNull(existingCargo))
					abOtherExpensesSummaryBO.deleteMedBillsCargo(existingCargo);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in deleteMedicalExpenseDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.DEL_MEDI_EXP_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.deleteMedicalExpenseDetails() - END",
				txnBean);
	}

	/**
	 * Store medical expense detail.
	 *
	 * @param txnBean the txn bean
	 */
	/* Store method for Medical Expense Details */
	@Transactional
	public void store60OrDisabilityDetails(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.store60OrDisabilityDetails() - START",
				txnBean);
		try {

			final Map pageCollection = txnBean.getPageCollection();
			final Map request = txnBean.getRequest();
			String appNumber = txnBean.getUserDetails().getAppNumber();
			FwMessageList validateInfo = null;
			int seq_num = 0;
			int indv_seq_num = 0;
			if (Objects.nonNull(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence())) {

				indv_seq_num = Integer.parseInt(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.getIndividualSequence());
			}
			if (Objects.nonNull(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence())) {
				seq_num = Integer.parseInt(
						txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			String medBillType = "DM"; // Setting columns values to default bcz which should not be null

			// get Details aset Collection and Cargo
			CP_APP_IN_MED_BILLS_Cargo appInMedBillsCargoFromReq = new CP_APP_IN_MED_BILLS_Cargo();
			CP_APP_IN_MED_BILLS_Collection appInMedBillsCollFromReq = (CP_APP_IN_MED_BILLS_Collection) pageCollection
					.get(CP_APP_IN_MED_BILLS_COLL);
			if (Objects.nonNull(appInMedBillsCollFromReq)) {
				appInMedBillsCargoFromReq = appInMedBillsCollFromReq.getCargo(0);
			}

			// get the Aset collection from Before Collection
			final CP_APP_IN_MED_BILLS_Collection appInMedBillsCollFromDB = abOtherExpensesSummaryBO
					.getMedDetailsByyMedBillType(appNumber, indv_seq_num, medBillType);
			boolean isIndvPresent = false;
			if ((appInMedBillsCollFromDB != null) && (!appInMedBillsCollFromDB.isEmpty())) {
				for (CP_APP_IN_MED_BILLS_Cargo fromDb : appInMedBillsCollFromDB.getResults()) {
					if (fromDb.getMedical_seq_num() == (seq_num)) {
						isIndvPresent = setMedBillsCargoFromDBValues(pageCollection, appInMedBillsCargoFromReq,
								appInMedBillsCollFromReq, fromDb);
					}
				}
			}
			if (!isIndvPresent) {

				appInMedBillsCargoFromReq.setMedical_seq_num(seq_num);
				appInMedBillsCargoFromReq.setApp_num(appNumber);
				// Setting columns values to default bcz which should not be null
				appInMedBillsCargoFromReq.setMed_bill_type(medBillType);
				appInMedBillsCargoFromReq.setSrc_app_ind(FinancialInfoConstants.SRC_APP_AFB);
				cpAppInMedBillsRepository.save(appInMedBillsCargoFromReq);
				pageCollection.replace(CP_APP_IN_MED_BILLS_COLL, appInMedBillsCollFromReq);
			}
			validateInfo = null;

			if ((validateInfo != null) && validateInfo.hasMessages()) {

				pageCollection.put(CP_APP_IN_MED_BILLS_COLL, appInMedBillsCollFromReq);
				request.put(FwConstants.MESSAGE_LIST, validateInfo);

				return;
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in store60OrDisabilityDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_60OR_DIS_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.store60OrDisabilityDetails() - END",
				txnBean);
	}

	private boolean setMedBillsCargoFromDBValues(final Map pageCollection,
			CP_APP_IN_MED_BILLS_Cargo appInMedBillsCargoFromReq,
			CP_APP_IN_MED_BILLS_Collection appInMedBillsCollFromReq, CP_APP_IN_MED_BILLS_Cargo fromDb) {
		boolean isIndvPresent;
		
			if (Objects.nonNull(appInMedBillsCargoFromReq.getPayment_amt())) {
				fromDb.setPayment_amt(appInMedBillsCargoFromReq.getPayment_amt());
			}
			if (Objects.nonNull(appInMedBillsCargoFromReq.getReimburse_ind())) {
				fromDb.setReimburse_ind(appInMedBillsCargoFromReq.getReimburse_ind());
			}
			if (Objects.nonNull(appInMedBillsCargoFromReq.getReimburse_name())) {
				fromDb.setReimburse_name(appInMedBillsCargoFromReq.getReimburse_name());
			}
			if (Objects.nonNull(appInMedBillsCargoFromReq.getReimburse_amt())) {
				fromDb.setReimburse_amt(appInMedBillsCargoFromReq.getReimburse_amt());
			}
			if (Objects.nonNull(appInMedBillsCargoFromReq.getPay_freq())) {
				fromDb.setPay_freq(appInMedBillsCargoFromReq.getPay_freq());
			}
			if (Objects.nonNull(appInMedBillsCargoFromReq.getAdapt_record_id())) {
				fromDb.setAdapt_record_id(appInMedBillsCargoFromReq.getAdapt_record_id());
			}
			cpAppInMedBillsRepository.save(fromDb);
			appInMedBillsCollFromReq.set(0, fromDb);
			pageCollection.replace(CP_APP_IN_MED_BILLS_COLL, appInMedBillsCollFromReq);
			isIndvPresent = true;
			return isIndvPresent;
		
	}

	@Transactional
	public void get60OrDisabilityDetails(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.get60OrDisabilityDetails() - START",
				txnBean);
		try {

			String app_num = txnBean.getUserDetails().getAppNumber();
			int seq_num = 0;
			int indv_seq_num = 0;
			Map pageCollection = txnBean.getPageCollection();
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			String type = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			final Map request = txnBean.getRequest();
			// make loopingQuestion value NO in the request
			request.put(LOOP_QUESTION, FwConstants.NO);

			// Added as part of CSPM-3094 Creating name indv id map from fw_request objcet
			APP_INDV_Collection appIndvCollFromRequest = null;
			Map<Integer, String> indvIdNameMap = new HashMap<Integer, String>();
			appIndvCollFromRequest = (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection");
			if (Objects.nonNull(appIndvCollFromRequest)) {
				APP_INDV_Cargo[] appIndvArray = appIndvCollFromRequest.getResults();
				for (APP_INDV_Cargo indvCargo : appIndvArray) {
					if (!indvIdNameMap.containsKey(indvCargo.getIndv_seq_num())) {
						indvIdNameMap.put(indvCargo.getIndv_seq_num(),
								indvCargo.getFst_nam() + " " + indvCargo.getLast_nam());
					}
				}
			}

			// When user hits the Back button or comes from the Summary Page
			pageCollection = backButton(app_num, seq_num, indv_seq_num, pageCollection, indvIdList, type,
					indvIdNameMap);

			final CP_APP_IN_MED_BILLS_Collection medBillColl = (CP_APP_IN_MED_BILLS_Collection) pageCollection
					.get(CP_APP_IN_MED_BILLS_COLL);
			if ((medBillColl != null) && (!medBillColl.isEmpty())) {
				final CP_APP_IN_MED_BILLS_Cargo medBillCargo = medBillColl.getCargo(0);
				medBillCargo.getMed_bill_type();
				medBillCargo.getIndv_seq_num();
			}

			// put the Current Individual Sequence Number in the pageCollection
			if ((medBillColl != null) && (!medBillColl.isEmpty())) {
				final CP_APP_IN_MED_BILLS_Cargo medBillCargo = medBillColl.getCargo(0);
				final String indvSeqNum = medBillCargo.getIndv_seq_num().toString();
				pageCollection.put(AppConstants.CURRENT_INDIV_SEQ_NUM, indvSeqNum);
			}

			txnBean.setPageCollection(pageCollection);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in get60OrDisabilityDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_60OR_DIS_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.get60OrDisabilityDetails() - END",
				txnBean);
	}
	@SuppressWarnings("squid:S3776")
	private Map backButton(String app_num, int seq_num, int indv_seq_num, Map pageCollection, List<Integer> indvIdList,
			String type, Map<Integer, String> indvIdNameMap) {
		try {
			String mode = (String) pageCollection.get(FinancialInfoConstants.MODE);
			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {
				if (null == mode || !mode.equals(FinancialInfoConstants.RAC)) {
					pageCollection = new HashMap();
				}
				// get Details_Collection from DataBase and set to
				// PageCollection
				CP_APP_IN_MED_BILLS_Collection coll = abOtherExpensesSummaryBO.getMedicalExpenseDetail(app_num,
						indv_seq_num, seq_num, type);
				pageCollection.put(CP_APP_IN_MED_BILLS_COLL, coll);
			} else {
				if (null == mode || !mode.equals(FinancialInfoConstants.RAC)) {
					pageCollection = new HashMap();
				}
				CP_APP_IN_MED_BILLS_Cargo[] appIndvArrayFromDB = null;

				CP_APP_IN_MED_BILLS_Collection appIndvCollToRequest = null;
				appIndvArrayFromDB = cpAppInMedBillsRepository.getByAppNumAndIndvs(Integer.parseInt(app_num), indvIdList);
				if (null != appIndvArrayFromDB && appIndvArrayFromDB.length > 0) {
					appIndvCollToRequest = new CP_APP_IN_MED_BILLS_Collection();
					for (CP_APP_IN_MED_BILLS_Cargo cargo : appIndvArrayFromDB) {
						//Removed null check as part of CSPM-32710
						if (null != cargo.getMed_bill_type()
								&& cargo.getMed_bill_type().equalsIgnoreCase("DM")) {

							if (null == cargo.getPayment_amt()) {
								cargo.setPayment_amt(0.00);
							}
							cargo.setFirstName(indvIdNameMap.get(cargo.getIndv_seq_num()));
							appIndvCollToRequest.addCargo(cargo);

						}
					}
					if (null != mode && mode.equals(FinancialInfoConstants.RAC)) {
						CP_APP_IN_MED_BILLS_Collection existingColl = (CP_APP_IN_MED_BILLS_Collection) pageCollection
								.get(CP_APP_IN_MED_BILLS_COLL);
						if (null != existingColl && !existingColl.isEmpty()) {
							appIndvCollToRequest.addAll(existingColl);
						}
					}
					pageCollection.put(CP_APP_IN_MED_BILLS_COLL, appIndvCollToRequest);
				}
			}
			return pageCollection;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in backButton()", e);
			throw e;
		}
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void delete60OrDisabilityDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.delete60OrDisabilityDetails() - START",
				txnBean);
		try {

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String appNum = userDetails.getAppNumber();
			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			int seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());
			String medBillType = "DM"; // Setting columns values to default bcz which should not be null
			CP_APP_IN_MED_BILLS_Collection existingMedBillsColl = abOtherExpensesSummaryBO
					.getMedicalExpenseDetail(appNum, indvSeqNum, seqNum, medBillType);
			if (Objects.nonNull(existingMedBillsColl) && !existingMedBillsColl.isEmpty()) {
				CP_APP_IN_MED_BILLS_Cargo existingCargo = existingMedBillsColl.getCargo(0);
				if (Objects.nonNull(existingCargo))
					abOtherExpensesSummaryBO.deleteMedBillsCargo(existingCargo);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in delete60OrDisabilityDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.DEL_60OR_DIS_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.delete60OrDisabilityDetails() - END",
				txnBean);
	}

	/**
	 * Store medical expense detail.
	 *
	 * @param txnBean the txn bean
	 */
	/* Store method for Medical Expense Details */
	@Transactional
	public void storeBillPayHelpSelectionDetails(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesService.storeBillPayHelpSelectionDetails() - START", txnBean);
		try {

			final Map pageCollection = txnBean.getPageCollection();

			String appNumber = txnBean.getUserDetails().getAppNumber();
			// Murali

			// get Details aset Collection and Cargo
			CP_APP_IN_MED_BILLS_Cargo appInMedBillsCargoFromReq = new CP_APP_IN_MED_BILLS_Cargo();
			CP_APP_IN_MED_BILLS_Collection appInMedBillsCollFromReq = (CP_APP_IN_MED_BILLS_Collection) pageCollection
					.get(CP_APP_IN_MED_BILLS_COLL);
			int seq_num = 0;
			if (Objects.nonNull(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence())) {
				seq_num = Integer.parseInt(
						txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}
			int indv_seq_num = Integer.parseInt(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			if (null != appInMedBillsCollFromReq) {
				appInMedBillsCargoFromReq = appInMedBillsCollFromReq.getCargo(0);
			}

			// get the Aset collection from Before Collection
			String medBillType = "HM";
			final CP_APP_IN_MED_BILLS_Collection appInMedBillsCollFromDB = abOtherExpensesSummaryBO
					.getMedDetailsByyMedBillType(appNumber, indv_seq_num, medBillType);
			if ((appInMedBillsCollFromDB != null) && (!appInMedBillsCollFromDB.isEmpty())) {
				for (CP_APP_IN_MED_BILLS_Cargo fromDb : appInMedBillsCollFromDB.getResults()) {

					persistSingleMedBillsCargo(pageCollection, appInMedBillsCargoFromReq, appInMedBillsCollFromReq,
							fromDb);

				}
			}else {

			appInMedBillsCargoFromReq.setMedical_seq_num(seq_num);
			appInMedBillsCargoFromReq.setApp_num(appNumber);
			// Setting columns values to default bcz which should not be null
			appInMedBillsCargoFromReq.setSrc_app_ind(FinancialInfoConstants.SRC_APP_AFB);
			appInMedBillsCargoFromReq.setMed_bill_type("HM");
			appInMedBillsCargoFromReq.setIndv_seq_num(indv_seq_num);
			cpAppInMedBillsRepository.save(appInMedBillsCargoFromReq);
			pageCollection.replace(CP_APP_IN_MED_BILLS_COLL, appInMedBillsCollFromReq);
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeBillPayHelpSelectionDetails()",
					txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_PAY_BILL_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesService.storeBillPayHelpSelectionDetails() - END", txnBean);
	}

	private void persistSingleMedBillsCargo(final Map pageCollection,
			CP_APP_IN_MED_BILLS_Cargo appInMedBillsCargoFromReq,
			CP_APP_IN_MED_BILLS_Collection appInMedBillsCollFromReq, CP_APP_IN_MED_BILLS_Cargo fromDb) {
		try {
			if (Objects.nonNull(appInMedBillsCargoFromReq.getMa_backdt_mo_1_ind())) {
				fromDb.setMa_backdt_mo_1_ind(appInMedBillsCargoFromReq.getMa_backdt_mo_1_ind());
				fromDb.setMa_backdt_mo_2_ind(null);
				fromDb.setMa_backdt_mo_3_ind(null);
			}
			if (Objects.nonNull(appInMedBillsCargoFromReq.getMa_backdt_mo_2_ind())) {
				fromDb.setMa_backdt_mo_2_ind(appInMedBillsCargoFromReq.getMa_backdt_mo_2_ind());
				fromDb.setMa_backdt_mo_1_ind(null);
				fromDb.setMa_backdt_mo_3_ind(null);
			}
			if (Objects.nonNull(appInMedBillsCargoFromReq.getMa_backdt_mo_3_ind())) {
				fromDb.setMa_backdt_mo_3_ind(appInMedBillsCargoFromReq.getMa_backdt_mo_3_ind());
				fromDb.setMa_backdt_mo_1_ind(null);
				fromDb.setMa_backdt_mo_2_ind(null);
			}
			cpAppInMedBillsRepository.save(fromDb);
			if (null != appInMedBillsCollFromReq) {
				appInMedBillsCollFromReq.set(0, fromDb);
			}
			pageCollection.replace(CP_APP_IN_MED_BILLS_COLL, appInMedBillsCollFromReq);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in persistSingleMedBillsCargo()", e);
			throw e;
		}
	}

	@Transactional
	public void getBillPayHelpSelectionDetails(final FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesService.getBillPayHelpSelectionDetails() - START", txnBean);
		try {

			String app_num = txnBean.getUserDetails().getAppNumber();
			int seq_num = 0;
			int indv_seq_num = 0;
			Map pageCollection = txnBean.getPageCollection();
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			if (Objects.nonNull(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence())) {
				indv_seq_num = Integer.parseInt(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.getIndividualSequence());
			}
			if (Objects.nonNull(
					txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence())) {
				seq_num = Integer.parseInt(
						txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}
			String type = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			final Map request = txnBean.getRequest();
			// make loopingQuestion value NO in the request
			request.put(LOOP_QUESTION, FwConstants.NO);

			// Added as part of CSPM-3094 Creating name indv id map from fw_request objcet

			// When user hits the Back button or comes from the Summary Page
			pageCollection = backButtonForBillPay(app_num, seq_num, indv_seq_num, pageCollection, indvIdList, type);

			final CP_APP_IN_MED_BILLS_Collection medBillColl = (CP_APP_IN_MED_BILLS_Collection) pageCollection
					.get(CP_APP_IN_MED_BILLS_COLL);
			if ((medBillColl != null) && (!medBillColl.isEmpty())) {
				final CP_APP_IN_MED_BILLS_Cargo medBillCargo = medBillColl.getCargo(0);
				medBillCargo.getMed_bill_type();
				medBillCargo.getIndv_seq_num();

			}

			// put the Current Individual Sequence Number in the pageCollection
			if ((medBillColl != null) && (!medBillColl.isEmpty())) {
				final CP_APP_IN_MED_BILLS_Cargo medBillCargo = medBillColl.getCargo(0);
				final String indvSeqNum = medBillCargo.getIndv_seq_num().toString();
				pageCollection.put(AppConstants.CURRENT_INDIV_SEQ_NUM, indvSeqNum);
			}

			txnBean.setPageCollection(pageCollection);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getBillPayHelpSelectionDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.GET_BILL_PAY_HELP_SEL_DET, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesService.getBillPayHelpSelectionDetails() - END", txnBean);
	}
	@SuppressWarnings("squid:S3776")
	private Map backButtonForBillPay(String app_num, int seq_num, int indv_seq_num, Map pageCollection,
			List<Integer> indvIdList, String type) {
		try {
			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {

				pageCollection = new HashMap();
				CP_APP_IN_MED_BILLS_Collection coll = abOtherExpensesSummaryBO.getMedicalExpenseDetail(app_num,
						indv_seq_num, seq_num, type);
				pageCollection.put(CP_APP_IN_MED_BILLS_COLL, coll);
			} else {
				pageCollection = new HashMap();

				CP_APP_IN_MED_BILLS_Cargo[] appIndvArrayFromDB = null;
				CP_APP_IN_MED_BILLS_Collection appIndvCollToRequest = null;
				appIndvArrayFromDB = cpAppInMedBillsRepository.getByAppNumAndIndvs(Integer.parseInt(app_num), indvIdList);
				if (null != appIndvArrayFromDB && appIndvArrayFromDB.length > 0) {
					appIndvCollToRequest = new CP_APP_IN_MED_BILLS_Collection();
					for (CP_APP_IN_MED_BILLS_Cargo cargo : appIndvArrayFromDB) {
						if ((Objects.nonNull(cargo.getMa_backdt_mo_1_ind())
								|| Objects.nonNull(cargo.getMa_backdt_mo_2_ind())
								|| Objects.nonNull(cargo.getMa_backdt_mo_3_ind()))
								&& cargo.getMed_bill_type().equalsIgnoreCase("HM")) {
							if (Objects.nonNull(cargo.getMa_backdt_mo_1_ind())) {
								cargo.setRec_cplt_ind(cargo.getMa_backdt_mo_1_ind());
							} else if (Objects.nonNull(cargo.getMa_backdt_mo_2_ind())) {
								cargo.setRec_cplt_ind(cargo.getMa_backdt_mo_2_ind());
							} else {
								cargo.setRec_cplt_ind(cargo.getMa_backdt_mo_3_ind());
							}
							appIndvCollToRequest.addCargo(cargo);
						}
					}
					pageCollection.put(CP_APP_IN_MED_BILLS_COLL, appIndvCollToRequest);
				}
			}
			return pageCollection;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in backButtonForBillPay()", e);
			throw e;
		}
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void deleteBillPayHelpSelectionDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesService.deleteBillPayHelpSelectionDetails() - START", txnBean);
		try {

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String appNum = userDetails.getAppNumber();
			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			int seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());
			String medBillType = "HM";// For bill pay help selection
			CP_APP_IN_MED_BILLS_Collection existingMedBillsColl = abOtherExpensesSummaryBO
					.getMedicalExpenseDetail(appNum, indvSeqNum, seqNum, medBillType);
			if (Objects.nonNull(existingMedBillsColl) && !existingMedBillsColl.isEmpty()) {
				CP_APP_IN_MED_BILLS_Cargo existingCargo = existingMedBillsColl.getCargo(0);
				if (Objects.nonNull(existingCargo))
					abOtherExpensesSummaryBO.deleteMedBillsCargo(existingCargo);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in deleteBillPayHelpSelectionDetails()",
					txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.DELETE_BILL_SEL_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesService.deleteBillPayHelpSelectionDetails() - END", txnBean);
	}

	// Student Loan Interest - save
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void saveAlimonyStLoanDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.saveAlimonyStLoanDetails() - START",
				fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			Integer seqNum = null;
			Integer indvSeqNum = null;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			String pgId = fwTxn.getCurrentActionDetails().getPageId();
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"OtherExpensesServImpl.saveAlimonyStLoanDetails() - pgId " + pgId);
			CP_APP_IN_INCOME_TAX_DED_Collection inTaxDeductionColl = (CP_APP_IN_INCOME_TAX_DED_Collection) pageCollection
					.get(CP_APP_IN_INCOME_TAX_DED_COLL);
			CP_APP_IN_INCOME_TAX_DED_Cargo inTaxDeductionCargo;

			if (null != inTaxDeductionColl && !inTaxDeductionColl.isEmpty()) {
				inTaxDeductionCargo = inTaxDeductionColl.getCargo(0);
				if (null != inTaxDeductionCargo) {
					inTaxDeductionCargo.setApp_num(appNumber);
					if (inTaxDeductionCargo.getIndv_seq_num() != null) {
						indvSeqNum = inTaxDeductionCargo.getIndv_seq_num();
					} else if (Objects.nonNull(fwTxn.getCurrentActionDetails())
							&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
							&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
									.getIndividualSequence())) {
						indvSeqNum = Integer.parseInt(fwTxn.getCurrentActionDetails()
								.getIndividualCategorySequenceDetails().getIndividualSequence());
					}
					inTaxDeductionCargo.setIndv_seq_num(indvSeqNum);
					inTaxDeductionCargo.setSeq_num(seqNum);
					inTaxDeductionCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
					othBo.saveAlimonyStLoanDetails(inTaxDeductionCargo);
				}
			}

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in saveAlimonyStLoanDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.SAVE_ALIMONY_ST_LOAN_DETAILS, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.saveAlimonyStLoanDetails() - END",
				fwTxn);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	public void loadAlimonyStLoanDetails(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesServImpl.loadAlimonyStLoanDetails() - START");
		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appnum = userDetails.getAppNumber();
			String expType = null;
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"OtherExpensesServImpl.loadAlimonyStLoanDetails() - Getting data for appnum " + appnum);
			if (null != txnBean.getCurrentActionDetails().getPageId()) {
				if (txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase(FinancialInfoConstants.ABARS))
					expType = FinancialInfoConstants.ALIMONY;
				else if (txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase(FinancialInfoConstants.ABSLR))
					expType = FinancialInfoConstants.STUDENTLOAN;
				else if (txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase(FinancialInfoConstants.ABODR)
						|| txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase(FinancialInfoConstants.RCMTD))
					expType = FinancialInfoConstants.OTHERDEDUCTIONS;
			}
			CP_APP_IN_INCOME_TAX_DED_Collection inTaxDeductionColl = othBo.loadAlimonyStLoanDetails(appnum, expType);
			if (!inTaxDeductionColl.isEmpty()) {
				pageCollection.put(CP_APP_IN_INCOME_TAX_DED_COLL, inTaxDeductionColl);
			}

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in loadAlimonyStLoanDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.LOAD_ALIMONY_ST_LOAN_DETAILS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.loadAlimonyStLoanDetails() - END",
				txnBean);
	}

	// Remove student loan interest data
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void deleteAlimonyStLoanDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.deleteAlimonyStLoanDetails() - START",
				txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			String appNum = txnBean.getUserDetails().getAppNumber();
			Integer seqNum = null;
			Integer indvSeqNum = null;
			String expType = null;
			if (Objects.nonNull(txnBean.getCurrentActionDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.getIndividualSequence());
			}
			if (Objects.nonNull(txnBean.getCurrentActionDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}
			if (null != txnBean.getCurrentActionDetails().getPageId()) {
				if (txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase(FinancialInfoConstants.ABARS))
					expType = FinancialInfoConstants.ALIMONY;
				else if (txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase(FinancialInfoConstants.ABSLR))
					expType = FinancialInfoConstants.STUDENTLOAN;
				else if (txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase(FinancialInfoConstants.ABODR)
						|| txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase(FinancialInfoConstants.RCMTD))
					expType = FinancialInfoConstants.OTHERDEDUCTIONS;
			}
			CP_APP_IN_INCOME_TAX_DED_Cargo inTaxDeductionCargo = new CP_APP_IN_INCOME_TAX_DED_Cargo();

			if (!StringUtils.isEmpty(appNum) && seqNum != null && indvSeqNum != null) {
				inTaxDeductionCargo.setApp_num(appNum);
				inTaxDeductionCargo.setIndv_seq_num(indvSeqNum);
				inTaxDeductionCargo.setSeq_num(seqNum);
				inTaxDeductionCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
				inTaxDeductionCargo.setExp_type(expType);
				othBo.deleteAlimonyStLoanDetails(inTaxDeductionCargo);
			}

			CP_APP_IN_INCOME_TAX_DED_Collection inTaxDeductionColl = othBo.loadAlimonyStLoanDetails(appNum, expType);
			pageCollection.put(CP_APP_IN_INCOME_TAX_DED_COLL, inTaxDeductionColl);

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in deleteAlimonyStLoanDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.DELETE_ALIMONY_ST_LOAN_DETAILS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherExpensesService.deleteAlimonyStLoanDetails() - END",
				txnBean);

	}

	public void loadAlimonyStLoanForRacSummary(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesServImpl.loadAlimonyStLoanForRacSummary() - START");
		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appnum = userDetails.getAppNumber();
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"OtherExpensesServImpl.loadAlimonyStLoanForRacSummary() - Getting data for appnum " + appnum);

			CP_APP_IN_INCOME_TAX_DED_Collection inTaxDeductionColl = othBo.getAppInDeductionTaxByAppNum(appnum);
			if (!inTaxDeductionColl.isEmpty()) {
				pageCollection.put(CP_APP_IN_INCOME_TAX_DED_COLL, inTaxDeductionColl);
			}

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID("getServiceClass");
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, LOAD_ALI_ST_LOAN_DET, fe);
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherExpensesServImpl.loadAlimonyStLoanForRacSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}

}
