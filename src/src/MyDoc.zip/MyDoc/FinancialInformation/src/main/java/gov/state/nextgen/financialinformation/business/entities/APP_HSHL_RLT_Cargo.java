/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import javax.persistence.Id;

import gov.state.nextgen.access.business.entities.AbstractCargo;


public class APP_HSHL_RLT_Cargo extends AbstractCargo implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String app_num;
	@Id
	private String ref_indv_seq_num;
	@Id
	private String src_indv_seq_num;
	@Id
	private String src_app_ind;
	private String care_resp;
	private String chg_eff_dt;
	private String pnp_tghr_sw;
	private String rec_cplt_ind;
	private String rlt_cd;
	private String phy_boe_sep_sw;
	private String tax_dpnd_resp;
	private String chg_dt;
	
	/**
     * @return the chg_dt
     */
    public String getChg_dt() {
        return chg_dt;
    }

    /**
     * @param chg_dt the chg_dt to set
     */
    public void setChg_dt(String chg_dt) {
        this.chg_dt = chg_dt;
    }

	public String getTax_dpnd_resp() {
		return tax_dpnd_resp;
	}

	public void setTax_dpnd_resp(final String tax_dpnd_resp) {
		this.tax_dpnd_resp = tax_dpnd_resp;
	}

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return app_num;
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_num = app_num;
	}

	/**
	 * returns the ref_indv_seq_num value.
	 */
	public String getRef_indv_seq_num() {
		return ref_indv_seq_num;
	}

	/**
	 * sets the ref_indv_seq_num value.
	 */
	public void setRef_indv_seq_num(final String ref_indv_seq_num) {
		this.ref_indv_seq_num = ref_indv_seq_num;
	}

	/**
	 * returns the src_indv_seq_num value.
	 */
	public String getSrc_indv_seq_num() {
		return src_indv_seq_num;
	}

	/**
	 * sets the src_indv_seq_num value.
	 */
	public void setSrc_indv_seq_num(final String src_indv_seq_num) {
		this.src_indv_seq_num = src_indv_seq_num;
	}

	/**
	 * returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * returns the care_resp value.
	 */
	public String getCare_resp() {
		return care_resp;
	}

	/**
	 * sets the care_resp value.
	 */
	public void setCare_resp(final String care_resp) {
		this.care_resp = care_resp;
	}

	/**
	 * returns the chg_eff_dt value.
	 */
	public String getChg_eff_dt() {
		return chg_eff_dt;
	}

	/**
	 * sets the chg_eff_dt value.
	 */
	public void setChg_eff_dt(final String chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}

	/**
	 * returns the pnp_tghr_sw value.
	 */
	public String getPnp_tghr_sw() {
		return pnp_tghr_sw;
	}

	/**
	 * sets the pnp_tghr_sw value.
	 */
	public void setPnp_tghr_sw(final String pnp_tghr_sw) {
		this.pnp_tghr_sw = pnp_tghr_sw;
	}

	/**
	 * returns the rec_cplt_ind value.
	 */
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * sets the rec_cplt_ind value.
	 */
	public void setRec_cplt_ind(final String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * returns the rlt_cd value.
	 */
	public String getRlt_cd() {
		return rlt_cd;
	}

	/**
	 * sets the rlt_cd value.
	 */
	public void setRlt_cd(final String rlt_cd) {
		this.rlt_cd = rlt_cd;
	}

	/**
	 * returns the phy_boe_sep_sw value.
	 */
	public String getPhy_boe_sep_sw() {
		return phy_boe_sep_sw;
	}

	/**
	 * sets the phy_boe_sep_sw value.
	 */
	public void setPhy_boe_sep_sw(final String phy_boe_sep_sw) {
		this.phy_boe_sep_sw = phy_boe_sep_sw;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((app_num == null) ? 0 : app_num.trim().hashCode());
		result = (prime * result) + ((care_resp == null) ? 0 : care_resp.trim().hashCode());
		result = (prime * result) + ((chg_eff_dt == null) ? 0 : chg_eff_dt.trim().hashCode());
		result = (prime * result) + ((phy_boe_sep_sw == null) ? 0 : phy_boe_sep_sw.trim().hashCode());
		result = (prime * result) + ((pnp_tghr_sw == null) ? 0 : pnp_tghr_sw.trim().hashCode());
		result = (prime * result) + ((rec_cplt_ind == null) ? 0 : rec_cplt_ind.trim().hashCode());
		result = (prime * result) + ((ref_indv_seq_num == null) ? 0 : ref_indv_seq_num.trim().hashCode());
		result = (prime * result) + ((rlt_cd == null) ? 0 : rlt_cd.trim().hashCode());
		result = (prime * result) + ((src_app_ind == null) ? 0 : src_app_ind.trim().hashCode());
		result = (prime * result) + ((src_indv_seq_num == null) ? 0 : src_indv_seq_num.trim().hashCode());
		result = (prime * result) + ((tax_dpnd_resp == null) ? 0 : tax_dpnd_resp.trim().hashCode());
		result = (prime * result) + ((chg_dt == null) ? 0 : chg_dt.trim().hashCode());
		return result;
	}


	

}
