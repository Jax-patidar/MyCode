package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "CP_APP_IN_DEDUCTION")
@IdClass(CP_APP_IN_DEDUCTION_Key.class)
public class CP_APP_IN_DEDUCTION_Cargo extends AbstractCargo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Transient
	private boolean isDirty = false;

	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;

	@Id
	private Integer indv_seq_num;

	@Id
	private Integer seq_num;

	
	private String src_app_ind;

	@Id
	@Column(name="exp_type")
	private String exp_typ;

	private Double exp_amt;

	@Transient
	private String ecp_id;


	private Integer rec_cplt_ind;
	private Date expense_end_dt;
	private String exp_sub_type;
	private String smone_els_pay_ind;
	private String child_sup_payee_name;
	@Column(name="court_order_pay_child_sup_ind")
	private String court_order_pay_chld_sup_ind;
	private Double court_order_pay_amt;
	private String pay_freq_cd;
	private String children_name;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date divorce_dt;
	@Column(name = "other_expense_type")
	private String otherExpenseType;
	
	@Column(name = "ded_calsaws_object")
	private String dedCalsawsObject;

	/**
	 * Non existnent fields - Transient
	 */
	@Transient
	private String chld_sup_payee_nam;

	@Transient
	private String loopingInd;
	
	@Transient
	private String fst_name;

	public String getFst_name() {
		return fst_name;
	}

	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}

	@JsonFormat(pattern = "yyyy-MM-dd")
	@Column(name="change_dt")
	private Date chg_dt;

	/**
	 * @return the chg_dt
	 */
	public Date getChg_dt() {
        return this.chg_dt!= null ? new Date(chg_dt.getTime()) : null;
	}

	/**
	 * @param chg_dt the chg_dt to set
	 */
	public void setChg_dt(Date chg_dt) {
		this.chg_dt = (chg_dt == null) ? null : new Date(chg_dt.getTime());
	}

	/**
	 * @return the ecp_id
	 */
	public String getEcp_id() {
		return ecp_id;
	}

	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(final String ecp_id) {
		this.ecp_id = ecp_id;
	}

	@Override
	public boolean isDirty() {
		return isDirty;
	}

	@Override
	public void setDirty(final boolean isDirty) {
		this.isDirty = isDirty;
	}

	public String getCourt_order_pay_chld_sup_ind() {
		return court_order_pay_chld_sup_ind;
	}

	public void setCourt_order_pay_chld_sup_ind(final String court_order_pay_chld_sup_ind) {
		this.court_order_pay_chld_sup_ind = court_order_pay_chld_sup_ind;
	}

	public Double getCourt_order_pay_amt() {
		return court_order_pay_amt;
	}

	public void setCourt_order_pay_amt(final Double court_order_pay_amt) {
		this.court_order_pay_amt = court_order_pay_amt;
	}

	public String getChld_sup_payee_nam() {
		return chld_sup_payee_nam;
	}

	public void setChld_sup_payee_nam(final String chld_sup_payee_nam) {
		this.chld_sup_payee_nam = chld_sup_payee_nam;
	}

	public Date getExp_end_date() {
        return expense_end_dt!= null ? expense_end_dt : null;
	}

	public void setExp_end_date(final Date exp_end_date) {
		this.expense_end_dt = (exp_end_date == null) ? null : exp_end_date;
	}

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * returns the exp_typ value.
	 */
	public String getExp_typ() {
		return exp_typ;
	}

	/**
	 * returns the exp_amt value.
	 */
	public Double getExp_amt() {
		return exp_amt;
	}

	/**
	 * returns the rec_cplt_ind value.
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * sets the exp_typ value.
	 */
	public void setExp_typ(final String exp_typ) {
		this.exp_typ = exp_typ;
	}

	/**
	 * sets the exp_amt value.
	 */
	public void setExp_amt(final Double exp_amt) {
		this.exp_amt = exp_amt;
	}

	/**
	 * sets the rec_cplt_ind value.
	 */
	public void setRec_cplt_ind(final Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * @return the loopingInd
	 */
	public String getLoopingInd() {
		return loopingInd;
	}

	/**
	 * @param loopingInd the loopingInd to set
	 */
	public void setLoopingInd(final String loopingInd) {
		this.loopingInd = loopingInd;
	}

	/**
	 * @return the pay_freq_cd
	 */
	public String getPay_freq_cd() {
		return pay_freq_cd;
	}

	/**
	 * @param pay_freq_cd the pay_freq_cd to set
	 */
	public void setPay_freq_cd(final String pay_freq_cd) {
		this.pay_freq_cd = pay_freq_cd;
	}

	public String getExp_sub_type() {
		return exp_sub_type;
	}

	public void setExp_sub_type(String exp_sub_type) {
		this.exp_sub_type = exp_sub_type;
	}

	public String getSmone_els_pay_ind() {
		return smone_els_pay_ind;
	}

	public void setSmone_els_pay_ind(String smone_els_pay_ind) {
		this.smone_els_pay_ind = smone_els_pay_ind;
	}

	public Date getExpense_end_dt() {
		return expense_end_dt;
	}

	public void setExpense_end_dt(Date expense_end_dt) {
		this.expense_end_dt = expense_end_dt;
	}

	public String getChild_sup_payee_name() {
		return child_sup_payee_name;
	}

	public void setChild_sup_payee_name(String child_sup_payee_name) {
		this.child_sup_payee_name = child_sup_payee_name;
	}

	

	public String getChildren_name() {
		return children_name;
	}

	public void setChildren_name(String children_name) {
		this.children_name = children_name;
	}

	public Date getDivorce_dt() {
		return divorce_dt;
	}

	public void setDivorce_dt(Date divorce_dt) {
		this.divorce_dt = divorce_dt;
	}

	public String getOtherExpenseType() {
		return otherExpenseType;
	}

	public void setOtherExpenseType(String otherExpenseType) {
		this.otherExpenseType = otherExpenseType;
	}
	
	public String getDedCalsawsObject() {
		return dedCalsawsObject;
	}

	public void setDedCalsawsObject(String dedCalsawsObject) {
		this.dedCalsawsObject = dedCalsawsObject;
	}
}
