package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(CP_INDV_EXP_Id.class)
@Table(name = "CP_INDV_EXP")
public class CP_INDV_EXP_Cargo extends AbstractCargo implements Serializable {

	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	private Integer hshl_id;
	@Id
	private Integer indv_id;
	@Id
	private String exp_type;
	
	private Double exp_amt;

	
	/**
	 * @return the hshl_id
	 */
	public Integer getHshl_id() {
		return hshl_id;
	}

	/**
	 * @param hshl_id the hshl_id to set
	 */
	public void setHshl_id(Integer hshl_id) {
		this.hshl_id = hshl_id;
	}

	/**
	 * @return the indv_id
	 */
	public Integer getIndv_id() {
		return indv_id;
	}

	/**
	 * @param indv_id the indv_id to set
	 */
	public void setIndv_id(Integer indv_id) {
		this.indv_id = indv_id;
	}

	/**
	 * @return the exp_type
	 */
	public String getExp_type() {
		return exp_type;
	}

	/**
	 * @param exp_type the exp_type to set
	 */
	public void setExp_type(String exp_type) {
		this.exp_type = exp_type;
	}

	/**
	 * @return the exp_amt
	 */
	public Double getExp_amt() {
		return exp_amt;
	}

	/**
	 * @param exp_amt the exp_amt to set
	 */
	public void setExp_amt(Double exp_amt) {
		this.exp_amt = exp_amt;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((exp_amt == null) ? 0 : exp_amt.hashCode());
		result = prime * result + ((exp_type == null) ? 0 : exp_type.hashCode());
		result = prime * result + ((hshl_id == null) ? 0 : hshl_id.hashCode());
		result = prime * result + ((indv_id == null) ? 0 : indv_id.hashCode());
		return result;
	}

	

}