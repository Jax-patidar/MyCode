package gov.state.nextgen.financialinformation.business.rules;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessage;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_A_WAGE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_A_WAGE_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;


@Service("CommonLogicBO")
public class CommonLogicBO extends AbstractBO  {
	
	private static final String FETCHAPPDET = "fetchAppointmentDetails";
	
	private static final String CARGO = "_Cargo";
	
	
	
	
	public APP_IN_SELFE_Cargo splitEmplColl(
            final APP_IN_SELFE_Collection emplColl, final String recordIndicator) {
		

		try {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"RMCJobIncomeEJBBean.splitEmplColl() - START");
		
        if (emplColl != null && !emplColl.isEmpty()) {
            final int emplCollSize = emplColl.size();
            APP_IN_SELFE_Cargo emplCargo = null;
            for (int i = 0; i < emplCollSize; i++) {
                emplCargo = emplColl.getCargo(i);
                if (emplCargo.getSrc_app_ind().equals(recordIndicator)) {
                    return emplColl.getCargo(i);
                }
            }

        }

            FwLogger.log(this.getClass(), FwLogger.Level.INFO,
    				"JobIncomeEJBBean.splitEmplColl() - END , Time Taken : \"\r\n"
    						+ "					+ (System.currentTimeMillis() - startTime)\r\n"
    						+ "					+ \" milliseconds");
			return null;
            
		} catch (final Exception e) {
			throw e;
		} 
		
	}

	/**
	 * This method checks for warning messages that has been already displayed
	 * in the jsp.
	 *
	 * @author govinpr
	 * @param reqWarningMsg the req warning msg
	 * @param messageList            gov.state.nextgen.framework.management.messages.FwMessageList
	 * @return messageFlag boolean
	 */
	public boolean checkForWarningMesgs(final String reqWarningMsg,
			final FwMessageList messageList) {
		 FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AppSessionBean::checkForWarningMesgs::Start");
		try {
			// Code to check for Warning Messages
			boolean noValidation = false;
			if ((reqWarningMsg != null) && (reqWarningMsg.trim().length() > 0)) {
				// Check if the new warning messages are same as or subset of
				// previous, don't display validations.
				int messageListSize = createMsgList(messageList);
				final List warningMsgList = new ArrayList();
				// Collecting warning message in a list. Return false, if the
				// message list has other than warning message
				if(messageList != null && messageListSize>0){
				for (int i = 0; i < messageListSize; i++) {
					if (AppConstants.WARNING.equals(messageList
							.getMessageAtIndex(i).getMessageSeverity())) {
						warningMsgList.add(messageList.getMessageAtIndex(i)
								.getMessageCode());
					} else {
						return noValidation;
					}
				}
			}
				// Tokenizing the request warrning message and putting into a
				// list
				noValidation = validateWarningMsgList(reqWarningMsg, noValidation, warningMsgList);
			}
			 FwLogger.log(this.getClass(), FwLogger.Level.INFO, "AppSessionBean::checkForWarningMesgs::End");
			return noValidation;
		} catch(FwException fe){
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
            throw fe;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        } 
		
		}

	private int createMsgList(final FwMessageList messageList) {
		int messageListSize = 0;
		try {
		if (messageList != null) {
			messageListSize = messageList.getMessageListSize();
		}
		return messageListSize;
		} catch (final Exception e) {
			throw e;
		}
	}

	private boolean validateWarningMsgList(final String reqWarningMsg, boolean noValidation,
			final List warningMsgList) {
		try {
		final StringTokenizer tokenizer = new StringTokenizer(
				reqWarningMsg, FinancialInfoConstants.TILDE);
		final List reqMsgList = new ArrayList();
		while (tokenizer.hasMoreElements()) {
			reqMsgList.add(tokenizer.nextElement());
		}
		final int warningMsgListSize = warningMsgList.size();
		final int reqMsgListSize = reqMsgList.size();
		// Check whether the message list has any warning message that
		// has been already displayed, if so return true
		for (int r = 0; r < reqMsgListSize; r++) {
			final String msgStr = reqMsgList.get(r).toString();
			for (int w = 0; w < warningMsgListSize; w++) {
				final String warMsgStr = warningMsgList.get(w)
						.toString();
				if (warMsgStr.equals(msgStr)) {
					noValidation = true;
					break;
				}
				if (noValidation) {
					break;
				}
			}
		}
		return noValidation;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	/**
	 * Check back to my access selected.
	 *
	 * @author Surendra Nath
	 * @param request the request
	 * @return boolean
	 */
	public boolean checkBackToMyAccessSelected(final Map request) {

		try {
			if (request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON) == null) {
				return false;
			}
			final String reqWarningMsgs = (String) request
					.get(FwConstants.WARNING_MSG_DETAILS);
			if ((reqWarningMsgs != null)
					&& (reqWarningMsgs.trim().length() > 0)) {
				// Tokenizing the request warrning message and putting into a
				// list
				final StringTokenizer tokenizer = new StringTokenizer(
						reqWarningMsgs, FinancialInfoConstants.TILDE);
				final List reqMsgList = new ArrayList();
				while (tokenizer.hasMoreElements()) {
					reqMsgList.add(tokenizer.nextElement());
				}
				if (reqMsgList.contains(FinancialInfoConstants.MSG_30075)) {
					return true;
				}
			}
			final FwMessageList messageList = new FwMessageList();
			final FwMessage message = new FwMessage();
			message.addMessageCode(FinancialInfoConstants.MSG_30075);
			messageList.addMessageToList(message);
			request.put(FwConstants.MESSAGE_LIST, messageList);
			return true;
		} catch(FwException fe){
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
            throw fe;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        } 
	
	}
	
	
	/**
	 * 
	 * Setting default values.
	 *
	 * @param tempCargo the temp cargo
	 * @return the AP p_ i n_ emp l_ a_ wag e_ cargo
	 * 
	 * 
	 */
	public APP_IN_EMPL_A_WAGE_Cargo settingDefaultValues(final APP_IN_EMPL_A_WAGE_Cargo tempCargo) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean.settingDefaultValues() - START");
		try {
			// indicator logic
			setDefaultValues(tempCargo);
			if ((tempCargo.getAdtl_pay_amt() == null
					|| FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_pay_amt().toString().trim()))
					&& (tempCargo.getAdtl_hrs_qty() == null
							|| FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_hrs_qty().toString().trim()))) {
				tempCargo.setAdtl_pay_ind(FinancialInfoConstants.FOURE_DOUBLE);
			}
			
			if (tempCargo.getAdtl_hrs_qty() == null
					|| FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_hrs_qty().toString().trim())) {
				tempCargo.setAdtl_hrs_qty(null);
			}
			if (tempCargo.getAdtl_pay_amt() == null
					|| FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_pay_amt().toString().trim())) {
				tempCargo.setAdtl_pay_amt(null);
			}
			if (tempCargo.getAdtl_pay_typ() == null
					|| FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_pay_typ().trim())
					|| AppConstants.SELECT_DEFAULT_OPTION.equals(tempCargo.getAdtl_pay_typ().trim())) {
				tempCargo.setAdtl_pay_typ(FwConstants.EMPTY_STRING);
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean.settingDefaultValues() - END"
					+ (System.currentTimeMillis() - startTime) + AppConstants.SPACE + AppConstants.MILLISECONDS);

			return tempCargo;
		} catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        } 
		
	}

	private void setDefaultValues(final APP_IN_EMPL_A_WAGE_Cargo tempCargo) {
		try {
		if (tempCargo.getAdtl_pay_amt() != null
				&& !FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_pay_amt().toString().trim())
				&& tempCargo.getAdtl_hrs_qty() != null
				&& !FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_hrs_qty().toString().trim())
				&& (tempCargo.getAdtl_pay_ind() == null || (tempCargo.getAdtl_pay_ind() != null && !FwConstants.ONE.equals(tempCargo.getAdtl_pay_ind().toString().trim())))) {
			tempCargo.setAdtl_pay_ind(FinancialInfoConstants.ZERO_DOUBLE);
		} else if (tempCargo.getAdtl_pay_ind() != null && FwConstants.ONE.equals(tempCargo.getAdtl_pay_ind().toString().trim())) {
			tempCargo.setAdtl_pay_ind(FinancialInfoConstants.ZERO_DOUBLE);
		} else if (tempCargo.getAdtl_pay_amt() != null
				&& !FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_pay_amt().toString().trim())
				&& (tempCargo.getAdtl_hrs_qty() == null
						|| FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_hrs_qty().toString().trim()))) {
			tempCargo.setAdtl_pay_ind(FinancialInfoConstants.TWO_DOUBLE);
		} else if (tempCargo.getAdtl_hrs_qty() != null
				&& !FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_hrs_qty().toString().trim())
				&& (tempCargo.getAdtl_pay_amt() == null
						|| FwConstants.EMPTY_STRING.equals(tempCargo.getAdtl_pay_amt().toString().trim()))) {
			tempCargo.setAdtl_pay_ind(FinancialInfoConstants.THREE_DOUBLE);
		}
		} catch (final Exception e) {
			throw e;
		}
	}
	
	/**
	 * 
	 * 
	 * Split empl wage.
	 *
	 * @param wageColl the wage coll
	 * @param seqNum   the seq num
	 * @return the AP p_ i n_ emp l_ a_ wag e_ cargo
	 * 
	 * 
	 */
	public APP_IN_EMPL_A_WAGE_Cargo splitEmplWage(final APP_IN_EMPL_A_WAGE_Collection wageColl, final Integer seqNum) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RMCJobIncomeEJBBean::splitEmplWage - START");

		try {
			if (wageColl != null) {
				final int collSize = wageColl.size();
				APP_IN_EMPL_A_WAGE_Cargo tempCargo = null;
				for (int i = 0; i < collSize; i++) {
					tempCargo = wageColl.getResult(i);
					if (seqNum.equals(tempCargo.getAdtl_pay_seq_num())) {
						return tempCargo;
					}
				}
			}
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RMCJobIncomeEJBBean.splitEmplWage() - END"
					+ (System.currentTimeMillis() - startTime) + AppConstants.SPACE + AppConstants.MILLISECONDS);

			return null;
			
		} catch (final Exception e) {
			throw e;
		}
		 
		
	}
	
	/**
	 * 
	 * 
	 * Setting default values.
	 *
	 * @param tempCargo the temp cargo
	 * @return the AP p_ i n_ emp l_ a_ wag e_ cargo
	 * 
	 * 
	 */

	public APP_IN_EMPL_Cargo settingDefaultValues(final APP_IN_EMPL_Cargo emplCargo) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeEJBBean.settingDefaultValues() - settingDefaultValues");
		try {
			Date date = new Date(0000 - 00 - 00);
			if (emplCargo != null) {
				// initialize date fields
				if (emplCargo.getEmpl_begin_dt() == null) {
					emplCargo.setEmpl_begin_dt(date);
				}
				if (emplCargo.getEmpl_end_dt() == null) {
					emplCargo.setEmpl_end_dt(date);
				}
				if (emplCargo.getStrike_begin_dt() == null) {
					emplCargo.setStrike_begin_dt(date);
				}
				if (emplCargo.getLast_payck_dt() == null) {
					emplCargo.setLast_payck_dt(date);
				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RMCJobIncomeEJBBean.settingDefaultValues() - END , Time Taken : \"\r\n"
							+ "                        + (System.currentTimeMillis() - startTime)\r\n"
							+ "                        + AppConstants.SPACE + AppConstants.MILLISECONDS");

			return emplCargo;

		}catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        } 
	}
	
	/**
	 * 
	 * 
	 * Split wage coll.
	 *
	 * @param wageColl        the wage coll
	 * @param recordIndicator the record indicator
	 * @return the map
	 * 
	 * 
	 */
	public Map splitWageColl(APP_IN_EMPL_A_WAGE_Collection wageColl, String recordIndicator) {

		final long startTime = System.currentTimeMillis();

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RMCJobIncomeEJBBean.splitWageColl() - START");
		try {
			final Map wageMap = new HashMap();
			if (wageColl != null && !wageColl.isEmpty()) {
				APP_IN_EMPL_A_WAGE_Cargo wageCargo = null;
				final int wageCollSize = wageColl.size();
				String wageRecInd = null;
				String wagePayType = null;
				int adlInd = 0;
				int othInd = 0;

				for (int i = 0; i < wageCollSize; i++) {
					wageCargo = wageColl.getResult(i);
					wageRecInd = wageCargo.getSrc_app_ind();
					// changed code by Anupam for IN-Pre Work
					// added IF condition.Provided Null check before using trim
					if (wageCargo.getAdtl_pay_typ() != null) {
						wagePayType = wageCargo.getAdtl_pay_typ().trim();

						if (recordIndicator.equals(wageRecInd)) {
							validatWagePayType(wageColl, wageMap, wagePayType, i);
							adlInd = validateOverTimeData(wageColl, wageMap, wagePayType, adlInd, i); 
							othInd = validateWagePayType(wageColl, wageMap, wagePayType, othInd, i); 
						}
					}
				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean.splitWageColl() - END"
					+ (System.currentTimeMillis() - startTime) + AppConstants.SPACE + AppConstants.MILLISECONDS);

			return wageMap;
		} catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        } 
		

	}

	private int validateOverTimeData(APP_IN_EMPL_A_WAGE_Collection wageColl, final Map wageMap, String wagePayType,
			int adlInd, int i) {
		if (AppConstants.WAGE_TYPE_OVERTIME.equals(wagePayType)
				|| AppConstants.WAGE_TYPE_WEEKEND.equals(wagePayType)
				|| AppConstants.WAGE_TYPE_HOLIDAY.equals(wagePayType)
				|| AppConstants.WAGE_TYPE_SHITDIFF.equals(wagePayType)
				|| AppConstants.WAGE_TYPE_OTHER.equals(wagePayType)) {
			adlInd = validateOveTime(wageColl, wageMap, adlInd, i);

		}
		return adlInd;
		
	}

	private int validateWagePayType(APP_IN_EMPL_A_WAGE_Collection wageColl, final Map wageMap, String wagePayType,
			int othInd, int i) {
		if ("BON".equals(wagePayType)) {
			wageMap.put("APP_IN_EMPL_A_WAGE_OTH" + ++othInd + CARGO,
					settingDefaultValues(wageColl.getResult(i)));
		} else if (AppConstants.WAGE_TYPE_BONUS.equals(wagePayType)) {
			wageMap.put("APP_IN_EMPL_A_WAGE_OTH" + ++othInd + CARGO,
					settingDefaultValues(wageColl.getResult(i)));
		}
		return othInd;
		
	}

	private int validateOveTime(APP_IN_EMPL_A_WAGE_Collection wageColl, final Map wageMap, int adlInd, int i) {
		wageMap.put("APP_IN_EMPL_A_WAGE_ADL" + ++adlInd + CARGO,
				settingDefaultValues(wageColl.getResult(i)));
		wageMap.put("APP_IN_EMPL_A_WAGE_ADD_Cargo",
				settingDefaultValues(wageColl.getResult(i)));
		return adlInd;
		
	}

	private void validatWagePayType(APP_IN_EMPL_A_WAGE_Collection wageColl, final Map wageMap, String wagePayType,
			int i) {
		if (AppConstants.EMPL_INKIND.equals(wagePayType)) {
			wageMap.put("APP_IN_EMPL_A_WAGE_INKIND_Cargo",
					settingDefaultValues(wageColl.getResult(i)));
		}
		if (AppConstants.WAGE_TYPE_HOURLY.equals(wagePayType)) {
			wageMap.put("APP_IN_EMPL_A_WAGE_HOURLY_Cargo",
					settingDefaultValues(wageColl.getResult(i)));
		} else if (AppConstants.WAGE_TYPE_SALARY.equals(wagePayType)) {
			wageMap.put("APP_IN_EMPL_A_WAGE_SALARY_Cargo",
					settingDefaultValues(wageColl.getResult(i)));
		}
		else if (AppConstants.WAGE_TYPE_JOB.equals(wagePayType)) {
			wageMap.put("APP_IN_EMPL_A_WAGE_JOB_Cargo",
					settingDefaultValues(wageColl.getResult(i)));
		} else if (AppConstants.WAGE_TYPE_ADDITIONAL.equals(wagePayType)) {
			wageMap.put("APP_IN_EMPL_A_WAGE_ADD_Cargo",
					settingDefaultValues(wageColl.getResult(i)));
		}
		
	}
	
	
	
	/**
	 * 
	 * 
	 * Split empl coll.
	 *
	 * @param emplColl        the empl coll
	 * @param recordIndicator the record indicator
	 * @return the AP p_ i n_ emp l_ cargo
	 * 
	 * 
	 */

	public APP_IN_EMPL_Cargo splitEmplColl(final APP_IN_EMPL_Collection emplColl, final String recordIndicator) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean.splitEmplColl() - START");
		try {
			if (emplColl != null && !emplColl.isEmpty()) {
				final int emplCollSize = emplColl.size();
				APP_IN_EMPL_Cargo emplCargo = null;
				for (int i = 0; i < emplCollSize; i++) {
					emplCargo = emplColl.getCargo(i);
					if (emplCargo.getSrc_app_ind().equals(recordIndicator)) {
						return emplColl.getCargo(i);
					}
				}

			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RMCJobIncomeEJBBean.splitEmplColl() - END , Time Taken : \"\r\n"
							+ "                        + (System.currentTimeMillis() - startTime)\r\n"
							+ "                        + AppConstants.SPACE + AppConstants.MILLISECONDS");
			return null;
		
		} catch (final Exception e) {
			throw e;
		}
	}

}
