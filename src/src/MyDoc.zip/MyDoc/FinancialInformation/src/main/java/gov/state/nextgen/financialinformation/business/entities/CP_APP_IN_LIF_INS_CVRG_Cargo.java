/**
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * @author khuskumari
 * Entity class for CP_APP_IN_LIF_INS_CVRG
 *
 */

public class CP_APP_IN_LIF_INS_CVRG_Cargo extends AbstractCargo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String app_num;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	@Id
	private String src_app_ind;
	@Id
	private Integer covered_seq_num;
	private String first_name;
	private String last_name;
	private Integer rec_cplt_ind;
	private Integer covered_indv_seq_num;
	private String adapt_record_id;
	@Transient
	private String fst_nam;

	public String getFst_nam() {
		return fst_nam;
	}

	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}
	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return app_num;
	}
	/**
	 * @param app_num the app_num to set
	 */
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	/**
	 * @return the seq_num
	 */
	public Integer getSeq_num() {
		return seq_num;
	}
	/**
	 * @param seq_num the seq_num to set
	 */
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	/**
	 * @return the covered_seq_num
	 */
	public Integer getCovered_seq_num() {
		return covered_seq_num;
	}
	/**
	 * @param covered_seq_num the covered_seq_num to set
	 */
	public void setCovered_seq_num(Integer covered_seq_num) {
		this.covered_seq_num = covered_seq_num;
	}
	/**
	 * @return the first_name
	 */
	public String getFirst_name() {
		return first_name;
	}
	/**
	 * @param first_name the first_name to set
	 */
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	/**
	 * @return the last_name
	 */
	public String getLast_name() {
		return last_name;
	}
	/**
	 * @param last_name the last_name to set
	 */
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	/**
	 * @return the rec_cplt_ind
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	/**
	 * @param rec_cplt_ind the rec_cplt_ind to set
	 */
	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	/**
	 * @return the covered_indv_seq_num
	 */
	public Integer getCovered_indv_seq_num() {
		return covered_indv_seq_num;
	}
	/**
	 * @param covered_indv_seq_num the covered_indv_seq_num to set
	 */
	public void setCovered_indv_seq_num(Integer covered_indv_seq_num) {
		this.covered_indv_seq_num = covered_indv_seq_num;
	}
	/**
	 * @return the adapt_record_id
	 */
	public String getAdapt_record_id() {
		return adapt_record_id;
	}
	/**
	 * @param adapt_record_id the adapt_record_id to set
	 */
	public void setAdapt_record_id(String adapt_record_id) {
		this.adapt_record_id = adapt_record_id;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((adapt_record_id == null) ? 0 : adapt_record_id.hashCode());
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((covered_indv_seq_num == null) ? 0 : covered_indv_seq_num.hashCode());
		result = prime * result + ((covered_seq_num == null) ? 0 : covered_seq_num.hashCode());
		result = prime * result + ((first_name == null) ? 0 : first_name.hashCode());
		result = prime * result + ((fst_nam == null) ? 0 : fst_nam.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((last_name == null) ? 0 : last_name.hashCode());
		result = prime * result + ((rec_cplt_ind == null) ? 0 : rec_cplt_ind.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}
	
}
