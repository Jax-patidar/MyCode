package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * @author tdatta
 *
 */

@Embeddable
public class APP_IN_SHLTC_Id implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private Integer app_number = null;
	private String seq_num = null;
	private String indv_seq_num = null;
	
	
	public APP_IN_SHLTC_Id() {
	}

	public APP_IN_SHLTC_Id(Integer app_num, String seq_num, String indv_seq_num) {
		super();
		this.app_number = app_num;
		this.seq_num = seq_num;
		this.indv_seq_num = indv_seq_num;
		
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		
		return result;
	}
@SuppressWarnings("squid:S3776")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		APP_IN_SHLTC_Id other = (APP_IN_SHLTC_Id) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		if (seq_num == null) {
			if (other.seq_num != null)
				return false;
		} else if (!seq_num.equals(other.seq_num))
			return false;
		
		return true;
	}

	
}
