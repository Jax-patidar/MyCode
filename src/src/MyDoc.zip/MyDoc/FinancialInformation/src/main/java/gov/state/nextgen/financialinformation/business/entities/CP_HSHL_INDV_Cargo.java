package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(CP_HSHL_INDV_Id.class)
@Table(name = "CP_HSHL_INDV")
public class CP_HSHL_INDV_Cargo extends AbstractCargo implements Serializable {

	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	private Integer hshl_id;
	@Id
	private Integer indv_id;
	
	private String first_name;
	
	private String gndr_cd;
	
	private Integer indv_age;
	

	/**
	 * @return the hshl_id
	 */
	public Integer getHshl_id() {
		return hshl_id;
	}

	/**
	 * @param hshl_id the hshl_id to set
	 */
	public void setHshl_id(Integer hshl_id) {
		this.hshl_id = hshl_id;
	}

	/**
	 * @return the indv_id
	 */
	public Integer getIndv_id() {
		return indv_id;
	}

	/**
	 * @param indv_id the indv_id to set
	 */
	public void setIndv_id(Integer indv_id) {
		this.indv_id = indv_id;
	}

	/**
	 * @return the first_name
	 */
	public String getFirst_name() {
		return first_name;
	}

	/**
	 * @param first_name the first_name to set
	 */
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	/**
	 * @return the gndr_cd
	 */
	public String getGndr_cd() {
		return gndr_cd;
	}

	/**
	 * @param gndr_cd the gndr_cd to set
	 */
	public void setGndr_cd(String gndr_cd) {
		this.gndr_cd = gndr_cd;
	}

	/**
	 * @return the indv_age
	 */
	public Integer getIndv_age() {
		return indv_age;
	}

	/**
	 * @param indv_age the indv_age to set
	 */
	public void setIndv_age(Integer indv_age) {
		this.indv_age = indv_age;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((first_name == null) ? 0 : first_name.hashCode());
		result = prime * result + ((gndr_cd == null) ? 0 : gndr_cd.hashCode());
		result = prime * result + ((hshl_id == null) ? 0 : hshl_id.hashCode());
		result = prime * result + ((indv_age == null) ? 0 : indv_age.hashCode());
		result = prime * result + ((indv_id == null) ? 0 : indv_id.hashCode());
		return result;
	}

	

}