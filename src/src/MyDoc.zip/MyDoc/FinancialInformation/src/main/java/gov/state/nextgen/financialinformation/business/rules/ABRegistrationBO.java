package gov.state.nextgen.financialinformation.business.rules;

import java.util.Map;

public class ABRegistrationBO {

	public Map loadRegistrationInformation() {
		// TODO Auto-generated method stub
		return null;
	}

}
