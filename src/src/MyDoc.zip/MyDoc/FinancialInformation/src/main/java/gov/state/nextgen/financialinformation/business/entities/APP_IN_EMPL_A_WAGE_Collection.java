/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class acts as a wrapper for one or many cargos of APP_IN_EMPL_A_WAGE
 *
 * @author Architecture Team
 * Creation Date Thu Jun 08 08:12:58 CDT 2006 Modified By: Modified on: PCR#
 */
public class APP_IN_EMPL_A_WAGE_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_IN_EMPL_A_WAGE";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_EMPL_A_WAGE_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Returns an abstract cargo.
	 */
	public AbstractCargo getAbstractCargo() {
		return (AbstractCargo) get(0);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_EMPL_A_WAGE_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_EMPL_A_WAGE_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_EMPL_A_WAGE_Cargo[] getResults() {
		final APP_IN_EMPL_A_WAGE_Cargo[] cbArray = new APP_IN_EMPL_A_WAGE_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_EMPL_A_WAGE_Cargo getCargo(final int idx) {
		return (APP_IN_EMPL_A_WAGE_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_EMPL_A_WAGE_Cargo[] cloneResults() {
		final APP_IN_EMPL_A_WAGE_Cargo[] rescargo = new APP_IN_EMPL_A_WAGE_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_EMPL_A_WAGE_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_EMPL_A_WAGE_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setEmpl_seq_num(cargo.getEmpl_seq_num());
			rescargo[i].setAdtl_pay_seq_num(cargo.getAdtl_pay_seq_num());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setAdtl_hrs_qty(cargo.getAdtl_hrs_qty());
			rescargo[i].setAdtl_pay_amt(cargo.getAdtl_pay_amt());
			rescargo[i].setAdtl_pay_ind(cargo.getAdtl_pay_ind());
			rescargo[i].setAdtl_pay_typ(cargo.getAdtl_pay_typ());
			rescargo[i].setAdtl_pay_freq_cd(cargo.getAdtl_pay_freq_cd());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_EMPL_A_WAGE_Cargo[]) {
			final APP_IN_EMPL_A_WAGE_Cargo[] cbArray = (APP_IN_EMPL_A_WAGE_Cargo[]) obj;
			setResults(cbArray);
		}
	}

	/**
	 * Sets the cargo object to the collection.
	 */
	public void setAbstractCargo(final AbstractCargo aCargo) {
		if (size() == 0) {
			add(aCargo);
		} else {
			set(0, aCargo);
		}
	}

	/**
	 * Returns a particular cargo.
	 *
	 * Creation Date Fri Feb 10 10:12:39 CST 2006
	 * @return
	 *         gov.state.nextgen.access.business.entities.APP_IN_EMPL_A_WAGE_Collection
	 */
	public APP_IN_EMPL_A_WAGE_Cargo getResult(final int idx) {
		return (APP_IN_EMPL_A_WAGE_Cargo) get(idx);
	}
}