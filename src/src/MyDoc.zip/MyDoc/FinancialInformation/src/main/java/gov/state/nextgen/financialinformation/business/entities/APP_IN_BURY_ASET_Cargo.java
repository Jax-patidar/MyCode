/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.util.Date;

import javax.persistence.Id;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * This java bean contains the entities of APP_IN_BURY_ASET
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Tue Feb 13 10:24:43 CST 2007 Modified By: Modified on: PCR#
 */

public class APP_IN_BURY_ASET_Cargo extends AbstractCargo implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private String app_num;
	private String ecp_id;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	private Double bury_aset_amt;
	private Integer bury_aset_amt_ind;
	private String bury_aset_rlt_cd;
	@Id
	private String bury_aset_typ;
	private Integer for_indv_seq_num;
	private Integer rec_cplt_ind;
	// EDSP - Starts
	private String bury_asset_institution_name;
	private String bury_asset_l1_addr;
	private String bury_asset_city_addr;
	private String bury_asset_state_addr;
	private String bury_asset_zip5_addr;
	private Double bury_asset_owe_amt;
	private Date acquired_dt;
	private String jnt_own_resp;
	private Date asset_end_dt;
	private String src_app_ind;
	@Transient
	private String loopingQuestion;
	private String burial_resource_type;

	private Date chg_dt;
	
	/**
     * @return the chg_dt
     */
    public Date getChg_dt() {
        return chg_dt;
    }

    /**
     * @param chg_dt the chg_dt to set
     */
    public void setChg_dt(Date chg_dt) {
        this.chg_dt = chg_dt;
    }
	/**
	 * @return the ecp_id
	 */
	public String getEcp_id() {
		return ecp_id;
	}

	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(final String ecp_id) {
		this.ecp_id = ecp_id;
	}

	/**
	 * @return the burial_resource_type
	 */
	public String getBurial_resource_type() {
		return burial_resource_type;
	}

	/**
	 * @param burial_resource_type the burial_resource_type to set
	 */
	public void setBurial_resource_type(final String burial_resource_type) {
		this.burial_resource_type = burial_resource_type;
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * sets the chg_eff_dt value.
	 */
	public void setChg_eff_dt(final Date asset_end_dt) {
		this.asset_end_dt = asset_end_dt;
	}

	/**
	 * returns the chg_eff_dt value.
	 */
	public Date getChg_eff_dt() {
		return asset_end_dt;
	}

	// EDSP - Ends

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return app_num;
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_num = app_num;
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * returns the bury_aset_amt value.
	 */
	public Double getBury_aset_amt() {
		return bury_aset_amt;
	}

	/**
	 * sets the bury_aset_amt value.
	 */
	public void setBury_aset_amt(final Double bury_aset_amt) {
		this.bury_aset_amt = bury_aset_amt;
	}

	/**
	 * returns the bury_aset_amt_ind value.
	 */
	public Integer getBury_aset_amt_ind() {
		return bury_aset_amt_ind;
	}

	/**
	 * sets the bury_aset_amt_ind value.
	 */
	public void setBury_aset_amt_ind(final Integer bury_aset_amt_ind) {
		this.bury_aset_amt_ind = bury_aset_amt_ind;
	}

	/**
	 * returns the bury_aset_rlt_cd value.
	 */
	public String getBury_aset_rlt_cd() {
		return bury_aset_rlt_cd;
	}

	/**
	 * sets the bury_aset_rlt_cd value.
	 */
	public void setBury_aset_rlt_cd(final String bury_aset_rlt_cd) {
		this.bury_aset_rlt_cd = bury_aset_rlt_cd;
	}

	/**
	 * returns the bury_aset_typ value.
	 */
	public String getBury_aset_typ() {
		return bury_aset_typ;
	}

	/**
	 * sets the bury_aset_typ value.
	 */
	public void setBury_aset_typ(final String bury_aset_typ) {
		this.bury_aset_typ = bury_aset_typ;
	}

	/**
	 * returns the for_indv_seq_num value.
	 */
	public Integer getFor_indv_seq_num() {
		return for_indv_seq_num;
	}

	/**
	 * sets the for_indv_seq_num value.
	 */
	public void setFor_indv_seq_num(final Integer for_indv_seq_num) {
		this.for_indv_seq_num = for_indv_seq_num;
	}

	/**
	 * returns the rec_cplt_ind value.
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * sets the rec_cplt_ind value.
	 */
	public void setRec_cplt_ind(final Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * returns the bury_asset_institution_name value.
	 */
	public String getBury_asset_institution_name() {
		return bury_asset_institution_name;
	}

	/**
	 * sets the bury_asset_institution_name value.
	 */
	public void setBury_asset_institution_name(final String bury_asset_institution_name) {
		this.bury_asset_institution_name = bury_asset_institution_name;
	}

	/**
	 * returns the bury_asset_l1_addr value.
	 */
	public String getBury_asset_l1_addr() {
		return bury_asset_l1_addr;
	}

	/**
	 * sets the bury_asset_l1_addr value.
	 */
	public void setBury_asset_l1_addr(final String bury_asset_l1_addr) {
		this.bury_asset_l1_addr = bury_asset_l1_addr;
	}

	/**
	 * returns the bury_asset_city_addr value.
	 */
	public String getBury_asset_city_addr() {
		return bury_asset_city_addr;
	}

	/**
	 * sets the bury_asset_city_addr value.
	 */
	public void setBury_asset_city_addr(final String bury_asset_city_addr) {
		this.bury_asset_city_addr = bury_asset_city_addr;
	}

	/**
	 * returns the bury_asset_state_addr value.
	 */
	public String getBury_asset_state_addr() {
		return bury_asset_state_addr;
	}

	/**
	 * sets the bury_asset_state_addr value.
	 */
	public void setBury_asset_state_addr(final String bury_asset_state_addr) {
		this.bury_asset_state_addr = bury_asset_state_addr;
	}

	/**
	 * returns the bury_asset_zip5_addr value.
	 */
	public String getBury_asset_zip5_addr() {
		return bury_asset_zip5_addr;
	}

	/**
	 * sets the bury_asset_zip5_addr value.
	 */
	public void setBury_asset_zip5_addr(final String bury_asset_zip5_addr) {
		this.bury_asset_zip5_addr = bury_asset_zip5_addr;
	}

	/**
	 * returns the bury_asset_owe_amt value.
	 */
	public Double getBury_asset_owe_amt() {
		return bury_asset_owe_amt;
	}

	/**
	 * sets the bury_asset_owe_amt value.
	 */
	public void setBury_asset_owe_amt(final Double bury_asset_owe_amt) {
		this.bury_asset_owe_amt = bury_asset_owe_amt;
	}

	/**
	 * returns the acquired_dt value.
	 */
	public Date getAcquired_dt() {
		return acquired_dt;
	}

	/**
	 * sets the acquired_dt value.
	 */
	public void setAcquired_dt(final Date acquired_dt) {
		this.acquired_dt = acquired_dt;
	}

	/**
	 * returns the jnt_own_resp value.
	 */
	public String getJnt_own_resp() {
		return jnt_own_resp;
	}

	/**
	 * sets the jnt_own_resp value.
	 */
	public void setJnt_own_resp(final String jnt_own_resp) {
		this.jnt_own_resp = jnt_own_resp;
	}

	/**
	 * @return the loopingQuestion
	 */
	public String getLoopingQuestion() {
		return loopingQuestion;
	}

	/**
	 * @param loopingQuestion
	 *            the loopingQuestion to set
	 */
	public void setLoopingQuestion(final String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}

	/**
	 * returns the string value of cargo.
	 */
	public String inspectCargo() {
		return new StringBuilder().append("APP_IN_BURY_ASET: ").append("app_num=").append(app_num).append("ecp_id=").append(ecp_id)
				.append("indv_seq_num=").append(indv_seq_num).append("seq_num=").append(seq_num).append("bury_aset_amt=").append(bury_aset_amt)
				.append("bury_aset_amt_ind=").append(bury_aset_amt_ind).append("bury_aset_rlt_cd=").append(bury_aset_rlt_cd).append("bury_aset_typ=")
				.append(bury_aset_typ).append("for_indv_seq_num=").append(for_indv_seq_num).append("rec_cplt_ind=").append(rec_cplt_ind).append("chg_dt=").append(chg_dt).toString();
	}


	

}