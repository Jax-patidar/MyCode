/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.AbstractCollection;

public class CP_APP_IN_UTILC_Custom_Collection extends AbstractCollection {

	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.base.APP_IN_UTILC";

	/**
	 * Adds the new cargo to this collection.
	 *
	 * @param newCargo
	 */
	public void addCargo(final CP_APP_IN_UTILC_Custom_Cargo newCargo) {
		add(newCargo);
	}

	/**
	 * Returns the package name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	public CP_APP_IN_UTILC_Custom_Cargo getCargo(final int idx) {
		if (size() < idx) {
			return null;
		} else {
			return (CP_APP_IN_UTILC_Custom_Cargo) get(idx);
		}
	}

	/**
	 * Returns cargo.
	 *
	 * @return
	 */
	public CP_APP_IN_UTILC_Custom_Cargo getCargo() {
		if (size() == 0) {
			add(new CP_APP_IN_UTILC_Custom_Cargo());
		}
		return (CP_APP_IN_UTILC_Custom_Cargo) get(0);
	}

	/**
	 * Sets cargo values.
	 *
	 * @param newCargo
	 */
	public void setCargo(final CP_APP_IN_UTILC_Custom_Cargo newCargo) {
		if (size() == 0) {
			add(newCargo);
		} else {
			set(0, newCargo);
		}
	}

	/**
	 * Returns an abstract cargo.
	 *
	 * @return
	 */
	public AbstractCargo getAbstractCargo() {
		return getCargo();
	}

	/**
	 * Sets abstract cargo.
	 *
	 * @param cargo
	 */
	public void setAbstractCargo(final AbstractCargo cargo) {
		setCargo((CP_APP_IN_UTILC_Custom_Cargo) cargo);
	}

	/**
	 * Sets cargo array into collection.
	 *
	 * @param cbArray
	 */
	public void setResults(final CP_APP_IN_UTILC_Custom_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets the cargo at specified index
	 *
	 * @param idx
	 * @param cb
	 */
	public void setResults(final int idx, final CP_APP_IN_UTILC_Custom_Cargo cb) {
		set(idx, cb);
	}

	/**
	 * Sets generic result
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_APP_IN_UTILC_Custom_Cargo[]) {
			final CP_APP_IN_UTILC_Custom_Cargo[] cbArray = (CP_APP_IN_UTILC_Custom_Cargo[]) obj;
			for (int i = 0; i < cbArray.length; i++) {
				add(cbArray[i]);
			}
		}
	}

	/**
	 * returns cargo array
	 *
	 * @return cargo array
	 */
	public CP_APP_IN_UTILC_Custom_Cargo[] getResults() {
		final CP_APP_IN_UTILC_Custom_Cargo[] cbArray = new CP_APP_IN_UTILC_Custom_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * Returns a particular cargo.
	 *
	 * @param idx
	 * @return CP_APP_IN_UTILC_Custom_Cargo
	 */
	public CP_APP_IN_UTILC_Custom_Cargo getResult(final int idx) {
		return (CP_APP_IN_UTILC_Custom_Cargo) get(idx);
	}

	/**
	 * Returns size of a collection.
	 *
	 * @return collection size
	 */
	public int getResultsSize() {
		return size();
	}

	/**
	 * This one for clone Results
	 *
	 * @return array of cargos
	 */
	public CP_APP_IN_UTILC_Custom_Cargo[] cloneResults() {
		final CP_APP_IN_UTILC_Custom_Cargo[] rescargo = new CP_APP_IN_UTILC_Custom_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_APP_IN_UTILC_Custom_Cargo cargo = getResult(i);
			rescargo[i] = new CP_APP_IN_UTILC_Custom_Cargo();
			rescargo[i].setApplicationNumber(cargo.getApplicationNumber());
			rescargo[i].setIndivdiualSequenceNumber(cargo.getIndivdiualSequenceNumber());
			rescargo[i].setElectricityMonthlyAmount(cargo.getElectricityMonthlyAmount());
			rescargo[i].setGasMonthlyAmount(cargo.getGasMonthlyAmount());
			rescargo[i].setKerosineMonthlyAmount(cargo.getKerosineMonthlyAmount());
			rescargo[i].setCoalMonthlyAmount(cargo.getCoalMonthlyAmount());
			rescargo[i].setDisasterMonthlyAmount(cargo.getDisasterMonthlyAmount());
			rescargo[i].setOilMonthlyAmount(cargo.getOilMonthlyAmount());
			rescargo[i].setWoodMonthlyAmount(cargo.getWoodMonthlyAmount());
			rescargo[i].setWaterMonthlyAmount(cargo.getWaterMonthlyAmount());
			rescargo[i].setGarbageMonthlyAmount(cargo.getGarbageMonthlyAmount());
			rescargo[i].setInstallationMonthlyAmount(cargo.getInstallationMonthlyAmount());
			rescargo[i].setTelephoneMonthlyAmount(cargo.getTelephoneMonthlyAmount());
			rescargo[i].setOtherMonthlyAmount(cargo.getOtherMonthlyAmount());
			rescargo[i].setOther2MonthlyAmount(cargo.getOther2MonthlyAmount());
			rescargo[i].setOther3MonthlyAmount(cargo.getOther3MonthlyAmount());
			rescargo[i].setUtil_electric_resp(cargo.getUtil_electric_resp());
			rescargo[i].setUtil_sewage_resp(cargo.getUtil_sewage_resp());
			rescargo[i].setUtil_garbage_resp(cargo.getUtil_garbage_resp());
			rescargo[i].setUtil_phone_resp(cargo.getUtil_phone_resp());
			rescargo[i].setUtil_gas_resp(cargo.getUtil_gas_resp());
			rescargo[i].setUtil_water_resp(cargo.getUtil_water_resp());
			rescargo[i].setUtil_fuel_resp(cargo.getUtil_fuel_resp());
			rescargo[i].setMo_hsld_pay_amt(cargo.getMo_hsld_pay_amt());
			rescargo[i].setUtil_total_amt(cargo.getUtil_total_amt());

		}
		return rescargo;
	}

}
