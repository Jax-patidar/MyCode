package gov.state.nextgen.financialinformation.business.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.configuration.FwPageActionDetails;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_BURY_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_BURY_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_P_PROP_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_P_PROP_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_R_PROP_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_R_PROP_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SPS_IMPOV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SPS_IMPOV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_VEH_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_VEH_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_RGST_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_RGST_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_INDV_ADDI_INFO_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_INDV_ADDI_INFO_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_ASET_XFER_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_ASET_XFER_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Collection;
import gov.state.nextgen.financialinformation.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.financialinformation.business.entities.NO_ONE_Collection;
import gov.state.nextgen.financialinformation.business.rules.ABHousingTypeBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherReourcesTypeBO;
import gov.state.nextgen.financialinformation.business.rules.BurialAssetBO;
import gov.state.nextgen.financialinformation.business.rules.ExpenseSummaryBO;
import gov.state.nextgen.financialinformation.business.rules.FinancialAssetsBO;
import gov.state.nextgen.financialinformation.business.rules.LiquidAssetBO;
import gov.state.nextgen.financialinformation.business.rules.OtherAssetBO;
import gov.state.nextgen.financialinformation.business.rules.RealPropertyBO;
import gov.state.nextgen.financialinformation.business.rules.VehicleAssetBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInJntOwnRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInPPropAssetRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInRealPropertyRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInSpsRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInVehAssetRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppRgstRepository;
import gov.state.nextgen.framework.business.model.IndividualCategorySequenceDetails;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.framework.business.model.UserDetails;

@SuppressWarnings("squid:S2229")
@Service("FinancialAssetsService")
public class FinancialAssetsServImpl implements FinancialServInterface {

	@Autowired
	private FinancialAssetsBO financialAssetsBO;

	@Autowired
	private VehicleAssetBO vehicleAssetBO;

	@Autowired
	ExpenseSummaryBO expenseSummaryBO;

	@Autowired
	ABHousingTypeBO housingTypeBO;

	@Autowired
	private RealPropertyBO aBRealPropertyDetailsBO;

	@Autowired
	private BurialAssetBO burialAsetBO;

	@Autowired
	private OtherAssetBO otherResourDetailsBO;

	@Autowired
	private ABOtherReourcesTypeBO abResTypeBO;

	@Autowired
	private LiquidAssetBO liquidAssetBO;

	@Autowired
	private RealPropertyBO realPropBo;

	@Autowired
	private AppInRealPropertyRepository appInRealPropertyRepository;

	@Autowired
	private AppInJntOwnRepository appInJntOwnRepository;

	private AppInSpsRepository appInSpsRepository;

	@Autowired
	private AppInPPropAssetRepository appInPPropAssetRepository;
	
	@Autowired
	private AppInVehAssetRepository appInVehAssetRepository;

	private CpAppRgstRepository cpAppRgstRepository;

	@Autowired
	private RestTemplate restTemplate;

	/** The Constant APP_IN_VEH_ASET_COLLECTION. */

	/** The Constant LOOPING_QUESTION. */
	private static final String LOOPING_QUESTION = "loopingQuestion";

	private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

	private static final String APP_IN_P_PROP_ASET_COLL = "APP_IN_P_PROP_ASET_Collection";

	private static final String APP_IN_JNT_OWN_COLLECTION = "APP_IN_JNT_OWN_COLLECTION";

	private static final String APP_IN_BURY_ASET_COLL = "APP_IN_BURY_ASET_Collection";

	private static final String ABVATLOAAD = "ABVATLoad";

	private static final String INDV_ID = "indvIds";

	private static final String GROSS_INC = "gross_income";

	private static final String STORE_VEHICLE_ASSET_DETAILS_ERROR = "Error occured in FinancialAssetsServImpl.storeVehicleAssetDetails()";
	
	private static final String GET_VEHICLE_ASSET_DETAILS_ERROR = "Error occured in FinancialAssetsServImpl.getVehicleAssetDetails()";
	
	private static final String INDV_IDS = "indvIds";
	
	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {

		switch (methodName) {

		case FinancialInfoConstants.GET_VEHI_ASSET_DET:
			this.getVehicleAssetDetails(txnBean);
			break;

		case FinancialInfoConstants.STORE_VEHI_ASSET_DET:
			this.storeVehicleAssetDetails(txnBean);
			break;

		case FinancialInfoConstants.GET_REAL_PROP_TYPE:
			this.getRealPropertyType(txnBean);
			break;

		case FinancialInfoConstants.STORE_REAL_PROP_TYPE:
			this.storeRealPropertyType(txnBean);
			break;

		case FinancialInfoConstants.GET_REAL_PROP_DET:
			this.getRealPropertyDetails(txnBean);
			break;

		case FinancialInfoConstants.STORE_REAL_PROP_DET:
			this.storeRealPropertyDetails(txnBean);
			break;

		case FinancialInfoConstants.GET_BUR_ASS_DET:
			this.getBurialAssetDetails(txnBean);
			break;

		case FinancialInfoConstants.STORE_BURI_ASS_DET:
			this.storeBurialAssetDetails(txnBean);
			break;

		case FinancialInfoConstants.GET_OTHER_RES_DET:
			this.getOtherResourceDetails(txnBean);
			break;

		case FinancialInfoConstants.STORE_OTHER_RES_DET:
			this.storeOtherResourceDetails(txnBean);
			break;

		case FinancialInfoConstants.GET_THER_RES_TYPE:
			this.getOtherResourceType(txnBean);
			break;

		case FinancialInfoConstants.GET_AFBASSETSUMM_DET:
			this.getAFBAssetSummaryDetails(txnBean);
			break;

		case FinancialInfoConstants.GET_ASSE_INC_DET:
			this.getAssetAndIncomeDetails(txnBean);
			break;

		case FinancialInfoConstants.STR_ASS_OWN_PROP_DET:
			this.storeAssetsOwnPropertyDetails(txnBean);
			break;

		case FinancialInfoConstants.LOAD_ASS_OWN_PROP_DET:
			this.loadAssetsOwnPropertyDetails(txnBean);
			break;

		case FinancialInfoConstants.REMOVE_ASS_OWN_PROP_DET:
			this.removeAssetsOwnPropertyDetails(txnBean);
			break;

		case FinancialInfoConstants.GET_AFBASS_SUMM:
			this.getAFBAssetSummary(txnBean);
			break;

		case FinancialInfoConstants.STORE_AFB_INFO:
			this.storeAFBAssetInfo(txnBean);
			break;

		case FinancialInfoConstants.DEL_AFB_INFO:
			this.deleteAFBAssetInfo(txnBean);
			break;

		case FinancialInfoConstants.STORE_PP_DET:
			this.storePersonalPropertyDetails(txnBean);
			break;

		case FinancialInfoConstants.STORE_PERSONAL_PROPERTY_DETAILS_RC:
			this.storePersonalPropertyDetailsRC(txnBean);
			break;

		case FinancialInfoConstants.LOAD_PP_DET:

			this.loadPersonalPropertyDetails(txnBean);
			break;

		case FinancialInfoConstants.REMOVE_PP_DET:
			this.removePersonalPropertyDetails(txnBean);
			break;

		case FinancialInfoConstants.LOAD_PP_INFO:
			this.loadPersonalPropertyInfo(txnBean);
			break;

		case FinancialInfoConstants.GETASSSUM_DET:
			this.getAssetSummaryDetails(txnBean);
			break;
		case FinancialInfoConstants.GET_ASSET_VEHICLE_PROPERTY_SUMMARY:
			this.getAssetVehiclePropertySummaryDetails(txnBean);
			break;
		case FinancialInfoConstants.STORE_PERSONAL_PROPERTY_DETAILS_MC:
			this.storePersonalPropertyDetailsMC(txnBean);
			break;
		case FinancialInfoConstants.LOAD_PERSONAL_PROPERTY_DETAILS_MC:
			this.loadPersonalPropertyDetailsMC(txnBean);
			break;
		case FinancialInfoConstants.DELETE_PERSONAL_PROPERTY_DETAILS_MC:
			this.deletePersonalPropertyDetailsMC(txnBean);
			break;
		case FinancialInfoConstants.GET_OWN_VEH_SMRY_DETAILS:
			this.getOwnVehicleSummaryDetails(txnBean);
			break;
		default:
			break;

		}

	}

	

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getOtherResourceType(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getOtherResourceType() - START", txnBean);
		try {
			final Map request = txnBean.getRequest();
			loadTypes(txnBean, request.get(FwConstants.CURRENT_PAGE_ID).toString());


		}  catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.getOtherResourceType()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_THER_RES_TYPE,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getOtherResourceType() - END", txnBean);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeOtherResourceDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getOtherResourceType() - START", txnBean);

		try {

			Map pageCollection = txnBean.getPageCollection();

			final APP_IN_P_PROP_ASET_Collection appInShltcCollReq = (APP_IN_P_PROP_ASET_Collection) pageCollection
					.get(APP_IN_P_PROP_ASET_COLL);
			APP_IN_P_PROP_ASET_Cargo shltcCargoReq = new APP_IN_P_PROP_ASET_Cargo();
			if (appInShltcCollReq != null && !appInShltcCollReq.isEmpty()) {
				shltcCargoReq = appInShltcCollReq.getCargo(0);
			}

			// get details joint owner collection
			final APP_IN_JNT_OWN_Collection appInJntOwnColl = (APP_IN_JNT_OWN_Collection) pageCollection
					.get(APP_IN_JNT_OWN_COLLECTION);

			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl = new APP_IN_JNT_OWN_Collection();
			APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo = null;
			if (appInJntOwnColl != null) {
				iterateAndValidateJointOwnCargo(appInJntOwnColl);
			}

			if (shltcCargoReq.isDirty()) {
				otherResourDetailsBO.storeOtherResourcesDetails(appInShltcCollReq);
			}
			// values entered and when the user tries to save the record first
			// time
			if (appInJntOwnColl != null) {
				setJointOwnCargoForOtherResources(shltcCargoReq, appInJntOwnColl, appInJntOwnNewColl,
						appInJntOwnBeforeCargo);
			}

			financialAssetsBO.storeJointOwnerDetails(appInJntOwnNewColl);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.storeOtherResourceDetails:End()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_OTHER_RES_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getOtherResourceType() - END", txnBean);
	}
	@SuppressWarnings("squid:S3776")
	private void setJointOwnCargoForOtherResources(APP_IN_P_PROP_ASET_Cargo shltcCargoReq,
			final APP_IN_JNT_OWN_Collection appInJntOwnColl, final APP_IN_JNT_OWN_Collection appInJntOwnNewColl,
			APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointOwnCargoForOtherResources() - START");
			APP_IN_JNT_OWN_Cargo appInJntOwnCargo;
			final int appInJntCollSize = appInJntOwnColl.size();
			for (int i = 0; i < appInJntCollSize; i++) {
				appInJntOwnCargo = appInJntOwnColl.getCargo(i);

				if (appInJntOwnBeforeCargo == null) {
					setSeqNumbersForJointCargo(shltcCargoReq, appInJntOwnCargo);
					appInJntOwnCargo.setAset_sub_typ(shltcCargoReq.getPrsn_prop_aset_typ());
					appInJntOwnCargo.setAset_typ(AppConstants.JOINT_OWNER_OTHER_RESOURCES);
					if (appInJntOwnCargo.getJnt_own_fst_nam() == null) {
						appInJntOwnCargo.setJnt_own_fst_nam(FwConstants.SPACE);
					}
					if (appInJntOwnCargo.getJnt_own_last_nam() == null) {
						appInJntOwnCargo.setJnt_own_last_nam(FwConstants.SPACE);
					}
					if (appInJntOwnCargo.getOtsd_ind() == null) {
						appInJntOwnCargo.setOtsd_ind(FwConstants.SPACE);
					}
					if (appInJntOwnCargo.getSeq_num() == null) {
						appInJntOwnCargo.setSeq_num(0);
					}
					appInJntOwnCargo.setRowAction(FwConstants.ROWACTION_INSERT);
					appInJntOwnNewColl.add(appInJntOwnCargo);
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointOwnCargoForOtherResources() - END");
	}

	private void setSeqNumbersForJointCargo(APP_IN_P_PROP_ASET_Cargo shltcCargoReq,
			APP_IN_JNT_OWN_Cargo appInJntOwnCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setSeqNumbersForJointCargo() - START");
			appInJntOwnCargo.setApp_num(shltcCargoReq.getApp_num());
			if (shltcCargoReq.getSeq_num() != null && !"".equals(shltcCargoReq.getSeq_num().toString().trim())) {
				appInJntOwnCargo.setJnt_own_seq_num(shltcCargoReq.getSeq_num());
			}
			if (shltcCargoReq.getIndv_seq_num() != null
					&& !"".equals(shltcCargoReq.getIndv_seq_num().toString().trim())) {
				appInJntOwnCargo.setIndv_seq_num(shltcCargoReq.getIndv_seq_num());
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setSeqNumbersForJointCargo() - END");
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getOtherResourceDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getOtherResourceDetails() - START", txnBean);
		try {

			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			final Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());
			final String type = categorySequenceDetails.getCategoryType();

			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {

				pageCollection = new HashMap();
				pageCollection.put(APP_IN_P_PROP_ASET_COLL,
						otherResourDetailsBO.loadOtherAssetDetails(appNum, indvSeqNum, seqNum, type));

			} else {
				pageCollection = new HashMap();

				final APP_IN_P_PROP_ASET_Collection appPropColl = otherResourDetailsBO.loadOtherAssetDetails(appNum,
						indvSeqNum, seqNum, type);

				int sizeColl = 0;
				APP_IN_P_PROP_ASET_Cargo appPropCargo = null;
				if ((appPropColl != null) && (!appPropColl.isEmpty())) {
					sizeColl = appPropColl.size();
				}
				if (sizeColl > 0) {
					appPropCargo = appPropColl.getCargo(sizeColl - 1);
				} else {
					appPropCargo = new APP_IN_P_PROP_ASET_Cargo();
					appPropCargo.setApp_num(appNum);
					appPropCargo.setIndv_seq_num(indvSeqNum);
					appPropCargo.setSeq_num(seqNum);

				}
				final APP_IN_P_PROP_ASET_Collection temp = new APP_IN_P_PROP_ASET_Collection();
				temp.addCargo(appPropCargo);
				pageCollection.put(APP_IN_P_PROP_ASET_COLL, temp);
				txnBean.setPageCollection(pageCollection);
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.getOtherResourceDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_OTHER_RES_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getOtherResourceDetails() - END", txnBean);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeBurialAssetDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.storeBurialAssetDetails() - START", txnBean);
		try {

			final Map request = txnBean.getRequest();
			Map pageCollection = txnBean.getPageCollection();

			final APP_IN_BURY_ASET_Collection appInBuryCollReq = (APP_IN_BURY_ASET_Collection) pageCollection
					.get(APP_IN_BURY_ASET_COLL);
			if (appInBuryCollReq != null && !appInBuryCollReq.isEmpty()) {

				APP_IN_BURY_ASET_Cargo buryCargoReq = appInBuryCollReq.getCargo(0);
				buryCargoReq.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				// PersistData if the cargo is dirty
				burialAsetBO.storeBurialAssetDetails(appInBuryCollReq);
			}

			// get details joint owner collection
			final APP_IN_JNT_OWN_Collection appInJntOwnColl = (APP_IN_JNT_OWN_Collection) pageCollection
					.get(APP_IN_JNT_OWN_COLLECTION);

			String validateLooping = FwConstants.YES;

			String dob = getBirthDateFromPeopleHandler();

			burialAsetBO.validateBurialAssetDetails(appInBuryCollReq, dob, validateLooping);

			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl = new APP_IN_JNT_OWN_Collection();
			APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo = null;
			if (appInJntOwnColl != null) {
				iterateAndValidateJointOwnCargo(appInJntOwnColl);
			}

			// values entered and when the user tries to save the record first
			// time
			if (appInJntOwnColl != null) {
				setJointOwnCargoForBurial(appInJntOwnColl, appInJntOwnNewColl, appInJntOwnBeforeCargo);
			}

			financialAssetsBO.storeJointOwnerDetails(appInJntOwnNewColl);

			// Does LoopingQuestion flag is YES
			if (!((request.get(LOOPING_QUESTION) != null) && FwConstants.YES.equals(request.get(LOOPING_QUESTION)))) {
				boolean detailsFinishedFlag = true;
			}

		}  catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.storeBurialAssetDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_BURI_ASS_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.storeBurialAssetDetails() - END", txnBean);
	}
	@SuppressWarnings("squid:S3776")
	private void setJointOwnCargoForBurial(final APP_IN_JNT_OWN_Collection appInJntOwnColl,
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl, APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointOwnCargoForBurial() - START");
			APP_IN_JNT_OWN_Cargo appInJntOwnCargo;
			final int appInJntCollSize = appInJntOwnColl.size();
			for (int i = 0; i < appInJntCollSize; i++) {
				appInJntOwnCargo = appInJntOwnColl.getCargo(i);

				if (appInJntOwnBeforeCargo == null) {

					appInJntOwnCargo.setAset_typ(AppConstants.JOINT_OWNER_TYPE_BURIAL_ASSET);
					if (appInJntOwnCargo.getJnt_own_fst_nam() == null) {
						appInJntOwnCargo.setJnt_own_fst_nam(FwConstants.SPACE);
					}
					if (appInJntOwnCargo.getJnt_own_last_nam() == null) {
						appInJntOwnCargo.setJnt_own_last_nam(FwConstants.SPACE);
					}
					if (appInJntOwnCargo.getOtsd_ind() == null) {
						appInJntOwnCargo.setOtsd_ind(FwConstants.SPACE);
					}
					if (appInJntOwnCargo.getSeq_num() == null) {
						appInJntOwnCargo.setSeq_num(0);
					}

					appInJntOwnCargo.setRowAction(FwConstants.ROWACTION_INSERT);
					appInJntOwnNewColl.add(appInJntOwnCargo);
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointOwnCargoForBurial() - END");
	}

	private void iterateAndValidateJointOwnCargo(final APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.iterateAndValidateJointOwnCargo() - START");
			int appInJntCollSize = appInJntOwnColl.size();
			APP_IN_JNT_OWN_Cargo jntOwnCargo = null;
			for (int i = 0; i < appInJntCollSize; i++) {
				jntOwnCargo = appInJntOwnColl.getCargo(i);
				if ((jntOwnCargo.getJnt_indv_seq_num() != null)
						&& FwConstants.ZERO.equals(jntOwnCargo.getJnt_indv_seq_num().toString().trim())
						&& ((jntOwnCargo.getJnt_own_fst_nam() == null)
								|| (jntOwnCargo.getJnt_own_fst_nam().trim().length() == 0))
						&& ((jntOwnCargo.getJnt_own_last_nam() == null)
								|| (jntOwnCargo.getJnt_own_last_nam().trim().length() == 0))
						&& ((jntOwnCargo.getOtsd_ind() == null) || (jntOwnCargo.getOtsd_ind().trim().length() == 0))) {
					appInJntOwnColl.remove(i);
					i--;
					appInJntCollSize--;
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.iterateAndValidateJointOwnCargo() - END");
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getBurialAssetDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getBurialAssetDetails() - START", txnBean);
		try {
			final Map request = txnBean.getRequest();
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			final Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			// make loopingQuestion value NO in the request
			request.put(LOOPING_QUESTION, FwConstants.NO);

			// When user hits the Back button or comes from the Summary Page
			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {
				// get burial resource details from burial resource detials
				// table in database

				pageCollection = new HashMap();
				// get Details_Collection from DataBase and set to
				// PageCollection
				pageCollection.put(APP_IN_BURY_ASET_COLL,
						burialAsetBO.loadIndividualBurialAsetDetails(appNum, indvSeqNum, seqNum));
			} else {
				pageCollection = new HashMap();

				final APP_IN_BURY_ASET_Collection appPropColl = burialAsetBO.loadIndividualBurialAsetDetails(appNum,
						indvSeqNum, seqNum);

				int sizeColl = 0;
				APP_IN_BURY_ASET_Cargo buryAsetCargo = null;
				if ((appPropColl != null) && (!appPropColl.isEmpty())) {
					sizeColl = appPropColl.size();
				}
				buryAsetCargo = setBurryAssetCargo(pageCollection, appNum, indvSeqNum, seqNum, appPropColl, sizeColl);

				final APP_IN_BURY_ASET_Collection temp = new APP_IN_BURY_ASET_Collection();
				temp.addCargo(buryAsetCargo);
				pageCollection.put(APP_IN_BURY_ASET_COLL, temp);
				txnBean.setPageCollection(pageCollection);

			}

			INDIVIDUAL_Custom_Collection indivCustCol = null;
			indivCustCol = financialAssetsBO.getRelevantIndividuals();
			pageCollection.put("INDIVIDUAL_CUSTOM_COLLECTION", indivCustCol);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.getBurialAssetDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_BUR_ASS_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getBurialAssetDetails() - END", txnBean);
	}

	private APP_IN_BURY_ASET_Cargo setBurryAssetCargo(Map pageCollection, final String appNum, final Integer indvSeqNum,
			final Integer seqNum, final APP_IN_BURY_ASET_Collection appPropColl, int sizeColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setBurryAssetCargo() - START");
		APP_IN_BURY_ASET_Cargo buryAsetCargo;
		try {
			if (sizeColl > 0) {
				buryAsetCargo = appPropColl.getCargo(sizeColl - 1);

				if (buryAsetCargo.getSeq_num() != null) {
					final APP_IN_JNT_OWN_Collection appInJntCol = financialAssetsBO.loadJointOwnerDetails(appNum,
							indvSeqNum, AppConstants.JOINT_OWNER_TYPE_BURIAL_ASSET, buryAsetCargo.getBury_aset_typ(),
							buryAsetCargo.getSeq_num());
					if ((appInJntCol != null) && (!appInJntCol.isEmpty())) {
						pageCollection.put(APP_IN_BURY_ASET_COLL, appInJntCol);
					}
				}
				// put the Current Individual Sequence Number in the pageCollection

			} else {
				buryAsetCargo = new APP_IN_BURY_ASET_Cargo();
				buryAsetCargo.setApp_num(appNum);
				buryAsetCargo.setIndv_seq_num(indvSeqNum);
				buryAsetCargo.setSeq_num(seqNum);

			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.setBurryAssetCargo()");
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setBurryAssetCargo() - END");
		return buryAsetCargo;
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeRealPropertyDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.storeRealPropertyDetails() - START", txnBean);
		try {

			final Map request = txnBean.getRequest();
			Map<Object, Object> pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			final Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			// get the APP_IN_PRFL Collection from session

			// get Details aset Collection and Cargo
			APP_IN_R_PROP_ASET_Collection appInRPropAsetColl = (APP_IN_R_PROP_ASET_Collection) pageCollection
					.get("APP_IN_R_PROP_ASET_Collection");
			APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo;
			appInRPropAsetCargo = appInRPropAsetColl.getCargo(0);

			// get the Aset collection from Before Collection
			final APP_IN_R_PROP_ASET_Collection appInRPropAsetBeforeColl = appInRealPropertyRepository
					.getByAppNum_IndSeq(Integer.parseInt(appNum), indvSeqNum, seqNum);

			// get details joint owner collection
			final APP_IN_JNT_OWN_Collection appInJntOwnColl = (APP_IN_JNT_OWN_Collection) pageCollection
					.get(APP_IN_JNT_OWN_COLLECTION);

			// get the joint owner collection from before collection
			final APP_IN_JNT_OWN_Collection appInJntBeforeColl = appInJntOwnRepository.getExistingRecord(Integer.parseInt(appNum),
					indvSeqNum);

			appInRPropAsetCargo = setAmountFieldsRProp(pageCollection, appNum, appInRPropAsetCargo,
					appInRPropAsetBeforeColl, appInJntOwnColl);

			final String addrOption = (String) request.get("radioGroup");
			if (addrOption != null) {
				if ("hshlAddr".equals(addrOption)) {
					appInRPropAsetCargo.setProp_adr_ind(FwConstants.ONE);
				} else if ("spsAddr".equals(addrOption)) {
					appInRPropAsetCargo.setProp_adr_ind("2");
				} else if ("othAddr".equals(addrOption)) {
					appInRPropAsetCargo.setProp_adr_ind("3");
				}
			}

			String dob = getBirthDateFromPeopleHandler();
			// TODO: fetch birthDate from people handler
			aBRealPropertyDetailsBO.validateRealPropertyDetails(appInRPropAsetColl, appInRPropAsetBeforeColl, dob,
					request);

			setRPropAssetCargo(appInRPropAsetCargo, addrOption);

			// If we select Household address or the Spousal address option
			// populate here
			if (addrOption != null) {
				setAddressDetailsInCargo(appNum, appInRPropAsetCargo, addrOption);
			}
			// determine if individual is married

			appInRPropAsetColl = aBRealPropertyDetailsBO.storeRealPropertyDetails(appInRPropAsetColl);

			appInRPropAsetCargo = appInRPropAsetColl.getCargo(0);
			APP_IN_JNT_OWN_Cargo appInJntOwnCargo = null;
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl = new APP_IN_JNT_OWN_Collection();
			APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo = null;

			if (appInJntOwnColl != null) {
				iterateJointCargo(appInJntOwnColl);
			}

			// user pressed back and the before collection is not null delete it
			// else update it.
			if (appInJntBeforeColl != null) {
				appInJntOwnBeforeCargo = setJointCargo(appInRPropAsetCargo, appInJntBeforeColl, appInJntOwnCargo,
						appInJntOwnNewColl, appInJntOwnBeforeCargo);
			}
			// values entered and when the user tries to save the record first
			// time
			if (appInJntOwnColl != null) {
				final int appInJntCollSize = appInJntOwnColl.size();
				for (int i = 0; i < appInJntCollSize; i++) {
					appInJntOwnCargo = appInJntOwnColl.getCargo(i);
					if (appInJntOwnBeforeCargo == null) {
						setJointOwnCargo(appInRPropAsetCargo, appInJntOwnCargo, appInJntOwnNewColl);
					}
				}
			}

			financialAssetsBO.storeJointOwnerDetails(appInJntOwnNewColl);

			// Define DetailsFinishedFlag as True

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.storeRealPropertyDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_REAL_PROP_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.storeRealPropertyDetails() - END", txnBean);
	}

	private void iterateJointCargo(final APP_IN_JNT_OWN_Collection appInJntOwnColl) {
			int appInJntCollSize = appInJntOwnColl.size();
			APP_IN_JNT_OWN_Cargo jntOwnCargo = null;
			for (int i = 0; i < appInJntCollSize; i++) {
				jntOwnCargo = appInJntOwnColl.getCargo(i);
				if (FwConstants.YES.equals(jntOwnCargo.getOtsd_ind())) {
					continue;
				}
				if (!FwConstants.YES.equals(jntOwnCargo.getAset_typ())) {
					appInJntOwnColl.remove(i);
					i--;
					appInJntCollSize--;
				}
			}
		
	}

	private APP_IN_R_PROP_ASET_Cargo setAmountFieldsRProp(Map<Object, Object> pageCollection, final String appNum,
			APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo, final APP_IN_R_PROP_ASET_Collection appInRPropAsetBeforeColl,
			final APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setAmountFieldsRProp() - START");
			if ((appInRPropAsetBeforeColl != null) && (!appInRPropAsetBeforeColl.isEmpty())) {
				appInRPropAsetCargo = setRPropFromCollToCargo(appNum, appInRPropAsetCargo, appInRPropAsetBeforeColl,
						appInJntOwnColl);

			}
			if (appInRPropAsetCargo.getProp_fmv_amt_ind() == null) {
				if (null != appInRPropAsetCargo.getProp_fmv_amt()
						&& FwConstants.EMPTY_STRING.equals(appInRPropAsetCargo.getProp_fmv_amt().toString().trim())) {
					appInRPropAsetCargo.setProp_fmv_amt(FinancialInfoConstants.ZERO_DOUBLE);
					appInRPropAsetCargo.setProp_fmv_amt_ind(2);
				} else {
					appInRPropAsetCargo.setProp_fmv_amt_ind(FinancialInfoConstants.ZERO);
				}
			} else {
				if (null != appInRPropAsetCargo.getProp_fmv_amt()
						&& FwConstants.EMPTY_STRING.equals(appInRPropAsetCargo.getProp_fmv_amt().toString().trim())) {
					appInRPropAsetCargo.setProp_fmv_amt(FinancialInfoConstants.ZERO_DOUBLE);
				} else {
					pageCollection.put("AMT_AND_IND_CHECKED", FwConstants.ONE);
				}
			}

			setRPropOweAmt(pageCollection, appInRPropAsetCargo);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setAmountFieldsRProp() - END");
			return appInRPropAsetCargo;
		
	}

	private void setRPropOweAmt(Map<Object, Object> pageCollection, APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setRPropOweAmt() - START");
			if (appInRPropAsetCargo.getProp_owe_amt_ind() == null) {
				if (FwConstants.EMPTY_STRING.equals(appInRPropAsetCargo.getProp_owe_amt().toString().trim())) {
					appInRPropAsetCargo.setProp_owe_amt(FinancialInfoConstants.ZERO_DOUBLE);
					appInRPropAsetCargo.setProp_owe_amt_ind(2);
				} else {
					appInRPropAsetCargo.setProp_owe_amt_ind(FinancialInfoConstants.ZERO);
				}
			} else {
				if (FwConstants.EMPTY_STRING.equals(appInRPropAsetCargo.getProp_owe_amt().toString().trim())) {
					appInRPropAsetCargo.setProp_owe_amt(FinancialInfoConstants.ZERO_DOUBLE);
				} else {
					pageCollection.put("AmtAndIndChecked1", FwConstants.ONE);
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setRPropOweAmt() - END");
	}

	private APP_IN_R_PROP_ASET_Cargo setRPropFromCollToCargo(final String appNum,
			APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo, final APP_IN_R_PROP_ASET_Collection appInRPropAsetBeforeColl,
			final APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setRPropFromCollToCargo() - START");
			APP_IN_R_PROP_ASET_Cargo appInRPropAsetBeforeCargo;
			appInRPropAsetBeforeCargo = appInRPropAsetBeforeColl.getCargo(0);
			appInRPropAsetCargo.setApp_num(appNum);
			appInRPropAsetCargo.setIndv_seq_num(appInRPropAsetBeforeCargo.getIndv_seq_num());
			appInRPropAsetCargo.setReal_prop_aset_typ(appInRPropAsetBeforeCargo.getReal_prop_aset_typ());
			appInRPropAsetCargo.setSeq_num(appInRPropAsetBeforeCargo.getSeq_num());

			if (appInRPropAsetCargo.getSeq_num() == null) {
				appInRPropAsetCargo.setRowAction(FwConstants.ROWACTION_INSERT);
			} else {
				appInRPropAsetCargo.setRowAction(FwConstants.ROWACTION_UPDATE);
			}

			if (appInRPropAsetCargo.getRes_sw() == null) {
				appInRPropAsetCargo.setRes_sw(FwConstants.SPACE);
			}
			if (appInRPropAsetCargo.getIntn_ret_sw() == null) {
				appInRPropAsetCargo.setIntn_ret_sw(FwConstants.SPACE);
			}

			if (appInRPropAsetCargo.getSps_live_sw() == null) {
				appInRPropAsetCargo.setSps_live_sw(FwConstants.SPACE);
			}
			if (appInRPropAsetCargo.getRlt_cd() == null) {
				appInRPropAsetCargo.setRlt_cd(FwConstants.SPACE);
			}
			if (appInRPropAsetCargo.getSale_agr_sw() == null) {
				appInRPropAsetCargo.setSale_agr_sw(FwConstants.SPACE);
			}

			if (appInJntOwnColl != null) {
				iterateJointCargo(appInJntOwnColl);
			}

			if ((appInJntOwnColl != null) && (!appInJntOwnColl.isEmpty())) {
				appInRPropAsetCargo.setJnt_own_resp(FwConstants.YES);
			} else {
				appInRPropAsetCargo.setJnt_own_resp(FwConstants.NO);
			}
			// check dirty

			if (!appInRPropAsetCargo.isDirty())
				appInRPropAsetCargo = (APP_IN_R_PROP_ASET_Cargo) isChanged(appInRPropAsetBeforeCargo,
						appInRPropAsetCargo);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setRPropFromCollToCargo() - END");
			return appInRPropAsetCargo;
		
	}

	private void setRPropAssetCargo(APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo, final String addrOption)
			throws ParseException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setRPropAssetCargo() - START");
			if (addrOption == null) {
				appInRPropAsetCargo.setProp_adr_ind(FwConstants.ZERO);
			}
			if (appInRPropAsetCargo.getIndividual_live_ind() == null) {
				appInRPropAsetCargo.setIndividual_live_ind(FwConstants.SPACE);
			}

			if (appInRPropAsetCargo.getProperty_producing_income_ind() == null) {
				appInRPropAsetCargo.setProperty_producing_income_ind(FwConstants.SPACE);
			}
			if (appInRPropAsetCargo.getProperty_rented_for_sale_ind() == null) {
				appInRPropAsetCargo.setProperty_rented_for_sale_ind(FwConstants.SPACE);
			}
			if (appInRPropAsetCargo.getProperty_change_ownership_ind() == null) {
				appInRPropAsetCargo.setProperty_change_ownership_ind(FwConstants.SPACE);
			}
			if ((appInRPropAsetCargo.getAsset_acquired_dt() == null)) {
				appInRPropAsetCargo.setAsset_acquired_dt(new SimpleDateFormat().parse(AppConstants.LOW_DATE));
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setRPropAssetCargo() - END");
	}

	private void setJointOwnCargo(APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo, APP_IN_JNT_OWN_Cargo appInJntOwnCargo,
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointOwnCargo() - START");
			setSeqNumbersForRProp(appInRPropAsetCargo, appInJntOwnCargo);
			setJointCargoOtherValues(appInRPropAsetCargo, appInJntOwnCargo);

			appInJntOwnCargo.setRowAction(FwConstants.ROWACTION_INSERT);
			appInJntOwnNewColl.add(appInJntOwnCargo);
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointOwnCargo() - END");
	}

	private APP_IN_JNT_OWN_Cargo setJointCargo(APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo,
			final APP_IN_JNT_OWN_Collection appInJntBeforeColl, APP_IN_JNT_OWN_Cargo appInJntOwnCargo,
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl, APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointCargo() - START");
			final int appInjntBeforeCollSize = appInJntBeforeColl.size();

			for (int i = 0; i < appInjntBeforeCollSize; i++) {

				appInJntOwnBeforeCargo = appInJntBeforeColl.getCargo(i);

				if (appInJntOwnCargo == null) {
					appInJntOwnBeforeCargo.setRowAction(FwConstants.ROWACTION_DELETE);
					appInJntOwnNewColl.add(appInJntOwnBeforeCargo);
				} else {
					// now we need to check the dirty indicator
					setSeqNumbersForRProp(appInRPropAsetCargo, appInJntOwnCargo);

					if (appInJntOwnCargo.getSeq_num() == null) {
						appInJntOwnCargo.setSeq_num(appInJntOwnBeforeCargo.getSeq_num());
					}

					setJointCargoOtherValues(appInRPropAsetCargo, appInJntOwnCargo);
					if (appInJntOwnCargo.isDirty()) {

						appInJntOwnCargo.setRowAction(FwConstants.ROWACTION_UPDATE);
						appInJntOwnNewColl.add(appInJntOwnCargo);
					}
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointCargo() - END");
		return appInJntOwnBeforeCargo;
	}

	private void setJointCargoOtherValues(APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo,
			APP_IN_JNT_OWN_Cargo appInJntOwnCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointCargoOtherValues() - START");
			appInJntOwnCargo.setAset_sub_typ(appInRPropAsetCargo.getReal_prop_aset_typ());

			appInJntOwnCargo.setAset_typ(AppConstants.JOINT_OWNER_TYPE_REAL_PROPERTY);
			if (appInJntOwnCargo.getJnt_own_fst_nam() == null) {
				appInJntOwnCargo.setJnt_own_fst_nam(FwConstants.SPACE);
			}
			if (appInJntOwnCargo.getJnt_own_last_nam() == null) {
				appInJntOwnCargo.setJnt_own_last_nam(FwConstants.SPACE);
			}
			if (appInJntOwnCargo.getOtsd_ind() == null) {
				appInJntOwnCargo.setOtsd_ind(FwConstants.SPACE);
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointCargoOtherValues() - END");
	}

	private void setSeqNumbersForRProp(APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo,
			APP_IN_JNT_OWN_Cargo appInJntOwnCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setSeqNumbersForRProp() - START");
			appInJntOwnCargo.setApp_num(appInRPropAsetCargo.getApp_num());
			if (appInRPropAsetCargo.getSeq_num() != null
					&& !"".equals(appInRPropAsetCargo.getSeq_num().toString().trim())) {
				appInJntOwnCargo.setJnt_indv_seq_num(appInRPropAsetCargo.getSeq_num());
			}
			if (appInRPropAsetCargo.getIndv_seq_num() != null
					&& !"".equals(appInRPropAsetCargo.getIndv_seq_num().toString().trim())) {
				appInJntOwnCargo.setIndv_seq_num(appInRPropAsetCargo.getIndv_seq_num());
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setSeqNumbersForRProp() - END");
	}

	private void setAddressDetailsInCargo(final String appNum, APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo,
			final String addrOption) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setAddressDetailsInCargo() - START");
			if ("hshlAddr".equals(addrOption)) {
				final APP_RGST_Collection appRgstColl = cpAppRgstRepository.getByAppNumAndSrcApp(appNum, "AB");
				if ((appRgstColl != null) && (!appRgstColl.isEmpty())) {
					final APP_RGST_Cargo appRgstCargo = appRgstColl.getCargo(0);
					appInRPropAsetCargo.setProp_l1_adr(appRgstCargo.getHshl_l1_adr());
					appInRPropAsetCargo.setProp_l2_adr(appRgstCargo.getHshl_l2_adr());
					appInRPropAsetCargo.setProp_city_adr(appRgstCargo.getHshl_city_adr());
					appInRPropAsetCargo.setProp_sta_adr(appRgstCargo.getHshl_sta_adr());
					appInRPropAsetCargo.setProp_zip_adr(appRgstCargo.getHshl_zip_adr());
				}
			} else if ("spsAddr".equals(addrOption)) {
				final APP_IN_SPS_IMPOV_Collection appInSpsColl = appInSpsRepository.getByAppNum(appNum);
				if ((appInSpsColl != null) && (!appInSpsColl.isEmpty())) {
					final APP_IN_SPS_IMPOV_Cargo appInSpsCargo = appInSpsColl.getCargo(0);
					appInRPropAsetCargo.setProp_l1_adr(appInSpsCargo.getSps_l1_adr());
					appInRPropAsetCargo.setProp_l2_adr(appInSpsCargo.getSps_l2_adr());
					appInRPropAsetCargo.setProp_city_adr(appInSpsCargo.getSps_city_adr());
					appInRPropAsetCargo.setProp_sta_adr(appInSpsCargo.getSps_sta_adr());
					appInRPropAsetCargo.setProp_zip_adr(appInSpsCargo.getSps_zip_adr());
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setAddressDetailsInCargo() - END");
	}

	
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getRealPropertyDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getRealPropertyDetails() - START", txnBean);
		try {
			final Map request = txnBean.getRequest();
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			final Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			// make loopingQuestion value NO in the request
			request.put(LOOPING_QUESTION, FwConstants.NO);

			// When user hits the Back button or comes from the Summary Page
			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {
				// get RealProperty details from RealProperty details table in
				// database

				pageCollection = new HashMap();
				// get Details_Collection from DataBase and set to
				// PageCollection

				final APP_IN_R_PROP_ASET_Collection appPropCol = aBRealPropertyDetailsBO
						.loadIndividualRealPropertyDetails(appNum, indvSeqNum, seqNum);
				pageCollection.put("APP_IN_R_PROP_ASET_COLLECTION", appPropCol);

			} else {
				pageCollection = new HashMap();

				final APP_IN_R_PROP_ASET_Collection appPropColl = aBRealPropertyDetailsBO
						.loadIndividualRealPropertyDetails(appNum, indvSeqNum, seqNum);

				int sizeColl = 0;
				APP_IN_R_PROP_ASET_Cargo appPropCargo = null;
				if ((appPropColl != null) && (!appPropColl.isEmpty())) {
					sizeColl = appPropColl.size();
				}
				if (sizeColl > 0) {
					appPropCargo = appPropColl.getCargo(sizeColl - 1);
				} else {
					appPropCargo = new APP_IN_R_PROP_ASET_Cargo();
					appPropCargo.setApp_num(appNum);
					appPropCargo.setIndv_seq_num(indvSeqNum);
					appPropCargo.setSeq_num(seqNum);

				}
				final APP_IN_R_PROP_ASET_Collection temp = new APP_IN_R_PROP_ASET_Collection();
				temp.addCargo(appPropCargo);
				pageCollection.put("APP_IN_R_PROP_ASET_Collection", temp);
				txnBean.setPageCollection(pageCollection);

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.getRealPropertyDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_REAL_PROP_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getRealPropertyDetails() - END", txnBean);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeRealPropertyType(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.storeRealPropertyType() - START", txnBean);
		try {

			final Map pageCollection = txnBean.getPageCollection();

			// Initialize messageList
			FwMessageList validateInfo = null;

			// Persist Array List Collection and cargo
			final List persistArray = new ArrayList();

			// Get ABRPT Other Real Property Type Before Collection

			// Initialize the colSize

			int noOneSize = 0;

			boolean persistFlag = false;
			boolean driverFlag = true;
			// EDSP CP Modified

			String beforeIndvSeqNum = null;
			String resIndvSeqNum = null;

		}  catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.storeRealPropertyType()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STORE_REAL_PROP_TYPE, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.storeRealPropertyType() - END", txnBean);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getRealPropertyType(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getRealPropertyType() - START", txnBean);
		try {

			final Map request = txnBean.getRequest();
			loadTypes(txnBean, request.get(FwConstants.CURRENT_PAGE_ID).toString());

		}  catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.getRealPropertyType()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_REAL_PROP_TYPE,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getRealPropertyType() - END", txnBean);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeVehicleAssetDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.storeVehicleAssetDetails() - START", txnBean);
		try {

			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			final Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			// get the BeforeCollection

			// get Details aset Collection and Cargo
			APP_IN_VEH_ASET_Cargo appInVAsetCargo = new APP_IN_VEH_ASET_Cargo();
			APP_IN_VEH_ASET_Collection appInVAsetColl = (APP_IN_VEH_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_VEH_ASET_COLL);
			if (appInVAsetColl != null && !appInVAsetColl.isEmpty()) {
				appInVAsetCargo = appInVAsetColl.getCargo(0);
			}

			// get details joint owner collection
			final APP_IN_JNT_OWN_Collection appInJntOwnColl = (APP_IN_JNT_OWN_Collection) pageCollection
					.get(APP_IN_JNT_OWN_COLLECTION);

			appInVAsetCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
			appInVAsetCargo.setApp_num(appNum);
			appInVAsetCargo.setIndv_seq_num(indvSeqNum);
			appInVAsetCargo.setSeq_num(seqNum);
			if ((appInVAsetCargo.getMv_yr() == null)
					|| FwConstants.EMPTY_STRING.equals(appInVAsetCargo.getMv_yr().toString().trim())) {
				appInVAsetCargo.setMv_yr(9999);
			}
			// date conversion

			if ((appInVAsetCargo.getVehicle_acquired_dt() == null)) {

				try {
					appInVAsetCargo.setVehicle_acquired_dt(format.parse(AppConstants.LOW_DATE));
				} catch (final ParseException e) {
					FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_VEHICLE_ASSET_DETAILS_ERROR, txnBean);
				}
			}
			if ((appInVAsetCargo.getAsset_end_dt() == null)) {
				try {
					appInVAsetCargo.setAsset_end_dt(format.parse(AppConstants.LOW_DATE));
				} catch (final ParseException e) {
					FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_VEHICLE_ASSET_DETAILS_ERROR, txnBean);
				}

			}

			// completeness check
			appInVAsetCargo.setRec_cplt_ind(financialAssetsBO.completenessCheck(appInVAsetCargo));
			// PersistData if the cargo is dirty
			appInVAsetColl = vehicleAssetBO.storeVehicleAssetDetails(appInVAsetColl);

			if (appInVAsetColl != null && !appInVAsetColl.isEmpty()) {
				setJointOwnCargoForVehAsset(appInVAsetColl, appInJntOwnColl);
			}

			// values entered and when the user tries to save the record first
			// time

			// Define DetailsFinishedFlag as True
		}  catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_VEHICLE_ASSET_DETAILS_ERROR, txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STORE_VEHI_ASSET_DET, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.storeVehicleAssetDetails() - END", txnBean);
	}

	private void setJointOwnCargoForVehAsset(APP_IN_VEH_ASET_Collection appInVAsetColl,
			final APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointOwnCargoForVehAsset() - START");
			APP_IN_VEH_ASET_Cargo appInVAsetCargo;
			appInVAsetCargo = appInVAsetColl.getCargo(0);
			APP_IN_JNT_OWN_Cargo appInJntOwnCargo = null;
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl = new APP_IN_JNT_OWN_Collection();
			APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo = null;
			if (appInJntOwnColl != null) {
				iterateAndValidateJoinCargoVehAsset(appInJntOwnColl);
			}
			if (appInJntOwnColl != null) {
				final int appInJntCollSize = appInJntOwnColl.size();
				for (int i = 0; i < appInJntCollSize; i++) {
					appInJntOwnCargo = appInJntOwnColl.getCargo(i);

					if (appInJntOwnBeforeCargo == null) {
						setVehAssetJointCargo(appInVAsetCargo, appInJntOwnCargo, appInJntOwnNewColl);
					}
				}
			}

			financialAssetsBO.storeJointOwnerDetails(appInJntOwnNewColl);
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setJointOwnCargoForVehAsset() - END");
	}

	private void setVehAssetJointCargo(APP_IN_VEH_ASET_Cargo appInVAsetCargo, APP_IN_JNT_OWN_Cargo appInJntOwnCargo,
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setVehAssetJointCargo() - START");
			appInJntOwnCargo.setApp_num(appInVAsetCargo.getApp_num());
			appInJntOwnCargo.setJnt_indv_seq_num(appInVAsetCargo.getSeq_num());
			appInJntOwnCargo.setIndv_seq_num(appInVAsetCargo.getIndv_seq_num());
			appInJntOwnCargo.setAset_sub_typ(appInVAsetCargo.getVeh_aset_typ());
			appInJntOwnCargo.setAset_typ(AppConstants.JOINT_OWNER_TYPE_VEHICLE_ASSET);
			if (appInJntOwnCargo.getJnt_own_fst_nam() == null) {
				appInJntOwnCargo.setJnt_own_fst_nam(FwConstants.SPACE);
			}
			if (appInJntOwnCargo.getJnt_own_last_nam() == null) {
				appInJntOwnCargo.setJnt_own_last_nam(FwConstants.SPACE);
			}
			if (appInJntOwnCargo.getOtsd_ind() == null) {
				appInJntOwnCargo.setOtsd_ind(FwConstants.SPACE);
			}
			if (appInJntOwnCargo.getSeq_num() == null) {
				appInJntOwnCargo.setSeq_num(0);
			}

			appInJntOwnCargo.setRowAction(FwConstants.ROWACTION_INSERT);
			appInJntOwnNewColl.add(appInJntOwnCargo);
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.setVehAssetJointCargo() - END");
	}

	private void iterateAndValidateJoinCargoVehAsset(final APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.iterateAndValidateJoinCargoVehAsset() - START");
			int appInJntCollSize = appInJntOwnColl.size();
			APP_IN_JNT_OWN_Cargo jntOwnCargo = null;
			for (int i = 0; i < appInJntCollSize; i++) {
				jntOwnCargo = appInJntOwnColl.getCargo(i);
				if ((jntOwnCargo.getJnt_indv_seq_num() != null)
						&& (FinancialInfoConstants.ZERO == jntOwnCargo.getJnt_indv_seq_num().intValue())
						&& ((jntOwnCargo.getJnt_own_fst_nam() == null)
								|| (jntOwnCargo.getJnt_own_fst_nam().trim().length() == 0))
						&& ((jntOwnCargo.getJnt_own_last_nam() == null)
								|| (jntOwnCargo.getJnt_own_last_nam().trim().length() == 0))
						&& ((jntOwnCargo.getOtsd_ind() == null) || (jntOwnCargo.getOtsd_ind().trim().length() == 0))) {
					appInJntOwnColl.remove(i);
					i--;
					appInJntCollSize--;
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.iterateAndValidateJoinCargoVehAsset() - END");
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getVehicleAssetDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getVehicleAssetDetails() - START", txnBean);
		try {
			final Map request = txnBean.getRequest();
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			final Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			// make loopingQuestion value NO in the request
			request.put(LOOPING_QUESTION, FwConstants.NO);

			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {
				// get PersonalProperty details from PersonalProperty details
				// table in database

				pageCollection = new HashMap();
				// get Details_Collection from DataBase and set to
				// PageCollection

				final APP_IN_VEH_ASET_Collection appVehColl = vehicleAssetBO.loadIndividualVehicleAsetDetails(appNum,
						indvSeqNum, seqNum);

				pageCollection.put(FinancialInfoConstants.APP_IN_VEH_ASET_COLL, appVehColl);
			} else {
				pageCollection = new HashMap();

				final APP_IN_VEH_ASET_Collection appVehColl = vehicleAssetBO.loadIndividualVehicleAsetDetails(appNum,
						indvSeqNum, seqNum);

				int sizeColl = 0;
				APP_IN_VEH_ASET_Cargo appVehCargo = null;
				if ((appVehColl != null) && (!appVehColl.isEmpty())) {
					sizeColl = appVehColl.size();
				}
				if (sizeColl > 0) {
					appVehCargo = appVehColl.getCargo(sizeColl - 1);
				} else {
					appVehCargo = new APP_IN_VEH_ASET_Cargo();
					appVehCargo.setApp_num(appNum);
					appVehCargo.setIndv_seq_num(indvSeqNum);
					appVehCargo.setSeq_num(seqNum);

				}
				final APP_IN_VEH_ASET_Collection temp = new APP_IN_VEH_ASET_Collection();
				temp.addCargo(appVehCargo);
				pageCollection.put(FinancialInfoConstants.APP_IN_VEH_ASET_COLL, temp);

			}

			INDIVIDUAL_Custom_Collection indivCustCol = null;
			// need to use the loadPeopleHandler method and then getRelevent Indv method
			// through service chaining
			pageCollection.put("INDIVIDUAL_Custom_Collection", indivCustCol);

			txnBean.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), Level.INFO, "FinancialAssetsServImpl::getVehicleAssetDetails");

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, GET_VEHICLE_ASSET_DETAILS_ERROR, txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_VEHI_ASSET_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getVehicleAssetDetails() - END", txnBean);
	}


	private void loadTypes(final FwTransaction txnBean, final String pageCollectionPrefix) {
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.loadTypes() - START", txnBean);
			final Map session = txnBean.getSession();
			final Map request = txnBean.getRequest();
			final Map pageCollection = txnBean.getPageCollection();

			final NO_ONE_Collection noOneCollection = new NO_ONE_Collection();

			final Map firstNameList = new HashMap();

			pageCollection.put(pageCollectionPrefix + "_FIRST_NAME_LIST", firstNameList);
			pageCollection.put(pageCollectionPrefix + "_NO_ONE_COLLECTION", noOneCollection);

			// Add the page collection to before collection

			session.put(FwConstants.BEFORE_COLLECTION, pageCollection);
			request.put(FwConstants.NEXT_PAGE_ID, ABVATLOAAD);
			request.put(FwConstants.NEXT_PAGE_ACTION, ABVATLOAAD);
			FwPageActionDetails details = new FwPageActionDetails();
			details.setSuccesspageID(ABVATLOAAD);
			details.setSuccesspageAction(ABVATLOAAD);
			txnBean.getNextActionDetails().setPageActionUrl("");
			txnBean.setPageCollection(request);
			txnBean.setPageActionDetails(details);
			txnBean.setPageCollection(pageCollection);
			txnBean.setSession(session);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.loadTypes()", txnBean);
			throw e;

		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.loadTypes() - END", txnBean);
	}

	
	
	

	protected AbstractCargo isChanged(final AbstractCargo aBeforeCargo, final AbstractCargo aAfterCargo)
			throws FwException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.isChanged() - START");
			if (aBeforeCargo == aAfterCargo) {
				aAfterCargo.setDirty(false);
			} else {
				if (null != aAfterCargo) {
					if ((aBeforeCargo == null) || (aBeforeCargo.hashCode() != aAfterCargo.hashCode())) {
						aAfterCargo.setDirty(true);
					} else
						aAfterCargo.setDirty(false);
				}
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.isChanged() - END");
			return aAfterCargo;
		
		
	}

	public String getBirthDateFromPeopleHandler() {
		Date dob = new Date();
		return dob + "";
	}

	@Transactional
	public void getAFBAssetSummaryDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getAFBAssetSummaryDetails() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			if (CollectionUtils.isNullOrEmpty(indvIds)) {
				List<String> indvIdList = new ArrayList<String>();
				ExpenseSummaryServiceImpl obj = new ExpenseSummaryServiceImpl();
				APP_INDV_Collection appIndvCollection = obj.getIndvList(fwTxn);
				if (appIndvCollection != null && !appIndvCollection.isEmpty()) {
					for (int i = 0; i < appIndvCollection.size(); i++) {
						APP_INDV_Cargo appIndvCargo1 = (APP_INDV_Cargo) appIndvCollection.get(i);
						indvIdList.add(appIndvCargo1.getIndv_seq_num().toString());
					}
					FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Final IndvList:" + indvIdList);
					pageCollection.put(INDV_ID, indvIdList);
					fwTxn.setPageCollection(pageCollection);
				}
			}

			// Account Summary
			getAccountSummaryDetails(fwTxn);
			// Own Vehicle Summary
			getOwnVehicleSummaryDetails(fwTxn);
			// Use Vehicle Summary - not needed as own and use vehicle uses same table
			getOwnPropertySummaryDetails(fwTxn);
			// personal property Summary
			getPersonalPropertySummaryDetails(fwTxn);
			// Asset Summary
			getAssetSummaryDetails(fwTxn);
			// AFb asset summary Mapping everything in pageCollection Object
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.storeOutOfState()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.GET_AFBASSETSUMM_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getAFBAssetSummaryDetails() - END", fwTxn);
	}

	@Transactional
	public void getAssetSummaryDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getAssetSummaryDetails() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			IndividualCategorySequenceDetails categorySequenceDetails;
			CP_APP_IN_ASET_XFER_Collection xferColl=null;
			
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			
			if (null != txnBean.getCurrentActionDetails().getPageId() && txnBean.getCurrentActionDetails().getPageId().equalsIgnoreCase("PROAS")) {
					xferColl = liquidAssetBO.loadAssetXferByAppNumForPR(appNum,indvIdList);				
			}else {
				xferColl = liquidAssetBO.loadAssetXferByAppNum(appNum);
			}
			CP_APP_IN_DEDUCTION_Collection appInDedColl;			

			
			int sizeColl = 0;
			CP_APP_IN_ASET_XFER_Cargo xferCargo = null;
			if ((xferColl != null) && (!xferColl.isEmpty())) {
				sizeColl = xferColl.size();
			}
			final CP_APP_IN_ASET_XFER_Collection temp = new CP_APP_IN_ASET_XFER_Collection();

			for (int i = 0; i < sizeColl; i++) {
				xferCargo = xferColl.getCargo(i);
				temp.addCargo(xferCargo);
			}

			pageCollection.put(FinancialInfoConstants.CP_APP_IN_ASET_XFER_COLL, temp);
			txnBean.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), Level.INFO, "FinancialAssetsServImpl::getAssetSummaryDetails");

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.getAssetSummaryDetails()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GETASSSUM_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getAssetSummaryDetails() - END", txnBean);
	}

	private void getPersonalPropertySummaryDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getPersonalPropertySummaryDetails() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			IndividualCategorySequenceDetails categorySequenceDetails;

			final APP_IN_P_PROP_ASET_Collection appPPropColl = otherResourDetailsBO.loadPPropertyAssetDetails(appNum);
			int sizeColl = 0;
			APP_IN_P_PROP_ASET_Cargo appPPropCargo = null;
			if ((appPPropColl != null) && (!appPPropColl.isEmpty())) {
				sizeColl = appPPropColl.size();
			}
			final APP_IN_P_PROP_ASET_Collection temp = new APP_IN_P_PROP_ASET_Collection();

			for (int i = 0; i < sizeColl; i++) {
				appPPropCargo = appPPropColl.getCargo(i);
				temp.addCargo(appPPropCargo);
			}

			pageCollection.put(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL, temp);
			txnBean.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), Level.INFO, "FinancialAssetsServImpl::getPersonalPropertySummaryDetails");

		}  catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.getPersonalPropertySummaryDetails()", txnBean);
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getPersonalPropertySummaryDetails() - END", txnBean);
	}

	private void getOwnPropertySummaryDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getOwnPropertySummaryDetails() - END", txnBean);
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			final APP_IN_R_PROP_ASET_Collection appRPropColl = realPropBo.loadRealPropertyDetails(appNum);
			int sizeColl = 0;
			APP_IN_R_PROP_ASET_Cargo appRPropCargo = null;
			if ((appRPropColl != null) && (!appRPropColl.isEmpty())) {
				sizeColl = appRPropColl.size();
			}
			final APP_IN_R_PROP_ASET_Collection temp = new APP_IN_R_PROP_ASET_Collection();

			for (int i = 0; i < sizeColl; i++) {
				appRPropCargo = appRPropColl.getCargo(i);
				temp.addCargo(appRPropCargo);
			}

			pageCollection.put(FinancialInfoConstants.APP_IN_R_PROP_ASET_COLL, temp);
			txnBean.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), Level.INFO, "FinancialAssetsServImpl::getOwnPropertySummaryDetails");

		

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.getOwnPropertySummaryDetails() - END", txnBean);
	}

	private void getAccountSummaryDetails(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.getAccountSummaryDetails() - START", fwTxn);
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			final String appNum = userDetails.getAppNumber();
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			APP_IN_LQD_ASET_Collection coll = liquidAssetBO.loadAccountSummarydetails(appNum, indvIdList);
			APP_IN_LQD_ASET_Cargo appInLqdCargo;
			APP_IN_LQD_ASET_Collection temp = new APP_IN_LQD_ASET_Collection();
			int sizeColl = 0;
			if (coll != null && !coll.isEmpty()) {
				sizeColl = coll.size();
			}
			for (int i = 0; i < sizeColl; i++) {
				appInLqdCargo = coll.getCargo(i);
				temp.addCargo(appInLqdCargo);
			}

			pageCollection.put(FinancialInfoConstants.APP_IN_LQD_ASET_COLL, temp);

		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.getAccountSummaryDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getAssetAndIncomeDetails(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.getAssetAndIncomeDetails() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			// Get data from APP_IN_LQD_ASET and check if it is less than $100
			APP_IN_LQD_ASET_Collection coll = liquidAssetBO.loadAccountSummarydetails(appNum, indvIdList);
			APP_IN_LQD_ASET_Cargo[] appInLqdCargo = null;
			appInLqdCargo = coll.getResults();

			// Get gross income value
			CP_APP_INDV_ADDI_INFO_Cargo cpAppIndvAddiInfoCargo = new CP_APP_INDV_ADDI_INFO_Cargo();
			CP_APP_INDV_ADDI_INFO_Collection cpAppIndvCollection = new CP_APP_INDV_ADDI_INFO_Collection();
			if (null != pageCollection.get(GROSS_INC) && (null != pageCollection.get(GROSS_INC).toString()
					&& !pageCollection.get(GROSS_INC).toString().equals(""))) {
				double grossIncome = Double.parseDouble(pageCollection.get(GROSS_INC).toString());
				// Get expense data
				APP_IN_HOU_BILLS_Collection appInHousingColl = expenseSummaryBO.getHousingSummaryDetails(appNum,
						indvIdList);
				// Set data in CP_APP_INDV_ADDI_INFO_Cargo based on logic
				setGrossIncomeRelatedColumns(appInLqdCargo, cpAppIndvAddiInfoCargo, grossIncome, appInHousingColl);
			}
			cpAppIndvCollection.addCargo(cpAppIndvAddiInfoCargo);
			pageCollection.put(FinancialInfoConstants.CP_APP_INDV_ADDI_INFO_COLL, cpAppIndvCollection);

		}  catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.getAssetAndIncomeDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_ASSE_INC_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.getAssetAndIncomeDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);
	}

	private void setGrossIncomeRelatedColumns(APP_IN_LQD_ASET_Cargo[] appInLqdCargo,
			CP_APP_INDV_ADDI_INFO_Cargo cpAppIndvAddiInfoCargo, double grossIncome,
			APP_IN_HOU_BILLS_Collection appInHousingColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.setGrossIncomeRelatedColumns() - START");
		try {
			if (grossIncome != 0 && appInLqdCargo.length > 0) {
				if (question1(grossIncome, appInLqdCargo)) {
					cpAppIndvAddiInfoCargo.setGross_income_less("Y");
				} else {
					cpAppIndvAddiInfoCargo.setGross_income_less("N");
				}
				if (question3(appInLqdCargo)) {
					cpAppIndvAddiInfoCargo.setMig_farm_wrkr_resp("Y");
				} else {
					cpAppIndvAddiInfoCargo.setMig_farm_wrkr_resp("N");
				}
				if (question2(grossIncome, appInLqdCargo, appInHousingColl)) {
					cpAppIndvAddiInfoCargo.setCombined_gross_income("Y");
				} else {
					cpAppIndvAddiInfoCargo.setCombined_gross_income("N");
				}
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.setGrossIncomeRelatedColumns()");
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.setGrossIncomeRelatedColumns() - END");
	}

	private boolean question1(double grossIncome, APP_IN_LQD_ASET_Cargo[] appInLqdCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.question1() - START");
		try {
			int liquidAsset = 0;
			if (appInLqdCargo.length > 0) {
				for (APP_IN_LQD_ASET_Cargo cargo : appInLqdCargo) {
					if ((cargo.getLqd_aset_typ().equalsIgnoreCase("CA")
							|| cargo.getLqd_aset_typ().equalsIgnoreCase("SA")
							|| cargo.getLqd_aset_typ().equalsIgnoreCase("CH"))
							&& Objects.nonNull(cargo.getLqd_aset_amt())) {
						liquidAsset += cargo.getLqd_aset_amt();
					}
				}
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.question1() - END");
				return grossIncome < 150 && liquidAsset <= 100;
			} else {
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.question1() - END");
				return grossIncome < 150;
			}
			
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.question1()");
			throw e;
		}
		
	}

	private boolean question2(double grossIncome, APP_IN_LQD_ASET_Cargo[] appInLqdCargo,
			APP_IN_HOU_BILLS_Collection appInHousingColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.question2() - START");
			int liquidAsset = 0;
			int expenses = 0;
			if (appInLqdCargo.length > 0) {
				for (APP_IN_LQD_ASET_Cargo cargo : appInLqdCargo) {
					if ((cargo.getLqd_aset_typ().equalsIgnoreCase("CA")
							|| cargo.getLqd_aset_typ().equalsIgnoreCase("SA")
							|| cargo.getLqd_aset_typ().equalsIgnoreCase("CH")
							|| cargo.getLqd_aset_typ().equalsIgnoreCase("SB")
							|| cargo.getLqd_aset_typ().equalsIgnoreCase("MM")
							|| cargo.getLqd_aset_typ().equalsIgnoreCase("UC"))
							&& Objects.nonNull(cargo.getLqd_aset_amt())) {
						// Calculate checking account, savings account, cash on hand,
						// stocks/bonds, money market and uncashed checks only
						liquidAsset += cargo.getLqd_aset_amt();
					}
				}
			}

			for (int i = 0; i < appInHousingColl.size(); i++) {
				APP_IN_HOU_BILLS_Cargo cargo = appInHousingColl.getCargo(i);
				if (cargo.getBill_type().equalsIgnoreCase("RH") || cargo.getBill_type().equalsIgnoreCase("GE")
						|| cargo.getBill_type().equalsIgnoreCase("WA")) {
					expenses += getMonthlyAmount(cargo.getPymt_amt(), cargo.getPymt_freq());
				}
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.question2() - END");
			return (liquidAsset + grossIncome) < expenses;
		
	}

	private double getMonthlyAmount(Double pymt_amt, String payFrequency) {
			
			//Fix for BCUAT-2244-Expedited Food Assistance screen load issue-Adding null check
		if(null != payFrequency) {
			if (payFrequency.equals("02")) {
				return pymt_amt * 4.33;
			} else if (payFrequency.equals("03")) {
				return pymt_amt * 2.167;
			} else if (payFrequency.equals("04")) {
				return pymt_amt * 2;
			} else if (payFrequency.equals("05")) {
				return pymt_amt;
			} else if (payFrequency.equals("06")) {
				return pymt_amt / 3;
			} else if (payFrequency.equals("09")) {
				return pymt_amt / 12;
			} else {
				return pymt_amt;
			}
		}else {
			return pymt_amt;
		}
		
		
	}

	private boolean question3(APP_IN_LQD_ASET_Cargo[] appInLqdCargo) {
			int liquidAsset = 0;
			if (appInLqdCargo.length > 0) {
				for (APP_IN_LQD_ASET_Cargo cargo : appInLqdCargo) {
					if (Objects.nonNull(cargo.getLqd_aset_amt())) {
						liquidAsset += cargo.getLqd_aset_amt();
					}
				}
			}
			return liquidAsset < 100;
		
	}

	private void getOwnVehicleSummaryDetails(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.getOwnVehicleSummaryDetails() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();
			List<Integer> indvIdList = new ArrayList<Integer>();
			String pageId = txnBean.getCurrentActionDetails()!=null?txnBean.getCurrentActionDetails().getPageId():null;
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			APP_IN_VEH_ASET_Collection temp = new APP_IN_VEH_ASET_Collection();
			APP_IN_VEH_ASET_Collection appVehColl = null;
            if(FinancialInfoConstants.MCAVP.equalsIgnoreCase(pageId)) {
            	appVehColl = appInVehAssetRepository.loadOwnVehicleSummaryMC(Integer.parseInt(appNum), indvIdList);
            }else {
            	appVehColl = vehicleAssetBO.loadOwnVehicleSummary(appNum, indvIdList);
            }
			int sizeColl = 0;
			APP_IN_VEH_ASET_Cargo appVehCargo;
			if (appVehColl != null && !appVehColl.isEmpty()) {
				sizeColl = appVehColl.size();
			}
			for (int i = 0; i < sizeColl; i++) {
				appVehCargo = appVehColl.getCargo(i);
				temp.addCargo(appVehCargo);
			}
			pageCollection.put(FinancialInfoConstants.APP_IN_VEH_ASET_COLL, temp);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.getOwnVehicleSummaryDetails()", txnBean);
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.getOwnVehicleSummaryDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), txnBean);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeAssetsOwnPropertyDetails(FwTransaction fwTxn) {
		long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.storeAssetsOwnPropertyDetails() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			Integer seqNum = null;
			Integer indvSeqNum = null;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			APP_IN_R_PROP_ASET_Collection propAsetColl = (APP_IN_R_PROP_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_R_PROP_ASET_COLL);

			if (null != propAsetColl && !propAsetColl.isEmpty()) {
				APP_IN_R_PROP_ASET_Cargo propAsetCargo = propAsetColl.getCargo(0);
				propAsetCargo.setApp_num(appNumber);
				propAsetCargo.setIndv_seq_num(indvSeqNum);
				propAsetCargo.setSeq_num(seqNum);
				propAsetCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
				propAsetCargo.setReal_prop_aset_typ(FinancialInfoConstants.OP);

				propAsetColl.addCargo(propAsetCargo);

				realPropBo.saveOwnPropertyDetails(propAsetColl);
			}

		}  catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.storeAssetsOwnPropertyDetails()", fwTxn);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.STR_ASS_OWN_PROP_DET);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.STR_ASS_OWN_PROP_DET, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STR_ASS_OWN_PROP_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.storeAssetsOwnPropertyDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	@Transactional
	public void loadAssetsOwnPropertyDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.loadAssetsOwnPropertyDetails() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();

			APP_IN_R_PROP_ASET_Collection appPropColl = realPropBo.loadRealPropertyDetails(appNum);

			pageCollection.put(FinancialInfoConstants.APP_IN_R_PROP_ASET_COLL, appPropColl);
			txnBean.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), Level.INFO, "FinancialAssetsServImpl::loadAssetsOwnPropertyDetails");

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.loadAssetsOwnPropertyDetails()", txnBean);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.LOAD_ASS_OWN_PROP_DET);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.LOAD_ASS_OWN_PROP_DET, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.LOAD_ASS_OWN_PROP_DET, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.loadAssetsOwnPropertyDetails() - END", txnBean);

	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void removeAssetsOwnPropertyDetails(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.removeAssetsOwnPropertyDetails() - START", fwTransaction);
		try {
			String appNumber = fwTransaction.getUserDetails().getAppNumber();
			Integer indvSeqNum = Integer.parseInt(fwTransaction.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seqNum = Integer.parseInt(fwTransaction.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails().getCategorySequence());
			String ownPropertyAssetType = FinancialInfoConstants.OP;

			realPropBo.removeOwnPropertyDetails(appNumber, indvSeqNum, seqNum, ownPropertyAssetType);
		}  catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.removeAssetsOwnPropertyDetails()", fwTransaction);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.REMOVE_ASS_OWN_PROP_DET);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.REMOVE_ASS_OWN_PROP_DET, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.REMOVE_ASS_OWN_PROP_DET, fwTransaction.getUserDetails().getAppNumber(),
					fwTransaction.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.removeAssetsOwnPropertyDetails() - END", fwTransaction);

	}

	private void getAFBAssetSummary(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.getAFBAssetSummary() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			final CP_APP_IN_ASET_XFER_Collection xferColl = liquidAssetBO.loadAssetXferByAppNum(appNum);
			int sizeColl = 0;
			CP_APP_IN_ASET_XFER_Cargo xferCargo = null;
			if (xferColl != null && !xferColl.isEmpty()) {
				sizeColl = xferColl.size();
			}
			final CP_APP_IN_ASET_XFER_Collection temp = new CP_APP_IN_ASET_XFER_Collection();

			for (int i = 0; i < sizeColl; i++) {
				xferCargo = xferColl.getCargo(i);
				temp.addCargo(xferCargo);
			}

			pageCollection.put(FinancialInfoConstants.CP_APP_IN_ASET_XFER_COLL, temp);
			txnBean.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), Level.INFO, "FinancialAssetsServImpl::getAssetSummary");

		}  catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.getAFBAssetSummary()", txnBean);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.GET_AFBASS_SUMM);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.GET_AFBASS_SUMM, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_AFBASS_SUMM,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.getAFBAssetSummary() - END", txnBean);
	}

	@Transactional
	public void storeAFBAssetInfo(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.storeAFBAssetInfo() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			String appNumber = txnBean.getUserDetails().getAppNumber();
			String srcInd = FinancialInfoConstants.SRC_AB;
			Integer seqNum = null;
			Integer indvSeqNum = 1;
			if (Objects.nonNull(txnBean.getCurrentActionDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())
					&& !txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence()
							.isEmpty()
					&& !txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence()
							.equals("undefined")) {
				indvSeqNum = Integer.parseInt(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.getIndividualSequence());
			}
			if (Objects.nonNull(txnBean.getCurrentActionDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())
					&& !txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence()
							.isEmpty()) {
				seqNum = Integer.parseInt(
						txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			CP_APP_IN_ASET_XFER_Collection assetInfoColl = (CP_APP_IN_ASET_XFER_Collection) pageCollection
					.get("CP_APP_IN_ASET_XFER_Collection");

			if (null != assetInfoColl && !assetInfoColl.isEmpty()) {

				CP_APP_IN_ASET_XFER_Cargo assetInfoCargo;

				assetInfoCargo = assetInfoColl.getCargo(0);
				assetInfoCargo.setApp_num(appNumber);
				assetInfoCargo.setSrc_app_ind(srcInd);
				assetInfoCargo.setIndv_seq_num(indvSeqNum);
				assetInfoCargo.setSeq_num(seqNum);
				if (Objects.isNull(assetInfoCargo.getAsset_val_amt())) {
					assetInfoCargo.setAsset_val_amt(FinancialInfoConstants.ZERO_DOUBLE);
				}
				liquidAssetBO.storeAssetXferDetails(assetInfoCargo);
			}
		}catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.storeAFBAssetInfo()", txnBean);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.STORE_AFB_INFO);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.STORE_AFB_INFO, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_AFB_INFO,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.storeAFBAssetInfo() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), txnBean);

	}

	@Transactional
	public void deleteAFBAssetInfo(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialAssetsServImpl.deleteAFBAssetInfo() - START", fwTxn);
		try {
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			String reqSeqNum = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getCategorySequence();
			String reqIndvSeqNum = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence();
			Integer seqNum = 0;
			Integer zero = 0;
			Integer indvSeqNum = 1;
			if (null != reqSeqNum && !("".equalsIgnoreCase(reqSeqNum))) {
				seqNum = Integer.parseInt(reqSeqNum);
			}
			if (null != reqIndvSeqNum && !("".equalsIgnoreCase(reqIndvSeqNum))) {
				indvSeqNum = Integer.parseInt(reqIndvSeqNum);
			}

			if (!(seqNum.equals(zero) && indvSeqNum.equals(zero))) {
				CP_APP_IN_ASET_XFER_Collection beforeAssetInfoColl = liquidAssetBO
						.loadIndividualAssetXferDetails(appNumber, indvSeqNum, seqNum);

				if (null != beforeAssetInfoColl && !beforeAssetInfoColl.isEmpty()) {
					CP_APP_IN_ASET_XFER_Cargo cargo = beforeAssetInfoColl.getCargo(0);
					if (Objects.nonNull(cargo))
						liquidAssetBO.deleteAssetInfo(cargo);
				}
			}

		}  catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.deleteAFBAssetInfo()", fwTxn);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.DEL_AFB_INFO);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.DEL_AFB_INFO, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.DEL_AFB_INFO,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.deleteAFBAssetInfo() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storePersonalPropertyDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.storePersonalPropertyDetails() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			String categoryType = null;

			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
				categoryType = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			}

			APP_IN_P_PROP_ASET_Collection propAsetColl = (APP_IN_P_PROP_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL);

			APP_IN_P_PROP_ASET_Cargo propAsetCargo = null;
			if (null != propAsetColl && !propAsetColl.isEmpty()) {
				propAsetCargo = propAsetColl.getCargo(0);
				if (null != propAsetCargo) {
					propAsetCargo.setApp_num(appNumber);
					propAsetCargo.setIndv_seq_num(FinancialInfoConstants.ONE);
					propAsetCargo.setSeq_num(FinancialInfoConstants.ONE);
					propAsetCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
					propAsetCargo.setPrsn_prop_aset_typ(categoryType);
					propAsetCargo.setPrsn_prop_amt(propAsetCargo.getPrsn_prop_amt());
					propAsetCargo.setProperty_owe_amt(propAsetCargo.getProperty_owe_amt());
					otherResourDetailsBO.savePersonalPropertyDetails(propAsetCargo);
				}
			}
		}  catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.storePersonalPropertyDetails()", fwTxn);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.STORE_PP_DET);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.STORE_PP_DET, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_PP_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.storePersonalPropertyDetails() - END", fwTxn);
	}

	@Transactional
	public void loadPersonalPropertyDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.loadPersonalPropertyDetails() - END", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			String appNum = txnBean.getUserDetails().getAppNumber();

			APP_IN_P_PROP_ASET_Collection appPropColl = otherResourDetailsBO.loadPersonalPropertyDetails(null, appNum);
			if (Objects.nonNull(appPropColl) && !appPropColl.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL, appPropColl);
			}
			txnBean.setPageCollection(pageCollection);

		}  catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.loadPersonalPropertyDetails()", txnBean);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.LOAD_PP_DET);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.LOAD_PP_DET, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.LOAD_PP_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.loadPersonalPropertyDetails() - END", txnBean);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void removePersonalPropertyDetails(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.removePersonalPropertyDetails() - START", fwTransaction);
		try {

			String appNum = fwTransaction.getUserDetails().getAppNumber();
			String categoryType = null;

			if (Objects.nonNull(fwTransaction.getCurrentActionDetails()) && Objects
					.nonNull(fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
				categoryType = fwTransaction.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.getCategoryType();
			}
			otherResourDetailsBO.removePersonalPropertyDetails(categoryType, appNum);
		}  catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.removePersonalPropertyDetails()", fwTransaction);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.REMOVE_PP_DET);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.REMOVE_PP_DET, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.REMOVE_PP_DET,
					fwTransaction.getUserDetails().getAppNumber(), fwTransaction.getUserDetails().getLoginUserId(),
					true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.removePersonalPropertyDetails() - END", fwTransaction);
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadPersonalPropertyInfo(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.loadPersonalPropertyInfo() - END", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			String appNum = txnBean.getUserDetails().getAppNumber();
			String categoryType = null;
			APP_IN_P_PROP_ASET_Collection coll = (APP_IN_P_PROP_ASET_Collection) txnBean.getPageCollection()
					.get(APP_IN_P_PROP_ASET_COLL);
			if(Objects.nonNull(coll)) {
			APP_IN_P_PROP_ASET_Cargo cargo = coll.getCargo(0);
			if (Objects.nonNull(cargo)) {
				cargo.setPrsn_prop_aset_typ("");
				cargo.setPrsn_prop_amt(null);
				cargo.setProperty_owe_amt(null);
				cargo.setSale_ind("");
				cargo.setChg_dt(null);
			}
			coll.addCargo(cargo);
			}
			pageCollection.put(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL, coll);
			if (Objects.nonNull(txnBean.getCurrentActionDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
				categoryType = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.getCategoryType();
			}

			APP_IN_P_PROP_ASET_Collection appPropColl = otherResourDetailsBO.loadPersonalPropertyDetails(categoryType,
					appNum);
			if (Objects.nonNull(appPropColl) && !appPropColl.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL, appPropColl);
			}
			txnBean.setPageCollection(pageCollection);

		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.loadPersonalPropertyInfo()", txnBean);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.LOAD_PP_INFO);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.LOAD_PP_INFO, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.LOAD_PP_INFO,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.loadPersonalPropertyInfo() - END", txnBean);
	}

	private void storePersonalPropertyDetailsRC(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.storePersonalPropertyDetailsRC() - START", fwTxn);
		try {
			Map<Object, Object> pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			String categoryType = null;
			String seqNum = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getCategorySequence();
			String indvSeqNum = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence();
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
				categoryType = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			}

			APP_IN_P_PROP_ASET_Collection propAsetColl = (APP_IN_P_PROP_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL);

			APP_IN_P_PROP_ASET_Cargo propAsetCargo = null;
			if (null != propAsetColl && !propAsetColl.isEmpty()) {
				propAsetCargo = propAsetColl.getCargo(0);
				if (null != propAsetCargo) {
					propAsetCargo.setApp_num(appNumber);
					propAsetCargo.setIndv_seq_num(Integer.parseInt(indvSeqNum));
					propAsetCargo.setSeq_num(Integer.parseInt(seqNum));
					propAsetCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
					propAsetCargo.setPrsn_prop_aset_typ(categoryType);
					propAsetCargo.setPrsn_prop_amt(propAsetCargo.getPrsn_prop_amt());
					propAsetCargo.setProperty_owe_amt(propAsetCargo.getProperty_owe_amt());
					otherResourDetailsBO.savePersonalPropertyDetails(propAsetCargo);
				}
			}
		}  catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialAssetsServImpl.storePersonalPropertyDetailsRC()", fwTxn);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.STORE_PERSONAL_PROPERTY_DETAILS_RC);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.STORE_PERSONAL_PROPERTY_DETAILS_RC, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STORE_PERSONAL_PROPERTY_DETAILS_RC, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.storePersonalPropertyDetailsRC() - END", fwTxn);
	}

	public void getAssetVehiclePropertySummaryDetails(FwTransaction fwTxn) {
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.getAssetVehiclePropertySummaryDetails() - START", fwTxn);

		final Map<String, Object> pageCollection = fwTxn.getPageCollection();
		UserDetails userDetails = fwTxn.getUserDetails();
		String appNumber = userDetails.getAppNumber();

		try {
			APP_IN_VEH_ASET_Collection appVehColl = vehicleAssetBO.loadVehicleAssetDetails(appNumber);
			pageCollection.put(FinancialInfoConstants.APP_IN_VEH_ASET_COLL, appVehColl);
			fwTxn.getPageCollection().put("VehAssetMaxSeqNum", appInVehAssetRepository.loadUseVehicleAssetDetails(Integer.parseInt(appNumber)).getResults().length);
			
			APP_IN_R_PROP_ASET_Collection appRPropColl = realPropBo.loadPropertyDetails(appNumber);
			pageCollection.put(FinancialInfoConstants.APP_IN_R_PROP_ASET_COLL, appRPropColl);
			fwTxn.getPageCollection().put("RPropAssetMaxSeqNum", appInRealPropertyRepository.getRealPropertyByAppNum(Integer.parseInt(appNumber)).getResults().length);
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in FinancialAssetsServImpl.getAssetVehiclePropertySummaryDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), "getAssetVehiclePropertySummaryDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		} finally {
			fwTxn.setPageCollection(pageCollection);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.getAssetVehiclePropertySummaryDetails() - END", fwTxn);

	}
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storePersonalPropertyDetailsMC(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"FinancialAssetsServImpl.storePersonalPropertyDetailsMC() - START");
		try {
			Map<String, Object> pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			String categoryType = null;
			String seqNum = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getCategorySequence();
			String indvSeqNum = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence();
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
				categoryType = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			}

			APP_IN_P_PROP_ASET_Collection propAsetColl = (APP_IN_P_PROP_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL);
			
			APP_IN_P_PROP_ASET_Cargo propAsetCargo = null;
			if (null != propAsetColl && !propAsetColl.isEmpty()) {
				propAsetCargo = propAsetColl.getCargo(0);
				if (null != propAsetCargo) {
					propAsetCargo.setApp_num(appNumber);
					propAsetCargo.setIndv_seq_num(Integer.parseInt(indvSeqNum));
					propAsetCargo.setSeq_num(Integer.parseInt(seqNum));
					propAsetCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
					propAsetCargo.setPrsn_prop_aset_typ(categoryType);
					
					propAsetCargo.setTransaction_type(propAsetCargo.getTransaction_type());
					propAsetCargo.setPrsn_prop_amt(propAsetCargo.getPrsn_prop_amt());
					propAsetCargo.setChg_dt(propAsetCargo.getChg_dt());
					propAsetCargo.setAdditional_details(propAsetCargo.getAdditional_details());
					otherResourDetailsBO.savePersonalPropertyDetails(propAsetCargo);
				}
			}
		}  catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.STORE_PERSONAL_PROPERTY_DETAILS_MC, fwTxn);
			FwExceptionManager.handleException(e,this.getClass().getName(),
					FinancialInfoConstants.STORE_PERSONAL_PROPERTY_DETAILS_MC, fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialAssetsServImpl.storePersonalPropertyDetailsMC() - END");
	}
	@SuppressWarnings({"squid:S2230","squid:S3776"})
	@Transactional
	private void loadPersonalPropertyDetailsMC(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "FinancialAssetsServImpl.loadPersonalPropertyDetailsMC() - START");
		try {
			Map<String, Object> pageCollection = txnBean.getPageCollection();
			@SuppressWarnings("squid:S6212")
			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			@SuppressWarnings("squid:S6212")
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			@SuppressWarnings("squid:S6212")
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String expenseType = categorySequenceDetails.getCategoryType();

			List<Integer> indvIdList = new ArrayList<>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_ID);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			String pageId = currentPageActionDetails.getPageId();
			APP_IN_P_PROP_ASET_Collection appPropColl=null;
			if(FinancialInfoConstants.MCPPR.equalsIgnoreCase(pageId)) {
				APP_IN_P_PROP_ASET_Cargo[] resultSetCargo=null;
				appPropColl =new APP_IN_P_PROP_ASET_Collection();
				resultSetCargo = appInPPropAssetRepository.getByPAppNum(Integer.parseInt(appNum));
				
				if(resultSetCargo!=null && resultSetCargo.length>0) {
					pageCollection.put("AssetsMaxSeqNum", resultSetCargo.length);					
					for (APP_IN_P_PROP_ASET_Cargo cargo : resultSetCargo) {
						if(cargo!= null && (cargo.getAsset_end_dt() == null || "null".equalsIgnoreCase(cargo.getAsset_end_dt().toString()))) {
							appPropColl.addCargo(cargo);
						}
					}
				}
				
			}else if(FinancialInfoConstants.MCPSS.equalsIgnoreCase(pageId)) {
				appPropColl = appInPPropAssetRepository.getPersonalPropertSummary(Integer.parseInt(appNum), expenseType, indvIdList);
			}

			if (Objects.nonNull(appPropColl) && !appPropColl.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL, appPropColl);
			}
			txnBean.setPageCollection(pageCollection);

		}  catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.LOAD_PERSONAL_PROPERTY_DETAILS_MC, txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), "loadPersonalPropertyDetailsMC",
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"FinancialAssetsServImpl.loadPersonalPropertyDetailsMC() - END");
	}
	@SuppressWarnings({"squid:S2230","squid:S6212"})
	@Transactional
	private void deletePersonalPropertyDetailsMC(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "FinancialAssetsServImpl.deletePersonalPropertyDetailsMC() - START");
		try {
			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			String categoryType = null;
			Integer indvSeqNum = null;
			Integer seqNum = null;
			APP_IN_P_PROP_ASET_Cargo inputCargo=null;
			if(txnBean.getPageCollection() != null && txnBean.getPageCollection().get(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL) != null) {
				APP_IN_P_PROP_ASET_Collection str = (APP_IN_P_PROP_ASET_Collection) txnBean.getPageCollection().get(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL);
				inputCargo = str.getCargo(0);
				categoryType = inputCargo.getPrsn_prop_aset_typ();
				indvSeqNum = inputCargo.getIndv_seq_num();
				seqNum = inputCargo.getSeq_num();
				APP_IN_P_PROP_ASET_Collection existingLqdColl = appInPPropAssetRepository.getByAppNum_IndSeq_SeqNum_Type(Integer.parseInt(appNum),indvSeqNum, seqNum,categoryType);
				if(Objects.nonNull(existingLqdColl) && !existingLqdColl.isEmpty()) {
					APP_IN_P_PROP_ASET_Cargo existingCargo = existingLqdColl.getCargo(0);
					if(Objects.nonNull(existingCargo)) {
						existingCargo.setAsset_end_dt(inputCargo.getAsset_end_dt());
						appInPPropAssetRepository.save(existingCargo);
					}
				}
			}
			
			APP_IN_P_PROP_ASET_Collection appInPersoanllColl = new APP_IN_P_PROP_ASET_Collection();
			APP_IN_P_PROP_ASET_Cargo appInasetCargo = new APP_IN_P_PROP_ASET_Cargo();
			appInasetCargo.setPrsn_prop_aset_typ(categoryType);
			appInPersoanllColl.add(appInasetCargo);
			txnBean.getPageCollection().put(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL, appInPersoanllColl);
		}
      catch (Exception e) {
  		    FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.DELETE_PERSONAL_PROPERTY_DETAILS_MC, txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.DELETE_PERSONAL_PROPERTY_DETAILS_MC, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);

		}
		FwLogger.log(this.getClass(), Level.INFO, "FinancialAssetsServImpl.deletePersonalPropertyDetailsMC() - END");
	}
	
}
