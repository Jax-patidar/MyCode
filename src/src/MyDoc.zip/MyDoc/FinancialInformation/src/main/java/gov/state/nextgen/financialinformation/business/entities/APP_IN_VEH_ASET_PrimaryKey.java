/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

/**
 * This java bean contains the primary keys for the table APP_IN_VEH_ASET
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Thu Feb 01 09:36:48 CST 2007 Modified By: Modified on: PCR#
 */

@Embeddable
public class APP_IN_VEH_ASET_PrimaryKey implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private Integer app_number;
	private Integer indv_seq_num;
	private Integer seq_num;
	
	private String veh_aset_typ;
	
	public Integer getApp_number() {
		return app_number;
	}
	public void setApp_number(Integer app_number) {
		this.app_number = app_number;
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public Integer getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	
	public String getVeh_aset_typ() {
		return veh_aset_typ;
	}
	public void setVeh_aset_typ(String veh_aset_typ) {
		this.veh_aset_typ = veh_aset_typ;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((veh_aset_typ == null) ? 0 : veh_aset_typ.hashCode());
		return result;
	}
	@SuppressWarnings("squid:S3776")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		APP_IN_VEH_ASET_PrimaryKey other = (APP_IN_VEH_ASET_PrimaryKey) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		if (seq_num == null) {
			if (other.seq_num != null)
				return false;
		} else if (!seq_num.equals(other.seq_num))
			return false;
		if (veh_aset_typ == null) {
			if (other.veh_aset_typ != null)
				return false;
		} else if (!veh_aset_typ.equals(other.veh_aset_typ))
			return false;
		return true;
	}
	
	

}