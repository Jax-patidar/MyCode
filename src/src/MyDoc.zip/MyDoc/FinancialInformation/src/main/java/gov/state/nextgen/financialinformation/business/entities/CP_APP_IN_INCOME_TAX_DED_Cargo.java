/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(CP_APP_IN_INCOME_TAX_DED_Id.class)
@Table(name = "CP_APP_IN_INCOME_TAX_DED")
public class CP_APP_IN_INCOME_TAX_DED_Cargo extends AbstractCargo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private Integer indv_seq_num;
	
	private String src_app_ind;
	private Double ecp_id;

	@Column(name="end_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date end_date;

	private Double educator_exp;
	private Double business_exp;
	private Double health_saving_exp;
	private Double moving_exp;
	private Double deductible_self_exp;
	private Double self_sep_exp;
	private Double self_health_exp;
	private Double penalty_exp;
	private Double alimony_exp;
	private Double ira_exp;
	private Double student_loan_exp;
	private Double tution_exp;
	private Double domestic_exp;
	
	@Column(name="change_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_dt;
	@Id
	private Integer seq_num;
	@Transient
	private String fst_name;
	
	private String pay_freq;
	private String exp_pay_desc;
	
	@Id
	private String exp_type;
	
	@Column(name = "inc_tax_calsaws_object")
	private String incTaxCalsawsObject;
	
	@Column(name = "exp_type_desc")
	private String expTypeDesc;

	public String getApp_num() {
		return String.valueOf(app_number);
	}

	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public Double getEcp_id() {
		return ecp_id;
	}

	public void setEcp_id(Double ecp_id) {
		this.ecp_id = ecp_id;
	}

	public Date getEnd_date() {
        return this.end_date!= null ? new Date(end_date.getTime()) : null;
	}

	public void setEnd_date(Date end_date) {
		this.end_date = (end_date == null) ? null : new Date(end_date.getTime());
	}

	public Double getEducator_exp() {
		return educator_exp;
	}

	public void setEducator_exp(Double educator_exp) {
		this.educator_exp = educator_exp;
	}

	public Double getBusiness_exp() {
		return business_exp;
	}

	public void setBusiness_exp(Double business_exp) {
		this.business_exp = business_exp;
	}

	public Double getHealth_saving_exp() {
		return health_saving_exp;
	}

	public void setHealth_saving_exp(Double health_saving_exp) {
		this.health_saving_exp = health_saving_exp;
	}

	public Double getMoving_exp() {
		return moving_exp;
	}

	public void setMoving_exp(Double moving_exp) {
		this.moving_exp = moving_exp;
	}

	public Double getDeductible_self_exp() {
		return deductible_self_exp;
	}

	public void setDeductible_self_exp(Double deductible_self_exp) {
		this.deductible_self_exp = deductible_self_exp;
	}

	public Double getSelf_sep_exp() {
		return self_sep_exp;
	}

	public void setSelf_sep_exp(Double self_sep_exp) {
		this.self_sep_exp = self_sep_exp;
	}

	public Double getSelf_health_exp() {
		return self_health_exp;
	}

	public void setSelf_health_exp(Double self_health_exp) {
		this.self_health_exp = self_health_exp;
	}

	public Double getPenalty_exp() {
		return penalty_exp;
	}

	public void setPenalty_exp(Double penalty_exp) {
		this.penalty_exp = penalty_exp;
	}

	public Double getAlimony_exp() {
		return alimony_exp;
	}

	public void setAlimony_exp(Double alimony_exp) {
		this.alimony_exp = alimony_exp;
	}

	public Double getIra_exp() {
		return ira_exp;
	}

	public void setIra_exp(Double ira_exp) {
		this.ira_exp = ira_exp;
	}

	public Double getStudent_loan_exp() {
		return student_loan_exp;
	}

	public void setStudent_loan_exp(Double student_loan_exp) {
		this.student_loan_exp = student_loan_exp;
	}

	public Double getTution_exp() {
		return tution_exp;
	}

	public void setTution_exp(Double tution_exp) {
		this.tution_exp = tution_exp;
	}

	public Double getDomestic_exp() {
		return domestic_exp;
	}

	public void setDomestic_exp(Double domestic_exp) {
		this.domestic_exp = domestic_exp;
	}

	public Date getChg_dt() {
        return this.chg_dt!= null ? new Date(chg_dt.getTime()) : null;
	}

	public void setChg_dt(Date chg_dt) {
		this.chg_dt = (chg_dt == null) ? null : new Date(chg_dt.getTime());
	}

	public Integer getSeq_num() {
		return seq_num;
	}

	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}

	public String getFst_name() {
		return fst_name;
	}

	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}

	public String getPay_freq() {
		return pay_freq;
	}

	public void setPay_freq(String pay_freq) {
		this.pay_freq = pay_freq;
	}

	public String getExp_pay_desc() {
		return exp_pay_desc;
	}

	public void setExp_pay_desc(String exp_pay_desc) {
		this.exp_pay_desc = exp_pay_desc;
	}
	
	public String getExp_type() {
		return exp_type;
	}

	public void setExp_type(String exp_type) {
		this.exp_type = exp_type;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getIncTaxCalsawsObject() {
		return incTaxCalsawsObject;
	}

	public void setIncTaxCalsawsObject(String incTaxCalsawsObject) {
		this.incTaxCalsawsObject = incTaxCalsawsObject;
	}

	public String getExpTypeDesc() {
		return expTypeDesc;
	}

	public void setExpTypeDesc(String expTypeDesc) {
		this.expTypeDesc = expTypeDesc;
	}
}