package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;
@Embeddable
public class APP_IN_DABL_Key implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String app_num; 
	private Integer indv_seq_num;
	private String src_app_ind;
	private Integer seq_num;
	
	//default constructor
	public APP_IN_DABL_Key() {
		
	}

	/**
	 * @param app_num
	 * @param indv_seq_num
	 * @param src_app_ind
	 * @param seq_num
	 */
	public APP_IN_DABL_Key(String app_num, Integer indv_seq_num, String src_app_ind, Integer seq_num) {
		super();
		this.app_num = app_num;
		this.indv_seq_num = indv_seq_num;
		this.src_app_ind = src_app_ind;
		this.seq_num = seq_num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}

	
	

}
