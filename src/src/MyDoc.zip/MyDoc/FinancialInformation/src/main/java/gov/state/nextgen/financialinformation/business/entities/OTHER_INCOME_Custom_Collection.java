/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class acts as a wrapper for one or many cargos of APP_IN_EMPL
 *
 * @author Architecture Team
 * Creation Date Thu Feb 20 08:13:08 CDT 2007 Modified By: Modified on: PCR#
 */
public class OTHER_INCOME_Custom_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "local:ejb/ejb/gov/state/nextgen/access/business/services/cares/CwwOtherIncomeEJBLocalHome";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final OTHER_INCOME_Custom_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Returns an abstract cargo.
	 */
	public AbstractCargo getAbstractCargo() {
		return (AbstractCargo) get(0);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final OTHER_INCOME_Custom_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final OTHER_INCOME_Custom_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public OTHER_INCOME_Custom_Cargo[] getResults() {
		final OTHER_INCOME_Custom_Cargo[] cbArray = new OTHER_INCOME_Custom_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public OTHER_INCOME_Custom_Cargo getCargo(final int idx) {
		return (OTHER_INCOME_Custom_Cargo) get(idx);
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof OTHER_INCOME_Custom_Cargo[]) {
			final OTHER_INCOME_Custom_Cargo[] cbArray = (OTHER_INCOME_Custom_Cargo[]) obj;
			setResults(cbArray);
		}
	}

	/**
	 * Sets the cargo object to the collection.
	 */
	public void setAbstractCargo(final AbstractCargo aCargo) {
		if (size() == 0) {
			add(aCargo);
		} else {
			set(0, aCargo);
		}
	}

	/**
	 * Returns a particular cargo.
	 *
	 * Creation Date Fri Feb 10 10:12:39 CST 2006
	 * @return gov.state.nextgen.access.business.entities.APP_IN_EMPL_Collection
	 */
	public OTHER_INCOME_Custom_Cargo getResult(final int idx) {
		return (OTHER_INCOME_Custom_Cargo) get(idx);
	}
}