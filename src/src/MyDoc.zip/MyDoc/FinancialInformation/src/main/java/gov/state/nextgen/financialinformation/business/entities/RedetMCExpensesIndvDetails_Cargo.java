package gov.state.nextgen.financialinformation.business.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class RedetMCExpensesIndvDetails_Cargo extends AbstractCargo {

	private static final long serialVersionUID = 1L;

	@JsonProperty("indv_seq_num")
	private Integer indvSeqNum;

	@JsonProperty("seq_num")
	private Integer seqNum;

	private Double paymentAmount;

	private String expenseType;

	private String paymentFrequency;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date divorceDate;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date changeDate;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date endDate;
	
	private String otherExpenseType;

	public Integer getIndvSeqNum() {
		return indvSeqNum;
	}

	public void setIndvSeqNum(Integer indvId) {
		this.indvSeqNum = indvId;
	}

	public Integer getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}

	public Double getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(Double amount) {
		this.paymentAmount = amount;
	}

	public String getPaymentFrequency() {
		return paymentFrequency;
	}

	public void setPaymentFrequency(String frequency) {
		this.paymentFrequency = frequency;
	}

	public String getExpenseType() {
		return expenseType;
	}

	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}

	public Date getDivorceDate() {
		return divorceDate;
	}

	public void setDivorceDate(Date divorceDate) {
		this.divorceDate = divorceDate;
	}

	public Date getChangeDate() {
		return changeDate;
	}

	public void setChangeDate(Date changeDate) {
		this.changeDate = changeDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getOtherExpenseType() {
		return otherExpenseType;
	}

	public void setOtherExpenseType(String otherExpenseType) {
		this.otherExpenseType = otherExpenseType;
	}

	
	
}
