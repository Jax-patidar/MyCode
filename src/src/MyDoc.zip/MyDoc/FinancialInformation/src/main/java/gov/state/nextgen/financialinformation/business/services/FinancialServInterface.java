package gov.state.nextgen.financialinformation.business.services;

import gov.state.nextgen.access.business.entities.FwTransaction;


/**
 * FinancialServInterface will be implemented by every service class
 * 
 * @author tdatta
 *
 */
public interface FinancialServInterface {

	public void callBusinessLogic(String methodName, FwTransaction txnBean);

}
