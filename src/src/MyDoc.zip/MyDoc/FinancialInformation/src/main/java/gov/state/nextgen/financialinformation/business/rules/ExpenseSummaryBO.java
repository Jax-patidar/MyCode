package gov.state.nextgen.financialinformation.business.rules;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_INS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_SNP_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_SNP_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppInHouRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInPrflRepository;
import gov.state.nextgen.financialinformation.data.db2.CP_ABCHS_Repository;
import gov.state.nextgen.financialinformation.data.db2.CP_APP_IN_DEDUCTION_Repository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInIncomeTaxDedRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInMedBillsRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInSnpRepository;


@Service("ExpenseSummaryBO")
public class ExpenseSummaryBO extends AbstractBO{
	
	AppInPrflRepository cpAppInPrflRepository;
	

	
	@Autowired
	AppInHouRepository appInHouRepository;
	
	@Autowired
	CP_ABCHS_Repository cpAbchsRepository;
	
	@Autowired
	CpAppInIncomeTaxDedRepository cpAppInIncomeTaxDedRepository;
	
	@Autowired
	CP_APP_IN_DEDUCTION_Repository deductionRepository;
	
	@Autowired
	CpAppInMedBillsRepository cpAppInMedBillsRepository;
	
	@Autowired
	CpAppInSnpRepository cpAppInSnpRepository;
	

	
	public APP_IN_PRFL_Collection getPrflData(String appNum) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getPrflData() - START");
        try {
        	APP_IN_PRFL_Collection appInPrflColl = new APP_IN_PRFL_Collection();
        	if(appNum != null) {
        		APP_IN_PRFL_Cargo[] appInPrflCargoArray  = cpAppInPrflRepository.getPrflData(appNum);
        		if (appInPrflCargoArray.length > 0) {
        			appInPrflColl.setResults(appInPrflCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getPrflData() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInPrflColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	public APP_INDV_Collection loadIndvData() {

		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.loadAppIndvCollection() - START");
        try {
        	APP_INDV_Collection appIndvColl = new APP_INDV_Collection();
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.loadAppIndvCollection() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appIndvColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	
		
	}

	public APP_IN_HOU_BILLS_Collection getHousingSummaryDetails(String appnum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getHousingSummaryDetails() - START");
        try {
        	APP_IN_HOU_BILLS_Collection appInHouColl = new APP_IN_HOU_BILLS_Collection();
        	if(appnum != null) {
        		APP_IN_HOU_BILLS_Cargo[] appInHouCargoArray  = appInHouRepository.getHousingSummaryDetails(Integer.parseInt(appnum), indvIds);
        		if (appInHouCargoArray.length > 0) {
        			appInHouColl.setResults(appInHouCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getHousingSummaryDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInHouColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	public CP_APP_IN_SNP_Collection getSplNeedPayData(String appnum) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getSplNeedPayData() - START");
        try {
        	CP_APP_IN_SNP_Collection splneedpaycoll = new CP_APP_IN_SNP_Collection();
        	 if (null != appnum ){
        		CP_APP_IN_SNP_Cargo[] splneedpayCargoArray  = cpAppInSnpRepository.getSplNeedsPayData(Integer.parseInt(appnum));
        		if (splneedpayCargoArray.length > 0) {
        			splneedpaycoll.setResults(splneedpayCargoArray);
        		}
        	 }
        	
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getSplNeedPayData() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return splneedpaycoll;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	

	public CP_ABCHS_Collection getCareCostSummaryDetails(String appnum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getCareCostSummaryDetails() - START");
        try {
        	CP_ABCHS_Collection appInCarcostColl = new CP_ABCHS_Collection();
        	if(appnum != null) {
        		CP_ABCHS_Cargo[] appInCarecostCargoArray  = cpAbchsRepository.getCareCostSummaryDetails(Integer.parseInt(appnum), indvIds);
        		if (appInCarecostCargoArray.length > 0) {
        			appInCarcostColl.setResults(appInCarecostCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getCareCostSummaryDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInCarcostColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}

	public CP_APP_IN_INCOME_TAX_DED_Collection getStudentLoanReviewDetails(String appnum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getStudentLoanReviewDetails() - START");
        try {
        	CP_APP_IN_INCOME_TAX_DED_Collection appInTaxColl = new CP_APP_IN_INCOME_TAX_DED_Collection();
        	if(appnum != null) {
        		CP_APP_IN_INCOME_TAX_DED_Cargo[] appInTaxCargoArray  = cpAppInIncomeTaxDedRepository.getStudentLoanReviewDetails(Integer.parseInt(appnum), indvIds);
        		if (appInTaxCargoArray.length > 0) {
        			appInTaxColl.setResults(appInTaxCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getStudentLoanReviewDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInTaxColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}

	public CP_APP_IN_DEDUCTION_Collection getCourtOrderedSummaryDetails(String appnum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getCourtOrderedSummaryDetails() - START");
        try {
        	CP_APP_IN_DEDUCTION_Collection appInDedColl = new CP_APP_IN_DEDUCTION_Collection();
        	if(appnum != null) {
        		CP_APP_IN_DEDUCTION_Cargo[] appInDedCargoArray  = deductionRepository.getCourtOrderedSummaryDetails(Integer.parseInt(appnum), indvIds);
        		if (appInDedCargoArray.length > 0) {
        			appInDedColl.setResults(appInDedCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getCourtOrderedSummaryDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInDedColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}

	public CP_APP_IN_MED_BILLS_Collection getMedicalSummaryDetails(String appnum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getMedicalSummaryDetails() - START");
        try {
        	CP_APP_IN_MED_BILLS_Collection appInDedColl = new CP_APP_IN_MED_BILLS_Collection();
        	if(appnum != null) {
        		CP_APP_IN_MED_BILLS_Cargo[] appInDedCargoArray  = cpAppInMedBillsRepository.getMedicalSummaryDetails(Integer.parseInt(appnum), indvIds);
        		if (appInDedCargoArray.length > 0) {
        			appInDedColl.setResults(appInDedCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getMedicalSummaryDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInDedColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}

	public CP_APP_IN_MED_INS_Collection getHeathInsuranceSummaryDetails(String appnum) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getHeathInsuranceSummaryDetails() - START");
        try {
        	CP_APP_IN_MED_INS_Collection appInDedColl = new CP_APP_IN_MED_INS_Collection();
        	
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getHeathInsuranceSummaryDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInDedColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}
	
	
	public APP_IN_HOU_BILLS_Collection getHouseBillsCollection(String appNum){

		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getHouseBillsCollection() - START");
        try {
        	APP_IN_HOU_BILLS_Collection appInHouColl = null;
        	if(appNum != null) {
        		appInHouColl = appInHouRepository.getHouseBillsCollection(Integer.parseInt(appNum));
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ExpenseSummaryBO.getHouseBillsCollection() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    + " milliseconds");
        	
    		return appInHouColl;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	
	}

}
