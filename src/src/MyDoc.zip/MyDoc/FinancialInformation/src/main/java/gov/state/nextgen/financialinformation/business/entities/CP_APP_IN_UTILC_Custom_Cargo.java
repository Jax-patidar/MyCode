/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class CP_APP_IN_UTILC_Custom_Cargo extends AbstractCargo implements Serializable {

	private static final long serialVersionUID = 1L;
	private String applicationNumber;
	private Integer indivdiualSequenceNumber;
	private String electricityMonthlyAmount;
	private String gasMonthlyAmount;
	private String kerosineMonthlyAmount;
	private String coalMonthlyAmount;
	private String disasterMonthlyAmount;
	private String oilMonthlyAmount;
	private String woodMonthlyAmount;
	private String waterMonthlyAmount;
	private String garbageMonthlyAmount;
	private String installationMonthlyAmount;

	private String telephoneMonthlyAmount;
	private String otherMonthlyAmount;
	private String other2MonthlyAmount;
	private String other3MonthlyAmount;
	private String someoneElsePays;
	private String util_electric_resp;
	private String util_sewage_resp;
	private String util_garbage_resp;
	private String util_phone_resp;
	private String util_gas_resp;
	private String util_water_resp;
	private String util_fuel_resp;
	private String mo_hsld_pay_amt;
	private String util_total_amt;
	
	@Transient
	private String fst_name;

	public String getFst_name() {
		return fst_name;
	}

	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}

	/**
	 * @return the util_total_amt
	 */
	public String getUtil_total_amt() {
		return util_total_amt;
	}

	/**
	 * @param util_total_amt the util_total_amt to set
	 */
	public void setUtil_total_amt(final String util_total_amt) {
		this.util_total_amt = util_total_amt;
	}

	/**
	 * @return the util_electric_resp
	 */
	public String getUtil_electric_resp() {
		return util_electric_resp;
	}

	/**
	 * @param util_electric_resp the util_electric_resp to set
	 */
	public void setUtil_electric_resp(final String util_electric_resp) {
		this.util_electric_resp = util_electric_resp;
	}

	/**
	 * @return the util_sewage_resp
	 */
	public String getUtil_sewage_resp() {
		return util_sewage_resp;
	}

	/**
	 * @param util_sewage_resp the util_sewage_resp to set
	 */
	public void setUtil_sewage_resp(final String util_sewage_resp) {
		this.util_sewage_resp = util_sewage_resp;
	}

	/**
	 * @return the util_garbage_resp
	 */
	public String getUtil_garbage_resp() {
		return util_garbage_resp;
	}

	/**
	 * @param util_garbage_resp the util_garbage_resp to set
	 */
	public void setUtil_garbage_resp(final String util_garbage_resp) {
		this.util_garbage_resp = util_garbage_resp;
	}

	/**
	 * @return the util_phone_resp
	 */
	public String getUtil_phone_resp() {
		return util_phone_resp;
	}

	/**
	 * @param util_phone_resp the util_phone_resp to set
	 */
	public void setUtil_phone_resp(final String util_phone_resp) {
		this.util_phone_resp = util_phone_resp;
	}

	/**
	 * @return the util_gas_resp
	 */
	public String getUtil_gas_resp() {
		return util_gas_resp;
	}

	/**
	 * @param util_gas_resp the util_gas_resp to set
	 */
	public void setUtil_gas_resp(final String util_gas_resp) {
		this.util_gas_resp = util_gas_resp;
	}

	/**
	 * @return the util_water_resp
	 */
	public String getUtil_water_resp() {
		return util_water_resp;
	}

	/**
	 * @param util_water_resp the util_water_resp to set
	 */
	public void setUtil_water_resp(final String util_water_resp) {
		this.util_water_resp = util_water_resp;
	}

	/**
	 * @return the util_fuel_resp
	 */
	public String getUtil_fuel_resp() {
		return util_fuel_resp;
	}

	/**
	 * @param util_fuel_resp the util_fuel_resp to set
	 */
	public void setUtil_fuel_resp(final String util_fuel_resp) {
		this.util_fuel_resp = util_fuel_resp;
	}

	/**
	 * @return the mo_hsld_pay_amt
	 */
	public String getMo_hsld_pay_amt() {
		return mo_hsld_pay_amt;
	}

	/**
	 * @param mo_hsld_pay_amt the mo_hsld_pay_amt to set
	 */
	public void setMo_hsld_pay_amt(final String mo_hsld_pay_amt) {
		this.mo_hsld_pay_amt = mo_hsld_pay_amt;
	}

	/**
	 * @return the applicationNumber
	 */
	public String getApplicationNumber() {
		return applicationNumber;
	}

	/**
	 * @param applicationNumber the applicationNumber to set
	 */
	public void setApplicationNumber(final String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public String getDisasterMonthlyAmount() {
		return disasterMonthlyAmount;
	}

	public void setDisasterMonthlyAmount(final String disasterMonthlyAmount) {
		this.disasterMonthlyAmount = disasterMonthlyAmount;
	}

	/**
	 * @return the indivdiualSequenceNumber
	 */
	public Integer getIndivdiualSequenceNumber() {
		return indivdiualSequenceNumber;
	}

	/**
	 * @param indivdiualSequenceNumber the indivdiualSequenceNumber to set
	 */
	public void setIndivdiualSequenceNumber(final Integer indivdiualSequenceNumber) {
		this.indivdiualSequenceNumber = indivdiualSequenceNumber;
	}

	/**
	 * @return the electricityMonthlyAmount
	 */
	public String getElectricityMonthlyAmount() {
		return electricityMonthlyAmount;
	}

	/**
	 * @param electricityMonthlyAmount the electricityMonthlyAmount to set
	 */
	public void setElectricityMonthlyAmount(final String electricityMonthlyAmount) {
		this.electricityMonthlyAmount = electricityMonthlyAmount;
	}

	/**
	 * @return the gasMonthlyAmount
	 */
	public String getGasMonthlyAmount() {
		return gasMonthlyAmount;
	}

	/**
	 * @param gasMonthlyAmount the gasMonthlyAmount to set
	 */
	public void setGasMonthlyAmount(final String gasMonthlyAmount) {
		this.gasMonthlyAmount = gasMonthlyAmount;
	}

	/**
	 * @return the kerosineMonthlyAmount
	 */
	public String getKerosineMonthlyAmount() {
		return kerosineMonthlyAmount;
	}

	/**
	 * @param kerosineMonthlyAmount the kerosineMonthlyAmount to set
	 */
	public void setKerosineMonthlyAmount(final String kerosineMonthlyAmount) {
		this.kerosineMonthlyAmount = kerosineMonthlyAmount;
	}

	/**
	 * @return the coalMonthlyAmount
	 */
	public String getCoalMonthlyAmount() {
		return coalMonthlyAmount;
	}

	/**
	 * @param coalMonthlyAmount the coalMonthlyAmount to set
	 */
	public void setCoalMonthlyAmount(final String coalMonthlyAmount) {
		this.coalMonthlyAmount = coalMonthlyAmount;
	}

	/**
	 * @return the oilMonthlyAmount
	 */
	public String getOilMonthlyAmount() {
		return oilMonthlyAmount;
	}

	/**
	 * @param oilMonthlyAmount the oilMonthlyAmount to set
	 */
	public void setOilMonthlyAmount(final String oilMonthlyAmount) {
		this.oilMonthlyAmount = oilMonthlyAmount;
	}

	/**
	 * @return the woodMonthlyAmount
	 */
	public String getWoodMonthlyAmount() {
		return woodMonthlyAmount;
	}

	/**
	 * @param woodMonthlyAmount the woodMonthlyAmount to set
	 */
	public void setWoodMonthlyAmount(final String woodMonthlyAmount) {
		this.woodMonthlyAmount = woodMonthlyAmount;
	}

	/**
	 * @return the waterMonthlyAmount
	 */
	public String getWaterMonthlyAmount() {
		return waterMonthlyAmount;
	}

	/**
	 * @param waterMonthlyAmount the waterMonthlyAmount to set
	 */
	public void setWaterMonthlyAmount(final String waterMonthlyAmount) {
		this.waterMonthlyAmount = waterMonthlyAmount;
	}

	/**
	 * @return the garbageMonthlyAmount
	 */
	public String getGarbageMonthlyAmount() {
		return garbageMonthlyAmount;
	}

	/**
	 * @param garbageMonthlyAmount the garbageMonthlyAmount to set
	 */
	public void setGarbageMonthlyAmount(final String garbageMonthlyAmount) {
		this.garbageMonthlyAmount = garbageMonthlyAmount;
	}

	/**
	 * @return the installationMonthlyAmount
	 */
	public String getInstallationMonthlyAmount() {
		return installationMonthlyAmount;
	}

	/**
	 * @param installationMonthlyAmount the installationMonthlyAmount to set
	 */
	public void setInstallationMonthlyAmount(final String installationMonthlyAmount) {
		this.installationMonthlyAmount = installationMonthlyAmount;
	}

	/**
	 * @return the telephoneMonthlyAmount
	 */
	public String getTelephoneMonthlyAmount() {
		return telephoneMonthlyAmount;
	}

	/**
	 * @param telephoneMonthlyAmount the telephoneMonthlyAmount to set
	 */
	public void setTelephoneMonthlyAmount(final String telephoneMonthlyAmount) {
		this.telephoneMonthlyAmount = telephoneMonthlyAmount;
	}

	/**
	 * @return the otherMonthlyAmount
	 */
	public String getOtherMonthlyAmount() {
		return otherMonthlyAmount;
	}

	/**
	 * @param otherMonthlyAmount the otherMonthlyAmount to set
	 */
	public void setOtherMonthlyAmount(final String otherMonthlyAmount) {
		this.otherMonthlyAmount = otherMonthlyAmount;
	}

	/**
	 * @return the other2MonthlyAmount
	 */
	public String getOther2MonthlyAmount() {
		return other2MonthlyAmount;
	}

	/**
	 * @param other2MonthlyAmount the other2MonthlyAmount to set
	 */
	public void setOther2MonthlyAmount(final String other2MonthlyAmount) {
		this.other2MonthlyAmount = other2MonthlyAmount;
	}

	/**
	 * @return the other3MonthlyAmount
	 */
	public String getOther3MonthlyAmount() {
		return other3MonthlyAmount;
	}

	/**
	 * @param other3MonthlyAmount the other3MonthlyAmount to set
	 */
	public void setOther3MonthlyAmount(final String other3MonthlyAmount) {
		this.other3MonthlyAmount = other3MonthlyAmount;
	}

	/**
	 * @return the someoneElsePays
	 */
	public String getSomeoneElsePays() {
		return someoneElsePays;
	}

	/**
	 * @param someoneElsePays the someoneElsePays to set
	 */
	public void setSomeoneElsePays(final String someoneElsePays) {
		this.someoneElsePays = someoneElsePays;
	}

	
	
}
