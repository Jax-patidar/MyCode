package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CP_APP_IN_SNP_Key implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Integer app_number;
	
	
	public CP_APP_IN_SNP_Key() {
		
	}
	
	public CP_APP_IN_SNP_Key(Integer app_num) {
		super();
		this.app_number = app_num;
		
	}
	public Integer getApp_number() {
		return app_number;
	}

	public void setApp_number(Integer app_number) {
		this.app_number = app_number;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CP_APP_IN_SNP_Key other = (CP_APP_IN_SNP_Key) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		
		return true;
	}
	
	

}
