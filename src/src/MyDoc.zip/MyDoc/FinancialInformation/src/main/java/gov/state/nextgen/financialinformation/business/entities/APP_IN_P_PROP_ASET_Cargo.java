/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * This java bean contains the entities of APP_IN_P_PROP_ASET
 *
 **/
@Entity 
@Table(name = "CP_APP_IN_P_PROP_ASSET")
@IdClass(APP_IN_P_PROP_ASET_PrimaryKey.class)
public class APP_IN_P_PROP_ASET_Cargo extends AbstractCargo implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	private String jnt_own_resp;
	@Column(name="person_prop_amt")
	private Double prsn_prop_amt;
	private Double property_owe_amt;
	@Transient
	private String prsn_prop_amt_ind;// Don't need
	@Id
	@Column(name="person_prop_asset_type")
	private String prsn_prop_aset_typ;
	private Date acquired_dt;
	@Transient
	private String business_trade_farming_ind;
	private String rec_cplt_ind;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date asset_end_dt;
	@Transient
	private String prsn_prop_dsc;
	@Transient
	private String loopingQuestion;
	@Transient
	private String ecp_id;

	@Column(name="change_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_dt;
	
	private String wic_request_ind;
	private String sale_ind;
	
	private String transaction_type;
	
	private String additional_details;
	
	@Column(name= "p_prop_calsaws_object")
	private String pPropCalsawsObject;
	
	@Column(name= "prsn_prop_aset_typ_desc")
	private String prsnPropAsetTypDesc;
	
	/**
     * @return the chg_dt
     */
    public Date getChg_dt() {
        return chg_dt;
    }

    /**
     * @param chg_dt the chg_dt to set
     */
    public void setChg_dt(Date chg_dt) {
        this.chg_dt = chg_dt;
    }

	/**
	 * @return the ecp_id
	 */
	public String getEcp_id() {
		return ecp_id;
	}

	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(final String ecp_id) {
		this.ecp_id = ecp_id;
	}

	/**
	 * @return the loopingQuestion
	 */
	public String getLoopingQuestion() {
		return loopingQuestion;
	}

	/**
	 * @param loopingQuestion
	 *            the loopingQuestion to set
	 */
	public void setLoopingQuestion(final String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}

	public Date getAsset_end_dt() {
		return asset_end_dt;
	}

	public void setAsset_end_dt(final Date asset_end_dt) {
		this.asset_end_dt = asset_end_dt;
	}

	// EDSP
	
	private String src_app_ind;

	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * @return the prsn_prop_dsc
	 */
	public String getPrsn_prop_dsc() {
		return prsn_prop_dsc;
	}

	/**
	 * @param prsn_prop_dsc
	 *            the prsn_prop_dsc to set
	 */
	public void setPrsn_prop_dsc(final String prsn_prop_dsc) {
		this.prsn_prop_dsc = prsn_prop_dsc;
	}

	/**
	 * @param src_app_ind
	 *            the src_app_ind to set
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	// EDsp ends

	/**
	 * @return the property_owe_amt
	 */
	public Double getProperty_owe_amt() {
		return property_owe_amt;
	}

	/**
	 * @param property_owe_amt
	 *            the property_owe_amt to set
	 */
	public void setProperty_owe_amt(final Double property_owe_amt) {
		this.property_owe_amt = property_owe_amt;
	}

	/**
	 * @return the acquired_dt
	 */
	public Date getAcquired_dt() {
		return acquired_dt;
	}

	/**
	 * @param acquired_dt
	 *            the acquired_dt to set
	 */
	public void setAcquired_dt(final Date acquired_dt) {
		this.acquired_dt = acquired_dt;
	}

	/**
	 * @return the business_trade_farming_ind
	 */
	public String getBusiness_trade_farming_ind() {
		return business_trade_farming_ind;
	}

	/**
	 * @param business_trade_farming_ind
	 *            the business_trade_farming_ind to set
	 */
	public void setBusiness_trade_farming_ind(final String business_trade_farming_ind) {
		this.business_trade_farming_ind = business_trade_farming_ind;
	}

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * returns the jnt_own_resp value.
	 */
	public String getJnt_own_resp() {
		return jnt_own_resp;
	}

	/**
	 * sets the jnt_own_resp value.
	 */
	public void setJnt_own_resp(final String jnt_own_resp) {
		this.jnt_own_resp = jnt_own_resp;
	}

	/**
	 * returns the prsn_prop_amt value.
	 */
	public Double getPrsn_prop_amt() {
		return prsn_prop_amt;
	}

	/**
	 * sets the prsn_prop_amt value.
	 */
	public void setPrsn_prop_amt(final Double prsn_prop_amt) {
		this.prsn_prop_amt = prsn_prop_amt;
	}

	/**
	 * returns the prsn_prop_amt_ind value.
	 */
	public String getPrsn_prop_amt_ind() {
		return prsn_prop_amt_ind;
	}

	/**
	 * sets the prsn_prop_amt_ind value.
	 */
	public void setPrsn_prop_amt_ind(final String prsn_prop_amt_ind) {
		this.prsn_prop_amt_ind = prsn_prop_amt_ind;
	}

	/**
	 * returns the prsn_prop_aset_typ value.
	 */
	public String getPrsn_prop_aset_typ() {
		return prsn_prop_aset_typ;
	}

	/**
	 * sets the prsn_prop_aset_typ value.
	 */
	public void setPrsn_prop_aset_typ(final String prsn_prop_aset_typ) {
		this.prsn_prop_aset_typ = prsn_prop_aset_typ;
	}

	/**
	 * returns the rec_cplt_ind value.
	 */
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * sets the rec_cplt_ind value.
	 */
	public void setRec_cplt_ind(final String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	
	public String getWic_request_ind() {
		return wic_request_ind;
	}

	public void setWic_request_ind(String wic_request_ind) {
		this.wic_request_ind = wic_request_ind;
	}

	public String getSale_ind() {
		return sale_ind;
	}

	public void setSale_ind(String sale_ind) {
		this.sale_ind = sale_ind;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getAdditional_details() {
		return additional_details;
	}

	public void setAdditional_details(String additional_details) {
		this.additional_details = additional_details;
	}
	
	public String getpPropCalsawsObject() {
		return pPropCalsawsObject;
	}

	public void setpPropCalsawsObject(String pPropCalsawsObject) {
		this.pPropCalsawsObject = pPropCalsawsObject;
	}

	public String getPrsnPropAsetTypDesc() {
		return prsnPropAsetTypDesc;
	}

	public void setPrsnPropAsetTypDesc(String prsnPropAsetTypDesc) {
		this.prsnPropAsetTypDesc = prsnPropAsetTypDesc;
	}

	/**
	 * returns the string value of cargo.
	 */
	public String inspectCargo() {
		return new StringBuilder().append("APP_IN_P_PROP_ASET: ").append("app_num=").append(app_num).append("indv_seq_num=").append(indv_seq_num)
				.append("seq_num=").append(seq_num).append("jnt_own_resp=").append(jnt_own_resp).append("prsn_prop_amt=").append(prsn_prop_amt)
				.append("prsn_prop_amt_ind=").append(prsn_prop_amt_ind).append("prsn_prop_aset_typ=").append(prsn_prop_aset_typ)
				.append("rec_cplt_ind=").append(rec_cplt_ind).append("prsn_prop_dsc=").append(prsn_prop_dsc).append("loopingQuestion=")
				.append(loopingQuestion).append("ecp_id=").append(ecp_id).append("chg_dt=").append(chg_dt).append("wic_request_ind=").append(wic_request_ind).append("sale_ind=").append(sale_ind).toString();
	}

	
}