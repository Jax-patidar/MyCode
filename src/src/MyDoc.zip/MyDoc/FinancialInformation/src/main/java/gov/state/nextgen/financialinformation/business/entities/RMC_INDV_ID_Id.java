/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;



import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * This java bean contains the entities of RMC_INDV_ID
 *
 * @author Architecture Team
 * Creation Date Tue Jun 06 22:08:16 CDT 2006 Modified By: Modified on: PCR#
 */
public class RMC_INDV_ID_Id extends AbstractCargo implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.RMC_INDV_ID";

	private String app_num;
	private String indv_seq_num;
	private String pin_num;

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return app_num;
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_num = app_num;
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public String getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final String indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the pin_num value.
	 */
	public String getPin_num() {
		return pin_num;
	}

	/**
	 * sets the pin_num value.
	 */
	public void setPin_num(final String pin_num) {
		this.pin_num = pin_num;
	}

	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((app_num == null) ? 0 : app_num.trim().hashCode());
		result = (prime * result) + ((indv_seq_num == null) ? 0 : indv_seq_num.trim().hashCode());
		result = (prime * result) + ((pin_num == null) ? 0 : pin_num.trim().hashCode());
		return result;
	}
	

	/**
	 * returns the PACKAGE name.
	 */
	public String getPackage() {
		return PACKAGE;
	}

	

}