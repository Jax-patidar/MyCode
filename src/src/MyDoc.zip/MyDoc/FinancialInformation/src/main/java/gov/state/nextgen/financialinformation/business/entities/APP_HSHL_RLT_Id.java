/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class APP_HSHL_RLT_Id implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -229952865791821390L;
	/**
	 *
	 */
	private String app_num;
	private String ref_indv_seq_num;
	private String src_indv_seq_num;
	private String src_app_ind;
	

	public APP_HSHL_RLT_Id() {
		
	}
	
	public APP_HSHL_RLT_Id(String app_num, String ref_indv_seq_num, String src_indv_seq_num, String src_app_ind) {
		super();
		this.app_num = app_num;
		this.ref_indv_seq_num = ref_indv_seq_num;
		this.src_indv_seq_num = src_indv_seq_num;
		this.src_app_ind = src_app_ind;
	}

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return app_num;
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_num = app_num;
	}

	/**
	 * returns the ref_indv_seq_num value.
	 */
	public String getRef_indv_seq_num() {
		return ref_indv_seq_num;
	}

	/**
	 * sets the ref_indv_seq_num value.
	 */
	public void setRef_indv_seq_num(final String ref_indv_seq_num) {
		this.ref_indv_seq_num = ref_indv_seq_num;
	}

	/**
	 * returns the src_indv_seq_num value.
	 */
	public String getSrc_indv_seq_num() {
		return src_indv_seq_num;
	}

	/**
	 * sets the src_indv_seq_num value.
	 */
	public void setSrc_indv_seq_num(final String src_indv_seq_num) {
		this.src_indv_seq_num = src_indv_seq_num;
	}

	/**
	 * returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	
}
