package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(CP_APP_IN_SNP_Key.class)
@Table(name = "CP_APP_IN_SNP")
public class CP_APP_IN_SNP_Cargo extends AbstractCargo implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	
	private String src_app_ind;
	
	private String special_needs_resp;
	private String special_needs_desc;
	
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getSpecial_needs_resp() {
		return special_needs_resp;
	}
	public void setSpecial_needs_resp(String special_needs_resp) {
		this.special_needs_resp = special_needs_resp;
	}
	public String getSpecial_needs_desc() {
		return special_needs_desc;
	}
	public void setSpecial_needs_desc(String special_needs_desc) {
		this.special_needs_desc = special_needs_desc;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((special_needs_desc == null) ? 0 : special_needs_desc.hashCode());
		result = prime * result + ((special_needs_resp == null) ? 0 : special_needs_resp.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}
	

}
