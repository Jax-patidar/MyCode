package gov.state.nextgen.financialinformation.business.rules;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_BURY_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_BURY_ASET_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppHshlRltRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInBuryAssetRepository;

@Service("BurialAssetBO")
public class BurialAssetBO extends AbstractBO{
	
	private static Logger logger = LoggerFactory.getLogger(BurialAssetBO.class);
	
	private AppHshlRltRepository appHshlRltRepository;
	
	@Autowired
	IReferenceTableManager iref;
	
	private AppInBuryAssetRepository appInBuryAssetRepository;


	public Map loadInstitution() {
		
		logger.info("InstitutionBO.loadInstitution() - START");

		
		final Map pageCollection = new HashMap();
		
		return pageCollection;
	}


	public APP_IN_BURY_ASET_Collection loadIndividualBurialAsetDetails(String appNum, Integer indivSeqNum, Integer seqNum) {

		logger.info("BurialAssetBO.loadIndividualBurialAsetDetails- START");
		try {
			final APP_IN_BURY_ASET_Collection appInBurColl = appInBuryAssetRepository.getByAppNum_IndSeq_SeqNum(appNum, indivSeqNum, seqNum);
			logger.info("BenefitSummaryBO.loadIndividualBurialAsetDetails - END , Time Taken : ");
			return appInBurColl;
		}catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}

	public APP_IN_BURY_ASET_Collection loadBurialAssetDetails() {
		return null;
		}

	public void storeBurialAssetDetails(APP_IN_BURY_ASET_Collection appInBuryCollReq) {

		try {

			if (null!=appInBuryCollReq && !appInBuryCollReq.isEmpty()) {
				appInBuryAssetRepository.save(appInBuryCollReq.getCargo(0));
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
	}


	public void validateBurialAssetDetails(APP_IN_BURY_ASET_Collection appInBuryCollReq, String dob,
			String validateLooping) {

		try {
			final APP_IN_BURY_ASET_Cargo aCargo = appInBuryCollReq.getCargo(0);
			final char[] specialChars = { '-', '\'', '.', ' ' };
			dob = dateRoutine.convertSimpleDateFormat(dob);
			final StringBuilder dateConverter = new StringBuilder();
			final String sAppDate = dob;
			dateConverter.append(sAppDate.substring(6, 10)).append("-").append(sAppDate.substring(0, 2)).append("-").append(sAppDate.substring(3, 5));
			dob = dateConverter.toString();

			final String[] reftabcolVal = new String[1];
			reftabcolVal[0] = iref.getColumnValue("TBAS", 102, aCargo.getBury_aset_typ(), "EN");

			validateDetails(aCargo, specialChars);

			boolean isNumber = false;
	

			if (appMgr.isFieldEmpty(aCargo.getBurial_resource_type()) || (aCargo.getBurial_resource_type() == null)
					|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(aCargo.getBurial_resource_type())) {
				addMessageCode("00853");
			}

			if (null!=(aCargo.getAcquired_dt())) {
				if (!appMgr.validateDate(aCargo.getAcquired_dt())) {
					addMessageCode("10430");
				} else if (appMgr.isDateBeforeDate(aCargo.getAcquired_dt(), fwDate.getDate(dob))) {
					addMessageCode("10431");
				} else if (appMgr.isDateAfterDate(aCargo.getAcquired_dt(), fwDate.getDate())) {
					final Object[] error = new Object[] { new FwMessageTextLabel("3018170"), new FwMessageTextLabel("3018071") };
					// EDSP CP team: text message is changed
					this.addMessageWithFieldValues("90722", error);
				}
			}
			if (((aCargo.getLoopingQuestion() == null) || FwConstants.EMPTY_STRING.equals(aCargo.getLoopingQuestion().trim()))
					&& FwConstants.YES.equals(validateLooping)) {
				addMessageCode("00266");
			}
		}catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}

	}


	private void validateDetails(final APP_IN_BURY_ASET_Cargo aCargo, final char[] specialChars) {
		try {
		if (!appMgr.isFieldEmpty(aCargo.getBury_asset_institution_name())
				&& !appMgr.isSpecialAlphaNumeric(aCargo.getBury_asset_institution_name(), specialChars)) {
			final Object[] error = new Object[] { new FwMessageTextLabel("3018198") };
			this.addMessageWithFieldValues("10226", error);
		}

		if (!appMgr.isFieldEmpty(aCargo.getBury_asset_l1_addr()) && !appMgr.isSpecialAlphaNumeric(aCargo.getBury_asset_l1_addr(), specialChars)) {
			addMessageCode("10227");
		}

		if (!appMgr.isFieldEmpty(aCargo.getBury_asset_city_addr())
				&& !appMgr.isSpecialAlphaNumeric(aCargo.getBury_asset_city_addr(), specialChars)) {
			addMessageCode("10228");
		}

		if (!appMgr.isFieldEmpty(aCargo.getBury_asset_zip5_addr())) {
			if (!appMgr.isInteger(aCargo.getBury_asset_zip5_addr())) {
				addMessageCode("90748");
			} else if (!((aCargo.getBury_asset_zip5_addr().length() == 5) || (aCargo.getBury_asset_zip5_addr().length() == 9))) {
				addMessageCode("90748");
			}

			else if (("00000".equals(aCargo.getBury_asset_zip5_addr()) || "000000000".equals(aCargo.getBury_asset_zip5_addr()))) {
				addMessageCode("10232");
			}

		}
		} catch (final Exception e) {
			logger.error("Error occured in BurialAssetBO.validateDetails()", e);
		}
	}

	

}
