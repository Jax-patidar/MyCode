package gov.state.nextgen.financialinformation.business.rules;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Collection;
import gov.state.nextgen.financialinformation.data.db2.CpAppSelfeRepository;

@Service("SelfEmploymentBO")
public class SelfEmploymentBO extends AbstractBO {

	@Autowired
	private CpAppSelfeRepository cpAppSelfeRepository;

	public APP_IN_SELFE_Collection loadSelfEmploymentDetails(String appNum, Integer indv_seq_num, Integer seq_num) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SelfEmploymentBO.loadSelfEmploymentDetails() - START");
		try {
			final APP_IN_SELFE_Collection appInSelfeColl = new APP_IN_SELFE_Collection();

			if (appNum != null && indv_seq_num != null && seq_num != null) {

				final APP_IN_SELFE_Cargo[] appInSelfeCargoArray = cpAppSelfeRepository.loadSelfEmploymentDetails(Integer.parseInt(appNum),indv_seq_num, seq_num);
				appInSelfeColl.setResults(appInSelfeCargoArray);
			} 	

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SelfEmploymentBO.loadSelfEmploymentDetails() - END"
					+ (System.currentTimeMillis() - startTime) + AppConstants.SPACE + AppConstants.MILLISECONDS);

			return appInSelfeColl;

		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

	}

	public long getMaxEmplSeqNumber(String appNum, Integer indv_seq_num) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SelfEmploymentBO.getMaxEmplSeqNumber() - START");
		final Map sqlMap = new HashMap();
		int maxSeqNum = 0;
		try {
			sqlMap.put(FwConstants.SQL_IND, "sql-RM33");

			if (appNum != null && indv_seq_num != null) {
				maxSeqNum = cpAppSelfeRepository.getMaxEmplSeqNumber(Integer.parseInt(appNum), indv_seq_num);
				
			} 

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SelfEmploymentBO.getMaxEmplSeqNumber() - END"
					+ (System.currentTimeMillis() - startTime) + AppConstants.SPACE + AppConstants.MILLISECONDS);

			return maxSeqNum;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

	}

	public void storeSelfEmploymentDetails(final APP_IN_SELFE_Collection storeAppInSelfeCollection) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SelfEmploymentBO.storeSelfEmploymentDetails() - START");
		APP_IN_SELFE_Collection appInUpColl = new APP_IN_SELFE_Collection();
		APP_IN_SELFE_Cargo cargo = new APP_IN_SELFE_Cargo();
		APP_IN_SELFE_Cargo resCargo = new APP_IN_SELFE_Cargo();
		try {
			
			if (null!=storeAppInSelfeCollection && !storeAppInSelfeCollection.isEmpty()) {
				for(int i=0; i<storeAppInSelfeCollection.size();i++) {
					cargo = storeAppInSelfeCollection.getCargo(i);
					resCargo = cpAppSelfeRepository.save(cargo);
						appInUpColl.addCargo(resCargo);
				}
			}

		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "SelfEmploymentBO.storeSelfEmploymentDetails() - END , Time Taken : " + (System.currentTimeMillis() - startTime)
				+ " milliseconds");
	

	}

}
