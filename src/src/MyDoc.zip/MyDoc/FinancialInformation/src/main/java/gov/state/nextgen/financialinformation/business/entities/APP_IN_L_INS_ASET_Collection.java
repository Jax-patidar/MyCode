/**
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.rmi.RemoteException;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * @author khuskumari
 *
 */
public class APP_IN_L_INS_ASET_Collection extends AbstractCollection{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.financialinformation.business.entities.APP_IN_L_INS_ASET";
	
	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}
	
	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_L_INS_ASET_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_L_INS_ASET_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_L_INS_ASET_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_L_INS_ASET_Cargo[] getResults() {
		final APP_IN_L_INS_ASET_Cargo[] cbArray = new APP_IN_L_INS_ASET_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_L_INS_ASET_Cargo getCargo(final int idx) {
		return (APP_IN_L_INS_ASET_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_L_INS_ASET_Cargo[] cloneResults() {
		final APP_IN_L_INS_ASET_Cargo[] rescargo = new APP_IN_L_INS_ASET_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_L_INS_ASET_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_L_INS_ASET_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setEcp_id(cargo.getEcp_id());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setSeq_num(cargo.getSeq_num());
			rescargo[i].setIns_co_city_adr(cargo.getIns_co_city_adr());
			rescargo[i].setIns_co_l1_adr(cargo.getIns_co_l1_adr());
			rescargo[i].setIns_co_l2_adr(cargo.getIns_co_l2_adr());
			rescargo[i].setIns_co_nam(cargo.getIns_co_nam());
			rescargo[i].setIns_co_sta_adr(cargo.getIns_co_sta_adr());
			rescargo[i].setIns_co_zip_adr(cargo.getIns_co_zip_adr());
			rescargo[i].setLife_ins_aset_typ(cargo.getLife_ins_aset_typ());
			rescargo[i].setLife_ins_f_amt_ind(cargo.getLife_ins_f_amt_ind());
			rescargo[i].setLife_ins_face_amt(cargo.getLife_ins_face_amt());
			rescargo[i].setLife_ins_plcy_num(cargo.getLife_ins_plcy_num());
			rescargo[i].setLife_ins_s_amt_ind(cargo.getLife_ins_s_amt_ind());
			rescargo[i].setLife_ins_surr_amt(cargo.getLife_ins_surr_amt());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setAcquired_dt(cargo.getAcquired_dt());
			rescargo[i].setAsset_end_dt(cargo.getAsset_end_dt());
			rescargo[i].setCvrg_resp(cargo.getCvrg_resp());
			rescargo[i].setInsurance_company_phone_number(cargo.getInsurance_company_phone_number());
			rescargo[i].setJnt_own_resp(cargo.getJnt_own_resp());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
			rescargo[i].setChg_dt(cargo.getChg_dt());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_L_INS_ASET_Cargo[]) {
			final APP_IN_L_INS_ASET_Cargo[] cbArray = (APP_IN_L_INS_ASET_Cargo[]) obj;
			setResults(cbArray);
		}
	}

}
