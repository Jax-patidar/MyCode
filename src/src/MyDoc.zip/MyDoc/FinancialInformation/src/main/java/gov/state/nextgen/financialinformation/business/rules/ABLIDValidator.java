/**
 * 
 */
package gov.state.nextgen.financialinformation.business.rules;

import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_L_INS_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_BEF_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_LIF_INS_CVRG_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_LIF_INS_CVRG_Collection;

/**
 * @author khuskumari
 *
 */
@Service("ABLIDValidator")
public class ABLIDValidator extends AbstractBO{
	
	public FwMessageList messageList = new FwMessageList();
	
	private static final String ERROR_00705 = "00705";
	
	private static final String ERROR_3018181 = "3018181";
	
	private static final String ERROR_10239 = "10239";
	
	private static final String ERROR_3018182 = "3018182";
	
	

	public void validatePageContents(APP_IN_L_INS_ASET_Cargo abLifeInsureCargo, boolean amtEntered, String valueType) {
		
		FwLogger.log(this.getClass(), Level.INFO, "ABLIDValidator.validatePageContents() - START");

		try {
			if ("face".equals(valueType)) {
				if (!appMgr.isCurrency(abLifeInsureCargo.getLife_ins_face_amt())) {
					// EDSP Starts
					validateLifeInsuFaceAmt(abLifeInsureCargo);
					// EDSP Ends
				} else if (!appMgr.isValidAmountLimit(Float.toString(abLifeInsureCargo.getLife_ins_face_amt()))) {
					messageList.addMessageToList(addMessageCode("98040"));
				}

				if (1 == (abLifeInsureCargo.getLife_ins_f_amt_ind()) && amtEntered) {
					final Object[] error = new Object[] { new FwMessageTextLabel("32502") };
					messageList.addMessageToList(addMessageWithFieldValues("20013", error));
				}
			} else {
				validateLifeInsurOtherType(abLifeInsureCargo, amtEntered);
			}
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
		
	}

	private void validateLifeInsurOtherType(APP_IN_L_INS_ASET_Cargo abLifeInsureCargo, boolean amtEntered) {
		try {
		if (!appMgr.isCurrency(abLifeInsureCargo.getLife_ins_surr_amt())) {
			validateLifeInsurSurrAmt(abLifeInsureCargo);
		} else if (!appMgr.isValidAmountLimit(Float.toString(abLifeInsureCargo.getLife_ins_surr_amt()))) {
			messageList.addMessageToList(addMessageCode("98042"));
		}

		if (1 == (abLifeInsureCargo.getLife_ins_s_amt_ind()) && amtEntered) {
			final Object[] error = new Object[] { new FwMessageTextLabel("32651") };
			messageList.addMessageToList(addMessageWithFieldValues("20013", error));
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateLifeInsurSurrAmt(APP_IN_L_INS_ASET_Cargo abLifeInsureCargo) {
		try {
		if ("OT".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
			messageList.addMessageToList(addMessageCode("LID07"));
		} else if ("WH".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
			messageList.addMessageToList(addMessageCode("LID05"));
		} else if ("GT".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
			messageList.addMessageToList(addMessageCode("LID09"));
		} else if ("TM".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
			messageList.addMessageToList(addMessageCode("LID11"));
		} else {
			messageList.addMessageToList(addMessageCode("98041"));
		}
		} catch (final Exception e) {
			throw e;
		}
		// EDSP Ends
	}

	private void validateLifeInsuFaceAmt(APP_IN_L_INS_ASET_Cargo abLifeInsureCargo) {
		try {
		if ("OT".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
			messageList.addMessageToList(addMessageCode("LID04"));
		} else if ("WH".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
			messageList.addMessageToList(addMessageCode("LID01"));
		} else if ("GT".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
			messageList.addMessageToList(addMessageCode("LID03"));
		} else if ("TM".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
			messageList.addMessageToList(addMessageCode("LID02"));
		} else {
			messageList.addMessageToList(addMessageCode("98039"));
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	public void validateAddressContents(APP_IN_L_INS_ASET_Cargo abLifeInsureCargo) {
		
		FwLogger.log(this.getClass(), Level.INFO, "ABLIDValidator.validateAddressContents() - START");

		try {
			
			if (!appMgr.validateAddress(abLifeInsureCargo.getIns_co_l1_adr()) || !appMgr.validateAddress(abLifeInsureCargo.getIns_co_l2_adr())) {				
				messageList.addMessageToList(addMessageCode("90759"));
			}
			if (!appMgr.isAlphaWithSpace(abLifeInsureCargo.getIns_co_city_adr())) {				
				messageList.addMessageToList(addMessageCode("10228"));
			}
			final String zipcode = abLifeInsureCargo.getIns_co_zip_adr();
			if ((zipcode != null) && (zipcode.length() > 0)) {
				if (!appMgr.isInteger(zipcode)) {
					messageList.addMessageToList(addMessageCode("90748"));
				} else if ((zipcode != null) && (Integer.parseInt(zipcode) == 0)) {
					messageList.addMessageToList(addMessageCode("90501"));
				} else if ((zipcode != null) && (zipcode.length() != 5)) {
					messageList.addMessageToList(addMessageCode("10505"));
				}
			}
			if (!messageList.containsMessage("00019")
					&& abLifeInsureCargo.getAddr_zip4() != null
					&& !"".equals(abLifeInsureCargo.getAddr_zip4().trim())
					&& !abLifeInsureCargo.getAddr_zip4().matches("\\d+")) {
				messageList.addMessageToList(addMessageCode("00019"));
			}
			
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
		
	}

	public void validateRestOfPageContents(APP_IN_L_INS_ASET_Cargo abLifeInsureCargo) {

		FwLogger.log(this.getClass(), Level.INFO, "ABLIDValidator.validateRestOfPageContents() - START");
		final char[] specialChars = { '-', '\'', '.' };

		try {
			if (!appMgr.isFieldEmpty(abLifeInsureCargo.getLife_ins_plcy_num()) && !appMgr.isSpecialAlphaNumeric(abLifeInsureCargo.getLife_ins_plcy_num(), specialChars)) {


				messageList.addMessageToList(addMessageCode("90496"));
				
			}
			if (!appMgr.isFieldEmpty(abLifeInsureCargo.getIns_co_nam()) && !appMgr.isSpecialAlphaNumeric(abLifeInsureCargo.getIns_co_nam(), specialChars)) {

				messageList.addMessageToList(addMessageCode("90517"));
				
			}
			if (!appMgr.isFieldEmpty(abLifeInsureCargo.getInsurance_company_phone_number())) {
				validateInsureCompPhnNum(abLifeInsureCargo);
			}
			if ((abLifeInsureCargo.getLooping_ind() == null) || FwConstants.EMPTY_STRING.equals(abLifeInsureCargo.getLooping_ind().trim())) {

				if ("OT".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
					messageList.addMessageToList(addMessageCode("LID12"));
				} else if ("WH".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
					messageList.addMessageToList(addMessageCode("LID06"));
				} else if ("GT".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
					messageList.addMessageToList(addMessageCode("LID09"));
				} else if ("TM".equals(abLifeInsureCargo.getLife_ins_aset_typ())) {
					messageList.addMessageToList(addMessageCode("LID08"));
				} else {
					messageList.addMessageToList(addMessageCode("00002"));
				}
			}
			
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
		
	}

	private void validateInsureCompPhnNum(APP_IN_L_INS_ASET_Cargo abLifeInsureCargo) {
		try {
		if (!appMgr.isInteger(abLifeInsureCargo.getInsurance_company_phone_number())) {
			messageList.addMessageToList(addMessageCode("90926"));
		} else if (!appMgr.validatePhone(abLifeInsureCargo.getInsurance_company_phone_number())) {
			messageList.addMessageToList(addMessageCode("90926"));
		} else if ((abLifeInsureCargo.getInsurance_company_phone_number().charAt(0)) == '0') {
			messageList.addMessageToList(addMessageCode("10238"));
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	public void validateJointOwnerInformation(APP_IN_JNT_OWN_Collection appInJntOwnColl) {

		FwLogger.log(this.getClass(), Level.INFO, "ABLIDValidator.validateJointOwnerInformation() - START");

		try {
			if ((appInJntOwnColl != null) && (!appInJntOwnColl.isEmpty())) {
				APP_IN_JNT_OWN_Cargo jntOwnCargo = null;
				double total = 0;
				for (int i = 0; i < appInJntOwnColl.size(); i++) {
					total = validateJntOwnerInfo(appInJntOwnColl, total, i);

				}
				if (total > 100 && !messageList.containsMessage(ERROR_00705)) {

					messageList.addMessageToList(addMessageCode(ERROR_00705));
					
				}
			}
			
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
		
	}

	private double validateJntOwnerInfo(APP_IN_JNT_OWN_Collection appInJntOwnColl, double total, int i) {
		try {
		APP_IN_JNT_OWN_Cargo jntOwnCargo;
		jntOwnCargo = appInJntOwnColl.getCargo(i);
		final String share = Double.toString(jntOwnCargo.getJnt_own_share());

		if ((null != share) && (FwConstants.EMPTY_STRING.equals(share.trim()) || !appMgr.isInteger(share))) {
			if (!messageList.containsMessage("00691")) {
				messageList.addMessageToList(addMessageCode("00691"));
			}
		} else if ((null != share) && (Double.parseDouble(share) > 100) && !messageList.containsMessage(ERROR_00705)) {

			messageList.addMessageToList(addMessageCode(ERROR_00705));
			

		}
		try {
			total += Double.parseDouble(share);
		} catch (final Exception e) {
			total += 0;
		}
		return total;
		} catch (final Exception e) {
			throw e;
		}
	}
	@SuppressWarnings("squid:S3776")
	public void validateInsuredPersonInformation(CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCol) {

		FwLogger.log(this.getClass(), Level.INFO, "ABLIDValidator.validateInsuredPersonInformation() - START");

		try {
			final char[] specialChars = { '-', '\'', '.', ' ' };
			if ((appInLifInsCol != null) && (!appInLifInsCol.isEmpty())) {
				final int appLifInsCollSize = appInLifInsCol.size();
				CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsCargo = null;
				final Integer someOneOutSideHome = getSomeOneOutSideHomeResponse(appInLifInsCol);
				boolean fstNameOneFlg = false;
				boolean lstNameOneFlg = false;
				boolean fstNameTwoFlg = false;
				boolean lstNameTwoFlg = false;

				boolean jntOwnSeq2 = false;
				for (int i = 0; i < appLifInsCollSize; i++) {
					appInLifInsCargo = appInLifInsCol.getCargo(i);
					// first name validations for the first person
					if ((someOneOutSideHome != 0) && (appInLifInsCargo.getCovered_seq_num() != null)
							&& 1 == (appInLifInsCargo.getCovered_seq_num())) {
						fstNameOneFlg = validateFirstName(specialChars, appInLifInsCargo, fstNameOneFlg);
						lstNameOneFlg = validateLastName(specialChars, appInLifInsCargo, lstNameOneFlg);

					}
					// name validations for the second person
					else if ((someOneOutSideHome != 0) && (appInLifInsCargo.getCovered_seq_num() != null)
							&& 2 == (appInLifInsCargo.getCovered_seq_num())) {
						jntOwnSeq2 = true;
						fstNameTwoFlg = validateFirstName(specialChars, appInLifInsCargo, fstNameTwoFlg);
						lstNameTwoFlg = validateLastName(specialChars, appInLifInsCargo, lstNameTwoFlg);
					}

					if ((someOneOutSideHome == 0) && (appInLifInsCargo.getCovered_seq_num() != null)
							&& 1 == (appInLifInsCargo.getCovered_seq_num())) {
						fstNameOneFlg = validateFirstName(specialChars, appInLifInsCargo, fstNameOneFlg);
						lstNameOneFlg = validateLastName(specialChars, appInLifInsCargo, lstNameOneFlg);
					} else if ((someOneOutSideHome == 0) && (appInLifInsCargo.getCovered_seq_num() != null)
							&& 2==(appInLifInsCargo.getCovered_seq_num())) {
						jntOwnSeq2 = true;
						fstNameTwoFlg = validateFirstName(specialChars, appInLifInsCargo, fstNameTwoFlg);
						lstNameTwoFlg = validateLastName(specialChars, appInLifInsCargo, lstNameTwoFlg);
					} 
				}
				validateInsurPrsnInfo(fstNameOneFlg, lstNameOneFlg, fstNameTwoFlg, lstNameTwoFlg, jntOwnSeq2);

			}
			
			
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
		
	}

	private boolean validateLastName(final char[] specialChars, CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsCargo,
			boolean lstNameOneFlg) {
		try {
		if (appMgr.isFieldEmpty(appInLifInsCargo.getLast_name())) {
			lstNameOneFlg = true;
		} else {
			if (!appMgr.isSpecialAlphaNumeric(appInLifInsCargo.getLast_name(), specialChars)) {
				final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018182) };
				messageList.addMessageToList(addMessageWithFieldValues(ERROR_10239, error));
			}
		}
		return lstNameOneFlg;
		} catch (final Exception e) {
			throw e;
		}
	}

	private boolean validateFirstName(final char[] specialChars, CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsCargo,
			boolean fstNameOneFlg) {
		try {
		if (appMgr.isFieldEmpty(appInLifInsCargo.getFirst_name())) {
			fstNameOneFlg = true;
		} else {
			if (!appMgr.isSpecialAlphaNumeric(appInLifInsCargo.getFirst_name(), specialChars)) {
				final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018181) };
				messageList.addMessageToList(addMessageWithFieldValues(ERROR_10239, error));
			}
		}
		return fstNameOneFlg;
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateInsurPrsnInfo(boolean fstNameOneFlg, boolean lstNameOneFlg, boolean fstNameTwoFlg,
			boolean lstNameTwoFlg, boolean jntOwnSeq2) {
		try {
		if ((fstNameTwoFlg && !lstNameTwoFlg) || (fstNameOneFlg && !lstNameOneFlg)) {
			final Object[] error = new Object[] { new FwMessageTextLabel("30000") };
			messageList.addMessageToList(addMessageWithFieldValues("10065", error));
		}
		if ((!fstNameTwoFlg && lstNameTwoFlg) || (!fstNameOneFlg && lstNameOneFlg)) {
			final Object[] error = new Object[] { new FwMessageTextLabel("30022") };
			messageList.addMessageToList(addMessageWithFieldValues("10065", error));
		}
		if (!jntOwnSeq2 && fstNameOneFlg && lstNameOneFlg) {
			messageList.addMessageToList(addMessageCode("20102"));
		}
		} catch (final Exception e) {
			throw e;
		}
	}
	
	/**
	 * This method is used to get someone out side home response information
	 *
	 * @param aAppInLifInsColl
	 * @return
	 */
	public Integer getSomeOneOutSideHomeResponse(final CP_APP_IN_LIF_INS_CVRG_Collection aAppInLifInsColl) {
		Integer someOneOutSideHomeResp = 0;
		int collSize = 0;
		try {
		if ((aAppInLifInsColl != null) && (!aAppInLifInsColl.isEmpty())) {
			collSize = aAppInLifInsColl.size();
		}
		for (int j = 0; j < collSize; j++) {
			final CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsCargo = aAppInLifInsColl.getCargo(j);
			if (appInLifInsCargo.getCovered_indv_seq_num() != null) {
				someOneOutSideHomeResp = appInLifInsCargo.getCovered_indv_seq_num();
				break;
			}
		}
		return someOneOutSideHomeResp;
		} catch (final Exception e) {
			throw e;
		}
	}


}
