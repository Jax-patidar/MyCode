package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_R_PROP_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_VEH_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;
import gov.state.nextgen.financialinformation.business.rules.ABJobIncomeBO;
import gov.state.nextgen.financialinformation.business.rules.ExpenseSummaryBO;
import gov.state.nextgen.financialinformation.business.rules.LiquidAssetBO;
import gov.state.nextgen.financialinformation.business.rules.RealPropertyBO;
import gov.state.nextgen.financialinformation.business.rules.VehicleAssetBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.framework.business.model.UserDetails;

@Service("FinancialInfoServiceImpl")
public class FinancialDocumentsInformationServiceImpl implements FinancialServInterface {

	private static final String GET_SERV_CLASS = "getServiceClass";

	@Autowired
	private ABJobIncomeBO abJobIncomeBO;

	@Autowired
	private RealPropertyBO realPropBo;

	@Autowired
	private LiquidAssetBO liquidAssetBO;
	@Autowired
	private VehicleAssetBO vehicleAssetBO;

	@Autowired
	private JobIncomeServiceImpl jobIncomeServiceImpl;
	@Autowired
	private OtherIncomeServImpl otherIncomeServImpl;
	@Autowired
	private SpecialNeedsServiceImpl specialNeedsServiceImpl;
	@Autowired
	private FinancialAssetsServImpl financialAssetsServImpl;

	@Autowired
	private HousingExpenseServImpl housingExpenseServImpl;

	@Autowired
	OtherExpensesServImpl otherExpensesServImpl;

	@Autowired
	private ExpenseSummaryBO expenseSummaryBO;

	@Autowired
	protected ApplicationContext applicationContext;
	@Autowired
	private CareCostsServImpl careCostsServImpl;
	@Autowired
	private LiquidAssetsServImpl liquidAssetsServImpl;
	@Autowired
	private VehicleAssetsServiceImpl vehicleAssetsServiceImpl;

	private static final String INDV_IDS = "indvIds";
	private static final String INDV_ID = "indvIds";
	
	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {

		switch (methodName) {

		case FinancialInfoConstants.GETFINANCIALMODULEREQUIREDDOCUMENTS:
			this.getFinancialModuleRequiredDocuments(fwTxn);
			break;
		case FinancialInfoConstants.GETFINANCIALMODULESUMMARYINFO:
			this.getFinancialSummaryForRAC(fwTxn);
			break;
		default:
			break;
		}
	}

	@SuppressWarnings("squid:S2230")
	@Transactional
	private void getFinancialModuleRequiredDocuments(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialDocumentsInformationServiceImpl.getFinancialModuleRequiredDocuments() - START", fwTxn);
		try {
			String flowMode = null;
			if(fwTxn.getPageCollection().containsKey(FinancialInfoConstants.MODE))
			{
				flowMode = (String) fwTxn.getPageCollection().get(FinancialInfoConstants.MODE);
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, 
						"FinancialDocumentsInformationServiceImpl.getFinancialModuleRequiredDocuments() flowMode "+flowMode);
			}
			else
			{
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, 
						"FinancialDocumentsInformationServiceImpl.getFinancialModuleRequiredDocuments() flowMode no mode key");
			}
			FinancialServInterface service = (FinancialServInterface) applicationContext.getBean("DCFExpensesService");
			service.callBusinessLogic("loadDCFFinancialSummaryDetails", fwTxn);

			getIncomeSummaryDetails(fwTxn);
			getBankStatementSummaryDetails(fwTxn);
			getVehicleAssetSummaryDetails(fwTxn);
            //commented as part of enhancement CSPM-35846(Should not display at all on Recommended Documents)- START
			//getHouseholdExpensesOtherThanRent(fwTxn);
			//getAdultOrChildCareExpenses(fwTxn);
            //commented as part of enhancement CSPM-35846(Should not display at all on Recommended Documents)- END
			if(flowMode != null && FinancialInfoConstants.MC_MODE.equalsIgnoreCase(flowMode)) {
				getHouseholdExpensesOtherThanRent(fwTxn);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"FinancialDocumentsInformationServiceImpl.getFinancialModuleRequiredDocuments() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime), fwTxn);

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialDocumentsInformationServiceImpl.getFinancialModuleRequiredDocuments()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.GETFINANCIALMODULEREQUIREDDOCUMENTS, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);

		}
	}

	private void getIncomeSummaryDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialDocumentsInformationServiceImpl.getIncomeSummaryDetails() - START", fwTxn);
		try {
			Map<Object, Object> pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();
			ArrayList<Integer> indvList = (ArrayList<Integer>) pageCollection.get(FinancialInfoConstants.INDVLIST);
			APP_IN_EMPL_Collection appInEmplCollection;
			APP_IN_SELFE_Collection appInSelfEmplCollection;
			APP_IN_UEI_Collection appInUEICollection;

			appInEmplCollection = abJobIncomeBO.getAppInEmplCollection(appNum, indvList);

			if (Objects.nonNull(appInEmplCollection) && !(appInEmplCollection.isEmpty())
					&& appInEmplCollection.size() > 0) {
				pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_COLL, appInEmplCollection);
			}

			appInSelfEmplCollection = abJobIncomeBO.getAppInSelfEmplCollection(appNum, indvList);

			if (Objects.nonNull(appInSelfEmplCollection) && !(appInSelfEmplCollection.isEmpty())
					&& appInSelfEmplCollection.size() > 0) {
				pageCollection.put(FinancialInfoConstants.APP_IN_SELFE_COLL, appInSelfEmplCollection);
			}

			appInUEICollection = abJobIncomeBO.getUnearnedIncome(appNum, indvList);

			if (Objects.nonNull(appInUEICollection) && !(appInUEICollection.isEmpty())
					&& appInUEICollection.size() > 0) {
				pageCollection.put(FinancialInfoConstants.APP_IN_UEI_COLL, appInUEICollection);
			}

			fwTxn.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialDocumentsInformationServiceImpl.getIncomeSummaryDetails()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERV_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, "getIncomeSummaryDetails:End", fe);
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialDocumentsInformationServiceImpl.getIncomeSummaryDetails() - END", fwTxn);

	}

	public void getRentLeaseMortgageSummaryDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialDocumentsInformationServiceImpl.getRentLeaseMortgageSummaryDetails() - START", fwTxn);

		try {
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();

			APP_IN_R_PROP_ASET_Collection appPropColl = realPropBo.loadRealPropertyDetails(appNum);
			fwTxn.getPageCollection().put(FinancialInfoConstants.APP_IN_R_PROP_ASET_COLL, appPropColl);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialDocumentsInformationServiceImpl.getRentLeaseMortgageSummaryDetails()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERV_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialDocumentsInformationServiceImpl.getRentLeaseMortgageSummaryDetails() - END", fwTxn);


	}

	private void getBankStatementSummaryDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialDocumentsInformationServiceImpl.getBankStatementSummaryDetails() - START", fwTxn);
		try {
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();
			APP_IN_LQD_ASET_Collection appInColl;
			Map<Object, Object> pageCollection = fwTxn.getPageCollection();
			ArrayList<Integer> indvList = (ArrayList<Integer>) pageCollection.get(FinancialInfoConstants.INDVLIST);
			appInColl = liquidAssetBO.loadAccountSummarydetails(appNum, indvList);
			fwTxn.getPageCollection().put(FinancialInfoConstants.APP_IN_LQD_ASET_COLL, appInColl);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialDocumentsInformationServiceImpl.getBankStatementSummaryDetails()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERV_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialDocumentsInformationServiceImpl.getBankStatementSummaryDetails() - END", fwTxn);
	}

	private void getVehicleAssetSummaryDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialDocumentsInformationServiceImpl.getVehicleAssetSummaryDetails() - START", fwTxn);
		try {
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();
			APP_IN_VEH_ASET_Collection appVehColl;
			Map<Object, Object> pageCollection = fwTxn.getPageCollection();
			ArrayList<Integer> indvList = (ArrayList<Integer>) pageCollection.get(FinancialInfoConstants.INDVLIST);

			appVehColl = vehicleAssetBO.loadOwnVehicleSummary(appNum, indvList);

			fwTxn.getPageCollection().put(FinancialInfoConstants.APP_IN_VEH_ASET_COLL, appVehColl);

		} catch (final Exception e) {
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERV_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getVehicleAssetSummaryDetails()", fwTxn);
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialDocumentsInformationServiceImpl.getVehicleAssetSummaryDetails() - END", fwTxn);

	}

	private void getFinancialSummaryForRAC(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialDocumentsInformationServiceImpl.getFinancialSummaryForRAC() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			pageCollection.put(FinancialInfoConstants.MODE, FinancialInfoConstants.RAC);
			
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			ExpenseSummaryServiceImpl obj = new ExpenseSummaryServiceImpl();
			if (fwTxn.getCurrentActionDetails() != null && fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails() != null
					&& "".equals(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType()))
			{
				fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().setCategoryType(null);
			}
			if (CollectionUtils.isNullOrEmpty(indvIds)) {
				List<String> indvIdList = new ArrayList<String>();
				FwTransaction fwTxnDummy = new FwTransaction();
				fwTxnDummy.setCurrentActionDetails(fwTxn.getCurrentActionDetails());
				fwTxnDummy.setUserDetails(fwTxn.getUserDetails());
				APP_INDV_Collection appIndvCollection=obj.getIndvList(fwTxnDummy);
				
				if(appIndvCollection != null && !appIndvCollection.isEmpty() && appIndvCollection.size() > 0) {
					for (int i = 0; i < appIndvCollection.size(); i++) {
						APP_INDV_Cargo appIndvCargo1 = (APP_INDV_Cargo) appIndvCollection.get(i);
						indvIdList.add(appIndvCargo1.getIndv_seq_num().toString());
					}	
					fwTxn.getPageCollection().put(INDV_ID, indvIdList);
				}
			}
			
			jobIncomeServiceImpl.getLostJobDetail(fwTxn);
			jobIncomeServiceImpl.getSelfEmploymentDetail(fwTxn);
			otherIncomeServImpl.getOtherIncomeDetail(fwTxn);
			financialAssetsServImpl.loadPersonalPropertyDetails(fwTxn);
			financialAssetsServImpl.loadAssetsOwnPropertyDetails(fwTxn);
			financialAssetsServImpl.getAssetSummaryDetails(fwTxn);
			housingExpenseServImpl.getHousingExpensesSummary(fwTxn);
			specialNeedsServiceImpl.getSpecialNeeds(fwTxn);
			otherExpensesServImpl.getMedicalExpenseDetails(fwTxn);
			otherExpensesServImpl.get60OrDisabilityDetails(fwTxn);
			careCostsServImpl.loadCareCostSummaryInformation(fwTxn);
			otherExpensesServImpl.getDependentCareDetail(fwTxn);
			otherExpensesServImpl.loadAlimonyStLoanForRacSummary(fwTxn);
			liquidAssetsServImpl.getAccountInfoDetailsRAC(fwTxn);
			vehicleAssetsServiceImpl.loadAssetsUseVehicleDetailsRAC(fwTxn);
			jobIncomeServiceImpl.loadChangeInIncomeDetailsRAC(fwTxn);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"FinancialDocumentsInformationServiceImpl.getFinancialSummaryForRAC() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + " milliseconds", fwTxn);

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialDocumentsInformationServiceImpl.getFinancialSummaryForRAC()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.GETFINANCIALMODULESUMMARYINFO, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);

		}
	}

	private void getHouseholdExpensesOtherThanRent(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialInformationServiceImpl.getHouseholdExpensesOtherThanRent() - START", fwTxn);
		try {
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();
			APP_IN_HOU_BILLS_Collection appInHouseBillsCollection;
			Map<Object, Object> pageCollection = fwTxn.getPageCollection();
			ArrayList<Integer> indvList = (ArrayList<Integer>) pageCollection.get(FinancialInfoConstants.INDVLIST);
			appInHouseBillsCollection = expenseSummaryBO.getHousingSummaryDetails(appNum, indvList);
			fwTxn.getPageCollection().put(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION,
					appInHouseBillsCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in FinancialDocumentsInformationServiceImpl.getHouseholdExpensesOtherThanRent()", fwTxn);
			final FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(GET_SERV_CLASS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"FinancialInformationServiceImpl.getHouseholdExpensesOtherThanRent() - END", fwTxn);

	}
	
	private void getAdultOrChildCareExpenses(FwTransaction fwTxn) {
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "FinancialDocumentsInformationServiceImpl.getAdultOrChildCareExpenses() - START", fwTxn);
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			ArrayList<Integer> indvList = (ArrayList<Integer>) fwTxn.getPageCollection().get(FinancialInfoConstants.INDVLIST);
			CP_ABCHS_Collection  cpAbchsCollection=expenseSummaryBO.getCareCostSummaryDetails(appNumber, indvList);
			fwTxn.getPageCollection().put(FinancialInfoConstants.CP_ABCHS_COLLECTION, cpAbchsCollection);
			
		} catch (FwException fe) {
			FwLogger.log(this.getClass(), Level.ERROR, "getAdultOrChildCareExpenses", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					"getAdultOrChildCareExpenses", fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		
	}

}
