/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;



import java.io.Serializable;

import javax.persistence.Id;

import gov.state.nextgen.access.business.entities.AbstractCargo;


public class APP_IN_RM_BRD_INCM_Cargo extends AbstractCargo implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private String app_num;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	@Id
	private String src_app_ind;
	private String brd_incm_amt;
	private String brd_incm_ind;
	private String brder_sw;
	private String chg_eff_dt;
	private String paid_for_qty;
	private String payr_indv_seq_num;
	private String room_incm_amt;
	private String room_incm_ind;
	private String roomer_sw;

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return app_num;
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * returns the brd_incm_amt value.
	 */
	public String getBrd_incm_amt() {
		return displayFormatter.getNumberFormat(brd_incm_amt);
	}

	/**
	 * returns the brd_incm_ind value.
	 */
	public String getBrd_incm_ind() {
		return brd_incm_ind;
	}

	/**
	 * returns the brder_sw value.
	 */
	public String getBrder_sw() {
		return brder_sw;
	}

	/**
	 * returns the chg_eff_dt value.
	 */
	public String getChg_eff_dt() {
		return chg_eff_dt;
	}

	/**
	 * returns the paid_for_qty value.
	 */
	public String getPaid_for_qty() {
		return paid_for_qty;
	}

	/**
	 * returns the payr_indv_seq_num value.
	 */
	public String getPayr_indv_seq_num() {
		return payr_indv_seq_num;
	}

	/**
	 * returns the room_incm_amt value.
	 */
	public String getRoom_incm_amt() {
		return displayFormatter.getNumberFormat(room_incm_amt);
	}

	/**
	 * returns the room_incm_ind value.
	 */
	public String getRoom_incm_ind() {
		return room_incm_ind;
	}

	/**
	 * returns the roomer_sw value.
	 */
	public String getRoomer_sw() {
		return roomer_sw;
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_num = app_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * sets the brd_incm_amt value.
	 */
	public void setBrd_incm_amt(final String brd_incm_amt) {
		this.brd_incm_amt = brd_incm_amt;
	}

	/**
	 * sets the brd_incm_ind value.
	 */
	public void setBrd_incm_ind(final String brd_incm_ind) {
		this.brd_incm_ind = brd_incm_ind;
	}

	/**
	 * sets the brder_sw value.
	 */
	public void setBrder_sw(final String brder_sw) {
		this.brder_sw = brder_sw;
	}

	/**
	 * sets the chg_eff_dt value.
	 */
	public void setChg_eff_dt(final String chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}

	/**
	 * sets the paid_for_qty value.
	 */
	public void setPaid_for_qty(final String paid_for_qty) {
		this.paid_for_qty = paid_for_qty;
	}

	/**
	 * sets the payr_indv_seq_num value.
	 */
	public void setPayr_indv_seq_num(final String payr_indv_seq_num) {
		this.payr_indv_seq_num = payr_indv_seq_num;
	}

	/**
	 * sets the room_incm_amt value.
	 */
	public void setRoom_incm_amt(final String room_incm_amt) {
		this.room_incm_amt = room_incm_amt;
	}

	/**
	 * sets the room_incm_ind value.
	 */
	public void setRoom_incm_ind(final String room_incm_ind) {
		this.room_incm_ind = room_incm_ind;
	}

	/**
	 * sets the roomer_sw value.
	 */
	public void setRoomer_sw(final String roomer_sw) {
		this.roomer_sw = roomer_sw;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((app_num == null) ? 0 : app_num.trim().hashCode());
		result = (prime * result) + ((brd_incm_amt == null) ? 0 : brd_incm_amt.trim().hashCode());
		result = (prime * result) + ((brd_incm_ind == null) ? 0 : brd_incm_ind.trim().hashCode());
		result = (prime * result) + ((brder_sw == null) ? 0 : brder_sw.trim().hashCode());
		result = (prime * result) + ((chg_eff_dt == null) ? 0 : chg_eff_dt.trim().hashCode());
		result = (prime * result) + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = (prime * result) + ((paid_for_qty == null) ? 0 : paid_for_qty.trim().hashCode());
		result = (prime * result) + ((payr_indv_seq_num == null) ? 0 : payr_indv_seq_num.trim().hashCode());
		result = (prime * result) + ((room_incm_amt == null) ? 0 : room_incm_amt.trim().hashCode());
		result = (prime * result) + ((room_incm_ind == null) ? 0 : room_incm_ind.trim().hashCode());
		result = (prime * result) + ((roomer_sw == null) ? 0 : roomer_sw.trim().hashCode());
		result = (prime * result) + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = (prime * result) + ((src_app_ind == null) ? 0 : src_app_ind.trim().hashCode());
		return result;
	}

	
}