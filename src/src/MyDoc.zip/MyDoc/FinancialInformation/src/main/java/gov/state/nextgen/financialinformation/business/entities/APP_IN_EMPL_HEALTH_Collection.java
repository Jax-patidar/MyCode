/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class acts as a wrapper for one or many cargos Created By: Muahammad
 * Ghafoor
 */
public class APP_IN_EMPL_HEALTH_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.APP_IN_EMPL_HEALTH";


	public void addCargo(final APP_IN_EMPL_HEALTH_Cargo appInHlthCargo) {
		add(appInHlthCargo);
	}

	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	public APP_IN_EMPL_HEALTH_Cargo getCargo() {
		if (size() == 0) {
			add(new APP_IN_EMPL_HEALTH_Cargo());
		}
		return (APP_IN_EMPL_HEALTH_Cargo) get(0);
	}

	public APP_IN_EMPL_HEALTH_Cargo getCargo(final int idx) {
		return (APP_IN_EMPL_HEALTH_Cargo) get(idx);
	}

	public void setCargo(final APP_IN_EMPL_HEALTH_Cargo newCargo) {
		if (size() == 0) {
			add(newCargo);
		} else {
			set(0, newCargo);
		}
	}

	/**
	 * Returns an abstract cargo.
	 *
	 *
	 * @return gov.state.nextgen.access.business.entities.AbstractCargo
	 */
	public AbstractCargo getAbstractCargo() {
		return getCargo();
	}

	/**
	 * Sets abstract cargo.
	 *
	 *
	 * @param cargo
	 *            The Cargo to set
	 */

	public void setAbstractCargo(final AbstractCargo cargo) {
		setCargo((APP_IN_EMPL_HEALTH_Cargo) cargo);
	}

	/**
	 * Sets cargo array into collection.
	 *
	 * 6
	 *
	 * @param cbArray
	 *            The cbArray to set
	 */

	public void setResults(final APP_IN_EMPL_HEALTH_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets a cargo into particular index of the collection
	 *
	 *
	 * @param cb
	 *            The cbarray to set
	 * @param idx
	 *            The idx to set
	 */

	public void setResults(final int idx, final APP_IN_EMPL_HEALTH_Cargo cb) {
		set(idx, cb);
	}

	/**
	 * Sets a cargo into particular index of the collection
	 *
	 *
	 * @param obj
	 *            The cbarray to set
	 */

	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_EMPL_HEALTH_Cargo[]) {
			final APP_IN_EMPL_HEALTH_Cargo[] cbArray = (APP_IN_EMPL_HEALTH_Cargo[]) obj;
			for (int i = 0; i < cbArray.length; i++) {
				add(cbArray[i]);
			}
		}
	}

	/**
	 * Returns cargo array.
	 *
	 *
	 * @return
	 *         gov.state.nextgen.access.business.entities.APP_IN_MEDCR_Collection
	 *         []
	 */
	public APP_IN_EMPL_HEALTH_Cargo[] getResults() {
		final APP_IN_EMPL_HEALTH_Cargo[] cbArray = new APP_IN_EMPL_HEALTH_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * Returns a particular cargo.
	 *
	 *
	 * @return
	 *         gov.state.nextgen.access.business.entities.APP_IN_MEDCR_Collection
	 */
	public APP_IN_EMPL_HEALTH_Cargo getResult(final int idx) {
		return (APP_IN_EMPL_HEALTH_Cargo) get(idx);
	}

	/**
	 * Returns size of a collection.
	 *
	 *
	 * @return int
	 */
	public int getResultsSize() {
		return size();
	}

}
