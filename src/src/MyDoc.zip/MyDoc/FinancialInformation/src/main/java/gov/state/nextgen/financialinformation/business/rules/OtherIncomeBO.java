package gov.state.nextgen.financialinformation.business.rules;

import gov.state.nextgen.financialinformation.data.db2.AppInUieRepository;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.util.DateRoutine;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "OtherIncomeBO")
public class OtherIncomeBO extends AbstractBO {

	/**
	 * Constructor
	 */

	@Autowired
	private AppInUieRepository appInUieRepository;
	
	private static final String DATE_FORMAT = "MM/dd/yyyy";
	
	private static final String MILLI = " milliseconds";
	
	private static final String ERROR_98058 = "98058"; 
	
	private static final String COMMENT = "validatePageContents";
	
	private static final String NAME = "Tulika";
	
	private static final String ERROR_3018069 = "3018069"; 
	
	private static final String ERROR_90461 = "90461"; 

	private SimpleDateFormat sf = new SimpleDateFormat(DATE_FORMAT);

	/**
	 * Method stores other income details
	 *
	 * @param appInUeiColl income details records
	 */
	public void storeOtherIncomeDetails(final APP_IN_UEI_Collection appInUeiColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.storeOtherIncomeDetails() - START");
		try {
			if (!appInUeiColl.isEmpty()) {
				appInUieRepository.saveAll(appInUeiColl);

			}
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherIncomeBO.storeOtherIncomeDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLI);
	}

	/**
	 * Inserts Exsiting details on database.
	 *
	 * @param appInUeiColl records to be insert
	 */
	public void insertExistingDetails(final APP_IN_UEI_Collection appInUeiColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.insertExistingDetails() - START");
		try {
			if (!appInUeiColl.isEmpty()) {
				appInUieRepository.saveAll(appInUeiColl);
			}
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.insertExistingDetails() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime) + MILLI);
	}

	/**
	 * Method splites other income collection
	 *
	 * @param emplColl        employment collection
	 * @param recordIndicator indicator
	 * @return null
	 */
	public APP_IN_UEI_Cargo splitOtherIncColl(final APP_IN_UEI_Collection emplColl, final String recordIndicator) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.splitOtherIncColl() - START");
		try {
			if ((emplColl != null) && !emplColl.isEmpty()) {
				final int emplCollSize = emplColl.size();
				APP_IN_UEI_Cargo emplCargo = null;
				for (int i = 0; i < emplCollSize; i++) {
					emplCargo = emplColl.getCargo(i);
					if (emplCargo.getSrc_app_ind().equals(recordIndicator)) {
						return emplColl.getCargo(i);
					}
				}

			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.splitOtherIncColl() - END , Time Taken : "
					+ (System.currentTimeMillis() - startTime) + MILLI);
			return null;
		} catch (final Exception e) {
			throw e;
		}

	}

	/**
	 * Method get max employment seq number
	 * 
	 * @param aAppNum    application number
	 * @param indvSeqNum individual sequence number
	 * @return highest Employment sequence number.
	 */
	public int getMaxEmplSeqNumber(final String aAppNum, final Integer indvSeqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.getMaxEmplSeqNumber() - START");

		int maxSeqNum = 0;
		try {
			final Long res = appInUieRepository.getMaxUtilitySeqNumber(Integer.parseInt(aAppNum), indvSeqNum);
			if (null != res) {
				maxSeqNum = Integer.parseInt(res.toString());
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"OtherIncomeBO.getMaxEmplSeqNumber() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLI);
			return maxSeqNum;
		} catch (final Exception e) {
			throw e;
		}

	}

	/**
	 * Method validates page content
	 *
	 * @param howMuch       unnecessary parameter
	 * @param appInUeiCargo cargo
	 * @param userEndInd    user
	 * @param amtEntered    inout ammount
	 */
	public FwMessageList validatePageContents(final Double howMuch, final APP_IN_UEI_Cargo appInUeiCargo,
			final short userEndInd, final boolean amtEntered) {
		FwMessageList messageList = new FwMessageList();
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.validatePageContents() - START");
		try {

			final DateRoutine dateRoutine = DateRoutine.getInstance();
			dateRoutine.addDaysToDate(fwDate.getDate(), 30);
			final String startDate = appInUeiCargo.getUei_beg_dt().toString();
			final String endDate = appInUeiCargo.getUei_end_dt().toString();
			
			
			
			if (appMgr.isFieldEmpty(appInUeiCargo.getUei_end_dt().toString())) {
				messageList.addMessageToList(addMessageCode(ERROR_98058));
				
			} else if (!appMgr.validateDate(appInUeiCargo.getUei_end_dt())
					&& !appInUeiCargo.getUei_end_dt().toString().trim().equals(AppConstants.HIGH_DATE)) {
				messageList.addMessageToList(addMessageCode(ERROR_98058));
				
			} else if (null!=appInUeiCargo.getUei_end_dt() && appInUeiCargo.getUei_end_dt().toString().trim().equals(AppConstants.HIGH_DATE)) {
				messageList.addMessageToList(addMessageCode(ERROR_98058));
				

			} else if ((startDate != null) && !startDate.equals(AppConstants.HIGH_DATE)
					&& appMgr.isDateBeforeDate(endDate, startDate)) {
				final Object[] error = new Object[] { new FwMessageTextLabel("3018363"),
						new FwMessageTextLabel("3019045") };
				this.addMessageWithFieldValues("10434", error);
				
			}

			final Date fourMonthDate = dateRoutine.addDaysToDate(fwDate.getDate(), 120);
			if (appMgr.isDateAfterDate(appInUeiCargo.getUei_end_dt(), fourMonthDate)) {
				messageList.addMessageToList(addMessageCode("99240"));
			}

		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.validatePageContents() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime) + MILLI);

		return messageList;
	}

	public FwMessageList validateChangePageContents(final String howMuch, final APP_IN_UEI_Cargo appInUeiCargo,
			final short userEndInd, final boolean isLoopingQuestionShown,
			final String loopingAnswer) {
		
		FwMessageList fwMessageList=new FwMessageList();
		final long startTime = System.currentTimeMillis();
		final char[] specialChars = { '.', '-', '\'' };
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.validateChangePageContents() - START");
		try {

			final DateRoutine dateRoutine = DateRoutine.getInstance();
			dateRoutine.addDaysToDate(fwDate.getDate(), 30);

			getErrorCode(appInUeiCargo.getUei_typ());
			if (userEndInd != 1) {
				validateUeiDet(appInUeiCargo, fwMessageList);
				validateUeiAmt(howMuch, appInUeiCargo, fwMessageList);

				validateUeiFreq(appInUeiCargo, isLoopingQuestionShown, loopingAnswer, fwMessageList, specialChars);

				if (appInUeiCargo.getChg_dt() != null) {
					validateUeiChgDate(appInUeiCargo, fwMessageList);
				}

			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"OtherIncomeBO.validateChangePageContents() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLI);
			
			return fwMessageList;
		} catch (final Exception e) {
			throw e;
		}
		
	}

	private void validateUeiChgDate(final APP_IN_UEI_Cargo appInUeiCargo, FwMessageList fwMessageList) {
		try {
		if (null == appInUeiCargo.getChg_dt()) {
			fwMessageList.addMessageToList(addMessageCode("99368"));
		}
		if (null != (appInUeiCargo.getChg_dt()) && !appMgr.validateDate(appInUeiCargo.getChg_dt())) {
			fwMessageList.addMessageToList(addMessageCode("99365"));
		}
		if (appMgr.isDateBeforeDate(sf.format(appInUeiCargo.getChg_dt()), "01/01/1880")) {
			fwMessageList.addMessageToList(addMessageCode("99366"));
		}
		java.util.Date nxtMnthLastDt = getNxtMnthlastDt();

		if (appMgr.isDateAfterDate(appInUeiCargo.getChg_dt(), nxtMnthLastDt)) {
			fwMessageList.addMessageToList(addMessageCode("99367"));
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateUeiDet(final APP_IN_UEI_Cargo appInUeiCargo, FwMessageList fwMessageList) {
		try {
		validateUeiType(appInUeiCargo, fwMessageList);
		
			if ((appInUeiCargo.getUei_beg_dt() == null)) {
				final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018069) };
				fwMessageList.addMessageToList(this.addMessageWithFieldValues(ERROR_90461, error));
			}
	
			String ueiBegDt = sf.format(appInUeiCargo.getUei_beg_dt());
			if (!appMgr.isFieldEmpty(ueiBegDt)) {
	
				if (!appMgr.validateDate(ueiBegDt)) {
					final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018069) };
					fwMessageList.addMessageToList(addMessageWithFieldValues(ERROR_90461, error));
				}
	
			}
		
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateUeiFreq(final APP_IN_UEI_Cargo appInUeiCargo, final boolean isLoopingQuestionShown,
			final String loopingAnswer, FwMessageList fwMessageList, final char[] specialChars) {
		try {
		if ((appInUeiCargo.getFreq_cd() == null)
				|| appInUeiCargo.getFreq_cd().equals(AppConstants.SELECT_DEFAULT_OPTION)) {
			final String name = "";
			final Object[] error = new Object[] { name };
			fwMessageList.addMessageToList(addMessageWithFieldValues("00324", error));
		} else if (((FinancialInfoConstants.UEI_TYPE1_INCOME.contains(appInUeiCargo.getUei_typ()))
				|| (FinancialInfoConstants.UEI_TYPE1_INCOME.contains(appInUeiCargo.getUei_Sub_Type())))
				&& (!"MO".equals(appInUeiCargo.getFreq_cd()))) {
			fwMessageList.addMessageToList(addMessageCode("9588"));
		}

		if (isLoopingQuestionShown && loopingAnswer == null) {
			
				fwMessageList.addMessageToList(addMessageCode("00327"));
			
		}

		if (appInUeiCargo.getUei_claim_num() != null && !appInUeiCargo.getUei_claim_num().isEmpty() && !appMgr.isSpecialAlphaNumeric(appInUeiCargo.getUei_claim_num(), specialChars)) {
			
				final Object[] error = new Object[] { new FwMessageTextLabel("800000508") };
				fwMessageList.addMessageToList(addMessageWithFieldValues("10446", error));
			
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateUeiAmt(final String howMuch, final APP_IN_UEI_Cargo appInUeiCargo,
			FwMessageList fwMessageList) {
		try {
		if ((appInUeiCargo.getUei_amt() == null) || null == (appInUeiCargo.getUei_amt())) {
			fwMessageList.addMessageToList(addMessageCode("00325"));
		}

		if (!appMgr.isCurrency(howMuch)) {
			fwMessageList.addMessageToList(addMessageCode("90711"));

		} else if (!appMgr.isValidAmountLimit(howMuch)) {
			fwMessageList.addMessageToList(addMessageCode("90735"));

		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateUeiType(final APP_IN_UEI_Cargo appInUeiCargo, FwMessageList fwMessageList) {
		if ((appInUeiCargo.getUei_typ() != null)
				&& appInUeiCargo.getUei_typ().equals(AppConstants.INC_OTH_VET_BNFT) && ((appInUeiCargo.getUei_Sub_Type() == null)
					|| appInUeiCargo.getUei_Sub_Type().equals(AppConstants.SELECT_DEFAULT_OPTION))) {
			
				final String name = NAME;
				final Object[] error = new Object[] { name };
				fwMessageList.addMessageToList(this.addMessageWithFieldValues("00321", error));
			
		}

		if ((appInUeiCargo.getUei_typ() != null)
				&& appInUeiCargo.getUei_typ().equals(AppConstants.INC_OTH_OTH_INC) && ((appInUeiCargo.getOthr_incm_src() == null)
					|| appInUeiCargo.getOthr_incm_src().equals(AppConstants.EMPTY_STRING))) {
			
				final String name = NAME;
				final Object[] error = new Object[] { name };
				fwMessageList.addMessageToList(this.addMessageWithFieldValues("00320", error));
		}
	}

	private String getErrorCode(final String ueiTyp) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.getErrorCode() - START");
		String error = FwConstants.EMPTY_STRING;
		if ("DI".equals(ueiTyp)) {
			error = "36059";
		} else if ("DV".equals(ueiTyp)) {
			error = "36060";
		} else if ("IN".equals(ueiTyp)) {
			error = "36061";
		} else if ("MA".equals(ueiTyp)) {
			error = "36062";
		} else if ("MO".equals(ueiTyp)) {
			error = "36063";
		} else if ("OT".equals(ueiTyp)) {
			error = "36064";
		} else if ("PE".equals(ueiTyp)) {
			error = "36065";
		} else if ("PS".equals(ueiTyp)) {
			error = "36066";
		} else if ("RE".equals(ueiTyp)) {
			error = "36067";
		} 
			error = validateErrorCode(ueiTyp, error);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.getErrorCode() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime) + MILLI);
		return error;
	}

	private String validateErrorCode(final String ueiTyp, String error) {
		if ("RR".equals(ueiTyp)) {
			error = "36068";
		} else if ("SI".equals(ueiTyp)) {
			error = "36069";
		} else if ("SS".equals(ueiTyp)) {
			error = "36074";
		} else if ("TP".equals(ueiTyp)) {
			error = "36075";
		} else if ("UN".equals(ueiTyp)) {
			error = "36076";
		} else if ("VE".equals(ueiTyp)) {
			error = "36077";
		} else if ("WC".equals(ueiTyp)) {
			error = "36078";
		} else if ("SF".equals(ueiTyp)) {
			error = "3019078";
		} else if ("CS".equals(ueiTyp)) {
			error = "36072";
		} else if ("SA".equals(ueiTyp)) {
			error = "36073";
		}
		return error;
	}
	
	public FwMessageList validateNewPageContents(final String howMuch, final APP_IN_UEI_Cargo appInUeiCargo, final boolean amtEntered, final boolean isLoopingQuestionShown, final String loopingAnswer) throws Exception {
		FwMessageList fwMessageList=new FwMessageList();
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.validateNewPageContents() - START");
		final DateRoutine dateRoutine = DateRoutine.getInstance();
		dateRoutine.addDaysToDate(fwDate.getDate(), 30);
		
		
		
		getErrorCode(appInUeiCargo.getUei_typ());
		final String personName = appInUeiCargo.getMoney_providing_person_name();
		final char[] specialChars = { '.', '-', '\'' };
		
		try {

			validateNewUeiType(appInUeiCargo);

			String beginDate = FwConstants.EMPTY_STRING;
			if ((appInUeiCargo.getUei_beg_dt() == null) || null==(appInUeiCargo.getUei_beg_dt())) {
				final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018069) };
				this.addMessageWithFieldValues("00293", error);
			}
			if (null!=appInUeiCargo.getUei_beg_dt()) {

				beginDate = validateNewUeiBegDt(appInUeiCargo, fwMessageList, beginDate);

			}
			String chgDt=sf.format(appInUeiCargo.getChg_dt());
			if(appInUeiCargo.getChg_dt() != null){
				validateNewUeiChgDt(appInUeiCargo, fwMessageList, chgDt);
			}
			validateNewUeiAmt(howMuch, appInUeiCargo, fwMessageList);

			if ((appInUeiCargo.getFreq_cd() == null) || appInUeiCargo.getFreq_cd().equals(AppConstants.SELECT_DEFAULT_OPTION)) {
				final String name = "";
				final Object[] error = new Object[] { name };
				this.addMessageWithFieldValues("00324", error);
			}else if(((FinancialInfoConstants.UEI_TYPE1_INCOME.contains(appInUeiCargo.getUei_typ())) || (FinancialInfoConstants.UEI_TYPE1_INCOME.contains(appInUeiCargo.getUei_Sub_Type()))) && (!"MO".equals(appInUeiCargo.getFreq_cd()))){
				fwMessageList.addMessageToList(addMessageCode("9588"));
				
			}
			if (isLoopingQuestionShown && loopingAnswer == null) {
				
					fwMessageList.addMessageToList(addMessageCode("00327"));
				
			}
			
			if ((personName != null) && (!personName.isEmpty()) && !appMgr.isSpecialAlphaNumeric(personName, specialChars)) {
				fwMessageList.addMessageToList(addMessageCode("90742"));
			}
			final boolean validBeginDate = true;
			boolean validEndDate = true;
			final String endDate = sf.format(appInUeiCargo.getUei_end_dt());
			validateNewUeiDet(appInUeiCargo, fwMessageList, specialChars, beginDate, validBeginDate, validEndDate,
					endDate);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeBO.validateNewPageContents() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + MILLI);

			return fwMessageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateNewUeiDet(final APP_IN_UEI_Cargo appInUeiCargo, FwMessageList fwMessageList,
			final char[] specialChars, String beginDate, final boolean validBeginDate, boolean validEndDate,
			final String endDate) throws ParseException {
		try {
		if ("SF".equalsIgnoreCase(appInUeiCargo.getUei_typ())) {

			validateNewUeiSFType(fwMessageList, beginDate, validBeginDate, validEndDate, endDate);
		}
			
			if (appInUeiCargo.getUei_claim_num() != null&&!appInUeiCargo.getUei_claim_num().isEmpty() && !appMgr.isSpecialAlphaNumeric(appInUeiCargo.getUei_claim_num(), specialChars)) {
				
					final Object[] error = new Object[] { new FwMessageTextLabel("800000508") };
					this.addMessageWithFieldValues("10446", error);
				
			}
		} catch (final Exception e) {
			throw e;
		}
		}

	private void validateNewUeiSFType(FwMessageList fwMessageList, String beginDate, final boolean validBeginDate,
			boolean validEndDate, final String endDate) throws ParseException {
		try {
		if (!appMgr.isFieldEmpty(endDate) && !appMgr.validateDate(endDate)) {
			
				validEndDate = false;
				if (validBeginDate) {
					fwMessageList.addMessageToList(addMessageCode("98019"));
				}
			
		}
		if (validBeginDate && validEndDate && (beginDate != null) && (beginDate.trim().length() > 0) && !beginDate.equals(AppConstants.HIGH_DATE)) {
			
				final SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
				final java.util.Date startDate = formatter.parse(beginDate);

				if (appMgr.isDateBeforeDate(endDate, startDate)) {
					fwMessageList.addMessageToList(addMessageCode("10275"));
				}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateNewUeiAmt(final String howMuch, final APP_IN_UEI_Cargo appInUeiCargo,
			FwMessageList fwMessageList) {
		try {
		if ((appInUeiCargo.getUei_amt() == null) || null==(appInUeiCargo.getUei_amt())) {
			fwMessageList.addMessageToList(addMessageCode("00325"));
		}

		if (!appMgr.isCurrency(appInUeiCargo.getUei_amt())) {
			fwMessageList.addMessageToList(addMessageCode("00326"));
		}

		if (!appMgr.isValidAmountLimit(howMuch)) {
			fwMessageList.addMessageToList(addMessageCode("90735"));

		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateNewUeiChgDt(final APP_IN_UEI_Cargo appInUeiCargo, FwMessageList fwMessageList, String chgDt) {
		try {
		if(appMgr.isFieldEmpty(chgDt)){
			fwMessageList.addMessageToList(addMessageCode("99368"));
		}
		if(!appMgr.isFieldEmpty(chgDt) && !appMgr.validateDate(appInUeiCargo.getChg_dt())){
			fwMessageList.addMessageToList(addMessageCode("99365"));
		}
		if(appMgr.isDateBeforeDate(chgDt, "01/01/1880")){
			fwMessageList.addMessageToList(addMessageCode("99366"));
		}
		java.util.Date nxtMnthLastDt = getNxtMnthlastDt();

		if(appMgr.isDateAfterDate(appInUeiCargo.getChg_dt(), nxtMnthLastDt)){
			fwMessageList.addMessageToList(addMessageCode("99367"));
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private String validateNewUeiBegDt(final APP_IN_UEI_Cargo appInUeiCargo, FwMessageList fwMessageList,
			String beginDate) {
		if ((appInUeiCargo != null) && (appInUeiCargo.getUei_beg_dt() != null)
				&& !appInUeiCargo.getUei_beg_dt().toString().trim().equals(AppConstants.HIGH_DATE)) {
			beginDate = sf.format(appInUeiCargo.getUei_beg_dt());
			if ((beginDate.length() >= 10) && (beginDate.charAt(4) == '-')) {
				beginDate = new SimpleDateFormat(DATE_FORMAT).format(appInUeiCargo.getUei_beg_dt());
			}
			if (!appMgr.validateDate(beginDate)) {
				final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018069) };
				this.addMessageWithFieldValues(ERROR_90461, error);
			} else if(!appMgr.futureDate(beginDate)){
				fwMessageList.addMessageToList(addMessageCode("99267"));
			}
		}
		return beginDate;
	}

	private void validateNewUeiType(final APP_IN_UEI_Cargo appInUeiCargo) {
		if ((appInUeiCargo.getUei_typ() != null) && appInUeiCargo.getUei_typ().equals(AppConstants.INC_OTH_VET_BNFT) && ((appInUeiCargo.getUei_Sub_Type() == null) || appInUeiCargo.getUei_Sub_Type().equals(AppConstants.SELECT_DEFAULT_OPTION))) {
			
				final String name = NAME;
				final Object[] error = new Object[] { name };
				this.addMessageWithFieldValues("00321", error);
			
		}

		if ((appInUeiCargo.getUei_typ() != null) && appInUeiCargo.getUei_typ().equals(AppConstants.INC_OTH_OTH_INC) && ((appInUeiCargo.getOthr_incm_src() == null) || appInUeiCargo.getOthr_incm_src().equals(AppConstants.EMPTY_STRING))) {
			
				final String name = NAME;
				final Object[] error = new Object[] { name };
				this.addMessageWithFieldValues("00320", error);
		}
	}
}
