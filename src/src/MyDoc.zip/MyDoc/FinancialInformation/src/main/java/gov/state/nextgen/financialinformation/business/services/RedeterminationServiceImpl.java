package gov.state.nextgen.financialinformation.business.services;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClient;
import com.amazonaws.services.lambda.model.InvocationType;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.business.entities.ServiceResponseCargo;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.util.ServiceChainUtil;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_P_PROP_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_P_PROP_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_R_PROP_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_R_PROP_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_VEH_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_VEH_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CpRmbRequestDetails_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CpRmbRequestDetails_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInEmplRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInHouRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInLqdAsetRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInPPropAssetRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInRealPropertyRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInSelfeRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInUieRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInVehAssetRepository;
import gov.state.nextgen.financialinformation.data.db2.CP_ABCHS_Repository;
import gov.state.nextgen.financialinformation.data.db2.CP_APP_IN_DEDUCTION_Repository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInIncomeTaxDedRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInMedBillsRepository;
import gov.state.nextgen.financialinformation.model.CaseIndividualDetails;
import gov.state.nextgen.financialinformation.model.CaseIndividualDetailsAsset;
import gov.state.nextgen.financialinformation.model.DriverPageResponse;
import gov.state.nextgen.financialinformation.model.InvokeResultResponse;
import gov.state.nextgen.financialinformation.model.ReqObjIncomeNewDetail;
import gov.state.nextgen.financialinformation.model.RequestObjExpenseInfoNewDetail;
import gov.state.nextgen.framework.business.model.PageActionDetails;

/**
 * As per CSPM-14666(Redetermination_MC210_Loading Financial Service).
 * 
 * @author upriyadarshi
 *
 */
@Service("RedeterminationService")
public class RedeterminationServiceImpl implements FinancialServInterface {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	AppInHouRepository appInHouRepository;

	@Autowired
	CP_APP_IN_DEDUCTION_Repository cpAppInDeductionRepository;

	@Autowired
	CP_ABCHS_Repository appInDcERepository;

	@Autowired
	CpAppInMedBillsRepository cpAppInMedBillsRepository;

	@Autowired
	CpAppInIncomeTaxDedRepository cpAppInIncomeTaxDedRepository;

	@Autowired
	ExpenseSummaryServiceImpl expenseSummaryServiceImpl;

	@Autowired
	AppInLqdAsetRepository appInLqdAsetRepository;

	@Autowired
	AppInPPropAssetRepository appInPPropAssetRepository;

	@Autowired
	AppInRealPropertyRepository appInRealPropertyRepository;

	@Autowired
	AppInVehAssetRepository appInVehAssetRepository;

	@Autowired
	AppInEmplRepository appInEmplRepository;

	@Autowired
	AppInSelfeRepository appInSelfeRepository;

	@Autowired
	AppInUieRepository appInUieRepository;

	private static final String STORE_RMC_EXPENSE_DETAIL = "Error occured in RedeterminationServiceImpl.storeRMCExpenseDetails()";
	private static final String STORE_RMC_EXPENSE_DETAIL_CALL = "Error occured while calling in RedeterminationServiceImpl.storeRMCExpenseDetails()";

	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTransaction) {
		if (FinancialInfoConstants.STORE_FIN_NON_FIN_DETAILS.equals(methodName)) {
			storeFinNonFinDetails(fwTransaction);
		}
	}
	
	/**
	 * As per CSPM-14666(Redetermination_MC210_Load Financial Service).
	 * 
	 * @param fwTransaction as FwTransaction
	 */
	private void storeFinNonFinDetails(FwTransaction fwTransaction) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "***UPDATED RedeterminationServiceImpl.storeFinNonFinDetails()*** - START");
		try {
			fetchFormStatusReqJson(fwTransaction);
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"*** UPDATED Error occured in RedeterminationServiceImpl.storeFinNonFinDetails()", fwTransaction);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STORE_FIN_NON_FIN_DETAILS, fwTransaction.getUserDetails().getAppNumber(),
					fwTransaction.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.storeFinNonFinDetails() - END",
				fwTransaction);
	}
	
	/**
	 * As per CSPM-14666(Redetermination_MC210_Loading Financial Service).
	 * 
	 * @param fwTransaction as FwTransaction
	 * @throws Exception
	 */
	private Map fetchFormStatusReqJson(FwTransaction fwTx) throws Exception {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"***RedeterminationServiceImpl.fetchFormStatusReqJson()*** - START");
		try {
			PageActionDetails action = fwTx.getCurrentActionDetails();
			action.setPageAction(FwConstants.HH_FORMSTATUSREQ_PAGEACTION);
			action.setPageId(FwConstants.HH_FORMSTATUSREQ_PAGEID);

			fwTx.setCurrentActionDetails(action);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "" + fwTx.getCurrentActionDetails().getPageAction());

			String payload = ServiceChainUtil.prepareAWSRequest(FwConstants.POST, FwConstants.HH_FORMSTATUSREQ_URL,
					FwConstants.HH_FORMSTATUSREQ_URL, fwTx);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "***Gateway fetchFormStatusReqJson complete***");
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"***Payload received for fetchFormStatusReqJson*** " + payload);

			AWSLambda client = AWSLambdaClient.builder().withRegion(System.getenv(FwConstants.REGION_SYS_ENV)).build();

			InvokeRequest request = new InvokeRequest();
			request.setInvocationType(InvocationType.RequestResponse);
			request.setFunctionName(System.getenv(FwConstants.HOUSEHOLD_FUNC_SYS_ENV));
			request.setPayload(payload);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Invoking fetchFormStatusReqJson client");
			InvokeResult invoke = client.invoke(request);
			String response = null;
			DriverPageResponse pageResponse;
			Map formStatusReqJson = null;
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"Status code fetchFormStatusReqJson: " + invoke.getStatusCode());

			if (invoke.getStatusCode() == 200) {
				response = new String(invoke.getPayload().array(), StandardCharsets.UTF_8);
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"fetchFormStatusReqJson Response received : " + response);

			}

			if (response != null) {
				ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
						false);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "");

				ServiceResponseCargo responseObj = mapper.readValue(response, ServiceResponseCargo.class);

				String body = responseObj.getBody();

				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "fetchFormStatusReqJson Body Received: " + body);

				pageResponse = mapper.readValue(body, DriverPageResponse.class);
				Map pageObject = pageResponse.getPageCollection();

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"fetchFormStatusReqJson pageObject Received: " + pageObject);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"fetchFormStatusReqJson Processing cpRmbRequestDetailsCollection... ");

				CpRmbRequestDetails_Collection cpRmbRequestDetailsCollection = (CpRmbRequestDetails_Collection) pageResponse
						.getCollectionData(pageObject, FwConstants.HH_CP_RMB_REQUEST_DETAILS_COLLECTION);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"fetchFormStatusReqJson cpRmbRequestDetailsCollection Received: "
								+ cpRmbRequestDetailsCollection);

				if (Objects.nonNull(cpRmbRequestDetailsCollection) && !cpRmbRequestDetailsCollection.isEmpty()) {

					CpRmbRequestDetails_Cargo cpRmbRequestDetailsCargo = (CpRmbRequestDetails_Cargo) cpRmbRequestDetailsCollection
							.get(0);

					FwLogger.log(this.getClass(), FwLogger.Level.INFO,
							"fetchFormStatusReqJson cpRmbRequestDetailsCargo: " + cpRmbRequestDetailsCargo);

					formStatusReqJson = (Map) new ObjectMapper()
							.readValue(cpRmbRequestDetailsCargo.getForm_status_req(), Object.class);

					FwLogger.log(this.getClass(), FwLogger.Level.INFO,
							"fetchFormStatusReqJson Object fetched" + formStatusReqJson);
					
					try {
						FwLogger.log(this.getClass(), FwLogger.Level.INFO, "***calling storeRMCDetails***");
						storeRMCDetails(fwTx, formStatusReqJson);
						FwLogger.log(this.getClass(), FwLogger.Level.INFO, "***completed storeRMCDetails***");

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - processing inkoveNonFinService...");
						inkoveNonFinService(fwTx);
						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - processed inkoveNonFinService...");

					} catch (final FwException fe) {
						FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
								STORE_RMC_EXPENSE_DETAIL_CALL + " " + fe.getMessage(), fwTx);
						
						throw fe;
					} catch (JsonProcessingException jpe) {
						FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_RMC_EXPENSE_DETAIL_CALL, fwTx);
						
						throw jpe;
					} catch (Exception ex) {
						FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_RMC_EXPENSE_DETAIL_CALL, fwTx);
						throw ex;
					}
				}

			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"***RedeterminationServiceImpl.fetchFormStatusReqJson() - END***");
			return formStatusReqJson;
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in RedeterminationServiceImpl.fetchFormStatusReqJson()");
			throw e;
		}
	}

	/**
	 * As per CSPM-14666(Redetermination_MC210_Loading Financial Service).
	 * 
	 * @param fwTransaction
	 * @throws Exception
	 */
	public void storeRMCDetails(FwTransaction fwTransaction, Map formStatusReqJson) throws Exception {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.storeRMCExpenseDetails() - START");

		final Map pageCollection = fwTransaction.getPageCollection();

		try {
			/* Getting formReportType from the FormStatus Request Json Clob */
			if (Objects.nonNull(formStatusReqJson)) {
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing formStatusReqJson...");

				String appNum = null;
				if (Objects.nonNull(fwTransaction.getUserDetails())) {
					appNum = fwTransaction.getUserDetails().getAppNumber();
				}

				String srcAppInd = FinancialInfoConstants.SRC_APP_AFB;
				String vehAsetType = FinancialInfoConstants.OV;

				APP_IN_HOU_BILLS_Collection appInHouBillsColl = new APP_IN_HOU_BILLS_Collection();
				CP_APP_IN_DEDUCTION_Collection appInDeductionColl = new CP_APP_IN_DEDUCTION_Collection();
				CP_ABCHS_Collection appInDcEColl = new CP_ABCHS_Collection();
				CP_APP_IN_MED_BILLS_Collection cpAppInMedBillsColl = new CP_APP_IN_MED_BILLS_Collection();
				CP_APP_IN_INCOME_TAX_DED_Collection cpAppInIncomeTaxDedColl = new CP_APP_IN_INCOME_TAX_DED_Collection();
				APP_IN_LQD_ASET_Collection appInLqdAsetCollection = new APP_IN_LQD_ASET_Collection();
				APP_IN_P_PROP_ASET_Collection appInPPropAsetCollection = new APP_IN_P_PROP_ASET_Collection();
				APP_IN_R_PROP_ASET_Collection appInRPropAsetColl = new APP_IN_R_PROP_ASET_Collection();
				APP_IN_VEH_ASET_Collection appInVehAsetColl = new APP_IN_VEH_ASET_Collection();
				APP_IN_EMPL_Collection appInEmplColl = new APP_IN_EMPL_Collection();
				APP_IN_SELFE_Collection appInSelfEColl = new APP_IN_SELFE_Collection();
				APP_IN_UEI_Collection appInUeiColl = new APP_IN_UEI_Collection();

				List caseIndividuals = (List) formStatusReqJson.get("CaseIndividuals");
				
				if (Objects.nonNull(caseIndividuals) && !caseIndividuals.isEmpty()) {

					List<String> housingBillTypeList = getTypeList(FinancialInfoConstants.HOUSING_BILLS_TYPE);
					List<String> medBillsTypeList = getTypeList(FinancialInfoConstants.MED_BILLS_TYPE);
					List<String> deductionTypeList = getTypeList(FinancialInfoConstants.DEDUCTION_TYPE);
					List<String> dcETypeList = getTypeList(FinancialInfoConstants.DC_E_TYPE);
					List<String> incomeTaxDedTypeList = getTypeList(FinancialInfoConstants.INCOME_TAX_DED_TYPE);
					List<String> ueiTypeList = getTypeList(FinancialInfoConstants.UEITYPE);

					Map<Integer, Integer> personalIdIndvIdMap = fetchIndvPersonIdMap(fwTransaction);
					FwLogger.log(this.getClass(), FwLogger.Level.INFO,
							"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing caseIndividuals...");

					for (Object caseIndividual : caseIndividuals) {
						/* Converting CaseIndividual JSON String to Java POJO */
						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing caseIndividual to String via Object Mapper...");
						String caseIndividualString = new ObjectMapper().writeValueAsString(caseIndividual);
						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing caseIndividual to CaseIndividualDetails object...");
						CaseIndividualDetails caseIndv = new ObjectMapper().readValue(caseIndividualString,
								CaseIndividualDetails.class);
						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - end Object Mapping...");
						
						FwLogger.log(this.getClass(), FwLogger.Level.INFO, "personalIdIndvIdMap "+personalIdIndvIdMap);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO, "caseIndv.getPersonalId() "+caseIndv.getPersonalId());

						Integer indvSeqNum = personalIdIndvIdMap.get(caseIndv.getPersonalId().intValue());

						FwLogger.log(this.getClass(), FwLogger.Level.INFO, "indvSeqNum" + indvSeqNum);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing Housing Bills expense...");
						processHousingBills(appNum, srcAppInd, appInHouBillsColl, housingBillTypeList, indvSeqNum,
								caseIndv);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing Med Bills expense...");
						processMedBills(appNum, srcAppInd, cpAppInMedBillsColl, medBillsTypeList, indvSeqNum, caseIndv);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing deduction expense...");
						processDeduction(appNum, srcAppInd, appInDeductionColl, deductionTypeList, indvSeqNum,
								caseIndv);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing DC E expense...");
						processDcEType(appNum, srcAppInd, appInDcEColl, dcETypeList, indvSeqNum, caseIndv);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing Income Tax deduction expense...");
						processIncomeTaxDed(appNum, srcAppInd, cpAppInIncomeTaxDedColl, incomeTaxDedTypeList,
								indvSeqNum, caseIndv);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing processLqdAsetCargo...");
						processLqdAsetCargo(appNum, srcAppInd, appInLqdAsetCollection, caseIndv, indvSeqNum);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing processPPropAsetCargo...");
						processPPropAsetCargo(appNum, srcAppInd, appInPPropAsetCollection, caseIndv, indvSeqNum, appInLqdAsetCollection);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing processRPropAsetCargo...");
						processRPropAsetCargo(appNum, srcAppInd, appInRPropAsetColl, caseIndv, indvSeqNum);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing processVehAsetCargo...");
						processVehAsetCargo(appNum, srcAppInd, appInVehAsetColl, caseIndv, indvSeqNum, vehAsetType);
						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - appInVehAsetColl..."
										+ appInVehAsetColl);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing processEmplCargo...");
						processEmplCargo(appNum, srcAppInd, appInEmplColl, caseIndv, indvSeqNum);
						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - appInEmplColl..."
										+ appInEmplColl);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing processSelfECargo...");
						processSelfECargo(appNum, srcAppInd, appInSelfEColl, caseIndv, indvSeqNum);
						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - appInSelfEColl..."
										+ appInSelfEColl);

						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - Processing processUeiCargo...");
						processUeiCargo(appNum, srcAppInd, appInUeiColl, caseIndv, indvSeqNum, ueiTypeList);
						FwLogger.log(this.getClass(), FwLogger.Level.INFO,
								"RedeterminationServiceImpl.storeRMCExpenseDetails() - processUeiCargo..."
										+ appInUeiColl);
					}
				}

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to appInHouBills...");
				appInHouRepository.saveAll(appInHouBillsColl);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to cpAppInDeduction...");
				cpAppInDeductionRepository.saveAll(appInDeductionColl);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to appInDcE...");
				appInDcERepository.saveAll(appInDcEColl);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to cpAppInMedBills...");
				cpAppInMedBillsRepository.saveAll(cpAppInMedBillsColl);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to cpAppInIncomeTaxDed...");
				cpAppInIncomeTaxDedRepository.saveAll(cpAppInIncomeTaxDedColl);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to appInLqdAset...");
				appInLqdAsetRepository.saveAll(appInLqdAsetCollection);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to appInPPropAsset...");
				appInPPropAssetRepository.saveAll(appInPPropAsetCollection);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to appInRealProperty...");
				appInRealPropertyRepository.saveAll(appInRPropAsetColl);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to appInVehAsset...");
				appInVehAssetRepository.saveAll(appInVehAsetColl);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to appInEmpl...");
				appInEmplRepository.saveAll(appInEmplColl);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to appInSelfE...");
				appInSelfeRepository.saveAll(appInSelfEColl);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeRMCExpenseDetails() - persisting data to appInUei...");
				appInUieRepository.saveAll(appInUeiColl);

				pageCollection.put(FinancialInfoConstants.APP_NUM, appNum);

			}
		} catch (Exception ex) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_RMC_EXPENSE_DETAIL, fwTransaction);
			throw ex;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.storeRMCExpenseDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + FinancialInfoConstants.MILLISECONDS,
				fwTransaction);
	}

	private void inkoveNonFinService(FwTransaction fwTransaction) throws Exception {
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.inkoveNonFinService() - START");
			/*
			 * Service call to store Non Fin Details
			 */
			storeNonFinDetails(fwTransaction);
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.inkoveNonFinService() - processed...");
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in RedeterminationServiceImpl.inkoveNonFinService()", fwTransaction);
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.inkoveNonFinService() - END",
				fwTransaction);
	}

	private Map<Integer, Integer> fetchIndvPersonIdMap(FwTransaction fwTransaction) throws Exception {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.fetchIndvPersonIdMap() - START");
		Map<Integer, Integer> personalIdIndvIdMap = new HashMap<>();
		try {
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "processing expenseSummaryServiceImpl.getIndvList");
			APP_INDV_Collection appIndvCollection = expenseSummaryServiceImpl.getIndvList(fwTransaction);
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "done processing expenseSummaryServiceImpl.getIndvList");
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "appIndvCollection "+ appIndvCollection);
			if (appIndvCollection != null && !appIndvCollection.isEmpty()) {
				for (int i = 0; i < appIndvCollection.size(); i++) {
					APP_INDV_Cargo appIndvCargo1 = (APP_INDV_Cargo) appIndvCollection.get(i);

					FwLogger.log(this.getClass(), FwLogger.Level.INFO,
							"appIndvCargo1.getCalsaws_personal_id() " + appIndvCargo1.getCalsaws_personal_id());

					FwLogger.log(this.getClass(), FwLogger.Level.INFO,
							"appIndvCargo1.getIndv_seq_num() " + appIndvCargo1.getIndv_seq_num());
					if (Objects.nonNull(appIndvCargo1.getCalsaws_personal_id())) {
						personalIdIndvIdMap.put(appIndvCargo1.getCalsaws_personal_id().intValue(),
								appIndvCargo1.getIndv_seq_num());
					}

				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.fetchIndvPersonIdMap() - END");
			return personalIdIndvIdMap;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in RedeterminationServiceImpl.fetchIndvPersonIdMap()", fwTransaction);
			throw e;
		}
	}

	private void processUeiCargo(String appNum, String srcAppInd, APP_IN_UEI_Collection appInUeiColl,
			CaseIndividualDetails caseIndv, Integer indvSeqNum, List<String> uieType) throws JsonProcessingException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.fetchIndvPersonIdMap() - START");
			if (Objects.nonNull(caseIndv.getReqObjIncomeNewDetail())
					&& !caseIndv.getReqObjIncomeNewDetail().isEmpty()) {
				Integer seqNum = 1;
				ResourceBundle rb = ResourceBundle.getBundle("mcIncomeMapping");
				
				for (ReqObjIncomeNewDetail reqObjIncomeNewDetail : caseIndv.getReqObjIncomeNewDetail()) {
					String incomeType = processIncomeType(rb, reqObjIncomeNewDetail.getIncomeType());
					if (Objects.nonNull(reqObjIncomeNewDetail.getIncomeType()) && uieType.contains(incomeType)) {
						seqNum = processUnearnedIncome(appNum, srcAppInd, appInUeiColl, indvSeqNum, seqNum,
								reqObjIncomeNewDetail, incomeType);
					} else if (!(FinancialInfoConstants.SELFEMPLTYPE.equals(incomeType)
									|| FinancialInfoConstants.EMPLTYPE.equals(incomeType))) {
						seqNum = processUnearnedIncome(appNum, srcAppInd, appInUeiColl, indvSeqNum, seqNum,
								reqObjIncomeNewDetail, FinancialInfoConstants.OTHER_TYPE);
					}
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.fetchIndvPersonIdMap() - END");
	}

	private Integer processUnearnedIncome(String appNum, String srcAppInd, APP_IN_UEI_Collection appInUeiColl,
			Integer indvSeqNum, Integer seqNum, ReqObjIncomeNewDetail reqObjIncomeNewDetail,
			String incomeType)
			throws JsonProcessingException {
		APP_IN_UEI_Cargo appInUeiCargo = new APP_IN_UEI_Cargo();

		appInUeiCargo.setApp_num(appNum);
		appInUeiCargo.setSrc_app_ind(srcAppInd);
		appInUeiCargo.setIndv_seq_num(indvSeqNum);
		appInUeiCargo.setSeq_num(seqNum);
		appInUeiCargo.setUei_typ(incomeType);
		appInUeiCargo.setIncome_source(reqObjIncomeNewDetail.getIncomeSource());
		appInUeiCargo.setFreq_cd(processFrequency(reqObjIncomeNewDetail.getFrequency()));

		if (Objects.nonNull(reqObjIncomeNewDetail.getAmount())) {
			String amount = String.valueOf(reqObjIncomeNewDetail.getAmount());
			appInUeiCargo.setUei_amt(Double.valueOf(amount));
		}

		appInUeiCargo.setUei_beg_dt(reqObjIncomeNewDetail.getStartDate());
		appInUeiCargo.setDivorce_dt(reqObjIncomeNewDetail.getDateOfSeperation());

		processUeiExpToContResp(reqObjIncomeNewDetail, appInUeiCargo);

		appInUeiCargo.setDt_services_rcvd(reqObjIncomeNewDetail.getLastDateRecieved());

		String incomeNewDetailStr = new ObjectMapper().writeValueAsString(reqObjIncomeNewDetail);
		appInUeiCargo.setUeiCalsawsObject(incomeNewDetailStr);

		appInUeiColl.add(appInUeiCargo);

		seqNum++;
		return seqNum;
	}

	private void processUeiExpToContResp(ReqObjIncomeNewDetail reqObjIncomeNewDetail, APP_IN_UEI_Cargo appInUeiCargo) {
			if (Objects.nonNull(reqObjIncomeNewDetail.isExpectedToContineIncome())
					&& reqObjIncomeNewDetail.isExpectedToContineIncome()) {
				appInUeiCargo.setExpected_to_cont_resp(FinancialInfoConstants.Y);
			}
		
	}

	private void processSelfECargo(String appNum, String srcAppInd, APP_IN_SELFE_Collection appInSelfEColl,
			CaseIndividualDetails caseIndv, Integer indvSeqNum) throws JsonProcessingException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.processSelfECargo() - START");
			if (Objects.nonNull(caseIndv.getReqObjIncomeNewDetail())
					&& !caseIndv.getReqObjIncomeNewDetail().isEmpty()) {
				Integer seqNum = 1;
				ResourceBundle rb = ResourceBundle.getBundle("mcIncomeMapping");
				
				for (ReqObjIncomeNewDetail reqObjIncomeNewDetail : caseIndv.getReqObjIncomeNewDetail()) {
					if (FinancialInfoConstants.SELFEMPLTYPE
							.equalsIgnoreCase(processIncomeType(rb, reqObjIncomeNewDetail.getIncomeType()))) {
						APP_IN_SELFE_Cargo appInSelfECargo = new APP_IN_SELFE_Cargo();

						appInSelfECargo.setApp_num(appNum);
						appInSelfECargo.setSrc_app_ind(srcAppInd);
						appInSelfECargo.setIndv_seq_num(indvSeqNum);
						appInSelfECargo.setSeq_num(seqNum);
						appInSelfECargo.setIncomeSource(reqObjIncomeNewDetail.getIncomeSource());
						appInSelfECargo.setSelf_empl_typ(FinancialInfoConstants.SELFEMPLTYPE);
						appInSelfECargo
								.setPay_freq(processFrequency(reqObjIncomeNewDetail.getFrequency()));


						if(Objects.nonNull(reqObjIncomeNewDetail.getAmount())) {
							String amount = String.valueOf(reqObjIncomeNewDetail.getAmount());
							appInSelfECargo.setAmount(Double.valueOf(amount));
						}

						appInSelfECargo.setEff_begin_dt(reqObjIncomeNewDetail.getStartDate());

						processSelfEExpToContResp(reqObjIncomeNewDetail, appInSelfECargo);

						String incomeNewDetailStr = new ObjectMapper().writeValueAsString(reqObjIncomeNewDetail);
						appInSelfECargo.setSelfECalsawsObject(incomeNewDetailStr);

						appInSelfEColl.add(appInSelfECargo);

						seqNum++;
					}
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.processSelfECargo() - END");
	}

	private void processSelfEExpToContResp(ReqObjIncomeNewDetail reqObjIncomeNewDetail,
			APP_IN_SELFE_Cargo appInSelfECargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.processSelfEExpToContResp() - START");
			if (Objects.nonNull(reqObjIncomeNewDetail.isExpectedToContineIncome())
					&& reqObjIncomeNewDetail.isExpectedToContineIncome()) {
				appInSelfECargo.setExpected_to_cont_resp(FinancialInfoConstants.Y);
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.processSelfEExpToContResp() - END");
	}

	private void processEmplCargo(String appNum, String srcAppInd, APP_IN_EMPL_Collection appInEmplColl,
			CaseIndividualDetails caseIndv, Integer indvSeqNum) throws JsonProcessingException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.processEmplCargo() - START");
			if (Objects.nonNull(caseIndv.getReqObjIncomeNewDetail())
					&& !caseIndv.getReqObjIncomeNewDetail().isEmpty()) {
				Integer seqNum = 1;
				ResourceBundle rb = ResourceBundle.getBundle("mcIncomeMapping");
				
				for (ReqObjIncomeNewDetail reqObjIncomeNewDetail : caseIndv.getReqObjIncomeNewDetail()) {
					if (FinancialInfoConstants.EMPLTYPE.equalsIgnoreCase(processIncomeType(rb, reqObjIncomeNewDetail.getIncomeType()))) {
						APP_IN_EMPL_Cargo appInEmplCargo = new APP_IN_EMPL_Cargo();
						
						appInEmplCargo.setApp_num(appNum);
						appInEmplCargo.setSrc_app_ind(srcAppInd);
						appInEmplCargo.setIndv_seq_num(indvSeqNum);
						appInEmplCargo.setEmpl_seq_num(seqNum);
						/*
						 * setting Ik_income_type as "E" as CalSAWs will send ongoing employment
						 * records.
						 */
						appInEmplCargo.setIk_income_type(FinancialInfoConstants.IK_INCOME_TYPE_E);
						appInEmplCargo.setEmpl_type(FinancialInfoConstants.IK_INCOME_TYPE_E);
						appInEmplCargo.setIncomeSource(reqObjIncomeNewDetail.getIncomeSource());
						appInEmplCargo
								.setPay_freq_cd(processFrequency(reqObjIncomeNewDetail.getFrequency()));

						if(Objects.nonNull(reqObjIncomeNewDetail.getAmount())) {
							String amount = String.valueOf(reqObjIncomeNewDetail.getAmount());
							appInEmplCargo.setHourly_pay_amt(Double.valueOf(amount));
							appInEmplCargo.setGross_pay_amt(Double.valueOf(amount));
						}


						appInEmplCargo.setEmpl_begin_dt(reqObjIncomeNewDetail.getStartDate());

						processEmplExpToContResp(reqObjIncomeNewDetail, appInEmplCargo);

						appInEmplCargo.setLast_payck_dt(reqObjIncomeNewDetail.getLastDateRecieved());

						String incomeNewDetailStr = new ObjectMapper().writeValueAsString(reqObjIncomeNewDetail);
						appInEmplCargo.setEmplCalsawsObject(incomeNewDetailStr);

						appInEmplColl.add(appInEmplCargo);

						seqNum++;
					}
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.processEmplCargo() - END");
	}

	private void processEmplExpToContResp(ReqObjIncomeNewDetail reqObjIncomeNewDetail,
			APP_IN_EMPL_Cargo appInEmplCargo) {
			if (Objects.nonNull(reqObjIncomeNewDetail.isExpectedToContineIncome())
					&& reqObjIncomeNewDetail.isExpectedToContineIncome()) {
				appInEmplCargo.setExpected_to_cont_resp(FinancialInfoConstants.Y);
			}
		
	}

	private void processVehAsetCargo(String appNum, String srcAppInd, APP_IN_VEH_ASET_Collection appInVehAsetColl,
			CaseIndividualDetails caseIndv, Integer indvSeqNum, String vehAssetType) throws JsonProcessingException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.processVehAsetCargo() - processing...");
			List<APP_IN_VEH_ASET_Cargo> appInVehAsetCargos = setAppInVehAsetDetails(appNum, indvSeqNum, srcAppInd,
					caseIndv, vehAssetType);
			if (Objects.nonNull(appInVehAsetCargos)) {
				for (APP_IN_VEH_ASET_Cargo appInVehAsetCargo : appInVehAsetCargos) {
					appInVehAsetColl.addCargo(appInVehAsetCargo);
				}
			}
		
	}

	private void processRPropAsetCargo(String appNum, String srcAppInd,
			APP_IN_R_PROP_ASET_Collection appInRPropAsetColl, CaseIndividualDetails caseIndv, Integer indvSeqNum)
			throws JsonProcessingException {
			List<APP_IN_R_PROP_ASET_Cargo> appInRPropAsetCargos = setAppInRVehAnsPropDetails(appNum, indvSeqNum,
					srcAppInd, caseIndv);
			if (Objects.nonNull(appInRPropAsetCargos)) {
				for (APP_IN_R_PROP_ASET_Cargo appInRPropAsetCargo : appInRPropAsetCargos) {
					appInRPropAsetColl.addCargo(appInRPropAsetCargo);
				}
			}
		
	}

	private void processPPropAsetCargo(String appNum, String srcAppInd,
			APP_IN_P_PROP_ASET_Collection appInPPropAsetCollection, CaseIndividualDetails caseIndv, Integer indvSeqNum,
			APP_IN_LQD_ASET_Collection appInLqdAsetCollection) throws JsonProcessingException {
		APP_IN_P_PROP_ASET_Cargo[] appInPPropAsetCargo = setCaseIndividualPPropDetails(appNum, indvSeqNum, caseIndv,
				srcAppInd, appInLqdAsetCollection);
		if (Objects.nonNull(appInPPropAsetCargo)) {
			for (int i = 0; i < appInPPropAsetCargo.length; i++) {
				appInPPropAsetCollection.addCargo(appInPPropAsetCargo[i]);
			}
		}
	}

	private void processLqdAsetCargo(String appNum, String srcAppInd, APP_IN_LQD_ASET_Collection appInLqdAsetCollection,
			CaseIndividualDetails caseIndv, Integer indvSeqNum) throws JsonProcessingException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.processLqdAsetCargo() - START");
			APP_IN_LQD_ASET_Cargo[] appInLqdAsetCargo = setCaseIndividualAssetDetails(appNum, indvSeqNum, caseIndv,
					srcAppInd);
			if (Objects.nonNull(appInLqdAsetCargo)) {
				for (int i = 0; i < appInLqdAsetCargo.length; i++) {
					appInLqdAsetCollection.addCargo(appInLqdAsetCargo[i]);
				}
			}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedeterminationServiceImpl.processLqdAsetCargo() - END");
	}

	private void processIncomeTaxDed(String appNum, String srcAppInd,
			CP_APP_IN_INCOME_TAX_DED_Collection cpAppInIncomeTaxDedColl, List<String> incomeTaxDedTypeList,
			Integer indvSeqNum, CaseIndividualDetails caseIndv) throws JsonProcessingException {
		if (Objects.nonNull(caseIndv.getReqObjExpInfoNewDetail()) && !caseIndv.getReqObjExpInfoNewDetail().isEmpty()) {
			int seqNum = 1;
			ResourceBundle rb = ResourceBundle.getBundle("mcExpanseMapping");
			for (RequestObjExpenseInfoNewDetail expenseDetail : caseIndv.getReqObjExpInfoNewDetail()) {
				if (Objects.nonNull(expenseDetail.getExpenseCode())) {
					String expenseType = processExpenseType(rb, expenseDetail);
					if (incomeTaxDedTypeList.contains(expenseType)) {
						CP_APP_IN_INCOME_TAX_DED_Cargo cpAppInIncomeTaxDedCargo = setCpAppInIncomeTaxDedCargo(appNum,
								indvSeqNum, srcAppInd, seqNum, expenseDetail, expenseType);
						cpAppInIncomeTaxDedColl.add(cpAppInIncomeTaxDedCargo);
						seqNum++;
					}
				}
			}
		}
	}

	private void processDcEType(String appNum, String srcAppInd, CP_ABCHS_Collection appInDcEColl,
			List<String> dcETypeList, Integer indvSeqNum, CaseIndividualDetails caseIndv)
			throws JsonProcessingException {
		if (Objects.nonNull(caseIndv.getReqObjExpInfoNewDetail()) && !caseIndv.getReqObjExpInfoNewDetail().isEmpty()) {
			int seqNum = 1;
			ResourceBundle rb = ResourceBundle.getBundle("mcExpanseMapping");
			for (RequestObjExpenseInfoNewDetail expenseDetail : caseIndv.getReqObjExpInfoNewDetail()) {
				if (Objects.nonNull(expenseDetail.getExpenseCode())) {
					String expenseType = processExpenseType(rb, expenseDetail);
					if (dcETypeList.contains(expenseType)) {
						CP_ABCHS_Cargo appInDcEListCargo = setAppInDcECargo(appNum, indvSeqNum, srcAppInd, seqNum,
								expenseDetail, expenseType);
						appInDcEColl.add(appInDcEListCargo);
						seqNum++;
					}
				}
			}
		}
	}

	private void processDeduction(String appNum, String srcAppInd, CP_APP_IN_DEDUCTION_Collection appInDeductionColl,
			List<String> deductionTypeList, Integer indvSeqNum, CaseIndividualDetails caseIndv)
			throws JsonProcessingException {
		if (Objects.nonNull(caseIndv.getReqObjExpInfoNewDetail()) && !caseIndv.getReqObjExpInfoNewDetail().isEmpty()) {

			List<String> housingBillTypeList = getTypeList(FinancialInfoConstants.HOUSING_BILLS_TYPE);
			List<String> medBillsTypeList = getTypeList(FinancialInfoConstants.MED_BILLS_TYPE);
			List<String> dcETypeList = getTypeList(FinancialInfoConstants.DC_E_TYPE);
			List<String> incomeTaxDedTypeList = getTypeList(FinancialInfoConstants.INCOME_TAX_DED_TYPE);

			int seqNum = 1;
			ResourceBundle rb = ResourceBundle.getBundle("mcExpanseMapping");
			for (RequestObjExpenseInfoNewDetail expenseDetail : caseIndv.getReqObjExpInfoNewDetail()) {
				if (Objects.nonNull(expenseDetail.getExpenseCode())) {
					String expenseType = processExpenseType(rb, expenseDetail);
					if (deductionTypeList.contains(expenseType)) {
						CP_APP_IN_DEDUCTION_Cargo appInDeductionCargo = setDeductionCargo(appNum, indvSeqNum, srcAppInd,
								seqNum, expenseDetail, true, expenseType);
						appInDeductionColl.add(appInDeductionCargo);
						seqNum++;
					} else if (Objects.nonNull(expenseDetail.getExpenseCode())
							&& !(housingBillTypeList.contains(expenseType) || medBillsTypeList.contains(expenseType)
									|| dcETypeList.contains(expenseType)
									|| incomeTaxDedTypeList.contains(expenseType))) {
						CP_APP_IN_DEDUCTION_Cargo appInDeductionCargo = setDeductionCargo(appNum, indvSeqNum, srcAppInd,
								seqNum, expenseDetail, false, expenseType);
						appInDeductionColl.add(appInDeductionCargo);
						seqNum++;
					}
				} else {
					CP_APP_IN_DEDUCTION_Cargo appInDeductionCargo = setDeductionCargo(appNum, indvSeqNum, srcAppInd,
							seqNum, expenseDetail, false, null);
					appInDeductionColl.add(appInDeductionCargo);
					seqNum++;
				}
			}
		}
	}

	private void processMedBills(String appNum, String srcAppInd, CP_APP_IN_MED_BILLS_Collection cpAppInMedBillsColl,
			List<String> medBillsTypeList, Integer indvSeqNum, CaseIndividualDetails caseIndv)
			throws JsonProcessingException {
		if (Objects.nonNull(caseIndv.getReqObjExpInfoNewDetail()) && !caseIndv.getReqObjExpInfoNewDetail().isEmpty()) {
			int seqNum = 1;
			ResourceBundle rb = ResourceBundle.getBundle("mcExpanseMapping");
			for (RequestObjExpenseInfoNewDetail expenseDetail : caseIndv.getReqObjExpInfoNewDetail()) {
				if (Objects.nonNull(expenseDetail.getExpenseCode())) {
					String expenseType = processExpenseType(rb, expenseDetail);
					if (medBillsTypeList.contains(expenseType)) {
						CP_APP_IN_MED_BILLS_Cargo cpAppInMedBillsCargo = setCpAppInMedBillsCargo(appNum, indvSeqNum,
								srcAppInd, seqNum, expenseDetail, expenseType);
						cpAppInMedBillsColl.add(cpAppInMedBillsCargo);
						seqNum++;
					}
				}
			}
		}
	}

	private void processHousingBills(String appNum, String srcAppInd, APP_IN_HOU_BILLS_Collection appInHouBillsColl,
			List<String> housingBillTypeList, Integer indvSeqNum, CaseIndividualDetails caseIndv)
			throws JsonProcessingException {
		if (Objects.nonNull(caseIndv.getReqObjExpInfoNewDetail()) && !caseIndv.getReqObjExpInfoNewDetail().isEmpty()) {
			int seqNum = 1;
			ResourceBundle rb = ResourceBundle.getBundle("mcExpanseMapping");
			for (RequestObjExpenseInfoNewDetail expenseDetail : caseIndv.getReqObjExpInfoNewDetail()) {
				if (Objects.nonNull(expenseDetail.getExpenseCode())) {
					String expenseType = processExpenseType(rb, expenseDetail);
					if (housingBillTypeList.contains(expenseType)) {
						APP_IN_HOU_BILLS_Cargo appInHouBillsCargo = setHousingBillsCargo(appNum, indvSeqNum, srcAppInd,
								seqNum, expenseDetail, expenseType);
						appInHouBillsColl.add(appInHouBillsCargo);
						seqNum++;
					}
				}
			}
		}
	}

	private List<String> getTypeList(String type) {
		return Arrays.asList(type.split(",")).stream().map(x -> x).collect(Collectors.toList());
	}

	private CP_APP_IN_INCOME_TAX_DED_Cargo setCpAppInIncomeTaxDedCargo(String appNum, Integer indvSeqNum,
			String srcAppInd, int seqNum, RequestObjExpenseInfoNewDetail expenseDetail, String expenseType)
			throws JsonProcessingException {
		CP_APP_IN_INCOME_TAX_DED_Cargo cpAppInIncomeTaxDedCargo = new CP_APP_IN_INCOME_TAX_DED_Cargo();
		cpAppInIncomeTaxDedCargo.setApp_num(appNum);
		cpAppInIncomeTaxDedCargo.setIndv_seq_num(indvSeqNum);
		cpAppInIncomeTaxDedCargo.setSeq_num(seqNum);
		cpAppInIncomeTaxDedCargo.setSrc_app_ind(srcAppInd);
		cpAppInIncomeTaxDedCargo.setPay_freq(processFrequency(expenseDetail.getFrequency()));

		cpAppInIncomeTaxDedCargo.setExp_type(expenseType);
		cpAppInIncomeTaxDedCargo.setExpTypeDesc(expenseDetail.getExpenseType());
		cpAppInIncomeTaxDedCargo.setAlimony_exp(expenseDetail.getAmount());

		String expenseDetailStr = new ObjectMapper().writeValueAsString(expenseDetail);
		cpAppInIncomeTaxDedCargo.setIncTaxCalsawsObject(expenseDetailStr);

		return cpAppInIncomeTaxDedCargo;

	}

	private String processExpenseType(ResourceBundle rb, RequestObjExpenseInfoNewDetail expenseDetail) {
		List<String> expenseTypeList = Arrays.asList(rb.getString("expenseTypeList").split(","));
		for (String expenseType : expenseTypeList) {
			List<String> expenseCodeList = Arrays.asList(rb.getString(expenseType).split(","));
			if (expenseCodeList.contains(expenseDetail.getExpenseCode())) {
				return expenseType;
			}
		}
		return null;
	}
	
	private String processLqdAssetType(ResourceBundle rb, String assetCode) {
		List<String> assetTypeList = Arrays.asList(rb.getString("lqdAssetTypeList").split(","));
		for (String assetType : assetTypeList) {
			List<String> assetCodeList = Arrays.asList(rb.getString(assetType).split(","));
			if (assetCodeList.contains(assetCode)) {
				return assetType;
			}
		}
		return null;
	}

	private String processPersonalPropType(ResourceBundle rb, String personalPropCode) {
		if (Objects.isNull(personalPropCode) || personalPropCode.trim().isEmpty()) {
			return null;
		}
		List<String> personalPropTypeList = Arrays.asList(rb.getString("personalPropTypList").split(","));
		for (String personalPropType : personalPropTypeList) {
			List<String> personalPropCodeList = Arrays.asList(rb.getString(personalPropType).split(","));
			if (personalPropCodeList.contains(personalPropCode)) {
				return personalPropType;
			}
		}
		return null;
	}
	
	private String processIncomeType(ResourceBundle rb, String incomeType) {
		if (Objects.isNull(incomeType) || incomeType.trim().isEmpty()) {
			return null;
		}
		List<String> incomeTypeList = Arrays.asList(rb.getString("incomeTypeList").split(","));
		for (String incomeTypeCode : incomeTypeList) {
			List<String> incomeTypeCodeList = Arrays.asList(rb.getString(incomeTypeCode).split(","));
			if (incomeTypeCodeList.contains(incomeType)) {
				return incomeTypeCode;
			}
		}
		return null;
	}
	
	private CP_APP_IN_MED_BILLS_Cargo setCpAppInMedBillsCargo(String appNum, Integer indvSeqNum, String srcAppInd,
			int seqNum, RequestObjExpenseInfoNewDetail expenseDetail, String expenseType) throws JsonProcessingException {
			CP_APP_IN_MED_BILLS_Cargo cpAppInMedBillsCargo = new CP_APP_IN_MED_BILLS_Cargo();
			cpAppInMedBillsCargo.setApp_num(appNum);
			cpAppInMedBillsCargo.setIndv_seq_num(indvSeqNum);
			cpAppInMedBillsCargo.setMedical_seq_num(seqNum);
			cpAppInMedBillsCargo.setSrc_app_ind(srcAppInd);
			cpAppInMedBillsCargo.setMed_bill_type(expenseType);
			cpAppInMedBillsCargo.setMedBillTypeDesc(expenseDetail.getExpenseType());
			cpAppInMedBillsCargo.setPay_freq(processFrequency(expenseDetail.getFrequency()));
			cpAppInMedBillsCargo.setPayment_amt(expenseDetail.getAmount());

			String expenseDetailStr = new ObjectMapper().writeValueAsString(expenseDetail);
			cpAppInMedBillsCargo.setMedBillsCalsawsObject(expenseDetailStr);

			return cpAppInMedBillsCargo;
		
	}

	private CP_ABCHS_Cargo setAppInDcECargo(String appNum, Integer indvSeqNum, String srcAppInd, int seqNum,
			RequestObjExpenseInfoNewDetail expenseDetail, String expenseType) throws JsonProcessingException {
			CP_ABCHS_Cargo appInDcECargo = new CP_ABCHS_Cargo();
			appInDcECargo.setApp_num(appNum);
			appInDcECargo.setIndv_seq_num(indvSeqNum);
			appInDcECargo.setSeq_num(seqNum);
			appInDcECargo.setSrc_app_ind(srcAppInd);
			appInDcECargo.setDpnd_care_exp_ind(expenseType);
			appInDcECargo.setDpndCareExpDesc(expenseDetail.getExpenseType());
			appInDcECargo.setPay_freq(processFrequency(expenseDetail.getFrequency()));
			appInDcECargo.setDpnd_care_exp_amt(expenseDetail.getAmount());

			String expenseDetailStr = new ObjectMapper().writeValueAsString(expenseDetail);
			appInDcECargo.setDcECalsawsObject(expenseDetailStr);

			return appInDcECargo;
	}

	private CP_APP_IN_DEDUCTION_Cargo setDeductionCargo(String appNum, Integer indvSeqNum, String srcAppInd, int seqNum,
			RequestObjExpenseInfoNewDetail expenseDetail, boolean flag, String expenseType) throws JsonProcessingException {
		CP_APP_IN_DEDUCTION_Cargo appInDeductionCargo = new CP_APP_IN_DEDUCTION_Cargo();
			appInDeductionCargo.setApp_num(appNum);
			appInDeductionCargo.setIndv_seq_num(indvSeqNum);
			appInDeductionCargo.setSeq_num(seqNum);
			appInDeductionCargo.setSrc_app_ind(srcAppInd);
			
			if("CC".equalsIgnoreCase(expenseType)) {
				appInDeductionCargo.setCourt_order_pay_chld_sup_ind(FinancialInfoConstants.Y);
			}
			
			if (flag) {
				appInDeductionCargo.setExp_typ(expenseType);
			} else {
				appInDeductionCargo.setExp_typ(FinancialInfoConstants.OTHER_TYPE);
			}
			appInDeductionCargo.setOtherExpenseType(expenseDetail.getExpenseType());
			appInDeductionCargo.setPay_freq_cd(processFrequency(expenseDetail.getFrequency()));
			appInDeductionCargo.setExp_amt(expenseDetail.getAmount());
			appInDeductionCargo.setDivorce_dt(expenseDetail.getDivorceDate());

			String expenseDetailStr = new ObjectMapper().writeValueAsString(expenseDetail);
			appInDeductionCargo.setDedCalsawsObject(expenseDetailStr);
		
		return appInDeductionCargo;
	}

	private APP_IN_HOU_BILLS_Cargo setHousingBillsCargo(String appNum, int indvSeqNum, String srcAppInd, int seqNum,
			RequestObjExpenseInfoNewDetail expenseDetail, String expenseType) throws JsonProcessingException {
		APP_IN_HOU_BILLS_Cargo appInHouBillsCargo = new APP_IN_HOU_BILLS_Cargo();
			appInHouBillsCargo.setApp_num(appNum);
			appInHouBillsCargo.setSeq_num(seqNum);
			appInHouBillsCargo.setIndv_seq_num(indvSeqNum);
			appInHouBillsCargo.setSrc_app_ind(srcAppInd);
			appInHouBillsCargo.setBill_type(expenseType);
			appInHouBillsCargo.setBillTypeDesc(expenseDetail.getExpenseType());
			appInHouBillsCargo.setPymt_freq(processFrequency(expenseDetail.getFrequency()));
			appInHouBillsCargo.setPymt_amt(expenseDetail.getAmount());

			String expenseDetailStr = new ObjectMapper().writeValueAsString(expenseDetail);
			appInHouBillsCargo.setHouBillsCalsawsObject(expenseDetailStr);
		
		return appInHouBillsCargo;
	}

	/**
	 * Method to set values related to Asset into APP_IN_LQD_ASET_Cargo from..
	 * CaseIndividualDetails.
	 * 
	 * @param appNum
	 * @param indvSeqNum
	 * @param caseIndv
	 * @param srcAppInd
	 * @return
	 */
	private APP_IN_LQD_ASET_Cargo[] setCaseIndividualAssetDetails(String appNum, Integer indvSeqNum,
			CaseIndividualDetails caseIndv, String srcAppInd) throws JsonProcessingException {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.setCaseIndividualAssetDetails() - START");
		
			APP_IN_LQD_ASET_Cargo[] appInLqdAsetCargo = null;
			if (caseIndv != null && caseIndv.getAssetNewInfo() != null) {
				ResourceBundle rb = ResourceBundle.getBundle("mcAssetMapping");
				List<String> lqdAssetTypeLst = getTypeList(FinancialInfoConstants.LQD_ASSET_TYPE);
				appInLqdAsetCargo = new APP_IN_LQD_ASET_Cargo[caseIndv.getAssetNewInfo().length];
				Integer seqNum = 1;
				for (int i = 0; i < caseIndv.getAssetNewInfo().length; i++) {
					APP_IN_LQD_ASET_Cargo asetcargo = new APP_IN_LQD_ASET_Cargo();
					asetcargo.setApp_num(appNum);
					asetcargo.setIndv_seq_num(indvSeqNum);
					asetcargo.setSrc_app_ind(srcAppInd);
					if (Objects.nonNull(caseIndv.getAssetNewInfo()[i].getDateOfChange())) {
						asetcargo.setAsset_change_dt(caseIndv.getAssetNewInfo()[i].getDateOfChange());
					}
					asetcargo.setLqd_aset_amt(caseIndv.getAssetNewInfo()[i].getAmount());
					if (Objects.nonNull(caseIndv.getAssetNewInfo()[i].getAssetCode())) {
						String lqdAssetType = processLqdAssetType(rb, caseIndv.getAssetNewInfo()[i].getAssetCode());
						if (lqdAssetTypeLst.contains(lqdAssetType)) {
							asetcargo.setLqd_aset_typ(lqdAssetType);
						} else{
							asetcargo.setLqd_aset_typ(FinancialInfoConstants.OTHER_TYPE);
						}
					}else {
						asetcargo.setLqd_aset_typ(FinancialInfoConstants.OTHER_TYPE);
					}
					asetcargo.setTransaction_type(caseIndv.getAssetNewInfo()[i].getAssetType());
					asetcargo.setAsset_comments(caseIndv.getAssetNewInfo()[i].getAddnalDetails());
					asetcargo.setSeq_num(seqNum);

					String assetNewInfoStr = new ObjectMapper().writeValueAsString(caseIndv.getAssetNewInfo()[i]);
					asetcargo.setLqdAssetCalsawsObject(assetNewInfoStr);

					seqNum++;
					appInLqdAsetCargo[i] = asetcargo;
				}

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.setCaseIndividualAssetDetails() - END");
			}
			return appInLqdAsetCargo;
	}

	/**
	 * Method to set values related to Personal Property into.
	 * APP_IN_P_PROP_ASET_Cargo from CaseIndividualDetails..
	 * 
	 * @param appNum
	 * @param indvSeqNum
	 * @param caseIndv
	 * @param srcAppInd
	 * @return
	 */
	private APP_IN_P_PROP_ASET_Cargo[] setCaseIndividualPPropDetails(String appNum, Integer indvSeqNum,
			CaseIndividualDetails caseIndv, String srcAppInd, APP_IN_LQD_ASET_Collection appInLqdAsetCollection)
			throws JsonProcessingException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.setCaseIndividualPPropDetails() - START");
		APP_IN_P_PROP_ASET_Cargo[] appInPPropAsetcargo = null;
		if (Objects.nonNull(caseIndv) && Objects.nonNull(caseIndv.getPersonalPropertyDetail())) {
			ResourceBundle rb = ResourceBundle.getBundle("mcPersonalPropMapping");
			List<APP_IN_P_PROP_ASET_Cargo> appInPPropAsetList = new ArrayList<>();
			Integer seqNum = 1;
			for (int i = 0; i < caseIndv.getPersonalPropertyDetail().length; i++) {
				String personalPropType = processPersonalPropType(rb,
						caseIndv.getPersonalPropertyDetail()[i].getPersonalPropCode());

				if (Objects.nonNull(personalPropType)) {
					APP_IN_P_PROP_ASET_Cargo pPropAsetCargo = new APP_IN_P_PROP_ASET_Cargo();
					pPropAsetCargo.setApp_num(appNum);
					pPropAsetCargo.setIndv_seq_num(indvSeqNum);
					pPropAsetCargo.setSrc_app_ind(srcAppInd);
					pPropAsetCargo.setPrsn_prop_amt(caseIndv.getPersonalPropertyDetail()[i].getAmount());
					if (Objects.nonNull(caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo())) {
						if (Objects.nonNull(
								caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo().getDateOfChange())) {
							pPropAsetCargo.setChg_dt(
									caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo().getDateOfChange());
						}
						pPropAsetCargo.setTransaction_type(
								caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo().getTransactionType());
						pPropAsetCargo.setAdditional_details(
								caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo().getAddnalDetails());
					}
					pPropAsetCargo.setPrsn_prop_aset_typ(personalPropType);
					pPropAsetCargo
							.setPrsnPropAsetTypDesc(caseIndv.getPersonalPropertyDetail()[i].getPersonalPropType());
					pPropAsetCargo.setSeq_num(seqNum);

					String personalPropDetailStr = new ObjectMapper()
							.writeValueAsString(caseIndv.getPersonalPropertyDetail()[i]);
					pPropAsetCargo.setpPropCalsawsObject(personalPropDetailStr);

					seqNum++;
					appInPPropAsetList.add(pPropAsetCargo);
				} else {
					processAmbiguousPropRecord(appNum, indvSeqNum, caseIndv, srcAppInd, appInLqdAsetCollection, i);
				}
			}
			
			if (!appInPPropAsetList.isEmpty()) {
				appInPPropAsetcargo = new APP_IN_P_PROP_ASET_Cargo[appInPPropAsetList.size()];
				for (int i = 0; i < appInPPropAsetList.size(); i++) {
					appInPPropAsetcargo[i] = appInPPropAsetList.get(i);
				}
			}
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.setCaseIndividualPPropDetails() - END");
		return appInPPropAsetcargo;
	}

	private void processAmbiguousPropRecord(String appNum, Integer indvSeqNum, CaseIndividualDetails caseIndv,
			String srcAppInd, APP_IN_LQD_ASET_Collection appInLqdAsetCollection, int i)
			throws JsonProcessingException {
		Integer lqdSeqNum = 0;
		if (appInLqdAsetCollection.getResults().length > 0) {
			lqdSeqNum = Arrays.asList(appInLqdAsetCollection.getResults()).stream()
					.filter(x -> indvSeqNum.equals(x.getIndv_seq_num())).map(APP_IN_LQD_ASET_Cargo::getSeq_num)
					.max((x, y) -> x - y).orElse(0);
		}

		APP_IN_LQD_ASET_Cargo appInLqdAsetCargo = new APP_IN_LQD_ASET_Cargo();
		appInLqdAsetCargo.setApp_num(appNum);
		appInLqdAsetCargo.setIndv_seq_num(indvSeqNum);
		appInLqdAsetCargo.setSeq_num(++lqdSeqNum);
		appInLqdAsetCargo.setSrc_app_ind(srcAppInd);
		appInLqdAsetCargo.setLqd_aset_amt(caseIndv.getPersonalPropertyDetail()[i].getAmount());
		appInLqdAsetCargo.setLqd_aset_typ(FinancialInfoConstants.OTHER_TYPE);
		appInLqdAsetCargo.setTransaction_type(caseIndv.getPersonalPropertyDetail()[i].getPersonalPropType());

		if (Objects.nonNull(caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo())) {
			appInLqdAsetCargo
					.setAsset_comments(caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo().getAddnalDetails());
			appInLqdAsetCargo
					.setAsset_change_dt(caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo().getDateOfChange());
		}

		CaseIndividualDetailsAsset caseIndividualDetailsAsset = processPersonalPropToAsset(caseIndv, i);

		String assetNewInfoStr = new ObjectMapper().writeValueAsString(caseIndividualDetailsAsset);
		appInLqdAsetCargo.setLqdAssetCalsawsObject(assetNewInfoStr);
		appInLqdAsetCollection.add(appInLqdAsetCargo);
	}

	private CaseIndividualDetailsAsset processPersonalPropToAsset(CaseIndividualDetails caseIndv, int i) {
		CaseIndividualDetailsAsset caseIndividualDetailsAsset = new CaseIndividualDetailsAsset();
		caseIndividualDetailsAsset.setPerson(caseIndv.getPersonalPropertyDetail()[i].getPerson());
		caseIndividualDetailsAsset.setAssetType(caseIndv.getPersonalPropertyDetail()[i].getPersonalPropType());
		caseIndividualDetailsAsset.setAmount(caseIndv.getPersonalPropertyDetail()[i].getAmount());
		if (Objects.nonNull(caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo())) {
			caseIndividualDetailsAsset
					.setDateOfChange(caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo().getDateOfChange());
			caseIndividualDetailsAsset.setTransactionType(
					caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo().getTransactionType());
			caseIndividualDetailsAsset
					.setAddnalDetails(caseIndv.getPersonalPropertyDetail()[i].getPesonalPropInfo().getAddnalDetails());
		}
		return caseIndividualDetailsAsset;
	}

	/**
	 * Method to set values related to Vehicle And Property Details into..
	 * APP_IN_R_PROP_ASET_Cargo from CaseIndividualDetails.
	 * 
	 * @param appNum
	 * @param indvSeqNum
	 * @param caseIndv
	 * @param srcAppInd
	 * @return APP_IN_R_PROP_ASET_Cargo type
	 */
	@SuppressWarnings("squid:S3776")
	private List<APP_IN_R_PROP_ASET_Cargo> setAppInRVehAnsPropDetails(String appNum, Integer indvSeqNum, String srcAppInd,
			CaseIndividualDetails caseIndv) throws JsonProcessingException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.setAppInRVehAnsPropDetails() - START");
		List<APP_IN_R_PROP_ASET_Cargo> appInRPropAsetAryCargo = null;
			if (Objects.nonNull(caseIndv) && Objects.nonNull(caseIndv.getVehicleAndProperty())) {
				appInRPropAsetAryCargo = new ArrayList<>();
				Integer seqNum = 1;
				for (int i = 0; i < caseIndv.getVehicleAndProperty().length; i++) {
					if (Objects.isNull(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail())) {
						APP_IN_R_PROP_ASET_Cargo cpAppInRPropAsetCargo = new APP_IN_R_PROP_ASET_Cargo();
						if (Objects.nonNull(appNum) && Objects.nonNull(indvSeqNum) && Objects.nonNull(srcAppInd)) {
							cpAppInRPropAsetCargo.setApp_num(appNum);
							cpAppInRPropAsetCargo.setIndv_seq_num(indvSeqNum);
							cpAppInRPropAsetCargo.setSrc_app_ind(srcAppInd);
						}
						if (Objects.nonNull(caseIndv.getVehicleAndProperty())
								&& Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getAddress()))
						{
							setVehicleAndPropertyAddress(caseIndv, i, cpAppInRPropAsetCargo);
						}

						if (Objects.nonNull(caseIndv.getVehicleAndProperty())) {

							seqNum = setVehicleAndPropertyDetails(seqNum, caseIndv, appInRPropAsetAryCargo, i,
									cpAppInRPropAsetCargo);
						}
					}
				}
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"RedeterminationServiceImpl.setAppInRVehAnsPropDetails() - END");
			return appInRPropAsetAryCargo;
		
	}

	private Integer setVehicleAndPropertyDetails(Integer seqNum, CaseIndividualDetails caseIndv,
			List<APP_IN_R_PROP_ASET_Cargo> appInRPropAsetAryCargo, int i, APP_IN_R_PROP_ASET_Cargo cpAppInRPropAsetCargo)
			throws JsonProcessingException {
			if (caseIndv.getVehicleAndProperty()[i].getValue() != null) {
				cpAppInRPropAsetCargo.setValue(caseIndv.getVehicleAndProperty()[i].getValue());
			}

			if (caseIndv.getVehicleAndProperty()[i].getAmountOwed() != null) {
				cpAppInRPropAsetCargo.setAmountOwed(caseIndv.getVehicleAndProperty()[i].getAmountOwed());
			}
			
			cpAppInRPropAsetCargo.setVehicleandpropertytypeDesc(caseIndv.getVehicleAndProperty()[i].getVehicleandpropertytype());

			seqNum = setPropertyInfoDetails(seqNum, caseIndv, appInRPropAsetAryCargo, i, cpAppInRPropAsetCargo);

			return seqNum;
	}
	@SuppressWarnings("squid:S3776")
	private Integer setPropertyInfoDetails(Integer seqNum, CaseIndividualDetails caseIndv,
			List<APP_IN_R_PROP_ASET_Cargo> appInRPropAsetAryCargo, int i, APP_IN_R_PROP_ASET_Cargo cpAppInRPropAsetCargo)
			throws JsonProcessingException {
			if (caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail() != null) {
				setVehiclePropertyInfoDetails(caseIndv, i, cpAppInRPropAsetCargo);

				if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isPropertyForSale())
						&& caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isPropertyForSale()) {
					cpAppInRPropAsetCargo.setForSaleInd("1");
				} else {
					cpAppInRPropAsetCargo.setForSaleInd("0");
				}

				if (Objects
						.nonNull(caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isFamilyMemberLivingInd())
						&& caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isFamilyMemberLivingInd()) {
					cpAppInRPropAsetCargo.setFamilyInd(FinancialInfoConstants.Y);
				} else {
					cpAppInRPropAsetCargo.setFamilyInd(FinancialInfoConstants.N);
				}

				if (caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().getRelationshipToYou() != null) {
					cpAppInRPropAsetCargo.setFamilyRelation(
							caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().getRelationshipToYou());
				}

				if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isPlanToLiveSomeday())
						&& caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isPlanToLiveSomeday()) {
					cpAppInRPropAsetCargo.setPlanToLiveSomedayInd(FinancialInfoConstants.Y);
				} else {
					cpAppInRPropAsetCargo.setPlanToLiveSomedayInd(FinancialInfoConstants.N);
				}
			}
			cpAppInRPropAsetCargo.setSeq_num(seqNum);

			String vehAndPropStr = new ObjectMapper().writeValueAsString(caseIndv.getVehicleAndProperty()[i]);
			cpAppInRPropAsetCargo.setrPropCalsawsObject(vehAndPropStr);

			seqNum++;
			appInRPropAsetAryCargo.add(cpAppInRPropAsetCargo);
			return seqNum;
	}
	@SuppressWarnings("squid:S2776")
	private void setVehiclePropertyInfoDetails(CaseIndividualDetails caseIndv, int i,
			APP_IN_R_PROP_ASET_Cargo cpAppInRPropAsetCargo) {
			if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isCurrentLivingHome())
					&& caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isCurrentLivingHome()) {
				cpAppInRPropAsetCargo.setIndividual_live_ind("1");
			} else {
				cpAppInRPropAsetCargo.setIndividual_live_ind("0");
			}

			if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isRentalInvestment())
					&& caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isRentalInvestment()) {
				cpAppInRPropAsetCargo.setIntn_ret_sw("1");
			} else {
				cpAppInRPropAsetCargo.setIntn_ret_sw("0");
			}

			if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isFormerHome())
					&& caseIndv.getVehicleAndProperty()[i].getPropertyInfoDetail().isFormerHome()) {
				cpAppInRPropAsetCargo.setFormerHouseInd("1");
			} else {
				cpAppInRPropAsetCargo.setFormerHouseInd("0");
			}
	}
	@SuppressWarnings("squid:S2776")
	private void setVehicleAndPropertyAddress(CaseIndividualDetails caseIndv, int i,
			APP_IN_R_PROP_ASET_Cargo cpAppInRPropAsetCargo) {
			if ((caseIndv.getVehicleAndProperty()[i].getAddress().getAddressLine()) != null) {
				cpAppInRPropAsetCargo.setProp_l1_adr(caseIndv.getVehicleAndProperty()[i].getAddress().getAddressLine());
			}

			if (caseIndv.getVehicleAndProperty()[i].getAddress().getApt() != null) {
				cpAppInRPropAsetCargo.setProp_l2_adr(caseIndv.getVehicleAndProperty()[i].getAddress().getApt());
			}

			if (caseIndv.getVehicleAndProperty()[i].getAddress().getCity() != null) {
				cpAppInRPropAsetCargo.setProp_city_adr(caseIndv.getVehicleAndProperty()[i].getAddress().getCity());
			}

			if (caseIndv.getVehicleAndProperty()[i].getAddress().getState() != null) {
				cpAppInRPropAsetCargo.setProp_sta_adr(caseIndv.getVehicleAndProperty()[i].getAddress().getState());
			}

			if (caseIndv.getVehicleAndProperty()[i].getAddress().getZipcode() != null) {
				cpAppInRPropAsetCargo.setProp_zip_adr(caseIndv.getVehicleAndProperty()[i].getAddress().getZipcode());
			}
	}

	/**
	 * Method to set values related to Vehicle And Property Details into.
	 * APP_IN_VEH_ASET_Cargo from CaseIndividualDetails.
	 * 
	 * @param appNum
	 * @param indvSeqNum
	 * @param caseIndv
	 * @param srcAppInd
	 * @return APP_IN_VEH_ASET_Cargo type
	 */

	private List<APP_IN_VEH_ASET_Cargo> setAppInVehAsetDetails(String appNum, Integer indvSeqNum, String srcAppInd,
			CaseIndividualDetails caseIndv, String vehAssetType) throws JsonProcessingException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedeterminationServiceImpl.setAppInVehAsetDetails() - START");
		List<APP_IN_VEH_ASET_Cargo> appInVehAsetAryCargo = null;
			if (Objects.nonNull(caseIndv) && Objects.nonNull(caseIndv.getVehicleAndProperty())) {
				appInVehAsetAryCargo = new ArrayList<>();
				Integer seqNum = 1;
				for (int i = 0; i < caseIndv.getVehicleAndProperty().length; i++) {
					if (Objects.nonNull(caseIndv.getVehicleAndProperty())
							&& Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail())) {
						APP_IN_VEH_ASET_Cargo cpAppInVehAsetCargo = new APP_IN_VEH_ASET_Cargo();
						
						cpAppInVehAsetCargo.setApp_num(appNum);
						cpAppInVehAsetCargo.setIndv_seq_num(indvSeqNum);
						cpAppInVehAsetCargo.setSrc_app_ind(srcAppInd);

						if (Objects.nonNull(vehAssetType)) {
							cpAppInVehAsetCargo.setVeh_aset_typ(vehAssetType);
						}
						setVehicleAssetDetails(caseIndv, i, cpAppInVehAsetCargo);

						cpAppInVehAsetCargo.setSeq_num(seqNum);
						seqNum++;
						appInVehAsetAryCargo.add(cpAppInVehAsetCargo);
					}
				}
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.setAppInVehAsetDetails() - END");

			}
			return appInVehAsetAryCargo;
	}

	private void setVehicleAssetDetails(CaseIndividualDetails caseIndv, int i,
			APP_IN_VEH_ASET_Cargo cpAppInVehAsetCargo) throws JsonProcessingException {
			if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail().getYear())) {
				cpAppInVehAsetCargo.setMv_yr(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail().getYear());
			}
			if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail().getMake())) {
				cpAppInVehAsetCargo
						.setMv_make_txt(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail().getMake());
			}
			if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail().getModel())) {
				cpAppInVehAsetCargo
						.setMv_modl_txt(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail().getModel());
			}
			if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail().getEstimatedValue())) {
				cpAppInVehAsetCargo.setMv_fmv_amt(
						Double.valueOf(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail().getEstimatedValue()));
			}
			if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail().getAmountOwed())) {
				cpAppInVehAsetCargo.setMv_owe_amt(Double.valueOf(
						caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail().getAmountOwed().intValue()));
			}
			if (Objects.nonNull(caseIndv.getVehicleAndProperty()[i].getVehicleandpropertytype())) {
				cpAppInVehAsetCargo
						.setVehicleandpropertytypeDesc(caseIndv.getVehicleAndProperty()[i].getVehicleandpropertytype());
			}

			String vehicleInfoDetailStr = new ObjectMapper()
					.writeValueAsString(caseIndv.getVehicleAndProperty()[i].getVehicleInfoDetail());
			cpAppInVehAsetCargo.setVehAssetCalsawsObject(vehicleInfoDetailStr);

	}

	public void storeNonFinDetails(FwTransaction fwTxn) throws Exception {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"Inside RedeterminationServiceImpl.storeNonFinDetails - START");
		try {
			PageActionDetails action = fwTxn.getCurrentActionDetails();
			action.setPageAction("MCNFNLoad");
			action.setPageId("MCNFN");

			fwTxn.setCurrentActionDetails(action);

			String payload = ServiceChainUtil.prepareAWSRequest("POST", FwConstants.NF_STORE_NONFIN_DETAIL_URL,
					FwConstants.NF_STORE_NONFIN_DETAIL_URL, fwTxn);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"Payload received for RedeterminationServiceImpl.storeNonFinDetails " + payload);

			AWSLambda client = AWSLambdaClient.builder().withRegion(System.getenv(FwConstants.REGION_SYS_ENV)).build();

			InvokeRequest request = new InvokeRequest();
			request.setInvocationType(InvocationType.RequestResponse);
			request.setFunctionName(System.getenv(FwConstants.NONFIN_FUNC_SYS_ENV));
			request.setPayload(payload);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"Invoking RedeterminationServiceImpl.storeNonFinDetails client");
			InvokeResult invoke = client.invoke(request);
			String response = null;
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"Status code RedeterminationServiceImpl.storeNonFinDetails: " + invoke.getStatusCode());

			if (invoke.getStatusCode() == 200) {
				response = StandardCharsets.UTF_8.decode(invoke.getPayload()).toString();
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeNonFinDetails Response received : " + response);
				handleNonFinException(response);
			} else {
				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"RedeterminationServiceImpl.storeNonFinDetails nonFinService call failure with "
								+ invoke.getStatusCode());
				throwException("Exception occur while Non Financial Lambda Invocation with status code "
						+ invoke.getStatusCode());
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in RedeterminationServiceImpl.storeNonFinDetails()", fwTxn);
			throw e;
		}
	}
	
	public void handleNonFinException(String response) throws JsonProcessingException {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"Inside RedeterminationServiceImpl.handleNonFinException - START");
		var mapper = new ObjectMapper();
		var resultResponse = mapper.readValue(response, InvokeResultResponse.class);
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"After Object mapping of response to InvokeResultResponse...");
		var successStatusCode = 200;
		if (Objects.nonNull(resultResponse) && successStatusCode != resultResponse.getStatusCode()) {
			throwException(
					"Exception occur on Non Financial Service with status code " + resultResponse.getStatusCode());
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"Inside RedeterminationServiceImpl.handleNonFinException - end");
	}
	
	private void throwException(String message) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "Inside RedeterminationServiceImpl.throwException - START");
		throw new RuntimeException(message);
	}

	private String processFrequency(Integer frequency) {
		
		if(null == frequency) {
			return null;
		}
		String freqStr = String.valueOf(frequency);
		return (!freqStr.isEmpty() && freqStr.length() == 1) ? "0" + freqStr
				: freqStr;
	}
}
