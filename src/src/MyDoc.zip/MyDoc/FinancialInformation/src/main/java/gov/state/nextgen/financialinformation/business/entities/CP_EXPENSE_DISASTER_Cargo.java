package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "CP_EXPENSE_DISASTER")
@IdClass(CP_EXPENSE_DISASTER_Key.class)
public class CP_EXPENSE_DISASTER_Cargo extends AbstractCargo implements Serializable {
	
	private static final long serialVersionUID = 755070021146152635L;

	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	
	private String src_app_ind;
	
	@Id
	private String exp_type;
	
	private Double exp_amt;

	public String getApp_num() {
		return String.valueOf(app_number);
	}

	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public String getExp_type() {
		return exp_type;
	}

	public void setExp_type(String exp_type) {
		this.exp_type = exp_type;
	}

	public Double getExp_amt() {
		return exp_amt;
	}

	public void setExp_amt(Double exp_amt) {
		this.exp_amt = exp_amt;
	}
	
	

}
