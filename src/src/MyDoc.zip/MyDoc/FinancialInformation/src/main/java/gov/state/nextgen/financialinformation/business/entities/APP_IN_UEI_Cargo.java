
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "CP_APP_IN_UEI")
@IdClass(APP_IN_UEI_Id.class)
public class APP_IN_UEI_Cargo extends AbstractCargo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "app_num")
	private int app_number;
	@Transient
	private String app_num;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	
	private String src_app_ind;
	@Transient
	private String ecp_id;
	@Column(name="change_eff_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_eff_dt;
	private Integer rec_cplt_ind;
	private Double uei_amt;
	private Integer uei_amt_ind;
	@Column(name="uei_begin_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date uei_beg_dt;
	@Id
	@Column(name="uei_type")
	private String uei_typ;
	private String rsdi_income_expected_sw;
	@Column(name="other_income_src")
	private String othr_incm_src;
	private String expected_to_cont_resp;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date uei_end_dt;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date end_dt;
	@Transient
	private String loopingQuestion;
	private String money_providing_person_name;
	@Transient
	private String money_direct_ind;
	@Transient
	private String loan_ind;
	@Transient
	private String money_pay_back_ind;
	private String freq_cd;
	@Transient
	private String uei_claim_num;
	private String uei_Sub_Type;
	@Column(name="change_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_dt;
	@Transient
	private String fst_nam;
	@Transient
	private String loopingFlag;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date income_receipt_end_dt;
	private String uei_another_resp;
	private String end_ind;
	private String end_reason;
	private String state;
	private String county;
	private String services;
	private Double value_of_services;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date dt_services_rcvd;
	public String getAddtl_info() {
		return addtl_info;
	}
	public void setAddtl_info(String addtl_info) {
		this.addtl_info = addtl_info;
	}
	private String comments;
	private String addtl_info;
	private String income_source;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date divorce_dt;
    
	@Column(name = "uei_calsaws_object")
	private String ueiCalsawsObject;
	
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public Integer getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public Date getChg_eff_dt() {
		return chg_eff_dt;
	}
	public void setChg_eff_dt(Date chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public Double getUei_amt() {
		return uei_amt;
	}
	public void setUei_amt(Double uei_amt) {
		this.uei_amt = uei_amt;
	}
	public Integer getUei_amt_ind() {
		return uei_amt_ind;
	}
	public void setUei_amt_ind(Integer uei_amt_ind) {
		this.uei_amt_ind = uei_amt_ind;
	}
	public Date getUei_beg_dt() {
		return uei_beg_dt;
	}
	public void setUei_beg_dt(Date uei_beg_dt) {
		this.uei_beg_dt = uei_beg_dt;
	}
	public String getUei_typ() {
		return uei_typ;
	}
	public void setUei_typ(String uei_typ) {
		this.uei_typ = uei_typ;
	}
	public String getRsdi_income_expected_sw() {
		return rsdi_income_expected_sw;
	}
	public void setRsdi_income_expected_sw(String rsdi_income_expected_sw) {
		this.rsdi_income_expected_sw = rsdi_income_expected_sw;
	}
	public String getOthr_incm_src() {
		return othr_incm_src;
	}
	public void setOthr_incm_src(String othr_incm_src) {
		this.othr_incm_src = othr_incm_src;
	}
	public String getExpected_to_cont_resp() {
		return expected_to_cont_resp;
	}
	public void setExpected_to_cont_resp(String expected_to_cont_resp) {
		this.expected_to_cont_resp = expected_to_cont_resp;
	}
	public Date getUei_end_dt() {
		return uei_end_dt;
	}
	public void setUei_end_dt(Date uei_end_dt) {
		this.uei_end_dt = uei_end_dt;
	}
	public String getLoopingQuestion() {
		return loopingQuestion;
	}
	public void setLoopingQuestion(String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}
	public String getMoney_providing_person_name() {
		return money_providing_person_name;
	}
	public void setMoney_providing_person_name(String money_providing_person_name) {
		this.money_providing_person_name = money_providing_person_name;
	}
	public String getMoney_direct_ind() {
		return money_direct_ind;
	}
	public void setMoney_direct_ind(String money_direct_ind) {
		this.money_direct_ind = money_direct_ind;
	}
	public String getLoan_ind() {
		return loan_ind;
	}
	public void setLoan_ind(String loan_ind) {
		this.loan_ind = loan_ind;
	}
	public String getMoney_pay_back_ind() {
		return money_pay_back_ind;
	}
	public void setMoney_pay_back_ind(String money_pay_back_ind) {
		this.money_pay_back_ind = money_pay_back_ind;
	}
	public String getFreq_cd() {
		return freq_cd;
	}
	public void setFreq_cd(String freq_cd) {
		this.freq_cd = freq_cd;
	}
	public String getUei_claim_num() {
		return uei_claim_num;
	}
	public void setUei_claim_num(String uei_claim_num) {
		this.uei_claim_num = uei_claim_num;
	}
	public String getUei_Sub_Type() {
		return uei_Sub_Type;
	}
	public void setUei_Sub_Type(String uei_Sub_Type) {
		this.uei_Sub_Type = uei_Sub_Type;
	}
	public Date getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(Date chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getFst_nam() {
		return fst_nam;
	}
	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}
	public String getLoopingFlag() {
		return loopingFlag;
	}
	public void setLoopingFlag(String loopingFlag) {
		this.loopingFlag = loopingFlag;
	}
	public Date getIncome_receipt_end_dt() {
		return income_receipt_end_dt;
	}
	public void setIncome_receipt_end_dt(Date income_receipt_end_dt) {
		this.income_receipt_end_dt = income_receipt_end_dt;
	}
	public String getUei_another_resp() {
		return uei_another_resp;
	}
	public void setUei_another_resp(String uei_another_resp) {
		this.uei_another_resp = uei_another_resp;
	}
	public String getEnd_ind() {
		return end_ind;
	}
	public void setEnd_ind(String end_ind) {
		this.end_ind = end_ind;
	}
	public String getEnd_reason() {
		return end_reason;
	}
	public void setEnd_reason(String end_reason) {
		this.end_reason = end_reason;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getServices() {
		return services;
	}
	public void setServices(String services) {
		this.services = services;
	}
	public Double getValue_of_services() {
		return value_of_services;
	}
	public void setValue_of_services(Double value_of_services) {
		this.value_of_services = value_of_services;
	}
	public Date getDt_services_rcvd() {
		return dt_services_rcvd;
	}
	public void setDt_services_rcvd(Date dt_services_rcvd) {
		this.dt_services_rcvd = dt_services_rcvd;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getIncome_source() {
		return income_source;
	}
	public void setIncome_source(String income_source) {
		this.income_source = income_source;
	}
	public Date getDivorce_dt() {
		return divorce_dt;
	}
	public void setDivorce_dt(Date divorce_dt) {
		this.divorce_dt = divorce_dt;
	}

	public String getUeiCalsawsObject() {
		return ueiCalsawsObject;
	}
	public void setUeiCalsawsObject(String ueiCalsawsObject) {
		this.ueiCalsawsObject = ueiCalsawsObject;
	}

	public Date getEnd_dt() {
		return end_dt;
	}
	public void setEnd_dt(Date end_dt) {
		this.end_dt = end_dt;
	}
    
    
}