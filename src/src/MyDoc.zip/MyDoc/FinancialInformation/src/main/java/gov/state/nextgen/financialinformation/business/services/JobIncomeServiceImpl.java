package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_PAY_STUB_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_PAY_STUB_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFEMP_PAY_STUB_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFEMP_PAY_STUB_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_INCOME_DISASTER_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_INCOME_DISASTER_Collection;
import gov.state.nextgen.financialinformation.business.entities.MCIncomeDetails;
import gov.state.nextgen.financialinformation.business.entities.MCIncomeIndividual_Cargo;
import gov.state.nextgen.financialinformation.business.entities.MCIncomeIndividual_Collection;
import gov.state.nextgen.financialinformation.business.entities.Questionnarie_jobIncomeCargo;
import gov.state.nextgen.financialinformation.business.entities.Questionnarie_jobIncomeCollection;
import gov.state.nextgen.financialinformation.business.rules.ABEmploymentBO;
import gov.state.nextgen.financialinformation.business.rules.ABJobIncomeBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherIncomeBO;
import gov.state.nextgen.financialinformation.business.rules.DisasterFinanceBO;
import gov.state.nextgen.financialinformation.business.rules.JobIncomeBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInPrflRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInSelfeRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInUieRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInEmplRepository;
import gov.state.nextgen.framework.business.model.IndividualCategorySequenceDetails;
import gov.state.nextgen.framework.business.model.UserDetails;

@SuppressWarnings("squid:S2229")
@Service("JobIncomeServiceImpl")
public class JobIncomeServiceImpl implements FinancialServInterface {

	private static final String APP_IN_EMPL_COLL = "APP_IN_EMPL_Collection";

	private static final String APP_IN_SELFE_COLL = "APP_IN_SELFE_Collection";

	private static final String APP_IN_PRFL_COLL = "APP_IN_PRFL_Collection";

	private static final String INDV_IDS = "indvIds";

	private static final String SELF_EMPL_INCOME = "SELF_EMPL_INCOME";

	private static final String EARNED_EMPL_INCOME = "EARNED_EMPL_INCOME";

	private static final String UNEARNED_EMPL_INCOME = "UNEARNED_EMPL_INCOME";

	private static final String APP_INDV_COLL = "APP_INDV_Collection";

	private static final String MILLISECONDS = "milliseconds";
	
	private static final String MC_INCOME_DETAILS = "MC_INCOME_DETAILS";
	
	private static final String INCOMEMAXSEQNUM = "IncomeMaxSeqNum";
	
	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {

		switch (methodName) {

		case FinancialInfoConstants.GET_EMPL_DET:
			this.getEmploymentDetail(fwTxn);
			break;

		case FinancialInfoConstants.STORE_EMP_DET:
			this.storeEmploymentDetail(fwTxn);
			break;

		case FinancialInfoConstants.GET_SELF_EMP_DET:
			this.getSelfEmploymentDetail(fwTxn);
			break;

		case FinancialInfoConstants.STORE_SELF_EMP_DET:
			this.storeSelfEmploymentDetail(fwTxn);
			break;

		case FinancialInfoConstants.STORE_INC_DET:
			this.storeIncomeDetails(fwTxn);
			break;
		case FinancialInfoConstants.GET_INC_DET:
			this.getIncomeDetails(fwTxn);
			break;
		case FinancialInfoConstants.GET_JOB_INC_SUMM_DET:
			this.getJobIncomeSummaryDetails(fwTxn);
			break;
		case FinancialInfoConstants.STORE_MONTOMON_INC_CHG_DET:
			this.storeMonthToMonthIncomeChangeDetails(fwTxn);
			break;
		case FinancialInfoConstants.LOAD_MNTOMON_INC_CHG_DET:
			this.loadMonthToMonthIncomeChangeDetails(fwTxn);
			break;
		case FinancialInfoConstants.DELETE_MONTOMON_INC_CHG_DET:
			this.deleteMonthToMonthIncomeChangeDetails(fwTxn);
			break;
		case FinancialInfoConstants.STORE_CNG_INC_DET:
			this.storeChangeInIncomeDetails(fwTxn);
			break;
		case FinancialInfoConstants.LOAD_CHG_IN_INC_DET:
			this.loadChangeInIncomeDetails(fwTxn);
			break;
		case FinancialInfoConstants.DELETE_CHG_IN_INC_DET:
			this.deleteChangeInIncomeDetails(fwTxn);
			break;
		case FinancialInfoConstants.DELETE_UNEARNED_INC_DET:
			this.deleteUnearnedIncomeDetails(fwTxn);
			break;
		case FinancialInfoConstants.DELETE_SELF_AND_EARNED_INC_DET:
			this.deleteSelfAndEarnedIncomeDetails(fwTxn);
			break;
		case FinancialInfoConstants.DELETE_EARNED_INC_DET:
			this.deleteEarnedIncomeDetails(fwTxn);
			break;
		case FinancialInfoConstants.DELETE_INC_INKIND_DET:
			this.deleteIncomeInKindDetails(fwTxn);
			break;

		case FinancialInfoConstants.STOREINCOMEDETAILSDCF:
			this.storeIncomeDetailsDCF(fwTxn);
			break;
		case FinancialInfoConstants.LOADINCOMEDETAILSDCF:
			this.loadIncomeDetailsDCF(fwTxn);
			break;
		case FinancialInfoConstants.GETLOSTJOBDETAIL:
			this.getLostJobDetail(fwTxn);
			break;
		case FinancialInfoConstants.DELETELOSTJOBDETAILS:
			this.deleteLostJobDetails(fwTxn);
			break;
		case FinancialInfoConstants.STORE_PR_SELF_EARNED_INCOME:
			this.storePRSelfEmployment(fwTxn);
			break;
		case FinancialInfoConstants.STORE_PR_EARNED_INCOME:
			this.storePREmployment(fwTxn);
			break;
		case FinancialInfoConstants.LOAD_PR_SELF_EARNED_INCOME:
			this.loadSeflEmploymentPayStub(fwTxn);
			break;

		case FinancialInfoConstants.LOADMCINCOMEDETAILS:
			this.loadAllIncomeDetailsMC(fwTxn);
			break;

		case  FinancialInfoConstants.LOAD_PR_EARNED_INCOME:
			this.loadEmploymentPayStub(fwTxn);
			break;

		case FinancialInfoConstants.STORE_MC_INCOME_DETAILS:
			this.storeMCIncomeDetails(fwTxn);
			break;

		case FinancialInfoConstants.STORESELFDETAIL:
			this.storeSelfDetail(fwTxn);
			break;

		case FinancialInfoConstants.DELETEMCINCOMEDETAILS:
			this.deleteMCIncomeDetails(fwTxn);
			break;
		case FinancialInfoConstants.STOREINCOMEINKINDDETAILS:
			storeIncomeInKindDetails(fwTxn);
			break;
		case FinancialInfoConstants.LOADINCOMEINKINDDETAILS:
			loadIncomeInKindDetails(fwTxn);
			break;
		case FinancialInfoConstants.DELETEINCOMEINKINDINFO:
			deleteIncomeInKindInfo(fwTxn);
			break;
		case FinancialInfoConstants.APP_SUMMARY_DATA:
			financialAppSummaryData(fwTxn);
			break;
		default:
			break;

		}
	}

	@Autowired
	private ABEmploymentBO employmentDetailsBO;

	@Autowired
	private ABJobIncomeBO abJobIncomeBO;

	@Autowired
	private JobIncomeBO jobIncomeBO;

	@Autowired
	private ABOtherIncomeBO abOtherIncomeBO;

	@Autowired
	private OtherExpensesServImpl otherExpensesServImpl;

	private AppInPrflRepository appInPrflRepository;

	@Autowired
	private CpAppInEmplRepository cpAppInEmplRepository;

	@Autowired
	private AppInUieRepository appInUieRepository;

	@Autowired
	private AppInSelfeRepository appInSelfeRepository;

	@Autowired
	private OtherIncomeServImpl otherIncomeServImpl;

	@Autowired
	private DisasterFinanceBO disasterFinanceBO;
	
	@Autowired
	ExpenseSummaryServiceImpl expenseSummaryServiceImpl;
	
	@Autowired
	FinancialAssetsServImpl financialAssetsService;
	@Autowired
	LiquidAssetsServImpl liquidAssetsServImpl;

	/******************************************************************************************************************
	 * 
	 * 
	 * Load method for current job details *
	 * 
	 ********************************************************************************************************************
	 */
	@Transactional
	public void getEmploymentDetail(final FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.getEmploymentDetail() - START", fwTxn);
		try {

			Map pageCollection;

			final String appNum = fwTxn.getUserDetails().getAppNumber();

			final Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			final Integer seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());

			// When user hits the Back button or comes from the Summary Page
			pageCollection = new HashMap();
			final APP_IN_EMPL_Collection appInEmplColl = employmentDetailsBO.loadIndividualEmploymentDetails(appNum,
					indv_seq_num, seq_num);

			APP_IN_EMPL_Cargo acargo = null;
			final int size = appInEmplColl.size();
			if (size > 0) {
				// get last cargo from session
				acargo = appInEmplColl.getCargo(size - 1);
			} else {
				acargo = new APP_IN_EMPL_Cargo();
				acargo.setIndv_seq_num(indv_seq_num);
				acargo.setEmpl_seq_num(seq_num);
			}
			final APP_IN_EMPL_Collection newColl = new APP_IN_EMPL_Collection();
			newColl.addCargo(acargo);

			// self emp details
			final APP_IN_SELFE_Collection collSes = abJobIncomeBO.loadIndividualSelfEmploymentDetails(appNum,
					indv_seq_num, seq_num);

			APP_IN_SELFE_Cargo cargoSes;
			final int size2 = collSes.size();
			if (size2 > 0) {
				// get last cargo from session
				cargoSes = collSes.getCargo(size2 - 1);
			} else {
				cargoSes = new APP_IN_SELFE_Cargo();
				cargoSes.setIndv_seq_num(indv_seq_num);
				cargoSes.setSeq_num(seq_num);
			}
			final APP_IN_SELFE_Collection newSelColl = new APP_IN_SELFE_Collection();
			newSelColl.addCargo(cargoSes);

			// add prfl data
			final APP_IN_PRFL_Collection appInPrflBeforeColl = appInPrflRepository.getExistingRecord(appNum,
					indv_seq_num);
			APP_IN_PRFL_Cargo appInPrflBeforeCar;
			final int size1 = appInPrflBeforeColl.size();
			if (size > 0) {
				// get last cargo from session
				appInPrflBeforeCar = appInPrflBeforeColl.getCargo(size1 - 1);
			} else {
				appInPrflBeforeCar = new APP_IN_PRFL_Cargo();
				appInPrflBeforeCar.setIndv_seq_num(indv_seq_num);
			}

			final APP_IN_PRFL_Collection newPrflColl = new APP_IN_PRFL_Collection();
			newPrflColl.addCargo(appInPrflBeforeCar);

			// set Details_Collection from session to PageCollection
			pageCollection.put(APP_IN_EMPL_COLL, newColl);
			pageCollection.put(APP_IN_SELFE_COLL, newSelColl);
			pageCollection.put(APP_IN_PRFL_COLL, newPrflColl);
			// set frist Name to PageCollection

			fwTxn.setPageCollection(pageCollection);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getEmploymentDetail()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_EMPL_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.getEmploymentDetail() - END", fwTxn);
	}

	@Transactional
	public void getIncomeDetails(final FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.getIncomeDetails() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();

			final String appNum = fwTxn.getUserDetails().getAppNumber();

			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();
			String type = categorySequenceDetails.getCategoryType();
			pageCollection = new HashMap();
			final APP_IN_EMPL_Collection appInEmplColl = employmentDetailsBO.getEmploymentDetailsOnIncomeType(appNum,
					type, indvIdList);

			APP_IN_EMPL_Cargo acargo = null;
			final int size = appInEmplColl.size();
			if (size > 0) {
				// get last cargo from session
				pageCollection.put(APP_IN_EMPL_COLL, appInEmplColl);
			}

			// add indv details
			APP_INDV_Collection indvColl = fwTxn.getPageCollection().get(FinancialInfoConstants.APP_INDV_COLL) != null
					? (APP_INDV_Collection) fwTxn.getPageCollection().get(FinancialInfoConstants.APP_INDV_COLL)
					: null;
			// add prfl details
			APP_IN_PRFL_Collection newPrflColl = fwTxn.getPageCollection()
					.get(FinancialInfoConstants.APP_IN_PRFL_COLL) != null
							? (APP_IN_PRFL_Collection) fwTxn.getPageCollection()
									.get(FinancialInfoConstants.APP_IN_PRFL_COLL)
							: null;

			// set Details_Collection from session to PageCollection

			pageCollection.put(APP_IN_PRFL_COLL, newPrflColl);
			pageCollection.put(APP_INDV_COLL, indvColl);
			fwTxn.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getIncomeDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_INC_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.getIncomeDetails() - END", fwTxn);

	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Store method for current job details *
	 * 
	 ********************************************************************************************************************
	 */

	@SuppressWarnings("unchecked")
	@Transactional
	public void storeEmploymentDetail(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeEmploymentDetail() - START",
				fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			final Map request = fwTxn.getRequest();

			final String appNum = fwTxn.getUserDetails().getAppNumber();

			final Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			;
			final Integer seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());

			// get Details aset Collection and Cargo
			APP_IN_EMPL_Collection cpAppInEmplColl = (APP_IN_EMPL_Collection) pageCollection.get(APP_IN_EMPL_COLL);
			APP_IN_EMPL_Cargo cpAppInEmplCargo = cpAppInEmplColl.getCargo(0);

			// get the Aset collection from Before Collection
			final APP_IN_EMPL_Collection cpAppInEmplBeforeColl = (APP_IN_EMPL_Collection) employmentDetailsBO
					.loadIndividualEmploymentDetails(appNum, indv_seq_num, seq_num);
			APP_IN_EMPL_Cargo cpAppInEmplBeforeCargo;

			if ((cpAppInEmplBeforeColl != null) && (!cpAppInEmplBeforeColl.isEmpty())) {
				cpAppInEmplBeforeCargo = cpAppInEmplBeforeColl.getCargo(0);
				cpAppInEmplCargo.setApp_num(appNum);
				cpAppInEmplBeforeCargo.setChange_eff_dt(cpAppInEmplCargo.getChange_eff_dt());
				cpAppInEmplCargo.setIndv_seq_num(cpAppInEmplBeforeCargo.getIndv_seq_num());
				cpAppInEmplCargo.setEmpl_seq_num(cpAppInEmplBeforeCargo.getEmpl_seq_num());

				final String emplRsnCd = cpAppInEmplCargo.getPay_freq_cd();
				if (emplRsnCd == null || AppConstants.SELECT_DEFAULT_OPTION.equals(emplRsnCd)) {
					cpAppInEmplCargo.setPay_freq_cd(null);
				}

			}

			if (null != request.get(FwConstants.WARNING_MSG_DETAILS)
					&& !request.get(FwConstants.WARNING_MSG_DETAILS).toString().isEmpty()) {
				if (!(request.get(FwConstants.WARNING_MSG_DETAILS) instanceof String)) {
					String[] strArr = (String[]) request.get(FwConstants.WARNING_MSG_DETAILS);
					FwLogger.log(this.getClass(), FwLogger.Level.INFO,
							"DeepLog::CP_DEBUG_LOGS::1:: WARNING_MSG_DETAILS is not an instance of String:"
									+ Arrays.toString(strArr) + ":::appNum" + appNum);

				}
			}
			cpAppInEmplCargo.setSrc_app_ind("AB");
			cpAppInEmplCargo.setEmpl_type("E");

			cpAppInEmplCargo.setApp_num(appNum);
			cpAppInEmplCargo.setIndv_seq_num(indv_seq_num);
			cpAppInEmplCargo.setEmpl_seq_num(seq_num);
			cpAppInEmplCargo.setIk_income_type("E");
			// Indicator for Lost job
			if (null != cpAppInEmplCargo.getLostJobInd()
					&& cpAppInEmplCargo.getLostJobInd().equals(FinancialInfoConstants.Y)) {
				cpAppInEmplCargo.setEmpl_type("L");
				cpAppInEmplCargo.setIk_income_type("L");
			}
			// completeness check
			cpAppInEmplCargo.setRec_cplt_ind(employmentDetailsBO.completenessCheckABEDT(cpAppInEmplCargo));
			// PersistData if the cargo is dirty

			cpAppInEmplColl.set(0, cpAppInEmplCargo);
			cpAppInEmplColl = employmentDetailsBO.storeEmplDetails(cpAppInEmplColl);

			// Load the CargoCollection into the PageCollection
			pageCollection.put(APP_IN_EMPL_COLL, cpAppInEmplColl);
			fwTxn.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeEmploymentDetail()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_EMP_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeEmploymentDetail() - END", fwTxn);
	}

	@Transactional
	public void storeIncomeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeIncomeDetails() - START", fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			final String appNum = fwTxn.getUserDetails().getAppNumber();

			Integer indv_seq_num = 0;
			Integer seq_num = 0;

			if (!StringUtils.isEmpty(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence()))
				indv_seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			if (!StringUtils.isEmpty(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence()))
				seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();
			String incomeType = categorySequenceDetails.getCategoryType();
			APP_IN_EMPL_Collection cpAppInEmplColl = (APP_IN_EMPL_Collection) pageCollection.get(APP_IN_EMPL_COLL);
			APP_IN_EMPL_Collection updatedAppInEmplColl = new APP_IN_EMPL_Collection();

			APP_IN_EMPL_Cargo cpAppInEmplCargo = null;
			APP_IN_EMPL_Cargo appInEmplExistingCargo = null;
			if (cpAppInEmplColl != null && !cpAppInEmplColl.isEmpty()) {
				cpAppInEmplCargo = cpAppInEmplColl.getCargo(0);
				cpAppInEmplCargo.setApp_num(appNum);
				cpAppInEmplCargo.setIndv_seq_num(indv_seq_num);
				cpAppInEmplCargo.setEmpl_type("IK");
				cpAppInEmplCargo.setIk_income_type(incomeType);
				cpAppInEmplCargo.setEmpl_seq_num(seq_num);
				if (Objects.isNull(seq_num))
					seq_num = cpAppInEmplCargo.getEmpl_seq_num();
				if (Objects.isNull(indv_seq_num))
					indv_seq_num = cpAppInEmplCargo.getIndv_seq_num();
				cpAppInEmplCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				updatedAppInEmplColl.add(cpAppInEmplCargo);

			}
			if (null != fwTxn.getNextActionDetails()) {
				fwTxn.getNextActionDetails().getIndividualCategorySequenceDetails()
						.setCategorySequence(seq_num.toString());
				fwTxn.getNextActionDetails().getIndividualCategorySequenceDetails()
						.setIndividualSequence(indv_seq_num.toString());
			}
			pageCollection.put("Ik_income_type", incomeType);
			updatedAppInEmplColl = employmentDetailsBO.storeEmplDetails(updatedAppInEmplColl);

			// Load the CargoCollection into the PageCollection
			pageCollection.put(APP_IN_EMPL_COLL, updatedAppInEmplColl);
			fwTxn.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeIncomeDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_INC_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeIncomeDetails() - END", fwTxn);
	}
	/*
	 * 
	 * 
	 * 
	 * 
	 * #############################################################################
	 * ####################################################################### Self
	 * Employment*******************************************************************
	 * ********
	 * #############################################################################
	 * #######################################################################
	 *
	 *
	 *
	 */

	/******************************************************************************************************************
	 * 
	 * 
	 * Load method for self employment detail
	 *
	 * 
	 ********************************************************************************************************************
	 */
	@SuppressWarnings("squid:S3776")
	@Transactional
	public void getSelfEmploymentDetail(final FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.getSelfEmploymentDetail() - START",
				fwTxn);
		try {

			final Map request = fwTxn.getRequest();
			Map pageCollection = fwTxn.getPageCollection();
			String mode = (String) pageCollection.get(FinancialInfoConstants.MODE);
			// make loopingQuestion value NO in the request
			request.put("loopingQuestion", FwConstants.NO);
			final String appNum = fwTxn.getUserDetails().getAppNumber();

			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {
				// get SelfEmployment details from SelfEmployment details table
				// in database
				if (null == mode || !mode.equals(FinancialInfoConstants.RAC)) {
					pageCollection = new HashMap();
				}
				// get Details_Collection from DataBase and set to
				// PageCollection
				final APP_IN_SELFE_Collection selfEmpColl = abJobIncomeBO.getSelfEmploymentDetailsByAppNum(appNum,
						indvIdList);

				pageCollection.put(APP_IN_SELFE_COLL, selfEmpColl);

			} else {

				if (null == mode || !mode.equals(FinancialInfoConstants.RAC)) {
					pageCollection = new HashMap();
				}
				// self emp details
				final APP_IN_SELFE_Collection collSes = abJobIncomeBO.getSelfEmploymentDetailsByAppNum(appNum,
						indvIdList);

				APP_IN_SELFE_Cargo cargoSes = null;
				final APP_IN_SELFE_Collection newColl = new APP_IN_SELFE_Collection();
				final int size = collSes.size();
				if (size > 0) {
					// get last cargo from session
					for (int self = 0; self < collSes.size(); self++) {
						cargoSes = collSes.getCargo(self);
						newColl.addCargo(cargoSes);
					}
				}

				// add earned income
				final APP_IN_EMPL_Collection appInEmplColl = employmentDetailsBO
						.getEmploymentDetailsOnIncomeType(appNum, "E", indvIdList);

				APP_IN_EMPL_Cargo acargo = null;
				final APP_IN_EMPL_Collection newEmpColl = new APP_IN_EMPL_Collection();
				final int size2 = appInEmplColl.size();
				if (size2 > 0) {
					// get last cargo from session
					for (int emp = 0; emp < appInEmplColl.size(); emp++) {
						acargo = appInEmplColl.getCargo(emp);
						newEmpColl.addCargo(acargo);
					}
				}

				// set Details_Collection from session to PageCollection
				if (newColl.size() > 0) {
					pageCollection.put(APP_IN_SELFE_COLL, newColl);
				}
				if (newEmpColl.size() > 0) {
					pageCollection.put(APP_IN_EMPL_COLL, newEmpColl);
				}
				fwTxn.setPageCollection(pageCollection);
			}
		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_SELF_EMP_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.getSelfEmploymentDetail() - END",
				fwTxn);
	}

	public void getEarnedIncome(Map pageCollection, final String appNum, List<Integer> indvIdList,
			final APP_IN_SELFE_Collection newColl) {
		try {
			final APP_IN_EMPL_Collection appInEmplColl = employmentDetailsBO.getEmploymentDetailsOnIncomeType(appNum,
					"E", indvIdList);

			APP_IN_EMPL_Cargo acargo = null;
			final APP_IN_EMPL_Collection newEmpColl = new APP_IN_EMPL_Collection();
			final int size2 = appInEmplColl.size();
			if (size2 > 0) {
				// get last cargo from session
				for (int emp = 0; emp < appInEmplColl.size(); emp++) {
					acargo = appInEmplColl.getCargo(emp);
					newEmpColl.addCargo(acargo);
				}
			}

			// set Details_Collection from session to PageCollection
			if (newColl.size() > 0) {
				pageCollection.put(APP_IN_SELFE_COLL, newColl);
			}
			if (newEmpColl.size() > 0) {
				pageCollection.put(APP_IN_EMPL_COLL, newEmpColl);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getEarnedIncome()", e);
			throw e;
		}
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Store method for self employment detail
	 *
	 * 
	 ********************************************************************************************************************
	 */
	@SuppressWarnings("squid:S3776")
	@Transactional
	public void storeSelfEmploymentDetail(final FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeSelfEmploymentDetail() - START",
				fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			final Map request = fwTxn.getRequest();
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			final String firstName = fwTxn.getUserDetails().getFirstName();
			Integer seq_num = 0;
			Double nullCheck = null;
			// get Details Collection and Cargo
			final APP_IN_SELFE_Collection appInCollReq = (APP_IN_SELFE_Collection) pageCollection
					.get(APP_IN_SELFE_COLL);
			APP_IN_SELFE_Cargo cargo_req = appInCollReq.getCargo(0);
			final Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			if (null != fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence()
					&& !fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence()
							.isEmpty()) {
				seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			} else {
				if (null != cargo_req && cargo_req.getSeq_num() != 0) {
					seq_num = cargo_req.getSeq_num();
				}
			}

			if (cargo_req != null) {

				cargo_req.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				FwMessageList validateInfo = new FwMessageList();
				String showLoopingQuestionFlag = (String) request.get("showloopingquestion");

				// get the SelfEmployment collection from Before Collection and set
				// the values to the cargo
				final APP_IN_SELFE_Collection cpAppInSelfeBeforeColl = abJobIncomeBO
						.loadIndividualSelfEmploymentDetails(appNum, indv_seq_num, seq_num);

				// Source app indicator and change effective date default values
				// population PCR # 29768

				if ((cargo_req.getSelf_empl_typ() == null)
						|| AppConstants.SELECT_DEFAULT_OPTION.equals(cargo_req.getSelf_empl_typ())) {
					cargo_req.setSelf_empl_typ(FwConstants.SPACE);
				}

				if ((cpAppInSelfeBeforeColl != null) && (!cpAppInSelfeBeforeColl.isEmpty())) {

					setSelfEmpCargo(pageCollection, appNum, cargo_req, cpAppInSelfeBeforeColl);

					// condition check in edit case
					setDefaultCases(pageCollection, cargo_req);
					// Setting Default values if the before cargo values are null

				}

				// Run Validations

				cargo_req.getSelf_empl_bus_nam();

				if (validateInfo.hasMessages()) {
					request.put(FwConstants.MESSAGE_LIST, validateInfo);
					pageCollection.put(AppConstants.FIRST_NAME, firstName);
					pageCollection.put("ShowLoopingQuestionFlag", showLoopingQuestionFlag);

					return;
				}

				// for fist time entry condition check
				// commented above lines to avoid setting default values unnecessarily

				cargo_req.setRec_cplt_ind(1);
				cargo_req.setApp_num(appNum);
				cargo_req.setIndv_seq_num(indv_seq_num);
				cargo_req.setSeq_num(seq_num);
				abJobIncomeBO.storeSelfEmploymentDetails(appInCollReq);
			}

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeSelfEmploymentDetail()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(), FinancialInfoConstants.STORE_SELF_EMP_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeSelfEmploymentDetail() - END",
				fwTxn);

	}

	private void setSelfEmpCargo(final Map pageCollection, final String appNum, APP_IN_SELFE_Cargo cargo_req,
			final APP_IN_SELFE_Collection cpAppInSelfeBeforeColl) {
		cargo_req.setApp_num(appNum);
		cargo_req.setIndv_seq_num(cpAppInSelfeBeforeColl.getCargo(0).getIndv_seq_num());
		cargo_req.setSeq_num(cpAppInSelfeBeforeColl.getCargo(0).getSeq_num());
		// set sequence number Zero if it is null
		if (cargo_req.getSeq_num() != null) {
			cargo_req.setRowAction(FwConstants.ROWACTION_UPDATE);
		} else {
			cargo_req.setRowAction(FwConstants.ROWACTION_INSERT);
		}
		if ((cargo_req.getSelf_empl_typ() == null)
				|| AppConstants.SELECT_DEFAULT_OPTION.equals(cargo_req.getSelf_empl_typ())) {
			cargo_req.setSelf_empl_typ(FwConstants.SPACE);
		}

		if (cargo_req.getExpected_to_cont_resp() == null) {
			cargo_req.setExpected_to_cont_resp(FwConstants.ZERO);
		}
		// Added by Rashmi
		if (cargo_req.getAvg_incm_ind() == null) {
			cargo_req.setAvg_incm_ind(0);
		}

		else if (Objects.nonNull(cargo_req.getAvg_incm_amt())
				&& !FwConstants.EMPTY_STRING.equals(cargo_req.getAvg_incm_amt().toString())) {
			// NG-5616:SONAR FIX:Empty If statement Fix

			pageCollection.put("IncAmtAndIndChecked", FwConstants.ONE);
		} else {
			if (Objects.nonNull(cargo_req.getAvg_incm_amt())
					&& FwConstants.EMPTY_STRING.equals(cargo_req.getAvg_incm_amt().toString())) {
				cargo_req.setAvg_incm_ind(2);
			}
		}
		
	}

	private void setDefaultCases(final Map pageCollection, APP_IN_SELFE_Cargo cargo_req) {
		
		if (cargo_req.getExp_ind() == null || cargo_req.getExp_ind() == 0) {
			if ((cargo_req.getExp_amt() == null) || cargo_req.getExp_amt() == 0) {
				cargo_req.setExp_amt(FinancialInfoConstants.ZERO_DOUBLE);
				cargo_req.setExp_ind(2);
			} else {
				cargo_req.setExp_ind(0);
			}
		} else if (FwConstants.EMPTY_STRING.equals(cargo_req.getExp_amt().toString().trim())) {
			cargo_req.setExp_amt(FinancialInfoConstants.ZERO_DOUBLE);
		} else {
			pageCollection.put("ExpAmtAndIndChecked", FwConstants.ONE);
		}
		if (cargo_req.getDprc_ind() == null) {
			cargo_req.setDprc_ind(0);
		}
		if (cargo_req.getDprc_amt() == null) {
			cargo_req.setDprc_amt(FinancialInfoConstants.ZERO_DOUBLE);
		}
		setWorkHours(pageCollection, cargo_req);
		if (cargo_req.getSelf_mng_sw() == null) {
			cargo_req.setSelf_mng_sw(FwConstants.SPACE);
		}
		
	}

	private void setWorkHours(final Map pageCollection, APP_IN_SELFE_Cargo cargo_req) {
		
		if (cargo_req.getHr_work_mo_ind() == null) {
			if ((null != cargo_req.getHr_work_mo_qty())
					&& FwConstants.EMPTY_STRING.equals(cargo_req.getHr_work_mo_qty().toString().trim())) {
				cargo_req.setHr_work_mo_ind(2);
			} else {
				cargo_req.setHr_work_mo_ind(0);
			}
		} else if (!FwConstants.EMPTY_STRING.equals(cargo_req.getHr_work_mo_qty().toString().trim())) {
			pageCollection.put("HoursAndIndChecked", FwConstants.ONE);
		}
		
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Load method to get job income summary
	 * 
	 ********************************************************************************************************************
	 */
	@SuppressWarnings({"squid:S2230","squid:S3776"})
	@Transactional
	private void getJobIncomeSummaryDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.getJobIncomeSummaryDetails() - START",
				fwTxn);
		try {
			Map<Object, Object> pageCollection = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNum = userDetails.getAppNumber();
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			} else {
				indvIds = new ArrayList<String>();
				ExpenseSummaryServiceImpl obj = new ExpenseSummaryServiceImpl();
				APP_INDV_Collection appIndvCollection = obj.getIndvList(fwTxn);
				if (appIndvCollection != null && !appIndvCollection.isEmpty() && appIndvCollection.size() > 0) {
					for (int i = 0; i < appIndvCollection.size(); i++) {
						APP_INDV_Cargo appIndvCargo1 = (APP_INDV_Cargo) appIndvCollection.get(i);
						indvIds.add(appIndvCargo1.getIndv_seq_num().toString());
					}
					indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
							.collect(Collectors.toList());
				}
			}
			String earnedIncome = "Y";
			String unearnedIncome = "Y";
			String unearnedIncomeA = "1";
			String unearnedIncomeB = "1";
			String incomeInKind = "Y";
			String incomeInKindA = "1";

			Questionnarie_jobIncomeCollection quesColl = new Questionnarie_jobIncomeCollection();
			Questionnarie_jobIncomeCargo questions = new Questionnarie_jobIncomeCargo();
			questions.setEarnedIncome(earnedIncome);
			questions.setIncomeInKind(incomeInKind);
			questions.setIncomeInKindA(incomeInKindA);
			questions.setUnearnedIncome(unearnedIncome);
			questions.setUnearnedIncomeA(unearnedIncomeA);
			questions.setUnearnedIncomeB(unearnedIncomeB);
			quesColl.addCargo(questions);
			pageCollection.put("Questionnarie_jobIncomeCollection", quesColl);

			/**
			 * Below lines will fetch earned income
			 */
			APP_IN_EMPL_Collection appInEmplCollection;
			APP_IN_SELFE_Collection appInSelfEmplCollection;

			appInEmplCollection = abJobIncomeBO.getAppInEmplCollection(appNum, indvIdList);
			appInSelfEmplCollection = abJobIncomeBO.getAppInSelfEmplCollection(appNum, indvIdList);
			if (Objects.nonNull(appInEmplCollection) && !(appInEmplCollection.isEmpty())
					&& appInEmplCollection.size() > 0) {
				pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_COLL, appInEmplCollection);
			}
			if (Objects.nonNull(appInSelfEmplCollection) && !(appInSelfEmplCollection.isEmpty())
					&& appInSelfEmplCollection.size() > 0) {
				pageCollection.put(FinancialInfoConstants.APP_IN_SELFE_COLL, appInSelfEmplCollection);
			}

			APP_IN_UEI_Collection appInUEICollection = abJobIncomeBO.getUnearnedIncome(appNum, indvIdList);
			if (Objects.nonNull(appInUEICollection) && !(appInUEICollection.isEmpty())
					&& appInUEICollection.size() > 0) {
				pageCollection.put(FinancialInfoConstants.APP_IN_UEI_COLL, appInUEICollection);
			}

			fwTxn.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.GET_JOB_INC_SUMM_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.JobIncomeServiceImpl() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

	}

	public void getEmploymentSelfEarnedUnearned(Map<Object, Object> pageCollection, String appNum,
			List<Integer> indvIdList) {
		try {
			APP_IN_EMPL_Collection appInEmplCollection;
			APP_IN_SELFE_Collection appInSelfEmplCollection;
			appInEmplCollection = abJobIncomeBO.getAppInEmplCollection(appNum, indvIdList);
			appInSelfEmplCollection = abJobIncomeBO.getAppInSelfEmplCollection(appNum, indvIdList);
			if (Objects.nonNull(appInEmplCollection) && !(appInEmplCollection.isEmpty())) {
				pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_COLL, appInEmplCollection);
			}
			if (Objects.nonNull(appInSelfEmplCollection) && !(appInSelfEmplCollection.isEmpty())) {
				pageCollection.put(FinancialInfoConstants.APP_IN_SELFE_COLL, appInSelfEmplCollection);
			}

			APP_IN_UEI_Collection appInUEICollection = abJobIncomeBO.getUnearnedIncome(appNum, indvIdList);
			if (Objects.nonNull(appInUEICollection) && !(appInUEICollection.isEmpty())) {
				pageCollection.put(FinancialInfoConstants.APP_IN_UEI_COLL, appInUEICollection);
			}
		} catch (final Exception e) {
			throw e;
		}
	}

	public void setQuestionnaireObject(Map<Object, Object> pageCollection) {
		try {
			String earnedIncome = "Y";
			String unearnedIncome = "Y";
			String unearnedIncomeA = "1";
			String unearnedIncomeB = "1";
			String incomeInKind = "Y";
			String incomeInKindA = "1";

			Questionnarie_jobIncomeCollection quesColl = new Questionnarie_jobIncomeCollection();
			Questionnarie_jobIncomeCargo questions = new Questionnarie_jobIncomeCargo();
			questions.setEarnedIncome(earnedIncome);
			questions.setIncomeInKind(incomeInKind);
			questions.setIncomeInKindA(incomeInKindA);
			questions.setUnearnedIncome(unearnedIncome);
			questions.setUnearnedIncomeA(unearnedIncomeA);
			questions.setUnearnedIncomeB(unearnedIncomeB);
			quesColl.addCargo(questions);
			pageCollection.put("Questionnarie_jobIncomeCollection", quesColl);
		} catch (final Exception e) {
			throw e;
		}
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * method to validate APP_IN_PRFL against unearnedIncome from Public
	 * Assistance(Unearned Income A)
	 * 
	 * @param appInPrflCargo
	 * @return true or false
	 * 
	 ********************************************************************************************************************
	 */
	private boolean validateForUnearnedIncomeA() {

		return false;
	}

	// Start: CSPM-1824
	@Transactional
	public void storeMonthToMonthIncomeChangeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.storeMonthToMonthIncomeChangeDetails() - START", fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			APP_IN_EMPL_Collection cpAppInEmplColl = (APP_IN_EMPL_Collection) pageCollection.get(APP_IN_EMPL_COLL);
			APP_IN_EMPL_Cargo cpAppInEmplCargo = cpAppInEmplColl.getCargo(0);
			final Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			APP_IN_EMPL_Cargo appInEmplCargo = new APP_IN_EMPL_Cargo();

			// Get Month to Month Income Change Details
			APP_IN_EMPL_Collection appInEmplColl;
			String empl_type = FinancialInfoConstants.MONTH_TO_MONTH_INCOME_CHANGE;
			Integer seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			appInEmplColl = cpAppInEmplRepository.loadMonthtoMonthDetails(Integer.parseInt(appNum), indv_seq_num, seq_num, empl_type);

			if (appInEmplColl.size() == 0) {
				// TO DO: Add the Profile table related code to set the Month to Month Income
				// Change indicator for a given individual

				// Each individual Can have only one Month to Month Income Change
				if (seq_num == null) {
					appInEmplCargo.setEmpl_seq_num(1);
				} else {
					appInEmplCargo.setEmpl_seq_num(seq_num);
				}
				appInEmplCargo.setApp_num(appNum);
				appInEmplCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
				appInEmplCargo.setIndv_seq_num(indv_seq_num);
				appInEmplCargo.setEmpl_type(empl_type);
				appInEmplCargo.setYearly_income_current_year(cpAppInEmplCargo.getYearly_income_current_year());
				appInEmplCargo.setYearly_income_next_year(cpAppInEmplCargo.getYearly_income_next_year());
				appInEmplCargo.setIk_income_type(empl_type);
			} else {
				appInEmplCargo = (APP_IN_EMPL_Cargo) appInEmplColl.get(0);
				appInEmplCargo.setYearly_income_current_year(cpAppInEmplCargo.getYearly_income_current_year());
				appInEmplCargo.setYearly_income_next_year(cpAppInEmplCargo.getYearly_income_next_year());
			}
			appInEmplCargo.setNext_year_income_change_ind(cpAppInEmplCargo.getNext_year_income_change_ind());
			cpAppInEmplRepository.save(appInEmplCargo);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in storeMonthToMonthIncomeChangeDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STORE_MONTOMON_INC_CHG_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.storeMonthToMonthIncomeChangeDetails() - END", fwTxn);

	};

	@Transactional
	public void loadMonthToMonthIncomeChangeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.loadMonthToMonthIncomeChangeDetails() - START", fwTxn);
		Map pageCollection;
		pageCollection = fwTxn.getPageCollection();
		try {
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			String empl_type = FinancialInfoConstants.MONTH_TO_MONTH_INCOME_CHANGE;
			APP_IN_EMPL_Collection listOfMonthToMonthIncomeChangeDtls;
			listOfMonthToMonthIncomeChangeDtls = cpAppInEmplRepository.getAllMonthToMonthIncomeChangeDetails(Integer.parseInt(appNum),
					empl_type, indvIdList);
			pageCollection.put(APP_IN_EMPL_COLL, listOfMonthToMonthIncomeChangeDtls);
			fwTxn.setPageCollection(pageCollection);
		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in loadMonthToMonthIncomeChangeDetails()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.LOAD_MNTOMON_INC_CHG_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.loadMonthToMonthIncomeChangeDetails() - END", fwTxn);
	}

	@Transactional
	public void deleteMonthToMonthIncomeChangeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.deleteMonthToMonthIncomeChangeDetails() - START", fwTxn);
		Map pageCollection;
		pageCollection = fwTxn.getPageCollection();
		try {
			final String appNum = fwTxn.getUserDetails().getAppNumber();

			final Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			APP_IN_EMPL_Collection cpAppInEmplColl = cpAppInEmplRepository.loadDetails(Integer.parseInt(appNum), indv_seq_num, seq_num);
			APP_IN_EMPL_Cargo cpAppInEmplCargo = cpAppInEmplColl.getCargo(0);
			cpAppInEmplRepository.delete(cpAppInEmplCargo);
			APP_IN_EMPL_Collection listOfMonthToMonthIncomeChangeDtls = new APP_IN_EMPL_Collection();
			pageCollection.put(APP_IN_EMPL_COLL, listOfMonthToMonthIncomeChangeDtls);
			fwTxn.setPageCollection(pageCollection);
		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"Error occured in deleteMonthToMonthIncomeChangeDetails()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.DELETE_MONTOMON_INC_CHG_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.deleteMonthToMonthIncomeChangeDetails() - END", fwTxn);
	}

	// End: CSPM-1824

	// Start: CSPM-6016
	@Transactional
	public void deleteUnearnedIncomeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.deleteUnearnedIncomeDetails() - START",
				fwTxn);

		String appNumber = null;
		final UserDetails userDetails = fwTxn.getUserDetails();
		try {
			appNumber = userDetails.getAppNumber();
			int indvSeqNum = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			int seqNum = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();
			APP_IN_UEI_Cargo cpAppUeiCargo = new APP_IN_UEI_Cargo();
			cpAppUeiCargo.setSrc_app_ind("AB");
			cpAppUeiCargo.setApp_num(appNumber);
			cpAppUeiCargo.setIndv_seq_num(indvSeqNum);
			cpAppUeiCargo.setUei_typ(categorySequenceDetails.getCategoryType());
			cpAppUeiCargo.setSeq_num(seqNum);
			appInUieRepository.delete(cpAppUeiCargo);
		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in deleteUnearnedIncomeDetails()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.DELETE_UNEARNED_INC_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.deleteUnearnedIncomeDetails() - END",
				fwTxn);
	}

	// End: CSPM-6016

	@Transactional
	public void deleteEarnedIncomeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.deleteEarnedIncomeDetails() - START",
				fwTxn);
		Map pageCollection;
		pageCollection = fwTxn.getPageCollection();
		String appNumber = null;
		final UserDetails userDetails = fwTxn.getUserDetails();
		try {
			appNumber = userDetails.getAppNumber();
			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();
			APP_IN_SELFE_Collection cpAppInSelfeCol = (APP_IN_SELFE_Collection) pageCollection.get(APP_IN_SELFE_COLL);
			APP_IN_SELFE_Cargo cpAppSelfeCargo = cpAppInSelfeCol.getCargo(0);
			cpAppSelfeCargo.setApp_num(appNumber);
			cpAppSelfeCargo.setIndv_seq_num(cpAppSelfeCargo.getIndv_seq_num());

			Integer indvSeq = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			Integer seq_num = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			APP_IN_SELFE_Cargo newCargo = new APP_IN_SELFE_Cargo();
			APP_IN_SELFE_Collection selfEmpColl = abJobIncomeBO.loadIndividualSelfEmploymentDetails(appNumber, indvSeq,
					seq_num);

			if ((selfEmpColl != null) && !selfEmpColl.isEmpty() && (selfEmpColl.getCargo(0) != null)) {
				newCargo = selfEmpColl.getCargo(0);
			}
			if (selfEmpColl != null && !selfEmpColl.isEmpty()
					&& !FinancialInfoConstants.EMPTY_STR.equals(newCargo.getApp_num())
					&& newCargo.getApp_num().equalsIgnoreCase(cpAppSelfeCargo.getApp_num())) {

				cpAppSelfeCargo.setRowAction(FwConstants.ROWACTION_DELETE);
				appInSelfeRepository.delete(newCargo);

			}
		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in deleteEarnedIncomeDetails()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.DELETE_EARNED_INC_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.deleteEarnedIncomeDetails() - END",
				fwTxn);

	}

	// Start: CSPM-3016
	@Transactional
	@SuppressWarnings("squid:S3776")
	public void storeChangeInIncomeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeChangeInIncomeDetails() - START",
				fwTxn);
		try {
			final Map pageCollection = fwTxn.getPageCollection();

			final String appNum = fwTxn.getUserDetails().getAppNumber();
			String pageId = fwTxn.getCurrentActionDetails().getPageId();
			String emplType = FinancialInfoConstants.CHANGE_IN_INCOMEA;
			if (!StringUtils.isEmpty(pageId)
					&& pageId.equalsIgnoreCase(FinancialInfoConstants.CHANGE_IN_INCOMEB_PAGEID)) {
				emplType = FinancialInfoConstants.CHANGE_IN_INCOMEB;
			}
			Integer indv_seq_num = null;
			Integer seq_num = null;

			APP_IN_EMPL_Collection cpAppInEmplColl = (APP_IN_EMPL_Collection) pageCollection.get(APP_IN_EMPL_COLL);
			APP_IN_EMPL_Collection updatedAppInEmplColl = new APP_IN_EMPL_Collection();
			APP_IN_EMPL_Cargo cpAppInEmplCargo = null;
			APP_IN_EMPL_Cargo appInEmplExistingCargo = null;

			APP_IN_EMPL_Collection appInEmplExistingColl;

			if (cpAppInEmplColl != null && !cpAppInEmplColl.isEmpty()) {
				cpAppInEmplCargo = cpAppInEmplColl.getCargo(0);
				if (Objects.nonNull(fwTxn.getCurrentActionDetails())
						&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
						&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
								.getIndividualSequence())) {
					indv_seq_num = Integer.parseInt(fwTxn.getCurrentActionDetails()
							.getIndividualCategorySequenceDetails().getIndividualSequence());
				}
				if (Objects.nonNull(fwTxn.getCurrentActionDetails())
						&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
						&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
								.getCategorySequence())) {
					seq_num = Integer.parseInt(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence());
				}
				appInEmplExistingColl = cpAppInEmplRepository.loadChangeInIncomeDetails(Integer.parseInt(appNum), indv_seq_num, seq_num,
						emplType);

				if (appInEmplExistingColl.size() == 0) {// save new record

					cpAppInEmplCargo.setApp_num(appNum);
					cpAppInEmplCargo.setEmpl_type(emplType);
					cpAppInEmplCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
					cpAppInEmplCargo.setEmpl_seq_num(seq_num);
					cpAppInEmplCargo.setIndv_seq_num(indv_seq_num);
					cpAppInEmplCargo.setIk_income_type(emplType);
					cpAppInEmplRepository.save(cpAppInEmplCargo);
				} else { // updated existing
					appInEmplExistingCargo = appInEmplExistingColl.getCargo(0);
					if (emplType.equalsIgnoreCase(FinancialInfoConstants.CHANGE_IN_INCOMEA)) {
						appInEmplExistingCargo.setStrike_begin_dt(cpAppInEmplCargo.getStrike_begin_dt());
						appInEmplExistingCargo.setLast_payck_dt(cpAppInEmplCargo.getLast_payck_dt());
						appInEmplExistingCargo.setEmpl_addtl_info(cpAppInEmplCargo.getEmpl_addtl_info());
						appInEmplExistingCargo.setIk_income_type(emplType);
					} else if (emplType.equalsIgnoreCase(FinancialInfoConstants.CHANGE_IN_INCOMEB)) {
						appInEmplExistingCargo.setChange_eff_dt(cpAppInEmplCargo.getChange_eff_dt());
						appInEmplExistingCargo.setLast_payck_dt(cpAppInEmplCargo.getLast_payck_dt());
						appInEmplExistingCargo.setEmpl_addtl_info(cpAppInEmplCargo.getEmpl_addtl_info());
						appInEmplExistingCargo.setlast_60_days_ind(cpAppInEmplCargo.getlast_60_days_ind());
						appInEmplExistingCargo.setCounty_help_job_ind(cpAppInEmplCargo.getCounty_help_job_ind());
						appInEmplExistingCargo.setIk_income_type(emplType);
					}
					cpAppInEmplRepository.save(appInEmplExistingCargo);
				}
			}

			pageCollection.put("emplType", emplType);
			pageCollection.put(APP_IN_EMPL_COLL, updatedAppInEmplColl);
			fwTxn.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeChangeInIncomeDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_CNG_INC_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeChangeInIncomeDetails() - END",
				fwTxn);
	}

	public void setChangeInIncomeCargo(final FwTransaction fwTxn, final String appNum, String emplType,
			Integer indv_seq_num, Integer seq_num, APP_IN_EMPL_Collection cpAppInEmplColl) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.setChangeInIncomeCargo() - START",
				fwTxn);
		try {
			APP_IN_EMPL_Cargo cpAppInEmplCargo;
			APP_IN_EMPL_Cargo appInEmplExistingCargo;
			APP_IN_EMPL_Collection appInEmplExistingColl;
			cpAppInEmplCargo = cpAppInEmplColl.getCargo(0);
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indv_seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}
			appInEmplExistingColl = cpAppInEmplRepository.loadChangeInIncomeDetails(Integer.parseInt(appNum), indv_seq_num, seq_num,
					emplType);

			if (appInEmplExistingColl.isEmpty()) {// save new record

				cpAppInEmplCargo.setApp_num(appNum);
				cpAppInEmplCargo.setEmpl_type(emplType);
				cpAppInEmplCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				cpAppInEmplCargo.setEmpl_seq_num(seq_num);
				cpAppInEmplCargo.setIndv_seq_num(indv_seq_num);
				cpAppInEmplCargo.setIk_income_type(emplType);
				cpAppInEmplRepository.save(cpAppInEmplCargo);
			} else { // updated existing
				appInEmplExistingCargo = appInEmplExistingColl.getCargo(0);
				if (emplType.equalsIgnoreCase(FinancialInfoConstants.CHANGE_IN_INCOMEA)) {
					appInEmplExistingCargo.setStrike_begin_dt(cpAppInEmplCargo.getStrike_begin_dt());
					appInEmplExistingCargo.setLast_payck_dt(cpAppInEmplCargo.getLast_payck_dt());
					appInEmplExistingCargo.setEmpl_addtl_info(cpAppInEmplCargo.getEmpl_addtl_info());
					appInEmplExistingCargo.setIk_income_type(emplType);
				} else if (emplType.equalsIgnoreCase(FinancialInfoConstants.CHANGE_IN_INCOMEB)) {
					appInEmplExistingCargo.setChange_eff_dt(cpAppInEmplCargo.getChange_eff_dt());
					appInEmplExistingCargo.setLast_payck_dt(cpAppInEmplCargo.getLast_payck_dt());
					appInEmplExistingCargo.setEmpl_addtl_info(cpAppInEmplCargo.getEmpl_addtl_info());
					appInEmplExistingCargo.setlast_60_days_ind(cpAppInEmplCargo.getlast_60_days_ind());
					appInEmplExistingCargo.setCounty_help_job_ind(cpAppInEmplCargo.getCounty_help_job_ind());
					appInEmplExistingCargo.setIk_income_type(emplType);
				}
				cpAppInEmplRepository.save(appInEmplExistingCargo);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in setChangeInIncomeCargo()", fwTxn);
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.setChangeInIncomeCargo() - END",
				fwTxn);
	}

	@Transactional
	public void loadChangeInIncomeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.loadChangeInIncomeDetails() - START",
				fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			String pageId = fwTxn.getCurrentActionDetails().getPageId();
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			String emplType = FinancialInfoConstants.CHANGE_IN_INCOMEA;
			if ((!StringUtils.isEmpty(pageId)
					&& pageId.equalsIgnoreCase(FinancialInfoConstants.CHANGE_IN_INCOMEB_PAGEID))
					|| pageId.equalsIgnoreCase(FinancialInfoConstants.ABCBC)) {
				emplType = FinancialInfoConstants.CHANGE_IN_INCOMEB;
			}
			APP_IN_EMPL_Collection listOfIncomeChangedetailsBasedOnType;
			listOfIncomeChangedetailsBasedOnType = cpAppInEmplRepository.getAllDetailsOnType(Integer.parseInt(appNum), emplType,
					indvIdList);
			pageCollection.put(APP_IN_EMPL_COLL, listOfIncomeChangedetailsBasedOnType);

			// add indv details
			APP_INDV_Collection indvColl = fwTxn.getPageCollection().get(FinancialInfoConstants.APP_INDV_COLL) != null
					? (APP_INDV_Collection) fwTxn.getPageCollection().get(FinancialInfoConstants.APP_INDV_COLL)
					: null;
			// add prfl details
			APP_IN_PRFL_Collection newPrflColl = fwTxn.getPageCollection()
					.get(FinancialInfoConstants.APP_IN_PRFL_COLL) != null
							? (APP_IN_PRFL_Collection) fwTxn.getPageCollection()
									.get(FinancialInfoConstants.APP_IN_PRFL_COLL)
							: null;
			// set Details_Collection from session to PageCollection
			pageCollection.put(APP_IN_PRFL_COLL, newPrflColl);
			pageCollection.put(APP_INDV_COLL, indvColl);

			fwTxn.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in loadChangeInIncomeDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.LOAD_CHG_IN_INC_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.loadChangeInIncomeDetails() - END",
				fwTxn);
	}

	@Transactional
	public void deleteChangeInIncomeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.deleteChangeInIncomeDetails() - START",
				fwTxn);
		Map pageCollection;
		pageCollection = fwTxn.getPageCollection();
		try {
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			String pageId = fwTxn.getCurrentActionDetails().getPageId();
			String emplType = FinancialInfoConstants.CHANGE_IN_INCOMEA;
			if (!StringUtils.isEmpty(pageId)
					&& pageId.equalsIgnoreCase(FinancialInfoConstants.CHANGE_IN_INCOMEB_SUMMARY_PAGEID)) {
				emplType = FinancialInfoConstants.CHANGE_IN_INCOMEB;
			}
			Integer indvSeqNum = null;
			Integer seqNum = null;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}
			String src_app_ind = AppConstants.AFB_SRC_APP_IND;
			APP_IN_EMPL_Cargo cpAppInEmplCargo = new APP_IN_EMPL_Cargo();
			cpAppInEmplCargo.setIndv_seq_num(indvSeqNum);
			cpAppInEmplCargo.setEmpl_seq_num(seqNum);
			cpAppInEmplCargo.setEmpl_type(emplType);
			cpAppInEmplCargo.setApp_num(appNum);
			cpAppInEmplCargo.setSrc_app_ind(src_app_ind);
			cpAppInEmplCargo.setIk_income_type(emplType);
			cpAppInEmplRepository.delete(cpAppInEmplCargo);
			APP_IN_EMPL_Collection listOfIncomeChangedetailsBasedOnType = new APP_IN_EMPL_Collection();
			pageCollection.put(APP_IN_EMPL_COLL, listOfIncomeChangedetailsBasedOnType);
			// add indv details
			APP_INDV_Collection indvColl = fwTxn.getPageCollection().get(FinancialInfoConstants.APP_INDV_COLL) != null
					? (APP_INDV_Collection) fwTxn.getPageCollection().get(FinancialInfoConstants.APP_INDV_COLL)
					: null;
			// add prfl details
			APP_IN_PRFL_Collection newPrflColl = fwTxn.getPageCollection()
					.get(FinancialInfoConstants.APP_IN_PRFL_COLL) != null
							? (APP_IN_PRFL_Collection) fwTxn.getPageCollection()
									.get(FinancialInfoConstants.APP_IN_PRFL_COLL)
							: null;
			// set Details_Collection from session to PageCollection
			pageCollection.put(APP_IN_PRFL_COLL, newPrflColl);
			pageCollection.put(APP_INDV_COLL, indvColl);
			fwTxn.setPageCollection(pageCollection);
		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in deleteChangeInIncomeDetails()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.DELETE_CHG_IN_INC_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.deleteChangeInIncomeDetails() - END",
				fwTxn);
	}
	// End: CSPM-3016

	// Start: CSPM-6016

	/**
	 * Delete method for Income in kind details
	 */
	@Transactional
	public void deleteIncomeInKindDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.deleteIncomeInKindDetails() - START",
				fwTxn);

		try {
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();
			String incomeType = categorySequenceDetails.getCategoryType();
			Integer indvSeqNum = null;
			Integer seqNum = null;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}
			String src_app_ind = AppConstants.AFB_SRC_APP_IND;

			APP_IN_EMPL_Cargo cappInEmplCargoo = new APP_IN_EMPL_Cargo();
			if (cappInEmplCargoo != null) {
				cappInEmplCargoo.setIndv_seq_num(indvSeqNum);
				cappInEmplCargoo.setEmpl_seq_num(seqNum);
				cappInEmplCargoo.setIk_income_type(incomeType);
				cappInEmplCargoo.setApp_num(appNum);
				cappInEmplCargoo.setSrc_app_ind(src_app_ind);
				cappInEmplCargoo.setEmpl_type("IK");

				cpAppInEmplRepository.delete(cappInEmplCargoo);
			}
		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), Level.ERROR, "JobIncomeServiceImpl.deleteIncomeInKindDetails", fe);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.DELETE_INC_INKIND_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.deleteIncomeInKindDetails:End");
	}

	// End: CSPM-6016
	@Transactional
	public void deleteSelfAndEarnedIncomeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "deleteEarnedIncomeDetails");
		Map pageCollection;
		pageCollection = fwTxn.getPageCollection();
		String appNumber = null;
		final UserDetails userDetails = fwTxn.getUserDetails();
		try {
			appNumber = userDetails.getAppNumber();
			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();
			Integer indvSeq = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			Integer seq_num = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			if ("SE".equals(categorySequenceDetails.getCategoryType())) {
				APP_IN_SELFE_Collection cpAppInSelfeCol = (APP_IN_SELFE_Collection) pageCollection
						.get(APP_IN_SELFE_COLL);
				APP_IN_SELFE_Cargo cpAppSelfeCargo = null;
				if (null != cpAppInSelfeCol && cpAppInSelfeCol.size() > 0) {
					cpAppSelfeCargo = cpAppInSelfeCol.getCargo(0);
					cpAppSelfeCargo.setApp_num(appNumber);
					cpAppSelfeCargo.setIndv_seq_num(indvSeq);
				}
				APP_IN_SELFE_Cargo newCargo = new APP_IN_SELFE_Cargo();
				APP_IN_SELFE_Collection selfEmpColl = abJobIncomeBO.loadIndividualSelfEmploymentDetails(appNumber,
						indvSeq, seq_num);
				if ((selfEmpColl != null) && !selfEmpColl.isEmpty() && (selfEmpColl.getCargo(0) != null)) {
					newCargo = selfEmpColl.getCargo(0);
				}
				if (selfEmpColl != null && !selfEmpColl.isEmpty() && null != cpAppSelfeCargo
						&& !FinancialInfoConstants.EMPTY_STR.equals(newCargo.getApp_num())
						&& newCargo.getApp_num().equalsIgnoreCase(cpAppSelfeCargo.getApp_num())) {
					cpAppSelfeCargo.setRowAction(FwConstants.ROWACTION_DELETE);
					appInSelfeRepository.delete(newCargo);
					jobIncomeBO.deleteSelfEmplPayStubForParentRecord(appNumber, indvSeq, seq_num);
				}
			}

			deleteEarnedIncomeData(pageCollection, appNumber, categorySequenceDetails, indvSeq, seq_num);

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), Level.ERROR, "in excepion block", fe);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.DELETE_SELF_AND_EARNED_INC_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "deleteEarnedIncomeDetails: END");

	}

	// Start CSPM-12280
	private void storeIncomeDetailsDCF(FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeIncomeDetailsDCF() - START");

		Map<String, Object> pageCollection = null;

		CP_INCOME_DISASTER_Cargo cpIncomeDisasterCargo = null;
		CP_INCOME_DISASTER_Collection cpIncomeDisasterColl = null;

		String appNumber = fwTxn.getUserDetails().getAppNumber();

		try {

			pageCollection = fwTxn.getPageCollection();

			if (pageCollection.get(FinancialInfoConstants.CP_INCOME_DISASTER_COLLECTION) != null) {
				cpIncomeDisasterColl = (CP_INCOME_DISASTER_Collection) pageCollection
						.get(FinancialInfoConstants.CP_INCOME_DISASTER_COLLECTION);
				cpIncomeDisasterCargo = cpIncomeDisasterColl.getCargo(0);

				cpIncomeDisasterCargo.setApp_num(appNumber);
				cpIncomeDisasterCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);

				disasterFinanceBO.storeIncomeDisasterDetails(cpIncomeDisasterCargo);
			}

		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeIncomeDetailsDCF",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		} finally {
			fwTxn.setPageCollection(pageCollection);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.storeIncomeDetailsDCF() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

	}

	private void loadIncomeDetailsDCF(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.loadIncomeDetailsDCF() - START");

		Map<String, Object> pageCollection = null;
		String appNumber = FinancialInfoConstants.EMPTY_STR;
		try {
			appNumber = fwTxn.getUserDetails().getAppNumber();
			pageCollection = fwTxn.getPageCollection();
			CP_INCOME_DISASTER_Collection existingIncomeDisasterColl = disasterFinanceBO.loadIncomeDetails(appNumber);

			if (Objects.nonNull(existingIncomeDisasterColl) && !existingIncomeDisasterColl.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.CP_INCOME_DISASTER_COLLECTION, existingIncomeDisasterColl);
			}

		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadIncomeDetailsDCF",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		} finally {
			fwTxn.setPageCollection(pageCollection);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.loadIncomeDetailsDCF() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

	}

	public void getLostJobDetail(final FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "JobIncomeServiceImpl.getLostJobDetail() - START");
		try {
			final Map<String, Object> pageColl = fwTxn.getPageCollection();
			UserDetails userDetails = fwTxn.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			APP_IN_EMPL_Collection appInEmpColl = new APP_IN_EMPL_Collection();

			APP_IN_EMPL_Collection updatedAppEmplArr = jobIncomeBO.loadDetails(String.valueOf(appNum));
			if (null != updatedAppEmplArr) {
				for (Iterator<APP_IN_EMPL_Cargo> iterator = updatedAppEmplArr.iterator(); iterator.hasNext();) {
					APP_IN_EMPL_Cargo appInEmplCargo = iterator.next();
					if (null != appInEmplCargo && null != appInEmplCargo.getLostJobInd()
							&& appInEmplCargo.getLostJobInd().equalsIgnoreCase(FwConstants.YES)) {
						appInEmpColl.add(appInEmplCargo);
					}
				}
			}
			if (!appInEmpColl.isEmpty()) {
				pageColl.put(FinancialInfoConstants.APP_IN_EMPL_COLLECTION, appInEmpColl);
			}

			fwTxn.setPageCollection(pageColl);

		} catch (final Exception fe) {
			FwExceptionManager.handleException(fe, this.getClass().getName(), FinancialInfoConstants.GETLOSTJOBDETAIL,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.getLostJobDetail() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);
	}

	public void deleteLostJobDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), Level.INFO, "JobIncomeServiceImpl.deleteLostJobDetails() - START");
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer indivSeqNumInt = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seqNum = 0;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}
			APP_IN_EMPL_Collection appInEmpColl = jobIncomeBO.loadDetails(appNum, indivSeqNumInt, seqNum);
			for (int i = 0; i < appInEmpColl.size(); i++) {
				APP_IN_EMPL_Cargo appInEmpCargo = appInEmpColl.getCargo(i);
				if (Objects.nonNull(appInEmpCargo) && null != appInEmpCargo.getLostJobInd()
						&& appInEmpCargo.getLostJobInd().equals(FwConstants.YES)) {
					cpAppInEmplRepository.delete(appInEmpCargo);
				}
			}

		} catch (final Exception fe) {
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.DELETELOSTJOBDETAILS, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "JobIncomeServiceImpl.deleteLostJobDetails() - END");
	}

	public void storePRSelfEmployment(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::storePRSelfEmployment:Start");
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer seqNum = 0;
			// get Details Collection and Cargo
			final APP_IN_SELFE_Collection appInCollReq = (APP_IN_SELFE_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_SELFE_COLL);
			APP_IN_SELFE_Cargo cargoReq = appInCollReq.getCargo(0);

			final APP_IN_SELFEMP_PAY_STUB_Collection appInPayStubCollReq = (APP_IN_SELFEMP_PAY_STUB_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_SELFE_PAY_STUB_COLLECTION);

			final Integer indvSeqNum = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			if (null != fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence()
					&& !fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence()
							.isEmpty()) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			} else {
				if (null != cargoReq && cargoReq.getSeq_num() != 0) {
					seqNum = cargoReq.getSeq_num();
				}
			}

			List<APP_IN_SELFEMP_PAY_STUB_Cargo> sortedPayStubList = jobIncomeBO.getPayStubList(appInPayStubCollReq,
					appNum, indvSeqNum, seqNum);
			Double totalAmount = sortedPayStubList.stream().filter(cargo -> null != cargo.getPaymentAmt())
					.map(APP_IN_SELFEMP_PAY_STUB_Cargo::getPaymentAmt).reduce(Double.valueOf(0), Double::sum);
			if (null != cargoReq) {
				cargoReq.setAvg_incm_amt(totalAmount);
				cargoReq.setAmount(totalAmount);
				cargoReq.setExp_amt(Double.valueOf(0));
				cargoReq.setExp_ind(0);
			}

			storeSelfEmploymentDetail(fwTxn);

			jobIncomeBO.deleteSelfEmplPayStubForParentRecord(appNum, indvSeqNum, seqNum);
			jobIncomeBO.insertSelfEmplPayStubRecord(sortedPayStubList);

			if (!sortedPayStubList.isEmpty()) {
				appInPayStubCollReq.setResults(
						sortedPayStubList.toArray(new APP_IN_SELFEMP_PAY_STUB_Cargo[sortedPayStubList.size()]));
				pageCollection.put(FinancialInfoConstants.APP_IN_SELFE_PAY_STUB_COLLECTION, appInPayStubCollReq);
			}

			pageCollection.put(FinancialInfoConstants.APP_IN_SELFE_COLL, appInCollReq);
			fwTxn.setPageCollection(pageCollection);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::storePRSelfEmployment:End");
		} catch (final Exception fe) {
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.STORE_PR_SELF_EARNED_INCOME, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean.storePRSelfEmployment() - END ");

	}

	public void storePREmployment(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::storePREmployment:Start");
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer seqNum = 0;
			// get Details Collection and Cargo
			final APP_IN_EMPL_Collection appInCollReq = (APP_IN_EMPL_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_EMPL_COLLECTION);
			APP_IN_EMPL_Cargo cargoReq = appInCollReq.getCargo(0);

			final APP_IN_EMPL_PAY_STUB_Collection appInPayStubCollReq = (APP_IN_EMPL_PAY_STUB_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_EMPL_PAY_STUB_COLLECTION);

			final Integer indvSeqNum = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			if (null != fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence()
					&& !fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence()
							.isEmpty()) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			} else {
				if (null != cargoReq && cargoReq.getEmpl_seq_num() != 0) {
					seqNum = cargoReq.getEmpl_seq_num();
				}
			}

			List<APP_IN_EMPL_PAY_STUB_Cargo> sortedPayStubList = jobIncomeBO.getPayStubList(appInPayStubCollReq, appNum,
					indvSeqNum, seqNum);
			Double totalAmount = sortedPayStubList.stream().filter(cargo -> null != cargo.getPaymentAmt())
					.map(APP_IN_EMPL_PAY_STUB_Cargo::getPaymentAmt).reduce(Double.valueOf(0.0), Double::sum);
			if (null != cargoReq) {
				cargoReq.setGross_pay_amt(totalAmount);
			}

			storeEmploymentDetail(fwTxn);

			jobIncomeBO.deleteEmplPayStubForParentRecord(appNum, indvSeqNum, seqNum);
			jobIncomeBO.insertEmplPayStubRecord(sortedPayStubList);

			if (!sortedPayStubList.isEmpty()) {
				appInPayStubCollReq.setResults(
						sortedPayStubList.toArray(new APP_IN_EMPL_PAY_STUB_Cargo[sortedPayStubList.size()]));
				pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_PAY_STUB_COLLECTION, appInPayStubCollReq);
			}

			pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_COLLECTION, appInCollReq);
			fwTxn.setPageCollection(pageCollection);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::storePREmployment:End");
		} catch (final Exception fe) {
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.STORE_PR_EARNED_INCOME, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean.storePREmployment() - END ");

	}

	public void loadSeflEmploymentPayStub(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean.loadSeflEmploymetPayStub() - START");
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::loadSeflEmploymetPayStub:Start");
			final String appNum = fwTxn.getUserDetails().getAppNumber();

			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();
			Integer indvSeq = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			APP_IN_SELFEMP_PAY_STUB_Collection coll = jobIncomeBO.getSelfEmplPayStubForParentRecord(appNum, indvSeq,
					seqNum);
			APP_IN_SELFE_Collection selfEmpColl = abJobIncomeBO.loadIndividualSelfEmploymentDetails(appNum, indvSeq,
					seqNum);
			Map pageCollection = new HashMap();
			if (Objects.nonNull(coll) && !coll.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.APP_IN_SELFE_PAY_STUB_COLLECTION, coll);
			}
			if (Objects.nonNull(selfEmpColl) && !selfEmpColl.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.APP_IN_SELFE_COLL, selfEmpColl);
			}

			fwTxn.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::loadSeflEmploymetPayStub:End");
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, "JobIncomeServiceImpl.loadSeflEmploymentPayStub", e);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.LOAD_PR_SELF_EARNED_INCOME, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
	}

	public void loadEmploymentPayStub(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean.loadEmploymentPayStub() - START");
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::loadEmploymentPayStub");
			final String appNum = fwTxn.getUserDetails().getAppNumber();

			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();
			Integer indvSeq = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			APP_IN_EMPL_PAY_STUB_Collection coll = jobIncomeBO.getEmplPayStubForParentRecord(appNum, indvSeq, seqNum);
			APP_IN_EMPL_Collection appInEmplCollection = employmentDetailsBO.loadIndividualEmploymentDetails(appNum,
					indvSeq, seqNum);

			Map pageCollection = new HashMap();
			if (Objects.nonNull(coll) && !coll.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_PAY_STUB_COLLECTION, coll);
			}
			if (Objects.nonNull(appInEmplCollection) && !appInEmplCollection.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_COLLECTION, appInEmplCollection);
			}
			fwTxn.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::loadEmploymentPayStub:End");
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, "JobIncomeServiceImpl.loadEmploymentPayStub", e);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.LOAD_PR_EARNED_INCOME, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Load method for all(Earned, UnEarned, Self) Income details for MC flow *
	 * 
	 ********************************************************************************************************************
	 */
	@SuppressWarnings("squid:S3776")
	private void loadAllIncomeDetailsMC(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.loadAllIncomeDetailsMC() - START");

		Map<String, Object> pageCollection = null;
		try {
			pageCollection = fwTxn.getPageCollection();
			String pageAction = fwTxn.getCurrentActionDetails().getPageAction();
			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();

			List<MCIncomeDetails> finalIncomeList = new ArrayList<>();
			List<MCIncomeIndividual_Cargo> mcIncomeIndividualList = new ArrayList<>();
			
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);
			

			if ("MCISULoad".equalsIgnoreCase(pageAction)) {
				mcIncomeIndividualList = loadMCEmploymentDtls(fwTxn, mcIncomeIndividualList, indvIds);
				mcIncomeIndividualList = loadMCSelfEmploymentDtls(fwTxn, mcIncomeIndividualList, indvIds);
				
				List<MCIncomeIndividual_Cargo> resultData = mcIncomeIndividualList.stream()
						.collect(Collectors.toList());
				
				MCIncomeDetails reviewDetails = new MCIncomeDetails();
				reviewDetails.setIncomeIndvList(resultData);
				finalIncomeList.add(reviewDetails);
				
				pageCollection.put(MC_INCOME_DETAILS, finalIncomeList);
				pageCollection.put(INCOMEMAXSEQNUM, mcIncomeIndividualList.size());
			}else if ("MCIBSLoad".equalsIgnoreCase(pageAction) || "MCICSLoad".equalsIgnoreCase(pageAction)) {
				mcIncomeIndividualList = loadMCUnearnedIncomeDtls(fwTxn, mcIncomeIndividualList, indvIds);
				Map<String, List<MCIncomeIndividual_Cargo>> resultData = mcIncomeIndividualList.stream()
						.collect(Collectors.groupingBy(MCIncomeIndividual_Cargo::getIncomeCd));
				String incomeType = categorySequenceDetails.getCategoryType();
				resultData.forEach((key, value) -> {
					if(key.equalsIgnoreCase(incomeType)) {
					MCIncomeDetails reviewDetails = new MCIncomeDetails();
					reviewDetails.setIncomeCd(key);
					reviewDetails.setIncomeIndvList(value);
					finalIncomeList.add(reviewDetails);
					}
				});
				
				pageCollection.put(MC_INCOME_DETAILS, finalIncomeList);
				pageCollection.put(INCOMEMAXSEQNUM, mcIncomeIndividualList.size());
			} else if ("MCIRWLoad".equalsIgnoreCase(pageAction)) {
				mcIncomeIndividualList = loadMCEmploymentDtls(fwTxn, mcIncomeIndividualList, indvIds);
				mcIncomeIndividualList = loadMCSelfEmploymentDtls(fwTxn, mcIncomeIndividualList, indvIds);
				mcIncomeIndividualList = loadMCUnearnedIncomeDtls(fwTxn, mcIncomeIndividualList, indvIds);
								
				Map<String, List<MCIncomeIndividual_Cargo>> resultData = mcIncomeIndividualList.stream()
						.collect(Collectors.groupingBy(MCIncomeIndividual_Cargo::getIncomeCd));
				resultData.forEach((key, value) -> {
					MCIncomeDetails reviewDetails = new MCIncomeDetails();
					reviewDetails.setIncomeCd(key);
					reviewDetails.setIncomeIndvList(value);
					finalIncomeList.add(reviewDetails);
				});
				
				pageCollection.put(MC_INCOME_DETAILS, finalIncomeList);
				pageCollection.put(INCOMEMAXSEQNUM, mcIncomeIndividualList.size());
				
			}


		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"JobIncomeServiceImpl.loadAllIncomeDetailsMC() - MCIRW, exception occurred: "+exception);
			
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadAllIncomeDetailsMC",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		} finally {
			fwTxn.setPageCollection(pageCollection);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.loadAllIncomeDetailsMC() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Load method for Earned Income details for MC flow 
	 * @param indvIds *
	 * 
	 ********************************************************************************************************************
	 */
	private List<MCIncomeIndividual_Cargo> loadMCEmploymentDtls(FwTransaction fwTxn,
			List<MCIncomeIndividual_Cargo> mcIncomeIndividualList, ArrayList<String> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.loadMCEmploymentDtls() - START");

		Map<String, Object> pageCollection = null;
		String appNumber = FinancialInfoConstants.EMPTY_STR;
		try {
			appNumber = fwTxn.getUserDetails().getAppNumber();
			pageCollection = fwTxn.getPageCollection();

			APP_IN_EMPL_Collection incomeColl = employmentDetailsBO.getActiveEmploymentDetails(appNumber);

			if (Objects.nonNull(incomeColl) && !incomeColl.isEmpty()) {

				for (APP_IN_EMPL_Cargo appInEmplCargo : incomeColl.getResults()) {
						if (null != appInEmplCargo && appInEmplCargo.getEmpl_type().equalsIgnoreCase(FinancialInfoConstants.IK_INCOME_TYPE_E)) {
							if(indvIds.contains(appInEmplCargo.getIndv_seq_num().toString())) {
							MCIncomeIndividual_Cargo mcIncomeIndividual = new MCIncomeIndividual_Cargo();
							mcIncomeIndividual.setIndv_seq_num(appInEmplCargo.getIndv_seq_num());
							mcIncomeIndividual.setApp_num(appNumber);
							mcIncomeIndividual.setPay_freq(appInEmplCargo.getPay_freq_cd());
							mcIncomeIndividual.setAmt(appInEmplCargo.getGross_pay_amt());
							mcIncomeIndividual.setIncomeCd(appInEmplCargo.getEmpl_type());
							mcIncomeIndividual.setSeqNum(appInEmplCargo.getEmpl_seq_num());
							mcIncomeIndividual.setEff_begin_dt(appInEmplCargo.getEmpl_begin_dt());
							mcIncomeIndividual.setEff_end_dt(appInEmplCargo.getEmpl_end_dt());
							mcIncomeIndividual.setExpected_to_cont_resp(appInEmplCargo.getExpected_to_cont_resp());
							mcIncomeIndividual.setIncome_src(appInEmplCargo.getIncomeSource());
							mcIncomeIndividualList.add(mcIncomeIndividual);
						}
					}
				}
			}
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadMCEmploymentDtls",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.loadMCEmploymentDtls() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

		return mcIncomeIndividualList;
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Load method for SelfEmployment Income details for MC flow 
	 * @param indvIds *
	 * 
	 ********************************************************************************************************************
	 */
	private List<MCIncomeIndividual_Cargo> loadMCSelfEmploymentDtls(FwTransaction fwTxn,
			List<MCIncomeIndividual_Cargo> mcIncomeIndividualList, ArrayList<String> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.loadMCSelfEmploymentDtls() - START");

		Map<String, Object> pageCollection = null;
		String appNumber = FinancialInfoConstants.EMPTY_STR;
		try {
			appNumber = fwTxn.getUserDetails().getAppNumber();
			pageCollection = fwTxn.getPageCollection();

			APP_IN_SELFE_Collection selfEmpColl = abJobIncomeBO.getActiveSelfEmploymentDetails(appNumber);

			if (Objects.nonNull(selfEmpColl) && !selfEmpColl.isEmpty()) {

				for (APP_IN_SELFE_Cargo selfEmpCargo : selfEmpColl.getResults()) {
					if(indvIds.contains(selfEmpCargo.getIndv_seq_num().toString())) {
						MCIncomeIndividual_Cargo mcIncomeIndividual = new MCIncomeIndividual_Cargo();
						mcIncomeIndividual.setIndv_seq_num(selfEmpCargo.getIndv_seq_num());
						mcIncomeIndividual.setApp_num(appNumber);
						mcIncomeIndividual.setPay_freq(selfEmpCargo.getPay_freq());
						mcIncomeIndividual.setAmt(selfEmpCargo.getAmount());
						mcIncomeIndividual.setIncomeCd(selfEmpCargo.getSelf_empl_typ());
						mcIncomeIndividual.setSeqNum(selfEmpCargo.getSeq_num());
						mcIncomeIndividual.setEff_begin_dt(selfEmpCargo.getEff_begin_dt());
						mcIncomeIndividual.setEff_end_dt(selfEmpCargo.getSelf_emp_end_dt());
						mcIncomeIndividual.setExpected_to_cont_resp(selfEmpCargo.getExpected_to_cont_resp());
						mcIncomeIndividual.setIncome_src(selfEmpCargo.getIncomeSource());

						mcIncomeIndividualList.add(mcIncomeIndividual);
					}
				}

			}

		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadMCSelfEmploymentDtls",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.loadMCSelfEmploymentDtls() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

		return mcIncomeIndividualList;
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Load method for Unearned Income details for MC flow 
	 * @param indvIds *
	 * 
	 ********************************************************************************************************************
	 */
	private List<MCIncomeIndividual_Cargo> loadMCUnearnedIncomeDtls(FwTransaction fwTxn,
			List<MCIncomeIndividual_Cargo> mcIncomeIndividualList, ArrayList<String> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.loadMCUnearnedIncomeDtls() - START");

		Map<String, Object> pageCollection = null;
		String appNumber = FinancialInfoConstants.EMPTY_STR;
		try {
			appNumber = fwTxn.getUserDetails().getAppNumber();
			pageCollection = fwTxn.getPageCollection();

			APP_IN_UEI_Collection appInUeiCollection = abOtherIncomeBO.loadActiveOtherIncomesDetail(appNumber);

			if (Objects.nonNull(appInUeiCollection) && !appInUeiCollection.isEmpty()) {

				for (APP_IN_UEI_Cargo ueiEmpCargo : appInUeiCollection.getResults()) {
					if(indvIds.contains(ueiEmpCargo.getIndv_seq_num().toString())) {
						MCIncomeIndividual_Cargo mcIncomeIndividual = new MCIncomeIndividual_Cargo();
						mcIncomeIndividual.setIndv_seq_num(ueiEmpCargo.getIndv_seq_num());
						mcIncomeIndividual.setApp_num(appNumber);
						mcIncomeIndividual.setPay_freq(ueiEmpCargo.getFreq_cd());
						mcIncomeIndividual.setAmt(ueiEmpCargo.getUei_amt());
						mcIncomeIndividual.setIncomeCd(ueiEmpCargo.getUei_typ());
						mcIncomeIndividual.setSeqNum(ueiEmpCargo.getSeq_num());
						mcIncomeIndividual.setEff_begin_dt(ueiEmpCargo.getUei_beg_dt());
						mcIncomeIndividual.setEff_end_dt(ueiEmpCargo.getUei_end_dt());
						mcIncomeIndividual.setExpected_to_cont_resp(ueiEmpCargo.getExpected_to_cont_resp());
						mcIncomeIndividual.setIncome_src(ueiEmpCargo.getIncome_source());

						mcIncomeIndividualList.add(mcIncomeIndividual);
					}
				}
			}
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadMCUnearnedIncomeDtls",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.loadMCUnearnedIncomeDtls() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS);

		return mcIncomeIndividualList;
	}

	public void storeSelfDetail(final FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeEJBBean.storeSelfDetail() - START , Time Taken : \"\r\n"
						+ "							+ (System.currentTimeMillis() - startTime)\r\n"
						+ "							+ \" milliseconds");
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			final Map request = fwTxn.getRequest();
			final String appNum = fwTxn.getUserDetails().getAppNumber();

			APP_IN_EMPL_Collection cpAppInEmplColl = (APP_IN_EMPL_Collection) pageCollection.get(APP_IN_EMPL_COLL);
			APP_IN_EMPL_Cargo cpAppInEmplCargo = cpAppInEmplColl.getCargo(0);
			Integer indv_seq_num = cpAppInEmplCargo.getIndv_seq_num();

			APP_IN_EMPL_Collection cpAppInEmplBeforeColl = cpAppInEmplRepository.getEarnedIncomeChangeData(Integer.parseInt(appNum),
					indv_seq_num);
			if (Objects.nonNull(cpAppInEmplBeforeColl) && (!cpAppInEmplBeforeColl.isEmpty())) {
				APP_IN_EMPL_Cargo cpAppInEmplBeforeCargo = cpAppInEmplBeforeColl.getCargo(0);
				cpAppInEmplCargo.setEmpl_seq_num(cpAppInEmplBeforeCargo.getEmpl_seq_num());
			} else {
				Integer maxSeqNum = (Integer) cpAppInEmplRepository.getMaxEmplSeqNumber(Integer.parseInt(appNum), indv_seq_num);
				Integer updatedmaxSeqNum = Objects.nonNull(maxSeqNum) ? maxSeqNum + 1 : 1;
				cpAppInEmplCargo.setEmpl_seq_num(updatedmaxSeqNum);
			}

			cpAppInEmplCargo.setSrc_app_ind("AB");
			cpAppInEmplCargo.setEmpl_type("EIC");
			cpAppInEmplCargo.setApp_num(appNum);
			cpAppInEmplCargo.setIndv_seq_num(indv_seq_num);
			cpAppInEmplCargo.setIk_income_type("EIC");

			cpAppInEmplColl.set(0, cpAppInEmplCargo);
			cpAppInEmplColl = employmentDetailsBO.storeEmplDetails(cpAppInEmplColl);

			pageCollection.put(APP_IN_EMPL_COLL, cpAppInEmplColl);
			fwTxn.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORESELFDETAIL,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.storeSelfDetail:End() - END , Time Taken : \"\r\n"
						+ "							+ (System.currentTimeMillis() - startTime)\r\n"
						+ "							+ \" milliseconds");
	}

	public void loadChangeInIncomeDetailsRAC(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean.loadChangeInIncomeDetailsRAC() - START");
		try {
			Map pageCollection = fwTxn.getPageCollection();
			final String appNum = fwTxn.getUserDetails().getAppNumber();
			APP_IN_EMPL_Collection listOfIncomeChangedetailsBasedOnType;
			listOfIncomeChangedetailsBasedOnType = cpAppInEmplRepository.getEmploymentDetailsByAppNum(Integer.parseInt(appNum));
			pageCollection.put(APP_IN_EMPL_COLL, listOfIncomeChangedetailsBasedOnType);

			fwTxn.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::loadChangeInIncomeDetailsRAC");
		} catch (final Exception e) {
			throw e;
		}
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Store Income details method for MC flow *
	 * 
	 ********************************************************************************************************************
	 */
	public void storeMCIncomeDetails(final FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeEJBBean.storeMCEmploymentDetail() - START , Time Taken : \r\n");
		try {
			Map pageCollection = fwTxn.getPageCollection();
			MCIncomeIndividual_Collection mcIndvCollection = (MCIncomeIndividual_Collection) pageCollection
					.get("MCIncomeIndividual_Collection");
			MCIncomeIndividual_Cargo indvIncomeCargo = mcIndvCollection.getCargo(0);
			
			if(null==indvIncomeCargo.getApp_num() || indvIncomeCargo.getApp_num().trim().isEmpty()) {
				indvIncomeCargo.setApp_num(fwTxn.getUserDetails().getAppNumber());
			}
			

			String specificIncomeCargo = getSpecificIncomeCargoName(indvIncomeCargo.getIncomeCd());
			
			var categorySequenceDetails = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails();
			Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			processSelfEmplDetails(pageCollection, indvIncomeCargo, specificIncomeCargo, seqNum);

			processEmplDetails(pageCollection, indvIncomeCargo, specificIncomeCargo, seqNum);

			processUnearnedIncome(pageCollection, indvIncomeCargo, specificIncomeCargo, seqNum);

			fwTxn.setPageCollection(pageCollection);

			switch (specificIncomeCargo) {
			case SELF_EMPL_INCOME:
				storeSelfEmploymentDetail(fwTxn);
				break;

			case EARNED_EMPL_INCOME:
				storeEmploymentDetail(fwTxn);
				break;

			case UNEARNED_EMPL_INCOME:
				otherIncomeServImpl.storeOtherIncomeDetail(fwTxn);
				break;

			default:
				break;

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"JobIncomeServiceImpl.storeMCEmploymentDetail:- " + e.getStackTrace());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"JobIncomeServiceImpl.storeMCEmploymentDetail:End() - END , Time Taken : \r\n");

	}

	private void processUnearnedIncome(Map pageCollection, MCIncomeIndividual_Cargo indvIncomeCargo,
			String specificIncomeCargo, Integer seqNum) {
		if (specificIncomeCargo.equalsIgnoreCase(UNEARNED_EMPL_INCOME)) {
			var appInUEIColl = new APP_IN_UEI_Collection();
			APP_IN_UEI_Cargo cargoReq = null;

			APP_IN_UEI_Collection exsistingUnearnedIncomeColl = abOtherIncomeBO.loadIndividualOtherIncomeDetail(
					indvIncomeCargo.getApp_num(), indvIncomeCargo.getIndv_seq_num(), seqNum,
					indvIncomeCargo.getIncomeCd());

			if (Objects.nonNull(exsistingUnearnedIncomeColl) && !exsistingUnearnedIncomeColl.isEmpty()) {
				cargoReq = exsistingUnearnedIncomeColl.getCargo(0);
			}

			if (Objects.isNull(cargoReq)) {
				cargoReq = new APP_IN_UEI_Cargo();
			}

			cargoReq.setFreq_cd(indvIncomeCargo.getPay_freq());
			cargoReq.setFst_nam(indvIncomeCargo.getName());
			cargoReq.setUei_amt(indvIncomeCargo.getAmt());
			cargoReq.setIndv_seq_num(indvIncomeCargo.getIndv_seq_num());
			cargoReq.setUei_typ(indvIncomeCargo.getIncomeCd());
			cargoReq.setApp_num(indvIncomeCargo.getApp_num());
			cargoReq.setExpected_to_cont_resp(indvIncomeCargo.getExpected_to_cont_resp());
			cargoReq.setUei_end_dt(indvIncomeCargo.getEff_end_dt());
			cargoReq.setUei_beg_dt(indvIncomeCargo.getEff_begin_dt());
			cargoReq.setIncome_source(indvIncomeCargo.getIncome_src());
			cargoReq.setDivorce_dt(indvIncomeCargo.getDivorce_dt());
			cargoReq.setChg_dt(new Date());

			appInUEIColl.add(cargoReq);
			pageCollection.put(FinancialInfoConstants.APP_IN_UEI_COLL, appInUEIColl);

		}
	}

	private void processEmplDetails(Map pageCollection, MCIncomeIndividual_Cargo indvIncomeCargo,
			String specificIncomeCargo, Integer seqNum) {
		if (specificIncomeCargo.equalsIgnoreCase(EARNED_EMPL_INCOME)) {
			var cpAppInEmplColl = new APP_IN_EMPL_Collection();
			APP_IN_EMPL_Cargo cargoReq = null;

			APP_IN_EMPL_Collection exsistingEarnedIncomeColl = employmentDetailsBO.getEarnedIncomeDetail(
					indvIncomeCargo.getApp_num(), indvIncomeCargo.getIndv_seq_num(), seqNum,
					indvIncomeCargo.getIncomeCd());

			if (Objects.nonNull(exsistingEarnedIncomeColl) && !exsistingEarnedIncomeColl.isEmpty()) {
				cargoReq = exsistingEarnedIncomeColl.getCargo(0);
			}

			if (Objects.isNull(cargoReq)) {
				cargoReq = new APP_IN_EMPL_Cargo();
			}
			
			cargoReq.setPay_freq_cd(indvIncomeCargo.getPay_freq());
			cargoReq.setFst_nam(indvIncomeCargo.getName());
			cargoReq.setGross_pay_amt(indvIncomeCargo.getAmt());
			cargoReq.setIndv_seq_num(indvIncomeCargo.getIndv_seq_num());
			cargoReq.setEmpl_type(indvIncomeCargo.getIncomeCd());
			cargoReq.setApp_num(indvIncomeCargo.getApp_num());
			cargoReq.setExpected_to_cont_resp(indvIncomeCargo.getExpected_to_cont_resp());
			cargoReq.setEmpl_end_dt(indvIncomeCargo.getEff_end_dt());
			cargoReq.setEmpl_begin_dt(indvIncomeCargo.getEff_begin_dt());
			cargoReq.setIncomeSource(indvIncomeCargo.getIncome_src());
			cargoReq.setChange_dt(new Date());

			cpAppInEmplColl.add(cargoReq);
			pageCollection.put(APP_IN_EMPL_COLL, cpAppInEmplColl);

		}
	}

	private void processSelfEmplDetails(Map pageCollection, MCIncomeIndividual_Cargo indvIncomeCargo,
			String specificIncomeCargo, Integer seqNum) {
		if (specificIncomeCargo.equalsIgnoreCase(SELF_EMPL_INCOME)) {
			var appInCollReq = new APP_IN_SELFE_Collection();

			APP_IN_SELFE_Cargo cargoReq = null;
			APP_IN_SELFE_Collection exsistingSelfIncomeColl = abJobIncomeBO.getSelfEmplIncomeDetail(
					indvIncomeCargo.getApp_num(), indvIncomeCargo.getIndv_seq_num(), seqNum);

			if (Objects.nonNull(exsistingSelfIncomeColl) && !exsistingSelfIncomeColl.isEmpty()) {
				cargoReq = exsistingSelfIncomeColl.getCargo(0);
			}

			if (Objects.isNull(cargoReq)) {
				cargoReq = new APP_IN_SELFE_Cargo();
			}
			
			cargoReq.setPay_freq(indvIncomeCargo.getPay_freq());
			cargoReq.setFst_name(indvIncomeCargo.getName());
			cargoReq.setAmount(indvIncomeCargo.getAmt());
			cargoReq.setIndv_seq_num(indvIncomeCargo.getIndv_seq_num());
			cargoReq.setSelf_empl_typ(indvIncomeCargo.getIncomeCd());
			cargoReq.setApp_num(indvIncomeCargo.getApp_num());
			cargoReq.setExpected_to_cont_resp(indvIncomeCargo.getExpected_to_cont_resp());
			cargoReq.setSelf_emp_end_dt(indvIncomeCargo.getEff_end_dt());
			cargoReq.setEff_begin_dt(indvIncomeCargo.getEff_begin_dt());
			cargoReq.setIncomeSource(indvIncomeCargo.getIncome_src());
			cargoReq.setChg_dt(new Date());

			appInCollReq.add(cargoReq);
			pageCollection.put(APP_IN_SELFE_COLL, appInCollReq);

		}
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Method to get specified income type based on income code passed *
	 * 
	 ********************************************************************************************************************
	 */
	private String getSpecificIncomeCargoName(String incomeCd) {
		
		List<String> ueiTypeList = Arrays.asList(FinancialInfoConstants.UEITYPE.split(",")).stream().map(x -> x)
				.collect(Collectors.toList());
		if (FinancialInfoConstants.SELFEMPLTYPE.equalsIgnoreCase(incomeCd)) {
			return SELF_EMPL_INCOME;

		} else if ((FinancialInfoConstants.EMPLTYPE).equalsIgnoreCase(incomeCd) || (FinancialInfoConstants.E).equalsIgnoreCase(incomeCd)) {
			return EARNED_EMPL_INCOME;

		} else if (ueiTypeList.contains(incomeCd)) { 
			return UNEARNED_EMPL_INCOME;

		}
		return EARNED_EMPL_INCOME;
	}

	/*
	 * This Method is used to update the eff_end_dt column for all the income tables
	 * based on income_cd whenever Remove is called from screen.
	 *
	 *
	 */
	public void deleteMCIncomeDetails(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "deleteMCIncomeDetails");
		Map pageCollection;
		pageCollection = fwTxn.getPageCollection();
		String appNumber = null;
		final UserDetails userDetails = fwTxn.getUserDetails();
		try {
			appNumber = userDetails.getAppNumber();
			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();
			MCIncomeIndividual_Collection mcIndvCollection = (MCIncomeIndividual_Collection) pageCollection
					.get("MCIncomeIndividual_Collection");
			MCIncomeIndividual_Cargo indvIncomeCargo = mcIndvCollection.getCargo(0);
			Integer indvSeq = indvIncomeCargo.getIndv_seq_num();
			Integer seqNum = indvIncomeCargo.getSeqNum();
			java.util.Date effEndDt = indvIncomeCargo.getEnd_dt();
			String incomeType = indvIncomeCargo.getIncomeCd();

			if ("SE".equals(incomeType)) {

				deleteMCSelfIncome(appNumber, indvSeq, seqNum, effEndDt);
			}

			if ("E".equals(incomeType)) {

				deleteMCEarnedIncome(appNumber, indvSeq, seqNum, effEndDt);

			}

			List<String> ueiTypeList = Arrays.asList(FinancialInfoConstants.UEITYPE.split(",")).stream().map(x -> x)
					.collect(Collectors.toList());
			if(ueiTypeList.contains(incomeType)) {
				String ueiType = categorySequenceDetails.getCategoryType();
				deleteMCUnEarnedIncome(appNumber, indvSeq, effEndDt, ueiType);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), Level.ERROR, "JobIncomeServiceImpl.deleteMCIncomeDetails", exception);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteMCIncomeDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "deleteMCIncomeDetails: END");

	}

	/**
	 * @author maheshr
	 * @param fwTxn
	 */
	public void financialAppSummaryData(FwTransaction fwTxn)
	{
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "financialAppSummaryData START");
			try {
				this.getJobIncomeSummaryDetails(fwTxn);
				expenseSummaryServiceImpl.getPrflData(fwTxn);
				financialAssetsService.getAFBAssetSummaryDetails(fwTxn);
				liquidAssetsServImpl.getAccountInfoDetailsRAC(fwTxn);
			} catch (Exception exception) {
				FwLogger.log(this.getClass(), Level.ERROR, "JobIncomeServiceImpl.financialAppSummaryData >>> "+exception);
				FwExceptionManager.handleException(exception, this.getClass().getName(), "financialAppSummaryData",
						fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "financialAppSummaryData END");
	}
	
	private void deleteMCSelfIncome(String appNumber, Integer indvSeq, Integer seqNum, java.util.Date effEndDt) {
		try {
			APP_IN_SELFE_Cargo newCargo = new APP_IN_SELFE_Cargo();
			APP_IN_SELFE_Collection selfEmpColl = abJobIncomeBO.loadIndividualSelfEmploymentDetails(appNumber, indvSeq,
					seqNum);
			if ((selfEmpColl != null) && !selfEmpColl.isEmpty() && (selfEmpColl.getCargo(0) != null)) {
				newCargo = selfEmpColl.getCargo(0);
				newCargo.setEnd_dt(effEndDt);
			}
			if (selfEmpColl != null && !selfEmpColl.isEmpty()
					&& !FinancialInfoConstants.EMPTY_STR.equals(newCargo.getApp_num())) {
				appInSelfeRepository.save(newCargo);

			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), Level.ERROR, "JobIncomeServiceImpl.deleteMCSelfIncome", exception);
			throw exception;
		}

	}

	private void deleteMCEarnedIncome(String appNumber, Integer indvSeq, Integer seqNum, java.util.Date effEndDt) {
		try {
			APP_IN_EMPL_Cargo cappInEmplCargoonewCargo = new APP_IN_EMPL_Cargo();
			APP_IN_EMPL_Collection appInEmplCollection = employmentDetailsBO.loadIndividualEmploymentDetails(appNumber,
					indvSeq, seqNum);
			if ((appInEmplCollection != null) && !appInEmplCollection.isEmpty()
					&& (appInEmplCollection.getCargo(0) != null)) {
				cappInEmplCargoonewCargo = appInEmplCollection.getCargo(0);
				cappInEmplCargoonewCargo.setEnd_dt(effEndDt);
			}
			if (appInEmplCollection != null && !appInEmplCollection.isEmpty()
					&& !FinancialInfoConstants.EMPTY_STR.equals(cappInEmplCargoonewCargo.getApp_num())) {
				if (cappInEmplCargoonewCargo != null) {
					cpAppInEmplRepository.save(cappInEmplCargoonewCargo);
				}
			}
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), Level.ERROR, "JobIncomeServiceImpl.deleteMCEarnedIncome", exception);
			throw exception;
		}
	}

	private void deleteMCUnEarnedIncome(String appNumber, Integer indvSeq, java.util.Date effEndDt, String ueiType) {
		try {
			APP_IN_UEI_Cargo cpAppUeiCargo = null;
			APP_IN_UEI_Collection appInUeiCollection = abOtherIncomeBO.loadIndividualOtherIncomeDetails(appNumber,
					indvSeq, ueiType);
			if ((appInUeiCollection != null) && !appInUeiCollection.isEmpty()
					&& (appInUeiCollection.getCargo(0) != null)) {
				cpAppUeiCargo = appInUeiCollection.getCargo(0);
				cpAppUeiCargo.setEnd_dt(effEndDt);
			}
			appInUieRepository.save(cpAppUeiCargo);
		} catch (Exception exception) {
			FwLogger.log(this.getClass(), Level.ERROR, "JobIncomeServiceImpl.deleteMCUnEarnedIncome", exception);
			throw exception;
		}
	}

	private void deleteEarnedIncomeData(Map pageCollection, String appNumber,
			IndividualCategorySequenceDetails categorySequenceDetails, Integer indvSeq, Integer seq_num) {
		
		if ("E".equals(categorySequenceDetails.getCategoryType())) {
			APP_IN_EMPL_Collection cpAppInEmplCollection = (APP_IN_EMPL_Collection) pageCollection
					.get(APP_IN_EMPL_COLL);
			APP_IN_EMPL_Cargo cappInEmplCargoo = null;
			if (null != cpAppInEmplCollection && cpAppInEmplCollection.size() > 0) {
				cappInEmplCargoo = cpAppInEmplCollection.getCargo(0);
				if (cappInEmplCargoo != null) {
					cappInEmplCargoo.setApp_num(appNumber);
					cappInEmplCargoo.setIndv_seq_num(indvSeq);
				}
			}
			APP_IN_EMPL_Cargo cappInEmplCargoonewCargo = new APP_IN_EMPL_Cargo();
			APP_IN_EMPL_Collection appInEmplCollection = employmentDetailsBO
					.loadIndividualEmploymentDetails(appNumber, indvSeq, seq_num);
			if ((appInEmplCollection != null) && !appInEmplCollection.isEmpty()
					&& (appInEmplCollection.getCargo(0) != null)) {
				cappInEmplCargoonewCargo = appInEmplCollection.getCargo(0);
			}
			if (appInEmplCollection != null && !appInEmplCollection.isEmpty() && null != cappInEmplCargoo
					&& cappInEmplCargoonewCargo != null && !FinancialInfoConstants.EMPTY_STR.equals(cappInEmplCargoonewCargo.getApp_num())
					&& cappInEmplCargoonewCargo.getApp_num().equalsIgnoreCase(cappInEmplCargoo.getApp_num())) {
				cappInEmplCargoo.setRowAction(FwConstants.ROWACTION_DELETE);
				cpAppInEmplRepository.delete(cappInEmplCargoonewCargo);
			}
		}
		
	}
	
	private void storeIncomeInKindDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeIncomeInKindDetails() - Start");
		try {
			final Map pageCollection = fwTxn.getPageCollection();
			final String appNum = fwTxn.getUserDetails().getAppNumber();

			APP_IN_EMPL_Collection cpAppInEmplColl = (APP_IN_EMPL_Collection) pageCollection.get(APP_IN_EMPL_COLL);
			APP_IN_EMPL_Collection updatedAppInEmplColl = new APP_IN_EMPL_Collection();
			APP_IN_EMPL_Cargo cpAppInEmplCargo = cpAppInEmplColl.getCargo(0);
			Integer indvSeqNum = Integer.valueOf((String) pageCollection.get("indvId"));
			Integer seqNum = Integer.valueOf((String) pageCollection.get("seqNum"));
			
			List<String> incomeList = processIncomeTypLst(cpAppInEmplCargo);

			APP_IN_EMPL_Collection existingAppInEmplColl = cpAppInEmplRepository.getEmplDetailsOnSNumLstOfIncomeType(Integer.parseInt(appNum),
					indvSeqNum, seqNum, Arrays.asList(FinancialInfoConstants.RENTINCOMEIND,
							FinancialInfoConstants.FOODINCOMEIND, FinancialInfoConstants.UTILITIESINCOMEIND));

			if (Objects.nonNull(existingAppInEmplColl) && !existingAppInEmplColl.isEmpty()) {
				List<APP_IN_EMPL_Cargo> existingAppInEmplCargoLst = Arrays.asList(existingAppInEmplColl.getResults());
				List<String> existingIncomeType = existingAppInEmplCargoLst.stream().map(x -> x.getIk_income_type())
						.collect(Collectors.toList());

				for (String incomeTypeStr : incomeList) {
					if (existingIncomeType.contains(incomeTypeStr)) {
						APP_IN_EMPL_Cargo existingAppInEmplCargo = existingAppInEmplCargoLst.stream()
								.filter(x -> x.getIk_income_type().equals(incomeTypeStr)).collect(Collectors.toList())
								.get(0);
						
						processIKRecieveType(cpAppInEmplCargo, incomeTypeStr, existingAppInEmplCargo);
						existingAppInEmplCargo.setExpected_to_cont_resp(cpAppInEmplCargo.getExpected_to_cont_resp());
						processLastPayckDt(cpAppInEmplCargo, existingAppInEmplCargo);
						updatedAppInEmplColl.add(existingAppInEmplCargo);
					} else {
						APP_IN_EMPL_Cargo appInEmplCargo = new APP_IN_EMPL_Cargo();
						appInEmplCargo.setApp_num(appNum);
						appInEmplCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
						appInEmplCargo.setIndv_seq_num(indvSeqNum);
						appInEmplCargo.setEmpl_type("IK");
						appInEmplCargo.setIk_income_type(incomeTypeStr);
						appInEmplCargo.setEmpl_seq_num(seqNum);
						processIKRecieveType(cpAppInEmplCargo, incomeTypeStr, appInEmplCargo);
						appInEmplCargo.setExpected_to_cont_resp(cpAppInEmplCargo.getExpected_to_cont_resp());
						processLastPayckDt(cpAppInEmplCargo, appInEmplCargo);

						updatedAppInEmplColl.add(appInEmplCargo);
					}
				}
				processRmvIncomeTyp(incomeList, existingAppInEmplCargoLst, existingIncomeType);
			} else {
				persistNewIncomeTyp(appNum, updatedAppInEmplColl, cpAppInEmplCargo, indvSeqNum, seqNum, incomeList);
			}
			updatedAppInEmplColl = employmentDetailsBO.storeEmplDetails(updatedAppInEmplColl);

			// Load the CargoCollection into the PageCollection
			pageCollection.put(APP_IN_EMPL_COLL, updatedAppInEmplColl);

		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeIncomeInKindDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), false);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.storeIncomeInKindDetails() - END");
	}

	private void processIKRecieveType(APP_IN_EMPL_Cargo cpAppInEmplCargo, String incomeTypeStr,
			APP_IN_EMPL_Cargo existingAppInEmplCargo) {
		if(FinancialInfoConstants.RENTINCOMEIND.equals(incomeTypeStr)) {
			setRecieveTypeForRE(cpAppInEmplCargo, existingAppInEmplCargo);
			
		}
		if(FinancialInfoConstants.FOODINCOMEIND.equals(incomeTypeStr)) {
			setRecieveTypeForFD(cpAppInEmplCargo, existingAppInEmplCargo);
		}
		if(FinancialInfoConstants.UTILITIESINCOMEIND.equals(incomeTypeStr)) {
			setRecievedTypeForUT(cpAppInEmplCargo, existingAppInEmplCargo);
		}
	}

	private void setRecievedTypeForUT(APP_IN_EMPL_Cargo cpAppInEmplCargo, APP_IN_EMPL_Cargo existingAppInEmplCargo) {
		if (Objects.nonNull(cpAppInEmplCargo.getUtilitiesExchInd())
				&& FinancialInfoConstants.Y.equals(cpAppInEmplCargo.getUtilitiesExchInd())) {
			existingAppInEmplCargo.setIk_recv_type(FinancialInfoConstants.WORK_EXCHANGE_TYPE);
		} else if (Objects.nonNull(cpAppInEmplCargo.getUtilitiesExchInd())
				&& FinancialInfoConstants.N.equals(cpAppInEmplCargo.getUtilitiesExchInd())) {
			existingAppInEmplCargo.setIk_recv_type(FinancialInfoConstants.FREE_EXCHANGE_TYPE);
		}
	}

	private void setRecieveTypeForFD(APP_IN_EMPL_Cargo cpAppInEmplCargo, APP_IN_EMPL_Cargo existingAppInEmplCargo) {
		if (Objects.nonNull(cpAppInEmplCargo.getFoodExchInd())
				&& FinancialInfoConstants.Y.equals(cpAppInEmplCargo.getFoodExchInd())) {
			existingAppInEmplCargo.setIk_recv_type(FinancialInfoConstants.WORK_EXCHANGE_TYPE);
		} else if (Objects.nonNull(cpAppInEmplCargo.getFoodExchInd())
				&& FinancialInfoConstants.N.equals(cpAppInEmplCargo.getFoodExchInd())) {
			existingAppInEmplCargo.setIk_recv_type(FinancialInfoConstants.FREE_EXCHANGE_TYPE);
		}
	}

	private void setRecieveTypeForRE(APP_IN_EMPL_Cargo cpAppInEmplCargo, APP_IN_EMPL_Cargo existingAppInEmplCargo) {
		if (Objects.nonNull(cpAppInEmplCargo.getRentExchInd())
				&& FinancialInfoConstants.Y.equals(cpAppInEmplCargo.getRentExchInd())) {
			existingAppInEmplCargo.setIk_recv_type(FinancialInfoConstants.WORK_EXCHANGE_TYPE);
		} else if (Objects.nonNull(cpAppInEmplCargo.getRentExchInd())
				&& FinancialInfoConstants.N.equals(cpAppInEmplCargo.getRentExchInd())) {
			existingAppInEmplCargo.setIk_recv_type(FinancialInfoConstants.FREE_EXCHANGE_TYPE);
		}
	}

	private List<String> processIncomeTypLst(APP_IN_EMPL_Cargo cpAppInEmplCargo) {
		List<String> incomeList = new ArrayList<>();
		if (Objects.nonNull(cpAppInEmplCargo.getRentIncomeInd()) && FinancialInfoConstants.Y.equals(cpAppInEmplCargo.getRentIncomeInd())) {
			incomeList.add(FinancialInfoConstants.RENTINCOMEIND);
		}
		if (Objects.nonNull(cpAppInEmplCargo.getFoodIncomeInd()) && FinancialInfoConstants.Y.equals(cpAppInEmplCargo.getFoodIncomeInd())) {
			incomeList.add(FinancialInfoConstants.FOODINCOMEIND);
		}
		if (Objects.nonNull(cpAppInEmplCargo.getUtilitiesIncomeInd())
				&& FinancialInfoConstants.Y.equals(cpAppInEmplCargo.getUtilitiesIncomeInd())) {
			incomeList.add(FinancialInfoConstants.UTILITIESINCOMEIND);
		}
		return incomeList;
	}

	private void persistNewIncomeTyp(final String appNum, APP_IN_EMPL_Collection updatedAppInEmplColl,
			APP_IN_EMPL_Cargo cpAppInEmplCargo, Integer indvSeqNum, Integer seqNum, List<String> incomeList) {
		if (Objects.nonNull(incomeList) && !incomeList.isEmpty()) {
			for (String incomeTypeStr : incomeList) {
				APP_IN_EMPL_Cargo appInEmplCargo = new APP_IN_EMPL_Cargo();
				appInEmplCargo.setApp_num(appNum);
				appInEmplCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				appInEmplCargo.setIndv_seq_num(indvSeqNum);
				appInEmplCargo.setEmpl_type("IK");
				appInEmplCargo.setIk_income_type(incomeTypeStr);
				appInEmplCargo.setEmpl_seq_num(seqNum);
				processIKRecieveType(cpAppInEmplCargo, incomeTypeStr, appInEmplCargo);
				appInEmplCargo.setExpected_to_cont_resp(cpAppInEmplCargo.getExpected_to_cont_resp());
				processLastPayckDt(cpAppInEmplCargo, appInEmplCargo);
				updatedAppInEmplColl.add(appInEmplCargo);
			}
		}
	}

	private void processRmvIncomeTyp(List<String> incomeList, List<APP_IN_EMPL_Cargo> existingAppInEmplCargoLst,
			List<String> existingIncomeType) {
		List<String> removedIncomeTypeLst = existingIncomeType.stream().filter(x -> !incomeList.contains(x))
				.collect(Collectors.toList());
		if (Objects.nonNull(removedIncomeTypeLst) && !removedIncomeTypeLst.isEmpty()) {
			for (String removedIncomeType : removedIncomeTypeLst) {
				APP_IN_EMPL_Cargo existingAppInEmplCargo = existingAppInEmplCargoLst.stream()
						.filter(x -> x.getIk_income_type().equals(removedIncomeType)).collect(Collectors.toList())
						.get(0);
				cpAppInEmplRepository.delete(existingAppInEmplCargo);
			}
		}
	}

	private void processLastPayckDt(APP_IN_EMPL_Cargo cpAppInEmplCargo, APP_IN_EMPL_Cargo appInEmplCargo) {
		if ("Y".equalsIgnoreCase(cpAppInEmplCargo.getExpected_to_cont_resp())) {
			appInEmplCargo.setLast_payck_dt(null);
		} else if ("N".equalsIgnoreCase(cpAppInEmplCargo.getExpected_to_cont_resp())) {
			appInEmplCargo.setLast_payck_dt(cpAppInEmplCargo.getLast_payck_dt());
		}
	}
	
	private void deleteIncomeInKindInfo(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.deleteIncomeInKindInfo() - Start");
		Map pageCollection = fwTxn.getPageCollection();
		try {
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			Integer seqNum =  Integer.parseInt(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			Integer indvId = Integer.parseInt(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());

			APP_IN_EMPL_Collection existingAppInEmplColl = cpAppInEmplRepository.getEmplDetailsOnSNumLstOfIncomeType(
					Integer.parseInt(appNumber), indvId, seqNum, Arrays.asList(FinancialInfoConstants.RENTINCOMEIND,
							FinancialInfoConstants.FOODINCOMEIND, FinancialInfoConstants.UTILITIESINCOMEIND));
			if (Objects.nonNull(existingAppInEmplColl) && !existingAppInEmplColl.isEmpty()) {
				List<APP_IN_EMPL_Cargo> appInEmplCargos = Arrays.asList(existingAppInEmplColl.getResults());

				for (APP_IN_EMPL_Cargo appInEmplCargo : appInEmplCargos) {
					cpAppInEmplRepository.delete(appInEmplCargo);
				}
			}
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteIncomeInKindInfo",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), false);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.deleteIncomeInKindInfo() - END");
	}
	
	private void loadIncomeInKindDetails(FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.loadIncomeInKindDetails() - Start");
		Map pageCollection = fwTxn.getPageCollection();
		try {
			UserDetails userDetails = fwTxn.getUserDetails();
			String appNumber = userDetails.getAppNumber();
			List<Integer> indvIdList = new ArrayList<>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get(INDV_IDS);

			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			APP_IN_EMPL_Collection newAppInEmplColl = new APP_IN_EMPL_Collection();
			for (Integer indvId : indvIdList) {
				
				APP_IN_EMPL_Collection existingAppInEmplColl = cpAppInEmplRepository.getEmplDetailsOnLstOfIncomeType(
						Integer.parseInt(appNumber), indvId, Arrays.asList(FinancialInfoConstants.RENTINCOMEIND,
								FinancialInfoConstants.FOODINCOMEIND, FinancialInfoConstants.UTILITIESINCOMEIND));
				
				if (Objects.nonNull(existingAppInEmplColl) && !existingAppInEmplColl.isEmpty()) {
					List<APP_IN_EMPL_Cargo> appInEmplCargos = Arrays.asList(existingAppInEmplColl.getResults());
					List<Integer> seqNumList = appInEmplCargos.stream().map(APP_IN_EMPL_Cargo::getEmpl_seq_num)
							.distinct().collect(Collectors.toList());
					
					for (Integer seqNum : seqNumList) {
						APP_IN_EMPL_Cargo newAppInEmplCargo = new APP_IN_EMPL_Cargo();
						Optional<APP_IN_EMPL_Cargo> optExistingAppInEmplCargo = appInEmplCargos.stream()
								.filter(x -> seqNum.equals(x.getEmpl_seq_num())).findFirst();
						if (optExistingAppInEmplCargo.isPresent()) {
							APP_IN_EMPL_Cargo existingAppInEmplCargo = optExistingAppInEmplCargo.get();
							
							newAppInEmplCargo.setApp_num(existingAppInEmplCargo.getApp_num());
							newAppInEmplCargo.setSrc_app_ind(existingAppInEmplCargo.getSrc_app_ind());
							newAppInEmplCargo.setIndv_seq_num(existingAppInEmplCargo.getIndv_seq_num());
							newAppInEmplCargo.setEmpl_type(existingAppInEmplCargo.getEmpl_type());
							newAppInEmplCargo.setIk_income_type(null);
							newAppInEmplCargo.setEmpl_seq_num(existingAppInEmplCargo.getEmpl_seq_num());
							newAppInEmplCargo
									.setExpected_to_cont_resp(existingAppInEmplCargo.getExpected_to_cont_resp());
							newAppInEmplCargo.setLast_payck_dt(existingAppInEmplCargo.getLast_payck_dt());
							List<APP_IN_EMPL_Cargo> existingAppInEmplCargoBySeq = appInEmplCargos.stream()
							.filter(x -> seqNum.equals(x.getEmpl_seq_num())).collect(Collectors.toList());
							String incomeTypeStr = processIncomeTypLstStr(existingAppInEmplCargoBySeq, newAppInEmplCargo);

							newAppInEmplCargo.setIncomeTypeList(incomeTypeStr);
							newAppInEmplColl.add(newAppInEmplCargo);
						}

					}
				}
			}
			pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_COLL, newAppInEmplColl);
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadIncomeInKindDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), false);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeServiceImpl.loadIncomeInKindDetails() - END");
	}

	private void setUtilitiesExchInd(APP_IN_EMPL_Cargo newAppInEmplCargo, APP_IN_EMPL_Cargo existingAppInEmplCargo) {
		if (Objects.nonNull(existingAppInEmplCargo.getIk_recv_type())
				&& FinancialInfoConstants.WORK_EXCHANGE_TYPE.equals(existingAppInEmplCargo.getIk_recv_type())) {
			newAppInEmplCargo.setUtilitiesExchInd(FinancialInfoConstants.Y);
		} else if (Objects.nonNull(existingAppInEmplCargo.getIk_recv_type())
				&& FinancialInfoConstants.FREE_EXCHANGE_TYPE.equals(existingAppInEmplCargo.getIk_recv_type())) {
			newAppInEmplCargo.setUtilitiesExchInd(FinancialInfoConstants.N);
		}
	}

	private void sentFoodExchInd(APP_IN_EMPL_Cargo newAppInEmplCargo, APP_IN_EMPL_Cargo existingAppInEmplCargo) {
		if (Objects.nonNull(existingAppInEmplCargo.getIk_recv_type())
				&& FinancialInfoConstants.WORK_EXCHANGE_TYPE.equals(existingAppInEmplCargo.getIk_recv_type())) {
			newAppInEmplCargo.setFoodExchInd(FinancialInfoConstants.Y);
		} else if (Objects.nonNull(existingAppInEmplCargo.getIk_recv_type())
				&& FinancialInfoConstants.FREE_EXCHANGE_TYPE.equals(existingAppInEmplCargo.getIk_recv_type())) {
			newAppInEmplCargo.setFoodExchInd(FinancialInfoConstants.N);
		}
	}

	private void setRentExchInd(APP_IN_EMPL_Cargo newAppInEmplCargo, APP_IN_EMPL_Cargo existingAppInEmplCargo) {
		if (Objects.nonNull(existingAppInEmplCargo.getIk_recv_type())
				&& FinancialInfoConstants.WORK_EXCHANGE_TYPE.equals(existingAppInEmplCargo.getIk_recv_type())) {
			newAppInEmplCargo.setRentExchInd(FinancialInfoConstants.Y);
		} else if (Objects.nonNull(existingAppInEmplCargo.getIk_recv_type())
				&& FinancialInfoConstants.FREE_EXCHANGE_TYPE.equals(existingAppInEmplCargo.getIk_recv_type())) {
			newAppInEmplCargo.setRentExchInd(FinancialInfoConstants.N);
		}
	}

	private String processIncomeTypLstStr(List<APP_IN_EMPL_Cargo> appInEmplCargos,
			APP_IN_EMPL_Cargo newAppInEmplCargo) {
		Optional<String> optionalIncomeTypeStr = appInEmplCargos.stream().map(x -> {
			if (FinancialInfoConstants.RENTINCOMEIND.equals(x.getIk_income_type())) {
				newAppInEmplCargo.setRentIncomeInd(FinancialInfoConstants.Y);
				setRentExchInd(newAppInEmplCargo, x);
			}
			if (FinancialInfoConstants.FOODINCOMEIND.equals(x.getIk_income_type())) {
				newAppInEmplCargo.setFoodIncomeInd(FinancialInfoConstants.Y);
				sentFoodExchInd(newAppInEmplCargo, x);
			}
			if (FinancialInfoConstants.UTILITIESINCOMEIND.equals(x.getIk_income_type())) {
				newAppInEmplCargo.setUtilitiesIncomeInd(FinancialInfoConstants.Y);
				setUtilitiesExchInd(newAppInEmplCargo, x);
			}
			return getIncomeType(x.getIk_income_type());
		}).reduce((x, y) -> (x + ", " + y));
		return optionalIncomeTypeStr.isPresent() ? optionalIncomeTypeStr.get() : null;
	}
	
	private String getIncomeType(String incomeType) {
		switch (incomeType) {
		case FinancialInfoConstants.RENTINCOMEIND:
			return "Rent";
		case FinancialInfoConstants.FOODINCOMEIND:
			return "Food";
		case FinancialInfoConstants.UTILITIESINCOMEIND:
			return "Utilities";
		default:
			return null;
		}
	}	
}