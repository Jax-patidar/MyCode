/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import javax.persistence.Embeddable;

@Embeddable
public class APP_IN_UTILC_Id implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_IN_UTILC";

	private String app_num;
	private Integer indv_seq_num;
	private Integer seq_num;
	private String src_app_ind;

	public APP_IN_UTILC_Id() {
		super();
	}

	public APP_IN_UTILC_Id(String app_num, Integer indv_seq_num, Integer seq_num, String src_app_ind) {
		super();
		this.app_num = app_num;
		this.indv_seq_num = indv_seq_num;
		this.seq_num = seq_num;
		this.src_app_ind = src_app_ind;
	}

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return app_num;
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_num = app_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * returns the PACKAGE name.
	 */
	public String getPackage() {
		return PACKAGE;
	}

	/**
	 * returns the string value of cargo.
	 */
	public String inspectCargo() {
		return new StringBuilder().append("APP_IN_UTILC: ").append("app_num=").append(app_num).append("indv_seq_num=")
				.append(indv_seq_num).append("seq_num=").append(seq_num).append("src_app_ind=").append(src_app_ind)
				.toString();
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((app_num == null) ? 0 : app_num.trim().hashCode());
		result = (prime * result) + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = (prime * result) + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = (prime * result) + ((src_app_ind == null) ? 0 : src_app_ind.trim().hashCode());
		return result;
	}

	
}