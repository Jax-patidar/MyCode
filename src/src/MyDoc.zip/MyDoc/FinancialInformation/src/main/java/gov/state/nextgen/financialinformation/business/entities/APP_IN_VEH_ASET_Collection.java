/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class acts as a wrapper for one or many cargos of APP_IN_VEH_ASET
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Tue Feb 13 10:24:12 CST 2007 Modified By: Modified on: PCR#
 */
public class APP_IN_VEH_ASET_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.financialinformation.business.entities.APP_IN_VEH_ASET";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_VEH_ASET_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_VEH_ASET_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_VEH_ASET_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_VEH_ASET_Cargo[] getResults() {
		final APP_IN_VEH_ASET_Cargo[] cbArray = new APP_IN_VEH_ASET_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_VEH_ASET_Cargo getCargo(final int idx) {
		return (APP_IN_VEH_ASET_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_VEH_ASET_Cargo[] cloneResults() {
		final APP_IN_VEH_ASET_Cargo[] rescargo = new APP_IN_VEH_ASET_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_VEH_ASET_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_VEH_ASET_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setEcp_id(cargo.getEcp_id());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setSeq_num(cargo.getSeq_num());
			rescargo[i].setJnt_own_resp(cargo.getJnt_own_resp());
			rescargo[i].setLic_plate_txt(cargo.getLic_plate_txt());
			rescargo[i].setLic_sta_cd(cargo.getLic_sta_cd());
			rescargo[i].setMv_fmv_amt(cargo.getMv_fmv_amt());
			rescargo[i].setMv_fmv_amt_ind(cargo.getMv_fmv_amt_ind());
			rescargo[i].setMv_make_txt(cargo.getMv_make_txt());
			rescargo[i].setMv_modl_txt(cargo.getMv_modl_txt());
			rescargo[i].setMv_owe_amt(cargo.getMv_owe_amt());
			rescargo[i].setMv_owe_amt_ind(cargo.getMv_owe_amt_ind());
			rescargo[i].setMv_rgst_rqr_sw(cargo.getMv_rgst_rqr_sw());
			rescargo[i].setMv_yr(cargo.getMv_yr());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setVeh_aset_typ(cargo.getVeh_aset_typ());
			// new variables for EDSP
			rescargo[i].setAsset_end_dt(cargo.getAsset_end_dt());
			rescargo[i].setMotor_vehicle_description(cargo.getMotor_vehicle_description());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setVehicle_acquired_dt(cargo.getVehicle_acquired_dt());
			// new variables EDSP ends
			rescargo[i].setChg_eff_dt(cargo.getChg_eff_dt());
			rescargo[i].setMv_use_1_cd(cargo.getMv_use_1_cd());
			rescargo[i].setMv_use_2_cd(cargo.getMv_use_2_cd());
			rescargo[i].setMv_use_3_cd(cargo.getMv_use_3_cd());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
			rescargo[i].setChg_dt(cargo.getChg_dt());
			// for new columns
			rescargo[i].setAdapt_record_id(cargo.getAdapt_record_id());
			rescargo[i].setVeh_brw_ind(cargo.getVeh_brw_ind());
			rescargo[i].setVeh_find_value(cargo.getVeh_find_value());
			rescargo[i].setVeh_gift_how(cargo.getVeh_gift_how());
			rescargo[i].setVeh_gift_ind(cargo.getVeh_gift_ind());
			rescargo[i].setVeh_used_by(cargo.getVeh_used_by());
			rescargo[i].setHow_it_is_used(cargo.getHow_it_is_used());
			rescargo[i].setLeased_ind(cargo.getLeased_ind());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_VEH_ASET_Cargo[]) {
			final APP_IN_VEH_ASET_Cargo[] cbArray = (APP_IN_VEH_ASET_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}