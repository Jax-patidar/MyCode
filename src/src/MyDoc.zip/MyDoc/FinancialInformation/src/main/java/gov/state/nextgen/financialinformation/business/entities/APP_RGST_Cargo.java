package gov.state.nextgen.financialinformation.business.entities;


import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;


public class APP_RGST_Cargo extends AbstractCargo implements Serializable{

	private static final long serialVersionUID = 6129564707039643275L;
	
	@Id
	private String app_num;
	
	@Id
	private String src_app_ind;
	
	private String alt_city_adr;
	private String alt_l2_adr;
	private String alt_st_adr;
	private String alt_sta_adr;
	private String alt_zip_adr;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date chg_eff_dt;
	
	private String cnty_num;
	private String hless_sw;
	private String hshl_cell_phn_num;
	private String hshl_city_adr;
	private String hshl_email_adr;
	private String hshl_home_phn_num;
	private Integer hshl_indv_ct;
	private String hshl_l1_adr;
	private String hshl_l2_adr;
	private String hshl_sta_adr;
	private String hshl_work_phn_num;
	private String hshl_zip_adr;
	private String lang_cd;
	private String msg_phn_extn_num;
	private String msg_phn_num;
	private String phn_num_typ;
	private Integer pref_cntc_ind;
	private String pref_cntc_tm_txt;
	private Integer rec_cplt_ind;
	private String work_phn_extn_num;
	private Integer days_at_address_num;
	private String ebt_card_resp;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date home_addr_chg_begin_dt;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date mail_addr_chg_begin_dt;
	
	private String other_assistance_sw;
	private String hshl_apt_num;
	private String alt_apt_num;
	private String alt_l1_adr;
	private String chld_tanf_rcv_ind;
	private String living_arrangement_cd;
	private String assigned_cnty_num;
	private String hshl_home_phn_extn_num;
	private String hshl_past_addr_ind;
	private String living_plcd_govt_agency_ind;
	private String past_county_cd;
	private String past_state_cd;
	private String pref_cont_method_cd;
	private String pref_cont_time_cd;
	private String pref_deaf_cont_method_cd;
	private String pub_hsa_rcv_pay_own_bill_ind;
	private String house_rent_assist_type;
	private String house_liheap_rcv_ind;
	private String app_typ;
	private String ecp_id;
	private String ecp_id_mail;
	private String alt_addr_zip4;
	private String hshl_addr_zip4;
	
	@JsonFormat(pattern = "MM/dd/yyyy")
	private Date chg_dt;
	
	private String wic_clnc_cnty;
	private String wic_clnc_cd;
	private String wic_dsclsr;
	private String is_cc_renewal;
	private String caps_id;
	public String getApp_num() {
		return app_num;
	}
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getAlt_city_adr() {
		return alt_city_adr;
	}
	public void setAlt_city_adr(String alt_city_adr) {
		this.alt_city_adr = alt_city_adr;
	}
	public String getAlt_l2_adr() {
		return alt_l2_adr;
	}
	public void setAlt_l2_adr(String alt_l2_adr) {
		this.alt_l2_adr = alt_l2_adr;
	}
	public String getAlt_st_adr() {
		return alt_st_adr;
	}
	public void setAlt_st_adr(String alt_st_adr) {
		this.alt_st_adr = alt_st_adr;
	}
	public String getAlt_sta_adr() {
		return alt_sta_adr;
	}
	public void setAlt_sta_adr(String alt_sta_adr) {
		this.alt_sta_adr = alt_sta_adr;
	}
	public String getAlt_zip_adr() {
		return alt_zip_adr;
	}
	public void setAlt_zip_adr(String alt_zip_adr) {
		this.alt_zip_adr = alt_zip_adr;
	}
	public Date getChg_eff_dt() {
		return chg_eff_dt;
	}
	public void setChg_eff_dt(Date chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}
	public String getCnty_num() {
		return cnty_num;
	}
	public void setCnty_num(String cnty_num) {
		this.cnty_num = cnty_num;
	}
	public String getHless_sw() {
		return hless_sw;
	}
	public void setHless_sw(String hless_sw) {
		this.hless_sw = hless_sw;
	}
	public String getHshl_cell_phn_num() {
		return hshl_cell_phn_num;
	}
	public void setHshl_cell_phn_num(String hshl_cell_phn_num) {
		this.hshl_cell_phn_num = hshl_cell_phn_num;
	}
	public String getHshl_city_adr() {
		return hshl_city_adr;
	}
	public void setHshl_city_adr(String hshl_city_adr) {
		this.hshl_city_adr = hshl_city_adr;
	}
	public String getHshl_email_adr() {
		return hshl_email_adr;
	}
	public void setHshl_email_adr(String hshl_email_adr) {
		this.hshl_email_adr = hshl_email_adr;
	}
	public String getHshl_home_phn_num() {
		return hshl_home_phn_num;
	}
	public void setHshl_home_phn_num(String hshl_home_phn_num) {
		this.hshl_home_phn_num = hshl_home_phn_num;
	}
	public Integer getHshl_indv_ct() {
		return hshl_indv_ct;
	}
	public void setHshl_indv_ct(Integer hshl_indv_ct) {
		this.hshl_indv_ct = hshl_indv_ct;
	}
	public String getHshl_l1_adr() {
		return hshl_l1_adr;
	}
	public void setHshl_l1_adr(String hshl_l1_adr) {
		this.hshl_l1_adr = hshl_l1_adr;
	}
	public String getHshl_l2_adr() {
		return hshl_l2_adr;
	}
	public void setHshl_l2_adr(String hshl_l2_adr) {
		this.hshl_l2_adr = hshl_l2_adr;
	}
	public String getHshl_sta_adr() {
		return hshl_sta_adr;
	}
	public void setHshl_sta_adr(String hshl_sta_adr) {
		this.hshl_sta_adr = hshl_sta_adr;
	}
	public String getHshl_work_phn_num() {
		return hshl_work_phn_num;
	}
	public void setHshl_work_phn_num(String hshl_work_phn_num) {
		this.hshl_work_phn_num = hshl_work_phn_num;
	}
	public String getHshl_zip_adr() {
		return hshl_zip_adr;
	}
	public void setHshl_zip_adr(String hshl_zip_adr) {
		this.hshl_zip_adr = hshl_zip_adr;
	}
	public String getLang_cd() {
		return lang_cd;
	}
	public void setLang_cd(String lang_cd) {
		this.lang_cd = lang_cd;
	}
	public String getMsg_phn_extn_num() {
		return msg_phn_extn_num;
	}
	public void setMsg_phn_extn_num(String msg_phn_extn_num) {
		this.msg_phn_extn_num = msg_phn_extn_num;
	}
	public String getMsg_phn_num() {
		return msg_phn_num;
	}
	public void setMsg_phn_num(String msg_phn_num) {
		this.msg_phn_num = msg_phn_num;
	}
	public String getPhn_num_typ() {
		return phn_num_typ;
	}
	public void setPhn_num_typ(String phn_num_typ) {
		this.phn_num_typ = phn_num_typ;
	}
	public Integer getPref_cntc_ind() {
		return pref_cntc_ind;
	}
	public void setPref_cntc_ind(Integer pref_cntc_ind) {
		this.pref_cntc_ind = pref_cntc_ind;
	}
	public String getPref_cntc_tm_txt() {
		return pref_cntc_tm_txt;
	}
	public void setPref_cntc_tm_txt(String pref_cntc_tm_txt) {
		this.pref_cntc_tm_txt = pref_cntc_tm_txt;
	}
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getWork_phn_extn_num() {
		return work_phn_extn_num;
	}
	public void setWork_phn_extn_num(String work_phn_extn_num) {
		this.work_phn_extn_num = work_phn_extn_num;
	}
	public Integer getDays_at_address_num() {
		return days_at_address_num;
	}
	public void setDays_at_address_num(Integer days_at_address_num) {
		this.days_at_address_num = days_at_address_num;
	}
	public String getEbt_card_resp() {
		return ebt_card_resp;
	}
	public void setEbt_card_resp(String ebt_card_resp) {
		this.ebt_card_resp = ebt_card_resp;
	}
	public Date getHome_addr_chg_begin_dt() {
		return home_addr_chg_begin_dt;
	}
	public void setHome_addr_chg_begin_dt(Date home_addr_chg_begin_dt) {
		this.home_addr_chg_begin_dt = home_addr_chg_begin_dt;
	}
	public Date getMail_addr_chg_begin_dt() {
		return mail_addr_chg_begin_dt;
	}
	public void setMail_addr_chg_begin_dt(Date mail_addr_chg_begin_dt) {
		this.mail_addr_chg_begin_dt = mail_addr_chg_begin_dt;
	}
	public String getOther_assistance_sw() {
		return other_assistance_sw;
	}
	public void setOther_assistance_sw(String other_assistance_sw) {
		this.other_assistance_sw = other_assistance_sw;
	}
	public String getHshl_apt_num() {
		return hshl_apt_num;
	}
	public void setHshl_apt_num(String hshl_apt_num) {
		this.hshl_apt_num = hshl_apt_num;
	}
	public String getAlt_apt_num() {
		return alt_apt_num;
	}
	public void setAlt_apt_num(String alt_apt_num) {
		this.alt_apt_num = alt_apt_num;
	}
	public String getChld_tanf_rcv_ind() {
		return chld_tanf_rcv_ind;
	}
	public void setChld_tanf_rcv_ind(String chld_tanf_rcv_ind) {
		this.chld_tanf_rcv_ind = chld_tanf_rcv_ind;
	}
	public String getLiving_arrangement_cd() {
		return living_arrangement_cd;
	}
	public void setLiving_arrangement_cd(String living_arrangement_cd) {
		this.living_arrangement_cd = living_arrangement_cd;
	}
	public String getAssigned_cnty_num() {
		return assigned_cnty_num;
	}
	public void setAssigned_cnty_num(String assigned_cnty_num) {
		this.assigned_cnty_num = assigned_cnty_num;
	}
	public String getHshl_home_phn_extn_num() {
		return hshl_home_phn_extn_num;
	}
	public void setHshl_home_phn_extn_num(String hshl_home_phn_extn_num) {
		this.hshl_home_phn_extn_num = hshl_home_phn_extn_num;
	}
	public String getHshl_past_addr_ind() {
		return hshl_past_addr_ind;
	}
	public void setHshl_past_addr_ind(String hshl_past_addr_ind) {
		this.hshl_past_addr_ind = hshl_past_addr_ind;
	}
	public String getLiving_plcd_govt_agency_ind() {
		return living_plcd_govt_agency_ind;
	}
	public void setLiving_plcd_govt_agency_ind(String living_plcd_govt_agency_ind) {
		this.living_plcd_govt_agency_ind = living_plcd_govt_agency_ind;
	}
	public String getPast_county_cd() {
		return past_county_cd;
	}
	public void setPast_county_cd(String past_county_cd) {
		this.past_county_cd = past_county_cd;
	}
	public String getPast_state_cd() {
		return past_state_cd;
	}
	public void setPast_state_cd(String past_state_cd) {
		this.past_state_cd = past_state_cd;
	}
	public String getPref_cont_method_cd() {
		return pref_cont_method_cd;
	}
	public void setPref_cont_method_cd(String pref_cont_method_cd) {
		this.pref_cont_method_cd = pref_cont_method_cd;
	}
	public String getPref_cont_time_cd() {
		return pref_cont_time_cd;
	}
	public void setPref_cont_time_cd(String pref_cont_time_cd) {
		this.pref_cont_time_cd = pref_cont_time_cd;
	}
	public String getPref_deaf_cont_method_cd() {
		return pref_deaf_cont_method_cd;
	}
	public void setPref_deaf_cont_method_cd(String pref_deaf_cont_method_cd) {
		this.pref_deaf_cont_method_cd = pref_deaf_cont_method_cd;
	}
	public String getPub_hsa_rcv_pay_own_bill_ind() {
		return pub_hsa_rcv_pay_own_bill_ind;
	}
	public void setPub_hsa_rcv_pay_own_bill_ind(String pub_hsa_rcv_pay_own_bill_ind) {
		this.pub_hsa_rcv_pay_own_bill_ind = pub_hsa_rcv_pay_own_bill_ind;
	}
	public String getHouse_rent_assist_type() {
		return house_rent_assist_type;
	}
	public void setHouse_rent_assist_type(String house_rent_assist_type) {
		this.house_rent_assist_type = house_rent_assist_type;
	}
	public String getHouse_liheap_rcv_ind() {
		return house_liheap_rcv_ind;
	}
	public void setHouse_liheap_rcv_ind(String house_liheap_rcv_ind) {
		this.house_liheap_rcv_ind = house_liheap_rcv_ind;
	}
	public String getApp_typ() {
		return app_typ;
	}
	public void setApp_typ(String app_typ) {
		this.app_typ = app_typ;
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public String getEcp_id_mail() {
		return ecp_id_mail;
	}
	public void setEcp_id_mail(String ecp_id_mail) {
		this.ecp_id_mail = ecp_id_mail;
	}
	public String getAlt_addr_zip4() {
		return alt_addr_zip4;
	}
	public void setAlt_addr_zip4(String alt_addr_zip4) {
		this.alt_addr_zip4 = alt_addr_zip4;
	}
	public String getHshl_addr_zip4() {
		return hshl_addr_zip4;
	}
	public void setHshl_addr_zip4(String hshl_addr_zip4) {
		this.hshl_addr_zip4 = hshl_addr_zip4;
	}
	public Date getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(Date chg_dt) {
		this.chg_dt = chg_dt;
	}
	public String getWic_clnc_cnty() {
		return wic_clnc_cnty;
	}
	public void setWic_clnc_cnty(String wic_clnc_cnty) {
		this.wic_clnc_cnty = wic_clnc_cnty;
	}
	public String getWic_clnc_cd() {
		return wic_clnc_cd;
	}
	public void setWic_clnc_cd(String wic_clnc_cd) {
		this.wic_clnc_cd = wic_clnc_cd;
	}
	public String getWic_dsclsr() {
		return wic_dsclsr;
	}
	public void setWic_dsclsr(String wic_dsclsr) {
		this.wic_dsclsr = wic_dsclsr;
	}
	public String getIs_cc_renewal() {
		return is_cc_renewal;
	}
	public void setIs_cc_renewal(String is_cc_renewal) {
		this.is_cc_renewal = is_cc_renewal;
	}
	public String getCaps_id() {
		return caps_id;
	}
	public void setCaps_id(String caps_id) {
		this.caps_id = caps_id;
	}
	public String getAlt_l1_adr() {
		return alt_l1_adr;
	}
	public void setAlt_l1_adr(String alt_l1_adr) {
		this.alt_l1_adr = alt_l1_adr;
	}
		
	

}
