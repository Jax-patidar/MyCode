package gov.state.nextgen.financialinformation.business.rules;

import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_A_WAGE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_A_WAGE_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppInEmplHealthRepository;


@Service("WagesBO")
public class WagesBO extends AbstractBO {
	
	private AppInEmplHealthRepository cpAppInEmplRepository;

	public APP_IN_EMPL_A_WAGE_Collection loadDetails(final String appNum, final Integer indv_seq_num, final Integer seq_num) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "WagesBO.loadDetails() - START");
		try {
			final APP_IN_EMPL_A_WAGE_Collection appInEmplWageColl = new APP_IN_EMPL_A_WAGE_Collection();

			
			if(appNum != null && indv_seq_num != null && seq_num != null) {
                
				final APP_IN_EMPL_A_WAGE_Cargo[] appInEmplWageCargoArray= cpAppInEmplRepository.loadDetails1(appNum, indv_seq_num, seq_num);
				appInEmplWageColl.setResults(appInEmplWageCargoArray);
    			}
			
			 FwLogger.log(this.getClass(), FwLogger.Level.INFO,
	                    "WagesBO.loadDetails() - END" + (System.currentTimeMillis() - startTime)
	                    + AppConstants.SPACE + AppConstants.MILLISECONDS);

			return appInEmplWageColl;
		} catch (final Exception e) {
			throw e;
		}
	
	}

	public void storeDetails(APP_IN_EMPL_A_WAGE_Collection updatedWageColl) {
		// TODO Auto-generated method stub
		
	}


}


