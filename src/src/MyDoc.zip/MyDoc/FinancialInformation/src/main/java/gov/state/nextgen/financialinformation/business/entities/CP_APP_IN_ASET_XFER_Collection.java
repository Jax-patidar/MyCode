package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class acts as a wrapper for one or many cargos of CP_APP_IN_ASET_XFER
 *
 * @author Deloitte
 * Creation Date Modified By: Modified on: PCR#
 */
public class CP_APP_IN_ASET_XFER_Collection extends AbstractCollection {


	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.workerPortalIntergration.business.entities.CP_APP_IN_ASET_XFER";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CP_APP_IN_ASET_XFER_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CP_APP_IN_ASET_XFER_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CP_APP_IN_ASET_XFER_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CP_APP_IN_ASET_XFER_Cargo[] getResults() {
		final CP_APP_IN_ASET_XFER_Cargo[] cbArray = new CP_APP_IN_ASET_XFER_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CP_APP_IN_ASET_XFER_Cargo getCargo(final int idx) {
		return (CP_APP_IN_ASET_XFER_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public CP_APP_IN_ASET_XFER_Cargo[] cloneResults() {
		final CP_APP_IN_ASET_XFER_Cargo[] rescargo = new CP_APP_IN_ASET_XFER_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_APP_IN_ASET_XFER_Cargo cargo = getCargo(i);
			rescargo[i] = new CP_APP_IN_ASET_XFER_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setAsset_seq_num(cargo.getAsset_seq_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setAsset_acq_dt(cargo.getAsset_acq_dt());
			rescargo[i].setAsset_type(cargo.getAsset_type());
			rescargo[i].setAsset_val_amt(cargo.getAsset_val_amt());
			rescargo[i].setAsset_xfer_amt(cargo.getAsset_xfer_amt());
			rescargo[i].setAsset_xfer_dt(cargo.getAsset_xfer_dt());
			rescargo[i].setAsset_xfer_rsn_cd(cargo.getAsset_xfer_rsn_cd());
			rescargo[i].setFirst_name(cargo.getFirst_name());
			rescargo[i].setLast_name(cargo.getLast_name());
			rescargo[i].setLast_name(cargo.getSrc_app_ind());
			rescargo[i].setEcp_id(cargo.getEcp_id());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
			rescargo[i].setChg_dt(cargo.getChg_dt());
			rescargo[i].setComments(cargo.getComments());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_APP_IN_ASET_XFER_Cargo[]) {
			final CP_APP_IN_ASET_XFER_Cargo[] cbArray = (CP_APP_IN_ASET_XFER_Cargo[]) obj;
			setResults(cbArray);
		}
	}


}
