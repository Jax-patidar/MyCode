package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RedetMCExpensesReviewDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String expenseType;

	private List<RedetMCExpensesIndvDetails_Cargo> indvDetails;

	public String getExpenseType() {
		return expenseType;
	}

	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}

	public List<RedetMCExpensesIndvDetails_Cargo> getIndvDetails() {
		return indvDetails;
	}

	public void setIndvDetails(List<RedetMCExpensesIndvDetails_Cargo> indvDetails) {
		this.indvDetails = indvDetails;
	}

}
