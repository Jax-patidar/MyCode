/*
 *
 */
package gov.state.nextgen.financialinformation.business.rules;

import java.util.Objects;

import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_BEF_TAX_DED_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_BEF_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.CpAppInBefTaxDedRepository;

@Service("ABBeforeTaxDeductionBO")
public class ABBeforeTaxDeductionBO extends AbstractBO {

	private CpAppInBefTaxDedRepository appInBefTaxDedRepository;

	public CP_APP_IN_BEF_TAX_DED_Collection loadIndividualBeforeTaxDetails(final String appNumber,
			final Integer indvSeqNum, final Integer seqNum) {


		FwLogger.log(this.getClass(), Level.INFO, "ABBeforeTaxDeductionBO.loadIndividualBeforeTaxDetails() - START");

		try {
			final CP_APP_IN_BEF_TAX_DED_Collection appInColl = appInBefTaxDedRepository
					.loadIndividualBeforeTaxDetails(appNumber, indvSeqNum, seqNum);


			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	@SuppressWarnings("unchecked")
	public void storeBeforeTaxDetails(final CP_APP_IN_BEF_TAX_DED_Collection appInColl) {


		FwLogger.log(this.getClass(), Level.INFO, "ABBeforeTaxDeductionBO.storeBeforeTaxDetails() - START");

		try {
			if (!appInColl.isEmpty()) {

				appInBefTaxDedRepository.saveAll(appInColl);
			}
		} catch (final Exception e) {
			throw e;
		}

	}

	public CP_APP_IN_BEF_TAX_DED_Collection getBeforeTaxDeductionDetails(final String appNumber) {

		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseholdInformationSummaryBO.getBeforeTaxDeductionDetails() - START");
		try {
			final CP_APP_IN_BEF_TAX_DED_Collection appInBfrTxDedColl = appInBefTaxDedRepository
					.getBeforeTaxDeductionDetails(appNumber);

			return appInBfrTxDedColl;
		}  catch (final Exception e) {
			throw e;
		}
	}

	public void validateEraseChanges() {

		FwLogger.log(this.getClass(), Level.INFO, "ABBeforeTaxDeductionBO.validateEraseChanges() - START");
		try {
			FwLogger.log(this.getClass(), Level.INFO, "ABBeforeTaxDeductionBO::validateEraseChanges:Start");

			final Object[] error = new Object[] { new FwMessageTextLabel("81089") };
			this.addMessageWithFieldValues("79011", error);
			FwLogger.log(this.getClass(), Level.INFO, "ABBeforeTaxDeductionBO::validateEraseChanges:End");
		} catch (final Exception e) {
			throw e;
		}
	}
@SuppressWarnings("squid:S3776")
	public FwMessageList validateBeforeTaxDedDetailsCheck(final CP_APP_IN_BEF_TAX_DED_Cargo appCargo) {
		FwMessageList fwMessageList = new FwMessageList();


		FwLogger.log(this.getClass(), Level.INFO, "ABBeforeTaxDeductionBO.validateBeforeTaxDedDetailsCheck() - START");
		try {

			addTaxDedDetailsMessages(appCargo.getMedical_ins(), fwMessageList, FinancialInfoConstants.MEDICAL_INSURANCE);
			addTaxDedDetailsMessages(appCargo.getDental_ins(), fwMessageList, FinancialInfoConstants.DENTAL_INSURANCE);
			addTaxDedDetailsMessages(appCargo.getVision_ins(), fwMessageList, FinancialInfoConstants.VISION_CARE_INSURANCE);
			addTaxDedDetailsMessages(appCargo.getFlexi_spend_account(), fwMessageList, FinancialInfoConstants.FLEXIBLE_SPENDING_ACCOUNT_HEALTH_AND_DEPENDENT_PLANS);
			addTaxDedDetailsMessages(appCargo.getDeferred_comp(), fwMessageList, FinancialInfoConstants.DEFERRED_COMPENSATION);
			addTaxDedDetailsMessages(appCargo.getPre_tax_life_ins(), fwMessageList, FinancialInfoConstants.PRE_TAX_LIFE_INSURANCE_PREMIUMS);
			addTaxDedDetailsMessages(appCargo.getOther_exp(), fwMessageList, FinancialInfoConstants.OTHER);
			
			// Medical Insurance
			if ( (null != appCargo.getMedical_ins() && (appCargo.getMedical_ins()) > 9999999.99)
					|| (appCargo.getMedical_ins()) < 0.0) {
				fwMessageList.addMessageToList(addMessageCode("99294"));
			}
			// Dental Insurance
			if ( (null != appCargo.getDental_ins() && (appCargo.getDental_ins()) > 9999999.99)
					|| (appCargo.getDental_ins()) < 0.0) {
				fwMessageList.addMessageToList(addMessageCode("99295"));
			}
			// Vision Care Insurance
			if ( (null != appCargo.getVision_ins() && (appCargo.getVision_ins()) > 9999999.99)
					|| (appCargo.getVision_ins()) < 0.0) {
				fwMessageList.addMessageToList(addMessageCode("99296"));
			}
			// Flexible Spending Account(Health and Dependent Plans)
			if ( (null != appCargo.getFlexi_spend_account() && (appCargo.getFlexi_spend_account()) > 9999999.99)
					|| (appCargo.getFlexi_spend_account()) < 0.0) {
				fwMessageList.addMessageToList(addMessageCode("99297"));
			}
			// Deferred Compensation
			if ( (null != appCargo.getDeferred_comp() && (appCargo.getDeferred_comp()) > 9999999.99)
					|| (appCargo.getDeferred_comp()) < 0.0) {
				fwMessageList.addMessageToList(addMessageCode("99298"));
			}
			// Pre-tax Life Insurance Premiums
			if ( (null != appCargo.getPre_tax_life_ins() && (appCargo.getPre_tax_life_ins()) > 9999999.99)
					|| (appCargo.getPre_tax_life_ins()) < 0.0) {
				fwMessageList.addMessageToList(addMessageCode("99299"));
			}
			// Other
			if ( (null != appCargo.getOther_exp() && (appCargo.getOther_exp()) > 9999999.99)
					|| (appCargo.getOther_exp()) < 0.0) {
				fwMessageList.addMessageToList(addMessageCode("99300"));
			}

			if (!fwMessageList.hasMessages() && ((appCargo.getDeferred_comp()) <= 0 && (appCargo.getDental_ins()) <= 0
						&& (appCargo.getFlexi_spend_account()) <= 0 && (appCargo.getMedical_ins()) <= 0
						&& (appCargo.getOther_exp()) <= 0 && (appCargo.getPre_tax_life_ins()) <= 0
						&& (appCargo.getVision_ins()) <= 0)) {
					fwMessageList.addMessageToList(addMessageCode("99224"));
				
			}
		}catch (final Exception e) {
			throw e;
		}
		return fwMessageList;
	}

	/**
	 * @param amount
	 * @param fwMessageList
	 * @param type 
	 */
	private void addTaxDedDetailsMessages(final Double amount, FwMessageList fwMessageList, String type) {
		try {
		if (Objects.nonNull(amount) && (amount > 9999999.99
				|| amount < 0.0)) {
			switch (type) {
			case FinancialInfoConstants.MEDICAL_INSURANCE:
				fwMessageList.addMessageToList(addMessageCode("99294"));
				break;
				
			case FinancialInfoConstants.DENTAL_INSURANCE:
				fwMessageList.addMessageToList(addMessageCode("99295"));
				break;
				
			case FinancialInfoConstants.VISION_CARE_INSURANCE:
				fwMessageList.addMessageToList(addMessageCode("99296"));
				break;
				
			case FinancialInfoConstants.FLEXIBLE_SPENDING_ACCOUNT_HEALTH_AND_DEPENDENT_PLANS:
				fwMessageList.addMessageToList(addMessageCode("99297"));
				break;
				
			case FinancialInfoConstants.DEFERRED_COMPENSATION:
				fwMessageList.addMessageToList(addMessageCode("99298"));
				break;
				
			case FinancialInfoConstants.PRE_TAX_LIFE_INSURANCE_PREMIUMS:
				fwMessageList.addMessageToList(addMessageCode("99299"));
				break;
				
			case FinancialInfoConstants.OTHER:
				fwMessageList.addMessageToList(addMessageCode("99300"));
				break;

			default:
				break;
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}
	
	

	public CP_APP_IN_BEF_TAX_DED_Collection loadBeforeTaxDetails(
			final String appNumber) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.DEBUG, "ABBeforeTaxDeductionBO.loadBeforeTaxDetails() - START");

		try {
			final CP_APP_IN_BEF_TAX_DED_Collection appInColl = appInBefTaxDedRepository.loadBeforeTaxDetails(appNumber);

			FwLogger.log(this.getClass(), Level.DEBUG,
					"ABBeforeTaxDeductionBO.loadBeforeTaxDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");

			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public CP_APP_IN_BEF_TAX_DED_Cargo splitCldOblgCargo(
			final CP_APP_IN_BEF_TAX_DED_Collection oblgInfoColl,
			final String recordIndicator) {

		FwLogger.log(this.getClass(), Level.INFO, "ABBeforeTaxDeductionBO.splitCldOblgCargo() - START");

		try {
			if (oblgInfoColl != null && !oblgInfoColl.isEmpty()) {
				final int oblginfoCollSize = oblgInfoColl.size();
				CP_APP_IN_BEF_TAX_DED_Cargo oblgInfoCargo = null;
				for (int i = 0; i < oblginfoCollSize; i++) {
					oblgInfoCargo = oblgInfoColl.getCargo(i);
					if (oblgInfoCargo.getSrc_app_ind().equals(recordIndicator)) {
						return oblgInfoCargo;
					}
				}

			}
			return null;

		}catch (final Exception e) {
			throw e;
		}
	}
	
	public CP_APP_IN_BEF_TAX_DED_Cargo settingDefaultValues(
			final CP_APP_IN_BEF_TAX_DED_Cargo cargo) {

		FwLogger.log(this.getClass(), Level.INFO, "ABBeforeTaxDeductionBO.settingDefaultValues() - START");
		try {
			return cargo;
		}catch (final Exception e) {
			throw e;
		}
	}
	
	
	public int getMaxIncBefTaxSeqNumber(final String appNumber, final Integer indvSeqNum) {
		FwLogger.log(this.getClass(), Level.INFO, "ABBeforeTaxDeductionBO.getMaxIncBefTaxSeqNumber() - START");
		int maxSeqNum = 0;
		try {
			
			Integer maxSeq = appInBefTaxDedRepository.getMaxIncBefTaxSeqNumber(appNumber, indvSeqNum);
			
			if (maxSeq !=null) {
				maxSeqNum = maxSeq;
			}
			
			return maxSeqNum;
			
		} catch (final Exception e) {
			throw e;
		}

	}
}