package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the cp_app_in_empl_pay_stub database table.
 * 
 */
@Embeddable
public class CpAppInEmplPayStubPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="app_num")
	private Integer app_number;

	@Column(name="indv_seq_num")
	private Integer indvSeqNum;

	@Column(name="empl_seq_num")
	private Integer emplSeqNum;

	@Column(name="pay_stub_seq_num")
	private Integer payStubSeqNum;

	public CpAppInEmplPayStubPK() {
		//Will use bean pattern
	}
	
	

	public Integer getApp_number() {
		return app_number;
	}



	public void setApp_number(Integer app_number) {
		this.app_number = app_number;
	}



	public double getIndvSeqNum() {
		return this.indvSeqNum;
	}
	public void setIndvSeqNum(Integer indvSeqNum) {
		this.indvSeqNum = indvSeqNum;
	}
	public Integer getEmplSeqNum() {
		return this.emplSeqNum;
	}
	public void setEmplSeqNum(Integer emplSeqNum) {
		this.emplSeqNum = emplSeqNum;
	}
	public Integer getPayStubSeqNum() {
		return this.payStubSeqNum;
	}
	public void setPayStubSeqNum(Integer payStubSeqNum) {
		this.payStubSeqNum = payStubSeqNum;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if(other == null) {
			return false;
		}
		if (other.getClass() != this.getClass()) {
			return false;
		}
		CpAppInEmplPayStubPK castOther = (CpAppInEmplPayStubPK)other;
		return 
			this.app_number.equals(castOther.app_number)
			&& (this.indvSeqNum == castOther.indvSeqNum)
			&& (this.emplSeqNum == castOther.emplSeqNum)
			&& (this.payStubSeqNum == castOther.payStubSeqNum);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.app_number.hashCode();
		hash = hash * prime + ((int) (java.lang.Double.doubleToLongBits(this.indvSeqNum) ^ (java.lang.Double.doubleToLongBits(this.indvSeqNum) >>> 32)));
		hash = hash * prime + ((int) (java.lang.Double.doubleToLongBits(this.emplSeqNum) ^ (java.lang.Double.doubleToLongBits(this.emplSeqNum) >>> 32)));
		hash = hash * prime + ((int) (java.lang.Double.doubleToLongBits(this.payStubSeqNum) ^ (java.lang.Double.doubleToLongBits(this.payStubSeqNum) >>> 32)));
		
		return hash;
	}
}