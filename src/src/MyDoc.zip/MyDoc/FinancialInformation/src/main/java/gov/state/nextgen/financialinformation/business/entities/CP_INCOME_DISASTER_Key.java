package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

public class CP_INCOME_DISASTER_Key implements Serializable {
	
	private static final long serialVersionUID = -98351550904193723L;
	
	private Integer app_number;
	
	
	public CP_INCOME_DISASTER_Key() {
		
	}

	public CP_INCOME_DISASTER_Key(Integer app_num) {
		super();
		this.app_number = app_num;
		
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CP_INCOME_DISASTER_Key other = (CP_INCOME_DISASTER_Key) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		
		return true;
	}
	
	

}
