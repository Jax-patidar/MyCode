/**
 * 
 */
package gov.state.nextgen.financialinformation.business.services;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_P_PROP_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_R_PROP_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_VEH_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_MED_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.rules.ABEmploymentBO;
import gov.state.nextgen.financialinformation.business.rules.ABJobIncomeBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherIncomeBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInHouRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInLqdAsetRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInPPropAssetRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInRealPropertyRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInVehAssetRepository;
import gov.state.nextgen.financialinformation.data.db2.CP_ABCHS_Repository;
import gov.state.nextgen.financialinformation.data.db2.CP_APP_IN_DEDUCTION_Repository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInIncomeTaxDedRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInMedBillsRepository;
import gov.state.nextgen.framework.business.model.UserDetails;

/**
 * @author swabehera
 *
 */

@Service("RedetMCFinanceSummaryService")
public class RedetMCFinanceSummaryServiceImpl implements FinancialServInterface{
	
	@Autowired
	private ABEmploymentBO employmentDetailsBO;
	
	@Autowired
	private ABJobIncomeBO abJobIncomeBO;
	
	@Autowired
	private ABOtherIncomeBO abOtherIncomeBO;
	
	@Autowired
	private AppInHouRepository appInHouRepository;

	@Autowired
	private CpAppInMedBillsRepository cpAppInMedBillsRepository;

	@Autowired
	private CP_APP_IN_DEDUCTION_Repository cpAppIndeductionRepository;

	@Autowired
	private CP_ABCHS_Repository careCostRepository;

	@Autowired
	private CpAppInIncomeTaxDedRepository cpAppInIncomeTaxDedRepository;
	
	@Autowired
	private AppInPPropAssetRepository appInPPropAssetRepository;
	
	@Autowired
	private AppInLqdAsetRepository appInLqdAsetRepository;
	
	@Autowired
	private AppInVehAssetRepository appInVehAssetRepository;
	
	@Autowired
	private AppInRealPropertyRepository appInRealPropertyRepository;
	
	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {

		switch (methodName) {
		case FinancialInfoConstants.LOAD_MC_FINANCE_DETAILS:
			this.loadRedetMCFinanceDetails(txnBean);
			break;
		default:
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"No Service called");
		}
	}

	private void loadRedetMCFinanceDetails(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "RedetMCFinanceSummaryServiceImpl.loadRedetMCFinanceDetails() - START");
		try {
			Map<String, Object> pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			
			/*
			 * Load Income Details
			 */
			
			APP_IN_EMPL_Collection incomeColl = employmentDetailsBO.getEmploymentDetailsByAppNum(appNum);
			APP_IN_SELFE_Collection selfEmpColl = abJobIncomeBO.getSelfEmploymentDetails(appNum);
			APP_IN_UEI_Collection appInUeiCollection = abOtherIncomeBO.loadOtherIncomesDetail(appNum);

			/*
			 * Load Expense Details
			 */
			
			APP_IN_HOU_BILLS_Collection housingExpenseColl = appInHouRepository.getHouseBillsCollection(Integer.parseInt(appNum));
			CP_APP_IN_DEDUCTION_Collection appInDeductionColl = cpAppIndeductionRepository
					.findByAppNum(Integer.parseInt(appNum));
			CP_APP_IN_MED_BILLS_Collection appInMedBillsColl = cpAppInMedBillsRepository
					.getDetails(Integer.parseInt(appNum));
			CP_ABCHS_Collection careCostColl = careCostRepository.loadCareCostDetails(Integer.parseInt(appNum));
			CP_APP_IN_INCOME_TAX_DED_Collection incomeTaxDedColl = cpAppInIncomeTaxDedRepository
					.loadIndividualIncomeTaxDedByAppNum(Integer.parseInt(appNum));
			
			/*
			 * Load Asset Details
			 */
			APP_IN_VEH_ASET_Collection appVehColl = appInVehAssetRepository.loadUseVehicleAssetDetails(Integer.parseInt(appNum));
			APP_IN_R_PROP_ASET_Collection appRPropColl = appInRealPropertyRepository.getRealPropertyByAppNum(Integer.parseInt(appNum));			
			APP_IN_P_PROP_ASET_Collection appPPropColl = appInPPropAssetRepository.getPPropByAppNum(Integer.parseInt(appNum));			
			APP_IN_LQD_ASET_Collection lqdAssetColl = appInLqdAsetRepository.loadLqdAssetDetails(Integer.parseInt(appNum));
			
			pageCollection.put(FinancialInfoConstants.APP_IN_EMPL_COLL, incomeColl);
			pageCollection.put(FinancialInfoConstants.APP_IN_SELFE_COLL, selfEmpColl);
			pageCollection.put(FinancialInfoConstants.APP_IN_UEI_COLL, appInUeiCollection);
			
			pageCollection.put(FinancialInfoConstants.CP_ABCHS_COLLECTION, careCostColl);
			pageCollection.put(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION, housingExpenseColl);
			pageCollection.put(FinancialInfoConstants.CP_APP_IN_MED_BILLS_COLLECTION, appInMedBillsColl);
			pageCollection.put(FinancialInfoConstants.CP_APP_IN_DEDUCTION_COLLECTION, appInDeductionColl);
			pageCollection.put(FinancialInfoConstants.CP_APP_IN_INCOME_TAX_DED_COLL, incomeTaxDedColl);
			
			pageCollection.put(FinancialInfoConstants.APP_IN_LQD_ASET_COLL, lqdAssetColl);
			pageCollection.put(FinancialInfoConstants.APP_IN_VEH_ASET_COLL, appVehColl);
			pageCollection.put(FinancialInfoConstants.APP_IN_R_PROP_ASET_COLL, appRPropColl);
			pageCollection.put(FinancialInfoConstants.APP_IN_P_PROP_ASET_COLL, appPPropColl);

			FwLogger.log(this.getClass(), Level.INFO,
					"RedetMCFinanceSummaryServiceImpl.loadRedetMCFinanceDetails()- End");

		} catch (final Exception e) {
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.LOAD_MC_FINANCE_DETAILS,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO,
				"RedetMCFinanceSummaryServiceImpl.loadRedetMCFinanceDetails() - End , Time Taken : "
						+ (System.currentTimeMillis() - startTime));
	}

}
