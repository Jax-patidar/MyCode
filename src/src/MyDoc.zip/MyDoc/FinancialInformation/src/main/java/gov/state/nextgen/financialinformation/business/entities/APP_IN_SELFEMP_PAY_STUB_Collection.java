/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;


public class APP_IN_SELFEMP_PAY_STUB_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.APP_IN_SELFEMP_PAY_STUB";

	
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_SELFEMP_PAY_STUB_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_SELFEMP_PAY_STUB_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_SELFEMP_PAY_STUB_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_SELFEMP_PAY_STUB_Cargo[] getResults() {
		final APP_IN_SELFEMP_PAY_STUB_Cargo[] cbArray = new APP_IN_SELFEMP_PAY_STUB_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_SELFEMP_PAY_STUB_Cargo getCargo(final int idx) {
		return (APP_IN_SELFEMP_PAY_STUB_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_SELFEMP_PAY_STUB_Cargo[] cloneResults() {
		final APP_IN_SELFEMP_PAY_STUB_Cargo[] rescargo = new APP_IN_SELFEMP_PAY_STUB_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_SELFEMP_PAY_STUB_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_SELFEMP_PAY_STUB_Cargo();
			rescargo[i].setAppNum(cargo.getAppNum());
			rescargo[i].setSeqNum(cargo.getSeqNum());
			rescargo[i].setIndvSeqNum(cargo.getIndvSeqNum());
			rescargo[i].setPayStubSeqNum(cargo.getPayStubSeqNum());
			rescargo[i].setPaymentAmt(cargo.getPaymentAmt());
			rescargo[i].setPaymentDt(cargo.getPaymentDt());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_SELFEMP_PAY_STUB_Cargo[]) {
			final APP_IN_SELFEMP_PAY_STUB_Cargo[] cbArray = (APP_IN_SELFEMP_PAY_STUB_Cargo[]) obj;
			setResults(cbArray);
		}
	}

	public APP_IN_SELFEMP_PAY_STUB_Cargo getResult(final int idx) {
		return (APP_IN_SELFEMP_PAY_STUB_Cargo) get(idx);
	}
}