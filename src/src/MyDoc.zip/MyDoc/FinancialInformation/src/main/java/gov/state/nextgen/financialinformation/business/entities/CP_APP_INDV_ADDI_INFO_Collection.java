package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class contains the collection of entities of CP_APP_INDV_ADDI_INFO
 *
 * Created by @DeloitteUSI team Creation Date Mon Jan 25 11:34:07 IST 2021
 * 
 */

public class CP_APP_INDV_ADDI_INFO_Collection extends AbstractCollection {

	private static final long serialVersionUID = 2931702875253505718L;

	private static final String PACKAGE = "gov.state.nextgen.householddemographics.business.entities.CP_APP_INDV_ADDI_INFO";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CP_APP_INDV_ADDI_INFO_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CP_APP_INDV_ADDI_INFO_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CP_APP_INDV_ADDI_INFO_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CP_APP_INDV_ADDI_INFO_Cargo[] getResults() {
		final CP_APP_INDV_ADDI_INFO_Cargo[] cbArray = new CP_APP_INDV_ADDI_INFO_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CP_APP_INDV_ADDI_INFO_Cargo getCargo(final int idx) {
		return (CP_APP_INDV_ADDI_INFO_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public CP_APP_INDV_ADDI_INFO_Cargo[] cloneResults() {
		final CP_APP_INDV_ADDI_INFO_Cargo[] rescargo = new CP_APP_INDV_ADDI_INFO_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_APP_INDV_ADDI_INFO_Cargo cargo = getCargo(i);
			rescargo[i] = new CP_APP_INDV_ADDI_INFO_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setGross_income_less(cargo.getGross_income_less());
			rescargo[i].setCombined_gross_income(cargo.getCombined_gross_income());
			rescargo[i].setMig_farm_wrkr_resp(cargo.getMig_farm_wrkr_resp());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_APP_INDV_ADDI_INFO_Cargo[]) {
			final CP_APP_INDV_ADDI_INFO_Cargo[] cbArray = (CP_APP_INDV_ADDI_INFO_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}
