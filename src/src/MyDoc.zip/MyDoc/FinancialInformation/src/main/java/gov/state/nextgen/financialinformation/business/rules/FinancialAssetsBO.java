package gov.state.nextgen.financialinformation.business.rules;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.access.management.util.DateRoutine;
import gov.state.nextgen.financialinformation.business.entities.APP_HSHL_RLT_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_HSHL_RLT_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_VEH_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.INDIVIDUAL_Custom_Cargo;
import gov.state.nextgen.financialinformation.business.entities.INDIVIDUAL_Custom_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppInJntOwnRepository;



@Service("FinancialAssetsBO")
public class FinancialAssetsBO {

	
	
	
	private static String PRIMARY_PERSON = "PP";
	

	public static final String SPACE = " ";

	@Autowired
	private DateRoutine dateRoutine;

	@Autowired
	private IReferenceTableManager iref;


	
	@Autowired
	private AppInJntOwnRepository appInJntOwnRepository;

	private static Logger logger = LoggerFactory.getLogger(FinancialAssetsBO.class);

	private final Map<Object, Object> dropdownMap = new HashMap<Object, Object>();
	private final Map<Object, Object> relevantDropDownMap = new HashMap<Object, Object>();
	private final Map individualMap = new HashMap();

	/**
	 * Loads the Individuals information for the given APP_NUM
	 */
	public void loadPeopleHandler(final String aAppNum) {

		try {

			// Update indv map
			final INDIVIDUAL_Custom_Cargo[] individualCustomCargoArray = getAllIndividuals(aAppNum);
			for (int i = 0; i < individualCustomCargoArray.length; i++) {
				individualMap.put(individualCustomCargoArray[i].getIndv_seq_num(), individualCustomCargoArray[i]);
			}
			// Update dropdown map
			sortIndivAndUpdateDropDown();

		} catch (final FwException fe) {
			logger.error("Error occured in FinancialAssetsBO.loadPeopleHandler()");
			throw fe;
		}
	}

private INDIVIDUAL_Custom_Cargo[] getAllIndividuals(String aAppNum) {
	try {

		// get the app_indv information for the app_num
		final APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
		final APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
		appIndvCargo.setApp_num(aAppNum);
		appIndvCollection.addCargo(appIndvCargo);

		// Getting individuals in home only
		final INDIVIDUAL_Custom_Cargo[] individualCustomCargoArray = new INDIVIDUAL_Custom_Cargo[0];

		return individualCustomCargoArray;
	} catch (final FwException fe) {
		logger.error("Error occured in FinancialAssetsBO.getAllIndividuals()");
		throw fe;
	} 
}

	private void sortIndivAndUpdateDropDown() {
		INDIVIDUAL_Custom_Collection individualCustomCollection = new INDIVIDUAL_Custom_Collection();
		try {
		final Iterator iter = individualMap.keySet().iterator();
		while (iter.hasNext()) {
			individualCustomCollection.addCargo((INDIVIDUAL_Custom_Cargo) individualMap.get(iter.next()));
		}

		individualCustomCollection = sortIndividuals(individualCustomCollection);

		// update dropdown map
		updateDropDown(individualCustomCollection);
		} catch (final Exception e) {
			logger.error("Error occured in FinancialAssetsBO.sortIndivAndUpdateDropDown()");
			throw e;
		}
	}

	private void updateDropDown(INDIVIDUAL_Custom_Collection individualCustomCollection) {

		final List codeList = new ArrayList();
		final List descList = new ArrayList();
		final List relevantCodeList = new ArrayList();
		final List relevantDescList = new ArrayList();

		try {

			final int size = individualCustomCollection.size();
			for (int i = 0; i < size; i++) {
				final INDIVIDUAL_Custom_Cargo indivCustomCargo = (INDIVIDUAL_Custom_Cargo) individualCustomCollection
						.get(i);

				// Add code and desc for all individuals
				codeList.add(indivCustomCargo.getIndv_seq_num());
				descList.add(indivCustomCargo.getFst_nam());

				// Add code and desc for all relevant individuals
				if (Integer.parseInt(indivCustomCargo.getRlvn_ind()) == 1) {
					relevantCodeList.add(indivCustomCargo.getIndv_seq_num());
					relevantDescList.add(indivCustomCargo.getFst_nam());
				}
			}
			// Add code and desc for all individuals in dropdownMap
			dropdownMap.put(AppConstants.INDV_SEQUENCE_NUMBERS, codeList);
			dropdownMap.put(AppConstants.INDV_DESCRIPTIONS, descList);
			// Add code and desc for all relevant individuals in
			// relevantDropDownMap
			relevantDropDownMap.put(AppConstants.INDV_SEQUENCE_NUMBERS, relevantCodeList);
			relevantDropDownMap.put(AppConstants.INDV_DESCRIPTIONS, relevantDescList);
		} catch (final FwException fe) {
			logger.error("Error occured in FinancialAssetsBO.updateDropDown()");
			throw fe;
		}
	}

	public INDIVIDUAL_Custom_Collection sortIndividuals(INDIVIDUAL_Custom_Collection aIndividualCustomCollection) {
		return aIndividualCustomCollection; 
		}

	/**
	 * Returns all the individuals
	 */
	public INDIVIDUAL_Custom_Collection getAllIndividuals() {
		final INDIVIDUAL_Custom_Collection indvCustomCollection = new INDIVIDUAL_Custom_Collection();
		try {
		final Iterator iter = individualMap.keySet().iterator();
		while (iter.hasNext()) {
			indvCustomCollection.add(individualMap.get(iter.next()));
		}
		return indvCustomCollection;
		} catch (final Exception e) {
			logger.error("Error occured in FinancialAssetsBO.getAllIndividuals()");
			throw e;
		}
	}

	public INDIVIDUAL_Custom_Collection sortIndividualsByAge(
			final INDIVIDUAL_Custom_Collection individualCustomCollection) {
		
		return individualCustomCollection;
		}

	/**
	 * Returns an Individual for the given IndvSeqNum
	 */
	public INDIVIDUAL_Custom_Cargo getIndividual(final String aIndvSeqNum) {
		return (INDIVIDUAL_Custom_Cargo) individualMap.get(aIndvSeqNum);
	}

	/**
	 *
	 * @param appNumber
	 * @return
	 */
	public INDIVIDUAL_Custom_Collection getInAndOutOfHomeIndividuals(String appNumber) {
		try {
			Map individualMap = getHouseholdIndividuals(appNumber);

			final INDIVIDUAL_Custom_Collection indvCustomCollection = new INDIVIDUAL_Custom_Collection();
			// get the RLT_CD information for the app_num
			final APP_HSHL_RLT_Collection appHSHLCollection = new APP_HSHL_RLT_Collection();
			final APP_HSHL_RLT_Cargo appHSHLCargo = new APP_HSHL_RLT_Cargo();
			appHSHLCargo.setApp_num(appNumber);
			appHSHLCollection.addCargo(appHSHLCargo);
			List<APP_HSHL_RLT_Cargo> appHouseHoldRelationshipCargos = getAppHouseHoldRelationshipCargos();

			// get the app_indv information for the app_num
			final APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
			final APP_INDV_Cargo appIndvCargo = new APP_INDV_Cargo();
			appIndvCargo.setApp_num(appNumber);
			appIndvCollection.addCargo(appIndvCargo);

			List<APP_INDV_Cargo> appIndividualCargos = getAppIndividualCargo();

			List<INDIVIDUAL_Custom_Cargo> individual_custom_cargos = new ArrayList<INDIVIDUAL_Custom_Cargo>();
			for (APP_INDV_Cargo appIndividualCargo : appIndividualCargos) {
				INDIVIDUAL_Custom_Cargo individualCustomCargo = new INDIVIDUAL_Custom_Cargo();
				individualCustomCargo.setIndv_seq_num(String.valueOf(appIndividualCargo.getIndv_seq_num()));
				individualCustomCargo.setBrth_dt(String.valueOf(appIndividualCargo.getBrth_dt()));
				individualCustomCargo.setFst_nam(appIndividualCargo.getFst_nam().trim());
				individualCustomCargo.setLast_nam(appIndividualCargo.getLast_nam());
				individualCustomCargo.setMid_init(appIndividualCargo.getMid_init());
				individualCustomCargo.setRlvn_ind(String.valueOf(appIndividualCargo.getRlvn_ind()));
				individualCustomCargo.setSex_ind(appIndividualCargo.getSex_ind());
				individualCustomCargo.setIndv_age(dateRoutine.getAge(
						dateRoutine.getDateFromTimeStamp(String.valueOf(appIndividualCargo.getBrth_dt())),
						new java.sql.Date(new java.util.Date().getTime())));
				individualCustomCargo.setOut_of_home_ind(appIndividualCargo.getChld_out_home_resp());
				individualCustomCargo.setChld_trb_mbr_resp(appIndividualCargo.getChld_trb_mbr_resp());
				individualCustomCargo.setTrb_mbr_resp(appIndividualCargo.getTrb_mbr_resp());

				if (!FwConstants.YES.equals(appIndividualCargo.getPrim_prsn_sw())) {
					individualCustomCargo.setRlt_cd(getRelationCDForNonPP(appHouseHoldRelationshipCargos,
							individualCustomCargo.getIndv_seq_num(), individualCustomCargo.getSex_ind()));
				} else {
					individualCustomCargo.setRlt_cd(PRIMARY_PERSON);
				}
				individual_custom_cargos.add(individualCustomCargo);
			}
			indvCustomCollection.setResults(
					individual_custom_cargos.toArray(new INDIVIDUAL_Custom_Cargo[individual_custom_cargos.size()]));
			for (INDIVIDUAL_Custom_Cargo individual_custom_cargo : individual_custom_cargos) {
				individualMap.put(individual_custom_cargo.getIndv_seq_num(), individual_custom_cargo);
			}
			return indvCustomCollection;
		} catch (final FwException fe) {
			throw fe;
		}
		catch (final Exception e) {
			throw e;
		}
	}

	@Cacheable(value = "individuals", key = "appNum")
	public Map getHouseholdIndividuals(final String appNum) {
		Map individualMap = new HashMap();
		try {
			 //Update indv map
//			// Update dropdown map
			sortIndivAndUpdateDropDown(individualMap);
		} catch (final Exception fe) {
			logger.error(" Loading People Handler Failed ", fe.fillInStackTrace());
		}
		return individualMap;
	}

	/**
	 * Sorts Individuals and updates the dropdown map from the IndividualMap
	 */
	private void sortIndivAndUpdateDropDown(Map individualMap) {
		INDIVIDUAL_Custom_Collection individualCustomCollection = new INDIVIDUAL_Custom_Collection();
		try {
		final Iterator iter = individualMap.keySet().iterator();
		while (iter.hasNext()) {
			individualCustomCollection.addCargo((INDIVIDUAL_Custom_Cargo) individualMap.get(iter.next()));
		}


		// update dropdown map
		updateDropDown(individualCustomCollection);
		} catch (final Exception e) {
			logger.error("Error occured in FinancialAssetsBO.sortIndivAndUpdateDropDown()");
			throw e;
		}
	}

	/**
	 * Get App Household relationship cargos.
	 * 
	 * @param appNum - Application number picked up based on userId.
	 * @return APP_HSHL_RLT_Cargo[] - List of cargos
	 */
	private List<APP_HSHL_RLT_Cargo> getAppHouseHoldRelationshipCargos() {
		
		List<APP_HSHL_RLT_Cargo> appHshlRltCargoList = new ArrayList<>();
		return appHshlRltCargoList;
		
		
		
	}

	private List<APP_INDV_Cargo> getAppIndividualCargo() {
		
		
		List<APP_INDV_Cargo> appIndvCargoList = new ArrayList<>();
		return appIndvCargoList;
	}

	

	private String getRelationCDForNonPP(final List<APP_HSHL_RLT_Cargo> appHshlRltCargos, final String aIndvSeqNum,
			final String aGender) {

		try {
			for (APP_HSHL_RLT_Cargo app_hshl_rlt_cargo : appHshlRltCargos) {
				if (app_hshl_rlt_cargo.getRef_indv_seq_num().equals(aIndvSeqNum)) {
					if (AppConstants.SEX_IND_MALE.equals(aGender)) {
						// get reverse relation for the male
						return iref.getColumnValue("TREL", 69, app_hshl_rlt_cargo.getRlt_cd(), FwConstants.ENGLISH);
					} else {
						// get reverse relation for the female
						return iref.getColumnValue("TREL", 70, app_hshl_rlt_cargo.getRlt_cd(), FwConstants.ENGLISH);
					}
				} else if (app_hshl_rlt_cargo.getSrc_indv_seq_num().equals(aIndvSeqNum)) {
					return app_hshl_rlt_cargo.getRlt_cd();
				}
			}
			return SPACE;

		} catch (final Exception fe) {
			logger.error("Error occured in FinancialAssetsBO.getRelationCDForNonPP()");
			throw fe;
		}
	}

	/**
	 * Get App Household cargos.
	 * 
	 * @param householdRelationShip
	 * @return
	 */
	protected List<APP_HSHL_RLT_Cargo> getAppHouseholdRelationCargos(
			List<APP_HSHL_RLT_Cargo> householdRelationShip) {
		List<APP_HSHL_RLT_Cargo> app_hshl_rlt_cargos = new ArrayList<>();
		try {
		householdRelationShip.forEach(cp_app_hshl_rlt_cargo -> {
			APP_HSHL_RLT_Cargo cargo = new APP_HSHL_RLT_Cargo();
			cargo.setApp_num(cp_app_hshl_rlt_cargo.getApp_num());
			if (Objects.nonNull(cp_app_hshl_rlt_cargo.getChg_dt())) {
				cargo.setChg_dt(cp_app_hshl_rlt_cargo.getChg_dt().toString());
			}
			cargo.setRef_indv_seq_num(cp_app_hshl_rlt_cargo.getRef_indv_seq_num());
			cargo.setRlt_cd(cp_app_hshl_rlt_cargo.getRlt_cd());
			cargo.setSrc_indv_seq_num(cp_app_hshl_rlt_cargo.getSrc_indv_seq_num());
			app_hshl_rlt_cargos.add(cargo);

		});
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

		return app_hshl_rlt_cargos;
		}

	public INDIVIDUAL_Custom_Collection getRelevantIndividuals() {
		final INDIVIDUAL_Custom_Collection indvCustomCollection = new INDIVIDUAL_Custom_Collection();
		try {
		final Iterator iter = individualMap.keySet().iterator();
		while (iter.hasNext()) {
			final INDIVIDUAL_Custom_Cargo indvCargo = (INDIVIDUAL_Custom_Cargo) individualMap.get(iter.next());
			if (Integer.parseInt(indvCargo.getRlvn_ind()) == 1) {
				indvCustomCollection.add(indvCargo);
			}
		}
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
		return indvCustomCollection;
	}

	public String getFirstName() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void storeJointOwnerDetails(APP_IN_JNT_OWN_Collection appInJntOwnNewColl) {

		try {
			if (!appInJntOwnNewColl.isEmpty()) {
				int size = appInJntOwnNewColl.size();
				APP_IN_JNT_OWN_Cargo appInJntOwnCargo = null;
				final APP_IN_JNT_OWN_Collection deleteColl = new APP_IN_JNT_OWN_Collection();
				for (int i = 0; i < size; i++) {
					appInJntOwnCargo = appInJntOwnNewColl.getCargo(i);
					if (FwConstants.ROWACTION_DELETE.equals(appInJntOwnCargo.getRowAction())) {
						deleteColl.addCargo(appInJntOwnCargo);
						appInJntOwnNewColl.remove(i);
						i--;
						size--;
					}
				}
				if (!deleteColl.isEmpty()) {
					appInJntOwnRepository.save(deleteColl.getCargo(0));
				}
				if (!appInJntOwnNewColl.isEmpty()) {
					appInJntOwnRepository.save(appInJntOwnNewColl.getCargo(0));
				}
			}
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
}
	
	
	public String completenessCheck(final APP_IN_VEH_ASET_Cargo iCargo) {
		try {
			String completeIndicator = "0";

			if ((iCargo.getMv_make_txt() != null) && (iCargo.getMv_make_txt().trim().length() > 0) && (iCargo.getMv_modl_txt() != null)
					&& (iCargo.getMv_modl_txt().trim().length() > 0) && (iCargo.getMv_yr() != null) && !"9999".equals(iCargo.getMv_yr().toString().trim())) {
				completeIndicator = "1";
			}
			return completeIndicator;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public APP_IN_JNT_OWN_Collection loadJointOwnerDetails(final String appNumber, final Integer indvSeqNum, final String type, final String subType,
			final Integer seqNum) {
		try {
			final APP_IN_JNT_OWN_Collection appInHouseIndvSelColl = appInJntOwnRepository.loadIndividualJointOwnerDetails(Integer.parseInt(appNumber), indvSeqNum, type, subType, seqNum);
			return appInHouseIndvSelColl;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
	}
}
