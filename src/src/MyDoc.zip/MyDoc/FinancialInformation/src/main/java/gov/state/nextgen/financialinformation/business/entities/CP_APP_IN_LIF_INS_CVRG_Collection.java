/**
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * @author khuskumari
 *
 */
public class CP_APP_IN_LIF_INS_CVRG_Collection extends AbstractCollection{
	
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.financialinformation.business.entities.impl.CP_APP_IN_LIF_INS_CVRG";
	
	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CP_APP_IN_LIF_INS_CVRG_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CP_APP_IN_LIF_INS_CVRG_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CP_APP_IN_LIF_INS_CVRG_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CP_APP_IN_LIF_INS_CVRG_Cargo[] getResults() {
		final CP_APP_IN_LIF_INS_CVRG_Cargo[] cbArray = new CP_APP_IN_LIF_INS_CVRG_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CP_APP_IN_LIF_INS_CVRG_Cargo getCargo(final int idx) {
		return (CP_APP_IN_LIF_INS_CVRG_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public CP_APP_IN_LIF_INS_CVRG_Cargo[] cloneResults() {
		final CP_APP_IN_LIF_INS_CVRG_Cargo[] rescargo = new CP_APP_IN_LIF_INS_CVRG_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_APP_IN_LIF_INS_CVRG_Cargo cargo = getCargo(i);
			rescargo[i] = new CP_APP_IN_LIF_INS_CVRG_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setFirst_name(cargo.getFirst_name());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setLast_name(cargo.getLast_name());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setSeq_num(cargo.getSeq_num());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setCovered_indv_seq_num(cargo.getCovered_indv_seq_num());
			rescargo[i].setCovered_seq_num(cargo.getCovered_seq_num());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_APP_IN_LIF_INS_CVRG_Cargo[]) {
			final CP_APP_IN_LIF_INS_CVRG_Cargo[] cbArray = (CP_APP_IN_LIF_INS_CVRG_Cargo[]) obj;
			setResults(cbArray);
		}
	}

}
