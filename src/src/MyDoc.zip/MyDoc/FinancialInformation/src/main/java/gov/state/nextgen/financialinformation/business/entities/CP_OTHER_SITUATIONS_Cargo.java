package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(CP_OTHER_SITUATIONS_Id.class)
@Table(name = "CP_OTHER_SITUATIONS")
public class CP_OTHER_SITUATIONS_Cargo extends AbstractCargo implements Serializable {

	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	private Integer other_situation_id;
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	private String smone_paid_cmnt;
	
	private String other_change_cmnt;


	/**
	 * @return the other_situation_id
	 */
	public Integer getOther_situation_id() {
		return other_situation_id;
	}

	/**
	 * @param other_situation_id the other_situation_id to set
	 */
	public void setOther_situation_id(Integer other_situation_id) {
		this.other_situation_id = other_situation_id;
	}

	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}

	/**
	 * @param app_num the app_num to set
	 */
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	/**
	 * @return the smone_paid_cmnt
	 */
	public String getSmone_paid_cmnt() {
		return smone_paid_cmnt;
	}

	/**
	 * @param smone_paid_cmnt the smone_paid_cmnt to set
	 */
	public void setSmone_paid_cmnt(String smone_paid_cmnt) {
		this.smone_paid_cmnt = smone_paid_cmnt;
	}

	/**
	 * @return the other_change_cmnt
	 */
	public String getOther_change_cmnt() {
		return other_change_cmnt;
	}

	/**
	 * @param other_change_cmnt the other_change_cmnt to set
	 */
	public void setOther_change_cmnt(String other_change_cmnt) {
		this.other_change_cmnt = other_change_cmnt;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((other_change_cmnt == null) ? 0 : other_change_cmnt.hashCode());
		result = prime * result + ((other_situation_id == null) ? 0 : other_situation_id.hashCode());
		result = prime * result + ((smone_paid_cmnt == null) ? 0 : smone_paid_cmnt.hashCode());
		return result;
	}

	

}