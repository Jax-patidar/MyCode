package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_IN_DABL_Collection extends AbstractCollection {


	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_IN_DABL";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_DABL_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_DABL_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_DABL_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_DABL_Cargo[] getResults() {
		final APP_IN_DABL_Cargo[] cbArray = new APP_IN_DABL_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	public APP_IN_DABL_Cargo getResult(final int idx) {
		return (APP_IN_DABL_Cargo) get(idx);
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_DABL_Cargo getCargo(final int idx) {
		return (APP_IN_DABL_Cargo) get(idx);
	}


	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_DABL_Cargo[]) {
			final APP_IN_DABL_Cargo[] cbArray = (APP_IN_DABL_Cargo[]) obj;
			setResults(cbArray);
		}
	}

	public APP_IN_DABL_Cargo getCargo() {
		if (size() == 0) {
			add(new APP_IN_DABL_Cargo());
		}
		return (APP_IN_DABL_Cargo) get(0);
	}



}
