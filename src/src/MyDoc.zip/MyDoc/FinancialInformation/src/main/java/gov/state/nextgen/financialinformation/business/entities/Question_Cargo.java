package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class Question_Cargo extends AbstractCargo {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String firstName;
	private Integer age;
	private String gender;
	private String indvSeqNumber;
	private String ageSuffix;
	private String questionType;
	private String questionKey;
	private boolean readOnly;
	private String selected;
	private String otherSeqNumber;
	private String shareValue;
	private String shareKey;
	private String lastName;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getIndvSeqNumber() {
		return indvSeqNumber;
	}
	public void setIndvSeqNumber(String indvSeqNumber) {
		this.indvSeqNumber = indvSeqNumber;
	}
	public String getAgeSuffix() {
		return ageSuffix;
	}
	public void setAgeSuffix(String ageSuffix) {
		this.ageSuffix = ageSuffix;
	}
	public String getQuestionType() {
		return questionType;
	}
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}
	public String getQuestionKey() {
		return questionKey;
	}
	public void setQuestionKey(String questionKey) {
		this.questionKey = questionKey;
	}
	public boolean isReadOnly() {
		return readOnly;
	}
	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}
	public String getSelected() {
		return selected;
	}
	public void setSelected(String selected) {
		this.selected = selected;
	}
	public String getOtherSeqNumber() {
		return otherSeqNumber;
	}
	public void setOtherSeqNumber(String otherSeqNumber) {
		this.otherSeqNumber = otherSeqNumber;
	}
	public String getShareValue() {
		return shareValue;
	}
	public void setShareValue(String shareValue) {
		this.shareValue = shareValue;
	}
	public String getShareKey() {
		return shareKey;
	}
	public void setShareKey(String shareKey) {
		this.shareKey = shareKey;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((age == null) ? 0 : age.hashCode());
		result = prime * result + ((ageSuffix == null) ? 0 : ageSuffix.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + ((indvSeqNumber == null) ? 0 : indvSeqNumber.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((otherSeqNumber == null) ? 0 : otherSeqNumber.hashCode());
		result = prime * result + ((questionKey == null) ? 0 : questionKey.hashCode());
		result = prime * result + ((questionType == null) ? 0 : questionType.hashCode());
		result = prime * result + (readOnly ? 1231 : 1237);
		result = prime * result + ((selected == null) ? 0 : selected.hashCode());
		result = prime * result + ((shareKey == null) ? 0 : shareKey.hashCode());
		result = prime * result + ((shareValue == null) ? 0 : shareValue.hashCode());
		return result;
	}
	
	
}
