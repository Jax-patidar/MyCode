package gov.state.nextgen.financialinformation.business.rules;


import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.business.entities.ICargoCollection;
import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.DateRoutine;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.CpAppInEmplRepository;


@Service("ABEmploymentBO")
public class ABEmploymentBO extends AbstractBO {
	
		@Autowired
		private CpAppInEmplRepository cpAppInEmplRepository;
		
		private static final String ABEMPLOYMENT = "ABEmploymentBO.loadIndividualEmploymentDetails() - START";
		
		private static final String ERROR_00019 = "00019";
		
		private static final String ERROR_99269 = "99269";
		
		private static final long STARTTIME = System.currentTimeMillis();
		private static final String MILLISECONDS = " milliseconds";
		
		
		

		public APP_IN_EMPL_Collection loadIndividualEmploymentDetails(
			final String appNumber, final Integer indv_seq_num, final Integer seq_num) {
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, ABEMPLOYMENT);
		
		
		try {
			APP_IN_EMPL_Collection appInColl = new APP_IN_EMPL_Collection();

			
			 if(appNumber != null && indv_seq_num >=0 &&  seq_num >=0) {
                  
				 appInColl = cpAppInEmplRepository.getEmploymentDetails(Integer.parseInt(appNumber), indv_seq_num, seq_num);
                  }
            
            FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABEmploymentBO.loadIndividualEmploymentDetails() - END , Time Taken : "+(System.currentTimeMillis() - STARTTIME)+MILLISECONDS);
            return appInColl;
     		
		}catch (final Exception e) {
			throw e;
		}
	}
		
		public APP_IN_EMPL_Collection getEmploymentDetailsByAppNum(
				final String appNumber) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, ABEMPLOYMENT);
			
			
			try {
				APP_IN_EMPL_Collection appInColl = new APP_IN_EMPL_Collection();
				
				 if(appNumber != null) {
	                  
					 appInColl = cpAppInEmplRepository.getEmploymentDetailsByAppNum(Integer.parseInt(appNumber));
	                  }
	            
				 FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABEmploymentBO.getEmploymentDetailsByAppNum() - END , Time Taken : "+(System.currentTimeMillis() - STARTTIME)+MILLISECONDS);
	            return appInColl;
	     		
			}catch (final Exception e) {
				throw e;
			}
		} 
		
		public APP_IN_EMPL_Collection getActiveEmploymentDetails(
				final String appNumber) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, ABEMPLOYMENT);
			
			
			try {
				APP_IN_EMPL_Collection appInColl = new APP_IN_EMPL_Collection();
				
				 if(appNumber != null) {
	                  
					 appInColl = cpAppInEmplRepository.getActiveEmploymentDetails(Integer.parseInt(appNumber));
	                  }
	            
				 FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABEmploymentBO.getActiveEmploymentDetails() - END , Time Taken : "+(System.currentTimeMillis() - STARTTIME)+MILLISECONDS);
	            return appInColl;
	     		
			} catch (final Exception e) {
				throw e;
			}
		}
		
		public APP_IN_EMPL_Collection getEmploymentDetailsOnType(
				final String appNumber, final Integer indv_seq_num, final String empl_type) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, ABEMPLOYMENT);
			try {
				APP_IN_EMPL_Collection appInColl = new APP_IN_EMPL_Collection();
				 if(appNumber != null && indv_seq_num != null &&  empl_type != null) {
	                  
					 appInColl = cpAppInEmplRepository.getEmploymentDetailsOnType(Integer.parseInt(appNumber), indv_seq_num, empl_type);
				 }
	            return appInColl;
	     		
			} catch (final Exception e) {
				throw e;
			}
		}
		
		public APP_IN_EMPL_Collection getEmploymentDetailsOnIncomeType(
				final String appNumber, final String empl_type, List<Integer> indvIds) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, ABEMPLOYMENT);
			try {
				APP_IN_EMPL_Collection appInColl = new APP_IN_EMPL_Collection();
				 if(appNumber != null  &&  empl_type != null) {
	                  
					 appInColl = cpAppInEmplRepository.getEmploymentDetailsOnIncomeType(Integer.parseInt(appNumber), empl_type, indvIds);
				 }
	            return appInColl;
	     		
			} catch (final Exception e) {
				throw e;
			}
		}
		
		public FwMessageList validateCurrentJobDetails(APP_IN_EMPL_Cargo aCargo, String firstName,
				String showLoopingQuestion) {

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
                    "ABEmploymentBO.validateCurrentJobDetails() - START");
			try {
				
				FwMessageList messageList = new FwMessageList();
				
				final String userName = firstName;
				
				final Object[] error = new Object[] {};
				final char[] citySpecialChars = { '\'', '-', '.', ' ','&',',' };

				// Employer name
				validateEmpDetails(aCargo, error, citySpecialChars);
				validateEmpIncDetails(aCargo, firstName, messageList, userName);

				if (showLoopingQuestion != null

						&& showLoopingQuestion.equals(FwConstants.YES) && aCargo.getLooping_ind() == null) {
					

						this.addMessageWithFieldValues("70027",
								new String[] { firstName });

					
				}


				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"ABEmploymentBO.validateCurrentJobDetails() - END");
				
				return messageList;
			} catch (final Exception e) {
				throw e;
			}
					
		}

		private void validateEmpIncDetails(APP_IN_EMPL_Cargo aCargo, String firstName, FwMessageList messageList,
				final String userName) {
			try {

			validateEmpIncDet(aCargo, messageList);

			validateEmpIncDate(aCargo);

				validateEmplEndDt(aCargo);
			     validateDetails(aCargo, firstName);

				validdateEmpIncGrossAmt(aCargo, userName);

			/* Validation to trigger for Number of hours worked */

				validateEmpIncPayFreq(aCargo);
				
				validateEmpIncHrs(aCargo, userName);

			if (aCargo.getHourly_pay_amt() != null
					&& (aCargo.getHourly_pay_amt()!=0)) {
				if (!appMgr.isCurrency(aCargo.getHourly_pay_amt())) {

					addMessageCode("00287");
				} else if (aCargo.getHourly_pay_amt() < 0
						|| (aCargo.getHourly_pay_amt()) > 9999999.99) {
					addMessageCode("99293");
				}
			}
			} catch (final Exception e) {
				throw e;
			}
		}

		private void validateEmpIncHrs(APP_IN_EMPL_Cargo aCargo, final String userName) {
			try {
			if ((aCargo.getGross_pay_amt() == null
					|| aCargo.getGross_pay_amt()==0) && (aCargo.getNum_of_hours() == null
					|| aCargo.getNum_of_hours()==0) && (aCargo.getHourly_pay_amt() != null
							&& (aCargo.getHourly_pay_amt()!=0))) {
				
						this.addMessageWithFieldValues(ERROR_99269,
								new String[] { userName });
					
			}

			if (aCargo.getNum_of_hours() != null
							&& (aCargo.getNum_of_hours()!=0)
							&& !appMgr.isDecimal(aCargo.getNum_of_hours().toString())
							&& !appMgr.isInteger(aCargo.getNum_of_hours().toString())) {
						addMessageCode("80700");
			}
			
			if (aCargo.getGross_pay_amt() != null
							&& (aCargo.getGross_pay_amt()!=0)) {
						if (!appMgr.isCurrency(aCargo.getGross_pay_amt())) {
			
							addMessageCode("80667");
						} else if (aCargo.getGross_pay_amt() < 0
								|| (aCargo.getGross_pay_amt()) > 9999999.99) {
							addMessageCode("00319");
						}
			}
			} catch (final Exception e) {
				throw e;
			}
		}


		private void validateDetails(APP_IN_EMPL_Cargo aCargo, String firstName) {
			try {
			if (aCargo.getPay_freq_cd() == null
			            || aCargo.getPay_freq_cd().isEmpty()
			            || aCargo.getPay_freq_cd().equals(
			                    FwConstants.DEFAULT_DROPDOWN_SEL)) {
				 
			        this.addMessageWithFieldValues("00324",
			                new String[] { firstName });
			    }
			 if ((aCargo.getGross_pay_amt() == null || aCargo
						.getGross_pay_amt()==0)
						&& Objects.nonNull(aCargo.getNum_of_hours())
						&& Objects.nonNull(aCargo.getHourly_pay_amt())
						&& appMgr.isFieldEmpty(aCargo.getNum_of_hours().toString())
						&& appMgr.isFieldEmpty(aCargo.getHourly_pay_amt().toString())) {
					addMessageCode("00284");
				}
			

			if (aCargo.getEmpl_end_dt() != null) {

				addMessageCode("99259");
			}

			if (aCargo.getLast_payck_dt() != null) {
				addMessageCode("99260");
			}

			if (!appMgr.isFieldEmpty(aCargo.getLast_paycheck_amt().toString())){
				addMessageCode("99261");
			}
			} catch (final Exception e) {
				throw e;
			}
		}

		private void validateEmplEndDt(APP_IN_EMPL_Cargo aCargo) {
			try {
			if ((aCargo.getEmpl_end_dt() != null) || (Objects.nonNull(aCargo.getEmpl_end_dt()) &&
					 ((ICargoCollection) aCargo.getEmpl_end_dt()).isEmpty())) {
				validateEmpIncEndDate(aCargo);

			}

			if ((!(aCargo.getLast_payck_dt() == null || ((ICargoCollection) aCargo
					.getLast_payck_dt()).isEmpty())) &&(!appMgr.validateDate(aCargo.getLast_payck_dt()))) {
				
					addMessageCode("00311");
				
			}
			if (!(aCargo.getLast_paycheck_amt() == null || aCargo
					.getLast_paycheck_amt() == 0)) {

				if (!appMgr.isCurrency(aCargo.getLast_paycheck_amt())) {
					addMessageCode("80672");
				} else if (aCargo.getLast_paycheck_amt() < 0
						|| aCargo.getLast_paycheck_amt() > 9999999.99) {
					addMessageCode("00317");
				}
			}
			} catch (final Exception e) {
				throw e;
			}
		}

		private void validateEmpIncPayFreq(APP_IN_EMPL_Cargo aCargo) {
			try {
			if ((aCargo.getGross_pay_amt() == null || aCargo
					.getGross_pay_amt()==0)
					&& (aCargo.getNum_of_hours() == null || aCargo
					.getNum_of_hours()==0)) {
				if (aCargo.getHourly_pay_amt() != null
						&& aCargo.getHourly_pay_amt()!=0
						&& appMgr.isCurrency(aCargo.getHourly_pay_amt())) {
					addMessageCode("80695");
				}

			} else if ((aCargo.getGross_pay_amt() == null || aCargo
					.getGross_pay_amt()==0)
					&& (aCargo.getNum_of_hours() != null || (aCargo
					.getNum_of_hours()!=0)) && ( aCargo.getHourly_pay_amt() == null
					|| aCargo.getHourly_pay_amt()==0 )) {
				
					addMessageCode("80696");
				
			}
			} catch (final Exception e) {
				throw e;
			}

/* Validation for selecting Pay freq and hourly pay rate together */

			
		}

		private void validdateEmpIncGrossAmt(APP_IN_EMPL_Cargo aCargo, final String userName) {

			try {
			if ((aCargo.getGross_pay_amt() == null
					|| aCargo.getGross_pay_amt()==0)
					&& (aCargo.getNum_of_hours() == null || aCargo
					.getNum_of_hours()==0)
					&& (aCargo.getHourly_pay_amt() == null || aCargo
							.getHourly_pay_amt()==0)) {
				this.addMessageWithFieldValues(ERROR_99269,
						new String[] { userName });
			}
			if ((aCargo.getNum_of_hours() != null
					&& aCargo.getNum_of_hours()!=0 || aCargo
					.getHourly_pay_amt() != null
					&& aCargo.getHourly_pay_amt()!=0)
					&& (aCargo.getGross_pay_amt() != null)
					&& aCargo.getGross_pay_amt()!=0) {

				this.addMessageWithFieldValues(ERROR_99269,
						new String[] { userName });
			}
			
			} catch (final Exception e) {
				throw e;
			}
		}

		private void validateEmpIncEndDate(APP_IN_EMPL_Cargo aCargo) {
			try {
			if (!appMgr.validateDate(aCargo.getEmpl_end_dt())) {
				addMessageCode("00310");
			} else {
				DateRoutine.getInstance();
				
				final java.util.Date endDate = aCargo.getEmpl_end_dt();
				final java.util.Date currentDate = new java.util.Date();
				final java.sql.Date sqlDate = new java.sql.Date(
						currentDate.getTime());
				if (sqlDate.compareTo(endDate) > 30) {
					addMessageCode("00292");
				}
			}
			if (appMgr.isDateBeforeDate(aCargo.getEmpl_end_dt(),
					aCargo.getEmpl_begin_dt())) {
				addMessageCode("80717");
			}
			if (appMgr.isDateBeforeDate(aCargo.getLast_payck_dt(),
					aCargo.getEmpl_begin_dt())) {
				addMessageCode("30041");
			}
			} catch (final Exception e) {
				throw e;
			}
		}

		private void validateEmpIncDate(APP_IN_EMPL_Cargo aCargo) {

			try {
			if (appMgr.isDateBeforeDate(aCargo.getFirst_payck_dt(),
					aCargo.getEmpl_begin_dt())) {
				addMessageCode("98045");
			}


			if (!(aCargo.getFirst_payck_dt() == null || 
					(Objects.nonNull(aCargo.getFirst_payck_dt()) && ((ICargoCollection) aCargo.getFirst_payck_dt())
					.isEmpty())
					)) {

				
					addMessageCode("99043");
				
			}

			if (aCargo.getOn_strike_sw() == null) {
				addMessageCode("00625");
			}
			} catch (final Exception e) {
				throw e;
			}
		}

		private void validateEmpIncDet(APP_IN_EMPL_Cargo aCargo, FwMessageList messageList) {
			try {
			if (!messageList.containsMessage(ERROR_00019)
					&& aCargo.getAddress_zip4() != null
					&& !"".equals(aCargo.getAddress_zip4().trim())
					&& !aCargo.getAddress_zip4().matches("\\d+")) {
				messageList.addMessageToList(addMessageCode(ERROR_00019));
			}


			if (!appMgr.isFieldEmpty(aCargo.getEr_phone_num())) {
				if (!appMgr.isInteger(aCargo.getEr_phone_num())
						|| aCargo.getEr_phone_num().length() != 10) {
					addMessageCode("99017");
				}
				if (aCargo.getEr_phone_num().startsWith("0")) {
					addMessageCode("80660");
				}
			}
			if ((!(aCargo.getEmpl_begin_dt() == null || aCargo.getEmpl_begin_dt().toString().isEmpty())) && (!appMgr.validateDate(aCargo.getEmpl_begin_dt()))) {
			
					addMessageCode("80697");
			 
			}
			} catch (final Exception e) {
				throw e;
			}
		}

		private void validateEmpDetails(APP_IN_EMPL_Cargo aCargo, final Object[] error, final char[] citySpecialChars) {
			try {
			if (aCargo.getEr_name() == null
					|| appMgr.isFieldEmpty(aCargo.getEr_name())) {
				addMessageCode("00276");
			}

			validateEmpDet(aCargo, citySpecialChars);

			if (!appMgr.isFieldEmpty(aCargo.getEr_l2_address()) && (!appMgr.isFieldEmpty(aCargo.getEr_l2_address())
					&& !appMgr.isSpecialAlphaNumeric(aCargo.getEr_l2_address(),
							FinancialInfoConstants.SPECIAL_CHAR_FOR_ADDR))) {
				    addMessageCode("00017");
			}
			if (!appMgr.isFieldEmpty(aCargo.getEr_city_address())
					&& !appMgr.isAlphaWithSpace(aCargo.getEr_city_address())) {
				this.addMessageWithFieldValues("00018", error);

			}


			if (!appMgr.isFieldEmpty(aCargo.getEr_zip_address())) {
				if (!appMgr.isInteger(aCargo.getEr_zip_address())) {
					addMessageCode(ERROR_00019);
				} else if (!appMgr.isZero(aCargo.getEr_zip_address())) {
					addMessageCode("00022");
				} else if (!(aCargo.getEr_zip_address().length() == 5 || aCargo
						.getEr_zip_address().length() == 9)) {
					addMessageCode("99016");
				}

			}
			} catch (final Exception e) {
				throw e;
			}
		}

		private void validateEmpDet(APP_IN_EMPL_Cargo aCargo, final char[] citySpecialChars) {
			try {
			if (!appMgr.isFieldEmpty(aCargo.getEr_name())
					&& !appMgr.isSpecialAlphaNumeric(aCargo.getEr_name(),
							citySpecialChars)) {

				addMessageCode("00286");
			}
			if (!appMgr.isFieldEmpty(aCargo.getEr_name())
					&& aCargo.getEr_name().charAt(0) == '0') {
				addMessageCode("00008");
			}



			if (!appMgr.isFieldEmpty(aCargo.getEr_l1_address())
					&& !appMgr.isSpecialAlphaNumeric(aCargo.getEr_l1_address(),
							FinancialInfoConstants.SPECIAL_CHAR_FOR_ADDR)) {
			    addMessageCode("00017");

			}
			} catch (final Exception e) {
				throw e;
			}
		}

		public Integer completenessCheckABEDT(APP_IN_EMPL_Cargo appInEmplCargo) {

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
	                "ABEmploymentBO.completenessCheckABEDT() - START");

			Integer isItComplete = 0;
			try {


				if (
						appInEmplCargo.getLast_paycheck_amt() != null
						&& null!=(appInEmplCargo.getLast_paycheck_amt())) {
					isItComplete = 1;
				}
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABEmploymentBO.completenessCheckABEDT() - END , Time Taken : "+(System.currentTimeMillis() - STARTTIME)+MILLISECONDS);
				return isItComplete;
			}catch (final Exception e) {
				throw e;
			}
		}

		public APP_IN_EMPL_Collection storeEmplDetails(APP_IN_EMPL_Collection appInEmplColl) {


			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
	                "ABEmploymentBO.storeEmplDetails() - START");
			APP_IN_EMPL_Collection appInUpColl = new APP_IN_EMPL_Collection();
			APP_IN_EMPL_Cargo cargo = new APP_IN_EMPL_Cargo();
			APP_IN_EMPL_Cargo resCargo = new APP_IN_EMPL_Cargo();
			try {
				if (null!=appInEmplColl && !appInEmplColl.isEmpty()) {
					for(int i=0; i<appInEmplColl.size();i++) {
						cargo = appInEmplColl.getCargo(i);
						resCargo = cpAppInEmplRepository.save(cargo);
							appInUpColl.addCargo(resCargo);
					}
				}
				
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABEmploymentBO.storeEmplDetails() - END , Time Taken : "+(System.currentTimeMillis() - STARTTIME)+MILLISECONDS);
				return appInUpColl;
			} catch (final Exception e) {
				throw e;
			}
		
					}
		
		
		//No Title 
		public java.util.Date getDateOfBirth() {
		        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "MedicareBO.getDateOfBirth - START");
		        try {
		        	java.util.Date dateOfBirth = null;

		        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABEmploymentBO.getDateOfBirth() - END , Time Taken : "+(System.currentTimeMillis() - STARTTIME)+MILLISECONDS);

		        	return dateOfBirth;
		        }catch (final Exception e) {
		            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
		            throw e;
		        }
		    } 
		 
		public APP_IN_EMPL_Collection getEarnedIncomeDetail(String appNum, Integer indvSeqNum, Integer seqNum,
				String emplType) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABEmploymentBO.getEarnedIncomeDetail() - START");
			APP_IN_EMPL_Collection appInUpColl = null;
			try {
				appInUpColl = cpAppInEmplRepository.loadChangeInIncomeDetails(Integer.parseInt(appNum), indvSeqNum,
						seqNum, emplType);

				FwLogger.log(this.getClass(), FwLogger.Level.INFO,
						"ABEmploymentBO.getEarnedIncomeDetail() - END , Time Taken : "
								+ (System.currentTimeMillis() - STARTTIME) + MILLISECONDS);
				return appInUpColl;
			} catch (final Exception e) {
				FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
						"ABEmploymentBO.getEarnedIncomeDetail() - END , Time Taken : " + e.getStackTrace());
			}
			return appInUpColl;
		}
}
