/*
 *
 */
package gov.state.nextgen.financialinformation.business.rules;

import gov.state.nextgen.access.business.rules.AbstractBO;

import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppInEmplRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInSelfeRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInUieRepository;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("ABFinalSubmitBO")
public class ABFinalSubmitBO extends AbstractBO {

	@Autowired
	private AppInEmplRepository appInEmplRepository;

	@Autowired
	private AppInUieRepository appInUieRepository;

	@Autowired
	private AppInSelfeRepository appInSelfeRepository;
	
	private static final String SPILT = "spiltColl";
	
	private static final String TIME = " milliseconds";

	/**
	 * Constructor
	 */

	private APP_IN_EMPL_Collection spiltEMPLColl(final APP_IN_EMPL_Collection indvColl, final String recordIndicator) {
		final APP_IN_EMPL_Collection indvAsetTransferColl = new APP_IN_EMPL_Collection();
		try {
			if ((indvColl != null) && (!indvColl.isEmpty())) {
				final int indvAsetTransferCollSize = indvColl.size();
				APP_IN_EMPL_Cargo indvCargo = null;
				for (int i = 0; i < indvAsetTransferCollSize; i++) {
					indvCargo = indvColl.getCargo(i);
					if (null!=indvCargo && indvCargo.getSrc_app_ind().equals(recordIndicator)) {
						indvAsetTransferColl.add(indvCargo);
					}
				}
			}
			return indvAsetTransferColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	private Double calculateEmplAmount(String payCode, Double val, Double totalAmount) {
		try {
		switch (payCode) {
		case "DA":
			totalAmount = totalAmount + (30.4166 * val);
			break;
		case "WK":
			totalAmount = totalAmount + (4.3333 * val);
			break;
		case "BI":
			totalAmount = totalAmount + (2.1666 * val);
			break;
		case "SM":
			totalAmount = totalAmount + (2.0000 * val);
			break;
		case "QU":
			totalAmount = totalAmount + (0.3333 * val);
			break;
		case "SA":
			totalAmount = totalAmount + (0.1666 * val);
			break;
		case "AN":
			totalAmount = totalAmount + (0.0833 * val);
			break;
		case "MO":
			totalAmount += val;
			break;
		default:
			break;
		}		
		return totalAmount;
		} catch (final Exception e) {
			throw e;
		}
	}

	private Double calculateEmplAmountHR(String payCode, Double val, Double totalAmount, Double numHours) {
		try {
		switch (payCode) {
		case "DA":
			totalAmount = totalAmount + (30.4166 * val * numHours);
			break;
		case "WK":
			totalAmount = totalAmount + (4.3333 * val * numHours);
			break;
		case "BI":
			totalAmount = totalAmount + (2.1666 * val * numHours);
			break;
		case "SM":
			totalAmount = totalAmount + (2.0000 * val * numHours);
			break;
		case "QU":
			totalAmount = totalAmount + (0.3333 * val * numHours);
			break;
		case "SA":
			totalAmount = totalAmount + (0.1666 * val * numHours);
			break;
		case "AN":
			totalAmount = totalAmount + (0.0833 * val * numHours);
			break;
		default:
			break;
		}
		return totalAmount;
		} catch (final Exception e) {
			throw e;
		}	
	}


	private Double calculateOtherIncAmount(String payCode, Double val, Double totalAmount) {
		try {
		switch (payCode) {
		case "DA":
			totalAmount = totalAmount + (30.4166 * val);
			break;
		case "WK":
			totalAmount = totalAmount + (4.3333 * val);
			break;
		case "BI":
			totalAmount = totalAmount + (2.1666 * val);
			break;
		case "SM":
			totalAmount = totalAmount + (2.0000 * val);
			break;
		case "QU":
			totalAmount = totalAmount + (0.3333 * val);
			break;
		case "SA":
			totalAmount = totalAmount + (0.1666 * val);
			break;
		case "AN":
			totalAmount = totalAmount + (0.0833 * val);
			break;
		case "MO":
			totalAmount += val;
			break;
		default:
			break;
		}
		return totalAmount;
		} catch (final Exception e) {
			throw e;
		}
	}

	private APP_IN_EMPL_Cargo getMatchingEMPLCargo(final APP_IN_EMPL_Cargo cwwCargo,
			final APP_IN_EMPL_Collection Coll) {
		try {
			APP_IN_EMPL_Cargo rmcCargo = null;
			APP_IN_EMPL_Cargo tempCargo = null;
			final int size = (Coll != null) ? Coll.size() : 0;
			if (size > 0) {
				for (int i = 0; i < size; i++) {
					rmcCargo = Coll.getCargo(i);
					if (cwwCargo.getIndv_seq_num().equals(rmcCargo.getIndv_seq_num())) {
						tempCargo = rmcCargo;
						break;
					}
				}
			}
			return tempCargo;
		} catch (final Exception e) {
			throw e;
		}
	}

	private APP_IN_SELFE_Collection spiltSelfEMPLColl(final APP_IN_SELFE_Collection indvColl,
			final String recordIndicator) {
		final APP_IN_SELFE_Collection indvAsetTransferColl = new APP_IN_SELFE_Collection();
		try {
			if ((indvColl != null) && (!indvColl.isEmpty())) {
				final int indvAsetTransferCollSize = indvColl.size();
				APP_IN_SELFE_Cargo indvCargo = null;
				for (int i = 0; i < indvAsetTransferCollSize; i++) {
					indvCargo = indvColl.getCargo(i);
					if (indvCargo.getSrc_app_ind().equals(recordIndicator)) {
						indvAsetTransferColl.add(indvCargo);
					}
				}
			}
			return indvAsetTransferColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	private APP_IN_SELFE_Cargo getMatchingselfEMPLCargo(final APP_IN_SELFE_Cargo cwwCargo,
			final APP_IN_SELFE_Collection Coll) {
		try {
			APP_IN_SELFE_Cargo rmcCargo = null;
			APP_IN_SELFE_Cargo tempCargo = null;
			final int size = (Coll != null) ? Coll.size() : 0;
			if (size > 0) {
				for (int i = 0; i < size; i++) {
					rmcCargo = Coll.getCargo(i);
					if (cwwCargo.getIndv_seq_num().equals(rmcCargo.getIndv_seq_num())) {
						tempCargo = rmcCargo;
						break;
					}
				}
			}
			return tempCargo;
		} catch (final Exception e) {
			throw e;
		}
	}

	public Double loadEmplDetailGrossHRAmtRMB(final String appNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABFinalSubmitBO.loadEmplDetailGrossHRAmtRMB() - START");
		try {
			Double totalAmount = 0.0;
			final APP_IN_EMPL_Collection emplCollection = appInEmplRepository.loadEmplDetailGrossAmtRMB(Integer.parseInt(appNum));
			APP_IN_EMPL_Collection emplCWCollection = spiltEMPLColl(emplCollection, "CW");
			APP_IN_EMPL_Collection emplRWCollection = spiltEMPLColl(emplCollection, "RM");
			APP_IN_EMPL_Collection emplRECollection = spiltEMPLColl(emplCollection, "RE");
			APP_IN_EMPL_Collection emplRNCollection = spiltEMPLColl(emplCollection, "RN");
			final int emplCWCollectionSize = emplCWCollection.size();
			for (int i = 0; i < emplCWCollectionSize; i++) {
				totalAmount = setEmplCWCollectionData(totalAmount, emplCWCollection, emplRWCollection, emplRECollection,
						i);

			}
			final int emplRNCollectionSize = emplRNCollection.size();
			for (int i = 0; i < emplRNCollectionSize; i++) {
				APP_IN_EMPL_Cargo emplRNCargo = emplRNCollection.getCargo(i);
				String payCode = emplRNCargo.getPay_freq_cd();
				String hrAmt = emplRNCargo.getHourly_pay_amt().toString();
				String numHours = emplRNCargo.getNum_of_hours().toString();
				if (payCode != null && !"".equalsIgnoreCase(payCode) && hrAmt != null && !"".equalsIgnoreCase(hrAmt)
						&& numHours != null && !"".equalsIgnoreCase(numHours)) {
					Double val =  Double.valueOf(hrAmt);
					Double hours =  Double.valueOf(numHours);
					totalAmount = calculateEmplAmountHR(payCode, val, totalAmount, hours);
				}
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABFinalSubmitBO.loadEmplDetailGrossHRAmtRMB() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + TIME);

			return totalAmount;

		}catch (final Exception e) {
			return  Double.valueOf(0);
		}

	}

	/**
	 * @param totalAmount
	 * @param emplCWCollection
	 * @param emplRWCollection
	 * @param emplRECollection
	 * @param i
	 * @return
	 */
	private Double setEmplCWCollectionData(Double totalAmount, APP_IN_EMPL_Collection emplCWCollection,
			APP_IN_EMPL_Collection emplRWCollection, APP_IN_EMPL_Collection emplRECollection, int i) {
		try {
		APP_IN_EMPL_Cargo emplCWCargo = emplCWCollection.getCargo(i);
		APP_IN_EMPL_Cargo emplRMCargo = getMatchingEMPLCargo(emplCWCargo, emplRWCollection);
		APP_IN_EMPL_Cargo emplRECargo = getMatchingEMPLCargo(emplCWCargo, emplRECollection);
		if (emplRECargo == null) {
			if (emplRMCargo == null) {
				// emplCWCargo
				String payCode = emplCWCargo.getPay_freq_cd();
				String hrAmt = emplCWCargo.getHourly_pay_amt().toString();
				String numHours = emplCWCargo.getNum_of_hours().toString();
				if (payCode != null && !"".equalsIgnoreCase(payCode) && hrAmt != null
						&& !"".equalsIgnoreCase(hrAmt) && numHours != null && !"".equalsIgnoreCase(numHours)) {
					Double val =  Double.valueOf(hrAmt);
					Double hours =  Double.valueOf(numHours);
					totalAmount = calculateEmplAmountHR(payCode, val, totalAmount, hours);
				}
			} else {
				// emplRMCargo
				String payCode = emplRMCargo.getPay_freq_cd();
				String hrAmt = emplRMCargo.getHourly_pay_amt().toString();
				String numHours = emplRMCargo.getNum_of_hours().toString();
				if (payCode != null && !"".equalsIgnoreCase(payCode) && hrAmt != null
						&& !"".equalsIgnoreCase(hrAmt) && numHours != null && !"".equalsIgnoreCase(numHours)) {
					Double val =  Double.valueOf(hrAmt);
					Double hours =  Double.valueOf(numHours);
					totalAmount = calculateEmplAmountHR(payCode, val, totalAmount, hours);
				}
			}
		}
		return totalAmount;
		} catch (final Exception e) {
			throw e;
		}
	}

	public Double loadotherIncomeDetailsRMB(final String appNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABFinalSubmitBO.loadotherIncomeDetailsRMB() - START");
		try {
			Double totalAmount = 0.0;
			final APP_IN_UEI_Collection othrIncCollection = appInUieRepository.loadotherIncomeDetailsRMB(Integer.parseInt(appNum));
			APP_IN_UEI_Collection othrIncCWCollection = spiltoThrIncLColl(othrIncCollection, "CW");
			APP_IN_UEI_Collection othrIncRWCollection = spiltoThrIncLColl(othrIncCollection, "RM");
			APP_IN_UEI_Collection othrIncRECollection = spiltoThrIncLColl(othrIncCollection, "RE");
			APP_IN_UEI_Collection othrIncRNCollection = spiltoThrIncLColl(othrIncCollection, "RN");
			final int othrIncCWCollectionSize = othrIncCWCollection.size();

			for (int i = 0; i < othrIncCWCollectionSize; i++) {
				totalAmount = setOthrIncCWCollectionData(totalAmount, othrIncCWCollection, othrIncRWCollection,
						othrIncRECollection, i);

			}
			final int othrIncRNCollectionSize = othrIncRNCollection.size();
			for (int i = 0; i < othrIncRNCollectionSize; i++) {
				APP_IN_UEI_Cargo othrIncRNCargo = othrIncRNCollection.getCargo(i);
				String payCode = othrIncRNCargo.getFreq_cd();
				String grossAmt = othrIncRNCargo.getUei_amt().toString();
				if (payCode != null && !"".equalsIgnoreCase(payCode) && grossAmt != null
						&& !"".equalsIgnoreCase(grossAmt)) {
					Double val =  Double.valueOf(grossAmt);
					totalAmount = calculateOtherIncAmount(payCode, val, totalAmount);
				}

			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABFinalSubmitBO.loadotherIncomeDetailsRMB() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + TIME);

			return totalAmount;

		} catch (final Exception e) {
			return  Double.valueOf(0);
		}

	}

	/**
	 * @param totalAmount
	 * @param othrIncCWCollection
	 * @param othrIncRWCollection
	 * @param othrIncRECollection
	 * @param i
	 * @return
	 */
	private Double setOthrIncCWCollectionData(Double totalAmount, APP_IN_UEI_Collection othrIncCWCollection,
			APP_IN_UEI_Collection othrIncRWCollection, APP_IN_UEI_Collection othrIncRECollection, int i) {
		try {
		APP_IN_UEI_Cargo othrIncCWCargo = othrIncCWCollection.getCargo(i);
		APP_IN_UEI_Cargo othrIncRMCargo = getMatchingOtherIncCargo(othrIncCWCargo, othrIncRWCollection);
		APP_IN_UEI_Cargo othrIncRECargo = getMatchingOtherIncCargo(othrIncCWCargo, othrIncRECollection);
		if (othrIncRECargo == null) {
			if (othrIncRMCargo == null) {
				// othrIncCWCargo
				String payCode = othrIncCWCargo.getFreq_cd();
				String grossAmt = othrIncCWCargo.getUei_amt().toString();
				if (payCode != null && !"".equalsIgnoreCase(payCode) && grossAmt != null
						&& !"".equalsIgnoreCase(grossAmt)) {
					Double val =  Double.valueOf(grossAmt);
					totalAmount = calculateOtherIncAmount(payCode, val, totalAmount);
				}
			} else {
				// othrIncRMCargo
				String payCode = othrIncRMCargo.getFreq_cd();
				String grossAmt = othrIncRMCargo.getUei_amt().toString();
				if (payCode != null && !"".equalsIgnoreCase(payCode) && grossAmt != null
						&& !"".equalsIgnoreCase(grossAmt)) {
					Double val =  Double.valueOf(grossAmt);
					totalAmount = calculateOtherIncAmount(payCode, val, totalAmount);
				}

			}
		}
		return totalAmount;
		} catch (final Exception e) {
			throw e;
		}
	}

	private APP_IN_UEI_Cargo getMatchingOtherIncCargo(final APP_IN_UEI_Cargo cwwCargo,
			final APP_IN_UEI_Collection Coll) {
		try {
			APP_IN_UEI_Cargo rmcCargo = null;
			APP_IN_UEI_Cargo tempCargo = null;
			final int size = (Coll != null) ? Coll.size() : 0;
			if (size > 0) {
				for (int i = 0; i < size; i++) {
					rmcCargo = Coll.getCargo(i);
					if (cwwCargo.getIndv_seq_num().equals(rmcCargo.getIndv_seq_num())
							&& cwwCargo.getSeq_num().equals(rmcCargo.getSeq_num())
							&& cwwCargo.getUei_typ().equals(rmcCargo.getUei_typ())) {
						tempCargo = rmcCargo;
						break;
					}
				}
			}
			return tempCargo;
		} catch (final Exception e) {
			throw e;
		}
	}

	private APP_IN_UEI_Collection spiltoThrIncLColl(final APP_IN_UEI_Collection indvColl,
			final String recordIndicator) {
		final APP_IN_UEI_Collection indvAsetTransferColl = new APP_IN_UEI_Collection();
		try {
			if ((indvColl != null) && (!indvColl.isEmpty())) {
				final int indvAsetTransferCollSize = indvColl.size();
				APP_IN_UEI_Cargo indvCargo = null;
				for (int i = 0; i < indvAsetTransferCollSize; i++) {
					indvCargo = indvColl.getCargo(i);
					if (indvCargo.getSrc_app_ind().equals(recordIndicator)) {
						indvAsetTransferColl.add(indvCargo);
					}
				}
			}
			return indvAsetTransferColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	public Double loadEmplDetailGrossAmtRMB(final String appNum) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABFinalSubmitBO.loadEmplDetailGrossAmtRMB() - START");
		try {
			Double totalAmount = 0.0;
			final APP_IN_EMPL_Collection emplCollection = appInEmplRepository.loadEmplDetailGrossAmtRMB(Integer.parseInt(appNum));

			APP_IN_EMPL_Collection emplCWCollection = spiltEMPLColl(emplCollection, "CW");
			APP_IN_EMPL_Collection emplRWCollection = spiltEMPLColl(emplCollection, "RM");
			APP_IN_EMPL_Collection emplRECollection = spiltEMPLColl(emplCollection, "RE");
			APP_IN_EMPL_Collection emplRNCollection = spiltEMPLColl(emplCollection, "RN");
			final int emplCWCollectionSize = emplCWCollection.size();
			for (int i = 0; i < emplCWCollectionSize; i++) {
				totalAmount = setEmplCWCollectionDataWithoutNumHours(totalAmount, emplCWCollection, emplRWCollection,
						emplRECollection, i);

			}
			final int emplRNCollectionSize = emplRNCollection.size();
			for (int i = 0; i < emplRNCollectionSize; i++) {
				APP_IN_EMPL_Cargo emplRNCargo = emplRNCollection.getCargo(i);
				String payCode = emplRNCargo.getPay_freq_cd();
				String grossAmt = emplRNCargo.getGross_pay_amt().toString();
				if (payCode != null && !"".equalsIgnoreCase(payCode) && grossAmt != null
						&& !"".equalsIgnoreCase(grossAmt)) {
					Double val =  Double.valueOf(grossAmt);
					totalAmount = calculateEmplAmount(payCode, val, totalAmount);
				}
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABFinalSubmitBO.loadEmplDetailGrossAmtRMB() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + TIME);

			return totalAmount;

		}catch (final Exception e) {
			return  Double.valueOf(0);
		}
	}

	/**
	 * @param totalAmount
	 * @param emplCWCollection
	 * @param emplRWCollection
	 * @param emplRECollection
	 * @param i
	 * @return
	 */
	private Double setEmplCWCollectionDataWithoutNumHours(Double totalAmount, APP_IN_EMPL_Collection emplCWCollection,
			APP_IN_EMPL_Collection emplRWCollection, APP_IN_EMPL_Collection emplRECollection, int i) {
		try {
		APP_IN_EMPL_Cargo emplCWCargo = emplCWCollection.getCargo(i);
		APP_IN_EMPL_Cargo emplRMCargo = getMatchingEMPLCargo(emplCWCargo, emplRWCollection);
		APP_IN_EMPL_Cargo emplRECargo = getMatchingEMPLCargo(emplCWCargo, emplRECollection);
		if (emplRECargo == null) {
			if (emplRMCargo == null) {
				// emplCWCargo
				String payCode = emplCWCargo.getPay_freq_cd();
				String grossAmt = emplCWCargo.getGross_pay_amt().toString();
				if (payCode != null && !"".equalsIgnoreCase(payCode) && grossAmt != null
						&& !"".equalsIgnoreCase(grossAmt)) {
					Double val =  Double.valueOf(grossAmt);
					totalAmount = calculateEmplAmount(payCode, val, totalAmount);
				}
			} else {
				// emplRMCargo
				String payCode = emplRMCargo.getPay_freq_cd();
				String grossAmt = emplRMCargo.getGross_pay_amt().toString();
				if (payCode != null && !"".equalsIgnoreCase(payCode) && grossAmt != null
						&& !"".equalsIgnoreCase(grossAmt)) {
					Double val =  Double.valueOf(grossAmt);
					totalAmount = calculateEmplAmount(payCode, val, totalAmount);
				}
			}
		}
		return totalAmount;
		} catch (final Exception e) {
			throw e;
		}
	}

	public Double loadSelfEmplDetailsRMB(final String appNum) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABFinalSubmitBO.loadSelfEmplDetailsRMB() - START");
		try {
			Double totalAmount = 0.0;
			final APP_IN_SELFE_Collection selfCollection = appInSelfeRepository.loadSelfEmplDetailsRMB(Integer.parseInt(appNum));
			APP_IN_SELFE_Collection selfCWCollection = spiltSelfEMPLColl(selfCollection, "CW");
			APP_IN_SELFE_Collection selfRWCollection = spiltSelfEMPLColl(selfCollection, "RM");
			APP_IN_SELFE_Collection selfRECollection = spiltSelfEMPLColl(selfCollection, "RE");
			APP_IN_SELFE_Collection selfRNCollection = spiltSelfEMPLColl(selfCollection, "RN");
			final int selfCWCollectionSize = selfCWCollection.size();

			for (int i = 0; i < selfCWCollectionSize; i++) {
				totalAmount = setSelfCWCollectionData(totalAmount, selfCWCollection, selfRWCollection, selfRECollection,
						i);

			}
			final int selfRNCollectionSize = selfRNCollection.size();
			for (int i = 0; i < selfRNCollectionSize; i++) {
				APP_IN_SELFE_Cargo selfRNCargo = selfRNCollection.getCargo(i);
				String avgIncomeAmt = selfRNCargo.getAvg_incm_amt().toString();
				if (avgIncomeAmt != null && !"".equalsIgnoreCase(avgIncomeAmt)) {
					Double valAvgIncomeAmt =  Double.valueOf(avgIncomeAmt);
					totalAmount = totalAmount + valAvgIncomeAmt;
				}

			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABFinalSubmitBO.loadSelfEmplDetailsRMB() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + TIME);

			return totalAmount;

		}catch (final Exception e) {
			return  Double.valueOf(0);
		}
	}

	/**
	 * @param totalAmount
	 * @param selfCWCollection
	 * @param selfRWCollection
	 * @param selfRECollection
	 * @param i
	 * @return
	 */
	private Double setSelfCWCollectionData(Double totalAmount, APP_IN_SELFE_Collection selfCWCollection,
			APP_IN_SELFE_Collection selfRWCollection, APP_IN_SELFE_Collection selfRECollection, int i) {
		try {
		APP_IN_SELFE_Cargo selfCWCargo = selfCWCollection.getCargo(i);
		APP_IN_SELFE_Cargo selfRMCargo = getMatchingselfEMPLCargo(selfCWCargo, selfRWCollection);
		APP_IN_SELFE_Cargo selfRECargo = getMatchingselfEMPLCargo(selfCWCargo, selfRECollection);
		if (selfRECargo == null) {
			if (selfRMCargo == null) {
				// emplCWCargo
				String avgIncomeAmt = selfCWCargo.getAvg_incm_amt().toString();
				if (avgIncomeAmt != null && !"".equalsIgnoreCase(avgIncomeAmt)) {
					Double valAvgIncomeAmt =  Double.valueOf(avgIncomeAmt);
					totalAmount = totalAmount + valAvgIncomeAmt;
				}
			} else {
				// emplRMCargo
				String avgIncomeAmt = selfRMCargo.getAvg_incm_amt().toString();
				if (avgIncomeAmt != null && !"".equalsIgnoreCase(avgIncomeAmt)) {
					Double valAvgIncomeAmt =  Double.valueOf(avgIncomeAmt);
					totalAmount = totalAmount + valAvgIncomeAmt;
				}

			}
		}
		return totalAmount;
		} catch (final Exception e) {
			throw e;
		}
	}

}
