package gov.state.nextgen.financialinformation.business.entities;




import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_IN_SPS_IMPOV_Collection extends AbstractCollection{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5546191106587574143L;
	private static final String PACKAGE = "gov.nextgen.services.householddemographics.dao.entities.APP_IN_SPS_IMPOV";

	
	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_SPS_IMPOV_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_SPS_IMPOV_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_SPS_IMPOV_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_SPS_IMPOV_Cargo[] getResults() {
		final APP_IN_SPS_IMPOV_Cargo[] cbArray = new APP_IN_SPS_IMPOV_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_SPS_IMPOV_Cargo getCargo(final int idx) {
		return (APP_IN_SPS_IMPOV_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_SPS_IMPOV_Cargo[] cloneResults() {
		final APP_IN_SPS_IMPOV_Cargo[] rescargo = new APP_IN_SPS_IMPOV_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_SPS_IMPOV_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_SPS_IMPOV_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setSps_city_adr(cargo.getSps_city_adr());
			rescargo[i].setSps_l1_adr(cargo.getSps_l1_adr());
			rescargo[i].setSps_l2_adr(cargo.getSps_l2_adr());
			rescargo[i].setSps_sta_adr(cargo.getSps_sta_adr());
			rescargo[i].setSps_zip_adr(cargo.getSps_zip_adr());
			// EDSP Starts - Getting Started
			rescargo[i].setSpouse_out_of_home_ind(cargo.getSpouse_out_of_home_ind());
			rescargo[i].setSpouse_name(cargo.getSpouse_name());
			// EDSP ends - Getting Started
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setDirty(cargo.isDirty());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_SPS_IMPOV_Cargo[]) {
			final APP_IN_SPS_IMPOV_Cargo[] cbArray = (APP_IN_SPS_IMPOV_Cargo[]) obj;
			setResults(cbArray);
		}
	}
	

}
