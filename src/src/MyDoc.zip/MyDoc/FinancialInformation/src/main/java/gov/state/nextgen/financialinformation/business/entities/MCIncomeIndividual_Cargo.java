package gov.state.nextgen.financialinformation.business.entities;

import java.sql.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.management.constants.FwConstants;

public class MCIncomeIndividual_Cargo extends AbstractCargo {




private static final long serialVersionUID = -3049541947358803560L;
private String name;
private Double amt;
private String app_num = FwConstants.SPACE;
private Integer indv_seq_num;
private String pay_freq;
@JsonFormat(pattern = "yyyy-MM-dd")
private Date brth_dt;
private String incomeCd;
@JsonFormat(pattern = "yyyy-MM-dd")
private Date divorce_dt;
@JsonFormat(pattern = "yyyy-MM-dd")
private java.util.Date eff_begin_dt;
@JsonFormat(pattern = "yyyy-MM-dd")
private java.util.Date eff_end_dt;
@JsonProperty("seq_num")
private Integer seqNum;
@JsonFormat(pattern = "yyyy-MM-dd")
private java.util.Date end_dt;

private String income_src;

private String expected_to_cont_resp;

public String getExpected_to_cont_resp() {
	return expected_to_cont_resp;
}

public void setExpected_to_cont_resp(String expected_to_cont_resp) {
	this.expected_to_cont_resp = expected_to_cont_resp;
}

public String getIncome_src() {
	return income_src;
}

public void setIncome_src(String income_src) {
	this.income_src = income_src;
}

public java.util.Date getEff_end_dt() {       
	return this.eff_end_dt!= null ? new java.util.Date(eff_end_dt.getTime()) : null;

}

public void setEff_end_dt(java.util.Date eff_end_dt) {
	this.eff_end_dt = (eff_end_dt == null) ? null : new java.util.Date(eff_end_dt.getTime());
}


public java.util.Date getEff_begin_dt() {       
	return this.eff_begin_dt!= null ? new java.util.Date(eff_begin_dt.getTime()) : null;

}

public void setEff_begin_dt(java.util.Date eff_begin_dt) {
	this.eff_begin_dt = (eff_begin_dt == null) ? null : new java.util.Date(eff_begin_dt.getTime());
}


public Date getDivorce_dt() {
	return divorce_dt;
}
public void setDivorce_dt(Date divorce_dt) {
	this.divorce_dt = divorce_dt;
}

public String getIncomeCd() {
	return incomeCd;
}
public void setIncomeCd(String incomeCd) {
	this.incomeCd = incomeCd;
}
public Date getBrth_dt() {
	return brth_dt;
}
public void setBrth_dt(Date brth_dt) {
	this.brth_dt = brth_dt;
}
public String getPay_freq() {
	return pay_freq;
}
public void setPay_freq(String pay_freq) {
	this.pay_freq = pay_freq;
}
public String getApp_num() {
	return app_num;
}
public void setApp_num(String app_num) {
	this.app_num = app_num;
}
public Integer getIndv_seq_num() {
	return indv_seq_num;
}
public void setIndv_seq_num(Integer indv_seq_num) {
	this.indv_seq_num = indv_seq_num;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Double getAmt() {
	return amt;
}
public void setAmt(Double amt) {
	this.amt = amt;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((amt == null) ? 0 : amt.hashCode());
	result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
	result = prime * result + ((brth_dt == null) ? 0 : brth_dt.hashCode());
	result = prime * result + ((divorce_dt == null) ? 0 : divorce_dt.hashCode());
	result = prime * result + ((eff_begin_dt == null) ? 0 : eff_begin_dt.hashCode());
	result = prime * result + ((eff_end_dt == null) ? 0 : eff_end_dt.hashCode());
	result = prime * result + ((incomeCd == null) ? 0 : incomeCd.hashCode());
	result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
	result = prime * result + ((name == null) ? 0 : name.hashCode());
	result = prime * result + ((pay_freq == null) ? 0 : pay_freq.hashCode());
	return result;
}

public Integer getSeqNum() {
	return seqNum;
}

public void setSeqNum(Integer seqNum) {
	this.seqNum = seqNum;
}

public java.util.Date getEnd_dt() {
	return end_dt;
}

public void setEnd_dt(java.util.Date end_dt) {
	this.end_dt = end_dt;
}


}