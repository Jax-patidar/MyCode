package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_SHLTC_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_SHLTC_Collection;
import gov.state.nextgen.financialinformation.business.rules.ABFacilityInformationBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;

@SuppressWarnings("squid:S2229")
@Service("HouseholdDetailsFacilityServiceImpl")
public class HouseholdDetailsFacilityServiceImpl implements FinancialServInterface {

	@Autowired
	protected ABFacilityInformationBO facilityInformationBO;
	
	private static Logger logger = LoggerFactory.getLogger(HouseholdDetailsFacilityServiceImpl.class);

	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTransaction) {

		switch (methodName) {
			case FinancialInfoConstants.STORE_FAC_INFO:
				storeFacilityInformation(fwTransaction);
				break;

			case FinancialInfoConstants.LOAD_FAC_INFO:
				loadFacilityInformation(fwTransaction);
				break;
			case FinancialInfoConstants.REMOVE_FAC_INFO:
				removeFacilityInformation(fwTransaction);
				break;
			default:
				break;
		}
	}

	/*
	 * Load method for HouseholdDetails Facilty Summary Screen CSPM-6365
	 * TODO:CP_APP_IN_PRFL service chaining needs to be implemented
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void loadFacilityInformation(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDetailsFacilityServiceImpl.loadFacilityInformation() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNum = fwTxn.getUserDetails().getAppNumber();

			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("indvIds");
			List<Integer> indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
					.collect(Collectors.toList());
			CP_APP_IN_SHLTC_Collection appInShltcColl;
			appInShltcColl = facilityInformationBO.loadFacilityInformation(appNum, indvIdList);
			pageCollection.put(FinancialInfoConstants.CP_APP_IN_SHLTC_COLL, appInShltcColl);

			fwTxn.setPageCollection(pageCollection);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDetailsFacilityServiceImpl.loadFacilityInformation() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime), fwTxn );

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in loadFacilityInformation()", fwTxn);
			FwExceptionManager.handleException(e,this.getClass().getName(),
        			FinancialInfoConstants.CP_APP_IN_SHLTC_COLL, fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}

	}

	/*
	 * Store method for HouseholdDetails Facilty Person Selection and Facility Info Screen CSPM-6365
	 * TODO:CP_APP_IN_PRFL service chaining needs to be implemented
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void storeFacilityInformation(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDetailsFacilityServiceImpl.storeFacilityInformation() - START", fwTxn);
		try {
			
			Map pageCollection = fwTxn.getPageCollection();

			String appNum = fwTxn.getUserDetails().getAppNumber();
			Integer indv_seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seq_num = null;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			CP_APP_IN_SHLTC_Collection appInShltcColl = (CP_APP_IN_SHLTC_Collection) pageCollection
					.get(FinancialInfoConstants.CP_APP_IN_SHLTC_COLL);
			CP_APP_IN_SHLTC_Cargo appInShltcCargo;

			if (appInShltcColl != null && !appInShltcColl.isEmpty() && appInShltcColl.size() > 0) {

				appInShltcCargo = appInShltcColl.getCargo(0);



				appInShltcCargo.setApp_num(appNum);
				appInShltcCargo.setIndv_seq_num(indv_seq_num);
				CP_APP_IN_SHLTC_Collection facilityInfoDtls = facilityInformationBO.loadFacilityInformation(appNum,
						indv_seq_num);
				if (Objects.isNull(seq_num)) {
					seq_num = 1;
					if (!facilityInfoDtls.isEmpty()) {
						int index = facilityInfoDtls.size() - 1;
						CP_APP_IN_SHLTC_Cargo lastCargo = (CP_APP_IN_SHLTC_Cargo) facilityInfoDtls.get(index);
						seq_num = lastCargo.getSeq_num() + 1;
					}
				}
				
				 
				 
				appInShltcCargo.setSeq_num(seq_num);
				appInShltcCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
			}

			facilityInformationBO.storeFacilityInformations(appInShltcColl);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HouseholdDetailsFacilityServiceImpl.storeFacilityInformation() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime), fwTxn );

		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDetailsFacilityServiceImpl.storeFacilityInformation()", fwTxn);
			FwExceptionManager.handleException(fe,this.getClass().getName(),
        			FinancialInfoConstants.STORE_FAC_INFO, fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDetailsFacilityServiceImpl.storeFacilityInformation()", fwTxn);
			FwExceptionManager.handleException(e,this.getClass().getName(),
        			FinancialInfoConstants.STORE_FAC_INFO, fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}
	}

	/*
	 * Remove method for VehicleAsset Screen CSPM-3249
	 */
	@Transactional
	public void removeFacilityInformation(final FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HouseholdDetailsFacilityServiceImpl.removeFacilityInformation() - START", fwTxn);
		try {
			String appNum = fwTxn.getUserDetails().getAppNumber();
			
			String src_app_ind = AppConstants.AFB_SRC_APP_IND;
			Integer indvSeqNumber = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seq_num = Integer.parseInt(
					fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			facilityInformationBO.deleteFacilityInformation(appNum, indvSeqNumber, src_app_ind, seq_num);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HouseholdDetailsFacilityServiceImpl.removeFacilityInformation()", fwTxn);
			FwExceptionManager.handleException(e,this.getClass().getName(),
        			FinancialInfoConstants.REMOVE_FAC_INFO, fwTxn.getUserDetails().getAppNumber(),
        			fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HouseholdDetailsFacilityServiceImpl.removeFacilityInformation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn );
	}

}
