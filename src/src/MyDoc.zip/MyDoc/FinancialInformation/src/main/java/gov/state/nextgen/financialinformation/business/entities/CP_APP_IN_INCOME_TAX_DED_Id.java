/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CP_APP_IN_INCOME_TAX_DED_Id implements Serializable {

	private static final long serialVersionUID = -1184867010602687081L;
	private Integer app_number;
	private Integer indv_seq_num;
	private String src_app_ind;
	private Integer seq_num;
	private String exp_type;

	public CP_APP_IN_INCOME_TAX_DED_Id() {
		super();
	}

	public CP_APP_IN_INCOME_TAX_DED_Id( Integer app_num, Integer indv_seq_num,Integer seq_num, String exp_type) {
		super();
		this.app_number = app_num;
		this.indv_seq_num = indv_seq_num;
		this.seq_num = seq_num;
		this.exp_type = exp_type;
	}

	
	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public Integer getApp_number() {
		return app_number;
	}

	public void setApp_number(final Integer app_number) {
		this.app_number = app_number;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public Integer getSeq_num() {
		return seq_num;
	}

	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	
	public String getExp_type() {
		return exp_type;
	}

	public void setExp_type(String exp_type) {
		this.exp_type = exp_type;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((exp_type == null) ? 0 : exp_type.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}
@SuppressWarnings("squid:S3776")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CP_APP_IN_INCOME_TAX_DED_Id other = (CP_APP_IN_INCOME_TAX_DED_Id) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (exp_type == null) {
			if (other.exp_type != null)
				return false;
		} else if (!exp_type.equals(other.exp_type))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		if (seq_num == null) {
			if (other.seq_num != null)
				return false;
		} else if (!seq_num.equals(other.seq_num))
			return false;
		return true;
	}

	
}
