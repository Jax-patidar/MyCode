package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.access.management.util.FwDate;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_ASET_XFER_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_ASET_XFER_Collection;
import gov.state.nextgen.financialinformation.business.rules.ABOtherExpensesDetailsBO;
import gov.state.nextgen.financialinformation.business.rules.FinancialAssetsBO;
import gov.state.nextgen.financialinformation.business.rules.LiquidAssetBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInJntOwnRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInLqdAsetRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInAsetXferRepository;
import gov.state.nextgen.framework.business.model.IndividualCategorySequenceDetails;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.framework.business.model.UserDetails;

@SuppressWarnings("squid:S2229")
@Service("LiquidAssetsService")
public class LiquidAssetsServImpl implements FinancialServInterface {

	@Autowired
	private LiquidAssetBO liquidAssetBO;

	@Autowired
	private FinancialAssetsBO financialAssetsBO;

	@Autowired
	AppInLqdAsetRepository appInLqdAsetRepository;
	
	@Autowired
	AppInJntOwnRepository appInJntOwnRepository; 
		 
	
	private static final Object CP_APP_IN_ASET_XFER_COLLECTION = "CP_APP_IN_ASET_XFER_Collection";

	private static final String APP_IN_LQD_ASET_COLLECTION = "APP_IN_LQD_ASET_Collection";
	
	@Autowired
	private CpAppInAsetXferRepository cpAppInAsetXferRepository;
	
	@Autowired
	public FwDate fwDate;

	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {

		switch (methodName) {

		case FinancialInfoConstants.GET_SOLD_AND_TRANSFEERED_ASSETS:
			this.getSoldAndTransferredAssets(fwTxn);
			break;

		case FinancialInfoConstants.STORE_SOLD_AND_TRANS_ASSETS:
			this.storeSoldAndTransferredAssets(fwTxn);
			break;
		// Start:add changes as part of 1864
		case FinancialInfoConstants.LOAD_METHOD_FOR_ACC_INFO_DETAILS:
			this.getAccountInfoDetails(fwTxn);
			break;

		case FinancialInfoConstants.NEXT_METHOD_FOR_ACC_INFO_DETAILS:
			this.storeAccountInfoDetails(fwTxn);
			break;
		// End:add changes as part of 1864
		case FinancialInfoConstants.DELETE_ACC_INFO_DET:
			this.deleteAccountInfoDetails(fwTxn);
			break;
		case FinancialInfoConstants.FETCH_LQD_ASET_DTS:
			this.fetchLiquidAssetDetailsMC(fwTxn);
			break;
		case FinancialInfoConstants.DELETE_ASSETS_INFO_DET:
			this.deleteAssetsDetailsMC(fwTxn);
			break;
		default:
		}

	}

	//start :This is added as part of CSPM-1864
	@Transactional
	@SuppressWarnings("squid:S3776")
	public void storeAccountInfoDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.storeAccountInfoDetails() - START", fwTxn);
		int indvSeqNum = Integer.parseInt(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
		int seqNum = Integer.parseInt(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
		String categoryType = null;
		if (Objects.nonNull(fwTxn.getCurrentActionDetails())
				&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
			categoryType = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getCategoryType();
		}
		String src_app_ind = null;
		final String appNum = fwTxn.getUserDetails().getAppNumber();

		try {
			Map pageCollection = fwTxn.getPageCollection();
			APP_IN_LQD_ASET_Collection appInLqdAsetColl = (APP_IN_LQD_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_LQD_ASET_COLL);
			APP_IN_JNT_OWN_Cargo jntCargo=new APP_IN_JNT_OWN_Cargo();
			APP_IN_LQD_ASET_Cargo cargo = new APP_IN_LQD_ASET_Cargo();
			//Snigdha-Asset info Redet MC save - start
			if (null != pageCollection.get(AppConstants.FLOW_MODE) && (AppConstants.MCR_FLOW).equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())
					&& appInLqdAsetColl != null && !appInLqdAsetColl.isEmpty()) {
				cargo = appInLqdAsetColl.getCargo(0);
				cargo.setApp_num(appNum);
				cargo.setIndv_seq_num(indvSeqNum);
				cargo.setSeq_num(seqNum);
				cargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);

				APP_IN_LQD_ASET_Collection lqdAssetColl = appInLqdAsetRepository.loadLiquidAssetData(Integer.parseInt(appNum),indvSeqNum,seqNum,cargo.getLqd_aset_typ());
				if(null != lqdAssetColl && !lqdAssetColl.isEmpty()) {
					cargo.setChg_dt(fwDate.getDate());
				}
			}
			
			
			//Snigdha-Asset info Redet MC save - end
			else if (appInLqdAsetColl != null && !appInLqdAsetColl.isEmpty() && appInLqdAsetColl.size() > 0) {
				cargo = appInLqdAsetColl.getCargo(0);
				cargo.setApp_num(appNum);
				cargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
				cargo.setIndv_seq_num(indvSeqNum);
				cargo.setSeq_num(seqNum);
				cargo.setLqd_aset_typ(categoryType);
				
				jntCargo.setApp_num(appNum);
				jntCargo.setIndv_seq_num(indvSeqNum);
				jntCargo.setSeq_num(seqNum);
				jntCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
				jntCargo.setJnt_own_seq_num(indvSeqNum);
				jntCargo.setAset_typ(categoryType);
				jntCargo.setAset_sub_typ(categoryType);
				if(cargo.getJnt_own_resp()!=null && cargo.getJnt_own_resp().equals("Y")) {
					if(cargo.getJnt_indv_seq_num()!=null && cargo.getJnt_indv_seq_num() > 0) {
						jntCargo.setJnt_indv_seq_num(cargo.getJnt_indv_seq_num());
					}
					else if(cargo.getJnt_indv_seq_num()!=null && cargo.getJnt_indv_seq_num() == -1) {
						jntCargo.setJnt_own_fst_nam(cargo.getJnt_own_fst_nam());
						jntCargo.setJnt_own_last_nam(cargo.getJnt_own_last_nam());
						jntCargo.setJnt_indv_seq_num(-1);
					}
				}
				else
				{
						jntCargo.setJnt_own_fst_nam("");
						jntCargo.setJnt_own_last_nam("");
						jntCargo.setJnt_indv_seq_num(0);
				}
				appInJntOwnRepository.save(jntCargo);
			}


			appInLqdAsetRepository.save(cargo);
		}

		catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeAccountInfoDetails()", fwTxn);
			FwExceptionManager.handleException(fe,this.getClass().getName(),
					FinancialInfoConstants.NEXT_METHOD_FOR_ACC_INFO_DETAILS, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.storeAccountInfoDetails() - END", fwTxn);
	}
     // end
	
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void deleteAccountInfoDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.deleteAccountInfoDetails() - START", txnBean);
		try {

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails=txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String appNum = userDetails.getAppNumber();
			String categoryType = null;
			if (Objects.nonNull(txnBean.getCurrentActionDetails())
					&& Objects.nonNull(txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
				categoryType = txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
						.getCategoryType();
			}
			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			int seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());
			APP_IN_LQD_ASET_Collection existingLqdColl = liquidAssetBO.loadIndividualLiquidAssetDetails(appNum,
					indvSeqNum, seqNum,categoryType);
			if(Objects.nonNull(existingLqdColl) && !existingLqdColl.isEmpty() && existingLqdColl.size()>0) {
				APP_IN_LQD_ASET_Cargo existingCargo = existingLqdColl.getCargo(0);
				if(Objects.nonNull(existingCargo)) {
					appInJntOwnRepository.deleteAccountInfoDetail(Integer.parseInt(appNum),existingCargo.getIndv_seq_num(),existingCargo.getSeq_num(),existingCargo.getLqd_aset_typ());
					liquidAssetBO.deleteLqdAsetCargo(existingCargo);
				}
			}
		}
		catch (final Exception e) {
			final FwException fe = ABOtherExpensesDetailsBO.createFwException(this.getClass().getName(),
					"deleteMedicalExpenseDetails", e);
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in deleteAccountInfoDetails()", txnBean);
			FwExceptionManager.handleException(fe,this.getClass().getName(),
        			FinancialInfoConstants.DELETE_ACC_INFO_DET, txnBean.getUserDetails().getAppNumber(),
        			txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.deleteAccountInfoDetails() - END", txnBean);
	}

//start :This is added as part of CSPM-1864
	@Transactional
	@SuppressWarnings("squid:S3776")
	public void getAccountInfoDetails(FwTransaction txBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.getAccountInfoDetails() - START", txBean);
		
		Map pageCollection = txBean.getPageCollection();
		try {
			PageActionDetails currentActionDetails = txBean.getCurrentActionDetails();
			UserDetails userDetails = txBean.getUserDetails();
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("indvIds");
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			if (Objects.nonNull(currentActionDetails)) {
				String appNumber = userDetails.getAppNumber();
				String categoryType = null;
				if (Objects.nonNull(txBean.getCurrentActionDetails())
						&& Objects.nonNull(txBean.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
					categoryType = txBean.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategoryType();
				}
				APP_IN_LQD_ASET_Collection appInLqdAsetColl = new APP_IN_LQD_ASET_Collection();
				//Snigdha- Load Asset Summary-Redet MC-Start
				final APP_IN_LQD_ASET_Cargo[] appInCargoArray;
				if(null != pageCollection.get(AppConstants.FLOW_MODE)
						&& (AppConstants.MCR_FLOW).equalsIgnoreCase(pageCollection.get(AppConstants.FLOW_MODE).toString())) {
					 appInCargoArray =  appInLqdAsetRepository.getByAppNumTypeNonEndated(Integer.parseInt(appNumber), categoryType, indvIdList);
				}else {
				//Snigdha- Load Asset Summary-Redet MC-End

				appInCargoArray =  appInLqdAsetRepository
						.getByAppNumType(Integer.parseInt(appNumber), categoryType, indvIdList);
				
				for(APP_IN_LQD_ASET_Cargo lgdAssetCargo:appInCargoArray) {
					APP_IN_JNT_OWN_Cargo jntCargo = appInJntOwnRepository.getIndividualJointOwnerDetails(Integer.parseInt(appNumber),lgdAssetCargo.getIndv_seq_num(),
							lgdAssetCargo.getLqd_aset_typ(),lgdAssetCargo.getSeq_num());
					if(Objects.nonNull(jntCargo)) {
						lgdAssetCargo.setJnt_own_fst_nam(jntCargo.getJnt_own_fst_nam());
						lgdAssetCargo.setJnt_own_last_nam(jntCargo.getJnt_own_last_nam());
						lgdAssetCargo.setJnt_indv_seq_num(jntCargo.getJnt_indv_seq_num());
					}
				}}
				
				
				

				if (appInCargoArray != null && appInCargoArray.length > 0) {

						appInLqdAsetColl.setResults(appInCargoArray);

				}

				pageCollection.put(APP_IN_LQD_ASET_COLLECTION, appInLqdAsetColl);
				txBean.setPageCollection(pageCollection);
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getAccountInfoDetails()", txBean);
			FwExceptionManager.handleException(e,this.getClass().getName(),
        			FinancialInfoConstants.LOAD_METHOD_FOR_ACC_INFO_DETAILS, txBean.getUserDetails().getAppNumber(),
        			txBean.getUserDetails().getLoginUserId(), true);

		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.getAccountInfoDetails() - END", txBean);

	}
	//end 

	@Transactional
	public void storeSoldAndTransferredAssets(FwTransaction txnBean) {
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.storeSoldAndTransferredAssets() - START", txnBean);

		try {

			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			final Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());
			

			FwMessageList validateInfo = null;


			
			// get Details aset Collection and Cargo
			CP_APP_IN_ASET_XFER_Collection cpAppInAsetXferColl = (CP_APP_IN_ASET_XFER_Collection) pageCollection
					.get(CP_APP_IN_ASET_XFER_COLLECTION);
			CP_APP_IN_ASET_XFER_Cargo cpAppInAsetXferCargo = cpAppInAsetXferColl.getCargo(0);

			// get the Aset collection from Before Collection
			final CP_APP_IN_ASET_XFER_Collection cpAppInAsetXferBeforeColl = (CP_APP_IN_ASET_XFER_Collection) cpAppInAsetXferRepository
					.findByAppNum(Integer.parseInt(appNum));
			CP_APP_IN_ASET_XFER_Cargo cpAppInAsetXferBeforeCargo = null;

			if ((cpAppInAsetXferBeforeColl != null) && (!cpAppInAsetXferBeforeColl.isEmpty())) {
				cpAppInAsetXferBeforeCargo = cpAppInAsetXferBeforeColl.getCargo(0);
				cpAppInAsetXferCargo.setApp_num(appNum);
				cpAppInAsetXferCargo.setIndv_seq_num(cpAppInAsetXferBeforeCargo.getIndv_seq_num());
				cpAppInAsetXferCargo.setSeq_num(cpAppInAsetXferBeforeCargo.getSeq_num());

				if (cpAppInAsetXferCargo.getSeq_num() != null) {
					cpAppInAsetXferCargo.setRowAction(FwConstants.ROWACTION_UPDATE);
				} else {
					cpAppInAsetXferCargo.setRowAction(FwConstants.ROWACTION_INSERT);
				}

				final String xferRsnCd = cpAppInAsetXferCargo.getAsset_xfer_rsn_cd();
				if (xferRsnCd == null) {
					cpAppInAsetXferCargo.setAsset_xfer_rsn_cd(FwConstants.SPACE);
				}
				// check dirty
			
			} else {
				cpAppInAsetXferCargo.setApp_num(appNum);
				cpAppInAsetXferCargo.setIndv_seq_num(indvSeqNum);
				cpAppInAsetXferCargo.setSeq_num(seqNum);
				cpAppInAsetXferCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
			}

			
			validateInfo = liquidAssetBO.validateSoldAndTransferredAssetDetails(cpAppInAsetXferCargo);

			if ((validateInfo != null) && validateInfo.hasMessages()) {

				
				pageCollection.put(CP_APP_IN_ASET_XFER_COLLECTION, cpAppInAsetXferColl);
				
				// Run ComponentManager to get the components for the current
				// page
				return;
			}

			// //completeness check
			// EDSP CP START - NO COMPLETENESS CHECK SO MAKE IT COMPLETE
			cpAppInAsetXferCargo.setRec_cplt_ind(FinancialInfoConstants.ONE);
			// PersistData if the cargo is dirty
			cpAppInAsetXferColl.set(0, cpAppInAsetXferCargo);
			

			
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeSoldAndTransferredAssets()", txnBean);
			FwExceptionManager.handleException(e,this.getClass().getName(),
        			FinancialInfoConstants.STORE_SOLD_AND_TRANS_ASSETS, txnBean.getUserDetails().getAppNumber(),
        			txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.storeSoldAndTransferredAssets() - END", txnBean);
	}

	@Transactional
	public void getSoldAndTransferredAssets(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.getSoldAndTransferredAssets() - START", txnBean);
		try {
			final Map request = txnBean.getRequest();
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			final String appNum = userDetails.getAppNumber();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			final Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			final Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());
		

			// make loopingQuestion value NO in the request
			request.put("loopingQuestion", FwConstants.NO);


			
			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {
				// get LiquidAsset details from LiquidAsset details table in
				// database
				pageCollection = new HashMap();
				// get Details_Collection from DataBase and set to
				// PageCollection

				final CP_APP_IN_ASET_XFER_Collection cpAppAsetXferCol = liquidAssetBO
						.loadIndividualAssetXferDetails(appNum, indvSeqNum, seqNum);
				pageCollection.put(CP_APP_IN_ASET_XFER_COLLECTION, cpAppAsetXferCol);

			} else {
				pageCollection = new HashMap();

				final CP_APP_IN_ASET_XFER_Collection cpAppInXferAsetColl = liquidAssetBO
						.loadIndividualAssetXferDetails(appNum, indvSeqNum, seqNum);

				int sizeColl = 0;
				CP_APP_IN_ASET_XFER_Cargo cpAppInXferAsetCargo = null;
				if ((cpAppInXferAsetColl != null) && (!cpAppInXferAsetColl.isEmpty())) {
					sizeColl = cpAppInXferAsetColl.size();
				}
				if (sizeColl > 0) {
					cpAppInXferAsetCargo = cpAppInXferAsetColl.getCargo(sizeColl - 1);

				} else {
					cpAppInXferAsetCargo = new CP_APP_IN_ASET_XFER_Cargo();
					cpAppInXferAsetCargo.setApp_num(appNum);
					cpAppInXferAsetCargo.setIndv_seq_num(indvSeqNum);
					cpAppInXferAsetCargo.setSeq_num(seqNum);

				}

				final CP_APP_IN_ASET_XFER_Collection temp = new CP_APP_IN_ASET_XFER_Collection();
				temp.addCargo(cpAppInXferAsetCargo);
				pageCollection.put(CP_APP_IN_ASET_XFER_COLLECTION, temp);
				txnBean.setPageCollection(pageCollection);

			}

		
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getSoldAndTransferredAssets()", txnBean);
			FwExceptionManager.handleException(e,this.getClass().getName(),
        			FinancialInfoConstants.GET_SOLD_AND_TRANSFEERED_ASSETS, txnBean.getUserDetails().getAppNumber(),
        			txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.getSoldAndTransferredAssets() - END", txnBean);
	}
	
		public void getAccountInfoDetailsRAC(FwTransaction txBean) {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetsService.getAccountInfoDetailsRAC() - START");
			final long startTime = System.currentTimeMillis();
			Map pageCollection = txBean.getPageCollection();
			try {
				PageActionDetails currentActionDetails = txBean.getCurrentActionDetails();
				UserDetails userDetails = txBean.getUserDetails();
				
				if (Objects.nonNull(currentActionDetails)) {
					String appNumber = userDetails.getAppNumber();
					
					APP_IN_LQD_ASET_Collection appInLqdAsetColl = new APP_IN_LQD_ASET_Collection();

					final APP_IN_LQD_ASET_Cargo[] appInCargoArray =  appInLqdAsetRepository
							.getByAppNum(Integer.parseInt(appNumber));
					
					for(APP_IN_LQD_ASET_Cargo lgdAssetCargo:appInCargoArray) {
						APP_IN_JNT_OWN_Cargo jntCargo = appInJntOwnRepository.getIndividualJointOwnerDetails(Integer.parseInt(appNumber),lgdAssetCargo.getIndv_seq_num(),
								lgdAssetCargo.getLqd_aset_typ(),lgdAssetCargo.getSeq_num());
						if(Objects.nonNull(jntCargo)) {
							lgdAssetCargo.setJnt_own_fst_nam(jntCargo.getJnt_own_fst_nam());
							lgdAssetCargo.setJnt_own_last_nam(jntCargo.getJnt_own_last_nam());
							lgdAssetCargo.setJnt_indv_seq_num(jntCargo.getJnt_indv_seq_num());
						}
					}
					
					
					

					if (appInCargoArray != null && appInCargoArray.length > 0) {

							appInLqdAsetColl.setResults(appInCargoArray);

					}

					pageCollection.put(APP_IN_LQD_ASET_COLLECTION, appInLqdAsetColl);
					txBean.setPageCollection(pageCollection);
				}

			} catch (final Exception e) {
				FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
				final FwException fe = new FwException(e);
				fe.setClassID(this.getClass().getName());
				fe.setMethodID("getServiceClass");
				fe.setExceptionText(String.valueOf(e));
				fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
				fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
				FwLogger.log(this.getClass(), Level.ERROR, "getAccountInfoDetailsRAC", fe);
				throw e;

			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"LiquidAssetsService.getAccountInfoDetailsRAC()  - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) );

		}
		/**
		 * Method to fetch details from CP_APP_IN_LQD_ASSET for a particular appNum.
		 * @param fwTxn
		 */
		@Transactional
		public void fetchLiquidAssetDetailsMC(FwTransaction fwTxn) {
			try {
				APP_IN_LQD_ASET_Collection appInLqdAsetColl = liquidAssetBO.loadLiquidAssetDetails(fwTxn.getUserDetails().getAppNumber());
				fwTxn.getPageCollection().put("AssetsMaxSeqNum", appInLqdAsetColl.getResults().length);
				fwTxn.getPageCollection().put(APP_IN_LQD_ASET_COLLECTION, appInLqdAsetColl);
			}catch(final Exception e)
			{
				FwExceptionManager.handleException(e,this.getClass().getName(),
						FinancialInfoConstants.FETCH_LQD_ASET_DTS, fwTxn.getUserDetails().getAppNumber(),
						fwTxn.getUserDetails().getLoginUserId(), true);
			}
		}
		
		/**
		 * Method to delete(soft delete) details from CP_APP_IN_LQD_ASSET based on user selection.
		 * @param fwTxn
		 */
		public void deleteAssetsDetailsMC(FwTransaction txnBean) {
			try {

				UserDetails userDetails = txnBean.getUserDetails();
				String appNum = userDetails.getAppNumber();
				String categoryType = null;
				Integer indvSeqNum = null;
				Integer seqNum = null;
				APP_IN_LQD_ASET_Cargo lqdAsetDetails = null;
				if(txnBean.getPageCollection() != null && txnBean.getPageCollection().get(FinancialInfoConstants.APP_IN_LQD_ASET_COLL) != null) {
					APP_IN_LQD_ASET_Collection appInLqdAsetColl = (APP_IN_LQD_ASET_Collection) txnBean.getPageCollection().get(FinancialInfoConstants.APP_IN_LQD_ASET_COLL);
					lqdAsetDetails = appInLqdAsetColl.getCargo(0);
					categoryType = lqdAsetDetails.getLqd_aset_typ();
					indvSeqNum = lqdAsetDetails.getIndv_seq_num();
					seqNum = lqdAsetDetails.getSeq_num();
					APP_IN_LQD_ASET_Collection existingLqdColl = liquidAssetBO.loadIndividualLiquidAssetDetails(appNum,
							indvSeqNum, seqNum,categoryType);
					if(Objects.nonNull(existingLqdColl) && !existingLqdColl.isEmpty()) {
						APP_IN_LQD_ASET_Cargo existingCargo = existingLqdColl.getCargo(0);
						if(Objects.nonNull(existingCargo)) {
							existingCargo.setAsset_end_dt(lqdAsetDetails.getAsset_end_dt());
							appInLqdAsetRepository.save(existingCargo);
						}
					}
				}
				APP_IN_LQD_ASET_Collection appInLqdAsetColl = new APP_IN_LQD_ASET_Collection();
				APP_IN_LQD_ASET_Cargo appInLqdasetCargo = new APP_IN_LQD_ASET_Cargo();
				appInLqdasetCargo.setLqd_aset_typ(categoryType);
				appInLqdAsetColl.add(appInLqdasetCargo);
				txnBean.getPageCollection().put(FinancialInfoConstants.APP_IN_LQD_ASET_COLL, appInLqdAsetColl);
			}
			catch (final Exception e) {
				final FwException fe = AbstractBO.createFwException(this.getClass().getName(),
						FinancialInfoConstants.DELETE_ASSETS_INFO_DET, e);
				FwExceptionManager.handleException(e, this.getClass().getName(),
						FinancialInfoConstants.DELETE_ASSETS_INFO_DET, txnBean.getUserDetails().getAppNumber(),
						txnBean.getUserDetails().getLoginUserId(), true);

				FwLogger.log(this.getClass(), Level.ERROR, "deleteAssetsDetailsMC", fe);
				throw fe;
			}
			FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetsServImpl.deleteAssetsDetailsMC() - END");
		}
}
