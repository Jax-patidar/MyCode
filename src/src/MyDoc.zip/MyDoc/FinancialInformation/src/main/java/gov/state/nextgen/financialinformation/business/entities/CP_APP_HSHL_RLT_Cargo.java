package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;

public class CP_APP_HSHL_RLT_Cargo implements Serializable{

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name="app_num" )
    private String appNum;

    @Id
    @Column (name="ref_indv_seq_num" )
    private String refIndvSeqNum;

    @Id
    @Column (name="src_indv_seq_num" )
    private String srcIndvSeqNum;

    @Id
    @Column(name="SRC_APP_IND")
    private String srcAppIndiv;

    @Column (name="RLT_CD"   )
    private String rltCd;

    @Column (name="CHG_DT"   )
    private Date chg_dt;

    private String care_resp;

    private String rec_cplt_ind;

    @Embeddable
    public static class CP_APP_HSHL_RLT_Key implements Serializable {

        /**
		 * 
		 */
		private static final long serialVersionUID = -2705463483291884263L;
		private String appNum;
        private String refIndvSeqNum;
        private String srcIndvSeqNum;
        private String srcAppIndiv;

        public CP_APP_HSHL_RLT_Key(String appNum, String refIndvSeqNum, String srcIndvSeqNum, String srcAppIndiv) {
            this.appNum = appNum;
            this.refIndvSeqNum = refIndvSeqNum;
            this.srcIndvSeqNum = srcIndvSeqNum;
            this.srcAppIndiv = srcAppIndiv;
        }
        public CP_APP_HSHL_RLT_Key() {
        }
    }




    public String getCare_resp() {
        return care_resp;
    }

    public void setCare_resp(String care_resp) {
        this.care_resp = care_resp;
    }

    public String getRec_cplt_ind() {
        return rec_cplt_ind;
    }

    public void setRec_cplt_ind(String rec_cplt_ind) {
        this.rec_cplt_ind = rec_cplt_ind;
    }

    public String getAppNum() {
        return appNum;
    }

    public void setAppNum(String appNum) {
        this.appNum = appNum;
    }

    public String getSrcIndvSeqNum() {
        return srcIndvSeqNum;
    }

    public void setSrcIndvSeqNum(String srcIndvSeqNum) {
        this.srcIndvSeqNum = srcIndvSeqNum;
    }

    public Date getChg_dt() {
        return chg_dt;
    }

    public void setChg_dt(Date chg_dt) {
        this.chg_dt = chg_dt;
    }

    public String getRltCd() {
        return rltCd;
    }

    public void setRltCd(String rltCd) {
        this.rltCd = rltCd;
    }

    public String getSrcAppIndiv() {
        return srcAppIndiv;
    }

    public void setSrcAppIndiv(String srcAppIndiv) {
        this.srcAppIndiv = srcAppIndiv;
    }

    public String getRefIndvSeqNum() {
        return refIndvSeqNum;
    }

    public void setRefIndvSeqNum(String refIndvSeqNum) {
        this.refIndvSeqNum = refIndvSeqNum;
    }
}
