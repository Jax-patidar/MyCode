/**
 * 
 */
package gov.state.nextgen.financialinformation.business.services;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_L_INS_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_L_INS_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_LIF_INS_CVRG_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_LIF_INS_CVRG_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ASSETS_DISASTER_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_ASSETS_DISASTER_Collection;
import gov.state.nextgen.financialinformation.business.entities.Question_Cargo;
import gov.state.nextgen.financialinformation.business.entities.Question_Collection;
import gov.state.nextgen.financialinformation.business.rules.ABLIDValidator;
import gov.state.nextgen.financialinformation.business.rules.DisasterFinanceBO;
import gov.state.nextgen.financialinformation.business.rules.LifeInsuranceBO;
import gov.state.nextgen.financialinformation.business.rules.LiquidAssetBO;
import gov.state.nextgen.financialinformation.business.rules.VehicleAssetBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;

/**
 * @author khuskumari
 *
 */
@SuppressWarnings("squid:S2229")
@Service("OtherAssetService")
public class OtherAssetServImpl implements FinancialServInterface {

	@Autowired
	private LifeInsuranceBO lifeInsuranceDetailsBO;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private LiquidAssetBO liquidAssetBO;

	@Autowired
	private ABLIDValidator lifeInsDetailsValidator;

	@Autowired
	private VehicleAssetBO vehicleAssetBO;

	@Autowired
	private DisasterFinanceBO disasterFinanceBO;

	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {

		switch (methodName) {

		case FinancialInfoConstants.GET_LIFE_INSURANCE_DET:
			this.getLifeInsuranceDetails(fwTxn);
			break;

		case FinancialInfoConstants.STTORE_LIFE_INSUR_DET:
			this.storeLifeInsuranceDetails(fwTxn);
			break;

		case FinancialInfoConstants.GET_LIQ_ASSE_DET:
			this.getLiquidAssetDetails(fwTxn);
			break;

		case FinancialInfoConstants.STORE_LIQ_ASSET_DET:
			this.storeLiquidAssetDetails(fwTxn);

			break;

		case FinancialInfoConstants.STORE_DISASTER_ASSET_DETAILS:
			this.storeDisasterAssetDetails(fwTxn);
			break;

		case FinancialInfoConstants.LOAD_DISASTER_ASSET_DETAILS:
			this.loadDisasterAssetDetails(fwTxn);
			break;

		default:
			break;

		}

	}

	@Transactional
	public void storeLiquidAssetDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetService.storeLiquidAssetDetails() - START",
				fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			final Map request = fwTxn.getRequest();
			String appNumber = fwTxn.getUserDetails().getAppNumber();

			Integer indv_seq_num = 0;
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence() != null
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indv_seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			Integer seq_num = 0;
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence() != null
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			String typ_cd = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();

			String showLoopingQuestion = (String) request.get("showLoopingQuestion");

			APP_IN_LQD_ASET_Collection appInLqdAsetColl = (APP_IN_LQD_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_LQD_ASET_COLL);
			APP_IN_LQD_ASET_Cargo appInLqdAsetCargo = new APP_IN_LQD_ASET_Cargo();

			if (appInLqdAsetColl != null && !appInLqdAsetColl.isEmpty())
				appInLqdAsetCargo = appInLqdAsetColl.getCargo(0);

			final APP_IN_LQD_ASET_Collection appInLqdAsetBeforeColl = liquidAssetBO.loadLiquidAssetData(appNumber,
					indv_seq_num, seq_num, typ_cd);
			APP_IN_LQD_ASET_Cargo appInLqdAsetBeforeCargo = null;

			APP_IN_JNT_OWN_Collection appInJntOwnColl = new APP_IN_JNT_OWN_Collection();

			final Question_Collection cashQCollection = (Question_Collection) pageCollection.get("Question_Collection");
			setQuestionnaire(appNumber, indv_seq_num, appInJntOwnColl, cashQCollection);
			pageCollection.put(FinancialInfoConstants.APP_IN_JNT_OWN_COLLECTION, appInJntOwnColl);

			appInJntOwnColl = (APP_IN_JNT_OWN_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_JNT_OWN_COLLECTION);

			final APP_IN_JNT_OWN_Collection appInJntBeforeColl = liquidAssetBO.loadIndividualJointOwnerDetailsCargo(
					appNumber, indv_seq_num, AppConstants.JOINT_OWNER_TYPE_LIQUID_ASSET, typ_cd, seq_num);

			setLiquidAssetCargo(appNumber, indv_seq_num, seq_num, typ_cd, appInLqdAsetCargo);

			if ((appInLqdAsetBeforeColl != null) && (!appInLqdAsetBeforeColl.isEmpty())) {

				setLiquidAssetCargo(pageCollection, appInLqdAsetCargo, appInJntOwnColl);
			}

			FwMessageList fwMessageList = liquidAssetBO.validate(appInLqdAsetCargo, showLoopingQuestion);
			if ((fwMessageList != null) && fwMessageList.hasMessages()) {
				pageCollection.put(FinancialInfoConstants.APP_IN_LQD_ASET_COLL, appInLqdAsetColl);
				pageCollection.put(FinancialInfoConstants.APP_IN_JNT_OWN_COLLECTION, appInJntOwnColl);
				request.put(FwConstants.MESSAGE_LIST, fwMessageList);
				return;
			}

			setLiquidAssetRec_Cplt(appInLqdAsetCargo);

			liquidAssetBO.storeLiquidAssetDetails(appInLqdAsetColl);

			APP_IN_JNT_OWN_Cargo appInJntOwnCargo = null;
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl = new APP_IN_JNT_OWN_Collection();
			APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo = null;

			if (appInJntOwnColl != null) {
				iterateJointOwnCargoLiqAsset(appInJntOwnColl);
			}

			if (appInJntBeforeColl != null) {
				setJointOwnLiqAssetCargo(appInLqdAsetCargo, appInJntOwnColl, appInJntBeforeColl, appInJntOwnNewColl);

			}

			fwMessageList = liquidAssetBO.validateJntOwnerPerc(appInJntOwnNewColl);
			if ((fwMessageList != null) && fwMessageList.hasMessages()) {

				pageCollection.put(FinancialInfoConstants.APP_IN_LQD_ASET_COLL, appInLqdAsetColl);
				pageCollection.put(FinancialInfoConstants.APP_IN_JNT_OWN_COLLECTION, appInJntOwnColl);
				request.put(FwConstants.MESSAGE_LIST, fwMessageList);
				return;
			}
			liquidAssetBO.storeJointOwnerDetails(appInJntOwnNewColl);

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeLiquidAssetDetails()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.STORE_LIQ_ASSET_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetService.storeLiquidAssetDetails() - END", fwTxn);

	}

	private void setJointOwnLiqAssetCargo(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo,
			APP_IN_JNT_OWN_Collection appInJntOwnColl, final APP_IN_JNT_OWN_Collection appInJntBeforeColl,
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl) {
		
			APP_IN_JNT_OWN_Cargo appInJntOwnCargo;
			APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo;
			final int appInjntBeforeCollSize = appInJntBeforeColl.size();
			for (int i = 0; i < appInjntBeforeCollSize; i++) {
				appInJntOwnBeforeCargo = appInJntBeforeColl.getCargo(i);
				appInJntOwnCargo = getMatchingCargo(appInJntOwnColl);

				if (appInJntOwnCargo == null) {
					appInJntOwnBeforeCargo.setRowAction(FwConstants.ROWACTION_DELETE);
					appInJntOwnNewColl.add(appInJntOwnBeforeCargo);
				} else {
					// now we need to check the dirty indicator
					appInJntOwnCargo.setApp_num(appInLqdAsetCargo.getApp_num());
					appInJntOwnCargo.setJnt_own_seq_num(appInLqdAsetCargo.getSeq_num());
					appInJntOwnCargo.setIndv_seq_num(appInLqdAsetCargo.getIndv_seq_num());
					appInJntOwnCargo.setAset_sub_typ(appInLqdAsetCargo.getLqd_aset_typ());
					appInJntOwnCargo.setAset_typ(AppConstants.JOINT_OWNER_TYPE_LIQUID_ASSET);
					if (appInJntOwnCargo.getSeq_num() == null) {
						appInJntOwnCargo.setSeq_num(appInJntOwnBeforeCargo.getSeq_num());
					}

					appInJntOwnNewColl.add(appInJntOwnCargo);
				}
			}
		
	}

	private void iterateJointOwnCargoLiqAsset(APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		try {
			int appInJntCollSize = appInJntOwnColl.size();
			APP_IN_JNT_OWN_Cargo jntOwnCargo = null;
			for (int i = 0; i < appInJntCollSize; i++) {
				jntOwnCargo = appInJntOwnColl.getCargo(i);
				if ((null != jntOwnCargo.getJnt_indv_seq_num()
						&& FwConstants.ZERO.equals(jntOwnCargo.getJnt_indv_seq_num().toString().trim()))
						&& ((jntOwnCargo.getJnt_own_fst_nam() == null)
								|| (jntOwnCargo.getJnt_own_fst_nam().trim().length() == 0))
						&& ((jntOwnCargo.getJnt_own_last_nam() == null)
								|| (jntOwnCargo.getJnt_own_last_nam().trim().length() == 0))
						&& ((jntOwnCargo.getOtsd_ind() == null) || (jntOwnCargo.getOtsd_ind().trim().length() == 0))) {
					appInJntOwnColl.remove(i);
					i--;
					appInJntCollSize--;
				}
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in iterateJointOwnCargoLiqAsset()", e);
			throw e;
		}
	}

	private void setLiquidAssetRec_Cplt(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo) {
		try {
			String type = appInLqdAsetCargo.getLqd_aset_typ();
			if (!"FA".equals(type.trim()) && !"CAS".equals(type.trim())) {
				final double amt = appInLqdAsetCargo.getLqd_aset_amt();
				if (FinancialInfoConstants.ZERO_DOUBLE == amt) {
					appInLqdAsetCargo.setRec_cplt_ind(FwConstants.ONE);
				} else {
					appInLqdAsetCargo.setRec_cplt_ind(FwConstants.ZERO);
				}
			}
			if ("FA".equals(type.trim()) || "CAS".equals(type.trim())) {
				appInLqdAsetCargo.setRec_cplt_ind(FwConstants.ONE);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in setLiquidAssetRec_Cplt()", e);
			throw e;
		}
	}

	private void setLiquidAssetCargo(String appNumber, Integer indv_seq_num, Integer seq_num, String typ_cd,
			APP_IN_LQD_ASET_Cargo appInLqdAsetCargo) {
		
			appInLqdAsetCargo.setApp_num(appNumber);
			appInLqdAsetCargo.setIndv_seq_num(indv_seq_num);
			appInLqdAsetCargo.setSeq_num(seq_num);
			appInLqdAsetCargo.setSrc_app_ind(FinancialInfoConstants.SRC_APP_AFB);
			appInLqdAsetCargo.setLqd_aset_typ(typ_cd);
			appInLqdAsetCargo.setRec_cplt_ind(FwConstants.ONE);
		
	}

	private void setLiquidAssetCargo(Map pageCollection, APP_IN_LQD_ASET_Cargo appInLqdAsetCargo,
			APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		
			if (appInLqdAsetCargo.getLqd_aset_amt_ind() == null) {
				if ((FinancialInfoConstants.ZERO_DOUBLE) == appInLqdAsetCargo.getLqd_aset_amt()) {
					appInLqdAsetCargo.setLqd_aset_amt(FinancialInfoConstants.ZERO_DOUBLE);
					appInLqdAsetCargo.setLqd_aset_amt_ind(FinancialInfoConstants.TWO);
				} else {
					appInLqdAsetCargo.setLqd_aset_amt_ind(FinancialInfoConstants.ZERO);
				}
			} else if ((FinancialInfoConstants.ZERO_DOUBLE) == appInLqdAsetCargo.getLqd_aset_amt()) {
				appInLqdAsetCargo.setLqd_aset_amt(FinancialInfoConstants.ZERO_DOUBLE);
				appInLqdAsetCargo.setLqd_aset_amt_ind(FinancialInfoConstants.ONE);
			} else {
				pageCollection.put("AmtAndIndChecked", FwConstants.ONE);
			}
			if (appInJntOwnColl != null) {
				iterateJoinOwnCargoLiquidAsset(appInJntOwnColl);
			}

			if ((appInJntOwnColl != null) && (!appInJntOwnColl.isEmpty())) {
				appInLqdAsetCargo.setJnt_own_resp(FwConstants.YES);
			} else {
				appInLqdAsetCargo.setJnt_own_resp(FwConstants.NO);
			}
		
	}

	private void iterateJoinOwnCargoLiquidAsset(APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		
			int appInJntCollSize = appInJntOwnColl.size();
			APP_IN_JNT_OWN_Cargo jntOwnCargo = null;
			for (int i = 0; i < appInJntCollSize; i++) {
				jntOwnCargo = appInJntOwnColl.getCargo(i);
				if (FwConstants.YES.equals(jntOwnCargo.getOtsd_ind())) {
					continue;
				}
				if (!FwConstants.YES.equals(jntOwnCargo.getAset_typ())) {
					appInJntOwnColl.remove(i);
					i--;
					appInJntCollSize--;
				}
			}
		
	}

	private void setQuestionnaire(String appNumber, Integer indv_seq_num, APP_IN_JNT_OWN_Collection appInJntOwnColl,
			final Question_Collection cashQCollection) {
		
			if (cashQCollection != null && !cashQCollection.isEmpty()) {
				for (Question_Cargo cashQCargo : cashQCollection.getResults()) {
					if ("true".equalsIgnoreCase(cashQCargo.getSelected())) {
						APP_IN_JNT_OWN_Collection tempcollection = new APP_IN_JNT_OWN_Collection();
						APP_IN_JNT_OWN_Cargo tempcargo = new APP_IN_JNT_OWN_Cargo();
						tempcargo.setApp_num(appNumber);
						tempcargo.setJnt_indv_seq_num(Integer.parseInt(cashQCargo.getIndvSeqNumber()));
						tempcargo.setIndv_seq_num(indv_seq_num);
						tempcargo.setJnt_own_share(Double.parseDouble(cashQCargo.getShareValue()));
						tempcollection.addCargo(tempcargo);
						appInJntOwnColl.addAll(tempcollection);
					}
				}
			}
		
	}

	@Transactional
	public void getLiquidAssetDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetService.getLiquidAssetDetails() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();

			String appNumber = fwTxn.getUserDetails().getAppNumber();

			Integer indv_seq_num = 0;
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence() != null
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indv_seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			Integer seq_num = 0;
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence() != null
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			String typ_cd = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			APP_IN_LQD_ASET_Collection collSes;

			collSes = liquidAssetBO.loadLiquidAssetData(appNumber, indv_seq_num, seq_num, typ_cd);

			APP_IN_LQD_ASET_Cargo asetCargo = new APP_IN_LQD_ASET_Cargo();
			int size = 0;
			if (collSes != null && !collSes.isEmpty())
				size = collSes.size();
			if (size > 0) {
				asetCargo = collSes.getCargo(size - 1);
			} else {
				asetCargo.setApp_num(appNumber);
				asetCargo.setIndv_seq_num(indv_seq_num);
				asetCargo.setSeq_num(seq_num);
				asetCargo.setLqd_aset_typ("TR");
			}
			final APP_IN_LQD_ASET_Collection newColl = new APP_IN_LQD_ASET_Collection();
			newColl.addCargo(asetCargo);
			pageCollection.put(FinancialInfoConstants.APP_IN_LQD_ASET_COLL, newColl);

			// set Details_Collection from session to PageCollection
			setCargoValuesFromPageCollection(pageCollection, appNumber);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getLiquidAssetDetails()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_LIQ_ASSE_DET,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetService.getLiquidAssetDetails() - END", fwTxn);
	}

	private void setCargoValuesFromPageCollection(Map pageCollection, String appNumber) {
		try {
			final APP_IN_LQD_ASET_Collection liqAsetColl = (APP_IN_LQD_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_LQD_ASET_COLL);
			if ((liqAsetColl != null) && (!liqAsetColl.isEmpty())) {
				final APP_IN_LQD_ASET_Cargo appLiqAsetCargo = liqAsetColl.getCargo(0);
				if (appLiqAsetCargo.getSeq_num() != null) {
					final APP_IN_JNT_OWN_Collection appInJntCol = liquidAssetBO.loadIndividualJointOwnerDetailsCargo(
							appNumber, appLiqAsetCargo.getIndv_seq_num(), AppConstants.JOINT_OWNER_TYPE_LIQUID_ASSET,
							appLiqAsetCargo.getLqd_aset_typ(), appLiqAsetCargo.getSeq_num());
					if ((appInJntCol != null) && (!appInJntCol.isEmpty())) {
						pageCollection.put(FinancialInfoConstants.APP_IN_JNT_OWN_COLLECTION, appInJntCol);
					}
				}
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in setCargoValuesFromPageCollection()",
					e);
			throw e;
		}
	}

	/**
	 * store method for Life Insurance Type screen
	 * 
	 * @param fwTxn
	 */
	@Transactional
	@SuppressWarnings("squid:S3776")
	public void storeLifeInsuranceDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetService.storeLifeInsuranceDetails() - START");
		try {
			final Map request = fwTxn.getRequest();
			Map pageCollection = fwTxn.getPageCollection();

			String appNumber = fwTxn.getUserDetails().getAppNumber();
			Integer indv_seq_num = 0;
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence() != null
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indv_seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			Integer seqNum = 0;
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence() != null
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			String typ_cd = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();

			APP_IN_L_INS_ASET_Collection appInLifeInsureCollReq = (APP_IN_L_INS_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_L_INS_ASET_COLLECTION);
			APP_IN_JNT_OWN_Collection appInJntOwnColl = (APP_IN_JNT_OWN_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_JNT_OWN_COLLECTION);

			CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCvrgColl = (CP_APP_IN_LIF_INS_CVRG_Collection) pageCollection
					.get(FinancialInfoConstants.CP_APP_IN_LIF_INS_CVRG_COLLECTION);

			APP_IN_L_INS_ASET_Cargo lifeinsureCargoReq = new APP_IN_L_INS_ASET_Cargo();

			if (appInLifeInsureCollReq != null && !appInLifeInsureCollReq.isEmpty())
				lifeinsureCargoReq = appInLifeInsureCollReq.getCargo(0);

			APP_IN_L_INS_ASET_Collection beforeLifeInsureColl = lifeInsuranceDetailsBO
					.loadIndividualLifeInsuranceDetails(appNumber, indv_seq_num, seqNum, typ_cd);
			APP_IN_JNT_OWN_Collection appInJntBeforeColl = vehicleAssetBO.loadIndividualJointOwnerDetails(appNumber,
					indv_seq_num, AppConstants.JOINT_OWNER_TYPE_INSURANCE_ASSET, typ_cd, seqNum);
			CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCvrgBeforeColl = lifeInsuranceDetailsBO
					.loadInsPolicyPersonDetails(appNumber, indv_seq_num, seqNum);

			boolean amtEnteredF = false;
			boolean amtEnteredS = false;

			lifeinsureCargoReq.setApp_num(appNumber);
			lifeinsureCargoReq.setIndv_seq_num(indv_seq_num);
			lifeinsureCargoReq.setSeq_num(seqNum);
			lifeinsureCargoReq.setSrc_app_ind(FinancialInfoConstants.SRC_APP_AFB);
			lifeinsureCargoReq.setLife_ins_aset_typ(typ_cd);

			if ((beforeLifeInsureColl != null) && !beforeLifeInsureColl.isEmpty()) {
				setInsuranceAssetDetails(appInJntOwnColl, appInLifInsCvrgColl, lifeinsureCargoReq,
						beforeLifeInsureColl);
			}
			// This is for Face Value
			amtEnteredF = setFaceValue(pageCollection, lifeinsureCargoReq, amtEnteredF);
			// This is for Surrender Value

			amtEnteredS = setSurrenderValue(pageCollection, lifeinsureCargoReq, amtEnteredS);

			if (!"0".equals(Float.toString(lifeinsureCargoReq.getLife_ins_face_amt()))) {
				lifeinsureCargoReq.setRec_cplt_ind("1");
			} else {
				if (lifeinsureCargoReq.getLife_ins_surr_amt() != 0) {
					amtEnteredS = true;
					pageCollection.put("AmtAndIndChecked_S", FwConstants.ONE);
				}
			}

			validateInsuranceDetails(lifeinsureCargoReq, amtEnteredF, amtEnteredS);

			if (null != lifeInsDetailsValidator && null != lifeInsDetailsValidator.messageList
					&& lifeInsDetailsValidator.messageList.hasMessages()) {

				request.put(FwConstants.MESSAGE_LIST, lifeInsDetailsValidator.messageList);
				pageCollection.put(FinancialInfoConstants.APP_IN_JNT_OWN_COLLECTION, appInJntOwnColl);
				pageCollection.put(FinancialInfoConstants.CP_APP_IN_LIF_INS_CVRG_COLLECTION, appInLifInsCvrgColl);

				return;
			}

			if (!"0".equals(Float.toString(lifeinsureCargoReq.getLife_ins_face_amt()))) {
				lifeinsureCargoReq.setRec_cplt_ind("1");
			} else {
				lifeinsureCargoReq.setRec_cplt_ind("0");
			}
			lifeInsuranceDetailsBO.storeLifeInsDetails(appInLifeInsureCollReq);

			lifeinsureCargoReq = appInLifeInsureCollReq.getCargo(0);
			APP_IN_JNT_OWN_Cargo appInJntOwnCargo = null;
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl = new APP_IN_JNT_OWN_Collection();
			APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo = null;
			if (appInJntOwnColl != null) {
				setJoinOwnerColl(appInJntOwnColl);
			}
			final CP_APP_IN_LIF_INS_CVRG_Cargo cpAppInLifInsCvrgCargo = null;

			if (appInLifInsCvrgColl != null) {
				setLifeInsCoverageColl(appInLifInsCvrgColl);
			}
			// user pressed back and the before collection is not null delete it
			// else update it.
			deleteOrUpdateAssets(appInJntOwnColl, lifeinsureCargoReq, appInJntBeforeColl, appInJntOwnNewColl);
			// values entered and when the user tries to save the record first time
			saveRecordForFirstTime(appInJntOwnColl, lifeinsureCargoReq, appInJntBeforeColl, appInJntOwnNewColl);

			storeOtherAssetDetails(appInLifInsCvrgColl, lifeinsureCargoReq, appInLifInsCvrgBeforeColl,
					appInJntOwnNewColl);

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeLifeInsuranceDetails()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.STTORE_LIFE_INSUR_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetService.storeLifeInsuranceDetails() - END ");
	}

	private void storeOtherAssetDetails(CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCvrgColl,
			APP_IN_L_INS_ASET_Cargo lifeinsureCargoReq, CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCvrgBeforeColl,
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl) {
		try {
			vehicleAssetBO.storeJointOwnerDetails(appInJntOwnNewColl);

			final CP_APP_IN_LIF_INS_CVRG_Collection newLifInsCollection = new CP_APP_IN_LIF_INS_CVRG_Collection();
			if (appInLifInsCvrgColl != null) {
				setInsCoverageCargo(appInLifInsCvrgColl, lifeinsureCargoReq, newLifInsCollection);
			}

			final CP_APP_IN_LIF_INS_CVRG_Collection deleteLifeInsCollection = new CP_APP_IN_LIF_INS_CVRG_Collection();
			if ((appInLifInsCvrgBeforeColl != null) && (appInLifInsCvrgColl != null)) {
				deleteInsCoverageColl(appInLifInsCvrgColl, appInLifInsCvrgBeforeColl, deleteLifeInsCollection);
			}

			lifeInsuranceDetailsBO.storeInsPolicyPersonDetails(newLifInsCollection);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeOtherAssetDetails()", e);
			throw e;
		}
	}

	private boolean setSurrenderValue(Map pageCollection, APP_IN_L_INS_ASET_Cargo lifeinsureCargoReq,
			boolean amtEnteredS) {
		
			if (lifeinsureCargoReq.getLife_ins_s_amt_ind() == null) {
				if (lifeinsureCargoReq.getLife_ins_surr_amt() == 0) {
					lifeinsureCargoReq.setLife_ins_s_amt_ind(FinancialInfoConstants.TWO);
				} else {
					lifeinsureCargoReq.setLife_ins_s_amt_ind(FinancialInfoConstants.ZERO);
				}
			} else {
				if (lifeinsureCargoReq.getLife_ins_surr_amt() != 0) {
					amtEnteredS = true;
					pageCollection.put("AmtAndIndChecked_S", FwConstants.ONE);
				}
			}
			return amtEnteredS;
	}

	private boolean setFaceValue(Map pageCollection, APP_IN_L_INS_ASET_Cargo lifeinsureCargoReq, boolean amtEnteredF) {
		
			if (lifeinsureCargoReq.getLife_ins_f_amt_ind() == null) {
				lifeinsureCargoReq.setLife_ins_face_amt(FinancialInfoConstants.ZERO);
				lifeinsureCargoReq.setLife_ins_f_amt_ind(FinancialInfoConstants.TWO);

			} else {
				if (lifeinsureCargoReq.getLife_ins_face_amt() != 0) {
					amtEnteredF = true;
					pageCollection.put("AmtAndIndChecked_F", FwConstants.ONE);
				}
			}
			return amtEnteredF;
	}

	private void deleteInsCoverageColl(CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCvrgColl,
			CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCvrgBeforeColl,
			final CP_APP_IN_LIF_INS_CVRG_Collection deleteLifeInsCollection) {
		try {
			CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsCvrgCargo;
			CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsCvrgBeforeCargo;
			for (int i = 0; i < appInLifInsCvrgBeforeColl.size(); i++) {
				appInLifInsCvrgBeforeCargo = (CP_APP_IN_LIF_INS_CVRG_Cargo) appInLifInsCvrgBeforeColl.get(i);
				appInLifInsCvrgCargo = getMatchingInsCVRGCargo(appInLifInsCvrgColl, appInLifInsCvrgBeforeCargo);
				if ((appInLifInsCvrgCargo == null)
						|| (appInLifInsCvrgBeforeCargo.hashCode() != appInLifInsCvrgCargo.hashCode())) {
					appInLifInsCvrgBeforeCargo.setRowAction(FwConstants.ROWACTION_DELETE);
					deleteLifeInsCollection.add(appInLifInsCvrgBeforeCargo);
				}
			}
			if (!deleteLifeInsCollection.isEmpty()) {
				lifeInsuranceDetailsBO.storeInsPolicyPersonDetails(deleteLifeInsCollection);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in deleteInsCoverageColl()", e);
			throw e;
		}
	}

	private void setInsCoverageCargo(CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCvrgColl,
			APP_IN_L_INS_ASET_Cargo lifeinsureCargoReq, final CP_APP_IN_LIF_INS_CVRG_Collection newLifInsCollection) {
		CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsCvrgCargo;
		
			for (int i = 0; i < appInLifInsCvrgColl.size(); i++) {
				appInLifInsCvrgCargo = (CP_APP_IN_LIF_INS_CVRG_Cargo) appInLifInsCvrgColl.get(i);
				appInLifInsCvrgCargo.setRec_cplt_ind(Integer.parseInt(lifeinsureCargoReq.getRec_cplt_ind()));
				appInLifInsCvrgCargo.setSrc_app_ind("AB");
				appInLifInsCvrgCargo.setApp_num(lifeinsureCargoReq.getApp_num());
				appInLifInsCvrgCargo.setIndv_seq_num(lifeinsureCargoReq.getIndv_seq_num());
				appInLifInsCvrgCargo.setCovered_seq_num(lifeinsureCargoReq.getSeq_num());
				newLifInsCollection.add(appInLifInsCvrgCargo);
			}
		
	}

	private void setLifeInsCoverageColl(CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCvrgColl) {
		
			int cpAppInLifInsCollSize = appInLifInsCvrgColl.size();
			CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsCargo = null;
			for (int i = 0; i < cpAppInLifInsCollSize; i++) {
				appInLifInsCargo = appInLifInsCvrgColl.getCargo(i);
				if ((appInLifInsCargo.getCovered_indv_seq_num() != null)
						&& 0 == (appInLifInsCargo.getCovered_indv_seq_num())
						&& ((appInLifInsCargo.getFirst_name() == null)
								|| (appInLifInsCargo.getFirst_name().trim().length() == 0))
						&& ((appInLifInsCargo.getLast_name() == null)
								|| (appInLifInsCargo.getLast_name().trim().length() == 0))) {
					appInLifInsCvrgColl.remove(i);
					i--;
					cpAppInLifInsCollSize--;
				}
			}
	}

	private void validateInsuranceDetails(APP_IN_L_INS_ASET_Cargo lifeinsureCargoReq, boolean amtEnteredF,
			boolean amtEnteredS) {
		try {
			lifeInsDetailsValidator.validatePageContents(lifeinsureCargoReq, amtEnteredF, "face");
			lifeInsDetailsValidator.validatePageContents(lifeinsureCargoReq, amtEnteredS, "surrender");
			lifeInsDetailsValidator.validateAddressContents(lifeinsureCargoReq);
			lifeInsDetailsValidator.validateRestOfPageContents(lifeinsureCargoReq);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in validateInsuranceDetails()", e);
			throw e;
		}
	}

	private void setInsuranceAssetDetails(APP_IN_JNT_OWN_Collection appInJntOwnColl,
			CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCvrgColl, APP_IN_L_INS_ASET_Cargo lifeinsureCargoReq,
			APP_IN_L_INS_ASET_Collection beforeLifeInsureColl) {
		APP_IN_L_INS_ASET_Cargo beforeCargo;
		
			beforeCargo = beforeLifeInsureColl.getCargo(0);
			lifeinsureCargoReq.setLife_ins_aset_typ(beforeCargo.getLife_ins_aset_typ());
			lifeinsureCargoReq.setSeq_num(beforeCargo.getSeq_num());

			if (appInJntOwnColl != null) {
				iterateJoinOwnCargoLiquidAsset(appInJntOwnColl);
			}
			// ESDP - CP Start Insured Policy person box
			setInsuredPolicyCargo(appInLifInsCvrgColl);
			// ESDP - CP End Insured Policy person box

			if ((appInJntOwnColl != null) && (!appInJntOwnColl.isEmpty())) {
				lifeinsureCargoReq.setJnt_own_resp(FwConstants.YES);
			} else {
				lifeinsureCargoReq.setJnt_own_resp(FwConstants.NO);
			}
		
	}

	private void setJoinOwnerColl(APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		
			int appInJntCollSize = appInJntOwnColl.size();
			APP_IN_JNT_OWN_Cargo jntOwnCargo = null;
			for (int i = 0; i < appInJntCollSize; i++) {
				jntOwnCargo = appInJntOwnColl.getCargo(i);
				if ((jntOwnCargo.getJnt_indv_seq_num() != null) && 0 == (jntOwnCargo.getJnt_indv_seq_num())
						&& ((jntOwnCargo.getJnt_own_fst_nam() == null)
								|| (jntOwnCargo.getJnt_own_fst_nam().trim().length() == 0))
						&& ((jntOwnCargo.getJnt_own_last_nam() == null)
								|| (jntOwnCargo.getJnt_own_last_nam().trim().length() == 0))
						&& ((jntOwnCargo.getOtsd_ind() == null) || (jntOwnCargo.getOtsd_ind().trim().length() == 0))) {
					appInJntOwnColl.remove(i);
					i--;
					appInJntCollSize--;
				}
			}
		
	}

	private void setInsuredPolicyCargo(CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCvrgColl) {
		
			if (appInLifInsCvrgColl != null) {
				int appInLifInsCvrgSize = appInLifInsCvrgColl.size();
				CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsCargo = null;
				for (int i = 0; i < appInLifInsCvrgSize; i++) {
					appInLifInsCargo = appInLifInsCvrgColl.getCargo(i);
					if ((appInLifInsCargo.getCovered_indv_seq_num() != null)
							&& FwConstants.ZERO.equals(appInLifInsCargo.getCovered_indv_seq_num().toString().trim())
							&& ((appInLifInsCargo.getFirst_name() == null)
									|| (appInLifInsCargo.getFirst_name().trim().length() == 0))
							&& ((appInLifInsCargo.getLast_name() == null)
									|| (appInLifInsCargo.getLast_name().trim().length() == 0))) {
						appInLifInsCvrgColl.remove(i);
						i--;
						appInLifInsCvrgSize--;
					}
				}
			}
		
	}

	private void saveRecordForFirstTime(APP_IN_JNT_OWN_Collection appInJntOwnColl,
			APP_IN_L_INS_ASET_Cargo lifeinsureCargoReq, APP_IN_JNT_OWN_Collection appInJntBeforeColl,
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl) {
		APP_IN_JNT_OWN_Cargo appInJntOwnCargo;
		APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo;
		
			if (appInJntOwnColl != null) {
				final int appInJntCollSize = appInJntOwnColl.size();
				for (int i = 0; i < appInJntCollSize; i++) {
					appInJntOwnCargo = appInJntOwnColl.getCargo(i);
					appInJntOwnBeforeCargo = getMatchingCargo(appInJntBeforeColl);
					if (appInJntOwnBeforeCargo == null) {
						setValuesIfFirstTime(lifeinsureCargoReq, appInJntOwnNewColl, appInJntOwnCargo);
					}
				}
			}
		
	}

	private void setValuesIfFirstTime(APP_IN_L_INS_ASET_Cargo lifeinsureCargoReq,
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl, APP_IN_JNT_OWN_Cargo appInJntOwnCargo) {
		
			appInJntOwnCargo.setApp_num(lifeinsureCargoReq.getApp_num());
			appInJntOwnCargo.setJnt_own_seq_num(lifeinsureCargoReq.getSeq_num());
			appInJntOwnCargo.setIndv_seq_num(lifeinsureCargoReq.getIndv_seq_num());
			appInJntOwnCargo.setAset_sub_typ(lifeinsureCargoReq.getLife_ins_aset_typ());
			appInJntOwnCargo.setAset_typ(AppConstants.JOINT_OWNER_TYPE_INSURANCE_ASSET);
			if (appInJntOwnCargo.getJnt_own_fst_nam() == null) {
				appInJntOwnCargo.setJnt_own_fst_nam(FwConstants.SPACE);
			}
			if (appInJntOwnCargo.getJnt_own_last_nam() == null) {
				appInJntOwnCargo.setJnt_own_last_nam(FwConstants.SPACE);
			}
			if (appInJntOwnCargo.getOtsd_ind() == null) {
				appInJntOwnCargo.setOtsd_ind(FwConstants.SPACE);
			}
			if (appInJntOwnCargo.getSeq_num() == null) {
				appInJntOwnCargo.setSeq_num(0);
			}
			appInJntOwnNewColl.add(appInJntOwnCargo);
		
	}

	private void deleteOrUpdateAssets(APP_IN_JNT_OWN_Collection appInJntOwnColl,
			APP_IN_L_INS_ASET_Cargo lifeinsureCargoReq, APP_IN_JNT_OWN_Collection appInJntBeforeColl,
			final APP_IN_JNT_OWN_Collection appInJntOwnNewColl) {
		APP_IN_JNT_OWN_Cargo appInJntOwnCargo;
		APP_IN_JNT_OWN_Cargo appInJntOwnBeforeCargo;
		
			if (appInJntBeforeColl != null) {
				final int appInjntBeforeCollSize = appInJntBeforeColl.size();
				for (int i = 0; i < appInjntBeforeCollSize; i++) {
					appInJntOwnBeforeCargo = appInJntBeforeColl.getCargo(i);
					appInJntOwnCargo = getMatchingCargo(appInJntOwnColl);
					if (appInJntOwnCargo == null) {
						appInJntOwnBeforeCargo.setRowAction(FwConstants.ROWACTION_DELETE);
						appInJntOwnNewColl.add(appInJntOwnBeforeCargo);
					} else {
						appInJntOwnCargo.setApp_num(lifeinsureCargoReq.getApp_num());
						appInJntOwnCargo.setJnt_own_seq_num(lifeinsureCargoReq.getSeq_num());
						appInJntOwnCargo.setIndv_seq_num(lifeinsureCargoReq.getIndv_seq_num());
						appInJntOwnCargo.setAset_sub_typ(lifeinsureCargoReq.getLife_ins_aset_typ());
						appInJntOwnCargo.setAset_typ(AppConstants.JOINT_OWNER_TYPE_INSURANCE_ASSET);
						if (appInJntOwnCargo.getSeq_num() == null) {
							appInJntOwnCargo.setSeq_num(appInJntOwnBeforeCargo.getSeq_num());
						}
						appInJntOwnNewColl.add(appInJntOwnCargo);

					}
				}
			}
	}

	public CP_APP_IN_LIF_INS_CVRG_Cargo getMatchingInsCVRGCargo(CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsColl,
			CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsBeforeCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetService.getMatchingInsCVRGCargo() - START");
		try {
			if ((appInLifInsColl == null) || (appInLifInsColl.isEmpty())) {
				return null;
			}
			final int appInLifInsCollSize = appInLifInsColl.size();
			CP_APP_IN_LIF_INS_CVRG_Cargo appInLifInsCargo = null;
			final Integer coveredIndvSeqNum = appInLifInsBeforeCargo.getCovered_indv_seq_num();
			String otsdJntInd = null;
			if (!appInLifInsColl.isEmpty()) {
				for (int i = 0; i < appInLifInsCollSize; i++) {
					appInLifInsCargo = appInLifInsColl.getCargo(i);
					if (appInLifInsCargo.getCovered_indv_seq_num().equals(coveredIndvSeqNum)) {
						return appInLifInsCargo;
					}
				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"OtherAssetService.getMatchingInsCVRGCargo() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime));

			return null;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getMatchingInsCVRGCargo()", e);
			throw e;
		}
	}

	public APP_IN_JNT_OWN_Cargo getMatchingCargo(APP_IN_JNT_OWN_Collection appInJntOwnColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetService.getMatchingCargo() - START");
		try {
			if (appInJntOwnColl.isEmpty()) {
				return null;
			}
			final int appInJntCollSize = appInJntOwnColl.size();
			APP_IN_JNT_OWN_Cargo appInJntOwnCargo = null;

			String otsdJntInd = null;
			if (!appInJntOwnColl.isEmpty()) {
				for (int i = 0; i < appInJntCollSize; i++) {
					appInJntOwnCargo = appInJntOwnColl.getCargo(i);

					if ((appInJntOwnCargo.getJnt_indv_seq_num() != null)) {

						return appInJntOwnCargo;
					}
				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"OtherAssetService.getMatchingCargo() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime));
			return null;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getMatchingCargo()", e);
			throw e;
		}
	}

	/**
	 * load method for Life Insurance Type screen
	 * 
	 * @param fwTxn
	 */
	@Transactional
	public void getLifeInsuranceDetails(FwTransaction fwTxn) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetService.getLifeInsuranceDetails() - START",
				fwTxn);
		try {

			Map pageCollection;

			String appNumber = fwTxn.getUserDetails().getAppNumber();
			Integer indvSeqNum = 0;
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence() != null
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			Integer seq_num = 0;
			if (fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence() != null
					&& !"".equalsIgnoreCase(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seq_num = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			String typ_cd = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();

			pageCollection = new HashMap();
			// check if type needs to be passed as well
			APP_IN_L_INS_ASET_Collection assetCollection = lifeInsuranceDetailsBO
					.loadIndividualLifeInsuranceDetails(appNumber, indvSeqNum, seq_num, typ_cd);

			APP_IN_L_INS_ASET_Cargo asetCargo = new APP_IN_L_INS_ASET_Cargo();
			int size = 0;
			if (assetCollection != null && !assetCollection.isEmpty())
				size = assetCollection.size();
			if (size > 0) {
				asetCargo = assetCollection.getCargo(size - 1);
			}
			final APP_IN_L_INS_ASET_Collection newColl = new APP_IN_L_INS_ASET_Collection();
			newColl.addCargo(asetCargo);

			pageCollection.put(FinancialInfoConstants.APP_IN_L_INS_ASET_COLLECTION, newColl);

			final APP_IN_L_INS_ASET_Collection insAsetColl = (APP_IN_L_INS_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_L_INS_ASET_COLLECTION);
			if ((insAsetColl != null) && (!insAsetColl.isEmpty())) {
				setInsuranceAssetCargo(pageCollection, appNumber, insAsetColl);
			}
			// Insured policy person box
			if ((insAsetColl != null) && (!insAsetColl.isEmpty())) {
				setInsurancePolityDetailsCargot(pageCollection, appNumber, insAsetColl);
			}

			fwTxn.setPageCollection(pageCollection);
		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in getLifeInsuranceDetails()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.STORE_LIQ_ASSET_DET, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetService.getLifeInsuranceDetails() - END", fwTxn);
	}

	private void setInsuranceAssetCargo(Map pageCollection, String appNumber,
			final APP_IN_L_INS_ASET_Collection insAsetColl) {
		try {
			final APP_IN_L_INS_ASET_Cargo insAsetCargo = insAsetColl.getCargo(0);
			final String subType = insAsetCargo.getLife_ins_aset_typ();
			final Integer indvSeqNum = insAsetCargo.getIndv_seq_num();

			if (insAsetCargo.getSeq_num() != null) {
				final APP_IN_JNT_OWN_Collection appInJntCol = vehicleAssetBO.loadIndividualJointOwnerDetails(appNumber,
						indvSeqNum, AppConstants.JOINT_OWNER_TYPE_INSURANCE_ASSET, subType, insAsetCargo.getSeq_num());
				if ((appInJntCol != null) && (!appInJntCol.isEmpty())) {
					pageCollection.put(FinancialInfoConstants.APP_IN_JNT_OWN_COLLECTION, appInJntCol);
				}
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in setInsuranceAssetCargo()", e);
			throw e;
		}
	}

	/***************************************************************************************************************************************************************************************
	 * 
	 * store method to save details of Disaster Asset Details
	 * 
	 * @param fwTxn
	 * @author arunkuj
	 * 
	 ***************************************************************************************************************************************************************************************/
	private void storeDisasterAssetDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetServImpl.storeDisasterAssetDetails() - START");

		String appNumber = fwTxn.getUserDetails().getAppNumber();
		Map<String, Object> pageCollection = fwTxn.getPageCollection();
		try {
			if (pageCollection.get(FinancialInfoConstants.CP_ASSETS_DISASTER_COLLECTION) != null) {
				CP_ASSETS_DISASTER_Collection cpAssetsDiasasterCollection = (CP_ASSETS_DISASTER_Collection) pageCollection
						.get(FinancialInfoConstants.CP_ASSETS_DISASTER_COLLECTION);
				CP_ASSETS_DISASTER_Cargo cpAssetsDisasterCargo = cpAssetsDiasasterCollection.getCargo(0);
				if (null != cpAssetsDisasterCargo) {
					cpAssetsDisasterCargo.setApp_num(appNumber);
					cpAssetsDisasterCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);

					disasterFinanceBO.storeAssetDisaterDetails(cpAssetsDisasterCargo);
				}
			}
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeDisasterAssetDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherAssetServImpl.storeDisasterAssetDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + " milliseconds");
	}

	/***************************************************************************************************************************************************************************************
	 * 
	 * Method to load details of Disaster Asset Details based on appNumber
	 * 
	 * @param fwTxn
	 * @author arunkuj
	 * 
	 ***************************************************************************************************************************************************************************************/

	private void loadDisasterAssetDetails(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherAssetServImpl.storeDisasterAssetDetails() - START");
		String appNumber = fwTxn.getUserDetails().getAppNumber();
		Map<String, Object> pageCollection = fwTxn.getPageCollection();
		try {
			if (null != appNumber) {
				CP_ASSETS_DISASTER_Collection cpAssetsDiasasterCollection = disasterFinanceBO
						.getAssestDisaterDetails(appNumber);
				pageCollection.put(FinancialInfoConstants.CP_ASSETS_DISASTER_COLLECTION, cpAssetsDiasasterCollection);
			}
		} catch (Exception exception) {
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadDisasterAssetDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherAssetServImpl.storeDisasterAssetDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + " milliseconds");
	}

	private void setInsurancePolityDetailsCargot(Map pageCollection, String appNumber,
			final APP_IN_L_INS_ASET_Collection insAsetColl) {
		try {
			final APP_IN_L_INS_ASET_Cargo insAsetCargo = insAsetColl.getCargo(0);
			final Integer indvSeqNum = insAsetCargo.getIndv_seq_num();
			insAsetCargo.getSrc_app_ind();
			if (insAsetCargo.getSeq_num() != null) {
				final CP_APP_IN_LIF_INS_CVRG_Collection appInLifInsCol = lifeInsuranceDetailsBO
						.loadInsPolicyPersonDetails(appNumber, indvSeqNum, insAsetCargo.getSeq_num());
				if ((appInLifInsCol != null) && (!appInLifInsCol.isEmpty())) {
					pageCollection.put(FinancialInfoConstants.CP_APP_IN_LIF_INS_CVRG_COLLECTION, appInLifInsCol);
				}
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in setInsurancePolityDetailsCargot()",
					e);
			throw e;
		}
	}
}
