/*
 * 
 */
package gov.state.nextgen.financialinformation.business.rules;

import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_L_INS_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_L_INS_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_LIF_INS_CVRG_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_LIF_INS_CVRG_Collection;
import gov.state.nextgen.financialinformation.data.db2.APP_IN_L_INS_ASET_Repository;
import gov.state.nextgen.financialinformation.data.db2.CP_APP_IN_LIF_INS_CVRG_Repository;

/**
 * LifeInsuranceBO - Business Object skeleton auto generated - Architecture Team
 *
 * Creation Date :Thu Feb 01 18:04:27 CST 2007 Modified By: Modified on:
 */
@Service("LifeInsuranceBO")
public class LifeInsuranceBO extends AbstractBO {
	
	private APP_IN_L_INS_ASET_Repository appInLAsetRepo;
	
	private CP_APP_IN_LIF_INS_CVRG_Repository cpAppInLifInsCvrgRepo;

	/**
	 * Constructor
	 */



	public APP_IN_JNT_OWN_Cargo splitJointColl(final APP_IN_JNT_OWN_Collection lifeInsuJntColl, final Integer seqNum, final String recordIndicator) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "LifeInsuranceBO.splitJointColl() - START");
		FwLogger.log(this.getClass(), Level.INFO, "");
		try {
			if ((lifeInsuJntColl != null) && (!lifeInsuJntColl.isEmpty())) {
				final int lifeInsuCollSize = lifeInsuJntColl.size();
				APP_IN_JNT_OWN_Cargo lifeInsCargo = null;
				for (int i = 0; i < lifeInsuCollSize; i++) {
					lifeInsCargo = lifeInsuJntColl.getCargo(i);
					if (lifeInsCargo.getSeq_num().equals(seqNum) && lifeInsCargo.getSrc_app_ind().equals(recordIndicator)) {
						return lifeInsuJntColl.getCargo(i);
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO, "LifeInsuranceBO.splitJointColl() - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
			FwLogger.log(this.getClass(), Level.INFO, "");
			return null;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

	}
	
	public APP_IN_JNT_OWN_Collection splitLifeInsJointColl(final APP_IN_JNT_OWN_Collection lifeInsuJntColl, final String recordIndicator) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "LifeInsuranceBO.splitLifeInsJointColl() - START");
		FwLogger.log(this.getClass(), Level.INFO, "");
		final APP_IN_JNT_OWN_Collection returnColl = new APP_IN_JNT_OWN_Collection();
		try {
			if ((lifeInsuJntColl != null) && (!lifeInsuJntColl.isEmpty())) {
				final int lifeInsuCollSize = lifeInsuJntColl.size();
				APP_IN_JNT_OWN_Cargo lifeInsCargo = null;
				for (int i = 0; i < lifeInsuCollSize; i++) {
					lifeInsCargo = lifeInsuJntColl.getCargo(i);
					if (lifeInsCargo.getSrc_app_ind().equals(recordIndicator)) {
						returnColl.addCargo(lifeInsCargo);
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO, "");
			FwLogger.log(this.getClass(), Level.INFO, "LifeInsuranceBO.splitLifeInsJointColl() - END , Time Taken : " + (System.currentTimeMillis() - startTime)
					);
			return returnColl;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

	}
	
	public APP_IN_JNT_OWN_Cargo splitJointColl(final APP_IN_JNT_OWN_Collection lifeInsuJntColl, final String seqNum, final String recordIndicator) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "LifeInsuranceBO.splitJointColl() - START");
		FwLogger.log(this.getClass(), Level.INFO, "");
		try {
			if ((lifeInsuJntColl != null) && (!lifeInsuJntColl.isEmpty())) {
				final int lifeInsuCollSize = lifeInsuJntColl.size();
				APP_IN_JNT_OWN_Cargo lifeInsCargo = null;
				for (int i = 0; i < lifeInsuCollSize; i++) {
					lifeInsCargo = lifeInsuJntColl.getCargo(i);
					if (lifeInsCargo.getSeq_num().toString().equals(seqNum) && lifeInsCargo.getSrc_app_ind().equals(recordIndicator)) {
						return lifeInsuJntColl.getCargo(i);
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO, "LifeInsuranceBO.splitJointColl() - END , Time Taken : " + (System.currentTimeMillis() - startTime) );
			FwLogger.log(this.getClass(), Level.INFO, "");
			return null;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

	}
	
	public APP_IN_JNT_OWN_Collection getPageJointCollection(final APP_IN_JNT_OWN_Collection cwJntColl, final APP_IN_JNT_OWN_Collection rmJntColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "LifeInsuranceBO.getPageJointCollection() - START");
		FwLogger.log(this.getClass(), Level.INFO, "LifeInsuranceBO::getPageJointCollection:Start");
		APP_IN_JNT_OWN_Collection returnColl;
		returnColl = rmJntColl;
		try {
			if ((cwJntColl != null) && (!cwJntColl.isEmpty())) {
				cwJntColl.size();
				APP_IN_JNT_OWN_Cargo cwJntCargo = null;
				validateJntCargo(cwJntColl, rmJntColl, returnColl);
				return returnColl;
			} else {
				FwLogger.log(this.getClass(), Level.INFO, "LifeInsuranceBO.getPageJointCollection() - END , Time Taken : " + (System.currentTimeMillis() - startTime)
						);
			}
			return rmJntColl;

		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

	}

	private void validateJntCargo(final APP_IN_JNT_OWN_Collection cwJntColl, final APP_IN_JNT_OWN_Collection rmJntColl,
			APP_IN_JNT_OWN_Collection returnColl) {
		APP_IN_JNT_OWN_Cargo cwJntCargo;
		try {
		for (int i = 0; i < cwJntColl.size(); i++) {
			cwJntCargo = cwJntColl.getCargo(i);
			boolean rmRecordexists = false;

			for (int j = 0; j < rmJntColl.size(); j++) {
				final APP_IN_JNT_OWN_Cargo rmJntCargo = rmJntColl.getCargo(j);

				if (cwJntCargo.getSeq_num().equals(rmJntCargo.getSeq_num())) {
					rmRecordexists = true;
					break;
				}

			}
			if (!rmRecordexists) {
				returnColl.addCargo(cwJntCargo);
			}

		}
		} catch (final Exception e) {
			throw e;
		}
	}
	
	/**
	 * load data from CP_APP_IN_L_INS_ASET
	 * @param appNumber
	 * @param indv_seq_num
	 * @param seq_num
	 * @param typ_cd 
	 * @return
	 */
	public APP_IN_L_INS_ASET_Collection loadIndividualLifeInsuranceDetails(String appNumber, Integer indv_seq_num,
			Integer seq_num, String typ_cd) {
		try {
		return appInLAsetRepo.getAsetDetails(appNumber, indv_seq_num, seq_num, typ_cd);
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * 
	 * @param appNumber
	 * @param indvSeqNum
	 * @param seq_num
	 * @return
	 */
	public CP_APP_IN_LIF_INS_CVRG_Collection loadInsPolicyPersonDetails(String appNumber, Integer indvSeqNum,
			Integer seq_num) {
		// TODO Auto-generated method stub
		try {
		return cpAppInLifInsCvrgRepo.loadInsPolicyPersonDetails(appNumber, indvSeqNum, seq_num);
		} catch (final Exception e) {
			throw e;
		}
	}



	public void storeLifeInsDetails(APP_IN_L_INS_ASET_Collection appInLifeInsureCollReq) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO,"LifeInsuranceBO.storeLifeInsDetails() - START");
        try {
        	APP_IN_L_INS_ASET_Cargo cargo = null;
            if (null!=appInLifeInsureCollReq && !appInLifeInsureCollReq.isEmpty()) {
            	cargo = appInLifeInsureCollReq.getCargo(0);
            	appInLAsetRepo.save(cargo);
            }
        } catch (final FwException fe) {
        	FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessageText());
            throw fe;
        } catch (final Exception e) {
        	FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LifeInsuranceBO.storeLifeInsDetails() - END , Time Taken :" + (System.currentTimeMillis() - startTime) );		
	}



	public void storeInsPolicyPersonDetails(CP_APP_IN_LIF_INS_CVRG_Collection lifeInsCollection) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "VehicleAssetBO.storeJointOwnerDetails() - START");
		
		try {
			if(null != lifeInsCollection && !lifeInsCollection.isEmpty()) {
				for(int i = 0; i<lifeInsCollection.size(); i++) {
					CP_APP_IN_LIF_INS_CVRG_Cargo cargo = lifeInsCollection.getCargo(i);
					if(FwConstants.ROWACTION_DELETE.equalsIgnoreCase(cargo.getRowAction())){
						cpAppInLifInsCvrgRepo.delete(cargo);
					}else {
						cpAppInLifInsCvrgRepo.save(cargo);
					}	
				}
			}
			
		}catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessageText());
			throw fe;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "VehicleAssetBO.storeJointOwnerDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) );
	}
}
