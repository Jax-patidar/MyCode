package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessage;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_BILLS_RESP_FOR_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_BILLS_RESP_FOR_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UTILC_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_UTILC_Custom_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_UTILC_Custom_Collection;
import gov.state.nextgen.financialinformation.business.entities.NO_ONE_Collection;
import gov.state.nextgen.financialinformation.business.rules.ABHousingBillsBO;
import gov.state.nextgen.financialinformation.business.rules.ABHousingTypeBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherExpensesDetailsBO;
import gov.state.nextgen.financialinformation.business.rules.ExpenseSummaryBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInBillsRespRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInHouRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInPrflRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInUtilcRepository;
import gov.state.nextgen.financialinformation.model.IndivTypeSeqBean;
import gov.state.nextgen.framework.business.model.IndividualCategorySequenceDetails;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.framework.business.model.UserDetails;

/**
 * Housing Expense Service
 * 
 * @author Deloitte
 *
 */

@SuppressWarnings("squid:S2229")
@Service("HousingExpenseService")
public class HousingExpenseServImpl implements FinancialServInterface {

	private static final String NO = "N";
	private static final String YES = "Y";

	@Autowired
	private AppInHouRepository appInHouRepository;

	private AppInPrflRepository appInPrflRepository;

	@Autowired
	private ABHousingTypeBO housingTypeBO;

	@Autowired
	ExpenseSummaryBO expenseSummaryBO;

	private AppInBillsRespRepository appInBillsRespRepository;

	private AppInUtilcRepository appInUtilcRepository;

	@Autowired
	private ABHousingBillsBO abHousingBillsBO;

	@Autowired
	private RestTemplate restTemplate;
	private Object listCheckBox;

	private static final String SHOW_LOOPING_QUEST_FLAG = "ShowLoopingQuestionFlag";

	private static final String CHECK_BACK_TO_MY_ACCESS_SEL = "checkBackToMyAccessSelected";

	private static final String CP_APP_IN_UTILC_CUS_COLL = "CP_APP_IN_UTILC_Custom_Collection";

	private static final String STORE_END = "storeUtilityDetail:End";

	private static final String GET_SHEL_END = "getShelterDetail:End";

	private static final String GET_UTIL_END = "getUtilityDetail:End";

	private static final String STORE_SHELTER_DETAIL_ERROR = "Error occured in HousingExpenseServImpl.storeShelterDetail()";
	
	private static final String DELETE_HOUSING_EXPENSES_ERROR = "Error occured in HousingExpenseServImpl.deleteHousingExpenses()";
	
	private static final String REMOVE_SHELTER_DETAIL_ERROR = "Error occured in HousingExpenseServImpl.removeHomelessShelterDetails()";	
	
	/**
	 * To call specific business method of the same bean
	 */
	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {

		switch (methodName) {

		case FinancialInfoConstants.STORE_SHELTER_TYPE:
			this.storeShelterType(txnBean);
			break;

		case FinancialInfoConstants.STORE_SHELTER_DET:
			this.storeShelterDetails(txnBean);
			break;

		case FinancialInfoConstants.STORE_UTIL_DETAIL:
			this.storeUtilityDetail(txnBean);
			break;

		case FinancialInfoConstants.GET_SHELTER_DET:
			this.getShelterDetail(txnBean);
			break;

		case FinancialInfoConstants.GET_UTIL_DET:
			this.getUtilityDetail(txnBean);
			break;

		case FinancialInfoConstants.GET_SHEL_TYPE:
			this.getShelterType(txnBean);
			break;

		case FinancialInfoConstants.REMOVE_HOUSING_EXPENSES_BILLS:
			this.deleteHousingExpenses(txnBean);
			break;

		case FinancialInfoConstants.LOAD_HOUSING_EXPENSES_SUMMARY:
			this.getHousingExpensesSummary(txnBean);
			break;

		case FinancialInfoConstants.STORE_RENT_PROPERTY_DETAILS:
			this.storerentpropertyDetails(txnBean);
			break;
		case FinancialInfoConstants.STORE_OTHER_UTILITIES:
			this.storeOtherUtilities(txnBean);
			break;
		case FinancialInfoConstants.LOAD_RENT_MORTGAGE_SUMMARY:
			this.loadRentMortgageSummary(txnBean);
			break;
		case FinancialInfoConstants.DELETE_RENT_MORTGAGE_INFORMATION:
			this.deleteRentMortgageInformation(txnBean);

			break;
		case FinancialInfoConstants.STORE_HOMELESS_SHELTER_DETAILS:
			this.storehomelessShelterDetails(txnBean);
			break;
		case FinancialInfoConstants.REMOVE_HOMELESS_SHELTER_DETAILS:
			this.removeHomelessShelterDetails(txnBean);
			break;

		default:
			break;
		}
	}

	@Transactional
	public void storeShelterType(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.storeShelterType() - START", txnBean);
		try {

			final Map request = txnBean.getRequest();
			final Map pageCollection = txnBean.getPageCollection();

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();

			FwMessageList validateInfo = null;

			// Get pageStatus from DriverArray
			final int pageStatus = 1;

			// Define Persist Array List Collection and cargo
			final List persistArray = new ArrayList();
			final APP_IN_PRFL_Collection persistColl = new APP_IN_PRFL_Collection();

			// Get the PAGE Collection final
			APP_IN_PRFL_Collection appInPrflCollRequest = (APP_IN_PRFL_Collection) pageCollection
					.get("APP_IN_PRFL_Collection");

			// Get ABSCT SHELTER TYPE LIST AND FIRST NAME LIST FROM BEFORE
			// COLLECTION

			final Map beforeFirstNamesList = (Map) request.get("ABSCT_FIRST_NAME_LIST");
			final NO_ONE_Collection noOneBeforeColl = (NO_ONE_Collection) request.get("ABSCT_NO_ONE_COLLECTION");

			// Get the NO ONE Collection and Cargo from Session
			final NO_ONE_Collection noOneShelterColl = (NO_ONE_Collection) pageCollection.get("NO_ONE_Collection");

			// Get the Session and Request Cargo

			APP_IN_PRFL_Cargo appInPrflCargoRequest = new APP_IN_PRFL_Cargo();

			// Get NoOneCollection
			NO_ONE_Collection newNoOneColl;
			newNoOneColl = housingTypeBO.compareNoOneCollection(noOneBeforeColl, noOneShelterColl);

			// Run Validation
			validateInfo = housingTypeBO.validateNoOneSheterType(appInPrflCollRequest, beforeFirstNamesList);
			if ((validateInfo != null) && validateInfo.hasMessages()) {

				request.put(FwConstants.MESSAGE_LIST, validateInfo);
				pageCollection.put("ABSCT_APP_IN_PRFL_COLLECTION", appInPrflCollRequest);
				pageCollection.put("ABSCT_NO_ONE_COLLECTION", newNoOneColl);
				pageCollection.put("ABSCT_FIRST_NAME_LIST", beforeFirstNamesList);
				pageCollection.put("IS_FMA_EBD", request.get("IS_FMA_EBD"));
				pageCollection.put(FwConstants.PAGE_COMPONENT_LIST, request.get(FwConstants.PAGE_COMPONENT_LIST));
				txnBean.setRequest(request);
				txnBean.setPageCollection(pageCollection);
				return;
			}

			persistColl.add(appInPrflCargoRequest);

			APP_IN_PRFL_Cargo cargo = null;

			appInPrflRepository.saveAll(appInPrflCollRequest);

			// end of logic

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeShelterType()", txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_SHELTER_TYPE,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl" + FinancialInfoConstants.STORE_SHELTER_TYPE
				+ " - END , Time Taken : " + (System.currentTimeMillis() - startTime), txnBean);

	}

	/**
	 * Store Housing Util Indv Type.
	 *
	 * @param txnBean the txn bean
	 */
	@SuppressWarnings("squid:S3776")
	@Transactional
	public void storeShelterDetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.storeShelterDetail() - START", txnBean);

		try {

			final Map pageCollection = txnBean.getPageCollection();
			final Map request = txnBean.getRequest();
			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			FwMessageList validateInfo = null;

			final String langCD = "EN";
			String appNum = userDetails.getAppNumber();
			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			long seqNum = Long.parseLong(categorySequenceDetails.getCategorySequence());

			int driverStatus = 5;

			// get Details Collection and Cargo
			final APP_IN_HOU_BILLS_Collection appInShltcCollReq = (APP_IN_HOU_BILLS_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION);
			APP_IN_HOU_BILLS_Cargo shltcCargoReq = appInShltcCollReq.getCargo(0);

			final Map beforePageColl = (Map) request.get(FwConstants.BEFORE_COLLECTION);

			// get the shelterCost collection fron Before Collection and set the
			// values to the cargo
			String billType = shltcCargoReq.getBill_type();
			if (billType == null) {
				billType = "RH";
				shltcCargoReq.setBill_type("RH");
			}
			final APP_IN_HOU_BILLS_Collection beforeShltColl = appInHouRepository.loadIndividualShelterDetails(Integer.parseInt(appNum),
					indvSeqNum, seqNum, billType);

			APP_IN_HOU_BILLS_Cargo beforeCargo = new APP_IN_HOU_BILLS_Cargo();
			// Source app indicator and change effective date default values
			// population PCR # 29768
			shltcCargoReq.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
			shltcCargoReq.setApp_num(appNum);
			shltcCargoReq.setIndv_seq_num(indvSeqNum);
			shltcCargoReq.setSeq_num((int) seqNum);

			if (beforeShltColl != null && !beforeShltColl.isEmpty() && beforeShltColl.getCargo(0) != null) {
				populateShelterCargo(shltcCargoReq, beforeShltColl, appNum);
				// Setting Default values if the before cargo values are null
				// PCR # 29768
				beforeCargo = populateBeforeShelterCargo(beforeShltColl);
				// check dirty
				shltcCargoReq = (APP_IN_HOU_BILLS_Cargo) isChanged(beforeCargo, shltcCargoReq);
				beforeCargo = populateAppInBillsPart1(appInShltcCollReq.getCargo(0), beforeCargo, billType);
				if (null != beforeCargo) {
					shltcCargoReq = beforeCargo;
				}
			}

			char typeStatus = 'C';


			shltcCargoReq.setRec_cplt_ind(FinancialInfoConstants.ONE);
			APP_IN_HOU_BILLS_Collection finalColl = new APP_IN_HOU_BILLS_Collection();
			finalColl.add(shltcCargoReq);
			abHousingBillsBO.storeShelterCostDetails(finalColl);

			handleValidationAndStoreShelterDetails(pageCollection, request, validateInfo, appInShltcCollReq,
					shltcCargoReq, beforePageColl);

			APP_IN_PRFL_Cargo appinprflCargoSes = null;

			Object loopingQuestion = request.get(FinancialInfoConstants.LOOPING_QUESTION);
			// check if pageStatus is REQ OR ADDNEW ?
			if (!((loopingQuestion != null) && FwConstants.YES.equals(loopingQuestion))) {
				// Does LoopingQuestion flag is YES
				if ((driverStatus == FwConstants.DRIVER_REQUIRED) || (driverStatus == FwConstants.DRIVER_ADD_NEW)) {
					if ((beforePageColl != null && beforePageColl.get(FwConstants.LAST_RECORD_INDEX) != null)
							&& (beforePageColl.get(FwConstants.CURRENT_RECORD_INDEX) != null)
							&& ((String) beforePageColl.get(FwConstants.LAST_RECORD_INDEX))
									.equals(beforePageColl.get(FwConstants.CURRENT_RECORD_INDEX))) {
						// Make "Complete" for Type and persist

						appInPrflRepository.save(appinprflCargoSes);

					}
					if (appinprflCargoSes != null) {
						appInPrflRepository.save(appinprflCargoSes);
					}

				} else // when page status is VisitAgain or Complete
				{
					// Remove first Cargo from DetailCollection
					final APP_IN_HOU_BILLS_Collection collSession = (APP_IN_HOU_BILLS_Collection) request
							.get(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION);
					if (collSession != null) {
						collSession.remove(beforeCargo);
					}

				}

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_SHELTER_DETAIL_ERROR, txnBean);
			final FwException fe = ABOtherExpensesDetailsBO.createFwException(this.getClass().getName(), "", e);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_SHELTER_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.storeShelterDetail() - END", txnBean);
	}

	private void handleValidationAndStoreShelterDetails(final Map pageCollection, final Map request,
			FwMessageList validateInfo, final APP_IN_HOU_BILLS_Collection appInShltcCollReq,
			APP_IN_HOU_BILLS_Cargo shltcCargoReq, final Map beforePageColl) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.handleValidationAndStoreShelterDetails() - START");
		
			if (validateInfo != null && validateInfo.hasMessages()) {
				handleValidationInfoForShelterDetails(pageCollection, request, appInShltcCollReq, shltcCargoReq,
						beforePageColl, validateInfo);
				return;
			}

			shltcCargoReq.setRec_cplt_ind(FinancialInfoConstants.ONE);
			abHousingBillsBO.storeShelterCostDetails(appInShltcCollReq);
		
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.handleValidationAndStoreShelterDetails() - END");
	}

	private APP_IN_HOU_BILLS_Cargo populateBeforeShelterCargo(final APP_IN_HOU_BILLS_Collection beforeShltColl) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.populateBeforeShelterCargo() - START");
		APP_IN_HOU_BILLS_Cargo beforeCargo;
		
			beforeCargo = beforeShltColl.getCargo(0);
			if (beforeCargo.getSrc_app_ind() == null) {
				beforeCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
			}
			FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.populateBeforeShelterCargo() - END");
			return beforeCargo;
		
		
	}

	private void populateShelterCargo(APP_IN_HOU_BILLS_Cargo shltcCargoReq,
			final APP_IN_HOU_BILLS_Collection beforeShltColl, String appNum) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.populateShelterCargo() - START");
			shltcCargoReq.setApp_num(appNum);
			shltcCargoReq.setIndv_seq_num(beforeShltColl.getCargo(0).getIndv_seq_num());
			shltcCargoReq.setBill_type(beforeShltColl.getCargo(0).getBill_type());
			shltcCargoReq.setSeq_num(beforeShltColl.getCargo(0).getSeq_num());
			// set sequece number Zero if it is null
			if (shltcCargoReq.getSeq_num() != null) {
				shltcCargoReq.setRowAction(FwConstants.ROWACTION_UPDATE);
			} else {
				shltcCargoReq.setRowAction(FwConstants.ROWACTION_INSERT);
			}
		
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.populateShelterCargo() - END");
	}

	private void handleValidationInfoForShelterDetails(final Map pageCollection, final Map request,
			final APP_IN_HOU_BILLS_Collection appInShltcCollReq, APP_IN_HOU_BILLS_Cargo shltcCargo_req,
			final Map beforePageColl, FwMessageList validateInfo) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.handleValidationInfoForShelterDetails() - START");
		
			request.put(FwConstants.MESSAGE_LIST, validateInfo.getMessageList());
			// put the first Name into request to avoid null pointer in JSP
			pageCollection.put(AppConstants.FIRST_NAME, beforePageColl.get(AppConstants.FIRST_NAME));
			pageCollection.put(SHOW_LOOPING_QUEST_FLAG, beforePageColl.get(SHOW_LOOPING_QUEST_FLAG));
			pageCollection.put(FwConstants.PAGE_COMPONENT_LIST, beforePageColl.get(FwConstants.PAGE_COMPONENT_LIST));
			pageCollection.put(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION, appInShltcCollReq);
			pageCollection.put("APP_IN_HOU_BILLS_Cargo", shltcCargo_req);
			pageCollection.put("PEOPLE_377", beforePageColl.get("PEOPLE_377"));
		
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.handleValidationInfoForShelterDetails() - END");
	}

	public void setRowActionForShelterDetailBills(APP_IN_HOU_BILLS_Cargo shltcCargo_req,
			final APP_IN_BILLS_RESP_FOR_Collection appInJntBeforeColl,
			final APP_IN_BILLS_RESP_FOR_Collection appInJntOwnColl,
			final APP_IN_BILLS_RESP_FOR_Collection appInJntOwnNewColl) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.setRowActionForShelterDetailBills() - START");
		try {
			APP_IN_BILLS_RESP_FOR_Cargo appInJntOwnBeforeCargo;
			APP_IN_BILLS_RESP_FOR_Cargo appInJntOwnCargo;
			final int appInJntCollSize = appInJntOwnColl.size();
			for (int i = 0; i < appInJntCollSize; i++) {
				appInJntOwnCargo = appInJntOwnColl.getCargo(i);
				appInJntOwnBeforeCargo = getMatchingCargo(appInJntBeforeColl, appInJntOwnCargo);

				if (appInJntOwnBeforeCargo == null) {
					appInJntOwnCargo.setApp_num(shltcCargo_req.getApp_num());
					appInJntOwnCargo.setBill_own_seq_num(shltcCargo_req.getSeq_num());
					appInJntOwnCargo.setIndv_seq_num(shltcCargo_req.getIndv_seq_num());
					appInJntOwnCargo.setBill_type(shltcCargo_req.getBill_type());
					if (appInJntOwnCargo.getResponsible_fst_nam() == null) {
						appInJntOwnCargo.setResponsible_fst_nam(FwConstants.SPACE);
					}
					if (appInJntOwnCargo.getResponsible_lst_nam() == null) {
						appInJntOwnCargo.setResponsible_lst_nam(FwConstants.SPACE);
					}
					if (appInJntOwnCargo.getOtsd_ind() == null) {

						appInJntOwnCargo.setOtsd_ind(FwConstants.SPACE);
					}

					appInJntOwnCargo.setSrc_app_ind(shltcCargo_req.getSrc_app_ind());
					appInJntOwnCargo.setRowAction(FwConstants.ROWACTION_INSERT);

					appInJntOwnNewColl.add(appInJntOwnCargo);
				}
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.setRowActionForShelterDetailBills()");
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.setRowActionForShelterDetailBills() - END");
	}

	public void setRowActionForShelterDetails(APP_IN_HOU_BILLS_Cargo shltcCargo_req,
			final APP_IN_BILLS_RESP_FOR_Collection appInJntBeforeColl,
			final APP_IN_BILLS_RESP_FOR_Collection appInJntOwnColl,
			final APP_IN_BILLS_RESP_FOR_Collection appInJntOwnNewColl, int i) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.setRowActionForShelterDetails() - START");
		try {
			APP_IN_BILLS_RESP_FOR_Cargo appInJntOwnBeforeCargo;
			APP_IN_BILLS_RESP_FOR_Cargo appInJntOwnCargo;
			appInJntOwnBeforeCargo = appInJntBeforeColl.getCargo(i);
			appInJntOwnCargo = getMatchingCargo(appInJntOwnColl, appInJntOwnBeforeCargo);

			if (appInJntOwnCargo == null) {
				appInJntOwnBeforeCargo.setRowAction(FwConstants.ROWACTION_DELETE);
				appInJntOwnNewColl.add(appInJntOwnBeforeCargo);
			} else {

				// now we need to check the dirty indicator
				appInJntOwnCargo.setApp_num(shltcCargo_req.getApp_num());
				appInJntOwnCargo.setBill_own_seq_num(shltcCargo_req.getSeq_num());
				appInJntOwnCargo.setIndv_seq_num(shltcCargo_req.getIndv_seq_num());
				appInJntOwnCargo.setBill_type(shltcCargo_req.getBill_type());
				appInJntOwnCargo.setSrc_app_ind(shltcCargo_req.getSrc_app_ind());
				/*
				 * VG SONAR Cleanup - 08/26/2015 Deleted 2,1 lines Commented Code in this block
				 */
				if (appInJntOwnCargo.getResponsible_fst_nam() == null) {
					appInJntOwnCargo.setResponsible_fst_nam(FwConstants.SPACE);
				}
				if (appInJntOwnCargo.getResponsible_lst_nam() == null) {
					appInJntOwnCargo.setResponsible_lst_nam(FwConstants.SPACE);
				}
				if (appInJntOwnCargo.getOtsd_ind() == null) {
					appInJntOwnCargo.setOtsd_ind(FwConstants.SPACE);

				}
				if (appInJntOwnCargo.getSeq_num() == FinancialInfoConstants.ZERO) {
					appInJntOwnCargo.setSeq_num(appInJntOwnBeforeCargo.getSeq_num());
				}

				appInJntOwnCargo = (APP_IN_BILLS_RESP_FOR_Cargo) isChanged(appInJntOwnBeforeCargo, appInJntOwnCargo);

				appInJntOwnCargo.setDirty(true);
				if (appInJntOwnCargo.isDirty()) {
					appInJntOwnCargo.setRowAction(FwConstants.ROWACTION_UPDATE);
					appInJntOwnNewColl.add(appInJntOwnCargo);
				}
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.setRowActionForShelterDetails()");
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.setRowActionForShelterDetails() - END");
	}

	public void filterBillCollection(final APP_IN_BILLS_RESP_FOR_Collection billCollection) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.filterBillCollection() - START");
		APP_IN_BILLS_RESP_FOR_Cargo billCargo = null;
		try {
			for (int index = 0, size = billCollection.size(); index < size; index++) {
				billCargo = (APP_IN_BILLS_RESP_FOR_Cargo) billCollection.get(index);
				if (FwConstants.YES.equals(billCargo.getOtsd_ind())) {
					continue;
				}
				if (!FwConstants.YES.equals(billCargo.getBill_type())) {
					billCollection.remove(billCargo);
					index--;
					size--;
				}
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.filterBillCollection()");
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.filterBillCollection() - END");
	}

	/**
	 * Check back to my access selected.
	 *
	 * @param request the request
	 * @return boolean
	 */
	public boolean checkBackToMyAccessSelected(final Map request) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.checkBackToMyAccessSelected() - START");
		try {
			if (request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON) == null) {
				return false;
			}
			final String reqWarningMsgs = (String) request.get(FwConstants.WARNING_MSG_DETAILS);
			if ((reqWarningMsgs != null) && (reqWarningMsgs.trim().length() > 0)) {
				// Tokenizing the request warrning message and putting into a
				// list
				final StringTokenizer tokenizer = new StringTokenizer(reqWarningMsgs, FinancialInfoConstants.TILDE);
				final List reqMsgList = new ArrayList();
				while (tokenizer.hasMoreElements()) {
					reqMsgList.add(tokenizer.nextElement());
				}
				if (reqMsgList.contains(FinancialInfoConstants.MSG_30075)) {
					return true;
				}
			}
			final FwMessageList messageList = new FwMessageList();
			final FwMessage message = new FwMessage();
			message.addMessageCode(FinancialInfoConstants.MSG_30075);
			messageList.addMessageToList(message);
			request.put(FwConstants.MESSAGE_LIST, messageList);
			FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.checkBackToMyAccessSelected() - END");
			return true;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.checkBackToMyAccessSelected()");
			final FwException fe = ABOtherExpensesDetailsBO.createFwException(this.getClass().getName(),
					CHECK_BACK_TO_MY_ACCESS_SEL, e);
			throw e;
		}
		
	}

	/**
	 * Gets the matching cargo.
	 *
	 * @param appInJntOwnColl     the app in jnt own coll
	 * @param appInJntBeforeCargo the app in jnt before cargo
	 * @return the matching cargo
	 */
	public APP_IN_BILLS_RESP_FOR_Cargo getMatchingCargo(final APP_IN_BILLS_RESP_FOR_Collection appInJntOwnColl,
			final APP_IN_BILLS_RESP_FOR_Cargo appInJntBeforeCargo) {

		System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.getMatchingCargo() - START");
		try {
			if ((appInJntOwnColl == null) || (appInJntOwnColl.isEmpty())) {
				return null;
			}

			final int appInJntCollSize = appInJntOwnColl.size();
			APP_IN_BILLS_RESP_FOR_Cargo appInJntOwnCargo = null;
			String otsdInd = appInJntBeforeCargo.getOtsd_ind();
			final Integer jntIndvSeqNum = appInJntBeforeCargo.getBill_indv_seq_num();

			if (otsdInd == null) {
				otsdInd = FwConstants.SPACE;
			}

			String otsdJntInd = null;
			if (!appInJntOwnColl.isEmpty()) {
				for (int i = 0; i < appInJntCollSize; i++) {
					appInJntOwnCargo = appInJntOwnColl.getCargo(i);
					otsdJntInd = appInJntOwnCargo.getOtsd_ind();
					if (otsdJntInd == null) {
						otsdJntInd = FwConstants.SPACE;
					}
					if (appInJntOwnCargo.getBill_indv_seq_num().equals(jntIndvSeqNum) && otsdJntInd.equals(otsdInd)) {
						return appInJntOwnCargo;
					}

				}
			}
			FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.getMatchingCargo() - END");
			return null;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.getMatchingCargo()");
			throw e;
		}
	}

	protected AbstractCargo isChanged(final AbstractCargo aBeforeCargo, final AbstractCargo aAfterCargo)
			throws FwException {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.isChanged() - START");
		
			if (aBeforeCargo == aAfterCargo) {
				aAfterCargo.setDirty(false);
			} else {

				if (null != aAfterCargo) {
					if ((aBeforeCargo == null) || (aBeforeCargo.hashCode() != aAfterCargo.hashCode())) {
						aAfterCargo.setDirty(true);
					} else
						aAfterCargo.setDirty(false);
				}
			}
		
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.isChanged() - END");
		return aAfterCargo;

	}

	@Transactional
	public void storeUtilityDetail(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.storeUtilityDetail() - START", txnBean);
		try {
			FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean::storeUtilityDetail:Start");

			final Map pageCollection = txnBean.getPageCollection();
			final Map request = txnBean.getRequest();
			UserDetails userDetails = txnBean.getUserDetails();
			FwMessageList validationInfo = null;

			String appNumber = userDetails.getAppNumber();

			// For UI testing hardcode the Indv Seq and category seq num and utiltype for
			// now, comment lines: 934 - 938 and uncomment lines 939 - 941

			int indvSeqNum = 1;
			long seqNum = 1;

			// get Details Collection and Cargo

			final CP_APP_IN_UTILC_Custom_Collection appInUtilcCollReq = (CP_APP_IN_UTILC_Custom_Collection) pageCollection
					.get(CP_APP_IN_UTILC_CUS_COLL);

			appInUtilcCollReq.getCargo(0);

			APP_IN_UTILC_Collection appInUtilcColl = appInUtilcRepository.loadUtilityDetails(appNumber);
			final Map beforePageColl = (Map) request.get(FwConstants.BEFORE_COLLECTION);
			// get the utilityCost collection fron Before Collection and set the
			// values to the cargo

			final CP_APP_IN_UTILC_Custom_Collection beforeUtilColl = abHousingBillsBO
					.getUtilitiesCustomCollection(appNumber, indvSeqNum, appInUtilcColl);
			final CP_APP_IN_UTILC_Custom_Cargo beforeCargo = beforeUtilColl != null ? beforeUtilColl.getCargo() : null;

			final CP_APP_IN_UTILC_Custom_Cargo utilcCustomCargo = appInUtilcCollReq.getCargo(0);
			utilcCustomCargo.setIndivdiualSequenceNumber(indvSeqNum);
			utilcCustomCargo.setApplicationNumber(appNumber);
			validationInfo = abHousingBillsBO.validateUtilityBillsContents(utilcCustomCargo);
			if (validationInfo.hasMessages()) {
				request.put(FwConstants.MESSAGE_LIST, validationInfo.getMessageList());
				// put the first Name into request to avoid null pointer in JSP
				pageCollection.put(AppConstants.FIRST_NAME, beforePageColl.get(AppConstants.FIRST_NAME));
				pageCollection.put(SHOW_LOOPING_QUEST_FLAG, beforePageColl.get(SHOW_LOOPING_QUEST_FLAG));
				pageCollection.put(FwConstants.PAGE_COMPONENT_LIST,
						beforePageColl.get(FwConstants.PAGE_COMPONENT_LIST));
				return;
			}

			// Convert Data
			final APP_IN_UTILC_Collection aColl = abHousingBillsBO.loadUtilityDetails(appNumber);
			APP_IN_UTILC_Collection utilityCollection = null;
			if (null != aColl && !aColl.isEmpty()) {
				String heatCollSrc = aColl.getCargo(0).getHeat_cool_src();
				utilityCollection = abHousingBillsBO.getUtilityCollection(appNumber, utilcCustomCargo, indvSeqNum,
						FwConstants.ROWACTION_UPDATE);
				if (null != heatCollSrc) {
					utilityCollection.getCargo(0).setHeat_cool_src(heatCollSrc);
				}
			} else {
				utilityCollection = abHousingBillsBO.getUtilityCollection(appNumber, utilcCustomCargo, indvSeqNum,
						FwConstants.ROWACTION_INSERT);
			}

			// Persist Data
			if ((utilityCollection != null) && (!utilityCollection.isEmpty())) {
				abHousingBillsBO.storeUtilityCostDetails(utilityCollection);
			}

			FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean::storeUtilityDetail:End");
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.storeUtilityDetail()", txnBean);
			final FwException fe = ABOtherExpensesDetailsBO.createFwException(this.getClass().getName(), "", e);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.STORE_UTIL_DETAIL,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.storeUtilityDetail() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime), txnBean);
	}

	@Transactional
	public void getShelterType(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.getShelterType() - START", txnBean);
		try {

			loadTypes(txnBean, txnBean.getCurrentActionDetails().getPageId());

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.getShelterType()", txnBean);
			final FwException fe = ABOtherExpensesDetailsBO.createFwException(this.getClass().getName(), "", e);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_SHEL_TYPE,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.getShelterType() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime), txnBean);
	}

	public void loadTypes(final FwTransaction txnBean, final String pageCollectionPrefix) {

			FwLogger.log(this.getClass(), Level.INFO, "AFBSessionBean::loadTypes:Start", txnBean);

			final Map pageCollection = txnBean.getPageCollection();

			APP_IN_PRFL_Cargo appInPrflCargo = null;

			final APP_IN_PRFL_Collection appInPrflColl = new APP_IN_PRFL_Collection();

			final NO_ONE_Collection noOneCollection = new NO_ONE_Collection();

			Integer indivSeqNum = null;
			String firstName = null;
			String response = null;
			final Map firstNameList = new HashMap();

			pageCollection.put(pageCollectionPrefix + "_APP_IN_PRFL_COLLECTION", appInPrflColl);
			pageCollection.put(pageCollectionPrefix + "_FIRST_NAME_LIST", firstNameList);
			pageCollection.put(pageCollectionPrefix + "_NO_ONE_COLLECTION", noOneCollection);

			txnBean.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), Level.INFO, "AFBSessionBean::loadTypes:End", txnBean);

		
	}

	@Transactional
	public void getShelterDetail(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.getShelterDetail() - START", txnBean);
		try {
			FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean::getShelterDetail:Start");

			Map pageCollection;

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();

			String appNum = userDetails.getAppNumber();
			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			int seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());
			String billType = categorySequenceDetails.getCategoryType();

			pageCollection = new HashMap();
			final APP_IN_HOU_BILLS_Collection appInHouBillsCollection = abHousingBillsBO
					.loadIndividualShelterDetails(appNum, indvSeqNum, seqNum, billType);

			APP_IN_HOU_BILLS_Cargo appInHouBillsCargo = null;
			int sizeColl = 0;

			if ((appInHouBillsCollection != null) && (!appInHouBillsCollection.isEmpty())) {
				sizeColl = appInHouBillsCollection.size();
			}
			if (sizeColl > 0) {
				appInHouBillsCargo = appInHouBillsCollection.getCargo(0);
			}
			final APP_IN_HOU_BILLS_Collection temp = new APP_IN_HOU_BILLS_Collection();
			temp.addCargo(appInHouBillsCargo);
			pageCollection.put(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION, temp);

			txnBean.setPageCollection(pageCollection);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.getShelterDetail()", txnBean);
			final FwException fe = ABOtherExpensesDetailsBO.createFwException(this.getClass().getName(),
					"getShelterDetail", e);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_SHELTER_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.getShelterDetail() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime), txnBean);
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Method to delete housing bills expenses
	 * 
	 * 
	 ********************************************************************************************************************
	 */
	@SuppressWarnings("squid:S2230")
	@Transactional
	private void deleteHousingExpenses(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpensesServImpl.deleteHousingExpenses() - START", txnBean);

		try {

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String appNum = userDetails.getAppNumber();

			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			int seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());
			String billType = categorySequenceDetails.getCategoryType();

			APP_IN_HOU_BILLS_Collection existingHousingBillsColl = abHousingBillsBO.loadIndividualShelterDetails(appNum,
					indvSeqNum, (int) seqNum, billType);
			if (Objects.nonNull(existingHousingBillsColl) && !existingHousingBillsColl.isEmpty()
					&& existingHousingBillsColl.size() > 0) {
				APP_IN_HOU_BILLS_Cargo existingCargo = existingHousingBillsColl.getCargo(0);
				if (Objects.nonNull(existingCargo))
					abHousingBillsBO.deleteHousingBillsCargo(existingCargo);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, DELETE_HOUSING_EXPENSES_ERROR, txnBean);
			final FwException fe = ABOtherExpensesDetailsBO.createFwException(this.getClass().getName(), "", e);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.REMOVE_HOUSING_EXPENSES_BILLS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpensesServImpl.deleteHousingExpenses() - END", txnBean);
	}

	@Transactional
	public void getUtilityDetail(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.getUtilityDetail() - START", txnBean);
		try {
			CP_APP_IN_UTILC_Custom_Collection cp_APP_IN_UTILC_Custom_Collection;

			Map pageCollection = txnBean.getPageCollection();
			final Map request = txnBean.getRequest();
			UserDetails userDetails = txnBean.getUserDetails();
			FwMessageList validateInfo = null;

			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = new IndividualCategorySequenceDetails();
			categorySequenceDetails.setCategorySequence("1");
			categorySequenceDetails.setIndividualSequence("1");
			currentPageActionDetails.setIndividualCategorySequenceDetails(categorySequenceDetails);
			categorySequenceDetails = currentPageActionDetails.getIndividualCategorySequenceDetails();

			int indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());

			String appNum = userDetails.getAppNumber();

			// make loopingQuestion value NO in the request
			request.put("loopingQuestion", FwConstants.NO);

			// when user hits the Back button or comes from the Summary Page
			if (pageCollection.get(FwConstants.DETAIL_KEY_BEAN) != null) {
				// get utilitycost details from UtilityCost detials table in
				// database
				final IndivTypeSeqBean indvBean = (IndivTypeSeqBean) pageCollection.get(FwConstants.DETAIL_KEY_BEAN);
				pageCollection = new HashMap();
				// get Details_Collection from DataBase and set to
				// PageCollection
				// Start: VA EDSP CP making changes to page

				pageCollection.put(CP_APP_IN_UTILC_CUS_COLL,
						abHousingBillsBO.loadIndividualUtilityDetails(appNum, indvSeqNum));

				pageCollection.put("CP_APP_IN_UTILC_INDV", indvBean.getIndivSeqNum());
				// End VA EDSP CP changes
			} else {
				pageCollection = new HashMap();

				final CP_APP_IN_UTILC_Custom_Collection appInUtilcColl = abHousingBillsBO
						.loadIndividualUtilityDetails(appNum, indvSeqNum);

				int sizeColl = 0;
				CP_APP_IN_UTILC_Custom_Cargo appInUtilcCargo = null;
				if ((appInUtilcColl != null) && (!appInUtilcColl.isEmpty())) {
					sizeColl = appInUtilcColl.size();
				}
				if (sizeColl > 0) {
					appInUtilcCargo = appInUtilcColl.getResult(sizeColl - 1);
				}
				final CP_APP_IN_UTILC_Custom_Collection temp = new CP_APP_IN_UTILC_Custom_Collection();
				temp.addCargo(appInUtilcCargo);
				pageCollection.put(CP_APP_IN_UTILC_CUS_COLL, temp);

			}

			txnBean.setPageCollection(pageCollection);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.getUtilityDetail()", txnBean);
			final FwException fe = ABOtherExpensesDetailsBO.createFwException(this.getClass().getName(), "loadTypes",
					e);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.GET_UTIL_DET,
					txnBean.getUserDetails().getAppNumber(), txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.getUtilityDetail() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime), txnBean);
	}

	/**
	 * Gets Individual details from People Handler through the service to household
	 * service.
	 * 
	 * @param fwTransaction
	 * @param String        format of Page Load Action (/pageid/pageidLoad)
	 * @return
	 */
	@SuppressWarnings({"squid:S1871","squid:S3776"})
	public void prepareAppInPrflCargo(APP_IN_PRFL_Cargo existingAppInPrflCargo, APP_IN_PRFL_Cargo appInPrflCargo) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.prepareAppInPrflCargo() - START");
		try {
			if (appInPrflCargo.getHousing_bill_mortgage_resp() != null
					&& Objects.nonNull(existingAppInPrflCargo.getHousing_bill_mortgage_resp())
					&& !(existingAppInPrflCargo.getHousing_bill_mortgage_resp()
							.equals(appInPrflCargo.getHousing_bill_mortgage_resp()))) {
				existingAppInPrflCargo.setHousing_bill_mortgage_resp(appInPrflCargo.getHousing_bill_mortgage_resp());
			} else if (Objects.isNull(existingAppInPrflCargo.getHousing_bill_mortgage_resp())
					&& appInPrflCargo.getHousing_bill_mortgage_resp() != null) {
				existingAppInPrflCargo.setHousing_bill_mortgage_resp(appInPrflCargo.getHousing_bill_mortgage_resp());
			}

			if (appInPrflCargo.getHousing_bill_prop_tax_resp() != null
					&& Objects.nonNull(existingAppInPrflCargo.getHousing_bill_prop_tax_resp())
					&& !(existingAppInPrflCargo.getHousing_bill_prop_tax_resp()
							.equals(appInPrflCargo.getHousing_bill_prop_tax_resp()))) {
				existingAppInPrflCargo.setHousing_bill_prop_tax_resp(appInPrflCargo.getHousing_bill_prop_tax_resp());
			} else if (Objects.isNull(existingAppInPrflCargo.getHousing_bill_prop_tax_resp())
					&& appInPrflCargo.getHousing_bill_prop_tax_resp() != null) {
				existingAppInPrflCargo.setHousing_bill_prop_tax_resp(appInPrflCargo.getHousing_bill_prop_tax_resp());
			}

			if (appInPrflCargo.getSu_cst_fuel_resp() != null
					&& Objects.nonNull(existingAppInPrflCargo.getSu_cst_fuel_resp())
					&& !(existingAppInPrflCargo.getSu_cst_fuel_resp().equals(appInPrflCargo.getSu_cst_fuel_resp()))) {
				existingAppInPrflCargo.setSu_cst_fuel_resp(appInPrflCargo.getSu_cst_fuel_resp());
			} else if (Objects.isNull(existingAppInPrflCargo.getSu_cst_fuel_resp())
					&& appInPrflCargo.getSu_cst_fuel_resp() != null) {
				existingAppInPrflCargo.setSu_cst_fuel_resp(appInPrflCargo.getSu_cst_fuel_resp());
			}

			if (appInPrflCargo.getSu_cst_phn_resp() != null
					&& Objects.nonNull(existingAppInPrflCargo.getSu_cst_phn_resp())
					&& !(existingAppInPrflCargo.getSu_cst_phn_resp().equals(appInPrflCargo.getSu_cst_phn_resp()))) {
				existingAppInPrflCargo.setSu_cst_phn_resp(appInPrflCargo.getSu_cst_phn_resp());
			} else if (Objects.isNull(existingAppInPrflCargo.getSu_cst_phn_resp())
					&& appInPrflCargo.getSu_cst_phn_resp() != null) {
				existingAppInPrflCargo.setSu_cst_phn_resp(appInPrflCargo.getSu_cst_phn_resp());
			}

			if (appInPrflCargo.getSu_cst_wtr_swr_trsh_resp() != null
					&& Objects.nonNull(existingAppInPrflCargo.getSu_cst_wtr_swr_trsh_resp()) && !(existingAppInPrflCargo
							.getSu_cst_wtr_swr_trsh_resp().equals(appInPrflCargo.getSu_cst_wtr_swr_trsh_resp()))) {
				existingAppInPrflCargo.setSu_cst_wtr_swr_trsh_resp(appInPrflCargo.getSu_cst_wtr_swr_trsh_resp());
			} else if (Objects.isNull(existingAppInPrflCargo.getSu_cst_wtr_swr_trsh_resp())
					&& appInPrflCargo.getSu_cst_wtr_swr_trsh_resp() != null) {
				existingAppInPrflCargo.setSu_cst_wtr_swr_trsh_resp(appInPrflCargo.getSu_cst_wtr_swr_trsh_resp());
			}

			if (appInPrflCargo.getHousing_bill_hless_shlt_resp() != null
					&& Objects.nonNull(existingAppInPrflCargo.getHousing_bill_hless_shlt_resp())
					&& !(existingAppInPrflCargo.getHousing_bill_hless_shlt_resp()
							.equals(appInPrflCargo.getHousing_bill_hless_shlt_resp()))) {
				existingAppInPrflCargo
						.setHousing_bill_hless_shlt_resp(appInPrflCargo.getHousing_bill_hless_shlt_resp());
			} else if (Objects.isNull(existingAppInPrflCargo.getHousing_bill_hless_shlt_resp())
					&& appInPrflCargo.getHousing_bill_hless_shlt_resp() != null) {
				existingAppInPrflCargo
						.setHousing_bill_hless_shlt_resp(appInPrflCargo.getHousing_bill_hless_shlt_resp());
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.prepareAppInPrflCargo()");
			throw e;
		}
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.prepareAppInPrflCargo() - END");
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Method to load housing bills expenses summary
	 * 
	 * 
	 ********************************************************************************************************************
	 */
	@SuppressWarnings("squid:S6212")
	public void getHousingExpensesSummary(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpensesServImpl.getHousingExpensesSummary() - START", txnBean);

		try {

			final Map pageCollection = txnBean.getPageCollection();
			String mode = (String) pageCollection.get(FinancialInfoConstants.MODE);
			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("indvIds");
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String appNum = userDetails.getAppNumber();
			String billType = categorySequenceDetails.getCategoryType();
			APP_IN_HOU_BILLS_Collection existingHousingBillsColl;
			if (billType == null && (null != mode && mode.equals(FinancialInfoConstants.RAC))) {
				existingHousingBillsColl = expenseSummaryBO.getHousingSummaryDetails(appNum, indvIdList);
			} else {
				existingHousingBillsColl = abHousingBillsBO.loadHousingExpenses(appNum, billType, indvIdList);
			}
			if (Objects.nonNull(existingHousingBillsColl) && !existingHousingBillsColl.isEmpty()
					&& existingHousingBillsColl.size() > 0) {
				pageCollection.put(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION, existingHousingBillsColl);
			}
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.getHousingExpensesSummary()", txnBean);
			final FwException fe = ABOtherExpensesDetailsBO.createFwException(this.getClass().getName(),
					"getHousingExpensesSummary", e);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.LOAD_HOUSING_EXPENSES_SUMMARY, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpensesServImpl.getHousingExpensesSummary() - END", txnBean);
	}

	/////////////////////////////////////////////////////////////////////
	// RentorMortgage and property tax screen from periodic report flow
	@SuppressWarnings("squid:S3776")
	public void storerentpropertyDetails(final FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.storerentpropertyDetails() - START", txnBean);

		try {

			final Map pageCollection = txnBean.getPageCollection();
			final Map request = txnBean.getRequest();
			UserDetails userDetails = txnBean.getUserDetails();

			String appNum = userDetails.getAppNumber();
			int indvSeqNum = 0;
			int seqNum = 1;

			// get Details Collection and Cargo
			final APP_INDV_Collection appIndvColl = (APP_INDV_Collection) pageCollection.get("APP_INDV_Collection");
			for (APP_INDV_Cargo cargo : appIndvColl.getResults()) {
				if (Objects.nonNull(cargo.getPrim_prsn_sw()) && cargo.getPrim_prsn_sw().equalsIgnoreCase("Y")) {
					indvSeqNum = cargo.getIndv_seq_num();
				}
			}
			final APP_IN_HOU_BILLS_Collection appInShltcCollReq = (APP_IN_HOU_BILLS_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION);
			APP_IN_HOU_BILLS_Cargo shltcCargoReq = appInShltcCollReq.getCargo(0);
			String billType = "";

			APP_IN_HOU_BILLS_Collection existingRentColl = appInHouRepository.getByBillTypeIndvIdAppNum(Integer.parseInt(appNum),
					indvSeqNum, "PT");
			if (Objects.nonNull(existingRentColl) && !existingRentColl.isEmpty()) {
				billType = "PT";
				APP_IN_HOU_BILLS_Cargo ptCargo = existingRentColl.getCargo(0);
				seqNum = ptCargo.getSeq_num();
				String isPropertyTaxSelected = shltcCargoReq.getPr_select();
				if (Objects.nonNull(isPropertyTaxSelected)) {
					ptCargo.setPr_select(isPropertyTaxSelected);
				}
				if (null !=isPropertyTaxSelected && !YES.equalsIgnoreCase(isPropertyTaxSelected)) {
					abHousingBillsBO.deleteHousingBillsCargo(ptCargo);
				} else {
					insertIntoHouBillsCargo(ptCargo, appNum, indvSeqNum, seqNum, billType,
							shltcCargoReq.getPr_pymnt_amt());
				}
			}

			else {
				if (Objects.nonNull(shltcCargoReq.getPr_select()) && shltcCargoReq.getPr_select().equalsIgnoreCase("Y")
						&& Objects.nonNull(shltcCargoReq.getPr_pymnt_amt()) && shltcCargoReq.getPr_pymnt_amt() > 0) {

					APP_IN_HOU_BILLS_Cargo ptCargo = new APP_IN_HOU_BILLS_Cargo();
					billType = "PT";
					ptCargo.setPr_select(shltcCargoReq.getPr_select());
					insertIntoHouBillsCargo(ptCargo, appNum, indvSeqNum, seqNum, billType,
							shltcCargoReq.getPr_pymnt_amt());

					seqNum = seqNum + 1;
				}

			}
			existingRentColl = appInHouRepository.getByBillTypeIndvIdAppNum(Integer.parseInt(appNum), indvSeqNum, "RH");
			if (Objects.nonNull(existingRentColl) && !existingRentColl.isEmpty()) {
				billType = "RH";
				APP_IN_HOU_BILLS_Cargo rhCargo = existingRentColl.getCargo(0);
				seqNum = rhCargo.getSeq_num();
				if (Objects.nonNull(shltcCargoReq.getPr_select())) {
					rhCargo.setPr_select(shltcCargoReq.getPr_select());
				}
				insertIntoHouBillsCargo(rhCargo, appNum, indvSeqNum, seqNum, billType, shltcCargoReq.getPymt_amt());
			}

			else {
				if (Objects.nonNull(shltcCargoReq.getPymt_amt()) && shltcCargoReq.getPymt_amt() > 0) {

					APP_IN_HOU_BILLS_Cargo rhCargo = new APP_IN_HOU_BILLS_Cargo();
					billType = "RH";
					if (Objects.nonNull(shltcCargoReq.getPr_select())) {
						rhCargo.setPr_select(shltcCargoReq.getPr_select());
					}
					insertIntoHouBillsCargo(rhCargo, appNum, indvSeqNum, seqNum, billType, shltcCargoReq.getPymt_amt());
				}

			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.storeDependentCareDetail()", txnBean);
			final FwException fe = ABOtherExpensesDetailsBO.createFwException(this.getClass().getName(),
					"storeDependentCareDetail", e);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STORE_RENT_PROPERTY_DETAILS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.storerentpropertyDetails() - END", txnBean);
	}

	private void insertIntoHouBillsCargo(APP_IN_HOU_BILLS_Cargo ptCargo, String appNum, int indvSeqNum, int seqNum,
			String billType, Double paymtAmt) {
		
			ptCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
			ptCargo.setApp_num(appNum);
			ptCargo.setIndv_seq_num(indvSeqNum);
			ptCargo.setSeq_num((int) seqNum);
			ptCargo.setBill_type(billType);
			ptCargo.setPymt_amt(paymtAmt);
			appInHouRepository.save(ptCargo);
		
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////
	// Other utilities screen for periodic report flow
	private void storeOtherUtilities(FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HousingExpenseEJBBean.storeOtherUtilities() - START", txnBean);
		try {
			APP_IN_HOU_BILLS_Collection appIndvCollFromDB = null;
			final Map pageCollection = txnBean.getPageCollection();
			final String appNum = txnBean.getUserDetails().getAppNumber();
			int indvSeqNum = 0;
			int seqNum = 0;
			final APP_IN_HOU_BILLS_Collection appInShltcCollReq = (APP_IN_HOU_BILLS_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION);
			APP_IN_HOU_BILLS_Cargo shltcCargoReq = appInShltcCollReq.getCargo(0);
			indvSeqNum = shltcCargoReq.getIndv_seq_num();
			List<String> inputAry = new ArrayList<String>();
			inputAry = (List<String>) pageCollection.get("listCheckBox");
			// indvseqnum, appnum, billtype=RH
			List<String> actualAry = Arrays.asList("TE", "TR", "WA", "GE", "OH");

			final APP_IN_HOU_BILLS_Collection beforeShltfromDB = appInHouRepository.getUtilityInfoData(Integer.parseInt(appNum),
					indvSeqNum);

			if (Objects.nonNull(beforeShltfromDB) && !beforeShltfromDB.isEmpty()) {
				abHousingBillsBO.deleteUtilityInformation(appNum, indvSeqNum, actualAry);
			}
			if (Objects.nonNull(inputAry) && !inputAry.isEmpty()) {
				for (String utilityType : inputAry) {
					if (null!=utilityType && !utilityType.isEmpty()) {
						APP_IN_HOU_BILLS_Cargo cargo = new APP_IN_HOU_BILLS_Cargo();
						cargo.setApp_num(appNum);
						cargo.setIndv_seq_num(indvSeqNum);
						seqNum = seqNum + 1;
						cargo.setSeq_num(seqNum);
						cargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
						cargo.setBill_type(utilityType);
						appInHouRepository.save(cargo);
					}
				}
			}

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"HousingExpenseEJBBean.storeOtherUtilities() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + " milliseconds", txnBean);

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.storeOtherUtilities()", txnBean);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.STORE_OTHER_UTILITIES, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}

	}

	///////////////////////////////////////////////////////////////////////////////////////
	// Rent mortgage summary
	public void loadRentMortgageSummary(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "HousingExpenseEJBBean.loadRentMortgageSummary() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			List<String> actualAry = Arrays.asList("TE", "TR", "WA", "GE", "OH");

			final APP_IN_HOU_BILLS_Collection rentInfoColl = appInHouRepository.getAppNum(Integer.parseInt(appNumber), "RH", "PT");
			final APP_IN_HOU_BILLS_Cargo[] utilityInfoCargos = appInHouRepository
					.fetchByAppNumAndBillTypeList(Integer.parseInt(appNumber), actualAry);

			APP_IN_HOU_BILLS_Collection newColl = new APP_IN_HOU_BILLS_Collection();
			if (null != rentInfoColl && !rentInfoColl.isEmpty()) {

				APP_IN_HOU_BILLS_Cargo firstCargo = rentInfoColl.getCargo(0);
				if (rentInfoColl.size() == 2) {
					APP_IN_HOU_BILLS_Cargo secondCargo = rentInfoColl.getCargo(1);
					firstCargo.setPr_pymnt_amt(secondCargo.getPymt_amt());
					firstCargo.setBill(secondCargo.getBill_type());
					if (firstCargo.getPr_select() == null && Objects.nonNull(secondCargo.getPr_select())) {
						firstCargo.setPr_select(secondCargo.getPr_select());
					}

					rentInfoColl.remove(secondCargo);
				}
				if (null != utilityInfoCargos && utilityInfoCargos.length > 0) {
					firstCargo.setUtilities_pr_select("Y");
				} else {
					firstCargo.setUtilities_pr_select(NO);
				}
				newColl = rentInfoColl;
			}

			pageCollection.put(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION, newColl);

			fwTxn.setPageCollection(pageCollection);

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in HousingExpenseServImpl.loadCareCostSummaryInformation()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.LOAD_RENT_MORTGAGE_SUMMARY, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"HousingExpenseEJBBean.loadCareCostSummaryInformation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + " milliseconds", fwTxn);
	}

/////////////////////////////////////////////////////////////////////////
//RentMortgageSummaryDelete
	public void deleteRentMortgageInformation(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpensesServImpl.deleteRentMortgageInformation() - START", txnBean);

		try {

			final Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();
			String appNum = userDetails.getAppNumber();
			final APP_IN_HOU_BILLS_Collection appInShltcCollReq = (APP_IN_HOU_BILLS_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION);
			APP_IN_HOU_BILLS_Cargo housingExpensesCargoReq = appInShltcCollReq.getCargo(0);
			int indvSeqNum = housingExpensesCargoReq.getIndv_seq_num();
			int seqNum = housingExpensesCargoReq.getSeq_num();
			APP_IN_HOU_BILLS_Collection appInShltcCollFromDB = appInHouRepository.deleteRentProperty(Integer.parseInt(appNum));
			int size = appInShltcCollFromDB.size();
			for (int i = 0; i < size; i++) {
				APP_IN_HOU_BILLS_Cargo cargo = appInShltcCollFromDB.getCargo(i);
				appInHouRepository.delete(cargo);
			}

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, DELETE_HOUSING_EXPENSES_ERROR, txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.DELETE_RENT_MORTGAGE_INFORMATION, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpensesServImpl.deleteHousingExpenses() - END", txnBean);

	}

	public void storehomelessShelterDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.storehomelessShelterDetails() - START", txnBean);

		try {
			UserDetails userDetails = txnBean.getUserDetails();
			final Map pageCollection = txnBean.getPageCollection();
			String appNum = userDetails.getAppNumber();
			int indvSeqNum = 1;
			int seqNum = 1;
			APP_IN_HOU_BILLS_Collection appInShltcCollReq = null;
			APP_IN_HOU_BILLS_Cargo shltcCargoReq = null;
			final APP_IN_HOU_BILLS_Collection beforeShltColl = appInHouRepository.getBeforeHouseBillsCollection(Integer.parseInt(appNum),
					indvSeqNum, seqNum);
			if (null != beforeShltColl && !beforeShltColl.isEmpty()) {
				shltcCargoReq = (APP_IN_HOU_BILLS_Cargo) beforeShltColl.get(0);
				appInShltcCollReq = new APP_IN_HOU_BILLS_Collection();
				appInShltcCollReq.add(shltcCargoReq);
			} else {
				appInShltcCollReq = new APP_IN_HOU_BILLS_Collection();
				shltcCargoReq = new APP_IN_HOU_BILLS_Cargo();
				shltcCargoReq.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				shltcCargoReq.setApp_num(appNum);
				shltcCargoReq.setIndv_seq_num(indvSeqNum);
				shltcCargoReq.setSeq_num((int) seqNum);
				shltcCargoReq.setBill_type(FinancialInfoConstants.HOMELESS_SHELTER_TYPE);
				appInShltcCollReq.add(shltcCargoReq);
			}
			if (!appInShltcCollReq.isEmpty()) {
				abHousingBillsBO.storeShelterCostDetails(appInShltcCollReq);
				pageCollection.put(FinancialInfoConstants.APP_IN_HOU_BILLS_COLLECTION, appInShltcCollReq);
				txnBean.setPageCollection(pageCollection);
			}
			FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl::storehomelessShelterDetails:End");
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, STORE_SHELTER_DETAIL_ERROR, txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.STORE_HOMELESS_SHELTER_DETAILS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.storeShelterDetail() - END", txnBean);
	}
	
	public void removeHomelessShelterDetails(FwTransaction txnBean) {

		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.removeHomelessShelterDetails() - START",
				txnBean);
		try {
			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			int indvSeqNum = 1;
			int seqNum = 1;
			appInHouRepository.deleteHomelessShelterInfo(Integer.parseInt(appNum), indvSeqNum, seqNum,
					FinancialInfoConstants.HOMELESS_SHELTER_TYPE);

			FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl::removeHomelessShelterDetails() - END");
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, REMOVE_SHELTER_DETAIL_ERROR, txnBean);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.REMOVE_HOMELESS_SHELTER_DETAILS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseServImpl.removeHomelessShelterDetails() - END",
				txnBean);
	}

	private APP_IN_HOU_BILLS_Cargo populateAppInBillsPart1(APP_IN_HOU_BILLS_Cargo currentCargo,
			APP_IN_HOU_BILLS_Cargo beforeCargo, String billType) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.populateAppInBillsPart1() - START");
			beforeCargo.setPymt_freq((null != currentCargo.getPymt_freq() && !currentCargo.getPymt_freq().isEmpty())
					? currentCargo.getPymt_freq()
					: beforeCargo.getPymt_freq());
			beforeCargo.setPymt_amt(
					(null != currentCargo.getPymt_amt() && currentCargo.getPymt_amt() > 0) ? currentCargo.getPymt_amt()
							: beforeCargo.getPymt_amt());
			beforeCargo.setJnt_pay_resp(
					(null != currentCargo.getJnt_pay_resp() && !currentCargo.getJnt_pay_resp().isEmpty())
							? currentCargo.getJnt_pay_resp()
							: beforeCargo.getJnt_pay_resp());
			beforeCargo.setJnt_payee_first_name((null != currentCargo.getJnt_payee_first_name()
					&& !currentCargo.getJnt_payee_first_name().isEmpty()) ? currentCargo.getJnt_payee_first_name()
							: beforeCargo.getJnt_payee_first_name());
			beforeCargo.setBill_type(billType);
			populateAppInBillsPart2(currentCargo, beforeCargo);
		
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.populateAppInBillsPart1() - END");
		return beforeCargo;
	}

	private APP_IN_HOU_BILLS_Cargo populateAppInBillsPart2(APP_IN_HOU_BILLS_Cargo currentCargo,
			APP_IN_HOU_BILLS_Cargo beforeCargo) {
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.populateAppInBillsPart2() - START");
			beforeCargo.setJnt_payee_last_name(
					(null != currentCargo.getJnt_payee_last_name() && !currentCargo.getJnt_payee_last_name().isEmpty())
							? currentCargo.getJnt_payee_last_name()
							: beforeCargo.getJnt_payee_last_name());
			beforeCargo.setPaid_amt(
					(null != currentCargo.getPaid_amt() && currentCargo.getPaid_amt() > 0) ? currentCargo.getPaid_amt()
							: beforeCargo.getPaid_amt());
			beforeCargo.setJnt_pymt_freq(
					(null != currentCargo.getJnt_pymt_freq() && !currentCargo.getJnt_pymt_freq().isEmpty())
							? currentCargo.getJnt_pymt_freq()
							: beforeCargo.getJnt_pymt_freq());
			beforeCargo
					.setLiheap_resp((null != currentCargo.getLiheap_resp() && !currentCargo.getLiheap_resp().isEmpty())
							? currentCargo.getLiheap_resp()
							: beforeCargo.getLiheap_resp());
			beforeCargo.setChg_dt(currentCargo.getChg_dt());
		
		FwLogger.log(this.getClass(), Level.INFO, "HousingExpenseEJBBean.populateAppInBillsPart2() - END");
		return beforeCargo;
	}
}
