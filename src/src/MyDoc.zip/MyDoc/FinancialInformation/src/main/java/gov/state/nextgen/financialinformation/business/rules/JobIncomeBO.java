/*
 * 
 */
package gov.state.nextgen.financialinformation.business.rules;


import java.sql.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.access.management.util.DateRoutine;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_A_WAGE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_PAY_STUB_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_PAY_STUB_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFEMP_PAY_STUB_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFEMP_PAY_STUB_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInEmplPayStubRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInEmplRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInSelfempPayStubRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInEmplRepository;

/**
 * Enter the description of the class
 *
 * @author sahooka Creation Date Jun 13, 2006 Modified By: Modified on: PCR#
 */
@Service("JobIncomeBO")
public class JobIncomeBO extends AbstractBO{
	
	private static final String MILLI = " milliseconds";
	
	private static final String ERROR_800100072 = "800100072";
	
	private static final String ERROR_10434 = "10434";

	private static final String ERROR_3018322 = "3018322";
	
	private static final String ERROR_10278 = "10278";
	
	private static final String ERROR_3018069 = "3018069";
	
	
	
	
	@Autowired
	private AppInEmplRepository appInEmplRepository;
	
	/**
	 * Constructor
	 */

	

	
	@Autowired
	private CpAppInEmplRepository cpAppInEmplRepository; 
	
	
	
	
	@Autowired
	private AppInSelfempPayStubRepository cpAppInSelfEmplPayStubRepository;
	
	@Autowired
	private AppInEmplPayStubRepository cpAppInEmplPayStubRepository;
	
	
	

	public APP_IN_EMPL_Collection loadDetails(String appNum, Integer indv_seq_num, Integer seq_num) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeBO.loadDetails() - START");
		try {
			APP_IN_EMPL_Collection appInEmplColl = new APP_IN_EMPL_Collection();

			
			
			if(appNum != null && indv_seq_num != null &&  seq_num != null) {
                
				appInEmplColl = cpAppInEmplRepository.loadDetails(Integer.parseInt(appNum), indv_seq_num, seq_num);
                 }
			 FwLogger.log(this.getClass(), FwLogger.Level.INFO,
	                 "JobIncomeBO.loadDetails() - END , Time Taken :" + (System.currentTimeMillis() - startTime)
	                 + AppConstants.SPACE + AppConstants.MILLISECONDS);
			return appInEmplColl;

		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
	}

	public Integer completenessCheck(APP_IN_EMPL_Cargo lifeinsureCargo) {

		System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
                "JobIncomeBO.completenessCheck() - START");
		try {
			if ((("RM").equals(lifeinsureCargo.getSrc_app_ind()) || ("RN").equals(lifeinsureCargo.getSrc_app_ind()))
					) {
				return 1;
			} else {
				return 0;
			}
		} catch (final Exception e) {
			throw e;
		}
	
	}

	
	
	public APP_IN_EMPL_Cargo splithosColl(APP_IN_EMPL_Collection appInEmplColl, String recordIndicator) {
        final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABHouseHoldMemberBO.splithosColl() - START");
        try {
               if (appInEmplColl != null && !appInEmplColl.isEmpty()) {
                     final int medinfoCollSize = appInEmplColl.size();
                     APP_IN_EMPL_Cargo empinfoCargo = null;
                     for (int i = 0; i < medinfoCollSize; i++) {
                    	 empinfoCargo = appInEmplColl.getResult(i);
                            if (empinfoCargo.getSrc_app_ind().equals(recordIndicator)) {
                                  return appInEmplColl.getResult(i);
                            }
                     }

               }
               FwLogger.log(this.getClass(), FwLogger.Level.INFO,
                            "ABHouseHoldMemberBO.splithosColl() - END , Time Taken : "
                                         + (System.currentTimeMillis() - startTime)
                                         + MILLI);
               return null;
        }catch (final Exception e) {
       FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
       throw e;
   }
  }

	public int getMaxEmplSeqNumber(final String appNum, final Integer indv_seq_num) {

		final long startTime = System.currentTimeMillis();
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"JobIncomeBO.getMaxEmplSeqNumber() - START"); 
		
		final Map sqlMap = new HashMap();
		Integer maxSeqNum = 0;
		try {
			sqlMap.put(FwConstants.SQL_IND, "sql-RM03");
			
               if(appNum != null && indv_seq_num != null) {
                
            	   maxSeqNum = (Integer) cpAppInEmplRepository.getMaxEmplSeqNumber(Integer.parseInt(appNum), indv_seq_num);

               }
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,"JobIncomeBO.getMaxEmplSeqNumber() - END , Time Taken : "  + (System.currentTimeMillis() - startTime) + MILLI);
			return maxSeqNum;
		} catch (final NullPointerException fe) {
			return 0;
		} catch (final Exception e) {
			throw e;
		}
	}

	public APP_IN_EMPL_Collection loadDetails(String appNum) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeBO.loadDetails() - START");
		try {
			final APP_IN_EMPL_Collection appInEmplColl = new APP_IN_EMPL_Collection();

			if(appNum != null ) {
                
         	  final APP_IN_EMPL_Cargo[] appInEmplCargoArray = cpAppInEmplRepository.loadDetails(Integer.parseInt(appNum));
  			  appInEmplColl.setResults(appInEmplCargoArray);
              }			
			
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeBO.loadDetails() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + MILLI);
			return appInEmplColl;
		} catch (final Exception e) {
			throw e;
		}
	
	}

	public void validateRMCPageContents(APP_IN_EMPL_Cargo appInEmplCargo, Integer userEndSelectionInd, String pageMode, String loopingQuestionShown) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "EmploymentBO.validateRMCPageContents() - START");
		try {
			final DateRoutine dateRoutine = DateRoutine.getInstance();
			dateRoutine.addDaysToDate(fwDate.getDate(), 30);


			
			final char[] specialChars = { '(', '.', '-', '\'', ')','/' };
			final java.util.Date dob = getDateOfBirth();
			
			String startDate = null;
			String endDate = null;
			if (((appInEmplCargo.getEmpl_type() != null) && AppConstants.EMPLOYMENT_PAST.equalsIgnoreCase(appInEmplCargo.getEmpl_type()))) {
				startDate = validateEmpDate(appInEmplCargo, startDate);

				if (!appMgr.isFieldEmpty(appInEmplCargo.getEmpl_end_dt().toString()) && !AppConstants.HIGH_DATE.equals(appInEmplCargo.getEmpl_end_dt().toString().trim())) {
					dateRoutine.subtractDaysFromDate(fwDate.getDate(), 90);
					if (!appMgr.validateDate(appInEmplCargo.getEmpl_end_dt())) {
						final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_800100072) };
						this.addMessageWithFieldValues("90461", error);
					} else if ((startDate != null) && !AppConstants.HIGH_DATE.equalsIgnoreCase(startDate)
							&& appMgr.isDateBeforeDate(appInEmplCargo.getEmpl_end_dt(), fwDate.getDate(startDate))) {
						final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_800100072), new FwMessageTextLabel("3019045") };
						this.addMessageWithFieldValues(ERROR_10434, error);
					} else if (appMgr.isDateAfterDate(appInEmplCargo.getEmpl_end_dt(), fwDate.getDate())) {
						final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_800100072), new FwMessageTextLabel("3018071") };
						this.addMessageWithFieldValues("10284", error);
					}
					else {
						final StringBuilder starDateConverter = new StringBuilder();
						endDate = appInEmplCargo.getEmpl_end_dt().toString();
						validateEndDt(endDate, starDateConverter);
					}
				}

				validateAmtPhnNum(appInEmplCargo, pageMode, specialChars, dob, startDate);

			} else {

				validateUserEndSelInd(appInEmplCargo, userEndSelectionInd, pageMode, loopingQuestionShown, dateRoutine,
						specialChars, dob);
			}

		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "EmploymentBO.validateRMCPageContents() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + MILLI);

	}

	private void validateUserEndSelInd(APP_IN_EMPL_Cargo appInEmplCargo, Integer userEndSelectionInd, String pageMode,
			String loopingQuestionShown, final DateRoutine dateRoutine, final char[] specialChars,
			final java.util.Date dob) {
		try {
		if (userEndSelectionInd == 1) {

			validateJobEndDt(appInEmplCargo, dateRoutine);

		}

		else {
			validateNameJobDet(appInEmplCargo, pageMode, loopingQuestionShown, dateRoutine, specialChars, dob);

		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateEndDt(String endDate, final StringBuilder starDateConverter) {
		try {
		if ((endDate.length() == 10) && (endDate.charAt(4) != '-')) {
			starDateConverter.append(endDate.substring(6, 10)).append("-").append(endDate.substring(0, 2)).append("-")
			.append(endDate.substring(3, 5));

		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateNameJobDet(APP_IN_EMPL_Cargo appInEmplCargo, String pageMode, String loopingQuestionShown,
			final DateRoutine dateRoutine, final char[] specialChars, final java.util.Date dob) {
		try {
		validateName(appInEmplCargo, specialChars);


		// for start date
		if (!appMgr.isFieldEmpty(appInEmplCargo.getIk_job_start_dt().toString())
				&& !AppConstants.HIGH_DATE.equals(appInEmplCargo.getIk_job_start_dt().toString().trim())) {
			valdateJobStartDt(appInEmplCargo, pageMode, dob);
		}

		validateEachMonth(appInEmplCargo);

		if (!((appInEmplCargo.getIk_job_end_dt() == null) || appInEmplCargo.getIk_job_end_dt().toString().isEmpty()
				|| AppConstants.SPACE.equals(appInEmplCargo.getIk_job_end_dt().toString().trim()) || AppConstants.HIGH_DATE.equals(appInEmplCargo.getIk_job_end_dt().toString().trim()))) {
			validateIkJobDate(appInEmplCargo, dateRoutine);

		}
		if ((loopingQuestionShown != null) && FwConstants.YES.equals(loopingQuestionShown) && appInEmplCargo.getLooping_ind() == null) {
				addMessageCode("80662");
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateAmtPhnNum(APP_IN_EMPL_Cargo appInEmplCargo, String pageMode, final char[] specialChars,
			final java.util.Date dob, String startDate) {
		try {
		validateEmpAmt(appInEmplCargo, startDate);

		if (((appInEmplCargo.getEmpl_type() != null) && AppConstants.EMPLOYMENT_PAST.equalsIgnoreCase(appInEmplCargo.getEmpl_type()))) {
			validateEmpPersonalDet(appInEmplCargo, specialChars);

			
			// for phonenumber
			validatePhnNumber(appInEmplCargo);
			// for start date
			if (!appMgr.isFieldEmpty(appInEmplCargo.getEmpl_begin_dt().toString()) && !AppConstants.HIGH_DATE.equals(appInEmplCargo.getEmpl_begin_dt().toString().trim())) {
				if (!("c").equalsIgnoreCase(pageMode)) {
					startDate = validateBegDtPageMode(appInEmplCargo, dob, startDate);
				} else {
					startDate = validateBegDate(appInEmplCargo);
				}
			}

			if (!appMgr.isFieldEmpty(appInEmplCargo.getFirst_payck_dt().toString()) && !AppConstants.HIGH_DATE.equals(appInEmplCargo.getFirst_payck_dt().toString().trim())) {
				validateFirstPayCkDate(appInEmplCargo, startDate);
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void valdateJobStartDt(APP_IN_EMPL_Cargo appInEmplCargo, String pageMode, final java.util.Date dob) {
		String startDate;
		try {
		if (!("c").equalsIgnoreCase(pageMode)) {
			validatePageMode(appInEmplCargo, dob);
		} else {
			final StringBuilder starDateConverter = new StringBuilder();
			startDate = appInEmplCargo.getIk_job_start_dt().toString();
			validateEndDt(startDate, starDateConverter);
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateJobEndDt(APP_IN_EMPL_Cargo appInEmplCargo, final DateRoutine dateRoutine) {
		try {
		if (!((appInEmplCargo.getIk_job_end_dt() == null) || appInEmplCargo.getIk_job_end_dt().toString().isEmpty()
				|| (
						(null!=appInEmplCargo.getIk_job_end_dt() && AppConstants.SPACE.equals(appInEmplCargo.getIk_job_end_dt().toString().trim())) 
							|| AppConstants.HIGH_DATE.equals(appInEmplCargo.getIk_job_end_dt().toString().trim())
					)
				)
			) {
			validateIkJobDate(appInEmplCargo, dateRoutine);

		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateFirstPayCkDate(APP_IN_EMPL_Cargo appInEmplCargo, String startDate) {
		try {
		if (!appMgr.validateDate(appInEmplCargo.getFirst_payck_dt())) {
			addMessageCode("9046"); // "Please enter valid Date First Pay expected."
		} else if ((startDate != null) && !AppConstants.HIGH_DATE.equalsIgnoreCase(startDate) && appMgr.isDateBeforeDate(appInEmplCargo.getFirst_payck_dt(), fwDate.getDate(startDate))) {
			

				addMessageCode("98045");
			
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private String validateBegDate(APP_IN_EMPL_Cargo appInEmplCargo) {
		String startDate;
		final StringBuilder starDateConverter = new StringBuilder();
		try {
		startDate = appInEmplCargo.getEmpl_begin_dt().toString();
		if ((startDate.length() == 10) && (startDate.charAt(4) != '-')) {

			starDateConverter.append(startDate.substring(6, 10)).append("-").append(startDate.substring(0, 2)).append("-")
					.append(startDate.substring(3, 5));
			startDate = starDateConverter.toString();
		}
		
		return startDate;
		} catch (final Exception e) {
			throw e;
		}
	}

	private String validateBegDtPageMode(APP_IN_EMPL_Cargo appInEmplCargo, final java.util.Date dob, String startDate) {
		try {
		if (!appMgr.validateDate(appInEmplCargo.getEmpl_begin_dt())) {
			addMessageCode("80697");
		} else if (appMgr.isDateBeforeDate(appInEmplCargo.getEmpl_begin_dt(), dob)) {
			final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018069), new FwMessageTextLabel("3018070") };
			this.addMessageWithFieldValues(ERROR_10434, error);
		} else {
			startDate = validateBegDate(appInEmplCargo);
		}
		return startDate;
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validatePhnNumber(APP_IN_EMPL_Cargo appInEmplCargo) {
		try {
		if (!appMgr.isFieldEmpty(appInEmplCargo.getEr_phone_num())) {
			if (!appMgr.isInteger(appInEmplCargo.getEr_phone_num())) {
				addMessageCode("99017");
			} else if (!appMgr.validatePhone(appInEmplCargo.getEr_phone_num())) {
				addMessageCode("99017");
			} else if ((appInEmplCargo.getEr_phone_num().charAt(0)) == '0') {
				addMessageCode("80660");
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateEachMonth(APP_IN_EMPL_Cargo appInEmplCargo) {
		try {
		if (!appMgr.isFieldEmpty(appInEmplCargo.getIk_amt_each_month().toString()) && !AppConstants.ON_FILE.equalsIgnoreCase(appInEmplCargo.getIk_amt_each_month().toString())) {
			
				if (!appMgr.isInteger(appInEmplCargo.getIk_amt_each_month().toString()) && !appMgr.isCurrency(appInEmplCargo.getIk_amt_each_month())) {
					final Object[] error = new Object[] { new FwMessageTextLabel("3018326") };
					this.addMessageWithFieldValues("10241", error);
				} else if ((Double.parseDouble(appInEmplCargo.getIk_amt_each_month().toString()) < 0)
						|| (Double.parseDouble(appInEmplCargo.getIk_amt_each_month().toString()) > 999.99)) {
					final Object[] error = new Object[] { new FwMessageTextLabel("3018326") };
					this.addMessageWithFieldValues("90460", error);
				}
			
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validatePageMode(APP_IN_EMPL_Cargo appInEmplCargo, final java.util.Date dob) {
		String startDate;
		try {
		if (!appMgr.validateDate(appInEmplCargo.getIk_job_start_dt())) {
			addMessageCode("97013");
		} else if (appMgr.isDateBeforeDate(appInEmplCargo.getIk_job_start_dt(),dob)) {
			final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018069), new FwMessageTextLabel("3018070") };
			this.addMessageWithFieldValues(ERROR_10434, error);
		} else if (appMgr.isDateAfterDate(appInEmplCargo.getIk_job_start_dt(), fwDate.getDate())) {
			final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018069), new FwMessageTextLabel("3018071") };
			this.addMessageWithFieldValues("10435", error);
		} else {
			final StringBuilder starDateConverter = new StringBuilder();
			startDate = appInEmplCargo.getIk_job_start_dt().toString();
			validateEndDt(startDate, starDateConverter);
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateName(APP_IN_EMPL_Cargo appInEmplCargo, final char[] specialChars) {
		try {
		if (appMgr.isFieldEmpty(appInEmplCargo.getIk_empl_name())) {
			final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018322) };
			this.addMessageWithFieldValues(ERROR_10278, error);
		} else if (!appMgr.isFieldEmpty(appInEmplCargo.getIk_empl_name()) && (!appMgr.isInvalidFirstChar(appInEmplCargo.getIk_empl_name())
					|| !appMgr.isSpecialAlphaNumeric(appInEmplCargo.getIk_empl_name(), specialChars))) {
			
				final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018322) };
				this.addMessageWithFieldValues("10277", error);
			
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateIkJobDate(APP_IN_EMPL_Cargo appInEmplCargo, final DateRoutine dateRoutine) {
		String endDate;
		try {
		if (!appMgr.validateDate(appInEmplCargo.getIk_job_end_dt())) {
			addMessageCode("00310");
		}

		else {
			final Date oneMonthDate = dateRoutine.addDaysToDate(fwDate.getDate(), 30);
			endDate = appInEmplCargo.getIk_job_end_dt().toString();

			if (!(AppConstants.HIGH_DATE.equals(endDate))) {
				if (!appMgr.validateDate(endDate)) {
					addMessageCode("30090");
				} else if (appMgr.isDateBeforeDate(endDate, "1900-01-01")) {
					final Object[] error = new Object[] { "Curent-Employment End Date" };
					this.addMessageWithFieldValues("20011", error);
				} else if (appMgr.isDateAfterDate(endDate, oneMonthDate)) {
					addMessageCode("30091");
				}
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}
	@SuppressWarnings("squid:S3776")
	private void validateEmpPersonalDet(APP_IN_EMPL_Cargo appInEmplCargo, final char[] specialChars) {
		try {
		if (appMgr.isFieldEmpty(appInEmplCargo.getEr_name())) {
			final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018322) };
			this.addMessageWithFieldValues(ERROR_10278, error);
		} else if (!appMgr.isFieldEmpty(appInEmplCargo.getEr_name()) && (!appMgr.isInvalidFirstChar(appInEmplCargo.getEr_name())
					|| !appMgr.isSpecialAlphaNumeric(appInEmplCargo.getEr_name(), specialChars))) {
			
				final Object[] error = new Object[] { new FwMessageTextLabel(ERROR_3018322) };
				this.addMessageWithFieldValues("10277", error);
			
		}
		// employment type
		if ((FwConstants.DEFAULT_DROPDOWN_SEL).equals(appInEmplCargo.getEr_Typ())) {
			final Object[] error = new Object[] { new FwMessageTextLabel("800114") };
			this.addMessageWithFieldValues(ERROR_10278, error);
		}
		// address line
		if (!appMgr.isFieldEmpty(appInEmplCargo.getEr_l1_address()) && !appMgr.isSpecialAlphaNumeric(appInEmplCargo.getEr_l1_address(), FinancialInfoConstants.SPECIAL_CHAR_FOR_ADDR)) {
			
			    addMessageCode("00017");
			
		}
		
// for the city
		if (!appMgr.isFieldEmpty(appInEmplCargo.getEr_city_address()) && !appMgr.isAlphaWithSpace(appInEmplCargo.getEr_city_address())) {
			
				addMessageCode("00018");
			
		}

		// for Zip Address
		if (!appMgr.isFieldEmpty(appInEmplCargo.getEr_zip_address())) {
			if (!appMgr.isInteger(appInEmplCargo.getEr_zip_address())) {
				addMessageCode("00019");
			} else if (!((appInEmplCargo.getEr_zip_address().length() == 5) || (appInEmplCargo.getEr_zip_address().length() == 9))) {
				addMessageCode("99016");
			} else if (!appMgr.isZero(appInEmplCargo.getEr_zip_address())) {
				addMessageCode("99015");
			}
		}
		} catch (final Exception e) {
			throw e;
		}
		
	}

	private void validateEmpAmt(APP_IN_EMPL_Cargo appInEmplCargo, String startDate) {
		try {
		if (!appMgr.isFieldEmpty(appInEmplCargo.getLast_payck_dt().toString()) && !AppConstants.HIGH_DATE.equals(appInEmplCargo.getLast_payck_dt().toString().trim())) {
			if (!appMgr.validateDate(appInEmplCargo.getLast_payck_dt())) {
				final Object[] error = new Object[] { new FwMessageTextLabel("800051") };
				this.addMessageWithFieldValues("90461", error);
			} else if ((startDate != null) && appMgr.isDateBeforeDate(appInEmplCargo.getLast_payck_dt(), fwDate.getDate(startDate))) {
				final Object[] error = new Object[] { new FwMessageTextLabel("800052"), new FwMessageTextLabel("3019045") };
				this.addMessageWithFieldValues(ERROR_10434, error);
			}
		}

		if (!appMgr.isFieldEmpty(appInEmplCargo.getLast_paycheck_amt().toString())) {
			if (!appMgr.isCurrency(appInEmplCargo.getLast_paycheck_amt())) {
				addMessageCode("80672");
			} else if ((Double.parseDouble(appInEmplCargo.getLast_paycheck_amt().toString()) < 0)
					|| (Double.parseDouble(appInEmplCargo.getLast_paycheck_amt().toString()) > 9999999.99)) {
				final Object[] error = new Object[] { new FwMessageTextLabel("800053") };
				this.addMessageWithFieldValues("10234", error);
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private String validateEmpDate(APP_IN_EMPL_Cargo appInEmplCargo, String startDate) {
		try {
		if (!appMgr.isFieldEmpty(appInEmplCargo.getEmpl_begin_dt().toString()) && !AppConstants.HIGH_DATE.equals(appInEmplCargo.getEmpl_begin_dt().toString().trim())) {

			startDate = appInEmplCargo.getEmpl_begin_dt().toString();

		}

		if (appMgr.isFieldEmpty(appInEmplCargo.getOn_strike_sw())) {
			addMessageCode("00625");
		}



		if (!appMgr.isFieldEmpty(appInEmplCargo.getGross_pay_amt().toString()) && !appMgr.isInteger(appInEmplCargo.getGross_pay_amt().toString())) {
			
				addMessageCode("80663");
			
		}
		return startDate;
		} catch (final Exception e) {
			throw e;
		}
	}


	public void insertExistingDetails(APP_IN_EMPL_Collection appInEmplColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeBO.insertExistingDetails() - START");
		try {
			
			APP_IN_EMPL_Collection coll = new APP_IN_EMPL_Collection();
			APP_IN_EMPL_Cargo cargo;
			APP_IN_EMPL_Cargo resCargo;
						
			if (null!=appInEmplColl && !appInEmplColl.isEmpty()) {
				for(int i=0; i<appInEmplColl.size();i++) {
					cargo = appInEmplColl.getCargo(i);
					resCargo = cpAppInEmplRepository.save(cargo);
						coll.addCargo(resCargo);
				}
			}
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeBO.insertExistingDetails() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + MILLI);
	}

	public void storeDetails(APP_IN_EMPL_Collection appInEmplColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeBO.storeDetails() - START");
		try {
			APP_IN_EMPL_Collection coll = new APP_IN_EMPL_Collection();
			APP_IN_EMPL_Cargo cargo;
			APP_IN_EMPL_Cargo resCargo;
			
			if (null!=appInEmplColl && !appInEmplColl.isEmpty()) {
				for(int i=0; i<appInEmplColl.size();i++) {
					cargo = appInEmplColl.getCargo(i);
					resCargo = cpAppInEmplRepository.save(cargo);
						coll.addCargo(resCargo);
				}
			}
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeBO.storeDetails() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + MILLI);
	}
	
	//No Title 
	public java.util.Date getDateOfBirth() {
	        final long startTime = System.currentTimeMillis();
	        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "MedicareBO.getDateOfBirth) - START");
	        try {
	        	java.util.Date dateOfBirth = null;
	        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "MedicareBO.getDateOfBirth - END , Time Taken : "
	                + (System.currentTimeMillis() - startTime) + MILLI);

	        	return dateOfBirth;
	        }catch (final Exception e) {
	            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	            throw e;
	        }
	    } 

	public APP_IN_EMPL_Cargo splitemplColl(APP_IN_EMPL_Collection emplColl, String recordIndicator) {
        final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RMCJobIncomeEJBBean.splitEmplColl() - START");
        try {
            if (emplColl != null && !emplColl.isEmpty()) {
                final int emplCollSize = emplColl.size();
                APP_IN_EMPL_Cargo emplCargo = null;
                for (int i = 0; i < emplCollSize; i++) {
                    emplCargo = emplColl.getCargo(i);
                    if (emplCargo.getSrc_app_ind().equals(recordIndicator)) {
                        return emplColl.getCargo(i);
                    }
                }

            }

            
            FwLogger.log(this.getClass(), FwLogger.Level.INFO,
                    "RMCJobIncomeEJBBean.splitEmplColl() - END , Time Taken : "
                            + (System.currentTimeMillis() - startTime)
                            + AppConstants.SPACE + AppConstants.MILLISECONDS);
            
        } catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
		return null;
    }

	public APP_IN_SELFEMP_PAY_STUB_Collection getSelfEmplPayStubForParentRecord(String appNum, Integer indvSeqNum,
			Integer seqNum) {
		try {
		if (Objects.nonNull(appNum) && Objects.nonNull(indvSeqNum) && Objects.nonNull(seqNum)) {
			return cpAppInSelfEmplPayStubRepository.findByAppNumAndIndvSeqNumAndSeqNum(Integer.parseInt(appNum), indvSeqNum, seqNum);
		}
		} catch (final Exception e) {
			throw e;
		}
		return new APP_IN_SELFEMP_PAY_STUB_Collection();
	}

	public void deleteSelfEmplPayStubForParentRecord(String appNum, Integer indvSeqNum, Integer seqNum) {
		cpAppInSelfEmplPayStubRepository.deleteByAppNumAndIndvSeqNumAndSeqNum(Integer.parseInt(appNum), indvSeqNum, seqNum);
	}

	public void insertSelfEmplPayStubRecord(List<APP_IN_SELFEMP_PAY_STUB_Cargo> payStubListArrangedInInsertOrder) {
		try {
		if (Objects.nonNull(payStubListArrangedInInsertOrder) && !payStubListArrangedInInsertOrder.isEmpty()) {
			Integer payStubSeqNum = 0;
			for (APP_IN_SELFEMP_PAY_STUB_Cargo payStubCargo : payStubListArrangedInInsertOrder) {
				payStubCargo.setPayStubSeqNum(++payStubSeqNum);
			}

			cpAppInSelfEmplPayStubRepository.saveAll(payStubListArrangedInInsertOrder);

		}
		} catch (final Exception e) {
			throw e;
		}
	}

	public List<APP_IN_SELFEMP_PAY_STUB_Cargo> getPayStubList(APP_IN_SELFEMP_PAY_STUB_Collection appInPayStubCollReq,
			String appNum, Integer indvSeqNum, Integer seqNum) {
		try {
		if (Objects.nonNull(appInPayStubCollReq) && !appInPayStubCollReq.isEmpty()) {
			APP_IN_SELFEMP_PAY_STUB_Cargo[] payStubCargos = appInPayStubCollReq.getResults();
			for (APP_IN_SELFEMP_PAY_STUB_Cargo cargo : payStubCargos) {
				cargo.setAppNum(appNum);
				cargo.setIndvSeqNum(indvSeqNum);
				cargo.setSeqNum(seqNum);
			}
			return Arrays.asList(payStubCargos);

		}
		} catch (final Exception e) {
			throw e;
		}
		return new ArrayList<>(0);
	}

	public APP_IN_EMPL_PAY_STUB_Collection getEmplPayStubForParentRecord(String appNum, Integer indvSeqNum,
			Integer seqNum) {
		try {
		if (Objects.nonNull(appNum) && Objects.nonNull(indvSeqNum) && Objects.nonNull(seqNum)) {
			return cpAppInEmplPayStubRepository.findByAppNumAndIndvSeqNumAndEmplSeqNum(Integer.parseInt(appNum), indvSeqNum, seqNum);
		}
		} catch (final Exception e) {
			throw e;
		}
		return new APP_IN_EMPL_PAY_STUB_Collection();
	}

	public void deleteEmplPayStubForParentRecord(String appNum, Integer indvSeqNum, Integer seqNum) {
		cpAppInEmplPayStubRepository.deleteByAppNumAndIndvSeqNumAndEmplSeqNum(Integer.parseInt(appNum), indvSeqNum, seqNum);
	}

	public List<APP_IN_EMPL_PAY_STUB_Cargo> getPayStubList(APP_IN_EMPL_PAY_STUB_Collection appInPayStubCollReq,
			String appNum, Integer indvSeqNum, Integer emplSeqNum) {
		try {
		if (Objects.nonNull(appInPayStubCollReq) && !appInPayStubCollReq.isEmpty()) {
			APP_IN_EMPL_PAY_STUB_Cargo[] payStubCargos = appInPayStubCollReq.getResults();
			for (APP_IN_EMPL_PAY_STUB_Cargo cargo : payStubCargos) {
				cargo.setAppNum(appNum);
				cargo.setIndvSeqNum(indvSeqNum);
				cargo.setEmplSeqNum(emplSeqNum);
			}
			return Arrays.asList(payStubCargos);

		}
		} catch (final Exception e) {
			throw e;
		}
		return new ArrayList<>(0);
	}

	public void insertEmplPayStubRecord(List<APP_IN_EMPL_PAY_STUB_Cargo> sortedPayStubList) {
		try {
		if (Objects.nonNull(sortedPayStubList) && !sortedPayStubList.isEmpty()) {
			Integer payStubSeqNum = 0;
			for (APP_IN_EMPL_PAY_STUB_Cargo payStubCargo : sortedPayStubList) {
				payStubCargo.setPayStubSeqNum(++payStubSeqNum);
			}

			cpAppInEmplPayStubRepository.saveAll(sortedPayStubList);

		}
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public APP_IN_EMPL_PAY_STUB_Collection loadAppInEmplPayStubCollection(String appNum) {
		try {
		if (Objects.nonNull(appNum)) {
			return cpAppInEmplPayStubRepository.findByAppNum(Integer.parseInt(appNum));
		}
		} catch (final Exception e) {
			throw e;
		}
		return new APP_IN_EMPL_PAY_STUB_Collection();
	}
	
	public APP_IN_SELFEMP_PAY_STUB_Collection loadAppInSelfEmpPayStubCollection(String appNum) {
		try {
		if (Objects.nonNull(appNum)) {
			return cpAppInSelfEmplPayStubRepository.findByAppNum(Integer.parseInt(appNum));
		}
		} catch (final Exception e) {
			throw e;
		}
		return new APP_IN_SELFEMP_PAY_STUB_Collection();
	}
	
	
}
