/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import javax.persistence.Embeddable;


@Embeddable
public class APP_IN_JNT_OWN_Id implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer app_number;
	
	private Integer indv_seq_num;
	
	private Integer seq_num;
	
	private Integer jnt_own_seq_num;
	
	private String aset_typ;
	
	public Integer getApp_number() {
		return app_number;
	}

	public void setApp_number(final Integer app_number) {
		this.app_number = app_number;
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * returns the aset_typ value.
	 */
	public String getAset_typ() {
		return aset_typ;
	}

	/**
	 * sets the aset_typ value.
	 */
	public void setAset_typ(final String aset_typ) {
		this.aset_typ = aset_typ;
	}

	/**
	 * returns the jnt_own_seq_num value.
	 */
	public Integer getJnt_own_seq_num() {
		return jnt_own_seq_num;
	}

	/**
	 * sets the jnt_own_seq_num value.
	 */
	public void setJnt_own_seq_num(final Integer jnt_own_seq_num) {
		this.jnt_own_seq_num = jnt_own_seq_num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((aset_typ == null) ? 0 : aset_typ.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((jnt_own_seq_num == null) ? 0 : jnt_own_seq_num.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		return result;
	}
@SuppressWarnings("squid:S3776")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		APP_IN_JNT_OWN_Id other = (APP_IN_JNT_OWN_Id) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (aset_typ == null) {
			if (other.aset_typ != null)
				return false;
		} else if (!aset_typ.equals(other.aset_typ))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		if (jnt_own_seq_num == null) {
			if (other.jnt_own_seq_num != null)
				return false;
		} else if (!jnt_own_seq_num.equals(other.jnt_own_seq_num))
			return false;
		if (seq_num == null) {
			if (other.seq_num != null)
				return false;
		} else if (!seq_num.equals(other.seq_num))
			return false;
		return true;
	}

	

}