/**
 * 
 */
package gov.state.nextgen.financialinformation.business.rules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_DC_E_LIST_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_DC_E_LIST_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_PAY_STUB_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_PAY_STUB_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppInDcEListRepository;
import gov.state.nextgen.financialinformation.data.db2.CP_ABCHS_Repository;

/**
 * @author KumariK
 *
 */
@Service("CareCostBO")
public class CareCostBO extends AbstractBO{
	
	@Autowired
	private CP_ABCHS_Repository careCostRepo;
	@Autowired
	private AppInDcEListRepository appInDcEListRepository;
	
	private static final String MILLISECONDS = "milliseconds";
	/**
	 * load data from CP_APP_IN_DC_E
	 * @param appNumber
	 * @param indv_seq_num
	 * @param src_ind
	 * @return
	 */
	public CP_ABCHS_Collection loadIndvCareCostData(String appNumber, Integer indv_seq_num, String src_ind) {
		// TODO Auto-generated method stub
		return careCostRepo.loadIndvCareCostData(Integer.parseInt(appNumber), indv_seq_num, src_ind);
	}

	public void storeCareCostData(CP_ABCHS_Cargo careCostCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostBO.storeCareCostData() - START");
		try{
			if(careCostCargo != null) {
				careCostRepo.save(careCostCargo);
			}		
		} catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostBO.storeCareCostData - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) + MILLISECONDS);
	}

	public CP_ABCHS_Collection loadCareCostData(String appNumber, String src_ind, List<Integer> indvIds) {
		try {
		return careCostRepo.loadCareCostData(Integer.parseInt(appNumber), src_ind, indvIds);
		} catch (final Exception e) {
			  FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
		      throw e;
		}
	}

	public CP_ABCHS_Collection loadIndvCareCostData(String appNumber, Integer indv_seq_num, String src_ind,
			Integer seq_num) {
		try {
		return careCostRepo.loadIndvCareCostData(Integer.parseInt(appNumber), indv_seq_num, src_ind, seq_num);
		} catch (final Exception e) {  
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
        	throw e;
		}
	}

	public void deleteCareCostData(CP_ABCHS_Cargo careCostCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostBO.deleteCareCostData() - START");
		try{
			if(careCostCargo != null) {
				careCostRepo.delete(careCostCargo);
			}		
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostBO.deleteCareCostData - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) + MILLISECONDS);
	}
	
	public void deleteDependentStubsForDependentCareExpense(String appNum, Integer indvSeqNum, Integer seqNum) {
		try {
		appInDcEListRepository.deleteByAppNumAndIndvSeqNumAndSeqNum(Integer.parseInt(appNum), indvSeqNum, seqNum);
		
		} catch (final Exception e) {
			throw e;
		}
	}

	public List<APP_IN_DC_E_LIST_Cargo> getDependentStubListFromCollection(APP_IN_DC_E_LIST_Collection dependentStubCollReq,
			String appNum, Integer indvSeqNum, Integer seqNum) {
		try {
		if (Objects.nonNull(dependentStubCollReq) && !dependentStubCollReq.isEmpty()) {
			APP_IN_DC_E_LIST_Cargo[] dependentCargos = dependentStubCollReq.getResults();
			for (APP_IN_DC_E_LIST_Cargo cargo : dependentCargos) {
				cargo.setAppNum(appNum);
				cargo.setIndvSeqNum(indvSeqNum);
				cargo.setSeqNum(seqNum);
			}
			return Arrays.asList(dependentCargos);

		}
		} catch (final Exception e) {
			throw e;
		}
		return new ArrayList<>(0);
	}

	public void insertDependentCareStubRecord(List<APP_IN_DC_E_LIST_Cargo> dependentStubList) {
		try {
		if (Objects.nonNull(dependentStubList) && !dependentStubList.isEmpty()) {
			Integer stubSeqNum = 0;
			for (APP_IN_DC_E_LIST_Cargo payStubCargo : dependentStubList) {
				payStubCargo.setStubSeqNum(++stubSeqNum);
				if (payStubCargo.getDependentIndvSeqNum() != 0) {
					payStubCargo.setInHouseholdIndicator("Y");
				} else {
					payStubCargo.setInHouseholdIndicator("N");
				}
			}

			appInDcEListRepository.saveAll(dependentStubList);

		}
		} catch (final Exception e) {
			throw e;
		}
	}

	public CP_ABCHS_Collection loadDependentCareCostData(String appNum, Integer indvSeq, Integer seqNum) {
		return careCostRepo.loadIndvCareCostData(Integer.parseInt(appNum), indvSeq, "AB", seqNum);
	}

	public APP_IN_DC_E_LIST_Collection fetchDependentCareStub(String appNum, Integer indvSeqNum,
			Integer seqNum) {
		try {
		if (Objects.nonNull(appNum) && Objects.nonNull(indvSeqNum) && Objects.nonNull(seqNum)) {
			return appInDcEListRepository.findByAppNumAndIndvSeqNumAndSeqNum(Integer.parseInt(appNum), indvSeqNum, seqNum);
		}
		return new APP_IN_DC_E_LIST_Collection();
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public CP_ABCHS_Collection loadCareCostDetails(String appNumber) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostBO.loadCareCostDetails() - START");
		CP_ABCHS_Collection cpAbchsCollection= new CP_ABCHS_Collection();
		try{
			if(appNumber != null) {
				cpAbchsCollection=careCostRepo.loadCareCostDetails(Integer.parseInt(appNumber));
			}	
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostBO.loadCareCostDetails - END , Time Taken : "+ (System.currentTimeMillis() - startTime) + MILLISECONDS);
		return cpAbchsCollection;
	}
	
	public APP_IN_DC_E_LIST_Collection fetchDependentCareList(String appNum) {
		try {
		if (Objects.nonNull(appNum)) {
			return appInDcEListRepository.findByAppNum(Integer.parseInt(appNum));
		}
		} catch (final Exception e) {
			throw e;
		}
		return new APP_IN_DC_E_LIST_Collection();
	}

	/**
	 * Changes as per CSPM-41333.
	 * 
	 * @param appNum as Integer
	 * @param indvSeqNum as Integer
	 * @param seqNum as Integer
	 * @return as CP_ABCHS_Cargo
	 */
	public CP_ABCHS_Cargo getCareCostExpenseDetail(Integer appNum, Integer indvSeqNum, Integer seqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostBO.getCareCostExpenseDetail() - START");
		CP_ABCHS_Cargo careCostCargo = null;
		try {
			careCostCargo = careCostRepo.getCareCostExpenseDetail(appNum, indvSeqNum, seqNum);
		}catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostBO.getCareCostExpenseDetail - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime) + MILLISECONDS);
		return careCostCargo;
	}
}
