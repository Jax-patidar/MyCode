/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * This java bean contains the entities of APP_IN_R_PROP_ASET
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Tue Mar 13 16:05:47 CST 2007 Modified By: Modified on: PCR#
 */

@Entity
@Table(name = "CP_APP_IN_R_PROP_ASSET")
@IdClass(APP_IN_R_PROP_ASET_PrimaryKey.class)
public class APP_IN_R_PROP_ASET_Cargo extends AbstractCargo implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Transient
	private String ecp_id;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	@Column(name="indv_live_ind")
	private String individual_live_ind;
	private String indv_plan_live_ind;
	@Transient
	private Integer num_acres;
	@Transient
	private Double prop_fmv_amt;
	@Transient
	private Double prop_owe_amt;
	@Transient
	private String jnt_own_resp;
	private String property_currently_rented_ind;
	@Transient
	private String property_producing_income_ind;
	@Transient
	private String property_rented_for_sale_ind;
	private String property_change_ownership_ind;
	@Transient
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date asset_acquired_dt;
	private String rec_cplt_ind;
	private String src_app_ind;
	// following are deprecated by EDSP_CP TEAM
	private String intn_ret_sw;
	@Transient
	private String prop_adr_ind;
	@Column(name="prop_city_address")
	private String prop_city_adr;
	@Transient
	private Integer prop_fmv_amt_ind;
	@Column(name="prop_l1_address")
	private String prop_l1_adr;
	@Column(name="prop_l2_address")
	private String prop_l2_adr;
	@Transient
	private Integer prop_owe_amt_ind;
	@Column(name="prop_sta_address")
	private String prop_sta_adr;
	@Column(name="prop_zip_address")
	private String prop_zip_adr;
	@Column(name="real_prop_asset_type")
	private String real_prop_aset_typ;
	@Transient
	private String res_sw;
	@Transient
	private String rlt_cd;
	@Transient
	private String sale_agr_sw;
	@Transient
	private String sps_live_sw;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date asset_end_dt;
	@Transient
	private String loopingQuestion;
	@Column(name="prop_address_zip4")
	private String propAddrZip4;
	@Column(name="change_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_dt;
	private String how_often_rent_paid;
	private Integer rent_amt;
	
	@Column(name =   "r_prop_calsaws_object")
	private String rPropCalsawsObject;
	
	//CSPM_14666
	@Column(name = "value_")
	private Double value;
	
	@Column(name = "amount_owed")
	private Double amountOwed;
	
	@Column(name="plan_to_live_someday_ind")
	private String planToLiveSomedayInd;
	
	@Column(name="former_house_ind")
	private String formerHouseInd;
	
	@Column(name="for_sale_ind")
	private String forSaleInd;
	
	@Column(name="family_ind")
	private String familyInd;
	
	@Column(name="family_relation")
	private String familyRelation;
	
	@Column(name="vehicle_property_type_desc")
	private String vehicleandpropertytypeDesc;
	
	public String getIndv_plan_live_ind() {
		return indv_plan_live_ind;
	}
	public void setIndv_plan_live_ind(String indv_plan_live_ind) {
		this.indv_plan_live_ind = indv_plan_live_ind;
	}
	
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	public String getEcp_id() {
		return ecp_id;
	}
	public void setEcp_id(String ecp_id) {
		this.ecp_id = ecp_id;
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public Integer getSeq_num() {
		return seq_num;
	}
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	public String getIndividual_live_ind() {
		return individual_live_ind;
	}
	public void setIndividual_live_ind(String individual_live_ind) {
		this.individual_live_ind = individual_live_ind;
	}
	public Integer getNum_acres() {
		return num_acres;
	}
	public void setNum_acres(Integer num_acres) {
		this.num_acres = num_acres;
	}
	public Double getProp_fmv_amt() {
		return prop_fmv_amt;
	}
	public void setProp_fmv_amt(Double prop_fmv_amt) {
		this.prop_fmv_amt = prop_fmv_amt;
	}
	public Double getProp_owe_amt() {
		return prop_owe_amt;
	}
	public void setProp_owe_amt(Double prop_owe_amt) {
		this.prop_owe_amt = prop_owe_amt;
	}
	public String getJnt_own_resp() {
		return jnt_own_resp;
	}
	public void setJnt_own_resp(String jnt_own_resp) {
		this.jnt_own_resp = jnt_own_resp;
	}
	public String getProperty_currently_rented_ind() {
		return property_currently_rented_ind;
	}
	public void setProperty_currently_rented_ind(String property_currently_rented_ind) {
		this.property_currently_rented_ind = property_currently_rented_ind;
	}
	public String getProperty_producing_income_ind() {
		return property_producing_income_ind;
	}
	public void setProperty_producing_income_ind(String property_producing_income_ind) {
		this.property_producing_income_ind = property_producing_income_ind;
	}
	public String getProperty_rented_for_sale_ind() {
		return property_rented_for_sale_ind;
	}
	public void setProperty_rented_for_sale_ind(String property_rented_for_sale_ind) {
		this.property_rented_for_sale_ind = property_rented_for_sale_ind;
	}
	public String getProperty_change_ownership_ind() {
		return property_change_ownership_ind;
	}
	public void setProperty_change_ownership_ind(String property_change_ownership_ind) {
		this.property_change_ownership_ind = property_change_ownership_ind;
	}
	public Date getAsset_acquired_dt() {
		return asset_acquired_dt;
	}
	public void setAsset_acquired_dt(Date asset_acquired_dt) {
		this.asset_acquired_dt = asset_acquired_dt;
	}
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public String getIntn_ret_sw() {
		return intn_ret_sw;
	}
	public void setIntn_ret_sw(String intn_ret_sw) {
		this.intn_ret_sw = intn_ret_sw;
	}
	public String getProp_adr_ind() {
		return prop_adr_ind;
	}
	public void setProp_adr_ind(String prop_adr_ind) {
		this.prop_adr_ind = prop_adr_ind;
	}
	public String getProp_city_adr() {
		return prop_city_adr;
	}
	public void setProp_city_adr(String prop_city_adr) {
		this.prop_city_adr = prop_city_adr;
	}
	public Integer getProp_fmv_amt_ind() {
		return prop_fmv_amt_ind;
	}
	public void setProp_fmv_amt_ind(Integer prop_fmv_amt_ind) {
		this.prop_fmv_amt_ind = prop_fmv_amt_ind;
	}
	public String getProp_l1_adr() {
		return prop_l1_adr;
	}
	public void setProp_l1_adr(String prop_l1_adr) {
		this.prop_l1_adr = prop_l1_adr;
	}
	public String getProp_l2_adr() {
		return prop_l2_adr;
	}
	public void setProp_l2_adr(String prop_l2_adr) {
		this.prop_l2_adr = prop_l2_adr;
	}
	public Integer getProp_owe_amt_ind() {
		return prop_owe_amt_ind;
	}
	public void setProp_owe_amt_ind(Integer prop_owe_amt_ind) {
		this.prop_owe_amt_ind = prop_owe_amt_ind;
	}
	public String getProp_sta_adr() {
		return prop_sta_adr;
	}
	public void setProp_sta_adr(String prop_sta_adr) {
		this.prop_sta_adr = prop_sta_adr;
	}
	public String getProp_zip_adr() {
		return prop_zip_adr;
	}
	public void setProp_zip_adr(String prop_zip_adr) {
		this.prop_zip_adr = prop_zip_adr;
	}
	public String getReal_prop_aset_typ() {
		return real_prop_aset_typ;
	}
	public void setReal_prop_aset_typ(String real_prop_aset_typ) {
		this.real_prop_aset_typ = real_prop_aset_typ;
	}
	public String getRes_sw() {
		return res_sw;
	}
	public void setRes_sw(String res_sw) {
		this.res_sw = res_sw;
	}
	public String getRlt_cd() {
		return rlt_cd;
	}
	public void setRlt_cd(String rlt_cd) {
		this.rlt_cd = rlt_cd;
	}
	public String getSale_agr_sw() {
		return sale_agr_sw;
	}
	public void setSale_agr_sw(String sale_agr_sw) {
		this.sale_agr_sw = sale_agr_sw;
	}
	public String getSps_live_sw() {
		return sps_live_sw;
	}
	public void setSps_live_sw(String sps_live_sw) {
		this.sps_live_sw = sps_live_sw;
	}
	public Date getAsset_end_dt() {
		return asset_end_dt;
	}
	public void setAsset_end_dt(Date asset_end_dt) {
		this.asset_end_dt = asset_end_dt;
	}
	public String getLoopingQuestion() {
		return loopingQuestion;
	}
	public void setLoopingQuestion(String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}
	public String getPropAddrZip4() {
		return propAddrZip4;
	}
	public void setPropAddrZip4(String propAddrZip4) {
		this.propAddrZip4 = propAddrZip4;
	}
	public Date getChg_dt() {
		return chg_dt;
	}
	public void setChg_dt(Date chg_dt) {
		this.chg_dt = chg_dt;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getHow_often_rent_paid() {
		return how_often_rent_paid;
	}
	public void setHow_often_rent_paid(String how_often_rent_paid) {
		this.how_often_rent_paid = how_often_rent_paid;
	}
	public Integer getRent_amt() {
		return rent_amt;
	}
	public void setRent_amt(Integer rent_amt) {
		this.rent_amt = rent_amt;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	public Double getAmountOwed() {
		return amountOwed;
	}
	public void setAmountOwed(Double amountOwed) {
		this.amountOwed = amountOwed;
	}
	public String getPlanToLiveSomedayInd() {
		return planToLiveSomedayInd;
	}
	public void setPlanToLiveSomedayInd(String planToLiveSomedayInd) {
		this.planToLiveSomedayInd = planToLiveSomedayInd;
	}
	public String getFormerHouseInd() {
		return formerHouseInd;
	}
	public void setFormerHouseInd(String formerHouseInd) {
		this.formerHouseInd = formerHouseInd;
	}
	public String getForSaleInd() {
		return forSaleInd;
	}
	public void setForSaleInd(String forSaleInd) {
		this.forSaleInd = forSaleInd;
	}
	public String getFamilyInd() {
		return familyInd;
	}
	public void setFamilyInd(String familyInd) {
		this.familyInd = familyInd;
	}
	public String getFamilyRelation() {
		return familyRelation;
	}
	public void setFamilyRelation(String familyRelation) {
		this.familyRelation = familyRelation;
	}
	public String getrPropCalsawsObject() {
		return rPropCalsawsObject;
	}
	public void setrPropCalsawsObject(String rPropCalsawsObject) {
		this.rPropCalsawsObject = rPropCalsawsObject;
	}
	public String getVehicleandpropertytypeDesc() {
		return vehicleandpropertytypeDesc;
	}
	public void setVehicleandpropertytypeDesc(String vehicleandpropertytypeDesc) {
		this.vehicleandpropertytypeDesc = vehicleandpropertytypeDesc;
	}
}