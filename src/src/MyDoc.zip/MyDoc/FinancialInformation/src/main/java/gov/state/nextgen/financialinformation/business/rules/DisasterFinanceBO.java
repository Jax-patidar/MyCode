package gov.state.nextgen.financialinformation.business.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.CP_ASSETS_DISASTER_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_ASSETS_DISASTER_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_EXPENSE_DISASTER_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_EXPENSE_DISASTER_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_INCOME_DISASTER_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_INCOME_DISASTER_Collection;
import gov.state.nextgen.financialinformation.data.db2.CpExpensesDisasterRepository;
import gov.state.nextgen.financialinformation.data.db2.CpIncomeDisasterRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAssetsDisasterRepository;


@Service(value="DisasterFinanceBO")
public class DisasterFinanceBO extends AbstractBO {
	
	@Autowired
	private CpIncomeDisasterRepository cpIncomeDisasterRepository;
	
	@Autowired
	private CpExpensesDisasterRepository cpExpensesDisasterRepository;
	
	@Autowired
	private CpAssetsDisasterRepository cpAssetsDisasterRepository;
	
	private static String milliSeconds = " milliseconds";

	/**
	 * store Income Details
	 * @param cpIncomeDisasterCargo 
	 */
	public void storeIncomeDisasterDetails(CP_INCOME_DISASTER_Cargo cpIncomeDisasterCargo) {
		
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"DisasterFinanceBO.storeIncomeDisasterDetails- START");
		try {
	            if(cpIncomeDisasterCargo != null){
	            	cpIncomeDisasterRepository.save(cpIncomeDisasterCargo);
	            }
	   } catch (final Exception ex) {
		  throw ex;
		   
		} 
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DisasterFinanceBO.storeIncomeDisasterDetails - END , Time Taken : " + (System.currentTimeMillis() - startTime) + milliSeconds);	
	}
   
	public CP_INCOME_DISASTER_Collection loadIncomeDetails(String appNumber) {
		
		FwLogger.log(this.getClass(), Level.INFO,
				"DisasterFinanceBO.loadIncomeDetails() - START");
		
		CP_INCOME_DISASTER_Collection cpIncomeDisasterColl = new CP_INCOME_DISASTER_Collection();
		
		try {
			cpIncomeDisasterColl = cpIncomeDisasterRepository.getIncomeByAppNum(Integer.parseInt(appNumber));
		
		}catch (Exception ex) {
				 throw ex;
		 }
		
		FwLogger.log(this.getClass(), Level.INFO, "DisasterFinanceBO.loadIncomeDetails() - END");
		
		return cpIncomeDisasterColl;
	}
	
	public void storeExpensesDetails(CP_EXPENSE_DISASTER_Cargo cpExpensesDisasterCargo) {
		
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"DisasterFinanceBO.storeExpensesDetails- START");
		try {
	            if(cpExpensesDisasterCargo != null){
	            	cpExpensesDisasterRepository.save(cpExpensesDisasterCargo);
	            }
	   } catch (final Exception ex) {
		  throw ex;
		   
		} 
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DisasterFinanceBO.storeExpensesDetails - END , Time Taken : " + (System.currentTimeMillis() - startTime) + milliSeconds);	
		
	}

	public CP_EXPENSE_DISASTER_Collection loadExpensesDetailsByType(String appNumber, String expType) {
		
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"DisasterFinanceBO.loadExpensesDetailsByType) - START");
		
		CP_EXPENSE_DISASTER_Collection cpExpensesDisasterColl = new CP_EXPENSE_DISASTER_Collection();

		try {
			cpExpensesDisasterColl = cpExpensesDisasterRepository.getExpenseDetailsByType(Integer.parseInt(appNumber),expType);
		}catch (final Exception ex) {
			 throw ex;
		}
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DisasterFinanceBO.loadExpensesDetailsByType - END , Time Taken : " + (System.currentTimeMillis() - startTime) + milliSeconds);
		
		return cpExpensesDisasterColl;
			
		
	}

	public void deleteExpensesCargo(CP_EXPENSE_DISASTER_Cargo existingCargo) {
		
		FwLogger.log(this.getClass(), Level.INFO,
				"DisasterFinanceBO.deleteExpensesCargo() - START");

		try {
			
			cpExpensesDisasterRepository.delete(existingCargo);
			
		 }catch (final Exception ex) {
			throw ex;
		 }
		FwLogger.log(this.getClass(), Level.INFO, "DisasterFinanceBO.deleteExpensesCargo() - END");
	}

	public CP_EXPENSE_DISASTER_Collection loadExpensesSummaryDetails(String appNumber) {
		
		FwLogger.log(this.getClass(), Level.INFO,
				"DisasterFinanceBO.LoadExpensesSummary() - START");
		
		CP_EXPENSE_DISASTER_Collection cpExpensesDisasterColl = new CP_EXPENSE_DISASTER_Collection();
		
		try {
			cpExpensesDisasterColl = cpExpensesDisasterRepository.getExpenseSummaryDetails(Integer.parseInt(appNumber));
		
		}catch (Exception ex) {
			throw ex;
		 }
		
		FwLogger.log(this.getClass(), Level.INFO, "DisasterFinanceBO.LoadExpensesSummary() - END");
		
		return cpExpensesDisasterColl;
	}

	/*************************************************************************************************************************************************************
	 * 
	 * Method to store disasterAssetDetails to DB
	 * 
	 * @param cpAssetsDisasterCargo
	 * @param appNumber
	 * @author arunkuj
	 * 
	 ************************************************************************************************************************************************************/
	public void storeAssetDisaterDetails(CP_ASSETS_DISASTER_Cargo cpAssetsDisasterCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DisasterFinanceBO.storeAssetDisaterDetails- START");
		try {
				cpAssetsDisasterRepository.save(cpAssetsDisasterCargo);
		} catch (final Exception ex) {
			throw ex;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"DisasterFinanceBO.storeAssetDisaterDetails - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) +milliSeconds);
	}

	/*************************************************************************************************************************************************************
	 * 
	 * Method to get all the entries for "CP_ASSETS_DISASTER_Cargo" from DB
	 * 
	 * @param appNumber
	 * 
	 * @author arunkuj
	 * @return
	 * 
	 ************************************************************************************************************************************************************/
	public CP_ASSETS_DISASTER_Collection getAssestDisaterDetails(String appNumber) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DisasterFinanceBO.storeAssetDisaterDetails- START");
		CP_ASSETS_DISASTER_Collection cpAssetsDiasasterCollection = new CP_ASSETS_DISASTER_Collection();
		try {
			cpAssetsDiasasterCollection = cpAssetsDisasterRepository.findAllByAppNum(Integer.parseInt(appNumber));
		} catch (final Exception ex) {
			throw ex;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"DisasterFinanceBO.storeAssetDisaterDetails - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) +milliSeconds);

		return cpAssetsDiasasterCollection;
	}



}
