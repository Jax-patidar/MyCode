package gov.state.nextgen.financialinformation.business.rules;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.StringTokenizer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.AppValidationManager;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_DEDUCTION_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_INCOME_TAX_DED_Collection;
import gov.state.nextgen.financialinformation.data.db2.CP_APP_IN_DEDUCTION_Repository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInIncomeTaxDedRepository;

@Service("ABOtherExpensesQuestionsBO")
public class ABOtherExpensesQuestionsBO extends AbstractBO {

	@Autowired
	private CP_APP_IN_DEDUCTION_Repository dedRepository;



	@Autowired
	private AppValidationManager appMgrs;
	
	@Autowired
	private CpAppInIncomeTaxDedRepository cpAppInIncomeTaxDedRepository;

	private static final String TILDE = "~";
	private static final String MSG_30075 = "30075";

	private static final String LOOP_QES_MSG_CD = "00170";

	private static final String CHILD_SUP_ORDER_IND = "00166";
	private static final String ERROR_10034 = "10034";
	private static final String MILLI = " milliseconds";

	public CP_APP_IN_DEDUCTION_Collection getDedCollection(String appNumber, int indvSeqNum) {

		return dedRepository.findByAppNumIndv(Integer.parseInt(appNumber), indvSeqNum);
	}

	public APP_INDV_Cargo getIndividual() {
		return null;
	}

	/**
	 * Child Support Payment Details Validations
	 * 
	 * @param appOblgCargo            obligation data cargo
	 * @param firstName               individual first name
	 * @param pagemode                page mode
	 * @param showLoopingQuestionFlag looping flag
	 * @return validation error messages
	 */
	public FwMessageList validateRMBOblgStatus(final CP_APP_IN_DEDUCTION_Cargo appOblgCargo, final String firstName,
			final String pagemode, final String showLoopingQuestionFlag) {

		FwMessageList validationInfo = new FwMessageList();
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesQuestionsBO.validateRMBOblgStatus() - START");
		try {
			final char[] specials = { '(', '.', '-', '\'', ')', ' ' };

			StringBuilder oneHundred20yearsAgo = null;
			final Calendar now = Calendar.getInstance();
			final int thisYear = now.get(Calendar.YEAR);
			oneHundred20yearsAgo = new StringBuilder(String.valueOf(thisYear - 120));
			oneHundred20yearsAgo = oneHundred20yearsAgo.append("-01-01");
			if (pagemode != null && "E".equals(pagemode)) {
				validatePageMode(appOblgCargo, validationInfo, oneHundred20yearsAgo);
			} else {

				// is ChildSupport Ordered By Court?
				validateChildSuppDet(appOblgCargo, validationInfo);

				// Child Support Payment Amt
				validateChildIncDet(appOblgCargo, firstName, validationInfo);
				
				// Child Name
				if (!appMgrs.isFieldEmpty(appOblgCargo.getChld_sup_payee_nam())) {

					if (!appMgrs.isSpecialAlphaNumeric(appOblgCargo.getChld_sup_payee_nam(), specials)) {
						validationInfo.addMessageToList(addMessageCode("10510"));

					} else if (appOblgCargo.getChld_sup_payee_nam().startsWith("0")) {
						validationInfo.addMessageToList(addMessageCode("00008"));

					} else if (!appMgrs.isSpecialAlpha(appOblgCargo.getChld_sup_payee_nam(), specials)) {
						validationInfo.addMessageToList(addMessageCode("10510"));
					}

				} else {
					validationInfo.addMessageToList(addMessageCode("00169"));
				}

				// Other ChildSupport?
				validateOtherChildSuppDet(appOblgCargo, showLoopingQuestionFlag, validationInfo, oneHundred20yearsAgo);

				FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesQuestionsBO.validateRMBOblgStatus() - END");
			}
			return validationInfo;
		} catch (final Exception e) {
			throw e;
		}

	}

	private void validateOtherChildSuppDet(final CP_APP_IN_DEDUCTION_Cargo appOblgCargo,
			final String showLoopingQuestionFlag, FwMessageList validationInfo, StringBuilder oneHundred20yearsAgo) {
		if ((FwConstants.YES).equalsIgnoreCase(showLoopingQuestionFlag) && appMgrs.isFieldEmpty(appOblgCargo.getLoopingInd())) {
			
				validationInfo.addMessageToList(addMessageCode(LOOP_QES_MSG_CD));
			
		}
		if (appOblgCargo.getChg_dt() != null) {
			if (appMgrs.isFieldEmpty(appOblgCargo.getChg_dt().toString())) {
				validationInfo.addMessageToList(addMessageCode("99368"));
			}
			if (!appMgrs.isFieldEmpty(appOblgCargo.getChg_dt().toString())
					&& !appMgrs.validateDate(appOblgCargo.getChg_dt())) {
				validationInfo.addMessageToList(addMessageCode("99365"));
			}
			if (appMgrs.isDateBeforeDate(appOblgCargo.getChg_dt(),
					Date.valueOf(oneHundred20yearsAgo.toString()))) {
				validationInfo.addMessageToList(addMessageCode("99366"));
			}
			java.util.Date nxtMnthLastDt = getNxtMnthlastDt();

			if (appMgrs.isDateAfterDate(appOblgCargo.getChg_dt(), nxtMnthLastDt)) {
				validationInfo.addMessageToList(addMessageCode("99367"));
			}
		}
	}

	private void validateChildIncDet(final CP_APP_IN_DEDUCTION_Cargo appOblgCargo, final String firstName,
			FwMessageList validationInfo) {
		if (!appMgrs.isFieldEmpty(appOblgCargo.getExp_amt().toString())) {

			if (appOblgCargo.getExp_amt() != null
					&& !appMgrs.isValidAmountLimit(appOblgCargo.getExp_amt().toString())) {
				validationInfo.addMessageToList(addMessageCode(ERROR_10034));
			} else {
				try {
					Double.parseDouble(appOblgCargo.getExp_amt().toString());
				} catch (final Exception e) {
					validationInfo.addMessageToList(addMessageCode("00152"));
				}
			}

		} else {
			validationInfo.addMessageToList(addMessageCode("00168"));
		}

		// Child Support Payment Amt
		if (appMgrs.isFieldEmpty(appOblgCargo.getPay_freq_cd())
				|| FwConstants.DEFAULT_DROPDOWN_SEL.equals(appOblgCargo.getPay_freq_cd())) {
			final Object[] error = new Object[] { firstName };
			validationInfo.addMessageToList(addMessageWithFieldValues("00738", error));
		}

	}

	private void validateChildSuppDet(final CP_APP_IN_DEDUCTION_Cargo appOblgCargo, FwMessageList validationInfo) {
		if (appMgrs.isFieldEmpty(appOblgCargo.getCourt_order_pay_chld_sup_ind())) {
			validationInfo.addMessageToList(addMessageCode(CHILD_SUP_ORDER_IND));
		}

		// ChildSupport Ordered By Court Amt
		if (appMgrs.isFieldEmpty(appOblgCargo.getCourt_order_pay_amt().toString())) {
			if (!appMgrs.isFieldEmpty(appOblgCargo.getCourt_order_pay_chld_sup_ind())
					&& "Y".equalsIgnoreCase(appOblgCargo.getCourt_order_pay_chld_sup_ind())) {
				validationInfo.addMessageToList(addMessageCode("00167"));
			}
		} else {
			if (appOblgCargo.getCourt_order_pay_amt() != null
					&& !appMgrs.isValidAmountLimit(appOblgCargo.getCourt_order_pay_amt().toString())) {
				validationInfo.addMessageToList(addMessageCode(ERROR_10034));
			} else {
				try {
					Double.parseDouble(appOblgCargo.getCourt_order_pay_amt().toString());
				} catch (final Exception e) {
					validationInfo.addMessageToList(addMessageCode("00152"));
				}
			}
		}
	}

	private void validatePageMode(final CP_APP_IN_DEDUCTION_Cargo appOblgCargo, FwMessageList validationInfo,
			StringBuilder oneHundred20yearsAgo) {
		if (appMgrs.isFieldEmpty(appOblgCargo.getExp_end_date().toString())) {
			validationInfo.addMessageToList(addMessageCode("99091"));
		}

		if (!appMgrs.isFieldEmpty(appOblgCargo.getExp_end_date().toString())) {
			 if ((!appMgrs.futureDate(appOblgCargo.getExp_end_date()))||(appMgrs.isDateBeforeDate(appOblgCargo.getExp_end_date(),
					Date.valueOf(oneHundred20yearsAgo.toString())))) {
				validationInfo.addMessageToList(addMessageCode("00147"));
			} 
		}
	}

	public boolean checkBackToMyAccessSelected(final Map request) {
		if (request.get(AppConstants.BACK_TO_MY_ACCESS_BUTTON) == null) {
			return false;
		}
		final String reqWarningMsgs = (String) request.get(FwConstants.WARNING_MSG_DETAILS);
		if ((reqWarningMsgs != null) && (reqWarningMsgs.trim().length() > 0)) {
			// Tokenizing the request warrning message and putting into a
			// list
			final StringTokenizer tokenizer = new StringTokenizer(reqWarningMsgs, TILDE);
			final List reqMsgList = new ArrayList();
			while (tokenizer.hasMoreElements()) {
				reqMsgList.add(tokenizer.nextElement());
			}
			if (reqMsgList.contains(MSG_30075)) {
				return true;
			}
		}
		final FwMessageList messageList = new FwMessageList();

		messageList.addMessageToList(addMessageCode(MSG_30075));
		request.put(FwConstants.MESSAGE_LIST, messageList);
		return true;
	}

	public CP_APP_IN_DEDUCTION_Cargo splitChildObligCargo(final CP_APP_IN_DEDUCTION_Collection cldInfoColl,
			final String recordIndicator) {
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.splitChildCareCargo() - START");
		try {
		if (cldInfoColl != null && !cldInfoColl.isEmpty()) {
			final int cldInfoCollSize = cldInfoColl.size();
			CP_APP_IN_DEDUCTION_Cargo cldInfoCargo = null;
			for (int i = 0; i < cldInfoCollSize; i++) {
				cldInfoCargo = cldInfoColl.getCargo(i);
				if (cldInfoCargo.getSrc_app_ind().equals(recordIndicator)) {
					return cldInfoCargo;
				}
			}

		}
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesDetailsBO.splitChildCareCargo() - END");
		return null;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public int getMaxSeqNumber(String appNumber, int indvSeqNum) {
		int seqNum = 0;
		try {
		Integer result = dedRepository.findMaxSeqNum(Integer.parseInt(appNumber), indvSeqNum);
		if (result != null) {
			seqNum = result;
		}
		return seqNum;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public void storeAppInOblgIns(CP_APP_IN_DEDUCTION_Collection cpAppInDedPersistColl) {
		try {
		for (CP_APP_IN_DEDUCTION_Cargo data : cpAppInDedPersistColl.getResults()) {
			dedRepository.save(data);
		}
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public FwMessageList validateChildSupportDetails(
			final CP_APP_IN_DEDUCTION_Collection esignColl) {
		try {
		final CP_APP_IN_DEDUCTION_Cargo appInDedCargo = esignColl.getCargo(0);

		
		FwMessageList validationInfo = new FwMessageList();
		FwLogger.log(this.getClass(), Level.INFO,
				"ABOtherExpensesQuestionsBO.validateChildSupportDetails() - START");
		if(!(Objects.isNull(appInDedCargo.getCourt_order_pay_amt())) && !appMgrs.isFieldEmpty(Double.toString(appInDedCargo.getCourt_order_pay_amt()))) {
			
				if (!appMgrs.isCurrency(appInDedCargo.getCourt_order_pay_amt())) {
					validationInfo.addMessageToList(addMessageCode("80681"));
				} else if (!appMgrs.isValidAmountLimit(Double.toString(appInDedCargo
						.getCourt_order_pay_amt()))) {
					validationInfo.addMessageToList(addMessageCode(ERROR_10034));
				}
			
		}
		if(!(Objects.isNull(appInDedCargo.getExp_amt())) && !appMgrs.isFieldEmpty(Double.toString(appInDedCargo.getExp_amt()))) {
			
				if (!appMgrs.isCurrency(appInDedCargo.getExp_amt())) {

					validationInfo.addMessageToList(addMessageCode("80685"));
				} else if (!appMgrs.isValidAmountLimit(Double.toString(appInDedCargo
						.getExp_amt()))) {
					validationInfo.addMessageToList(addMessageCode(ERROR_10034));
				}
			
		}

		          FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesQuestionsBO.validateChildSupportDetails() - END");
			return validationInfo;
		} catch (final Exception e) {
			throw e;
		}
	}

	
	public CP_APP_IN_DEDUCTION_Collection loadIndividualDeductionDetails(
			final String appNumber, final Integer indvSeqNum,
			final Integer seqNum, final String type) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"LiquidAssetBO.loadIndividualLiquidAssetDetails() - START");
		try {
			final CP_APP_IN_DEDUCTION_Collection appInColl = dedRepository.loadIndividualDeductionDetails(Integer.parseInt(appNumber), indvSeqNum, seqNum, type);

		
			FwLogger.log(this.getClass(), Level.INFO,
					"LiquidAssetBO.loadIndividualLiquidAssetDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public CP_APP_IN_DEDUCTION_Collection splitChildOblgCargo(
			final CP_APP_IN_DEDUCTION_Collection cldInfoColl,
			final String recordIndicator) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"ABOtherExpensesQuestionsBO.splitChildOblgCargo() - START");

		try {
			final CP_APP_IN_DEDUCTION_Collection returnColl = new CP_APP_IN_DEDUCTION_Collection();
			if (cldInfoColl != null && !cldInfoColl.isEmpty()) {
				final int cldinfoCollSize = cldInfoColl.size();
				CP_APP_IN_DEDUCTION_Cargo cldInfoCargo = null;
				for (int i = 0; i < cldinfoCollSize; i++) {
					cldInfoCargo = cldInfoColl.getCargo(i);
					if (cldInfoCargo.getSrc_app_ind().equals(recordIndicator)) {
						returnColl.addCargo(cldInfoCargo);
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesQuestionsBO.splitChildOblgCargo() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return returnColl;

		} catch (final Exception e) {
			throw e;
		}

	}
	
	public CP_APP_IN_DEDUCTION_Cargo splitCldOblgCargo(
			final CP_APP_IN_DEDUCTION_Collection oblgInfoColl,
			final String recordIndicator) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesQuestionsBO.splitCldOblgCargo() - START");

		try {
			if (oblgInfoColl != null && !oblgInfoColl.isEmpty()) {
				final int oblginfoCollSize = oblgInfoColl.size();
				CP_APP_IN_DEDUCTION_Cargo oblgInfoCargo = null;
				for (int i = 0; i < oblginfoCollSize; i++) {
					oblgInfoCargo = oblgInfoColl.getCargo(i);
					if (oblgInfoCargo.getSrc_app_ind().equals(recordIndicator)) {
						return oblgInfoCargo;
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesQuestionsBO.splitCldOblgCargo() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return null;

		} catch (final Exception e) {
			throw e;
		}

	}
	
	public CP_APP_IN_DEDUCTION_Cargo settingDefaultValues(
			final CP_APP_IN_DEDUCTION_Cargo cldOblgInfoCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"ABOtherExpensesQuestionsBO.settingDefaultValues() - START");
			if (cldOblgInfoCargo != null && cldOblgInfoCargo.getSrc_app_ind() == null) {

				
					cldOblgInfoCargo.setSrc_app_ind(FwConstants.EMPTY_STRING);
				

			}
			FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesQuestionsBO.settingDefaultValues() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return cldOblgInfoCargo;
	}
	
	public CP_APP_IN_DEDUCTION_Collection loadAppCldOblg(final String appNumber, final Integer indvSeqNum, final Integer seqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesQuestionsBO.loadAppCldOblg() - START");
		try {
		    CP_APP_IN_DEDUCTION_Collection appCldOblgColl = dedRepository.loadAppCldOblg(Integer.parseInt(appNumber),indvSeqNum,seqNum);
			FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesQuestionsBO.loadAppCldOblg() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return appCldOblgColl;
		}catch (final Exception e) {
			throw e;
		}
	}
	
	
	public CP_APP_IN_DEDUCTION_Collection splitCldOblgCargo(
			final CP_APP_IN_DEDUCTION_Collection oblgInfoColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesQuestionsBO.splitCldOblgCargo() - START");

			final CP_APP_IN_DEDUCTION_Collection returnColl = new CP_APP_IN_DEDUCTION_Collection();
			if (oblgInfoColl != null && !oblgInfoColl.isEmpty()) {
				final int oblginfoCollSize = oblgInfoColl.size();
				CP_APP_IN_DEDUCTION_Cargo oblgInfoCargo = null;
				for (int i = 0; i < oblginfoCollSize; i++) {
					oblgInfoCargo = oblgInfoColl.getCargo(i);
					if (AppConstants.CWW_RECORD_IND.equals(oblgInfoCargo
							.getSrc_app_ind())
							|| AppConstants.RMC_MODIFIED_RECORD_IND
							.equals(oblgInfoCargo.getSrc_app_ind())) {
						returnColl.addCargo(oblgInfoCargo);
					}
				}

			}
			FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesQuestionsBO.splitCldOblgCargo() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return returnColl;


	}
	
	public CP_APP_IN_DEDUCTION_Collection loadChildObligationCoverageIndv(
			final String appNumber, final Integer indvSeqNum, final Integer seqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"ABOtherExpensesQuestionsBO.loadChildObligationCoverageIndv() - START");
		try {
			final CP_APP_IN_DEDUCTION_Collection appInCldIndvColl = dedRepository.loadChildObligationCoverageIndv(Integer.parseInt(appNumber), indvSeqNum, seqNum);
			FwLogger.log(this.getClass(), Level.INFO,
					"ABOtherExpensesQuestionsBO.loadChildObligationCoverageIndv() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return appInCldIndvColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	public CP_APP_IN_DEDUCTION_Collection loadIndividualDeductionDetails(
			final String appNumber, final String type) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"LiquidAssetBO.loadIndividualLiquidAssetDetails() - START");
		try {
			final CP_APP_IN_DEDUCTION_Collection appInColl = dedRepository.findByAppNumType(Integer.parseInt(appNumber), type);

		
			FwLogger.log(this.getClass(), Level.INFO,
					"LiquidAssetBO.loadIndividualLiquidAssetDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public CP_APP_IN_DEDUCTION_Collection loadIndividualDeductionDetailsForRenewels(
			final String appNumber, final String type,final List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"LiquidAssetBO.loadIndividualLiquidAssetDetails() - START");
		try {
			final CP_APP_IN_DEDUCTION_Collection appInColl = dedRepository.findByAppNumTypeForRenewels(Integer.parseInt(appNumber), type,indvIds);

		
			FwLogger.log(this.getClass(), Level.INFO,
					"LiquidAssetBO.loadIndividualLiquidAssetDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return appInColl;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	
	
	//Alimony and Student Loan Interest data- save
			public void saveAlimonyStLoanDetails(CP_APP_IN_INCOME_TAX_DED_Cargo inTaxDeductionCargo) {
				final long startTime = System.currentTimeMillis();
				FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherExpensesQuestionsBO.saveAlimonyStLoanDetails() - START");
				try{
					cpAppInIncomeTaxDedRepository.save(inTaxDeductionCargo);
							
				}catch (Exception e) {
			          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
			          throw e;
			        }
						 
						 
			      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherExpensesQuestionsBO.saveAlimonyStLoanDetails() - END , Time Taken : "
			              + (System.currentTimeMillis() - startTime) + MILLI);	
			}
			
			//Load Alimony/Student Loan Interest data based on appnum and exp type
			public CP_APP_IN_INCOME_TAX_DED_Collection loadAlimonyStLoanDetails(String appnum, String pageId) {
				
				final long startTime = System.currentTimeMillis();
		        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherExpensesQuestionsBO.loadAlimonyStLoanDetails() - START");
		        CP_APP_IN_INCOME_TAX_DED_Collection inTaxDeductionColl = new CP_APP_IN_INCOME_TAX_DED_Collection();
		       
		        try {
		        	if(appnum != null && !appnum.isEmpty()) {
		        		CP_APP_IN_INCOME_TAX_DED_Cargo[] inTaxDeductionCargoArr = cpAppInIncomeTaxDedRepository.getInTaxDeductionForAppExpType(Integer.parseInt(appnum),pageId);
		        		if(inTaxDeductionCargoArr != null && inTaxDeductionCargoArr.length > 0) {
		        			inTaxDeductionColl.setResults(inTaxDeductionCargoArr);
		        		}
		        	}
		        }catch (Exception e) {
		            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
					  throw e;
					 
		        }
		        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherExpensesQuestionsBO.loadAlimonyStLoanDetails() - END , Time Taken : "
			              + (System.currentTimeMillis() - startTime) + MILLI);	
				return inTaxDeductionColl;
			}

			//Delete Alimony/Student Loan Interest data based on appnum,seqNum,indvSeqNum and exp type
			public void deleteAlimonyStLoanDetails(CP_APP_IN_INCOME_TAX_DED_Cargo inTaxDeductionCargo) {
				final long startTime = System.currentTimeMillis();
		        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherExpensesQuestionsBO.deleteAlimonyStLoanDetails() - START");
		        try {
		        	cpAppInIncomeTaxDedRepository.delete(inTaxDeductionCargo);
		        }catch (Exception e) {
		            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
					  throw e;
					 
		        }
		        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABOtherExpensesQuestionsBO.deleteAlimonyStLoanDetails() - END , Time Taken : "
			              + (System.currentTimeMillis() - startTime) + MILLI);	
			}
			
			public CP_APP_IN_DEDUCTION_Collection getAppInDeductionDetails(String appNumber){
				final long startTime = System.currentTimeMillis();
				FwLogger.log(this.getClass(), Level.INFO,"ABOtherExpensesQuestionsBO.getAppInDeductionDetails() - START");
				try {
					final CP_APP_IN_DEDUCTION_Collection appInColl = dedRepository.findByAppNum(Integer.parseInt(appNumber));				
					FwLogger.log(this.getClass(), Level.INFO,"ABOtherExpensesQuestionsBO.getAppInDeductionDetails() - END , Time Taken : "+ (System.currentTimeMillis() - startTime)+ MILLI);
					return appInColl;
				} catch (final Exception e) {
					throw e;
				}
			
			}
			public CP_APP_IN_INCOME_TAX_DED_Collection getAppInDeductionTaxByAppNum(String appNumber){
				final long startTime = System.currentTimeMillis();
				FwLogger.log(this.getClass(), Level.INFO,"ABOtherExpensesQuestionsBO.getAppInDeductionTaxByAppNum() - START");
				try {
					final CP_APP_IN_INCOME_TAX_DED_Collection appInColl = cpAppInIncomeTaxDedRepository.loadIndividualIncomeTaxDedByAppNum(Integer.parseInt(appNumber));				
					FwLogger.log(this.getClass(), Level.INFO,"ABOtherExpensesQuestionsBO.getAppInDeductionTaxByAppNum() - END , Time Taken : "+ (System.currentTimeMillis() - startTime)+ MILLI);
					return appInColl;
				} catch (final Exception e) {
					throw e;
				}
			
			}
	
}
