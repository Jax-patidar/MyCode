package gov.state.nextgen.financialinformation.business.services;


import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.CP_ASSETS_DISASTER_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_EXPENSE_DISASTER_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_EXPENSE_DISASTER_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_INCOME_DISASTER_Collection;
import gov.state.nextgen.financialinformation.business.rules.DisasterFinanceBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.framework.business.model.UserDetails;



/**
 * DCF Expense Service
 * 
 * @author Swabehera
 *
 */

@Service("DCFExpensesService")
public class DCFExpensesServiceImpl implements FinancialServInterface{
	
	@Autowired
	private DisasterFinanceBO disasterFinanceBO;
    
	private static String milliSeconds = " milliseconds";
	
	/**
	 * To call specific business method of the same bean
	 */
	
	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {

		switch (methodName) {

		case FinancialInfoConstants.STORE_DCF_EXPENSES_DETAILS:
			this.storeDCFExpensesDetails(txnBean);
			break;

		case FinancialInfoConstants.REMOVE_DCF_EXPENSES_DETAILS:
			this.deleteDCFExpenses(txnBean);
			break;

		case FinancialInfoConstants.LOAD_DCF_EXPENSES_SUMMARY:
			this.loadDCFExpenseSummary(txnBean);
			break;		
		case FinancialInfoConstants.LOAD_DCF_SPECIFIC_EXPENSE:
			this.loadDCFSpecificExpense(txnBean);
			break;
		case FinancialInfoConstants.LOAD_DCF_FINSUMMARY_DETAILS:
			this.loadDCFFinancialSummaryDetails(txnBean);
			break;
		default:
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"No Service called");
		}

	}
    
	

	private void loadDCFFinancialSummaryDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DCFExpensesServiceImpl.loadDCFFinancialSummaryDetails() - START", txnBean);
		final Map<String,Object> pageCollection = txnBean.getPageCollection();
		UserDetails userDetails = txnBean.getUserDetails();
		String appNumber = userDetails.getAppNumber();
		
		try {
			CP_INCOME_DISASTER_Collection incomeColl = disasterFinanceBO.loadIncomeDetails(appNumber);
			pageCollection.put(FinancialInfoConstants.CP_INCOME_DISASTER_COLLECTION, incomeColl);
			
			CP_ASSETS_DISASTER_Collection assetColl = disasterFinanceBO.getAssestDisaterDetails(appNumber);
			pageCollection.put(FinancialInfoConstants.CP_ASSETS_DISASTER_COLLECTION, assetColl);
			
			loadDCFExpenseSummary(txnBean);
			
			
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, "Inside exception block with below error", e);
			pageCollection.put(FinancialInfoConstants.CP_INCOME_DISASTER_COLLECTION, null);
			pageCollection.put(FinancialInfoConstants.CP_ASSETS_DISASTER_COLLECTION, null);
			FwExceptionManager.handleException(e,this.getClass().getName(),
					FinancialInfoConstants.LOAD_DCF_FINSUMMARY_DETAILS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		} finally {
			txnBean.setPageCollection(pageCollection);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DCFExpensesServiceImpl.loadDCFFinancialSummaryDetails() - END", txnBean);
		
	}



	public void storeDCFExpensesDetails(final FwTransaction fwTxn) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DCFExpensesServiceImpl.storeDCFExpensesDetails() - START", fwTxn);

		Map<String, Object> pageCollection = null;

		CP_EXPENSE_DISASTER_Cargo cpExpensesDisasterCargo = null;
		CP_EXPENSE_DISASTER_Collection cpExpensesDisasterColl = null;

		String appNumber = FinancialInfoConstants.EMPTY_STR;
		String expType = FinancialInfoConstants.EMPTY_STR;

		try {
			appNumber = fwTxn.getUserDetails().getAppNumber();
			pageCollection = fwTxn.getPageCollection();
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
				expType = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			}
			if (pageCollection.get(FinancialInfoConstants.CP_EXPENSE_DISASTER_COLLECTION) != null) {
				cpExpensesDisasterColl = (CP_EXPENSE_DISASTER_Collection) pageCollection
						.get(FinancialInfoConstants.CP_EXPENSE_DISASTER_COLLECTION);
				cpExpensesDisasterCargo = cpExpensesDisasterColl.getCargo(0);

				cpExpensesDisasterCargo.setApp_num(appNumber);
				cpExpensesDisasterCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				cpExpensesDisasterCargo.setExp_type(expType);
				disasterFinanceBO.storeExpensesDetails(cpExpensesDisasterCargo);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in storeDCFExpensesDetails.storeDCFExpensesDetails()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "storeDCFExpensesDetails",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		} finally {
			fwTxn.setPageCollection(pageCollection);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"DCFExpensesServiceImpl.storeDCFExpensesDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + milliSeconds, fwTxn);

	}
	
	private void deleteDCFExpenses(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DCFExpensesServiceImpl.deleteDCFExpenses() - START", fwTxn);

		Map<String, Object> pageCollection = null;
		String expType = FinancialInfoConstants.EMPTY_STR;
		String appNumber = FinancialInfoConstants.EMPTY_STR;

		try {
			appNumber = fwTxn.getUserDetails().getAppNumber();
			pageCollection = fwTxn.getPageCollection();
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
				expType = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			}

			CP_EXPENSE_DISASTER_Collection existingExpensesDisasterColl = disasterFinanceBO
					.loadExpensesDetailsByType(appNumber, expType);
			if (Objects.nonNull(existingExpensesDisasterColl) && !existingExpensesDisasterColl.isEmpty()) {
				CP_EXPENSE_DISASTER_Cargo existingCargo = existingExpensesDisasterColl.getCargo(0);
				if (Objects.nonNull(existingCargo))
					disasterFinanceBO.deleteExpensesCargo(existingCargo);
			}

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in DCFExpensesServiceImpl.deleteDCFExpenses()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "deleteDCFExpenses",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		} finally {
			fwTxn.setPageCollection(pageCollection);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"DCFExpensesServiceImpl.deleteDCFExpenses() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + milliSeconds, fwTxn);

	}

	private void loadDCFExpenseSummary(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DCFExpensesServiceImpl.loadDCFExpenseSummary() - START", fwTxn);

		Map<String, Object> pageCollection = null;
		String appNumber = FinancialInfoConstants.EMPTY_STR;
		try {
			appNumber = fwTxn.getUserDetails().getAppNumber();
			pageCollection = fwTxn.getPageCollection();

			CP_EXPENSE_DISASTER_Collection existingExpensesDisasterColl = disasterFinanceBO
					.loadExpensesSummaryDetails(appNumber);

			if (Objects.nonNull(existingExpensesDisasterColl) && !existingExpensesDisasterColl.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.CP_EXPENSE_DISASTER_COLLECTION, existingExpensesDisasterColl);
			}
			

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in DCFExpensesServiceImpl.loadDCFExpenseSummary()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadDCFExpenseSummary",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		} finally {
			fwTxn.setPageCollection(pageCollection);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"DCFExpensesServiceImpl.loadDCFExpenseSummary() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + milliSeconds, fwTxn);

	}
	private void loadDCFSpecificExpense(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "DCFExpensesServiceImpl.loadDCFSpecificExpense() - START", fwTxn);

		Map<String, Object> pageCollection = null;
		String appNumber = FinancialInfoConstants.EMPTY_STR;
		String expType = FinancialInfoConstants.EMPTY_STR;
		try {
			appNumber = fwTxn.getUserDetails().getAppNumber();
			pageCollection = fwTxn.getPageCollection();
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())) {
				expType = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategoryType();
			}
			CP_EXPENSE_DISASTER_Collection existingExpensesDisasterColl = disasterFinanceBO
					.loadExpensesDetailsByType(appNumber, expType);

			pageCollection.put(FinancialInfoConstants.CP_EXPENSE_DISASTER_COLLECTION, existingExpensesDisasterColl);

		} catch (Exception exception) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in DCFExpensesServiceImpl.loadDCFSpecificExpense()", fwTxn);
			FwExceptionManager.handleException(exception, this.getClass().getName(), "loadDCFSpecificExpense",
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		} finally {
			fwTxn.setPageCollection(pageCollection);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"DCFExpensesServiceImpl.loadDCFSpecificExpense() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + milliSeconds, fwTxn);
		
	}

	
	
	

}
