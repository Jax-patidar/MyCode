/*
 *
 */
package gov.state.nextgen.financialinformation.business.rules;

import gov.state.nextgen.access.management.constants.AppConstants;

import gov.state.nextgen.financialinformation.business.entities.APP_IN_BILLS_RESP_FOR_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_BILLS_RESP_FOR_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_HOU_BILLS_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UTILC_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UTILC_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_UTILC_Custom_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_UTILC_Custom_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppInBillsRespRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInHouRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInPrflRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInUtilcRepository;
import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.access.management.util.AppValidationManager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("ABHousingBillsBO")
public class ABHousingBillsBO extends AbstractBO {

	private AppInBillsRespRepository appInBillsRespRepository;

	private AppInUtilcRepository appInUtilcRepository;
	
	@Autowired
	private AppInHouRepository appInHouRepository;
	
	private AppInPrflRepository appInPrflRepository;

	@Autowired
	private AppValidationManager appMgrs;
	@Autowired
	private IReferenceTableManager iref;


	private static final String EMPTY_STRING = FwConstants.EMPTY_STRING;


	private static final String ADDRS_PATTERN = "[A-Za-z0-9'\\.\\-\\s\\,]*";

	private static final String PROP_NAME_PATTERN = "[A-Za-z0-9\\s]+";
	private static final String PROP_ZIP_PATTERN = "[0-9]*";

	private static final String AMOUNT_MSG_CD = "00152";



	
	
	private static final String PROP_NAME_MSG_CD = "99102";
	private static final String ADD_LN_MSG_CD = "00017";
	private static final String PROP_ZIP_MSG_CD = "00019";
	private static final String PROP_ZIP_MSG_1_CD = "00022";
	private static final String MESSAGECODE = "10503";
	
	private static final String BILL_TYPE_RENT = "RM";
	
	private static final String DATE_FORMAT = "yyyy-MM-dd";
	
	private static final String MILLI = " milliseconds";
	
	

	/**
	 * Constructor
	 * @throws Exception 
	 */

	public APP_IN_UTILC_Collection getUtilityCollection(final String appNumber,
			final CP_APP_IN_UTILC_Custom_Cargo customCargo, final Integer indivdidualSequenceNumber,
			final String rowAction) throws Exception {
		final APP_IN_UTILC_Collection utilcColl = new APP_IN_UTILC_Collection();
		APP_IN_UTILC_Cargo utilcCargo = null;

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.getUtilityCollection() - START");
		try {

			setCustomCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, utilcColl);

			if (customCargo.getUtil_electric_resp() != null || customCargo.getUtil_sewage_resp() != null
					|| customCargo.getUtil_garbage_resp() != null || customCargo.getUtil_phone_resp() != null
					|| customCargo.getUtil_gas_resp() != null || customCargo.getUtil_water_resp() != null
					|| customCargo.getUtil_fuel_resp() != null) {
				utilcCargo = new APP_IN_UTILC_Cargo();
				utilcCargo.setUtil_typ("UT");
				utilcCargo.setApp_num(appNumber);
				utilcCargo.setSrc_app_ind("AB");
				utilcCargo.setChg_eff_dt(new SimpleDateFormat(DATE_FORMAT).parse(AppConstants.HIGH_DATE));
				utilcCargo.setRec_cplt_ind(1);
				utilcCargo.setSeq_num(1);
				utilcCargo.setMo_oblg_ind(1);
				utilcCargo.setRowAction(rowAction);
				utilcCargo.setIndv_seq_num(indivdidualSequenceNumber);
				utilcCargo.setUtil_electric_resp(customCargo.getUtil_electric_resp());
				utilcCargo.setUtil_sewage_resp(customCargo.getUtil_sewage_resp());
				utilcCargo.setUtil_garbage_resp(customCargo.getUtil_garbage_resp());
				utilcCargo.setUtil_phone_resp(customCargo.getUtil_phone_resp());
				utilcCargo.setUtil_gas_resp(customCargo.getUtil_gas_resp());
				utilcCargo.setUtil_water_resp(customCargo.getUtil_water_resp());
				utilcCargo.setUtil_fuel_resp(customCargo.getUtil_fuel_resp());
				utilcCargo.setUtil_total_amt(Double.parseDouble(customCargo.getUtil_total_amt()));
				utilcCargo.setMo_hsld_pay_amt(Double.parseDouble(customCargo.getMo_hsld_pay_amt()));
				utilcColl.addCargo(utilcCargo);
			}
		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.getUtilityCollection() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLI);
		return utilcColl;

	}

	/**
	 * @param appNumber
	 * @param customCargo
	 * @param indivdidualSequenceNumber
	 * @param rowAction
	 * @param utilcColl
	 * @throws ParseException
	 */
	private void setCustomCargoData(final String appNumber, final CP_APP_IN_UTILC_Custom_Cargo customCargo,
			final Integer indivdidualSequenceNumber, final String rowAction, final APP_IN_UTILC_Collection utilcColl)
			throws ParseException {
		APP_IN_UTILC_Cargo utilcCargo;
		try {
		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getCoalMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "CO",customCargo.getCoalMonthlyAmount());
		
		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getElectricityMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "EL",customCargo.getElectricityMonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getGasMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "GA",customCargo.getGasMonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getKerosineMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "KE",customCargo.getKerosineMonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getOilMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "OI",customCargo.getOilMonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getWoodMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "WO",customCargo.getWoodMonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getWaterMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "SE",customCargo.getWaterMonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getGarbageMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "TR",customCargo.getGarbageMonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getInstallationMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "IN",customCargo.getInstallationMonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getTelephoneMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "PH",customCargo.getTelephoneMonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getOtherMonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "O1",customCargo.getOtherMonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getOther2MonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "O2",customCargo.getOther2MonthlyAmount());

		utilcCargo = setUtilcCargoData(appNumber, customCargo, indivdidualSequenceNumber, rowAction, customCargo.getOther3MonthlyAmount());
		setUtilTypes(utilcColl, utilcCargo, "O3",customCargo.getOther3MonthlyAmount());
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * @param utilcColl
	 * @param utilcCargo
	 * @param type 
	 * @param amount 
	 */
	private void setUtilTypes(final APP_IN_UTILC_Collection utilcColl, APP_IN_UTILC_Cargo utilcCargo, String type, String amount) {

		try {
		if (amount != null && amount.trim().length() > 0) {
		utilcCargo.setUtil_typ(type);
		utilcColl.addCargo(utilcCargo);
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * @param appNumber
	 * @param customCargo
	 * @param indivdidualSequenceNumber
	 * @param rowAction
	 * @param amount
	 * @return 
	 * @throws ParseException
	 */
	private APP_IN_UTILC_Cargo setUtilcCargoData(final String appNumber, final CP_APP_IN_UTILC_Custom_Cargo customCargo,
			final Integer indivdidualSequenceNumber, final String rowAction, final String amount)
			throws ParseException {
		try {
		APP_IN_UTILC_Cargo utilcCargo = new APP_IN_UTILC_Cargo();
		if (amount != null && amount.trim().length() > 0) {
			utilcCargo.setMo_oblg_amt(Double.parseDouble(amount));
			utilcCargo.setApp_num(appNumber);
			utilcCargo.setSrc_app_ind("AB");
			utilcCargo.setChg_eff_dt(new SimpleDateFormat(DATE_FORMAT).parse(AppConstants.HIGH_DATE));
			utilcCargo.setSomeone_else_pay_ind(customCargo.getSomeoneElsePays());
			utilcCargo.setRec_cplt_ind(1);
			utilcCargo.setSeq_num(1);
			utilcCargo.setRowAction(rowAction);
			utilcCargo.setIndv_seq_num(indivdidualSequenceNumber);
			utilcCargo.setMo_oblg_ind(1);
		}
		return utilcCargo;
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * @param appNumber
	 * @param indvSeqNum
	 * @param appInUtilcColl
	 * @return
	 */
	public CP_APP_IN_UTILC_Custom_Collection getUtilitiesCustomCollection(final String appNumber,
			final Integer indvSeqNum, final APP_IN_UTILC_Collection appInUtilcColl) {
		APP_IN_UTILC_Cargo utilityCargo = null;
		final CP_APP_IN_UTILC_Custom_Collection utilityCustomCollection = new CP_APP_IN_UTILC_Custom_Collection();
		CP_APP_IN_UTILC_Custom_Cargo utilityCustomCargo = null;

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.getUtilitiesCustomCollection) - START");
		try {
		// If database returned values, populate the Custom Cargo
		if (appInUtilcColl != null && !appInUtilcColl.isEmpty()) {
			utilityCustomCargo = new CP_APP_IN_UTILC_Custom_Cargo();
			utilityCustomCargo.setApplicationNumber(appNumber);
			utilityCustomCargo.setIndivdiualSequenceNumber(indvSeqNum);
			for (int i = 0; i < appInUtilcColl.size(); i++) {
				setUtilityCustomCargoData(appInUtilcColl, utilityCustomCargo, i);
			}
		}

		// Add custom cargo to custom collection
		utilityCustomCollection.addCargo(utilityCustomCargo);

		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.getUtilitiesCustomCollection - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLI);

		return utilityCustomCollection;
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * @param appInUtilcColl
	 * @param utilityCustomCargo
	 * @param i
	 */
	@SuppressWarnings("squid:S3776")
	private void setUtilityCustomCargoData(final APP_IN_UTILC_Collection appInUtilcColl,
			CP_APP_IN_UTILC_Custom_Cargo utilityCustomCargo, int i) {
		try {
		APP_IN_UTILC_Cargo utilityCargo;
		utilityCargo = (APP_IN_UTILC_Cargo) appInUtilcColl.get(i);
		if ("EL".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setElectricityMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("GA".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setGasMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("KE".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setKerosineMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("CO".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setCoalMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("OI".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setOilMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("WO".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setWoodMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("SE".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setWaterMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("TR".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setGarbageMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("IN".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setInstallationMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("PH".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setTelephoneMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("O1".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setOtherMonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("O2".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setOther2MonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		} else if ("O3".equalsIgnoreCase(utilityCargo.getUtil_typ())) {
			utilityCustomCargo.setOther3MonthlyAmount(utilityCargo.getMo_oblg_amt().toString());
		}
		utilityCustomCargo.setSomeoneElsePays(utilityCargo.getSomeone_else_pay_ind());
		utilityCustomCargo.setUtil_electric_resp(utilityCargo.getUtil_electric_resp());
		utilityCustomCargo.setUtil_sewage_resp(utilityCargo.getUtil_sewage_resp());
		utilityCustomCargo.setUtil_garbage_resp(utilityCargo.getUtil_garbage_resp());
		utilityCustomCargo.setUtil_phone_resp(utilityCargo.getUtil_phone_resp());
		utilityCustomCargo.setUtil_gas_resp(utilityCargo.getUtil_gas_resp());
		utilityCustomCargo.setUtil_water_resp(utilityCargo.getUtil_water_resp());
		utilityCustomCargo.setUtil_fuel_resp(utilityCargo.getUtil_fuel_resp());
		utilityCustomCargo.setMo_hsld_pay_amt(utilityCargo.getMo_hsld_pay_amt()!=null?utilityCargo.getMo_hsld_pay_amt().toString():null);
		utilityCustomCargo.setUtil_total_amt(utilityCargo.getUtil_total_amt()!=null?utilityCargo.getUtil_total_amt().toString():null);

		} catch (final Exception e) {
			throw e;
		}
	}

	public void storeShelterCostDetails(final APP_IN_HOU_BILLS_Collection appInShltcColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.storeShelterCostDetails) - START");

		try {
			if (null != appInShltcColl && !appInShltcColl.isEmpty()) {
				appInHouRepository.saveAll(appInShltcColl);
			}
		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.storeShelterCostDetails - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLI);
	}

	/**
	 * Method description here
	 */
	public void storeUtilityCostDetails(final APP_IN_UTILC_Collection appInUtilcColl) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.storeUtilityCostDetails) - START");

		try {
			if (null != appInUtilcColl && !appInUtilcColl.isEmpty()) {
				appInUtilcRepository.saveAll(appInUtilcColl);
			}
		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.storeUtilityCostDetails - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLI);
	}
	@SuppressWarnings("squid:S3776")
	public FwMessageList validatePageContents(final APP_IN_HOU_BILLS_Cargo cargo, final String langCD) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.validatePageContents) - START");
		FwMessageList fwMessageList = new FwMessageList();
		try {
			String totalPaid = null;
			if(Objects.nonNull(cargo.getPaid_amt())) {
				totalPaid = cargo.getPaid_amt().toString();
			}
			if(Objects.nonNull(cargo.getPymt_amt())) {
			String amount = cargo.getPymt_amt().toString();
			validateAmount(amount, fwMessageList);
			}
			if(Objects.nonNull(totalPaid)) {
				validateAmount(totalPaid, fwMessageList);
			}

			
			if (BILL_TYPE_RENT.equals(cargo.getBill_type())) {
				setMessageForBillTypeRent(cargo, langCD, fwMessageList);

				final String type = iref.getColumnValue("THBT", 59, cargo.getBill_type(), langCD);
				final String[] message = new String[1];
				message[0] = type;
				cargo.getJnt_pay_resp();

				final String propName = cargo.getProperty_name();
				if (propName != null && !EMPTY_STRING.equals(propName) && !isValidName(PROP_NAME_PATTERN, propName)) {
					fwMessageList.addMessageToList(addMessageCode(PROP_NAME_MSG_CD));
				}
				final String addressLine1 = cargo.getProp_addr_l1();
				if (addressLine1 != null && !EMPTY_STRING.equals(addressLine1.trim())
						&& !isValidAddress(addressLine1)) {
					this.addMessageWithFieldValues(ADD_LN_MSG_CD, message);
				}
				final String addressLine2 = cargo.getProp_addr_l2();
				if (addressLine2 != null && !EMPTY_STRING.equals(addressLine2.trim())
						&& !isValidAddress(addressLine2)) {
					this.addMessageWithFieldValues(ADD_LN_MSG_CD, message);
				}
				final String zipNumber = cargo.getProp_addr_zip();
				if (zipNumber != null && !EMPTY_STRING.equals(zipNumber) && !isValidName(PROP_ZIP_PATTERN, zipNumber)) {
					if (!(cargo.getProp_addr_zip().length() == 5)) {
						fwMessageList.addMessageToList(addMessageCode(MESSAGECODE));
					}
					this.addMessageWithFieldValues(PROP_ZIP_MSG_CD, message);
				} else if (zipNumber != null && !EMPTY_STRING.equals(zipNumber)) {
					if (!(cargo.getProp_addr_zip().length() == 5)) {
						fwMessageList.addMessageToList(addMessageCode(MESSAGECODE));
					}
					try {
						final long zipNum = Long.parseLong(zipNumber);
						if (zipNum == 0) {
							this.addMessageWithFieldValues(PROP_ZIP_MSG_1_CD, message);
						}
					} catch (final Exception e) {
						this.addMessageWithFieldValues(PROP_ZIP_MSG_CD, message);
					}
				}
				if (fwMessageList.containsMessage(PROP_ZIP_MSG_CD) && cargo.getPropAddrZip4() != null
						&& !"".equals(cargo.getPropAddrZip4().trim()) && !cargo.getPropAddrZip4().matches("\\d+")) {
					fwMessageList.addMessageToList(addMessageCode(PROP_ZIP_MSG_CD));
				}

				final String city = cargo.getProp_addr_city();
				if (StringUtils.isNotBlank(city) && !appMgrs.isAlphaWithSpace(city)) {

					fwMessageList.addMessageToList(addMessageCode("00018"));
					
				}

			
				if (BILL_TYPE_RENT.equals(cargo.getBill_type())) {
					setMessageForBillTypeRent(cargo, langCD, fwMessageList);
				}
			}
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.validatePageContents - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime) + MILLI);
		return fwMessageList;
	}

	/**
	 * @param cargo
	 * @param langCD
	 * @param fwMessageList
	 */
	private void setMessageForBillTypeRent(final APP_IN_HOU_BILLS_Cargo cargo, final String langCD,
			FwMessageList fwMessageList) {
		try {
		final String type = iref.getColumnValue("THBT", 59, cargo.getBill_type(), langCD);
		final String[] message = new String[1];
		message[0] = type;
		cargo.getJnt_pay_resp();

		final String propName = cargo.getProperty_name();
		if (propName != null && !EMPTY_STRING.equals(propName) && !isValidName(PROP_NAME_PATTERN, propName)) {
			fwMessageList.addMessageToList(addMessageCode(PROP_NAME_MSG_CD));
		}
		final String addressLine1 = cargo.getProp_addr_l1();
		if (addressLine1 != null && !EMPTY_STRING.equals(addressLine1.trim())
				&& !isValidAddress(addressLine1)) {
			this.addMessageWithFieldValues(ADD_LN_MSG_CD, message);
		}
		final String addressLine2 = cargo.getProp_addr_l2();
		if (addressLine2 != null && !EMPTY_STRING.equals(addressLine2.trim())
				&& !isValidAddress(addressLine2)) {
			this.addMessageWithFieldValues(ADD_LN_MSG_CD, message);
		}
		validateZipCode(cargo, fwMessageList, message);
		if (fwMessageList.containsMessage(PROP_ZIP_MSG_CD) && cargo.getPropAddrZip4() != null
				&& !"".equals(cargo.getPropAddrZip4().trim()) && !cargo.getPropAddrZip4().matches("\\d+")) {
			fwMessageList.addMessageToList(addMessageCode(PROP_ZIP_MSG_CD));
		}

		final String city = cargo.getProp_addr_city();
		if (StringUtils.isNotBlank(city)) {
			if (!appMgrs.isAlphaWithSpace(city)) {
				fwMessageList.addMessageToList(addMessageCode("00018"));
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	/**
	 * @param cargo
	 * @param fwMessageList
	 * @param message
	 */
	private void validateZipCode(final APP_IN_HOU_BILLS_Cargo cargo, FwMessageList fwMessageList,
			final String[] message) {
		try {
		final String zipNumber = cargo.getProp_addr_zip();
		if (zipNumber != null && !EMPTY_STRING.equals(zipNumber) && !isValidName(PROP_ZIP_PATTERN, zipNumber)) {
			if (cargo.getProp_addr_zip().length() != 5) {
				fwMessageList.addMessageToList(addMessageCode(MESSAGECODE));
			}
			this.addMessageWithFieldValues(PROP_ZIP_MSG_CD, message);
		} else if (zipNumber != null && !EMPTY_STRING.equals(zipNumber)) {
			if (cargo.getProp_addr_zip().length() != 5) {
				fwMessageList.addMessageToList(addMessageCode(MESSAGECODE));
			}
			try {
				final long zipNum = Long.parseLong(zipNumber);
				if (zipNum == 0) {
					this.addMessageWithFieldValues(PROP_ZIP_MSG_1_CD, message);
				}
			} catch (final Exception e) {
				this.addMessageWithFieldValues(PROP_ZIP_MSG_CD, message);
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateAmount(final String amount, FwMessageList fwMessageList) {

		try {
		if (amount == null || EMPTY_STRING.equals(amount.trim())) {
			fwMessageList.addMessageToList(addMessageCode(AMOUNT_MSG_CD));
		} else if (!appMgrs.isValidAmountLimit(amount)) {
			fwMessageList.addMessageToList(addMessageCode("10034"));

		} else {
			try {
				Double.parseDouble(amount);
			} catch (final Exception e) {
				fwMessageList.addMessageToList(addMessageCode(AMOUNT_MSG_CD));
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private boolean isValidAddress(final String value) {
		return Pattern.compile(ADDRS_PATTERN).matcher(value).matches();
	}

	private boolean isValidName(final String pattern, final String value) {
		return Pattern.compile(pattern).matcher(value).matches();
	}

	public void storeBillResforCollection(final APP_IN_BILLS_RESP_FOR_Collection appInJntColl) {
		System.currentTimeMillis();
		try {
			if (appInJntColl != null && !appInJntColl.isEmpty()) {
				int size = appInJntColl.size();
				APP_IN_BILLS_RESP_FOR_Cargo appInJntOwnCargo = null;
				final APP_IN_BILLS_RESP_FOR_Collection deleteColl = new APP_IN_BILLS_RESP_FOR_Collection();
				for (int i = 0; i < size; i++) {
					appInJntOwnCargo = appInJntColl.getCargo(i);
					if (null!=appInJntOwnCargo.getRowAction() &&appInJntOwnCargo.getRowAction().equals(FwConstants.ROWACTION_DELETE)) {
						deleteColl.addCargo(appInJntOwnCargo);
						appInJntColl.remove(i);
						i--;
						size--;
					}
				}
				if (!deleteColl.isEmpty()) {
					appInBillsRespRepository.saveAll(deleteColl);
				}
				if (!appInJntColl.isEmpty()) {
					appInBillsRespRepository.saveAll(appInJntColl);

				}
			}
		} catch (final Exception e) {
			throw e;
		}
	}

	public APP_IN_HOU_BILLS_Collection splitHousingCollection(final APP_IN_HOU_BILLS_Collection otherIncColl,
			final String rmcNewRecordInd) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHousingBillsBO.splitHousingCollection- START");
		try {
			final APP_IN_HOU_BILLS_Collection updatedColl = new APP_IN_HOU_BILLS_Collection();
			if (otherIncColl != null && !otherIncColl.isEmpty()) {
				final int vehAstCollSize = otherIncColl.size();
				APP_IN_HOU_BILLS_Cargo vehAstCargo = null;
				for (int i = 0; i < vehAstCollSize; i++) {
					vehAstCargo = otherIncColl.getCargo(i);
					if (vehAstCargo.getSrc_app_ind().equals(rmcNewRecordInd)) {
						updatedColl.add(vehAstCargo);

					}
				}
				FwLogger.log(this.getClass(), Level.INFO,
						"ABHousingBillsBO.splitHousingCollection- START - END , Time Taken : "
								+ (System.currentTimeMillis() - startTime) + MILLI);
				return updatedColl;
			}
			return null;
		} catch (final Exception e) {
			throw e;
		}

	}

	public APP_IN_HOU_BILLS_Collection getNonCWCargoes(final APP_IN_HOU_BILLS_Collection allHouseBills) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHousingBillsBO.splitHousingCollection- START");
		try {
			final APP_IN_HOU_BILLS_Collection updatedColl = new APP_IN_HOU_BILLS_Collection();
			if (allHouseBills != null && !allHouseBills.isEmpty()) {
				final int vehAstCollSize = allHouseBills.size();
				APP_IN_HOU_BILLS_Cargo vehAstCargo = null;
				for (int i = 0; i < vehAstCollSize; i++) {
					vehAstCargo = allHouseBills.getCargo(i);
					if (!"CW".equals(vehAstCargo.getSrc_app_ind())) {
						updatedColl.add(vehAstCargo);

					}
				}
				FwLogger.log(this.getClass(), Level.INFO,
						"ABHousingBillsBO.getNonCWCargoes- START - END , Time Taken : "
								+ (System.currentTimeMillis() - startTime) + MILLI);
				return updatedColl;
			}
			return null;
		} catch (final Exception e) {
			throw e;
		}

	}

	public FwMessageList validateUtilityBillsContents(final CP_APP_IN_UTILC_Custom_Cargo cargo) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.validateUtilityBillsContents) - START");
		FwMessageList fwMessageList = new FwMessageList();

		try {

			fwMessageList.addMessageToList(validateUtilityDetailsField(cargo.getUtil_total_amt()));
			fwMessageList.addMessageToList(validateUtilityDetailsField(cargo.getMo_hsld_pay_amt()));

			if (!fwMessageList.hasMessages() && cargo.getMo_hsld_pay_amt() != null
					&& !"".equalsIgnoreCase(cargo.getMo_hsld_pay_amt())
					&& (cargo.getUtil_total_amt() == null || "".equalsIgnoreCase(cargo.getUtil_total_amt()))) {

				fwMessageList.addMessageToList(addMessageCode("99422"));
			}

			if (!fwMessageList.hasMessages() && cargo.getMo_hsld_pay_amt() != null
					&& !"".equalsIgnoreCase(cargo.getMo_hsld_pay_amt()) && cargo.getUtil_total_amt() != null
					&& !"".equalsIgnoreCase(cargo.getUtil_total_amt()) && Double.parseDouble(cargo.getMo_hsld_pay_amt()) > Double.parseDouble(cargo.getUtil_total_amt())) {

				fwMessageList.addMessageToList(addMessageCode("99422"));
			}

			validateUtilityDetailsField(cargo.getElectricityMonthlyAmount());
			validateUtilityDetailsField(cargo.getElectricityMonthlyAmount());
			validateUtilityDetailsField(cargo.getGasMonthlyAmount());
			validateUtilityDetailsField(cargo.getKerosineMonthlyAmount());
			validateUtilityDetailsField(cargo.getCoalMonthlyAmount());
			validateUtilityDetailsField(cargo.getDisasterMonthlyAmount());
			validateUtilityDetailsField(cargo.getOilMonthlyAmount());
			validateUtilityDetailsField(cargo.getWoodMonthlyAmount());
			validateUtilityDetailsField(cargo.getWaterMonthlyAmount());
			validateUtilityDetailsField(cargo.getGarbageMonthlyAmount());
			validateUtilityDetailsField(cargo.getInstallationMonthlyAmount());
			validateUtilityDetailsField(cargo.getTelephoneMonthlyAmount());
			validateUtilityDetailsField(cargo.getOtherMonthlyAmount());
			validateUtilityDetailsField(cargo.getOther2MonthlyAmount());
			validateUtilityDetailsField(cargo.getOther3MonthlyAmount());

		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.validateUtilityBillsContents - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLI);

		return fwMessageList;
	}

	private FwMessageList validateUtilityDetailsField(final String howMuch) {
		try {
		FwMessageList fwMessageList = new FwMessageList();

		System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.validateUtilityDetailsField) - START");

		boolean isNumber = false;
		if (!appMgrs.isFieldEmpty(howMuch)) {
			try {
				Double.parseDouble(howMuch);
				isNumber = true;
			} catch (final Exception e) {
				fwMessageList.addMessageToList(addMessageCode("98029"));
			}
		}

		if (!appMgrs.isFieldEmpty(howMuch) && isNumber && !appMgrs.isValidAmountLimit(howMuch)) {

			fwMessageList.addMessageToList(addMessageCode("98075"));
			
		}

		return fwMessageList;
		} catch (final Exception e) {
			throw e;
		}
	}

	public APP_IN_UTILC_Collection loadUtilityDetails(final String appNumber) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.loadUtilityDetails() - START");
		try {
			final APP_IN_UTILC_Collection appInUtilcColl = appInUtilcRepository.loadUtilityDetails(appNumber);

			FwLogger.log(this.getClass(), Level.INFO,
					"ABHouseHoldRelationshipBO.loadUtilityDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime) + MILLI);

			return appInUtilcColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	public APP_IN_HOU_BILLS_Collection loadIndividualShelterDetails(String appNum, Integer indivSeqNum, Integer seqNum, String type) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.loadIndividualShelterDetails) - START");

		try {
			final APP_IN_HOU_BILLS_Collection appInShltcColl = appInHouRepository.loadIndividualShelterDetails(Integer.parseInt(appNum), indivSeqNum, seqNum, type);
			FwLogger.log(this.getClass(), Level.INFO,
					"ABHouseHoldRelationshipBO.loadIndividualShelterDetails - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return appInShltcColl;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	
	public APP_IN_HOU_BILLS_Collection loadIndividualShelterDetails(String appNum, Integer indivSeqNum, Integer seqNum) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.loadIndividualShelterDetails) - START");

		try {
			final APP_IN_HOU_BILLS_Collection appInShltcColl = appInHouRepository.loadIndividualShelterDetails(Integer.parseInt(appNum), indivSeqNum, seqNum);
			FwLogger.log(this.getClass(), Level.INFO,
					"ABHouseHoldRelationshipBO.loadIndividualShelterDetails - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return appInShltcColl;
		}  catch (final Exception e) {
			throw e;
		}
	}
	public CP_APP_IN_UTILC_Custom_Collection loadIndividualUtilityDetails(
			final String appNumber, final Integer indvSeqNum) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.loadIndividualUtilityDetails() - START");
		try {

			// Create criteria and retrieve values from the database
			final APP_IN_UTILC_Collection appInUtilcColl = appInUtilcRepository.loadIndividualUtilityDetails(appNumber,indvSeqNum); 
			final CP_APP_IN_UTILC_Custom_Collection utilityCustomCollection = getUtilitiesCustomCollection(
					appNumber, indvSeqNum, appInUtilcColl);
			FwLogger.log(this.getClass(), Level.INFO,
					"ABHouseHoldRelationshipBO.loadIndividualUtilityDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			// return custom collection
			return utilityCustomCollection;
		} catch (final Exception e) {
			throw e;
		}

	}
	
	/*Added below code for recent housing bills screen changes*/
	public APP_IN_PRFL_Collection loadIndividualAPPInPrfl(String appNum, Integer indvSeqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.loadIndividualAPPInPrfl() - START");
		try {
			final APP_IN_PRFL_Collection appInPrflCollection = appInPrflRepository.getExistingRecord(appNum, indvSeqNum);
			FwLogger.log(this.getClass(), Level.INFO,
					"ABHouseHoldRelationshipBO.loadIndividualUtilityDetails() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ MILLI);
			return appInPrflCollection;
		}catch (final Exception e) {
			throw e;
		}
	}
	
	/*Added below code for recent housing bills screen changes*/
	public void saveIndividualAppInPrfl(APP_IN_PRFL_Cargo appInPrflCargo) {
		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.saveIndividualAppInPrfl() - START");
		try {
		appInPrflRepository.save(appInPrflCargo);
		}catch (final Exception e) {
			throw e;
		}
	}
	
	public void deleteHousingBillsCargo(APP_IN_HOU_BILLS_Cargo existingCargo) {
		
		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.deleteHousingBillsCargo) - START");

		try {
			
			appInHouRepository.delete(existingCargo);
		}
		catch (final Exception e) {
				FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
				throw e;
			}
		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.deleteHousingBillsCargo() - END");
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * Method to load housing bills expenses from DB
	 * 
	 * 
	 ********************************************************************************************************************
	 */
	public APP_IN_HOU_BILLS_Collection loadHousingExpenses(String appNum, String billType, List<Integer> indvIds) {
		FwLogger.log(this.getClass(), Level.INFO,
				"ABHouseHoldRelationshipBO.loadHousingExpenses) - START");
		APP_IN_HOU_BILLS_Collection appInHousBillsColl = new APP_IN_HOU_BILLS_Collection();
		try {
			
			appInHousBillsColl = appInHouRepository.getHousingExpenseSummaryDetails(Integer.parseInt(appNum), billType, indvIds);
		}
		 catch (final Exception e) {
				FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
				throw e;
			}
		FwLogger.log(this.getClass(), Level.INFO, "ABHouseHoldRelationshipBO.loadHousingExpenses() - END");
		return appInHousBillsColl;
	}
	
	/******************************************************************************************************************
	 * 
	 * 
	 * Method to delete Utilities Info from DB
	 * 
	 * 
	 ********************************************************************************************************************
	 */
	
    public void deleteUtilityInformation(String appNum, Integer indvSeqNumber, List<String> immedAry ) {
        try {
            appInHouRepository.deleteUtilityInformation(Integer.parseInt(appNum), indvSeqNumber,immedAry);
        } catch (final Exception exception) {
            throw exception;
        }
    }
}
