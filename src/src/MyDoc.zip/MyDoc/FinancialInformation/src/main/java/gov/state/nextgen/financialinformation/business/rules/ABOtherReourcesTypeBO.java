package gov.state.nextgen.financialinformation.business.rules;

import org.springframework.stereotype.Service;

@Service("ABOtherReourcesTypeBO")
public class ABOtherReourcesTypeBO {

}
