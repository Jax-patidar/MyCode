/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.util.Date;

import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;


public class APP_IN_UTILC_Cargo extends AbstractCargo implements java.io.Serializable {

	private static final long serialVersionUID = -2681181401839423849L;
	@Id
	private String app_num;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	@Id
	private String src_app_ind;
	private String bill_exp_resp;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_eff_dt;
	private String heat_sw;
	private Double mo_oblg_amt;
	private Integer mo_oblg_ind;
	private Integer rec_cplt_ind;
	private String util_typ;
	private String pay_freq;
	private String util_electric_resp;
	private String util_sewage_resp;
	private String util_garbage_resp;
	private String util_phone_resp;
	private String util_gas_resp;
	private String util_water_resp;
	private String util_fuel_resp;
	private Double mo_hsld_pay_amt;
	private Double util_total_amt;
	private Integer ecp_id;
	private String heat_cool_src;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_dt;

	/**
	 * @return the chg_dt
	 */
	public Date getChg_dt() {
        return this.chg_dt!= null ? new Date(chg_dt.getTime()) : null;

	}

	/**
	 * @param chg_dt the chg_dt to set
	 */
	public void setChg_dt(Date chg_dt) {
		this.chg_dt = (chg_dt == null) ? null : new Date(chg_dt.getTime());
	}

	/**
	 * @return the ecp_id
	 */
	public Integer getEcp_id() {
		return ecp_id;
	}

	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(final Integer ecp_id) {
		this.ecp_id = ecp_id;
	}

	/**
	 * @return the util_total_amt
	 */
	public Double getUtil_total_amt() {
		return util_total_amt;
	}

	/**
	 * @param util_total_amt the util_total_amt to set
	 */
	public void setUtil_total_amt(final Double util_total_amt) {
		this.util_total_amt = util_total_amt;
	}

	/**
	 * @return the util_electric_resp
	 */
	public String getUtil_electric_resp() {
		return util_electric_resp;
	}

	/**
	 * @param util_electric_resp the util_electric_resp to set
	 */
	public void setUtil_electric_resp(final String util_electric_resp) {
		this.util_electric_resp = util_electric_resp;
	}

	/**
	 * @return the util_sewage_resp
	 */
	public String getUtil_sewage_resp() {
		return util_sewage_resp;
	}

	/**
	 * @param util_sewage_resp the util_sewage_resp to set
	 */
	public void setUtil_sewage_resp(final String util_sewage_resp) {
		this.util_sewage_resp = util_sewage_resp;
	}

	/**
	 * @return the util_garbage_resp
	 */
	public String getUtil_garbage_resp() {
		return util_garbage_resp;
	}

	/**
	 * @param util_garbage_resp the util_garbage_resp to set
	 */
	public void setUtil_garbage_resp(final String util_garbage_resp) {
		this.util_garbage_resp = util_garbage_resp;
	}

	/**
	 * @return the util_phone_resp
	 */
	public String getUtil_phone_resp() {
		return util_phone_resp;
	}

	/**
	 * @param util_phone_resp the util_phone_resp to set
	 */
	public void setUtil_phone_resp(final String util_phone_resp) {
		this.util_phone_resp = util_phone_resp;
	}

	/**
	 * @return the util_gas_resp
	 */
	public String getUtil_gas_resp() {
		return util_gas_resp;
	}

	/**
	 * @param util_gas_resp the util_gas_resp to set
	 */
	public void setUtil_gas_resp(final String util_gas_resp) {
		this.util_gas_resp = util_gas_resp;
	}

	/**
	 * @return the util_water_resp
	 */
	public String getUtil_water_resp() {
		return util_water_resp;
	}

	/**
	 * @param util_water_resp the util_water_resp to set
	 */
	public void setUtil_water_resp(final String util_water_resp) {
		this.util_water_resp = util_water_resp;
	}

	/**
	 * @return the util_fuel_resp
	 */
	public String getUtil_fuel_resp() {
		return util_fuel_resp;
	}

	/**
	 * @param util_fuel_resp the util_fuel_resp to set
	 */
	public void setUtil_fuel_resp(final String util_fuel_resp) {
		this.util_fuel_resp = util_fuel_resp;
	}

	/**
	 * @return the mo_hsld_pay_amt
	 */
	public Double getMo_hsld_pay_amt() {
		return mo_hsld_pay_amt;
	}

	/**
	 * @param mo_hsld_pay_amt the mo_hsld_pay_amt to set
	 */
	public void setMo_hsld_pay_amt(final Double mo_hsld_pay_amt) {
		this.mo_hsld_pay_amt = mo_hsld_pay_amt;
	}

	// VA EDSP CP additions
	private String someone_else_pay_ind;

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return app_num;
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * returns the bill_exp_resp value.
	 */
	public String getBill_exp_resp() {
		return bill_exp_resp;
	}

	/**
	 * returns the chg_eff_dt value.
	 */
	public Date getChg_eff_dt() {
        return this.chg_eff_dt!= null ? new Date(chg_eff_dt.getTime()) : null;
	}

	/**
	 * returns the heat_sw value.
	 */
	public String getHeat_sw() {
		return heat_sw;
	}

	/**
	 * returns the mo_oblg_amt value.
	 */
	public Double getMo_oblg_amt() {
		return mo_oblg_amt;
	}

	/**
	 * returns the mo_oblg_ind value.
	 */
	public Integer getMo_oblg_ind() {
		return mo_oblg_ind;
	}

	/**
	 * returns the rec_cplt_ind value.
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * returns the util_typ value.
	 */
	public String getUtil_typ() {
		return util_typ;
	}

	/**
	 * returns the pay_freq value.
	 */
	public String getPay_freq() {
		return pay_freq;
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_num = app_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * sets the bill_exp_resp value.
	 */
	public void setBill_exp_resp(final String bill_exp_resp) {
		this.bill_exp_resp = bill_exp_resp;
	}

	/**
	 * sets the chg_eff_dt value.
	 */
	public void setChg_eff_dt(final Date chg_eff_dt) {
		this.chg_eff_dt = (chg_eff_dt == null) ? null : new Date(chg_eff_dt.getTime());
	}

	/**
	 * sets the heat_sw value.
	 */
	public void setHeat_sw(final String heat_sw) {
		this.heat_sw = heat_sw;
	}

	/**
	 * sets the mo_oblg_amt value.
	 */
	public void setMo_oblg_amt(final Double mo_oblg_amt) {
		this.mo_oblg_amt = mo_oblg_amt;
	}

	/**
	 * sets the mo_oblg_ind value.
	 */
	public void setMo_oblg_ind(final Integer mo_oblg_ind) {
		this.mo_oblg_ind = mo_oblg_ind;
	}

	/**
	 * sets the rec_cplt_ind value.
	 */
	public void setRec_cplt_ind(final Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * sets the util_typ value.
	 */
	public void setUtil_typ(final String util_typ) {
		this.util_typ = util_typ;
	}

	/**
	 * sets the pay_freq value.
	 */
	public void setPay_freq(final String pay_freq) {
		this.pay_freq = pay_freq;
	}

	/**
	 * @return the someone_else_pay_ind
	 */
	public String getSomeone_else_pay_ind() {
		return someone_else_pay_ind;
	}

	/**
	 * @param someone_else_pay_ind the someone_else_pay_ind to set
	 */
	public void setSomeone_else_pay_ind(final String someone_else_pay_ind) {
		this.someone_else_pay_ind = someone_else_pay_ind;
	}

	/**
	 * @return the heat_cool_src
	 */
	public String getHeat_cool_src() {
		return heat_cool_src;
	}

	/**
	 * @param heat_cool_src the heat_cool_src to set
	 */
	public void setHeat_cool_src(String heat_cool_src) {
		this.heat_cool_src = heat_cool_src;
	}


	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((app_num == null) ? 0 : app_num.trim().hashCode());
		result = (prime * result) + ((bill_exp_resp == null) ? 0 : bill_exp_resp.trim().hashCode());
		result = (prime * result) + ((chg_eff_dt == null) ? 0 : chg_eff_dt.hashCode());
		result = (prime * result) + ((heat_sw == null) ? 0 : heat_sw.trim().hashCode());
		result = (prime * result) + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = (prime * result) + ((mo_oblg_amt == null) ? 0 : mo_oblg_amt.hashCode());
		result = (prime * result) + ((mo_oblg_ind == null) ? 0 : mo_oblg_ind.hashCode());
		result = (prime * result) + ((pay_freq == null) ? 0 : pay_freq.trim().hashCode());
		result = (prime * result) + ((rec_cplt_ind == null) ? 0 : rec_cplt_ind.hashCode());
		result = (prime * result) + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = (prime * result) + ((src_app_ind == null) ? 0 : src_app_ind.trim().hashCode());
		result = (prime * result) + ((util_typ == null) ? 0 : util_typ.trim().hashCode());
		result = (prime * result) + ((ecp_id == null) ? 0 : ecp_id.hashCode());
		result = (prime * result) + ((heat_cool_src == null) ? 0 : heat_cool_src.trim().hashCode());
		result = (prime * result) + ((chg_dt == null) ? 0 : chg_dt.hashCode());
		return result;
	}

	

}
