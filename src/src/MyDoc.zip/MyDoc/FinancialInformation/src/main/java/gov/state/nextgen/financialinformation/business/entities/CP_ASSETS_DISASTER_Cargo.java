package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name= "CP_ASSETS_DISASTER")
@IdClass(CP_ASSETS_DISASTER_Key.class)
public class CP_ASSETS_DISASTER_Cargo extends AbstractCargo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	private String src_app_ind;
	
	private double cash_in_hand_amt;
	
	private double saving_account_amt;
	
	private double checking_account_amt;
	
	private double other_amt;

	public String getApp_num() {
		return String.valueOf(app_number);
	}

	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public double getCash_in_hand_amt() {
		return cash_in_hand_amt;
	}

	public void setCash_in_hand_amt(double cash_in_hand_amt) {
		this.cash_in_hand_amt = cash_in_hand_amt;
	}

	public double getSaving_account_amt() {
		return saving_account_amt;
	}

	public void setSaving_account_amt(double saving_account_amt) {
		this.saving_account_amt = saving_account_amt;
	}

	public double getChecking_account_amt() {
		return checking_account_amt;
	}

	public void setChecking_account_amt(double checking_account_amt) {
		this.checking_account_amt = checking_account_amt;
	}

	public double getOther_amt() {
		return other_amt;
	}

	public void setOther_amt(double other_amt) {
		this.other_amt = other_amt;
	}
}
