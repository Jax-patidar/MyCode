/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(APP_IN_SELFE_Id.class)
@Table(name = "CP_APP_IN_SELFEMP")
public class APP_IN_SELFE_Cargo extends AbstractCargo implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	
	private String src_app_ind;
	@Column(name="avg_income_amt")
	private Double avg_incm_amt;
	@Column(name="avg_income_ind")
	private Integer avg_incm_ind;
	@Column(name="change_eff_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_eff_dt;
	@Transient
	private Double dprc_amt;
	@Transient
	private Integer dprc_ind;
	private Double exp_amt;
	private Integer exp_ind;
	@Transient
	private Integer hr_work_mo_ind;
	@Transient
	private Integer hr_work_mo_qty;
	private Integer rec_cplt_ind;
	@Column(name="self_empl_type")
	private String self_empl_typ;
	@Transient
	private String self_mng_sw;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date eff_begin_dt;
	private String expected_to_cont_resp;
	@Transient
	private String bus_nam;
	@Transient
	private String self_empl_beg_mo;
	@Transient
	private String bus_tax_id_num;
	@Transient
	private String bus_tax_file_yr;
	@Transient
	private String bus_sgnf_chg_ind;
	@Transient
	private String bus_sgnf_chg_mo;
	@Transient
	private String bus_owsp_typ;
	@Transient
	private String fst_name;
	@Column(name="self_empl_bus_name")
	private String self_empl_bus_nam;
	@Transient
	private Double ecp_id;
	@Column(name="change_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_dt;
	@Column(name="amt")
	private Double amount;
	private String pay_freq;
	private Integer gross_mthly_income_amt;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date end_dt;
	
	public Date getEnd_dt() {
		return end_dt;
	}

	public void setEnd_dt(Date end_dt) {
		this.end_dt = end_dt;
	}

	@Column(name="income_source")
	private String incomeSource;
	
	@Column(name="addtl_info")
	private String addtl_info;
	
	@Column(name="num_of_hours")
	private Double numOfHours;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date self_emp_end_dt;
	
	@Column(name = "self_e_calsaws_object")
	private String selfECalsawsObject;

	public Date getSelf_emp_end_dt() {
		return self_emp_end_dt;
	}

	public void setSelf_emp_end_dt(Date self_emp_end_dt) {
		this.self_emp_end_dt = self_emp_end_dt;
	}

	public String getFst_name() {
		return fst_name;
	}

	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}

	public String getApp_num() {
		return String.valueOf(app_number);
	}

	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public Integer getSeq_num() {
		return seq_num;
	}

	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public Double getAvg_incm_amt() {
		return avg_incm_amt;
	}

	public void setAvg_incm_amt(Double avg_incm_amt) {
		this.avg_incm_amt = avg_incm_amt;
	}

	public Integer getAvg_incm_ind() {
		return avg_incm_ind;
	}

	public void setAvg_incm_ind(Integer avg_incm_ind) {
		this.avg_incm_ind = avg_incm_ind;
	}

	public Date getChg_eff_dt() {
        return this.chg_eff_dt!= null ? new Date(chg_eff_dt.getTime()) : null;
	}

	public void setChg_eff_dt(Date chg_eff_dt) {
		this.chg_eff_dt = (chg_eff_dt == null) ? null : new Date(chg_eff_dt.getTime());
	}

	public Double getDprc_amt() {
		return dprc_amt;
	}

	public void setDprc_amt(Double dprc_amt) {
		this.dprc_amt = dprc_amt;
	}

	public Integer getDprc_ind() {
		return dprc_ind;
	}

	public void setDprc_ind(Integer dprc_ind) {
		this.dprc_ind = dprc_ind;
	}

	public Double getExp_amt() {
		return exp_amt;
	}

	public void setExp_amt(Double exp_amt) {
		this.exp_amt = exp_amt;
	}

	public Integer getExp_ind() {
		return exp_ind;
	}

	public void setExp_ind(Integer exp_ind) {
		this.exp_ind = exp_ind;
	}

	public Integer getHr_work_mo_ind() {
		return hr_work_mo_ind;
	}

	public void setHr_work_mo_ind(Integer hr_work_mo_ind) {
		this.hr_work_mo_ind = hr_work_mo_ind;
	}

	public Integer getHr_work_mo_qty() {
		return hr_work_mo_qty;
	}

	public void setHr_work_mo_qty(Integer hr_work_mo_qty) {
		this.hr_work_mo_qty = hr_work_mo_qty;
	}

	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	public String getSelf_empl_typ() {
		return self_empl_typ;
	}

	public void setSelf_empl_typ(String self_empl_typ) {
		this.self_empl_typ = self_empl_typ;
	}

	public String getSelf_mng_sw() {
		return self_mng_sw;
	}

	public void setSelf_mng_sw(String self_mng_sw) {
		this.self_mng_sw = self_mng_sw;
	}

	public Date getEff_begin_dt() {       
		return this.eff_begin_dt!= null ? new Date(eff_begin_dt.getTime()) : null;

	}

	public void setEff_begin_dt(Date eff_begin_dt) {
		this.eff_begin_dt = (eff_begin_dt == null) ? null : new Date(eff_begin_dt.getTime());
	}


	public String getExpected_to_cont_resp() {
		return expected_to_cont_resp;
	}

	public void setExpected_to_cont_resp(String expected_to_cont_resp) {
		this.expected_to_cont_resp = expected_to_cont_resp;
	}

	public String getBus_nam() {
		return bus_nam;
	}

	public void setBus_nam(String bus_nam) {
		this.bus_nam = bus_nam;
	}

	public String getSelf_empl_beg_mo() {
		return self_empl_beg_mo;
	}

	public void setSelf_empl_beg_mo(String self_empl_beg_mo) {
		this.self_empl_beg_mo = self_empl_beg_mo;
	}

	public String getBus_tax_id_num() {
		return bus_tax_id_num;
	}

	public void setBus_tax_id_num(String bus_tax_id_num) {
		this.bus_tax_id_num = bus_tax_id_num;
	}

	public String getBus_tax_file_yr() {
		return bus_tax_file_yr;
	}

	public void setBus_tax_file_yr(String bus_tax_file_yr) {
		this.bus_tax_file_yr = bus_tax_file_yr;
	}

	public String getBus_sgnf_chg_ind() {
		return bus_sgnf_chg_ind;
	}

	public void setBus_sgnf_chg_ind(String bus_sgnf_chg_ind) {
		this.bus_sgnf_chg_ind = bus_sgnf_chg_ind;
	}

	public String getBus_sgnf_chg_mo() {
		return bus_sgnf_chg_mo;
	}

	public void setBus_sgnf_chg_mo(String bus_sgnf_chg_mo) {
		this.bus_sgnf_chg_mo = bus_sgnf_chg_mo;
	}

	public String getBus_owsp_typ() {
		return bus_owsp_typ;
	}

	public void setBus_owsp_typ(String bus_owsp_typ) {
		this.bus_owsp_typ = bus_owsp_typ;
	}

	public String getSelf_empl_bus_nam() {
		return self_empl_bus_nam;
	}

	public void setSelf_empl_bus_nam(String self_empl_bus_nam) {
		this.self_empl_bus_nam = self_empl_bus_nam;
	}

	public Double getEcp_id() {
		return ecp_id;
	}

	public void setEcp_id(Double ecp_id) {
		this.ecp_id = ecp_id;
	}

	public Date getChg_dt() {
        return this.chg_dt!= null ? new Date(chg_dt.getTime()) : null;
	}

	public void setChg_dt(Date chg_dt) {
		this.chg_dt = (chg_dt == null) ? null : new Date(chg_dt.getTime());
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	public Integer getGross_mthly_income_amt() {
		return gross_mthly_income_amt;
	}

	public void setGross_mthly_income_amt(Integer gross_mthly_income_amt) {
		this.gross_mthly_income_amt = gross_mthly_income_amt;
	}
	

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getPay_freq() {
		return pay_freq;
	}

	public void setPay_freq(String pay_freq) {
		this.pay_freq = pay_freq;
	}

	public String getAddtl_info() {
		return addtl_info;
	}

	public void setAddtl_info(String addtl_info) {
		this.addtl_info = addtl_info;
	}

	public Double getNumOfHours() {
		return numOfHours;
	}

	public void setNumOfHours(Double numOfHours) {
		this.numOfHours = numOfHours;
	}

	public String getIncomeSource() {
		return incomeSource;
	}

	public void setIncomeSource(String incomeSource) {
		this.incomeSource = incomeSource;
	}

	public String getSelfECalsawsObject() {
		return selfECalsawsObject;
	}

	public void setSelfECalsawsObject(String selfECalsawsObject) {
		this.selfECalsawsObject = selfECalsawsObject;
	}
	
}