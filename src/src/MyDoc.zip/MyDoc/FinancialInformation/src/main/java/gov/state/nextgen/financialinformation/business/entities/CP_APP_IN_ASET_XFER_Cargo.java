package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "cp_app_in_asset_xfer")
@IdClass(CpAppInAsetXferRepositoryId.class)
public class CP_APP_IN_ASET_XFER_Cargo extends AbstractCargo implements Serializable {

	/**
	*
	*/
	private static final long serialVersionUID = 1L;
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private Integer asset_seq_num;
	@Id
	private Integer indv_seq_num;
	
	private String src_app_ind;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date asset_acq_dt;
	private String asset_type;
	private Double asset_val_amt;
	private Double asset_xfer_amt;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date asset_xfer_dt;
	@Transient
	private String asset_xfer_rsn_cd;
	@Transient
	private String first_name;
	@Transient
	private String last_name;
	@Transient
	private String asset_st_ind;
	private Integer rec_cplt_ind;

	@Transient
	private String loopingInd;
	@Transient
	private Integer ecp_id;
	@Column(name = "change_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_dt;

	private String comments;

	private String asset_trans_type;

	private String asset_name;

	public String getAsset_trans_type() {
		return asset_trans_type;
	}

	public void setAsset_trans_type(String asset_trans_type) {
		this.asset_trans_type = asset_trans_type;
	}

	public String getAsset_name() {
		return asset_name;
	}

	public void setAsset_name(String asset_name) {
		this.asset_name = asset_name;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	/**
	 * returns the chg_dt value.
	 */
	public Date getChg_dt() {
		return chg_dt;
	}

	/**
	 * sets the chg_dt value.
	 */
	public void setChg_dt(Date chg_dt) {
		this.chg_dt = chg_dt;
	}

	/**
	 * returns the src_app_ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * sets the src_app_ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * returns the Seq_num value.
	 */

	public Integer getSeq_num() {
		return asset_seq_num;
	}

	/**
	 * sets the Seq_num value.
	 */


	public void setSeq_num(final Integer asset_seq_num) {
		this.asset_seq_num = asset_seq_num;
	}

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	/**
	 * returns the asset_seq_num value.
	 */
	public Integer getAsset_seq_num() {
		return asset_seq_num;
	}

	/**
	 * sets the asset_seq_num value.
	 */
	public void setAsset_seq_num(final Integer asset_seq_num) {
		this.asset_seq_num = asset_seq_num;
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the asset_acq_dt value.
	 */
	public Date getAsset_acq_dt() {
		return asset_acq_dt;
	}

	/**
	 * sets the asset_acq_dt value.
	 */
	public void setAsset_acq_dt(final Date asset_acq_dt) {
		this.asset_acq_dt = asset_acq_dt;
	}

	/**
	 * returns the asset_type value.
	 */
	public String getAsset_type() {
		return asset_type;
	}

	/**
	 * sets the asset_type value.
	 */
	public void setAsset_type(final String asset_type) {
		this.asset_type = asset_type;
	}

	/**
	 * returns the asset_val_amt value.
	 */
	public Double getAsset_val_amt() {
		return asset_val_amt;
	}

	/**
	 * sets the asset_val_amt value.
	 */
	public void setAsset_val_amt(final Double asset_val_amt) {
		this.asset_val_amt = asset_val_amt;
	}

	/**
	 * returns the asset_xfer_amt value.
	 */
	public Double getAsset_xfer_amt() {
		return asset_xfer_amt;
	}

	/**
	 * sets the asset_xfer_amt value.
	 */
	public void setAsset_xfer_amt(final Double asset_xfer_amt) {
		this.asset_xfer_amt = asset_xfer_amt;
	}

	/**
	 * returns the asset_xfer_dt value.
	 */
	public Date getAsset_xfer_dt() {
		return asset_xfer_dt;
	}

	/**
	 * sets the asset_xfer_dt value.
	 */
	public void setAsset_xfer_dt(final Date asset_xfer_dt) {
		this.asset_xfer_dt = asset_xfer_dt;
	}

	/**
	 * returns the asset_xfer_rsn_cd value.
	 */
	public String getAsset_xfer_rsn_cd() {
		return asset_xfer_rsn_cd;
	}

	/**
	 * sets the asset_xfer_rsn_cd value.
	 */
	public void setAsset_xfer_rsn_cd(final String asset_xfer_rsn_cd) {
		this.asset_xfer_rsn_cd = asset_xfer_rsn_cd;
	}

	/**
	 * returns the first_name value.
	 */
	public String getFirst_name() {
		return first_name;
	}

	/**
	 * sets the first_name value.
	 */
	public void setFirst_name(final String first_name) {
		this.first_name = first_name;
	}

	/**
	 * returns the last_name value.
	 */
	public String getLast_name() {
		return last_name;
	}

	/**
	 * sets the last_name value.
	 */
	public void setLast_name(final String last_name) {
		this.last_name = last_name;
	}

	/**
	 * returns the asset_st_ind value.
	 */
	public String getAsset_st_ind() {
		return asset_st_ind;
	}

	/**
	 * sets the asset_st_ind value.
	 */
	public void setAsset_st_ind(final String asset_st_ind) {
		this.asset_st_ind = asset_st_ind;
	}

	/**
	 * returns the asset_st_ind value.
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * sets the asset_st_ind value.
	 */
	public void setRec_cplt_ind(final Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * @return the loopingInd
	 */
	public String getLoopingInd() {
		return loopingInd;
	}

	/**
	 * @param loopingInd the loopingInd to set
	 */
	public void setLoopingInd(final String loopingInd) {
		this.loopingInd = loopingInd;
	}

	/**
	 * @return the ecp_id
	 */
	public Integer getEcp_id() {
		return ecp_id;
	}

	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(final Integer ecp_id) {
		this.ecp_id = ecp_id;
	}

	
	
	
}
