package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name = "CP_INCOME_DISASTER")
@IdClass(CP_INCOME_DISASTER_Key.class)
public class CP_INCOME_DISASTER_Cargo extends AbstractCargo implements Serializable{

	private static final long serialVersionUID = 8071277675924840859L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	private String src_app_ind;
	
	private String additional_info;
	
	private Double income_amt;

	public String getApp_num() {
		return String.valueOf(app_number);
	}

	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public String getAdditional_info() {
		return additional_info;
	}

	public void setAdditional_info(String additional_info) {
		this.additional_info = additional_info;
	}

	public Double getIncome_amt() {
		return income_amt;
	}

	public void setIncome_amt(Double income_amt) {
		this.income_amt = income_amt;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	

	

}
