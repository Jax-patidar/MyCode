package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;


@Embeddable
public class APP_IN_BILLS_RESP_FOR_Id implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	private String app_num;
	private int seq_num; 
	private int indv_seq_num;
	private String src_app_ind;
	private String bill_type;
	
	public APP_IN_BILLS_RESP_FOR_Id() {
	}

	
	public APP_IN_BILLS_RESP_FOR_Id(String app_num, int seq_num, int indv_seq_num, String src_app_ind, String bill_type) {
		super();
		this.bill_type=bill_type;
		this.app_num = app_num;
		this.seq_num = seq_num;
		this.indv_seq_num = indv_seq_num;
		this.src_app_ind = src_app_ind;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((bill_type == null) ? 0 : bill_type.hashCode());
		result = prime * result + indv_seq_num;
		result = prime * result + (int) (seq_num ^ (seq_num >>> 32));
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}


	
	

}
