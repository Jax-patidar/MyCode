package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class Questionnarie_jobIncomeCollection extends AbstractCollection{
	
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.Questionnarie_jobIncome";

	
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final Questionnarie_jobIncomeCargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final Questionnarie_jobIncomeCargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final Questionnarie_jobIncomeCargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public Questionnarie_jobIncomeCargo[] getResults() {
		final Questionnarie_jobIncomeCargo[] cbArray = new Questionnarie_jobIncomeCargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public Questionnarie_jobIncomeCargo getCargo(final int idx) {
		return (Questionnarie_jobIncomeCargo) get(idx);
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof Questionnarie_jobIncomeCargo[]) {
			final Questionnarie_jobIncomeCargo[] cbArray = (Questionnarie_jobIncomeCargo[]) obj;
			setResults(cbArray);
		}
	}

	public Questionnarie_jobIncomeCargo getResult(final int idx) {
		return (Questionnarie_jobIncomeCargo) get(idx);
	}

}
