package gov.state.nextgen.financialinformation.business.entities;

import java.util.Date;

import javax.persistence.*;


import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@Table(name="cp_app_in_med_bills")
@IdClass(CP_APP_IN_MED_BILLS_Key.class)

public class CP_APP_IN_MED_BILLS_Cargo extends AbstractCargo implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private Integer indv_seq_num;
	
	@Id
	private Integer medical_seq_num;
	
	@Id
	private String med_bill_type;
	
	
	private String src_app_ind;
	
	private Double payment_amt;
	private String pay_freq;
	private Integer rec_cplt_ind;
	@JsonFormat(pattern = "yyyy-mm-dd")
	private Date medical_bill_end_dt;
	private String adapt_record_id;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date change_dt;
	
   	private String special_needs_desc;
	private String reimburse_name;
	private String reimburse_ind ;
	private String  reimburse_amt;
	@Transient
	private Integer pymnt_amnt;
	@Transient
	private String firstName;
	@Transient
	private String lastName;
	@Transient
	private Integer age;
	
	@Transient
	private String[] medBillTypes;
	
	@Column(name = "med_bills_calsaws_object")
	private String medBillsCalsawsObject;
	
	@Column(name = "med_bill_type_desc")
	private String medBillTypeDesc;
	
	public String[] getMedBillTypes() {
		return medBillTypes;
	}
	public void setMedBillTypes(String[] medBillTypes) {
		this.medBillTypes = medBillTypes;
	}
	
	//added as part of CSPM-3129
	private Integer ma_backdt_mo_1_ind;
	private Integer ma_backdt_mo_2_ind;
	private Integer ma_backdt_mo_3_ind;
	public String getApp_num() {
		return String.valueOf(app_number);
	}
	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	public Integer getMedical_seq_num() {
		return medical_seq_num;
	}
	public void setMedical_seq_num(Integer medical_seq_num) {
		this.medical_seq_num = medical_seq_num;
	}
	public String getMed_bill_type() {
		return med_bill_type;
	}
	public void setMed_bill_type(String med_bill_type) {
		this.med_bill_type = med_bill_type;
	}
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	public Double getPayment_amt() {
		return payment_amt;
	}
	public void setPayment_amt(Double payment_amt) {
		this.payment_amt = payment_amt;
	}
	public String getPay_freq() {
		return pay_freq;
	}
	public void setPay_freq(String pay_freq) {
		this.pay_freq = pay_freq;
	}
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}
	public void setRec_cplt_ind(Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}
	public Date getMedical_bill_end_dt() {
		return medical_bill_end_dt;
	}
	public void setMedical_bill_end_dt(Date medical_bill_end_dt) {
		this.medical_bill_end_dt = medical_bill_end_dt;
	}
	public String getAdapt_record_id() {
		return adapt_record_id;
	}
	public void setAdapt_record_id(String adapt_record_id) {
		this.adapt_record_id = adapt_record_id;
	}
	public Date getChange_dt() {
		return change_dt;
	}
	public void setChange_dt(Date change_dt) {
		this.change_dt = change_dt;
	}
	public String getSpecial_needs_desc() {
		return special_needs_desc;
	}
	public void setSpecial_needs_desc(String special_needs_desc) {
		this.special_needs_desc = special_needs_desc;
	}
	public String getReimburse_name() {
		return reimburse_name;
	}
	public void setReimburse_name(String reimburse_name) {
		this.reimburse_name = reimburse_name;
	}
	public String getReimburse_ind() {
		return reimburse_ind;
	}
	public void setReimburse_ind(String reimburse_ind) {
		this.reimburse_ind = reimburse_ind;
	}
	public String getReimburse_amt() {
		return reimburse_amt;
	}
	public void setReimburse_amt(String reimburse_amt) {
		this.reimburse_amt = reimburse_amt;
	}
	public Integer getPymnt_amnt() {
		return pymnt_amnt;
	}
	public void setPymnt_amnt(Integer pymnt_amnt) {
		this.pymnt_amnt = pymnt_amnt;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Integer getMa_backdt_mo_1_ind() {
		return ma_backdt_mo_1_ind;
	}
	public void setMa_backdt_mo_1_ind(Integer ma_backdt_mo_1_ind) {
		this.ma_backdt_mo_1_ind = ma_backdt_mo_1_ind;
	}
	public Integer getMa_backdt_mo_2_ind() {
		return ma_backdt_mo_2_ind;
	}
	public void setMa_backdt_mo_2_ind(Integer ma_backdt_mo_2_ind) {
		this.ma_backdt_mo_2_ind = ma_backdt_mo_2_ind;
	}
	public Integer getMa_backdt_mo_3_ind() {
		return ma_backdt_mo_3_ind;
	}
	public void setMa_backdt_mo_3_ind(Integer ma_backdt_mo_3_ind) {
		this.ma_backdt_mo_3_ind = ma_backdt_mo_3_ind;
	}
	public String getMedBillsCalsawsObject() {
		return medBillsCalsawsObject;
	}
	public void setMedBillsCalsawsObject(String medBillsCalsawsObject) {
		this.medBillsCalsawsObject = medBillsCalsawsObject;
	}
	public String getMedBillTypeDesc() {
		return medBillTypeDesc;
	}
	public void setMedBillTypeDesc(String medBillTypeDesc) {
		this.medBillTypeDesc = medBillTypeDesc;
	}
}