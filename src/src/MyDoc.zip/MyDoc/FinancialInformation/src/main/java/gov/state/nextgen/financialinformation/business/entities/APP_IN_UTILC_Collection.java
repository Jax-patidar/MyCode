/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class APP_IN_UTILC_Collection extends AbstractCollection {

	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_IN_UTILC";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_UTILC_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_UTILC_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_UTILC_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_UTILC_Cargo[] getResults() {
		final APP_IN_UTILC_Cargo[] cbArray = new APP_IN_UTILC_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_UTILC_Cargo getCargo(final int idx) {
		return (APP_IN_UTILC_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_UTILC_Cargo[] cloneResults() {
		final APP_IN_UTILC_Cargo[] rescargo = new APP_IN_UTILC_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_UTILC_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_UTILC_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setSeq_num(cargo.getSeq_num());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setBill_exp_resp(cargo.getBill_exp_resp());
			rescargo[i].setChg_eff_dt(cargo.getChg_eff_dt());
			rescargo[i].setHeat_sw(cargo.getHeat_sw());
			rescargo[i].setMo_oblg_amt(cargo.getMo_oblg_amt());
			rescargo[i].setMo_oblg_ind(cargo.getMo_oblg_ind());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setUtil_typ(cargo.getUtil_typ());
			rescargo[i].setPay_freq(cargo.getPay_freq());
			// SY ADDED
			rescargo[i].setUtil_electric_resp(cargo.getUtil_electric_resp());
			rescargo[i].setUtil_sewage_resp(cargo.getUtil_sewage_resp());
			rescargo[i].setUtil_garbage_resp(cargo.getUtil_garbage_resp());
			rescargo[i].setUtil_phone_resp(cargo.getUtil_phone_resp());
			rescargo[i].setUtil_gas_resp(cargo.getUtil_gas_resp());
			rescargo[i].setUtil_water_resp(cargo.getUtil_water_resp());
			rescargo[i].setUtil_fuel_resp(cargo.getUtil_fuel_resp());
			rescargo[i].setMo_hsld_pay_amt(cargo.getMo_hsld_pay_amt());
			rescargo[i].setUtil_total_amt(cargo.getUtil_total_amt());
			rescargo[i].setEcp_id(cargo.getEcp_id());
			rescargo[i].setHeat_cool_src(cargo.getHeat_cool_src());

			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setChg_dt(cargo.getChg_dt());
			rescargo[i].setDirty(cargo.isDirty());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_UTILC_Cargo[]) {
			final APP_IN_UTILC_Cargo[] cbArray = (APP_IN_UTILC_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}