/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@IdClass(APP_IN_JNT_OWN_Id.class)
@Table(name="CP_APP_IN_JNT_OWN")
public class APP_IN_JNT_OWN_Cargo extends AbstractCargo implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	@Id
	private Integer jnt_own_seq_num;
	
	@Column(name="asset_type")
	@Id
	private String aset_typ;
	
	private String src_app_ind;
	@Transient
	private String ecp_id;
	
	@Column(name="asset_sub_type")
	private String aset_sub_typ;
	private Integer jnt_indv_seq_num;
	
	@Column(name="jnt_own_first_name")
	private String jnt_own_fst_nam;
	@Column(name="jnt_own_last_name")
	private String jnt_own_last_nam;
	@Transient
	private String otsd_ind;
	private Double jnt_own_share;
	@Transient
	private String fst_nam;

	public String getFst_nam() {
		return fst_nam;
	}

	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}

	/**
	 * @return the ecp_id
	 */
	public String getEcp_id() {
		return ecp_id;
	}

	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(final String ecp_id) {
		this.ecp_id = ecp_id;
	}

	/**
	 * returns the src app ind value.
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * sets the src app ind value.
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * returns the aset_typ value.
	 */
	public String getAset_typ() {
		return aset_typ;
	}

	/**
	 * sets the aset_typ value.
	 */
	public void setAset_typ(final String aset_typ) {
		this.aset_typ = aset_typ;
	}

	/**
	 * returns the jnt_own_seq_num value.
	 */
	public Integer getJnt_own_seq_num() {
		return jnt_own_seq_num;
	}

	/**
	 * sets the jnt_own_seq_num value.
	 */
	public void setJnt_own_seq_num(final Integer jnt_own_seq_num) {
		this.jnt_own_seq_num = jnt_own_seq_num;
	}

	/**
	 * returns the aset_sub_typ value.
	 */
	public String getAset_sub_typ() {
		return aset_sub_typ;
	}

	/**
	 * sets the aset_sub_typ value.
	 */
	public void setAset_sub_typ(final String aset_sub_typ) {
		this.aset_sub_typ = aset_sub_typ;
	}

	/**
	 * returns the jnt_indv_seq_num value.
	 */
	public Integer getJnt_indv_seq_num() {
		return jnt_indv_seq_num;
	}

	/**
	 * sets the jnt_indv_seq_num value.
	 */
	public void setJnt_indv_seq_num(final Integer jnt_indv_seq_num) {
		this.jnt_indv_seq_num = jnt_indv_seq_num;
	}

	/**
	 * returns the jnt_own_fst_nam value.
	 */
	public String getJnt_own_fst_nam() {
		return jnt_own_fst_nam;
	}

	/**
	 * sets the jnt_own_fst_nam value.
	 */
	public void setJnt_own_fst_nam(final String jnt_own_fst_nam) {
		this.jnt_own_fst_nam = jnt_own_fst_nam;
	}

	/**
	 * returns the jnt_own_last_nam value.
	 */
	public String getJnt_own_last_nam() {
		return jnt_own_last_nam;
	}

	/**
	 * sets the jnt_own_last_nam value.
	 */
	public void setJnt_own_last_nam(final String jnt_own_last_nam) {
		this.jnt_own_last_nam = jnt_own_last_nam;
	}

	/**
	 * returns the otsd_ind value.
	 */
	public String getOtsd_ind() {
		return otsd_ind;
	}

	/**
	 * sets the otsd_ind value.
	 */
	public void setOtsd_ind(final String otsd_ind) {
		this.otsd_ind = otsd_ind;
	}

	

	/**
	 * @return the jnt_own_share
	 */
	public Double getJnt_own_share() {
		return jnt_own_share;
	}

	/**
	 * @param jnt_own_share
	 *            the jnt_own_share to set
	 */
	public void setJnt_own_share(final Double jnt_own_share) {
		this.jnt_own_share = jnt_own_share;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((aset_sub_typ == null) ? 0 : aset_sub_typ.hashCode());
		result = prime * result + ((aset_typ == null) ? 0 : aset_typ.hashCode());
		result = prime * result + ((ecp_id == null) ? 0 : ecp_id.hashCode());
		result = prime * result + ((fst_nam == null) ? 0 : fst_nam.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((jnt_indv_seq_num == null) ? 0 : jnt_indv_seq_num.hashCode());
		result = prime * result + ((jnt_own_fst_nam == null) ? 0 : jnt_own_fst_nam.hashCode());
		result = prime * result + ((jnt_own_last_nam == null) ? 0 : jnt_own_last_nam.hashCode());
		result = prime * result + ((jnt_own_seq_num == null) ? 0 : jnt_own_seq_num.hashCode());
		result = prime * result + ((jnt_own_share == null) ? 0 : jnt_own_share.hashCode());
		result = prime * result + ((otsd_ind == null) ? 0 : otsd_ind.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}

	



	/*
	 * (non-Javadoc)
	 *
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		final StringBuilder builder = new StringBuilder();
		builder.append("APP_IN_JNT_OWN_Cargo [app_num=");
		builder.append(app_num);
		builder.append(", indv_seq_num=");
		builder.append(indv_seq_num);
		builder.append(", seq_num=");
		builder.append(seq_num);
		builder.append(", aset_typ=");
		builder.append(aset_typ);
		builder.append(", jnt_own_seq_num=");
		builder.append(jnt_own_seq_num);
		builder.append(", aset_sub_typ=");
		builder.append(aset_sub_typ);
		builder.append(", jnt_indv_seq_num=");
		builder.append(jnt_indv_seq_num);
		builder.append(", jnt_own_fst_nam=");
		builder.append(jnt_own_fst_nam);
		builder.append(", jnt_own_last_nam=");
		builder.append(jnt_own_last_nam);
		builder.append(", otsd_ind=");
		builder.append(otsd_ind);
		builder.append(", src_app_ind=");
		builder.append(src_app_ind);
		builder.append(", jnt_own_share=");
		builder.append(jnt_own_share);
		builder.append("]");
		return builder.toString();
	} 
	     
}