package gov.state.nextgen.financialinformation.business.entities;

import java.rmi.RemoteException;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class RedetMCExpensesIndvDetails_Collection extends AbstractCollection {

	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.RedetMCExpensesIndvDetails";

	public void setGenericResults(final Object obj) throws RemoteException {
		if (obj instanceof RedetMCExpensesIndvDetails_Cargo[]) {
			final RedetMCExpensesIndvDetails_Cargo[] cbArray = (RedetMCExpensesIndvDetails_Cargo[]) obj;
			setResults(cbArray);
		}

	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final RedetMCExpensesIndvDetails_Cargo[] cargos) {
		clear();
		for (int index = 0, length = cargos.length; index < length; index++) {
			add(cargos[index]);
		}
	}

	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	public boolean addCargo(final RedetMCExpensesIndvDetails_Cargo cargo) {
		return add(cargo);
	}

	public RedetMCExpensesIndvDetails_Cargo getCargo(final int index) {
		return (RedetMCExpensesIndvDetails_Cargo) get(index);
	}
}
