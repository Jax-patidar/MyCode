package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class CP_APP_IN_MED_INS_KEY implements Serializable{
	/**
    *
    */
   private static final long serialVersionUID = 1L;
   
   
	private String app_num;

	private Integer policy_seq_num;
	
	private Integer indv_seq_num;
	
	private String src_app_ind;

	public CP_APP_IN_MED_INS_KEY() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CP_APP_IN_MED_INS_KEY(String app_num, Integer policy_seq_num, Integer indv_seq_num, String src_app_ind) {
		super();
		this.app_num = app_num;
		this.policy_seq_num = policy_seq_num;
		this.indv_seq_num = indv_seq_num;
		this.src_app_ind = src_app_ind;
	}

	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return app_num;
	}

	/**
	 * @param app_num the app_num to set
	 */
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}

	/**
	 * @return the policy_seq_num
	 */
	public Integer getPolicy_seq_num() {
		return policy_seq_num;
	}

	/**
	 * @param policy_seq_num the policy_seq_num to set
	 */
	public void setPolicy_seq_num(Integer policy_seq_num) {
		this.policy_seq_num = policy_seq_num;
	}

	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((policy_seq_num == null) ? 0 : policy_seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}

	

}
