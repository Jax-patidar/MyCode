package gov.state.nextgen.financialinformation.business.services;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.util.ExceptionUtil;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Collection;
import gov.state.nextgen.financialinformation.business.rules.ABFinalSubmitBO;
import gov.state.nextgen.financialinformation.business.rules.ABOtherIncomeBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInUieRepository;
import gov.state.nextgen.framework.business.model.IndividualCategorySequenceDetails;
import gov.state.nextgen.framework.business.model.PageActionDetails;
import gov.state.nextgen.framework.business.model.UserDetails;

@SuppressWarnings("squid:S2229")
@Service("OtherIncomeService")
public class OtherIncomeServImpl implements FinancialServInterface {

	@Autowired
	private ABOtherIncomeBO abOtherIncomeBO;

	@Autowired
	private ABFinalSubmitBO finalSubmitBO;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private AppInUieRepository appInUeiRepository;

	private static final String MILLISECONDS = "milliseconds";
	
	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {

		switch (methodName) {

		case FinancialInfoConstants.STORE_OTHER_INC_DET:
			this.storeOtherIncomeDetail(txnBean);
			break;

		case FinancialInfoConstants.GET_OTHER_INC_DET:
			this.getOtherIncomeDetail(txnBean);
			break;
		case FinancialInfoConstants.STOREOTHERDETAIL:
			this.storeOtherDetail(txnBean);
			break;
			
		default:
		}

	}
	

	@Transactional
	@SuppressWarnings("squid:S3776")
	public void storeOtherIncomeDetail(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeServImpl.storeOtherIncomeDetail() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			FwMessageList validateInfo = null;
			String appNum = userDetails.getAppNumber();
			Integer seq_num = null;

			// get Details Collection and Cargo
			final APP_IN_UEI_Collection appInCollReq = (APP_IN_UEI_Collection) pageCollection
					.get("APP_IN_UEI_Collection");
			APP_IN_UEI_Cargo cargo_req = null;
			if (null!= appInCollReq && !appInCollReq.isEmpty()) {
				cargo_req = appInCollReq.getCargo(0);
			}
			IndividualCategorySequenceDetails categorySequenceDetails=txnBean.getCurrentActionDetails().getIndividualCategorySequenceDetails();
			Integer indvSeqNum = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			if(null!=categorySequenceDetails.getCategorySequence() && !categorySequenceDetails.getCategorySequence().isEmpty()) {
			seq_num = Integer.parseInt(categorySequenceDetails.getCategorySequence());
			}else {
				if(null!=cargo_req && cargo_req.getSeq_num()!=0) {
					
						seq_num=cargo_req.getSeq_num();
					
				}
			}
			String type = categorySequenceDetails.getCategoryType();
			if(null==type && null!=cargo_req) {
				type= cargo_req.getUei_typ();
			}

			final APP_IN_UEI_Collection beforeColl = abOtherIncomeBO.loadIndividualOtherIncomeDetails(appNum,
					indvSeqNum, seq_num, type);

			APP_IN_UEI_Cargo beforeCargo = new APP_IN_UEI_Cargo();
			// Source app indicator and change effective date default values
			// population PCR # 29768
			if(null!=cargo_req) {
			
			cargo_req.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);

			cargo_req.setIndv_seq_num(indvSeqNum);
			}
			if ((beforeColl != null) && beforeColl.size() > 0 && (!beforeColl.isEmpty())) {
				beforeCargo = beforeColl.getCargo(0);
				if(null!=cargo_req) {
				cargo_req.setApp_num(appNum);
				cargo_req.setUei_typ(beforeColl.getCargo(0).getUei_typ());
				cargo_req.setSeq_num(beforeColl.getCargo(0).getSeq_num());
				}
				if (beforeCargo.getSrc_app_ind() == null) {
					beforeCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				}

				// check dirty
				cargo_req = (APP_IN_UEI_Cargo) isChanged(beforeCargo, cargo_req);

			} 
			else if ((beforeColl != null) && beforeColl.size() == 0) {
				if(null!=cargo_req) {
				cargo_req.setApp_num(appNum);
				cargo_req.setIndv_seq_num(indvSeqNum);
				cargo_req.setUei_typ(type);
				cargo_req.setSeq_num(seq_num);
				}
				if (beforeCargo.getSrc_app_ind() == null) {
					beforeCargo.setSrc_app_ind(AppConstants.SRC_APP_IND_AFB);
				}
			}


			

			if (null!=cargo_req && cargo_req.getUei_amt() == null) {
					cargo_req.setUei_amt(FinancialInfoConstants.ZERO_DOUBLE);
				}
			if (null!=cargo_req && cargo_req.getRec_cplt_ind() == null) {
				cargo_req.setRec_cplt_ind(FinancialInfoConstants.ONE);
			}
			appInCollReq.addCargo(cargo_req);
			abOtherIncomeBO.storeOtherIncomeDetails(appInCollReq);

		
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in OtherIncomeServImpl.storeOtherIncomeDetail()", txnBean);
			FwExceptionManager.handleException(e,this.getClass().getName(),
        			FinancialInfoConstants.STORE_OTHER_INC_DET, txnBean.getUserDetails().getAppNumber(),
        			txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"OtherIncomeEJBBean.storeOtherIncomeDetail() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + MILLISECONDS, txnBean);
	}

	protected AbstractCargo isChanged(final AbstractCargo aBeforeCargo, final AbstractCargo aAfterCargo)
			throws FwException {

		
			if (aBeforeCargo == aAfterCargo) {
				aAfterCargo.setDirty(false);
			} else {
				if (null != aAfterCargo) {
					if ((aBeforeCargo == null) || (aBeforeCargo.hashCode() != aAfterCargo.hashCode())) {
						aAfterCargo.setDirty(true);
					} else
						aAfterCargo.setDirty(false);
				}
			}
			return aAfterCargo;
	}

	@Transactional
	public void getOtherIncomeDetail(final FwTransaction txnBean) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "OtherIncomeEJBBean.getOtherIncomeDetail() - START", txnBean);
		try {

			Map pageCollection = txnBean.getPageCollection();
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("indvIds");
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			UserDetails userDetails = txnBean.getUserDetails();
			PageActionDetails currentPageActionDetails = txnBean.getCurrentActionDetails();
			IndividualCategorySequenceDetails categorySequenceDetails = currentPageActionDetails
					.getIndividualCategorySequenceDetails();


			String appNum = userDetails.getAppNumber();

			String type = categorySequenceDetails.getCategoryType();
			
			

			

				final APP_IN_UEI_Collection appInUEICollection=abOtherIncomeBO.loadOtherIncomeDetails(
						appNum, type, indvIdList);
				pageCollection.put(FinancialInfoConstants.APP_IN_UEI_COLL, appInUEICollection);					




			
			txnBean.setPageCollection(pageCollection);
		
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in OtherIncomeServImpl.getOtherIncomeDetail()", txnBean);
			FwExceptionManager.handleException(e,this.getClass().getName(),
        			FinancialInfoConstants.GET_OTHER_INC_DET, txnBean.getUserDetails().getAppNumber(),
        			txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), Level.INFO, "OtherIncomeEJBBean.getOtherIncomeDetail() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime) + MILLISECONDS, txnBean);
	}

	public void storeOtherDetail(final FwTransaction txnBean) {

		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeEJBBean.storeOtherDetail() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();
			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			final APP_IN_UEI_Collection appInCollReq = (APP_IN_UEI_Collection) pageCollection
					.get("APP_IN_UEI_Collection");
			APP_IN_UEI_Cargo cargo_req = appInCollReq.getCargo(0);
			Integer indvSeqNum = cargo_req.getIndv_seq_num();
			String type = "OIC";

			cargo_req.setSrc_app_ind("AB");
			cargo_req.setSeq_num(1);
			cargo_req.setIndv_seq_num(indvSeqNum);
			cargo_req.setApp_num(appNum);
			cargo_req.setUei_typ(type);

			appInCollReq.addCargo(cargo_req);
			abOtherIncomeBO.storeOtherIncomeDetails(appInCollReq);

		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in OtherIncomeServImpl.storeOtherDetail()", txnBean);
			FwExceptionManager.handleException(e,this.getClass().getName(),
					FinancialInfoConstants.STOREOTHERDETAIL, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "OtherIncomeEJBBean.storeOtherDetail() - END , Time Taken : "
				+ (System.currentTimeMillis() - startTime) + MILLISECONDS, txnBean);
	}

	
}
