/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCargo;
import gov.state.nextgen.access.management.constants.FwConstants;

import javax.persistence.Embeddable;

/**
 * @author ransahu
 *
 */
@Embeddable
public class APP_IN_EMPL_Id  implements java.io.Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Integer app_number;
	
	private Integer indv_seq_num;
	
	private Integer empl_seq_num;
	
	
	
	
	private String ik_income_type;

	public APP_IN_EMPL_Id() {
		
	}
	
	

	public APP_IN_EMPL_Id(Integer app_num, Integer indv_seq_num, Integer empl_seq_num,String ik_income_type) {
		super();
		this.app_number = app_num;
		this.indv_seq_num = indv_seq_num;
		this.empl_seq_num = empl_seq_num;
		this.ik_income_type=ik_income_type;
	}



	public String getIk_income_type() {
		return ik_income_type;
	}



	public void setIk_income_type(String ik_income_type) {
		this.ik_income_type = ik_income_type;
	}


	public Integer getApp_number() {
		return app_number;
	}



	public void setApp_number(Integer app_number) {
		this.app_number = app_number;
	}



	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public Integer getEmpl_seq_num() {
		return empl_seq_num;
	}

	public void setEmpl_seq_num(Integer empl_seq_num) {
		this.empl_seq_num = empl_seq_num;
	}

	

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((empl_seq_num == null) ? 0 : empl_seq_num.hashCode());
		result = prime * result + ((ik_income_type == null) ? 0 : ik_income_type.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		return result;
	}


@SuppressWarnings("squid:S3776")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		APP_IN_EMPL_Id other = (APP_IN_EMPL_Id) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (empl_seq_num == null) {
			if (other.empl_seq_num != null)
				return false;
		} else if (!empl_seq_num.equals(other.empl_seq_num))
			return false;
		if (ik_income_type == null) {
			if (other.ik_income_type != null)
				return false;
		} else if (!ik_income_type.equals(other.ik_income_type))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		return true;
	}

	

}