package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.*;

/**
 * The primary key class for the cp_app_in_empl_pay_stub database table.
 * 
 */
@Embeddable
public class AppInDcEListPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="app_num")
	private Integer app_number;

	@Column(name="indv_seq_num")
	private Integer indvSeqNum;

	@Column(name="seq_num")
	private Integer seqNum;

	@Column(name="stub_seq_num")
	private Integer stubSeqNum;

	public AppInDcEListPK() {
		//Will use bean pattern
	}
	public Integer getApp_number() {
		return app_number;
	}

	public void setApp_number(Integer app_number) {
		this.app_number = app_number;
	}

	@Override
	public int hashCode() {
		return Objects.hash(app_number, indvSeqNum, seqNum, stubSeqNum);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AppInDcEListPK other = (AppInDcEListPK) obj;
		return Objects.equals(app_number, other.app_number) && Objects.equals(indvSeqNum, other.indvSeqNum)
				&& Objects.equals(seqNum, other.seqNum) && Objects.equals(stubSeqNum, other.stubSeqNum);
	}

	public Integer getIndvSeqNum() {
		return indvSeqNum;
	}

	public void setIndvSeqNum(Integer indvSeqNum) {
		this.indvSeqNum = indvSeqNum;
	}

	public Integer getStubSeqNum() {
		return stubSeqNum;
	}

	public void setStubSeqNum(Integer stubSeqNum) {
		this.stubSeqNum = stubSeqNum;
	}

	public Integer getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}

	
}