package gov.state.nextgen.financialinformation.business.entities;


import java.util.Date;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(APP_IN_LQD_ASET_Id.class)
@Table(name="CP_APP_IN_LQD_ASSET")
public class APP_IN_LQD_ASET_Cargo  extends AbstractCargo implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1124371622664418044L;
	
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	
	@Id
	private Integer indv_seq_num;
	
	@Id
	private Integer seq_num;
	
	
	private String src_app_ind;
	
	private String acct_num;
	@Transient
	private String bury_dsgt_sw;
	@Transient
	private String fncl_inst_city_adr;
	@Transient
	private String fncl_inst_l1_adr;
	@Transient
	private String fncl_inst_l2_adr;
	@Column(name="fncl_inst_name")
	private String fncl_inst_nam;
	@Transient
	private String fncl_inst_sta_adr;
	@Transient
	private String fncl_inst_zip_adr;
	private String jnt_own_resp;
	@Column(name="lqd_asset_amt")
	private Double lqd_aset_amt;
	@Column(name="lqd_asset_amt_ind")
	private Integer lqd_aset_amt_ind;
	@Id
	@Column(name="lqd_asset_type")
	private String lqd_aset_typ;
	private String rec_cplt_ind;

	@Transient
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date account_acquired_dt;
	
	private String account_maintainence_reason_cd;

	@JsonFormat(pattern="yyyy-MM-dd")
	private Date asset_end_dt;
	
	@Transient
	private String business_trade_farming_ind;
	@Transient
	private String first_name;
	@Transient
	private String last_name;
	private String liquid_asset_sub_type_cd;
	@Transient
	private String school_expenses_ind;
	@Transient
	private String lqd_aset_recov_type_cd;
	
	@Transient
	private String loopingInd;
	
	@Transient
	private Integer ecp_id;
	@Transient
	private String addrZip4;
	@Transient
	private String jnt_own_fst_nam;
	@Transient
	private String jnt_own_last_nam;
	
	@Column(name = "lqd_asset_calsaws_object")
	private String lqdAssetCalsawsObject;
	
	public String getJnt_own_fst_nam() {
		return jnt_own_fst_nam;
	}
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date asset_change_dt;
	public void setJnt_own_fst_nam(String jnt_own_fst_nam) {
		this.jnt_own_fst_nam = jnt_own_fst_nam;
	}

	public String getJnt_own_last_nam() {
		return jnt_own_last_nam;
	}

	public void setJnt_own_last_nam(String jnt_own_last_nam) {
		this.jnt_own_last_nam = jnt_own_last_nam;
	}

	public Integer getJnt_indv_seq_num() {
		return jnt_indv_seq_num;
	}

	public void setJnt_indv_seq_num(Integer jnt_indv_seq_num) {
		this.jnt_indv_seq_num = jnt_indv_seq_num;
	}

	@Transient
	private Integer jnt_indv_seq_num;
	
	
	@Column(name="change_dt")
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date chg_dt;

	//added as part of 10553 
    @Column(name="asset_name")
	private String asset_name;
    
    private String asset_comments;
    private String transaction_type;
    
	
	public String getAsset_name() {
		return asset_name;
	}

	public void setAsset_name(String asset_name) {
		this.asset_name = asset_name;
	}
   //end:changes
	
	public String getApp_num() {
		return String.valueOf(app_number);
	}

	public void setApp_num(String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}
	
	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}

	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	public Integer getSeq_num() {
		return seq_num;
	}

	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}

	public String getAcct_num() {
		return acct_num;
	}

	public void setAcct_num(String acct_num) {
		this.acct_num = acct_num;
	}

	public String getBury_dsgt_sw() {
		return bury_dsgt_sw;
	}

	public void setBury_dsgt_sw(String bury_dsgt_sw) {
		this.bury_dsgt_sw = bury_dsgt_sw;
	}

	public String getFncl_inst_city_adr() {
		return fncl_inst_city_adr;
	}

	public void setFncl_inst_city_adr(String fncl_inst_city_adr) {
		this.fncl_inst_city_adr = fncl_inst_city_adr;
	}

	public String getFncl_inst_l1_adr() {
		return fncl_inst_l1_adr;
	}

	public void setFncl_inst_l1_adr(String fncl_inst_l1_adr) {
		this.fncl_inst_l1_adr = fncl_inst_l1_adr;
	}

	public String getFncl_inst_l2_adr() {
		return fncl_inst_l2_adr;
	}

	public void setFncl_inst_l2_adr(String fncl_inst_l2_adr) {
		this.fncl_inst_l2_adr = fncl_inst_l2_adr;
	}

	public String getFncl_inst_nam() {
		return fncl_inst_nam;
	}

	public void setFncl_inst_nam(String fncl_inst_nam) {
		this.fncl_inst_nam = fncl_inst_nam;
	}

	public String getFncl_inst_sta_adr() {
		return fncl_inst_sta_adr;
	}

	public void setFncl_inst_sta_adr(String fncl_inst_sta_adr) {
		this.fncl_inst_sta_adr = fncl_inst_sta_adr;
	}

	public String getFncl_inst_zip_adr() {
		return fncl_inst_zip_adr;
	}

	public void setFncl_inst_zip_adr(String fncl_inst_zip_adr) {
		this.fncl_inst_zip_adr = fncl_inst_zip_adr;
	}

	public String getJnt_own_resp() {
		return jnt_own_resp;
	}

	public void setJnt_own_resp(String jnt_own_resp) {
		this.jnt_own_resp = jnt_own_resp;
	}

	public Double getLqd_aset_amt() {
		return lqd_aset_amt;
	}

	public void setLqd_aset_amt(Double lqd_aset_amt) {
		this.lqd_aset_amt = lqd_aset_amt;
	}

	public Integer getLqd_aset_amt_ind() {
		return lqd_aset_amt_ind;
	}

	public void setLqd_aset_amt_ind(Integer lqd_aset_amt_ind) {
		this.lqd_aset_amt_ind = lqd_aset_amt_ind;
	}

	public String getLqd_aset_typ() {
		return lqd_aset_typ;
	}

	public void setLqd_aset_typ(String lqd_aset_typ) {
		this.lqd_aset_typ = lqd_aset_typ;
	}

	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	public void setRec_cplt_ind(String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	public Date getAccount_acquired_dt() {
		return account_acquired_dt;
	}

	public void setAccount_acquired_dt(Date account_acquired_dt) {
		this.account_acquired_dt = account_acquired_dt;
	}

	public String getAccount_maintainence_reason_cd() {
		return account_maintainence_reason_cd;
	}

	public void setAccount_maintainence_reason_cd(String account_maintainence_reason_cd) {
		this.account_maintainence_reason_cd = account_maintainence_reason_cd;
	}

	public Date getAsset_end_dt() {
		return asset_end_dt;
	}

	public void setAsset_end_dt(Date asset_end_dt) {
		this.asset_end_dt = asset_end_dt;
	}

	public String getBusiness_trade_farming_ind() {
		return business_trade_farming_ind;
	}

	public void setBusiness_trade_farming_ind(String business_trade_farming_ind) {
		this.business_trade_farming_ind = business_trade_farming_ind;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getLiquid_asset_sub_type_cd() {
		return liquid_asset_sub_type_cd;
	}

	public void setLiquid_asset_sub_type_cd(String liquid_asset_sub_type_cd) {
		this.liquid_asset_sub_type_cd = liquid_asset_sub_type_cd;
	}

	public String getSchool_expenses_ind() {
		return school_expenses_ind;
	}

	public void setSchool_expenses_ind(String school_expenses_ind) {
		this.school_expenses_ind = school_expenses_ind;
	}

	public String getSrc_app_ind() {
		return src_app_ind;
	}

	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	public String getLqd_aset_recov_type_cd() {
		return lqd_aset_recov_type_cd;
	}

	public void setLqd_aset_recov_type_cd(String lqd_aset_recov_type_cd) {
		this.lqd_aset_recov_type_cd = lqd_aset_recov_type_cd;
	}

	public String getLoopingInd() {
		return loopingInd;
	}

	public void setLoopingInd(String loopingInd) {
		this.loopingInd = loopingInd;
	}

	public Integer getEcp_id() {
		return ecp_id;
	}

	public void setEcp_id(Integer ecp_id) {
		this.ecp_id = ecp_id;
	}

	public String getAddrZip4() {
		return addrZip4;
	}

	public void setAddrZip4(String addrZip4) {
		this.addrZip4 = addrZip4;
	}

	public Date getChg_dt() {
		return chg_dt;
	}

	public void setChg_dt(Date chg_dt) {
		this.chg_dt = chg_dt;
	}

	public Date getAsset_change_dt() {
		return asset_change_dt;
	}

	public void setAsset_change_dt(Date asset_change_dt) {
		this.asset_change_dt = asset_change_dt;
	}

	public String getAsset_comments() {
		return asset_comments;
	}

	public void setAsset_comments(String asset_comments) {
		this.asset_comments = asset_comments;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

	public String getLqdAssetCalsawsObject() {
		return lqdAssetCalsawsObject;
	}

	public void setLqdAssetCalsawsObject(String lqdAssetCalsawsObject) {
		this.lqdAssetCalsawsObject = lqdAssetCalsawsObject;
	}
}
