package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.exceptions.FwWrappedException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_R_PROP_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_R_PROP_ASET_Collection;
import gov.state.nextgen.financialinformation.business.rules.RealPropertyBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInRealPropertyRepository;
import gov.state.nextgen.framework.business.model.UserDetails;
import org.springframework.transaction.annotation.Transactional;

/**
 * Added as part of CSPM-18772-OwnPropertyService.
 * @author agopisainadh
 *
 */

@Service("RedetMCOwnPropertyService")
public class RedetMCOwnPropertyServImpl implements FinancialServInterface{
	@Autowired
	private RealPropertyBO realPropBo;
	@Autowired
	private AppInRealPropertyRepository appInRealPropertyRepository;
	@SuppressWarnings("squid:S2229")
	@Override
	public void callBusinessLogic(String methodName, FwTransaction txnBean) {

		switch (methodName) {

		case FinancialInfoConstants.LOAD_OWN_PROPERTY_DETAILS:
			loadOwnPropertyDetails(txnBean);
			break;

		case FinancialInfoConstants.REMOVE_OWN_PROPERTY_DETAILS:
			removeOwnPropertyDetails(txnBean);
			break;
		case FinancialInfoConstants.STORE_OWN_PROPERTY_DETAILS:
			storeOwnPropertyDetails(txnBean);
			break;
		default:
			break;
		}

	}
	/***
	 * Method to delete OwnPropertyDetails(Soft Delete).
	 * @param txnBean
	 */
	@SuppressWarnings("squid:S2229")
	@Transactional
	public void removeOwnPropertyDetails(FwTransaction txnBean) {
		try {
			String appNumber = txnBean.getUserDetails().getAppNumber();
			Integer indvSeqNum = Integer.parseInt(txnBean.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails().getIndividualSequence());
			Integer seqNum = Integer.parseInt(txnBean.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails().getCategorySequence());
			String ownPropertyAssetType = FinancialInfoConstants.OP;
			APP_IN_R_PROP_ASET_Collection existingRPropColl = realPropBo.loadIndividualRealPropertyDetailsMC(appNumber,
					indvSeqNum, seqNum);
			if(Objects.nonNull(existingRPropColl) && !existingRPropColl.isEmpty()) {
				APP_IN_R_PROP_ASET_Cargo existingCargo = existingRPropColl.getCargo(0);
				if(Objects.nonNull(existingCargo)) {
					existingCargo.setAsset_end_dt(new java.sql.Date(new java.util.Date().getTime()));
					appInRealPropertyRepository.save(existingCargo);
				}
			}
		} catch (FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in RedetMCOwnPropertyServImpl.removeOwnPropertyDetails()", txnBean);
			FwWrappedException we = new FwWrappedException(fe);
			we.setCallingClassID(getClass().getName());
			we.setCallingMethodID(FinancialInfoConstants.REMOVE_OWN_PROPERTY_DETAILS);
			we.setFwException(fe);
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.REMOVE_OWN_PROPERTY_DETAILS, we);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.REMOVE_OWN_PROPERTY_DETAILS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in RedetMCOwnPropertyServImpl.removeOwnPropertyDetails()", txnBean);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.REMOVE_OWN_PROPERTY_DETAILS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.REMOVE_OWN_PROPERTY_DETAILS, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.REMOVE_OWN_PROPERTY_DETAILS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedetMCOwnPropertyServImpl.removeOwnPropertyDetails() - END", txnBean);
	}

	/***
	 * Method to load OwnProperty Details based on appNum.
	 * @param txnBean
	 */
	@SuppressWarnings("squid:S2229")
	@Transactional
	public void loadOwnPropertyDetails(FwTransaction txnBean) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedetMCOwnPropertyServImpl.loadOwnPropertyDetails() - START", txnBean);
		try {
			Map pageCollection = txnBean.getPageCollection();

			UserDetails userDetails = txnBean.getUserDetails();
			String appNum = userDetails.getAppNumber();
			APP_IN_R_PROP_ASET_Collection appPropColl = null;
			appPropColl = realPropBo.loadRealPropertyDetailsMC(appNum);
			
			ArrayList<String> indvList = (ArrayList<String>) pageCollection.get("indvIds");
			
			List<APP_IN_R_PROP_ASET_Cargo> result =  Arrays.stream((appPropColl.getResults())).filter(val -> indvList.contains(val.getIndv_seq_num().toString())).collect(Collectors.toList());
			APP_IN_R_PROP_ASET_Cargo[] appInRPropFilteredCargo = result.toArray(new APP_IN_R_PROP_ASET_Cargo[result.size()]);
			appPropColl.setResults(appInRPropFilteredCargo);
			
			pageCollection.put(FinancialInfoConstants.APP_IN_R_PROP_ASET_COLL, appPropColl);
			txnBean.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), Level.INFO, "RedetMCOwnPropertyServImpl::loadOwnPropertyDetails");
		} catch (FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in RedetMCOwnPropertyServImpl.loadOwnPropertyDetails()", txnBean);
			FwWrappedException we = new FwWrappedException(fe);
			we.setCallingClassID(getClass().getName());
			we.setCallingMethodID(FinancialInfoConstants.LOAD_OWN_PROPERTY_DETAILS);
			we.setFwException(fe);
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.LOAD_OWN_PROPERTY_DETAILS, we);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.LOAD_OWN_PROPERTY_DETAILS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		} catch (Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in RedetMCOwnPropertyServImpl.loadOwnPropertyDetails()", txnBean);
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.LOAD_OWN_PROPERTY_DETAILS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.LOAD_OWN_PROPERTY_DETAILS, fe);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.LOAD_OWN_PROPERTY_DETAILS, txnBean.getUserDetails().getAppNumber(),
					txnBean.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "RedetMCOwnPropertyServImpl.loadOwnPropertyDetails() - END", txnBean);
	}

	/***
	 * Method to store updated or newly added OwnProperty Details.
	 * @param fwTxn
	 */
	@SuppressWarnings("squid:S2229")
	@Transactional
	public void storeOwnPropertyDetails(FwTransaction fwTxn) {
		long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedetMCOwnPropertyServImpl.storeOwnPropertyDetails() - START");
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			Integer seqNum = null;
			Integer indvSeqNum = null;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			APP_IN_R_PROP_ASET_Collection propAsetColl = (APP_IN_R_PROP_ASET_Collection) pageCollection
					.get(FinancialInfoConstants.APP_IN_R_PROP_ASET_COLL);

			if (null != propAsetColl && !propAsetColl.isEmpty()) {
				APP_IN_R_PROP_ASET_Cargo propAsetCargo = propAsetColl.getCargo(0);
				propAsetCargo.setApp_num(appNumber);
				propAsetCargo.setIndv_seq_num(indvSeqNum);
				propAsetCargo.setSeq_num(seqNum);
				propAsetCargo.setChg_dt(new java.sql.Date(new java.util.Date().getTime()));
				propAsetCargo.setSrc_app_ind(AppConstants.AFB_SRC_APP_IND);
				propAsetCargo.setReal_prop_aset_typ(FinancialInfoConstants.OP);

				propAsetColl.addCargo(propAsetCargo);

				realPropBo.saveOwnPropertyDetails(propAsetColl);
			}

		} catch (FwException fe) {
			FwLogger.log(this.getClass(), Level.ERROR, fe.getMessage());
			FwWrappedException we = new FwWrappedException(fe);
			we.setCallingClassID(getClass().getName());
			we.setCallingMethodID(FinancialInfoConstants.STORE_OWN_PROPERTY_DETAILS);
			we.setFwException(fe);
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.STORE_OWN_PROPERTY_DETAILS, we);
			throw we;
		} catch (Exception e) {
			FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
			FwException fe = new FwException(e);
			fe.setClassID(this.getClass().getName());
			fe.setMethodID(FinancialInfoConstants.STORE_OWN_PROPERTY_DETAILS);
			fe.setExceptionText(String.valueOf(e));
			fe.setExceptionType(FwConstants.EXP_TYP_FRAMEWORK);
			fe.setStackTraceValue(FwWrappedException.getStackTraceValue(e));
			FwLogger.log(this.getClass(), Level.ERROR, FinancialInfoConstants.STORE_OWN_PROPERTY_DETAILS, fe);
			throw fe;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"RedetMCOwnPropertyServImpl.storeOwnPropertyDetails() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) );

	}
}
