/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CP_OTHER_SITUATIONS_Id implements Serializable {

	private static final long serialVersionUID = -1184867010602687081L;
	
	private Integer other_situation_id;
	

	public CP_OTHER_SITUATIONS_Id() {
		super();
	}

	public CP_OTHER_SITUATIONS_Id(Integer other_situation_id) {
		super();
		this.other_situation_id = other_situation_id;
	}

	
	/**
	 * @return the other_situation_id
	 */
	public Integer getOther_situation_id() {
		return other_situation_id;
	}

	/**
	 * @param other_situation_id the other_situation_id to set
	 */
	public void setOther_situation_id(Integer other_situation_id) {
		this.other_situation_id = other_situation_id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((other_situation_id == null) ? 0 : other_situation_id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CP_OTHER_SITUATIONS_Id other = (CP_OTHER_SITUATIONS_Id) obj;
		if (other_situation_id == null) {
			if (other.other_situation_id != null)
				return false;
		} else if (!other_situation_id.equals(other.other_situation_id))
			return false;
		return true;
	}

	

}
