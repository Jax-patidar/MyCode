package gov.state.nextgen.financialinformation.business.rules;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_JNT_OWN_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_LQD_ASET_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_ASET_XFER_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_APP_IN_ASET_XFER_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.financialinformation.data.db2.AppInJntOwnRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInLqdAsetRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppInAsetXferRepository;

@Service("LiquidAssetBO")
public class LiquidAssetBO extends AbstractBO{
	
	private static Logger logger = LoggerFactory.getLogger(LiquidAssetBO.class);
	public static Double ZERO = 0.0;
	FwMessageList messageList = new FwMessageList();
	
	private static final String MILLI = " milliseconds";
	
	private static final String COMMENT = "LiquidAssetBO.validate() - START";
	
	private static final String ERROR_00312 = "00312";
	
	private static final String ERROR_00017 = "00017";
	
	private static final String ERROR_00019 = "00019";

	private static final String ERROR_99369 = "99369";
	
	private static final String COMMENT_1 = "LiquidAssetBO.validate() - END , Time Taken : ";
	
	private static final String COMMENT_2 = "validate";
	
	private static final String ERROR_00691 = "00691";
	
	@Autowired
	AppInLqdAsetRepository appInLqdAsetRepository;
	
	@Autowired
	AppInJntOwnRepository appInJntOwnRepository;
	
	@Autowired
	private IReferenceTableManager iref;
	
	@Autowired
	private CpAppInAsetXferRepository appInAsetXferRepository;
	private SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
	
	private static final String ASSET_TYPE_DEFAULT_CD = FwConstants.DEFAULT_DROPDOWN_SEL;
	private static final String ASSET_TYPE_MSG_CD = "00579";
	private static final String ASSET_ACQ_DT_MSG_CD = "00580";
	private static final String ASSET_SOLD_DT_MSG_CD = "XFRDT";
	private static final String ASSET_SOLD_AMT_MSG_CD = "00581";
	private static final String INVALID_SOLD_AMT_MSG_CD = "99291";
	private static final String INVALID_AMT_RECEIVED_MSG_CD = "99292";
	private static final String ASSET_XFER_AMT_MSG_CD = "00582";
	private static final String FUTURE_DATE = "40046";

	public APP_IN_LQD_ASET_Collection loadIndividualLiquidAssetDetails(String appNumber, int indvSeqNum,
			Integer seqNum, String categoryType) {

		logger.info( "LiquidAssetBO.loadIndividualLiquidAssetDetails() - START");
		try {
			final APP_IN_LQD_ASET_Collection appInColl = new APP_IN_LQD_ASET_Collection();
			
			final APP_IN_LQD_ASET_Cargo[] appInCargoArray = (APP_IN_LQD_ASET_Cargo[]) appInLqdAsetRepository.getAsetDetails(Integer.parseInt(appNumber), indvSeqNum, seqNum,categoryType);
			
			if(appInCargoArray != null && appInCargoArray.length > 0) 
			{
			appInColl.setResults(appInCargoArray);
			}
			
			
			return appInColl;
		}  catch (final Exception e) {
			throw e;
		}
	}

	public APP_IN_LQD_ASET_Collection loadLiquidAssetDetails(String appNumber) {

		logger.info( "LiquidAssetBO.loadLiquidAssetDetails() - START");
		try {
			final APP_IN_LQD_ASET_Collection appInColl = new APP_IN_LQD_ASET_Collection();

			final APP_IN_LQD_ASET_Cargo[] appInCargoArray = (APP_IN_LQD_ASET_Cargo[]) appInLqdAsetRepository.getByAppNum(Integer.parseInt(appNumber));
			
			if(appInCargoArray != null && appInCargoArray.length > 0) 
			{
			appInColl.setResults(appInCargoArray);
			}
			
			return appInColl;
		}  catch (final Exception e) {
			throw e;
		}
	}

	public APP_IN_JNT_OWN_Collection loadIndividualJointOwnerDetailsCargo(String appNumber, Integer indv_seq_num,
			String jointOwnerTypeLiquidAsset, String lqd_aset_typ, Integer seq_num) {

		logger.info( "LiquidAssetBO.loadIndividualJointOwnerDetails() - START");
		try {

			APP_IN_JNT_OWN_Collection appInJntColl = appInJntOwnRepository.getJointOwnerDetails(Integer.parseInt(appNumber),indv_seq_num,jointOwnerTypeLiquidAsset, lqd_aset_typ, seq_num);
			if(appInJntColl == null)
				appInJntColl = new APP_IN_JNT_OWN_Collection();
			
			
			return appInJntColl;
		}  catch (final Exception e) {
			throw e;
		}
	}

	public APP_IN_LQD_ASET_Collection loadLiquidAssetData(String appNumber, Integer indv_seq_num, Integer seq_num,
			String typ_cd) {
		try {
		return appInLqdAsetRepository.loadLiquidAssetData(Integer.parseInt(appNumber), indv_seq_num, seq_num, typ_cd);
		} catch (final Exception e) {
			throw e;
		}
	}

	public FwMessageList validate(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo, String showLoopingQuestion) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, COMMENT);
        try{
            FwMessageList messageList = new FwMessageList();

        	final char[] specialCharsForAddress = { '-', '\'', '.', '#', '/', ',' , '&', ' '};
            final String asettype = appInLqdAsetCargo.getLqd_aset_typ();
    		final String columnValue = iref.getColumnValue("TLAS", 99, asettype, FwConstants.ENGLISH);
    		final Object[] errorMessage = new Object[1];
    		errorMessage[0] = columnValue;
    		if (asettype != null && AppConstants.CASH_LIQUID_ASSET_TYPE.equals(asettype)) {
    			validateAssetType(appInLqdAsetCargo, messageList);
    		} else if (FinancialInfoConstants.ASSET_SUB_TYPE_CA.equals(asettype)) {
    			validateCAAssetType(appInLqdAsetCargo, showLoopingQuestion, messageList, specialCharsForAddress,
						errorMessage);

    		} else {
    			validateLiqAmt(appInLqdAsetCargo, messageList, asettype);

    			validateCompName(appInLqdAsetCargo, messageList);
    			String addressLine = appInLqdAsetCargo.getFncl_inst_l1_adr();
    			if((addressLine != null)) {
    				validateAddrDet(appInLqdAsetCargo, messageList, specialCharsForAddress, addressLine);
        			validateZipDet(appInLqdAsetCargo, messageList);
        			if (!messageList.containsMessage(ERROR_00019)
        					&& appInLqdAsetCargo.getAddrZip4() != null
        					&& !"".equals(appInLqdAsetCargo.getAddrZip4().trim())
        					&& !appInLqdAsetCargo.getAddrZip4().matches("\\d+")) {
        				messageList.addMessageToList(addMessageCode(ERROR_00019));
        			}
    				
    			}
    			
    			validateLiqAcctNum(appInLqdAsetCargo, showLoopingQuestion, messageList, errorMessage);
    		}
            FwLogger.log(this.getClass(), FwLogger.Level.INFO, COMMENT_1
                    + (System.currentTimeMillis() - startTime)
                    + MILLI);
            return messageList;
        }catch(FwException fe){
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
            throw fe;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }
	}

	private void validateCAAssetType(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo, String showLoopingQuestion,
			FwMessageList messageList, final char[] specialCharsForAddress, final Object[] errorMessage) {
		try {
		validateAssetAmtSubtype(appInLqdAsetCargo, messageList);
		validateCompName(appInLqdAsetCargo, messageList);
		String addressLine = appInLqdAsetCargo.getFncl_inst_l1_adr();
		if((addressLine != null)) {
			validateAddrDet(appInLqdAsetCargo, messageList, specialCharsForAddress, addressLine);
			validateZipDet(appInLqdAsetCargo, messageList);
			if (!messageList.containsMessage(ERROR_00019)
					&& appInLqdAsetCargo.getAddrZip4() != null
					&& !"".equals(appInLqdAsetCargo.getAddrZip4().trim())
					&& !appInLqdAsetCargo.getAddrZip4().matches("\\d+")) {
				messageList.addMessageToList(addMessageCode(ERROR_00019));
			}
			
		}
		
		validateAcctNum(appInLqdAsetCargo, showLoopingQuestion, messageList, errorMessage);
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateZipDet(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo, FwMessageList messageList) {
		try {
		final String zip = appInLqdAsetCargo.getFncl_inst_zip_adr();
		if (!appMgr.isFieldEmpty(zip)) {
			if (!appMgr.isInteger(zip)) {
				messageList.addMessageToList(addMessageCode(ERROR_00019));
			} else if (!appMgr.isZero(zip)) {
				messageList.addMessageToList(addMessageCode("00022"));
			}else if((appInLqdAsetCargo.getFncl_inst_zip_adr().length()!=5)){
				messageList.addMessageToList(addMessageCode("10503"));
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateAddrDet(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo, FwMessageList messageList,
			final char[] specialCharsForAddress, String addressLine) {
		try {
		if (!appMgr.isFieldEmpty(addressLine)
				&& !appMgr.isSpecialAlphaNumeric(addressLine,specialCharsForAddress)) {
			messageList.addMessageToList(addMessageCode(ERROR_00017));
		}
		addressLine = appInLqdAsetCargo.getFncl_inst_l2_adr();
		if ((addressLine != null) && !appMgr.isFieldEmpty(addressLine)
				&& !appMgr.isSpecialAlphaNumeric(addressLine,specialCharsForAddress)) {
			messageList.addMessageToList(addMessageCode(ERROR_00017));
		}
		final String city = appInLqdAsetCargo.getFncl_inst_city_adr();
		if ((city != null) && !appMgr.isFieldEmpty(city)
				&& !appMgr.isSpecialAlphaNumeric(city,specialCharsForAddress)) {
			messageList.addMessageToList(addMessageCode("00018"));
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateLiqAcctNum(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo, String showLoopingQuestion,
			FwMessageList messageList, final Object[] errorMessage) {
		try {
		final String accountNbr = appInLqdAsetCargo.getAcct_num();
		if ((accountNbr != null) && !FwConstants.EMPTY_STRING.equals(accountNbr.trim()) && !appMgr.isAlphaNumeric(accountNbr)) {
			messageList.addMessageToList(addMessageCode("00578"));
		}
		if(!AppConstants.CASH_LIQUID_ASSET_TYPE.equals(appInLqdAsetCargo.getLqd_aset_typ()) && FwConstants.YES.equalsIgnoreCase(showLoopingQuestion)){
			
				final String loopingInd = appInLqdAsetCargo.getLoopingInd();
				if ((loopingInd == null) || FwConstants.EMPTY_STRING.equals(loopingInd.trim())) {
					messageList.addMessageToList(addMessageWithFieldValues("00573", errorMessage));
				}
			
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateLiqAmt(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo, FwMessageList messageList,
			final String asettype) {
		try {
		final Double lqdAsetAmt = appInLqdAsetCargo.getLqd_aset_amt();
		if (lqdAsetAmt == FinancialInfoConstants.ZERO_DOUBLE) {
			messageList.addMessageToList(addMessageCode(ERROR_99369));
		}else {
				
				if ((lqdAsetAmt < FinancialInfoConstants.ZERO_DOUBLE) || (lqdAsetAmt > FinancialInfoConstants.MAX_AMOUNT)) {
					messageList.addMessageToList(addMessageCode(ERROR_00312));
				}

		}
		if (FinancialInfoConstants.ASSET_SUB_TYPE_TR.equals(asettype)) {
			final String revocable = appInLqdAsetCargo.getLqd_aset_recov_type_cd();
			if ((revocable == null) || ((revocable != null) && FwConstants.DEFAULT_DROPDOWN_SEL.equals(revocable))) {
				messageList.addMessageToList(addMessageCode(ERROR_99369));
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateCompName(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo, FwMessageList messageList) {
		final String companyName = appInLqdAsetCargo.getFncl_inst_nam();
		if ((companyName != null) && !FwConstants.EMPTY_STRING.equals(companyName.trim())) {
			final char[] specialChars = {  '.', '-', '\'', ' ','&' };
			if (!appMgr.isSpecialAlpha(
					companyName, specialChars)) {
				messageList.addMessageToList(addMessageCode("00572"));
			}				
		}
		
	}

	private void validateAcctNum(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo, String showLoopingQuestion,
			FwMessageList messageList, final Object[] errorMessage) {
		try {
		final String accountNbr = appInLqdAsetCargo.getAcct_num();
		if ((accountNbr != null) && !FwConstants.EMPTY_STRING.equals(accountNbr.trim()) && !appMgr.isAlphaNumeric(accountNbr)) {
			messageList.addMessageToList(addMessageCode("99404"));
		}
		if (FwConstants.YES.equalsIgnoreCase(showLoopingQuestion)) {
			final String loopingInd = appInLqdAsetCargo.getLoopingInd();
			if ((loopingInd == null) || FwConstants.EMPTY_STRING.equals(loopingInd.trim())) {
				messageList.addMessageToList(addMessageWithFieldValues("00573", errorMessage));
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateAssetAmtSubtype(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo, FwMessageList messageList) {
		try {
		final double lqdAsetAmt = appInLqdAsetCargo.getLqd_aset_amt();
		if (lqdAsetAmt == FinancialInfoConstants.ZERO_DOUBLE) {
			messageList.addMessageToList(addMessageCode("00570"));
		}else {
				if ((lqdAsetAmt < FinancialInfoConstants.ZERO_DOUBLE) || (lqdAsetAmt > FinancialInfoConstants.MAX_AMOUNT)) {
					messageList.addMessageToList(addMessageCode(ERROR_00312));
				}
		}
		final String liqAstSubTyCd = appInLqdAsetCargo.getLiquid_asset_sub_type_cd();
		if ((liqAstSubTyCd == null) || ((liqAstSubTyCd != null) && FwConstants.DEFAULT_DROPDOWN_SEL.equals(liqAstSubTyCd))) {
			messageList.addMessageToList(addMessageCode("00571"));
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	private void validateAssetType(APP_IN_LQD_ASET_Cargo appInLqdAsetCargo, FwMessageList messageList) {
		try {
		final Double lqdAsetAmt = appInLqdAsetCargo.getLqd_aset_amt();
		if (lqdAsetAmt == FinancialInfoConstants.ZERO_DOUBLE) {
			messageList.addMessageToList(addMessageCode("00569"));
		}else {
				
				if ((lqdAsetAmt < FinancialInfoConstants.ZERO_DOUBLE) || (lqdAsetAmt > FinancialInfoConstants.MAX_AMOUNT)) {
					messageList.addMessageToList(addMessageCode(ERROR_00312));
				}

		}
		} catch (final Exception e) {
			throw e;
		}
	}

	public void storeLiquidAssetDetails(APP_IN_LQD_ASET_Collection appInLqdAsetColl) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetBO.storeLiquidAssetDetails() - START");
        try {  	
        	if ((appInLqdAsetColl != null) && (!appInLqdAsetColl.isEmpty()) && (appInLqdAsetColl.size() > 0)){
        		APP_IN_LQD_ASET_Cargo lqdAssetCargo = appInLqdAsetColl.getCargo(0);
        		appInLqdAsetRepository.save(lqdAssetCargo);
            }
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetBO.storeLiquidAssetDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    + MILLI);
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }	
	}

	public FwMessageList validate(APP_IN_JNT_OWN_Cargo jntOwnCargo) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, COMMENT);
        try {  	
        	if (jntOwnCargo != null) {
    			final double sharedPerc = jntOwnCargo.getJnt_own_share();
    			if (FinancialInfoConstants.ZERO_DOUBLE == sharedPerc) {
    				messageList.addMessageToList(addMessageCode(ERROR_00691));
    			} 
    			else if(!appMgr.isInteger(Double.toString(sharedPerc)))
    			{
    			final Object[] error = new Object[] { new FwMessageTextLabel(
    				"3018182") };
    			messageList.addMessageToList(addMessageWithFieldValues("10242", error));
    			}
    			else {
    				try {
    					if (sharedPerc <= 0) {
    						messageList.addMessageToList(addMessageCode(ERROR_00691));
    					}

    				} catch (final Exception e) {
    					messageList.addMessageToList(addMessageCode(ERROR_00691));
    				}
    			}
    		}
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, COMMENT_1
                    + (System.currentTimeMillis() - startTime)
                    + MILLI);
        	return messageList;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }	
	}

	public FwMessageList validateJntOwnerPerc(APP_IN_JNT_OWN_Collection appInJntOwnCollection) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, COMMENT);
        try {  	
        	double totalShare = 0.00;
    		for (int index = 0, size = appInJntOwnCollection.size(); index < size; index++) {
    			final APP_IN_JNT_OWN_Cargo appInJntOwnCargo2 = appInJntOwnCollection.getCargo(index);
    			appInJntOwnCollection.getCargo(index);
    			final double value = appInJntOwnCargo2.getJnt_own_share();
				if ((FinancialInfoConstants.ZERO_DOUBLE == value)
						 && !FwConstants.ROWACTION_DELETE.equalsIgnoreCase(appInJntOwnCargo2.getRowAction())) {
    				try {
    					totalShare += appInJntOwnCargo2.getJnt_own_share();
    				} catch (final Exception e) {
    					totalShare += 0;
    				}
    			}
    		}
    		if (totalShare > 100) {
    			messageList.addMessageToList(addMessageCode("00705"));
    		}
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, COMMENT_1
                    + (System.currentTimeMillis() - startTime)
                    + MILLI);
        	return messageList;
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }	
	}

	public void storeJointOwnerDetails(APP_IN_JNT_OWN_Collection appInJntOwnNewColl) {
		final long startTime = System.currentTimeMillis();
        FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetBO.storeJointOwnerDetails() - START");
        try {  	
        	if ((appInJntOwnNewColl != null) && (!appInJntOwnNewColl.isEmpty()) && (appInJntOwnNewColl.size() > 0)){
        		APP_IN_JNT_OWN_Cargo jntOwnCargo = appInJntOwnNewColl.getCargo(0);
        		appInJntOwnRepository.save(jntOwnCargo);
            }
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "LiquidAssetBO.storeJointOwnerDetails() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    + MILLI);
        }catch (final Exception e) {
            FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
            throw e;
        }	
	}

	public CP_APP_IN_ASET_XFER_Collection storeAssetXferDetails(CP_APP_IN_ASET_XFER_Collection cpAppInAsetXferColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetBO.storeAssetXferDetails() - START");
		CP_APP_IN_ASET_XFER_Collection appInUpColl = new CP_APP_IN_ASET_XFER_Collection();
		try {
			if (null!=cpAppInAsetXferColl && cpAppInAsetXferColl.size()>0) {
				 appInAsetXferRepository.saveAll(cpAppInAsetXferColl);
			}
			FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetBO.storeAssetXferDetails() - END , Time Taken : " + (System.currentTimeMillis() - startTime) + MILLI);
			return appInUpColl;
		} catch (final Exception e) {
			throw e;
		}
	}
	public CP_APP_IN_ASET_XFER_Collection loadIndividualAssetXferDetails(String appNum, Integer indvSeqNum,
			Integer seqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetBO.loadIndividualAssetXferDetails() - START");
		try {
			final CP_APP_IN_ASET_XFER_Collection appInColl = appInAsetXferRepository.loadIndividualAssetXferDetails(Integer.parseInt(appNum),indvSeqNum,seqNum);
			FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetBO.loadIndividualAssetXferDetails() - END , Time Taken : " + (System.currentTimeMillis() - startTime)
					+ MILLI);
			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	public FwMessageList validateSoldAndTransferredAssetDetails(final CP_APP_IN_ASET_XFER_Cargo aCargo) {
		FwMessageList fwMessageList=new FwMessageList();
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetBO.validateSoldAndTransferredAssetDetails() - START");
		try {
		
			StringBuilder oneHundred20yearsAgo = null;
			final Calendar now = Calendar.getInstance();
			final int thisYear = now.get(Calendar.YEAR);
			oneHundred20yearsAgo = new StringBuilder(String.valueOf(thisYear - 120));
			oneHundred20yearsAgo = oneHundred20yearsAgo.append("-01-01");

			validateAssetType(aCargo, fwMessageList, oneHundred20yearsAgo);

			final String assetXferDt = format.format(aCargo.getAsset_xfer_dt());

			if (!appMgr.isFieldEmpty(assetXferDt)) {
				if (!appMgr.validateDate(assetXferDt)) {
					fwMessageList.addMessageToList(addMessageCode(ASSET_SOLD_DT_MSG_CD));
				} else if (!appMgr.futureDate(assetXferDt)) {
					fwMessageList.addMessageToList(addMessageCode(FUTURE_DATE));
				} else if (appMgr.isDateBeforeDate(assetXferDt, Date.valueOf(oneHundred20yearsAgo.toString()))) {
					fwMessageList.addMessageToList(addMessageCode(ASSET_SOLD_DT_MSG_CD));
				}
			}

			final Double valAmt = aCargo.getAsset_val_amt();
			if (valAmt == null) {
				fwMessageList.addMessageToList(addMessageCode(ASSET_SOLD_AMT_MSG_CD));
			} 

			if (valAmt != null && (((valAmt) > 9999999.99) || ((valAmt) < 0.0))) {
				
					fwMessageList.addMessageToList(addMessageCode(INVALID_SOLD_AMT_MSG_CD));
				
			}

			final Double assetXferAmt = aCargo.getAsset_xfer_amt();
			if (assetXferAmt == null) {
				fwMessageList.addMessageToList(addMessageCode(ASSET_XFER_AMT_MSG_CD));
			} 

			if (assetXferAmt != null && (((assetXferAmt) > 9999999.99) || ((assetXferAmt) < 0.0))) {
				
					fwMessageList.addMessageToList(addMessageCode(INVALID_AMT_RECEIVED_MSG_CD));
				
			}

			FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetBO.validateSoldAndTransferredAssetDetails() - END , Time Taken : " + (System.currentTimeMillis() - startTime)
					+ MILLI);
			return fwMessageList;
		} catch (final Exception e) {
			throw e;
		}

	}

	private void validateAssetType(final CP_APP_IN_ASET_XFER_Cargo aCargo, FwMessageList fwMessageList,
			StringBuilder oneHundred20yearsAgo) {
		try {
		final String assetType = aCargo.getAsset_type();
		if ((assetType != null) && ASSET_TYPE_DEFAULT_CD.equals(assetType.trim())) {
			fwMessageList.addMessageToList(addMessageCode(ASSET_TYPE_MSG_CD));
		}

		final String assetAcqDt = format.format(aCargo.getAsset_acq_dt());
		if (null!=(assetAcqDt)) {
			if (!appMgr.validateDate(assetAcqDt)) {
				fwMessageList.addMessageToList(addMessageCode(ASSET_ACQ_DT_MSG_CD));
			} else if (!appMgr.futureDate(assetAcqDt)) {
				fwMessageList.addMessageToList(addMessageCode(FUTURE_DATE));
			} else if (appMgr.isDateBeforeDate(assetAcqDt, Date.valueOf(oneHundred20yearsAgo.toString()))) {
				fwMessageList.addMessageToList(addMessageCode(ASSET_ACQ_DT_MSG_CD));
			}
		}
		} catch (final Exception e) {
			throw e;
		}
	}

	public APP_IN_LQD_ASET_Collection loadAccountSummarydetails(String appNum, List<Integer> indvIds) {

		logger.info( "LiquidAssetBO.loadgetAccountSummarydetails() - START");
		try {
			APP_IN_LQD_ASET_Collection appInColl; 
			
			appInColl = appInLqdAsetRepository.loadAccountSummarydetails(Integer.parseInt(appNum), indvIds);
			
			
			return appInColl;
		}  catch (final Exception e) {
			throw e;
		}
	}

	public CP_APP_IN_ASET_XFER_Collection loadAssetXferByAppNum(String appNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetBO.loadIndividualAssetXferDetails() - START");
		try {
			final CP_APP_IN_ASET_XFER_Collection appInColl = appInAsetXferRepository.loadAssetXferByAppNum(Integer.parseInt(appNum));
			FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetBO.loadIndividualAssetXferDetails() - END , Time Taken : " + (System.currentTimeMillis() - startTime)
					+ MILLI);
			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public CP_APP_IN_ASET_XFER_Collection loadAssetXferByAppNumForPR(String appNum,List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetBO.loadAssetXferByAppNumForPR() - START");
		try {
			final CP_APP_IN_ASET_XFER_Collection appInColl = appInAsetXferRepository.loadAssetXferByAppNumForPR(Integer.parseInt(appNum),indvIds);
			FwLogger.log(this.getClass(), Level.INFO, "LiquidAssetBO.loadAssetXferByAppNumForPR() - END , Time Taken : " + (System.currentTimeMillis() - startTime)
					+ MILLI);
			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	public void deleteLqdAsetCargo(APP_IN_LQD_ASET_Cargo existingCargo) {
		
		FwLogger.log(this.getClass(), Level.INFO,"ABOtherExpensesSummaryBO.deleteMedBillsCargo) - START");

		try {
			appInLqdAsetRepository.delete(existingCargo);
		}
		 catch (final Exception e) {
				FwLogger.log(this.getClass(), Level.ERROR, e.getMessage());
				throw e;
			}
		FwLogger.log(this.getClass(), Level.INFO, "ABOtherExpensesSummaryBO.deleteMedBillsCargo() - END");
	}
	
	
	public void storeAssetXferDetails(CP_APP_IN_ASET_XFER_Cargo assetInfoCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "liquidAssetBO.storeAssetXferDetails() - START");
		try{
			if(assetInfoCargo != null) {
				appInAsetXferRepository.save(assetInfoCargo);
			}		
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "liquidAssetBO.storeAssetXferDetails() - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) + MILLI);
	}
	
	
	public void deleteAssetInfo(CP_APP_IN_ASET_XFER_Cargo assetInfoCargo) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "liquidAssetBO.deleteAssetInfo() - START");
		try{
			if(assetInfoCargo != null) {
				appInAsetXferRepository.delete(assetInfoCargo);
			}		
		}catch (final Exception e) {
	          FwLogger.log(this.getClass(), FwLogger.Level.ERROR, e.getMessage());
	          throw e;
	      }
	      FwLogger.log(this.getClass(), FwLogger.Level.INFO, "liquidAssetBO.deleteAssetInfo() - END , Time Taken : "
	              + (System.currentTimeMillis() - startTime) + MILLI);
	}
}
