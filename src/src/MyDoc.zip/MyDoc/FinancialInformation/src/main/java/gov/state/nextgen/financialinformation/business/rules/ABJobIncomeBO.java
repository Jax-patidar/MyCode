package gov.state.nextgen.financialinformation.business.rules;


import java.util.List;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.AppConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.messages.FwMessageList;
import gov.state.nextgen.access.management.messages.FwMessageTextLabel;
import gov.state.nextgen.access.management.references.IReferenceTableManager;
import gov.state.nextgen.financialinformation.business.entities.APP_INDV_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_EMPL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_PRFL_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SELFE_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_UEI_Collection;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;

import gov.state.nextgen.financialinformation.data.db2.AppInEmplRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInPrflRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInSelfeRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInUieRepository;
import gov.state.nextgen.financialinformation.data.db2.CpAppSelfeRepository;
import javassist.runtime.Inner;

/**
 * Class contains validation methods, loads employee information, check cargo
 * completeness, and check component completeness
 *
 */
@Service("ABJobIncomeBO")
public class ABJobIncomeBO extends AbstractBO {
	
	@Autowired
	private IReferenceTableManager referenceTable;
	/**
	 * Constructor
	 */



	@Autowired
	private CpAppSelfeRepository cpAppSelfeRepository;
	
	private AppInPrflRepository appInPrflRepository;
	
	@Autowired
	private AppInEmplRepository appInEmplRepository;
	
	@Autowired
	private AppInSelfeRepository appInSelfeRepository;
	
	private static final String TEXTLABEL = "32227";
	private static final String GETUNEARNEDINCOMEEND = "ABJobIncomeBO.getUnearnedIncome() - END , Time Taken :";
	
	@Autowired
	private AppInUieRepository appInUieRepository;
	
	public APP_IN_SELFE_Collection loadIndividualSelfEmploymentDetails(
			final String appNumber, final Integer indv_seq_num, final Integer seq_num) {

	
	
	FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.loadIndividualSelfEmploymentDetails) - START");
	
	try {
		APP_IN_SELFE_Collection appInColl = new APP_IN_SELFE_Collection();
		
		
		 if(appNumber != null && indv_seq_num != null &&  seq_num != null) {
             
			 appInColl = cpAppSelfeRepository.getEmploymentDetails(Integer.parseInt(appNumber), indv_seq_num, seq_num);
              }
		 
		

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.loadIndividualSelfEmploymentDetails - END , Time Taken : \"\r\n");
		
		return appInColl;
	}catch (final Exception e) {
		throw e;
	}
}
	
public APP_IN_SELFE_Collection getSelfEmploymentDetailsByAppNum(
			final String appNumber, List<Integer> indvIds) {

	
	FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.loadIndividualSelfEmploymentDetails) - START");
	
	try {
		APP_IN_SELFE_Collection appInColl = new APP_IN_SELFE_Collection();
		
		 if(appNumber != null) {
             
			 appInColl = cpAppSelfeRepository.getSelfEmploymentDetailsByAppNum(Integer.parseInt(appNumber), indvIds);
              }
		

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.loadIndividualSelfEmploymentDetails - END , Time Taken : \"\r\n");
		
		return appInColl;
	} catch (final Exception e) {
		throw e;
	}
}	

    @SuppressWarnings("squid:S3776")
	public FwMessageList validateABSED(APP_IN_SELFE_Cargo selfEmpCargo, boolean incAmtEntered, boolean expAmtEntered) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.validateABSED) - START");
		
		try {
			
			FwMessageList messageList = new FwMessageList();

			final char[] specialChars = { '#', '/', '\'', '-', '(', ')', '@',
					'_', ',', '.', ' ' };

			String hours = null;
			if(null !=selfEmpCargo.getHr_work_mo_qty())
			hours=selfEmpCargo.getHr_work_mo_qty().toString();
			final int[] indicator = { 0 };

			if (appMgr.isFieldEmpty(selfEmpCargo.getSelf_empl_typ())) {
				addMessageCode("SE001");
			}

			if (!appMgr.isFieldEmpty(selfEmpCargo.getSelf_empl_bus_nam())) {
				final boolean specialAlphaNumeric = appMgr
						.isSpecialAlphaNumeric(
								selfEmpCargo.getSelf_empl_bus_nam(),
								specialChars);

				if (!specialAlphaNumeric) {
					addMessageCode("70001");
				}
			}

			if (appMgr.isFieldEmpty(selfEmpCargo.getSelf_empl_bus_nam())) {
				addMessageCode("70000");
			}
			// validate self_employment income amount
			if(selfEmpCargo.getAvg_incm_amt().toString() != null && Objects.nonNull(selfEmpCargo.getAvg_incm_ind())) 
			{
			validateAmount(selfEmpCargo.getAvg_incm_amt().toString(), "32226", incAmtEntered,
					indicator);
			}

			// validate hours entered

			
			if (hours != null && !hours.isEmpty()) {
				if (!appMgr.isInteger(hours)) {
					final Object[] error = new Object[] { new FwMessageTextLabel(
							TEXTLABEL) };
					this.addMessageWithFieldValues("10010", error);
				} else if (!appMgr.checkMaxAllowed(hours, 744)) {
					final Object[] error = new Object[] { new FwMessageTextLabel(
							TEXTLABEL) };
					this.addMessageWithFieldValues("20020", error);
				}

			}

			validateHoursEntered(hours);

			// validate expenses amount
			if(Objects.nonNull(selfEmpCargo.getExp_amt()) && selfEmpCargo.getExp_amt().toString() != null) {
				
			validateAmount(selfEmpCargo.getExp_amt().toString(), "32228", expAmtEntered,
					indicator);
			}
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.validateABSED - END , Time Taken : \"\r\n" + 
					"+ (System.currentTimeMillis() - startTime) ");
			
			return messageList;
			
		} catch (final Exception e) {
			throw e;
		}

		
		
	
		
	}

	/**
	 * @param selfEmpCargo
	 * @param hoursEntered
	 * @param hours
	 */
	
	private void validateHoursEntered(String hours) {
		try {
		if (hours != null && !hours.isEmpty()) {
			if (!appMgr.isInteger(hours)) {
				final Object[] error = new Object[] { new FwMessageTextLabel(
						TEXTLABEL) };
				this.addMessageWithFieldValues("10010", error);
			} else if (!appMgr.checkMaxAllowed(hours, 744)) {
				final Object[] error = new Object[] { new FwMessageTextLabel(
						TEXTLABEL) };
				this.addMessageWithFieldValues("20020", error);
			}

		}
		} catch (final Exception e) {
			throw e;
		}
	}

	
	public void validateAmount(final String howMuchAmount, final String msgLabel,
			final boolean amtEntered, final int[] indicator) {

		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.validateAmount) - START");
		try {
		if (howMuchAmount != null) {
			if (!appMgr.isCurrency(howMuchAmount)) {

				addMessageCode("80601");
			} else if (!appMgr.isValidAmountLimit(howMuchAmount)
					&& indicator[0] == 0) {
				addMessageCode("10034");
				indicator[0] = 1;

			}
		}
		} catch (final Exception e) {
			throw e;
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.validateAmount - END , Time Taken : \"\r\n" + 
				"+ (System.currentTimeMillis() - startTime) ");
	}



	public APP_IN_SELFE_Collection storeSelfEmploymentDetails(APP_IN_SELFE_Collection appInColl) {

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.storeSelfEmploymentDetails) - START");
		
		try {
						
			APP_IN_SELFE_Collection appInUpColl = new APP_IN_SELFE_Collection();
			APP_IN_SELFE_Cargo cargo;
			APP_IN_SELFE_Cargo resCargo;
			
			if (null!=appInColl && !appInColl.isEmpty()) {
				for(int i=0; i<appInColl.size();i++) {
					cargo = appInColl.getCargo(i);
					resCargo = cpAppSelfeRepository.save(cargo);
						appInUpColl.addCargo(resCargo);
				}
			}
			
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"ABEmploymentBO.storeEmplDetails() - END , Time Taken : \"\r\n");
			return appInUpColl;
		
		} catch (final Exception e) {
			throw e;
		}
		
	}


	

	// 
	public double calculateMFPL(int appInPrflCollectionSize) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.calculateMFPL() - START");
		
		Double mfplIncome = null;
		try {
			
			if (appInPrflCollectionSize > 0 && appInPrflCollectionSize <= 12) {
				mfplIncome = Double.parseDouble(referenceTable.getColumnValue("MFPL", 9833, Integer.toString(appInPrflCollectionSize), AppConstants.EN));
			} else {
				double mfplIncomeFor12 = Double.parseDouble(referenceTable.getColumnValue("MFPL", 9833, "12", AppConstants.EN));
				int moreThan12People = appInPrflCollectionSize - 12;
				mfplIncome = (857 * moreThan12People) + mfplIncomeFor12;
			}
			
			
			
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABJobIncomeBO.calculateMFPL() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						);
		return mfplIncome;
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * method to return APP_IN_PRFL'S in order to check  the field CURRENT_NEW_JOB_RESP
	 * @param appNum, indvSeqNum 
	 * 
	 ********************************************************************************************************************
	 */
	public APP_IN_PRFL_Cargo getApplicantPrfl(String appNum, int indvSeqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.getAppInPrfls() - START");
		APP_IN_PRFL_Cargo appInPrflCargo = new APP_IN_PRFL_Cargo();
		try {
			appInPrflCargo = appInPrflRepository.getAppInProfile(appNum, indvSeqNum);
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABJobIncomeBO.getAppInPrfls() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						);
		return appInPrflCargo;
	}


	/******************************************************************************************************************
	 * 
	 * 
	 * method to return APP_IN_EMPL_Collection 
	 * @param appNum 
	 * 
	 ********************************************************************************************************************
	 */
	public APP_IN_EMPL_Collection getAppInEmplCollection(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.getAppInEmplCollection() - START");
		APP_IN_EMPL_Collection appInEmplCollection = new APP_IN_EMPL_Collection();
		try {
			appInEmplCollection = appInEmplRepository.loadDetails(Integer.parseInt(appNum), indvIds);
		}catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABJobIncomeBO.getAppInEmplCollection() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						);
		return appInEmplCollection;
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * method to return APP_IN_SELFE_Collection 
	 * @param appNum 
	 * 
	 ********************************************************************************************************************
	 */
	public APP_IN_SELFE_Collection getAppInSelfEmplCollection(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.getAppInSelfEmplCollection() - START");
		APP_IN_SELFE_Collection appInSelfEmplCollection = new APP_IN_SELFE_Collection();
		try {
			appInSelfEmplCollection = appInSelfeRepository.loadSelfEmploymentDetails(Integer.parseInt(appNum), indvIds);
		}  catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABJobIncomeBO.getAppInSelfEmplCollection() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						);
		return appInSelfEmplCollection;
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * method to return APP_INDV_Collection 
	 * @param appNum 
	 * 
	 ********************************************************************************************************************
	 */
	public APP_INDV_Collection getAllIndividuals(String appNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.getAllIndividuals() - START");
		APP_INDV_Collection appIndvCollection = new APP_INDV_Collection();
		
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"ABJobIncomeBO.getAllIndividuals() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime)
						);
		return appIndvCollection;
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * method to return APP_IN_PRFL_Collection 
	 * @param appNum 
	 * 
	 ********************************************************************************************************************
	 */
	public APP_IN_PRFL_Collection getAppInPrflCollection(String appNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.getAppInPrflCollection() - START");
		try {
			APP_IN_PRFL_Collection appInPrflColl = new APP_IN_PRFL_Collection();
        	if(appNum != null) {
        		APP_IN_PRFL_Cargo[] appInPrflCargoArray  = appInPrflRepository.getPrflData(appNum);
        		if (appInPrflCargoArray.length > 0) {
        			appInPrflColl.setResults(appInPrflCargoArray);
        		}
        	}
        	
        	FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.getAppInPrflCollection() - END , Time Taken : "
                    + (System.currentTimeMillis() - startTime)
                    );
        	
    		return appInPrflColl;
		} catch (final Exception e) {
			throw e;
		}
	}

	/******************************************************************************************************************
	 * 
	 * 
	 * method to return APP_IN_UEI_Collection 
	 * @param appNum 
	 * 
	 ********************************************************************************************************************
	 */
	public APP_IN_UEI_Collection getUnearnedIncome(String appNum, List<Integer> indvIds) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.getUnearnedIncome() - START");
		APP_IN_UEI_Collection appInUEICollection = new APP_IN_UEI_Collection();
		try {
			appInUEICollection = appInUieRepository.loadOtherIncomeDetails(Integer.parseInt(appNum), indvIds);
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				GETUNEARNEDINCOMEEND
						+ (System.currentTimeMillis() - startTime)
						);
		return appInUEICollection;
	}
	

	/*
	 * Getting Unearned Details From the DB
	 */

	public APP_IN_UEI_Collection getUnearnedIncome4(String appNum , Integer indvSqnum , String ueiType) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.getUnearnedIncome() - START");
		APP_IN_UEI_Collection appInUEICollection = new APP_IN_UEI_Collection();
		try {
			appInUEICollection = appInUieRepository.loadUeiType(Integer.parseInt(appNum), indvSqnum , ueiType);
		} catch (final Exception e) {
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				GETUNEARNEDINCOMEEND
						+ (System.currentTimeMillis() - startTime)
						);
		return appInUEICollection;
	}
	
	public APP_IN_SELFE_Collection getSelfEmploymentDetails(String appNumber){
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.getSelfEmploymentDetails) - START");
		try {
			APP_IN_SELFE_Collection appInColl = new APP_IN_SELFE_Collection();			
			 if(appNumber != null) {	             
				 appInColl = cpAppSelfeRepository.getSelfEmploymentDetails(Integer.parseInt(appNumber));
	         } 
		   FwLogger.log(this.getClass(), FwLogger.Level.INFO, GETUNEARNEDINCOMEEND + (System.currentTimeMillis() - startTime)+ FinancialInfoConstants.MILLISECONDS);			
			return appInColl;
		} catch (final Exception e) {
			throw e;
		}
	}
	
	public APP_IN_SELFE_Collection getActiveSelfEmploymentDetails(String appNumber){
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,"ABJobIncomeBO.getSelfEmploymentDetails) - START");
		try {
			APP_IN_SELFE_Collection appInColl = new APP_IN_SELFE_Collection();			
			 if(appNumber != null) {	             
				 appInColl = cpAppSelfeRepository.getActiveSelfEmployments(Integer.parseInt(appNumber));
	         } 
		   FwLogger.log(this.getClass(), FwLogger.Level.INFO, GETUNEARNEDINCOMEEND + (System.currentTimeMillis() - startTime)+ FinancialInfoConstants.MILLISECONDS);			
			return appInColl;
		}  catch (final Exception e) {
			throw e;
		}
	}
	
	public APP_IN_SELFE_Collection getSelfEmplIncomeDetail(String appNumber, Integer indvSeqNum, Integer seqNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.getSelfEmplIncomeDetail) - START");
		APP_IN_SELFE_Collection appInColl = null;
		try {
			appInColl = cpAppSelfeRepository.getEmploymentDetails(Integer.parseInt(appNumber), indvSeqNum, seqNum);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "ABJobIncomeBO.getSelfEmplIncomeDetail"
					+ (System.currentTimeMillis() - startTime) + FinancialInfoConstants.MILLISECONDS);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR,
					"ABJobIncomeBO.getSelfEmplIncomeDetail " + e.getStackTrace());
		}
		return appInColl;
	}
}
