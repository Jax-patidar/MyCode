/*
 *
 */
package gov.state.nextgen.financialinformation.business.rules;

import org.springframework.stereotype.Service;

import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.financialinformation.business.entities.RMC_INDV_ID_Cargo;
import gov.state.nextgen.financialinformation.business.entities.RMC_INDV_ID_Collection;
import gov.state.nextgen.financialinformation.data.db2.RMCIndvIdRepository;

/**
 * Enter the description of the class
 *
 * @author nathsu Creation Date Jun 20, 2006 Modified By: Modified on: PCR#
 */

@Service("IndividualBO")
public class IndividualBO extends AbstractBO {

	private RMCIndvIdRepository idRepository;
	public RMC_INDV_ID_Collection getRmcIndvInfoForAppNum(final String appNumber) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "IndividualBO.getRmcIndvInfoForAppNum() - START");
		try {
			final RMC_INDV_ID_Collection appRmcIndvColl = idRepository.getRmcIndvInfoForAppNum(appNumber);

			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"IndividualBO.getRmcIndvInfoForAppNum() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");
			return appRmcIndvColl;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
	}

	public String getIndvSeqNumForPin(final RMC_INDV_ID_Collection rmcIndvColl,
			final Integer pinNum) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "IndividualBO.getIndvSeqNumForPin() - START");
		try {
			String indvSeqNum = null;
			final int rmcIndvSize = rmcIndvColl.size();
			RMC_INDV_ID_Cargo rmcIndvCargo = null;
			for (int i = 0; i < rmcIndvSize; i++) {
				rmcIndvCargo = rmcIndvColl.getCargo(i);
				if (rmcIndvCargo.getPin_num().equals(pinNum.toString())) {
					indvSeqNum = rmcIndvCargo.getIndv_seq_num();
					break;
				}
			}
			FwLogger.log(this.getClass(), FwLogger.Level.INFO,
					"IndividualBO.getIndvSeqNumForPin() - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");
			return indvSeqNum;
		} catch (final FwException fe) {
			throw fe;
		} catch (final Exception e) {
			throw e;
		}
	}

	

}
