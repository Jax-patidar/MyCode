/*
 *
 */
package gov.state.nextgen.financialinformation.business.rules;

import gov.state.nextgen.financialinformation.business.entities.NO_ONE_Cargo;
import gov.state.nextgen.financialinformation.business.entities.NO_ONE_Collection;
import gov.state.nextgen.financialinformation.business.entities.RMC_IN_PRFL_Cargo;
import gov.state.nextgen.financialinformation.business.entities.RMC_IN_PRFL_Collection;
import gov.state.nextgen.access.business.rules.AbstractBO;
import gov.state.nextgen.access.driver.FwPageManager;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.management.constants.FwConstants;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.access.management.logging.FwLogger.Level;
import gov.state.nextgen.access.management.messages.FwMessageList;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("ABMedicalTypeBO")
public class ABMedicalTypeBO extends AbstractBO {

	/**
	 * Constructor
	 */
	
	@Autowired
	private FwPageManager fwPageManager;
	
	


	public FwMessageList validateMedicalTypes(
			final RMC_IN_PRFL_Collection pageColl,
			final NO_ONE_Collection noOneColl,final String appType) {
		System.currentTimeMillis();
		FwMessageList fwMessageList=new FwMessageList();
		FwLogger.log(this.getClass(), Level.INFO, "ABMedicalTypeBO.validateMedicalType) - START");
		try {
			final int sizeRequest = pageColl.size();
			noOneColl.size();
			RMC_IN_PRFL_Cargo cargoRequest;
			NO_ONE_Cargo cargoNoOne;

			Integer indvSeqNum = null;
			String noOneName = null;
			String noOneValue = null;
			boolean aflag = false;

			for (int i = 0; i < sizeRequest; i++) {

				cargoRequest = (RMC_IN_PRFL_Cargo) pageColl.get(i);
				indvSeqNum = cargoRequest.getIndv_seq_num();
				cargoRequest.getMedtyp_hsa_contrib();
				cargoRequest.getMedtyp_dental();
				cargoRequest.getMedtyp_attendant_care();
				cargoRequest.getMedtyp_doctor();
				cargoRequest.getMedtyp_med_equip();
				cargoRequest.getMedtyp_hosp_bills();
				cargoRequest.getMedtyp_insur_premium();
				cargoRequest.getMedtyp_rx_cost();
				cargoRequest.getMedtyp_trans_med();
				cargoRequest.getMedtyp_other();

				cargoNoOne = noOneColl.getResult(i);
				noOneName = cargoNoOne.getNo_one_name();
				noOneValue = cargoNoOne.getNo_one_value();
				if (noOneName.equals(indvSeqNum.toString()) && (noOneValue != null
							&& !FwConstants.NO.equalsIgnoreCase(noOneValue)) && (cargoRequest != null
									&& (cargoRequest.getMedtyp_hsa_contrib() != null
									|| cargoRequest.getMedtyp_dental() != null
									|| cargoRequest
									.getMedtyp_attendant_care() != null
									|| cargoRequest.getMedtyp_doctor() != null
									|| cargoRequest.getMedtyp_med_equip() != null
									|| cargoRequest.getMedtyp_hosp_bills() != null
									|| cargoRequest
									.getMedtyp_insur_premium() != null
									|| cargoRequest.getMedtyp_rx_cost() != null
									|| cargoRequest.getMedtyp_trans_med() != null || cargoRequest
									.getMedtyp_other() != null))) {


					
							fwMessageList.addMessageToList(addMessageCode("00575"));
						

					

				}
				
				if ((appType.equalsIgnoreCase(String.valueOf(FwConstants.RMC_APP_TYPE)) || appType.equalsIgnoreCase(String.valueOf(FwConstants.RMB_APP_TYPE)) ) &&
						((cargoRequest.getMedtyp_hsa_contrib() == null) && (cargoRequest.getMedtyp_attendant_care() == null) && (cargoRequest.getMedtyp_dental() == null) 
								&& (cargoRequest.getMedtyp_doctor() == null)&& (cargoRequest.getMedtyp_med_equip() == null) 
								&& (cargoRequest.getMedtyp_hosp_bills() == null) && (cargoRequest.getMedtyp_insur_premium() == null)
								&& (cargoRequest.getMedtyp_rx_cost() == null) && (cargoRequest.getMedtyp_trans_med() == null)
								&& (cargoRequest.getMedtyp_other() == null) && (cargoRequest.getMedicare_part_a() == null)
								&& (cargoRequest.getMedicare_part_b() == null) && (cargoRequest.getMedicare_part_c() == null)
								&& (cargoRequest.getMedicare_part_d() == null)&& (cargoRequest.getCssp_provider_payment() == null)
								&& (cargoRequest.getAnimals_to_assist_disabled() == null)&& (cargoRequest.getFuneral_death_expense() == null)
								&& (cargoRequest.getBlind_work_expense() == null)&& (cargoRequest.getImpairment_work_expense() == null)
								&& (aflag == false))) {

					fwMessageList.addMessageToList(addMessageCode("9589"));
					
				}
			}

			return fwMessageList;

		} catch (final Exception e) {
			throw e;
		}
	}


	public RMC_IN_PRFL_Collection compareAppInPrflColl(
			final RMC_IN_PRFL_Collection appInPrflCollSession,
			final RMC_IN_PRFL_Collection pageColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABMedicalTypeBO.compareAppInPrflColl- START");
		try {
			final int pageCollSize = pageColl.size();
			final int sessionSize = appInPrflCollSession.size();
			RMC_IN_PRFL_Cargo beforeCargo = null;
			RMC_IN_PRFL_Cargo afterCargo = null;
			boolean found = false;
			final RMC_IN_PRFL_Collection appInPrflCollRequest = new RMC_IN_PRFL_Collection();
			for (int i = 0; i < sessionSize; i++) {
				found = false;
				beforeCargo = appInPrflCollSession.getCargo(i);
				for (int j = 0; j < pageCollSize; j++) {
					afterCargo = pageColl.getCargo(j);
					if (beforeCargo.getIndv_seq_num().equals(
							afterCargo.getIndv_seq_num())) {
						appInPrflCollRequest.add(afterCargo);
						found = true;
						break;
					}
				}
				if (!found) {
					afterCargo = new RMC_IN_PRFL_Cargo();
					afterCargo.setIndv_seq_num(beforeCargo.getIndv_seq_num());
					appInPrflCollRequest.add(afterCargo);
				}
			}
			FwLogger.log(this.getClass(), Level.INFO,
					"ABMedicalTypeBO.compareAppInPrflColl - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");
			return appInPrflCollRequest;

		} catch (final Exception e) {
			throw e;
		}

	}

	public NO_ONE_Collection compareNoOneCollection(
			final NO_ONE_Collection noOneBeforeColl,
			final NO_ONE_Collection noOneAfterColl) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), Level.INFO, "ABMedicalTypeBO.compareNoOneCollection- START");
		try {
			final int noOneBeforeSize = noOneBeforeColl.size();
			final int noOneAfterCollSize = noOneAfterColl.size();
			String noOneBeforeName = null;
			String noOneBeforeValue = null;
			String noOneAfterName = null;
			final NO_ONE_Collection newNoOneColl = new NO_ONE_Collection();
			NO_ONE_Cargo beforeNoOneCargo;
			NO_ONE_Cargo afterNoOneCargo;
			boolean found = false;

			for (int i = 0; i < noOneBeforeSize; i++) {
				found = false;
				beforeNoOneCargo = noOneBeforeColl.getResult(i);
				noOneBeforeName = beforeNoOneCargo.getNo_one_name();
				noOneBeforeValue = beforeNoOneCargo.getNo_one_value();

				for (int j = 0; j < noOneAfterCollSize; j++) {
					afterNoOneCargo = noOneAfterColl.getResult(j);
					noOneAfterName = afterNoOneCargo.getNo_one_name();
					if (noOneBeforeName.equals(noOneAfterName)) {
						newNoOneColl.add(afterNoOneCargo);
						found = true;
						break;
					}
				}
				if (!found) {
					afterNoOneCargo = new NO_ONE_Cargo();
					afterNoOneCargo.setNo_one_name(noOneBeforeName);
					afterNoOneCargo.setNo_one_value(noOneBeforeValue);
					newNoOneColl.add(afterNoOneCargo);

				}
			}
			FwLogger.log(this.getClass(), Level.INFO,
					"ABMedicalTypeBO.compareNoOneCollection - END , Time Taken : "
							+ (System.currentTimeMillis() - startTime)
							+ " milliseconds");
			return newNoOneColl;

		} catch (final Exception e) {
			throw e;
		}

	}

}
