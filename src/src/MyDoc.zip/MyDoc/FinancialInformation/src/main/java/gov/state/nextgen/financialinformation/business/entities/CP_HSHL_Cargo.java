package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;

@Entity
@IdClass(CP_HSHL_Id.class)
@Table(name = "CP_HSHL")
public class CP_HSHL_Cargo extends AbstractCargo implements Serializable {

	@Transient
	private static final long serialVersionUID = 1L;

	@Id
	private Integer hshl_id;
	
	private Integer child_ct;
	
	private String county_num;
	
	private String heat_bill_flag;
	
	private Integer person_ct;
	
	private String trb_cd;
	
	private String tanf_rcv_sw;
	
	private String guardian_present_sw;
	
	private String cooling_bill_flag;

	/**
	 * @return the hshl_id
	 */
	public Integer getHshl_id() {
		return hshl_id;
	}

	/**
	 * @param hshl_id the hshl_id to set
	 */
	public void setHshl_id(Integer hshl_id) {
		this.hshl_id = hshl_id;
	}

	/**
	 * @return the child_ct
	 */
	public Integer getChild_ct() {
		return child_ct;
	}

	/**
	 * @param child_ct the child_ct to set
	 */
	public void setChild_ct(Integer child_ct) {
		this.child_ct = child_ct;
	}

	/**
	 * @return the county_num
	 */
	public String getCounty_num() {
		return county_num;
	}

	/**
	 * @param county_num the county_num to set
	 */
	public void setCounty_num(String county_num) {
		this.county_num = county_num;
	}

	/**
	 * @return the heat_bill_flag
	 */
	public String getHeat_bill_flag() {
		return heat_bill_flag;
	}

	/**
	 * @param heat_bill_flag the heat_bill_flag to set
	 */
	public void setHeat_bill_flag(String heat_bill_flag) {
		this.heat_bill_flag = heat_bill_flag;
	}

	/**
	 * @return the person_ct
	 */
	public Integer getPerson_ct() {
		return person_ct;
	}

	/**
	 * @param person_ct the person_ct to set
	 */
	public void setPerson_ct(Integer person_ct) {
		this.person_ct = person_ct;
	}

	/**
	 * @return the trb_cd
	 */
	public String getTrb_cd() {
		return trb_cd;
	}

	/**
	 * @param trb_cd the trb_cd to set
	 */
	public void setTrb_cd(String trb_cd) {
		this.trb_cd = trb_cd;
	}

	/**
	 * @return the tanf_rcv_sw
	 */
	public String getTanf_rcv_sw() {
		return tanf_rcv_sw;
	}

	/**
	 * @param tanf_rcv_sw the tanf_rcv_sw to set
	 */
	public void setTanf_rcv_sw(String tanf_rcv_sw) {
		this.tanf_rcv_sw = tanf_rcv_sw;
	}

	/**
	 * @return the guardian_present_sw
	 */
	public String getGuardian_present_sw() {
		return guardian_present_sw;
	}

	/**
	 * @param guardian_present_sw the guardian_present_sw to set
	 */
	public void setGuardian_present_sw(String guardian_present_sw) {
		this.guardian_present_sw = guardian_present_sw;
	}

	/**
	 * @return the cooling_bill_flag
	 */
	public String getCooling_bill_flag() {
		return cooling_bill_flag;
	}

	/**
	 * @param cooling_bill_flag the cooling_bill_flag to set
	 */
	public void setCooling_bill_flag(String cooling_bill_flag) {
		this.cooling_bill_flag = cooling_bill_flag;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((child_ct == null) ? 0 : child_ct.hashCode());
		result = prime * result + ((cooling_bill_flag == null) ? 0 : cooling_bill_flag.hashCode());
		result = prime * result + ((county_num == null) ? 0 : county_num.hashCode());
		result = prime * result + ((guardian_present_sw == null) ? 0 : guardian_present_sw.hashCode());
		result = prime * result + ((heat_bill_flag == null) ? 0 : heat_bill_flag.hashCode());
		result = prime * result + ((hshl_id == null) ? 0 : hshl_id.hashCode());
		result = prime * result + ((person_ct == null) ? 0 : person_ct.hashCode());
		result = prime * result + ((tanf_rcv_sw == null) ? 0 : tanf_rcv_sw.hashCode());
		result = prime * result + ((trb_cd == null) ? 0 : trb_cd.hashCode());
		return result;
	}

		
	
	

}