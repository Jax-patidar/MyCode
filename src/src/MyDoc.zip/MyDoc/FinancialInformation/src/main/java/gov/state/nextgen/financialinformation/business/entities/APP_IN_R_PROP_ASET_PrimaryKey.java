/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;


/**
 * This java bean contains the primary keys for the table APP_IN_R_PROP_ASET
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Tue Mar 13 16:05:47 CST 2007 Modified By: Modified on: PCR#
 */
public class APP_IN_R_PROP_ASET_PrimaryKey implements java.io.Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private Integer app_number;
	private Integer indv_seq_num;
	private Integer seq_num;

	

	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	public Integer getApp_number() {
		return app_number;
	}

	public void setApp_number(Integer app_number) {
		this.app_number = app_number;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		APP_IN_R_PROP_ASET_PrimaryKey other = (APP_IN_R_PROP_ASET_PrimaryKey) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		if (seq_num == null) {
			if (other.seq_num != null)
				return false;
		} else if (!seq_num.equals(other.seq_num))
			return false;
		return true;
	}

	

}