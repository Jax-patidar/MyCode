package gov.state.nextgen.financialinformation.business.entities;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import gov.state.nextgen.access.business.entities.AbstractCargo;


public class CP_APP_IN_LST_HLTH_INS_Cargo extends AbstractCargo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String app_num;
	
	private Integer indv_seq_num;
	
	private Integer seq_num;
	
	private String src_app_ind;
	/**
	 * @author maheshr
	 */
	
	private String lost_hlt_ins_name;
	private String lost_hlt_ins_rsn_desc;
	

	
	public String getLost_hlt_ins_name() {
		return lost_hlt_ins_name;
	}
	public void setLost_hlt_ins_name(String lost_hlt_ins_name) {
		this.lost_hlt_ins_name = lost_hlt_ins_name;
	}
	public String getLost_hlt_ins_rsn_desc() {
		return lost_hlt_ins_rsn_desc;
	}
	public void setLost_hlt_ins_rsn_desc(String lost_hlt_ins_rsn_desc) {
		this.lost_hlt_ins_rsn_desc = lost_hlt_ins_rsn_desc;
	}
	/**
	 * @author maheshr
	 */
	
	private Date lst_dy_hlth_dt;
	
	private Date end_date;
	
	private Date chg_dt;
	
	private String fst_name;
	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return app_num;
	}
	/**
	 * @param app_num the app_num to set
	 */
	public void setApp_num(String app_num) {
		this.app_num = app_num;
	}
	/**
	 * @return the indv_seq_num
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}
	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}
	/**
	 * @return the seq_num
	 */
	public Integer getSeq_num() {
		return seq_num;
	}
	/**
	 * @param seq_num the seq_num to set
	 */
	public void setSeq_num(Integer seq_num) {
		this.seq_num = seq_num;
	}
	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}
	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}
	/**
	 * @return the lst_dy_hlth_dt
	 */
	public Date getLst_dy_hlth_dt() {
		return lst_dy_hlth_dt;
	}
	/**
	 * @param lst_dy_hlth_dt the lst_dy_hlth_dt to set
	 */
	public void setLst_dy_hlth_dt(Date lst_dy_hlth_dt) {
		this.lst_dy_hlth_dt = lst_dy_hlth_dt;
	}
	/**
	 * @return the end_date
	 */
	public Date getEnd_date() {
		return end_date;
	}
	/**
	 * @param end_date the end_date to set
	 */
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}
	/**
	 * @return the chg_dt
	 */
	public Date getChg_dt() {
		return chg_dt;
	}
	/**
	 * @param chg_dt the chg_dt to set
	 */
	public void setChg_dt(Date chg_dt) {
		this.chg_dt = chg_dt;
	}
	/**
	 * @return the fst_name
	 */
	public String getFst_name() {
		return fst_name;
	}
	/**
	 * @param fst_name the fst_name to set
	 */
	public void setFst_name(String fst_name) {
		this.fst_name = fst_name;
	}
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((chg_dt == null) ? 0 : chg_dt.hashCode());
		result = prime * result + ((end_date == null) ? 0 : end_date.hashCode());
		result = prime * result + ((fst_name == null) ? 0 : fst_name.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((lst_dy_hlth_dt == null) ? 0 : lst_dy_hlth_dt.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}
	
}
