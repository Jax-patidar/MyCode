package gov.state.nextgen.financialinformation.business.entities;


import java.io.Serializable;

public class APP_RGST_Key implements Serializable{

	private static final long serialVersionUID = -7406706786506800734L;

	private String app_num;

	private String src_app_ind;

	public APP_RGST_Key(String app_num, String src_app_ind) {
		super();
		this.app_num = app_num;
		this.src_app_ind = src_app_ind;
	}

	public APP_RGST_Key() {

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}

	
	
	
}
