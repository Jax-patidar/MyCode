/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class acts as a wrapper for one or many cargos of APP_IN_R_PROP_ASET
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Tue Mar 13 16:05:47 CST 2007 Modified By: Modified on: PCR#
 */
public class APP_IN_R_PROP_ASET_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.APP_IN_R_PROP_ASET";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final APP_IN_R_PROP_ASET_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final APP_IN_R_PROP_ASET_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final APP_IN_R_PROP_ASET_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public APP_IN_R_PROP_ASET_Cargo[] getResults() {
		final APP_IN_R_PROP_ASET_Cargo[] cbArray = new APP_IN_R_PROP_ASET_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public APP_IN_R_PROP_ASET_Cargo getCargo(final int idx) {
		return (APP_IN_R_PROP_ASET_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public APP_IN_R_PROP_ASET_Cargo[] cloneResults() {
		final APP_IN_R_PROP_ASET_Cargo[] rescargo = new APP_IN_R_PROP_ASET_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final APP_IN_R_PROP_ASET_Cargo cargo = getCargo(i);
			rescargo[i] = new APP_IN_R_PROP_ASET_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setEcp_id(cargo.getEcp_id());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setSeq_num(cargo.getSeq_num());
			rescargo[i].setIntn_ret_sw(cargo.getIntn_ret_sw());
			rescargo[i].setJnt_own_resp(cargo.getJnt_own_resp());
			rescargo[i].setProp_adr_ind(cargo.getProp_adr_ind());
			rescargo[i].setProp_city_adr(cargo.getProp_city_adr());
			rescargo[i].setProp_fmv_amt(cargo.getProp_fmv_amt());
			rescargo[i].setProp_fmv_amt_ind(cargo.getProp_fmv_amt_ind());
			rescargo[i].setProp_l1_adr(cargo.getProp_l1_adr());
			rescargo[i].setProp_l2_adr(cargo.getProp_l2_adr());
			rescargo[i].setProp_owe_amt(cargo.getProp_owe_amt());
			rescargo[i].setProp_owe_amt_ind(cargo.getProp_owe_amt_ind());
			rescargo[i].setProp_sta_adr(cargo.getProp_sta_adr());
			rescargo[i].setProp_zip_adr(cargo.getProp_zip_adr());
			rescargo[i].setReal_prop_aset_typ(cargo.getReal_prop_aset_typ());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setRes_sw(cargo.getRes_sw());
			rescargo[i].setRlt_cd(cargo.getRlt_cd());
			rescargo[i].setSale_agr_sw(cargo.getSale_agr_sw());
			rescargo[i].setSps_live_sw(cargo.getSps_live_sw());
			rescargo[i].setProperty_change_ownership_ind(cargo.getProperty_change_ownership_ind());
			rescargo[i].setLoopingQuestion(cargo.getLoopingQuestion());
			rescargo[i].setAsset_end_dt(cargo.getAsset_end_dt());
			rescargo[i].setChg_dt(cargo.getChg_dt());
			rescargo[i].setHow_often_rent_paid(cargo.getHow_often_rent_paid());
			rescargo[i].setRent_amt(cargo.getRent_amt());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof APP_IN_R_PROP_ASET_Cargo[]) {
			final APP_IN_R_PROP_ASET_Cargo[] cbArray = (APP_IN_R_PROP_ASET_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}