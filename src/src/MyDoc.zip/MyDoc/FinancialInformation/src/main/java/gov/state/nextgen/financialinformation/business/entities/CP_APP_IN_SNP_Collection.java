package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class CP_APP_IN_SNP_Collection extends AbstractCollection {
	

	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.CP_APP_IN_SNP";


	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CP_APP_IN_SNP_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CP_APP_IN_SNP_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CP_APP_IN_SNP_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CP_APP_IN_SNP_Cargo[] getResults() {
		final CP_APP_IN_SNP_Cargo[] cbArray = new CP_APP_IN_SNP_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CP_APP_IN_SNP_Cargo getCargo(final int idx) {
		return (CP_APP_IN_SNP_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public CP_APP_IN_SNP_Cargo[] cloneResults() {
		final CP_APP_IN_SNP_Cargo[] rescargo = new CP_APP_IN_SNP_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_APP_IN_SNP_Cargo cargo = getCargo(i);
			rescargo[i] = new CP_APP_IN_SNP_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setSpecial_needs_resp(cargo.getSpecial_needs_resp());
			rescargo[i].setSpecial_needs_desc(cargo.getSpecial_needs_desc());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_APP_IN_SNP_Cargo[]) {
			final CP_APP_IN_SNP_Cargo[] cbArray = (CP_APP_IN_SNP_Cargo[]) obj;
			setResults(cbArray);
		}
	}

	// NextGen NG-6481 Phase 3 updates to ACA Streamline changes : End

	public CP_APP_IN_SNP_Cargo getResult(final int idx) {
		return (CP_APP_IN_SNP_Cargo) get(idx);
	}

}
