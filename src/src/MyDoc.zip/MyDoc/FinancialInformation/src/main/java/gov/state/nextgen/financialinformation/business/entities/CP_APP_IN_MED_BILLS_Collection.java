package gov.state.nextgen.financialinformation.business.entities;
/*
 * 
 */

import gov.state.nextgen.access.business.entities.AbstractCollection;

/**
 * This class acts as a wrapper for one or many cargos of CP_APP_IN_MED_BILLS
 *
 * @author Deloitte
 * Creation Date Modified By: Modified on: PCR#
 */
public class CP_APP_IN_MED_BILLS_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.CP_APP_IN_MED_BILLS";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CP_APP_IN_MED_BILLS_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Returns a particular cargo.
	 *
	 * Creation Date Mon Jan 23 13:28:44 CST 2006
	 * @return gov.state.nextgen.access.business.entities.APP_IN_DC_E_Collection
	 */
	public CP_APP_IN_MED_BILLS_Cargo getResult(final int idx) {
		return (CP_APP_IN_MED_BILLS_Cargo) get(idx);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CP_APP_IN_MED_BILLS_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CP_APP_IN_MED_BILLS_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CP_APP_IN_MED_BILLS_Cargo[] getResults() {
		final CP_APP_IN_MED_BILLS_Cargo[] cbArray = new CP_APP_IN_MED_BILLS_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CP_APP_IN_MED_BILLS_Cargo getCargo(final int idx) {
		return (CP_APP_IN_MED_BILLS_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public CP_APP_IN_MED_BILLS_Cargo[] cloneResults() {
		final CP_APP_IN_MED_BILLS_Cargo[] rescargo = new CP_APP_IN_MED_BILLS_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_APP_IN_MED_BILLS_Cargo cargo = getCargo(i);
			rescargo[i] = new CP_APP_IN_MED_BILLS_Cargo();
			rescargo[i].setApp_num(cargo.getApp_num());
			rescargo[i].setIndv_seq_num(cargo.getIndv_seq_num());
			rescargo[i].setMedical_seq_num(cargo.getMedical_seq_num());
			rescargo[i].setMed_bill_type(cargo.getMed_bill_type());
			rescargo[i].setPymnt_amnt(cargo.getPymnt_amnt());
			rescargo[i].setPay_freq(cargo.getPay_freq());
			rescargo[i].setRec_cplt_ind(cargo.getRec_cplt_ind());
			rescargo[i].setMedical_bill_end_dt(cargo.getMedical_bill_end_dt());
			rescargo[i].setSrc_app_ind(cargo.getSrc_app_ind());
			rescargo[i].setAdapt_record_id(cargo.getAdapt_record_id());
			rescargo[i].setRowAction(cargo.getRowAction());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setChange_dt(cargo.getChange_dt());
			rescargo[i].setMa_backdt_mo_1_ind(cargo.getMa_backdt_mo_1_ind());
			rescargo[i].setMa_backdt_mo_2_ind(cargo.getMa_backdt_mo_2_ind());
			rescargo[i].setMa_backdt_mo_3_ind(cargo.getMa_backdt_mo_3_ind());
			rescargo[i].setDirty(cargo.isDirty());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_APP_IN_MED_BILLS_Cargo[]) {
			final CP_APP_IN_MED_BILLS_Cargo[] cbArray = (CP_APP_IN_MED_BILLS_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}