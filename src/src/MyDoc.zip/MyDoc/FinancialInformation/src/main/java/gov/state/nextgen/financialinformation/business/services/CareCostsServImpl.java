/**
 * 
 */
package gov.state.nextgen.financialinformation.business.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.amazonaws.util.CollectionUtils;

import gov.state.nextgen.access.business.entities.FwTransaction;
import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.access.exceptions.FwExceptionManager;
import gov.state.nextgen.access.management.logging.FwLogger;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_DC_E_LIST_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_DC_E_LIST_Collection;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Cargo;
import gov.state.nextgen.financialinformation.business.entities.CP_ABCHS_Collection;
import gov.state.nextgen.financialinformation.business.rules.CareCostBO;
import gov.state.nextgen.financialinformation.constants.FinancialInfoConstants;
import gov.state.nextgen.framework.business.model.IndividualCategorySequenceDetails;

/**
 * @author KumariK
 *
 */
@SuppressWarnings("squid:S2229")
@Service("CareCostsService")
public class CareCostsServImpl implements FinancialServInterface {

	@Autowired
	private CareCostBO careCostBO;


	/**
	 * To call specific business method of the same bean
	 */
	@Override
	public void callBusinessLogic(String methodName, FwTransaction fwTxn) {

		switch (methodName) {
		case FinancialInfoConstants.STORE_CARE_COST_INFO:
			this.storeCareCostInformation(fwTxn);
			break;
		case FinancialInfoConstants.LOAD_CARE_COST_SUMM_INFO:
			this.loadCareCostSummaryInformation(fwTxn);
			break;
		case FinancialInfoConstants.DELETE_CARE_COST_INFO:
			this.deleteCareCostInformation(fwTxn);
			break;
		case FinancialInfoConstants.STOREPRCARECOSTINFORMATION:
			this.storePRCareCostInformation(fwTxn);
			break;
		case FinancialInfoConstants.LOADDEPENDENTSTUB:
			this.loadDependentStub(fwTxn);
			break;
		default:
			break;

		}
	}

	@Transactional
	public void deleteCareCostInformation(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostsService.deleteCareCostInformation() - START", fwTxn);
		try {

			String appNumber = fwTxn.getUserDetails().getAppNumber();

			String src_ind = FinancialInfoConstants.SRC_AB;
			String req_seqNum = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getCategorySequence();
			String req_indvSeqNum = fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
					.getIndividualSequence();
			Integer seq_num = 0;
			Integer zero = 0;
			Integer indv_seq_num = 0;
			if (null != req_seqNum && !("".equalsIgnoreCase(req_seqNum))) {
				seq_num = Integer.parseInt(req_seqNum);
			}
			if (null != req_indvSeqNum && !("".equalsIgnoreCase(req_indvSeqNum))) {
				indv_seq_num = Integer.parseInt(req_indvSeqNum);
			}

			if (!(seq_num.equals(zero) && indv_seq_num.equals(zero))) {

				CP_ABCHS_Collection beforeCareCostColl = careCostBO.loadIndvCareCostData(appNumber, indv_seq_num,
						src_ind, seq_num);
				if (null != beforeCareCostColl && !beforeCareCostColl.isEmpty()) {

					CP_ABCHS_Cargo beforeCargo = beforeCareCostColl.getCargo(0);
					if (Objects.nonNull(beforeCargo)) {
						careCostBO.deleteCareCostData(beforeCargo);
						careCostBO.deleteDependentStubsForDependentCareExpense(appNumber, indv_seq_num, seq_num);
					}
				}

			}

		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, fe.getMessage());
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.DELETE_CARE_COST_INFO, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in CareCostsServImpl.deleteCareCostInformation()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(),
					FinancialInfoConstants.DELETE_CARE_COST_INFO, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}

		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"CareCostsService.deleteCareCostInformation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	@Transactional
	public void loadCareCostSummaryInformation(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostsService.loadCareCostSummaryInformation() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			String src_ind = FinancialInfoConstants.SRC_AB;
			List<Integer> indvIdList = new ArrayList<Integer>();
			ArrayList<String> indvIds = (ArrayList<String>) pageCollection.get("indvIds");
			if (!CollectionUtils.isNullOrEmpty(indvIds)) {
				indvIdList = indvIds.stream().filter(StringUtils::isNotEmpty).map(Integer::valueOf)
						.collect(Collectors.toList());
			}

			CP_ABCHS_Collection careCostColl = careCostBO.loadCareCostData(appNumber, src_ind, indvIdList);
			CP_ABCHS_Collection newColl = new CP_ABCHS_Collection();
			if (null != careCostColl && !careCostColl.isEmpty()) {
				for (int i = 0; i < careCostColl.size(); i++) {
					Double amount = 0.0;
					CP_ABCHS_Cargo careCostCargo = careCostColl.getCargo(i);
					if (careCostCargo.getJnt_amt_paid() != null) {
						amount = amount + careCostCargo.getJnt_amt_paid();
					}
					if (careCostCargo.getDpnd_care_exp_amt() != null) {
						amount = amount + careCostCargo.getDpnd_care_exp_amt();
					}
					careCostCargo.setTotalAmount(amount);
					careCostCargo.setFrequency(careCostCargo.getPay_freq());
					newColl.addCargo(careCostCargo);
				}
			} else {
				newColl = null;
			}

			pageCollection.put(FinancialInfoConstants.CP_ABCHS_COLL, newColl);

			fwTxn.setPageCollection(pageCollection);

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in CareCostsServImpl.loadCareCostSummaryInformation()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.LOAD_CARE_COST_SUMM_INFO, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"CareCostsService.loadCareCostSummaryInformation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);
	}

	@Transactional
	public void storeCareCostInformation(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostsService.storeCareCostInformation() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			String pageId = fwTxn.getCurrentActionDetails().getPageId();

			String srcInd = FinancialInfoConstants.SRC_AB;
			Integer seqNum = null;
			Integer indvSeqNum = null;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			CP_ABCHS_Collection careCostColl = (CP_ABCHS_Collection) pageCollection.get("CP_ABCHS_Collection");

			List<Integer> indvIdList = new ArrayList<>();
			indvIdList.add(indvSeqNum);
			final CP_ABCHS_Collection existingCarecostExpColl = careCostBO.loadCareCostData(appNumber, srcInd,
					indvIdList);

			CP_ABCHS_Cargo careCostCargo;
			if (null != careCostColl && !careCostColl.isEmpty()) {

				careCostCargo = careCostColl.getCargo(0);
				if (null != existingCarecostExpColl && !existingCarecostExpColl.isEmpty()) {
					CP_ABCHS_Cargo dBCargo = existingCarecostExpColl.getCargo(0);
					updateCareCostInformation(dBCargo, careCostCargo);
				} else {
					careCostCargo.setApp_num(appNumber);
					careCostCargo.setSrc_app_ind(srcInd);
					careCostCargo.setIndv_seq_num(indvSeqNum);
					careCostCargo.setSeq_num(seqNum);

					careCostCargo.setChg_dt(careCostCargo.getChg_dt());

					if (pageId.equals("ABPCB")) {
						careCostCargo.setJnt_payee_first_name(null);
						careCostCargo.setJnt_payee_last_name(null);
						careCostCargo.setJnt_amt_paid(null);
						careCostCargo.setJnt_payee_pay_freq(null);
					}
					careCostBO.storeCareCostData(careCostCargo);
				}

			}

		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in CareCostsService.storeCareCostInformation()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.STORE_CARE_COST_INFO, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"CareCostsService.storeCareCostInformation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime), fwTxn);

	}

	public void updateCareCostInformation(CP_ABCHS_Cargo dBCargo, CP_ABCHS_Cargo rcvdCareCostCargo) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostsService.updateCareCostInformation() - START");
		try {
			dBCargo.setDep_care_pay_amt(rcvdCareCostCargo.getDep_care_pay_amt());

			dBCargo.setDpnd_care_exp_amt(rcvdCareCostCargo.getDpnd_care_exp_amt());

			if (Objects.nonNull(rcvdCareCostCargo.getPay_freq())) {
				dBCargo.setPay_freq(rcvdCareCostCargo.getPay_freq());
			}
			if (Objects.nonNull(rcvdCareCostCargo.getPrvd_org_nam())) {
				dBCargo.setPrvd_org_nam(rcvdCareCostCargo.getPrvd_org_nam());
			}

			if (Objects.nonNull(rcvdCareCostCargo.getPrvd_addr_line1())) {
				dBCargo.setPrvd_addr_line1(rcvdCareCostCargo.getPrvd_addr_line1());
			}

			if (Objects.nonNull(rcvdCareCostCargo.getPrvd_addr_city())) {
				dBCargo.setPrvd_addr_city(rcvdCareCostCargo.getPrvd_addr_city());
			}

			if (Objects.nonNull(rcvdCareCostCargo.getPrvd_address_state_cd())) {
				dBCargo.setPrvd_address_state_cd(rcvdCareCostCargo.getPrvd_address_state_cd());
			}

			if (Objects.nonNull(rcvdCareCostCargo.getPrvd_address_state_cd())) {
				dBCargo.setPrvd_address_state_cd(rcvdCareCostCargo.getPrvd_address_state_cd());
			}

			if (Objects.nonNull(rcvdCareCostCargo.getPrvd_addr_zip())) {
				dBCargo.setPrvd_addr_zip(rcvdCareCostCargo.getPrvd_addr_zip());
			}

			if (Objects.nonNull(rcvdCareCostCargo.getJnt_pay_resp())) {
				dBCargo.setJnt_pay_resp(rcvdCareCostCargo.getJnt_pay_resp());
			}

			if (Objects.nonNull(rcvdCareCostCargo.getJnt_payee_first_name())) {
				dBCargo.setJnt_payee_first_name(rcvdCareCostCargo.getJnt_payee_first_name());
			}

			if (Objects.nonNull(rcvdCareCostCargo.getJnt_payee_last_name())) {
				dBCargo.setJnt_payee_last_name(rcvdCareCostCargo.getJnt_payee_last_name());
			}

			dBCargo.setJnt_amt_paid(rcvdCareCostCargo.getJnt_amt_paid());

			dBCargo.setChg_dt(rcvdCareCostCargo.getChg_dt());

			careCostBO.storeCareCostData(dBCargo);

		} catch (final FwException fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in CareCostsServImpl.updateCareCostInformation()");
			throw fe;
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in CareCostsServImpl.updateCareCostInformation()");
			throw e;
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostsService.updateCareCostInformation() - END");

	}

	public void storePRCareCostInformation(FwTransaction fwTxn) {
		final long startTime = System.currentTimeMillis();
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "CareCostsService.storePRCareCostInformation() - START", fwTxn);
		try {
			Map pageCollection = fwTxn.getPageCollection();
			String appNumber = fwTxn.getUserDetails().getAppNumber();
			Integer seqNum = null;
			Integer indvSeqNum = null;
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getIndividualSequence())) {
				indvSeqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getIndividualSequence());
			}
			if (Objects.nonNull(fwTxn.getCurrentActionDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails())
					&& Objects.nonNull(fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails()
							.getCategorySequence())) {
				seqNum = Integer.parseInt(
						fwTxn.getCurrentActionDetails().getIndividualCategorySequenceDetails().getCategorySequence());
			}

			CP_ABCHS_Collection careCostColl = (CP_ABCHS_Collection) pageCollection.get("CP_ABCHS_Collection");
			storeCareCostInformation(fwTxn);

			if (null != careCostColl && !careCostColl.isEmpty()) {
				Object item = pageCollection.get(FinancialInfoConstants.DEPENDENT_LIST_COLLECTION);
				//if DEPENDENT_LIST_COLLECTION is empty return empty arraylist otherwise returns collection
				if (item instanceof ArrayList) {
					careCostBO.deleteDependentStubsForDependentCareExpense(appNumber, indvSeqNum, seqNum);
				} else {
				APP_IN_DC_E_LIST_Collection dependentColl = (APP_IN_DC_E_LIST_Collection) pageCollection
						.get(FinancialInfoConstants.DEPENDENT_LIST_COLLECTION);
				if (Objects.nonNull(dependentColl) && !dependentColl.isEmpty()) {
					List<APP_IN_DC_E_LIST_Cargo> sortedPayStubList = careCostBO
							.getDependentStubListFromCollection(dependentColl, appNumber, indvSeqNum, seqNum);

					careCostBO.deleteDependentStubsForDependentCareExpense(appNumber, indvSeqNum, seqNum);
					careCostBO.insertDependentCareStubRecord(sortedPayStubList);

				}
			  }
			}
		} catch (final Exception fe) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in CareCostsServImpl.storePRCareCostInformation()", fwTxn);
			FwExceptionManager.handleException(fe, this.getClass().getName(),
					FinancialInfoConstants.STOREPRCARECOSTINFORMATION, fwTxn.getUserDetails().getAppNumber(),
					fwTxn.getUserDetails().getLoginUserId(), true);
		}
		FwLogger.log(this.getClass(), FwLogger.Level.INFO,
				"CareCostsService.storePRCareCostInformation() - END , Time Taken : "
						+ (System.currentTimeMillis() - startTime) + " milliseconds", fwTxn);

	}

	public void loadDependentStub(final FwTransaction fwTxn) {
		FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean.loadDependentStub() - START", fwTxn);
		try {
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::loadDependentStub:start");
			final String appNum = fwTxn.getUserDetails().getAppNumber();

			IndividualCategorySequenceDetails categorySequenceDetails = fwTxn.getCurrentActionDetails()
					.getIndividualCategorySequenceDetails();
			Integer indvSeq = Integer.parseInt(categorySequenceDetails.getIndividualSequence());
			Integer seqNum = Integer.parseInt(categorySequenceDetails.getCategorySequence());

			CP_ABCHS_Collection careCostColl = careCostBO.loadDependentCareCostData(appNum, indvSeq, seqNum);
			APP_IN_DC_E_LIST_Collection coll = careCostBO.fetchDependentCareStub(appNum, indvSeq, seqNum);
			Map pageCollection = new HashMap();
			if (Objects.nonNull(coll) && !coll.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.DEPENDENT_LIST_COLLECTION, coll);
			}
			if (Objects.nonNull(coll) && !coll.isEmpty()) {
				pageCollection.put(FinancialInfoConstants.CP_ABCHS_COLL, careCostColl);
			}

			fwTxn.setPageCollection(pageCollection);
			FwLogger.log(this.getClass(), FwLogger.Level.INFO, "JobIncomeEJBBean::loadDependentStub:End", fwTxn);
		} catch (final Exception e) {
			FwLogger.log(this.getClass(), FwLogger.Level.ERROR, "Error occured in CareCostsServImpl.loadDependentStub()", fwTxn);
			FwExceptionManager.handleException(e, this.getClass().getName(), FinancialInfoConstants.LOADDEPENDENTSTUB,
					fwTxn.getUserDetails().getAppNumber(), fwTxn.getUserDetails().getLoginUserId(), true);
		}
	}

}
