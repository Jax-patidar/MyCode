/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import gov.state.nextgen.access.business.entities.AbstractCargo;

/**
 * This java bean contains the entities of APP_IN_VEH_ASET
 *
 * @author CodeGenerator - Architecture Team
 * Creation Date Tue Feb 13 10:24:12 CST 2007 Modified By: Modified on: PCR#
 */

@Entity
@Table(name = "CP_APP_IN_VEH_ASSET")
@IdClass(APP_IN_VEH_ASET_PrimaryKey.class)
public class APP_IN_VEH_ASET_Cargo extends AbstractCargo implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	@Transient
	private String app_num;
	
	@Id
	@Column(name = "app_num")
	private int app_number;
	private String ecp_id;
	@Id
	private Integer indv_seq_num;
	@Id
	private Integer seq_num;
	private String jnt_own_resp;
	private String lic_plate_txt;
	private String lic_sta_cd;
	
	@Column(name="veh_fmv_amt")
   @JsonProperty("veh_fmv_amt") 
	private Double mv_fmv_amt;
	
	@Column(name="veh_fmv_amt_ind")
	@JsonProperty("veh_fmv_amt_ind")
	private Double mv_fmv_amt_ind;
	
	@Column(name="veh_make_txt")
	@JsonProperty("veh_make_txt")
	private String mv_make_txt;
	
	@Column(name="veh_modl_txt")
	@JsonProperty("veh_modl_txt")
	private String mv_modl_txt;
	
	@Column(name="veh_owe_amt")
	private Double mv_owe_amt;
	
	@Column(name="veh_owe_amt_ind")
	@JsonProperty("veh_owe_amt_ind")
	private Double mv_owe_amt_ind;
	
	@Column(name="veh_rgst_rqr_sw")
	@JsonProperty("veh_rgst_rqr_sw")
	private String mv_rgst_rqr_sw;
	
	@Column(name="veh_yr")
	@JsonProperty("veh_yr")
	private Integer mv_yr;
	
	
	private String rec_cplt_ind;
	@Id
	@Column(name="veh_asset_type")
	private String veh_aset_typ;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date asset_end_dt;
	
	@Column(name="motor_veh_desc")
	private String motor_vehicle_description;
	
	
	private String src_app_ind;
	
	@Column(name="veh_acquired_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date vehicle_acquired_dt;
	
	
	@Transient
	private Date chg_eff_dt;
	@Transient
	private String mv_use_1_cd;
	@Transient
	private String mv_use_2_cd;
	@Transient
	private String mv_use_3_cd;
	@Transient
	private String loopingQuestion;
	
	@Column(name="change_dt")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date chg_dt;
	
	private String adapt_record_id;
	
	private String veh_brw_ind;
	
	private String veh_find_value;
	
	private String veh_gift_how;
	
	private String veh_gift_ind;
	
	private String veh_used_by;
	
	private String how_it_is_used;
	
	private String leased_ind;
	
	@Transient
	private String[] how_it_is_usedarray;
	
	@Transient
	private String fst_nam;
	
	@Transient
	private String first_name;
	
	@Transient
	private String last_name;
	
	@Transient
	private String age;
	
	@Column(name = "veh_asset_calsaws_object")
	private String vehAssetCalsawsObject;
	
	@Column(name="vehicle_property_type_desc")
	private String vehicleandpropertytypeDesc;
	
	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String[] getHow_it_is_usedarray() {
		return how_it_is_usedarray;
	}

	public void setHow_it_is_usedarray(String[] how_it_is_usedarray) {
		this.how_it_is_usedarray = how_it_is_usedarray;
	}

	public String getFst_nam() {
		return fst_nam;
	}

	public void setFst_nam(String fst_nam) {
		this.fst_nam = fst_nam;
	}

	/**
     * @return the chg_dt
     */
    public Date getChg_dt() {
        return chg_dt;
    }

    /**
     * @param chg_dt the chg_dt to set
     */
    public void setChg_dt(Date chg_dt) {
        this.chg_dt = chg_dt;
    }


	/**
	 * @return the ecp_id
	 */
	public String getEcp_id() {
		return ecp_id;
	}

	/**
	 * @param ecp_id the ecp_id to set
	 */
	public void setEcp_id(final String ecp_id) {
		this.ecp_id = ecp_id;
	}

	public String getMv_use_1_cd() {
		return mv_use_1_cd;
	}

	public void setMv_use_1_cd(final String mv_use_1_cd) {
		this.mv_use_1_cd = mv_use_1_cd;
	}

	public String getMv_use_2_cd() {
		return mv_use_2_cd;
	}

	public void setMv_use_2_cd(final String mv_use_2_cd) {
		this.mv_use_2_cd = mv_use_2_cd;
	}

	public String getMv_use_3_cd() {
		return mv_use_3_cd;
	}

	public void setMv_use_3_cd(final String mv_use_3_cd) {
		this.mv_use_3_cd = mv_use_3_cd;
	}

	/**
	 * returns the chg_eff_dt value.
	 */
	public Date getChg_eff_dt() {
		return chg_eff_dt;
	}

	/**
	 * sets the chg_eff_dt value.
	 */
	public void setChg_eff_dt( Date chg_eff_dt) {
		this.chg_eff_dt = chg_eff_dt;
	}

	/**
	 * @return the asset_end_dt
	 */
	public Date getAsset_end_dt() {
		return asset_end_dt;
	}

	/**
	 * @param asset_end_dt
	 *            the asset_end_dt to set
	 */
	public void setAsset_end_dt(final Date asset_end_dt) {
		this.asset_end_dt = asset_end_dt;
	}

	/**
	 * @return the motor_vehicle_description
	 */
	public String getMotor_vehicle_description() {
		return motor_vehicle_description;
	}

	/**
	 * @param motor_vehicle_description
	 *            the motor_vehicle_description to set
	 */
	public void setMotor_vehicle_description(final String motor_vehicle_description) {
		this.motor_vehicle_description = motor_vehicle_description;
	}

	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * @param src_app_ind
	 *            the src_app_ind to set
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * @return the vehicle_acquired_dt
	 */
	public Date getVehicle_acquired_dt() {
		return vehicle_acquired_dt;
	}

	/**
	 * @param vehicle_acquired_dt
	 *            the vehicle_acquired_dt to set
	 */
	public void setVehicle_acquired_dt(final Date vehicle_acquired_dt) {
		this.vehicle_acquired_dt = vehicle_acquired_dt;
	}

	/**
	 * returns the app_num value.
	 */
	public String getApp_num() {
		return String.valueOf(app_number);
	}

	/**
	 * sets the app_num value.
	 */
	public void setApp_num(final String app_num) {
		this.app_number = Integer.parseInt(app_num);
	}

	public int getApp_number() {
		return app_number;
	}
	public void setApp_number(int app_number) {
		this.app_number = app_number;
		this.app_num = String.valueOf(app_number);
	}
	/**
	 * returns the indv_seq_num value.
	 */
	public Integer getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * sets the indv_seq_num value.
	 */
	public void setIndv_seq_num(final Integer indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * returns the seq_num value.
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * sets the seq_num value.
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * returns the jnt_own_resp value.
	 */
	public String getJnt_own_resp() {
		return jnt_own_resp;
	}

	/**
	 * sets the jnt_own_resp value.
	 */
	public void setJnt_own_resp(final String jnt_own_resp) {
		this.jnt_own_resp = jnt_own_resp;
	}

	/**
	 * returns the lic_plate_txt value.
	 */
	public String getLic_plate_txt() {
		return lic_plate_txt;
	}

	/**
	 * sets the lic_plate_txt value.
	 */
	public void setLic_plate_txt(final String lic_plate_txt) {
		this.lic_plate_txt = lic_plate_txt;
	}

	/**
	 * returns the lic_sta_cd value.
	 */
	public String getLic_sta_cd() {
		return lic_sta_cd;
	}

	/**
	 * sets the lic_sta_cd value.
	 */
	public void setLic_sta_cd(final String lic_sta_cd) {
		this.lic_sta_cd = lic_sta_cd;
	}

	/**
	 * returns the mv_fmv_amt value.
	 */
	public Double getMv_fmv_amt() {
		return mv_fmv_amt;
	}

	/**
	 * sets the mv_fmv_amt value.
	 */
	public void setMv_fmv_amt(final Double mv_fmv_amt) {
		this.mv_fmv_amt = mv_fmv_amt;
	}

	/**
	 * returns the mv_fmv_amt_ind value.
	 */
	public Double getMv_fmv_amt_ind() {
		return mv_fmv_amt_ind;
	}

	/**
	 * sets the mv_fmv_amt_ind value.
	 */
	public void setMv_fmv_amt_ind(final Double mv_fmv_amt_ind) {
		this.mv_fmv_amt_ind = mv_fmv_amt_ind;
	}

	/**
	 * returns the mv_make_txt value.
	 */
	public String getMv_make_txt() {
		return mv_make_txt;
	}

	/**
	 * sets the mv_make_txt value.
	 */
	public void setMv_make_txt(final String mv_make_txt) {
		this.mv_make_txt = mv_make_txt;
	}

	/**
	 * returns the mv_modl_txt value.
	 */
	public String getMv_modl_txt() {
		return mv_modl_txt;
	}

	/**
	 * sets the mv_modl_txt value.
	 */
	public void setMv_modl_txt(final String mv_modl_txt) {
		this.mv_modl_txt = mv_modl_txt;
	}

	/**
	 * returns the mv_owe_amt value.
	 */
	public Double getMv_owe_amt() {
		
		return mv_owe_amt;
	}

	/**
	 * sets the mv_owe_amt value.
	 */
	public void setMv_owe_amt(final Double mv_owe_amt) {
		this.mv_owe_amt = mv_owe_amt;
	}

	/**
	 * returns the mv_owe_amt_ind value.
	 */
	public Double getMv_owe_amt_ind() {
		return mv_owe_amt_ind;
	}

	/**
	 * sets the mv_owe_amt_ind value.
	 */
	public void setMv_owe_amt_ind(final Double mv_owe_amt_ind) {
		this.mv_owe_amt_ind = mv_owe_amt_ind;
	}

	/**
	 * returns the mv_rgst_rqr_sw value.
	 */
	public String getMv_rgst_rqr_sw() {
		return mv_rgst_rqr_sw;
	}

	/**
	 * sets the mv_rgst_rqr_sw value.
	 */
	public void setMv_rgst_rqr_sw(final String mv_rgst_rqr_sw) {
		this.mv_rgst_rqr_sw = mv_rgst_rqr_sw;
	}

	/**
	 * returns the mv_yr value.
	 */
	public Integer getMv_yr() {
		return mv_yr;
	}

	/**
	 * sets the mv_yr value.
	 */
	public void setMv_yr(final Integer mv_yr) {
		this.mv_yr = mv_yr;
	}

	/**
	 * returns the rec_cplt_ind value.
	 */
	public String getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * sets the rec_cplt_ind value.
	 */
	public void setRec_cplt_ind(final String rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * returns the veh_aset_typ value.
	 */
	public String getVeh_aset_typ() {
		return veh_aset_typ;
	}

	/**
	 * sets the veh_aset_typ value.
	 */
	public void setVeh_aset_typ(final String veh_aset_typ) {
		this.veh_aset_typ = veh_aset_typ;
	}


	/**
	 * @return the adapt_record_id
	 */
	public String getAdapt_record_id() {
		return adapt_record_id;
	}

	/**
	 * @param adapt_record_id the adapt_record_id to set
	 */
	public void setAdapt_record_id(String adapt_record_id) {
		this.adapt_record_id = adapt_record_id;
	}

	/**
	 * @return the veh_brw_ind
	 */
	public String getVeh_brw_ind() {
		return veh_brw_ind;
	}

	/**
	 * @param veh_brw_ind the veh_brw_ind to set
	 */
	public void setVeh_brw_ind(String veh_brw_ind) {
		this.veh_brw_ind = veh_brw_ind;
	}

	/**
	 * @return the veh_find_value
	 */
	public String getVeh_find_value() {
		return veh_find_value;
	}

	/**
	 * @param veh_find_value the veh_find_value to set
	 */
	public void setVeh_find_value(String veh_find_value) {
		this.veh_find_value = veh_find_value;
	}

	/**
	 * @return the veh_gift_how
	 */
	public String getVeh_gift_how() {
		return veh_gift_how;
	}

	/**
	 * @param veh_gift_how the veh_gift_how to set
	 */
	public void setVeh_gift_how(String veh_gift_how) {
		this.veh_gift_how = veh_gift_how;
	}

	/**
	 * @return the veh_gift_ind
	 */
	public String getVeh_gift_ind() {
		return veh_gift_ind;
	}

	/**
	 * @param veh_gift_ind the veh_gift_ind to set
	 */
	public void setVeh_gift_ind(String veh_gift_ind) {
		this.veh_gift_ind = veh_gift_ind;
	}

	/**
	 * @return the veh_used_by
	 */
	public String getVeh_used_by() {
		return veh_used_by;
	}

	/**
	 * @param veh_used_by the veh_used_by to set
	 */
	public void setVeh_used_by(String veh_used_by) {
		this.veh_used_by = veh_used_by;
	}

	/**
	 * @return the how_it_is_used
	 */
	public String getHow_it_is_used() {
		return how_it_is_used;
	}

	/**
	 * @param how_it_is_used the how_it_is_used to set
	 */
	public void setHow_it_is_used(String how_it_is_used) {
		this.how_it_is_used = how_it_is_used;
	}

	/**
	 * @return the leased_ind
	 */
	public String getLeased_ind() {
		return leased_ind;
	}

	/**
	 * @param leased_ind the leased_ind to set
	 */
	public void setLeased_ind(String leased_ind) {
		this.leased_ind = leased_ind;
	}

	/**
	 * @return the loopingQuestion
	 */
	public String getLoopingQuestion() {
		return loopingQuestion;
	}

	/**
	 * @param loopingQuestion
	 *            the loopingQuestion to set
	 */
	public void setLoopingQuestion(final String loopingQuestion) {
		this.loopingQuestion = loopingQuestion;
	}
	public String getVehAssetCalsawsObject() {
		return vehAssetCalsawsObject;
	}
	public void setVehAssetCalsawsObject(String vehAssetCalsawsObject) {
		this.vehAssetCalsawsObject = vehAssetCalsawsObject;
	}

	public String getVehicleandpropertytypeDesc() {
		return vehicleandpropertytypeDesc;
	}

	public void setVehicleandpropertytypeDesc(String vehicleandpropertytypeDesc) {
		this.vehicleandpropertytypeDesc = vehicleandpropertytypeDesc;
	}
}