package gov.state.nextgen.financialinformation.business.rules;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import gov.state.nextgen.access.exceptions.FwException;
import gov.state.nextgen.financialinformation.business.entities.APP_HSHL_RLT_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_INST_Cargo;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_INST_Collection;
import gov.state.nextgen.financialinformation.business.entities.APP_IN_SPS_IMPOV_Collection;
import gov.state.nextgen.financialinformation.data.db2.AppHshlRltRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInInstituionRepository;
import gov.state.nextgen.financialinformation.data.db2.AppInSpsRepository;

@Service("InstitutionBO")
public class InstitutionBO {
	
	private static Logger logger = LoggerFactory.getLogger(InstitutionBO.class);
	
	private AppHshlRltRepository appHshlRltRepository;
	
	private AppInInstituionRepository appInInstituionRepository;
	
	private AppInSpsRepository appInSpsRepository;

	public Map loadInstitution(String appNumber, String indvSeqNum) {

		logger.info("InstitutionBO.loadInstitution() - START");
		final Map pageCollection = new HashMap();
		APP_IN_INST_Collection instColl = null;
		APP_IN_SPS_IMPOV_Collection spouseColl = null;
		try {
			// get individual information
			instColl = new APP_IN_INST_Collection();
			APP_IN_INST_Cargo indCargo = appInInstituionRepository.getByAppNum_IndSeq_(appNumber, indvSeqNum);
			
				instColl.add(indCargo);
				pageCollection.put("APP_IN_INST_Collection", instColl);
			
			

			// for spouse contact info load
			spouseColl = appInSpsRepository.getByAppNum_IndSeq_(appNumber, indvSeqNum);
			pageCollection.put("APP_IN_SPS_IMPOV_Collection", spouseColl);

		} catch (final Exception e) {
			
			throw e;
		}
		return pageCollection;
	}

	public String isWifeOrHusband(String appNumber, String indvSeqNum) {

		logger.info("InstitutionBO.isWifeOrHusband() - START");
		try {

			String spouseIndvSeqNum = "";
			List<String> husWife = new ArrayList<>();
			husWife.add("HUS");
			husWife.add("WIF");
			APP_HSHL_RLT_Cargo cargo = appHshlRltRepository.getByAppNum_IndSeq_(appNumber, indvSeqNum, spouseIndvSeqNum, husWife);
			spouseIndvSeqNum = cargo.getRef_indv_seq_num().trim();
			if (spouseIndvSeqNum.equals(indvSeqNum)) {
				spouseIndvSeqNum = cargo.getSrc_indv_seq_num().trim();
			}

			return spouseIndvSeqNum;
		} catch (final Exception e) {
			throw e;
		}
	}

}
