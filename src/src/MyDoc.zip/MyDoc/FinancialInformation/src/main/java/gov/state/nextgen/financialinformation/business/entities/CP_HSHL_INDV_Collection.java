/*
 * 
 */
package gov.state.nextgen.financialinformation.business.entities;

import gov.state.nextgen.access.business.entities.AbstractCollection;

public class CP_HSHL_INDV_Collection extends AbstractCollection {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;
	private static final String PACKAGE = "gov.state.nextgen.access.business.entities.impl.CP_HSHL_INDV";

	/**
	 * returns the PACKAGE name.
	 */
	@Override
	public String getPACKAGE() {
		return PACKAGE;
	}

	/**
	 * Adds the given cargo to the collection.
	 */
	public void addCargo(final CP_HSHL_INDV_Cargo aNewCargo) {
		add(aNewCargo);
	}

	/**
	 * Sets cargo array into collection.
	 */
	public void setResults(final CP_HSHL_INDV_Cargo[] cbArray) {
		clear();
		for (int i = 0; i < cbArray.length; i++) {
			add(cbArray[i]);
		}
	}

	/**
	 * Sets cargo into collection at the given index.
	 */
	public void setCargo(final int idx, final CP_HSHL_INDV_Cargo aCargo) {
		set(idx, aCargo);
	}

	/**
	 * returns all the values in the Collection as Cargo Array.
	 */
	public CP_HSHL_INDV_Cargo[] getResults() {
		final CP_HSHL_INDV_Cargo[] cbArray = new CP_HSHL_INDV_Cargo[size()];
		toArray(cbArray);
		return cbArray;
	}

	// NextGen NG-6481 Phase 3 updates to ACA Streamline changes � start (H)

	public CP_HSHL_INDV_Cargo getResult(final int idx) {
		return (CP_HSHL_INDV_Cargo) get(idx);
	}

	// NextGen NG-6481 Phase 3 updates to ACA Streamline changes � end (H)

	/**
	 * returns a cargo from the Collection for the given index.
	 */
	public CP_HSHL_INDV_Cargo getCargo(final int idx) {
		return (CP_HSHL_INDV_Cargo) get(idx);
	}

	/**
	 * This one for clone Results.
	 */
	public CP_HSHL_INDV_Cargo[] cloneResults() {
		final CP_HSHL_INDV_Cargo[] rescargo = new CP_HSHL_INDV_Cargo[size()];
		for (int i = 0; i < size(); i++) {
			final CP_HSHL_INDV_Cargo cargo = getCargo(i);
			rescargo[i].setFirst_name(cargo.getFirst_name());
			rescargo[i].setGndr_cd(cargo.getGndr_cd());
			rescargo[i].setHshl_id(cargo.getHshl_id());
			rescargo[i].setIndv_age(cargo.getIndv_age());
			rescargo[i].setIndv_id(cargo.getIndv_id());
			rescargo[i].setCargoName(cargo.getCargoName());
			rescargo[i].setUser(cargo.getUser());
			rescargo[i].setRowAction(cargo.getRowAction());
		}
		return rescargo;
	}

	/**
	 * Set the cargo array object to the collection.
	 */
	@Override
	public void setGenericResults(final Object obj) {
		if (obj instanceof CP_HSHL_INDV_Cargo[]) {
			final CP_HSHL_INDV_Cargo[] cbArray = (CP_HSHL_INDV_Cargo[]) obj;
			setResults(cbArray);
		}
	}
}