/**
 *
 */
package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Id;

import gov.state.nextgen.access.business.entities.AbstractCargo;

public class APP_IN_BILLS_RESP_FOR_Cargo extends AbstractCargo implements Serializable {

	private static final long serialVersionUID = 7078121630520903757L;
	@Id
	private String app_num;
	@Id
	private String bill_type;
	@Id
	private int indv_seq_num;
	@Id
	private Integer seq_num;
	@Id
	private String src_app_ind;
	private Integer rec_cplt_ind;
	private String responsible_for_pay_ind;
	private Double responsible_amt;
	private String responsible_fst_nam;
	private String responsible_lst_nam;
	private String otsd_ind;
	private Integer bill_own_seq_num;
	private Integer bill_indv_seq_num;

	/**
	 *
	 */

	/**
	 * @return the app_num
	 */
	public String getApp_num() {
		return app_num;
	}

	/**
	 * @param app_num the app_num to set
	 */
	public void setApp_num(final String app_num) {
		this.app_num = app_num;
	}

	/**
	 * @return the bill_type
	 */
	public String getBill_type() {
		return bill_type;
	}

	/**
	 * @param bill_type the bill_type to set
	 */
	public void setBill_type(final String bill_type) {
		this.bill_type = bill_type;
	}

	/**
	 * @return the indv_seq_num
	 */
	public int getIndv_seq_num() {
		return indv_seq_num;
	}

	/**
	 * @param indv_seq_num the indv_seq_num to set
	 */
	public void setIndv_seq_num(final int indv_seq_num) {
		this.indv_seq_num = indv_seq_num;
	}

	/**
	 * @return the rec_cplt_ind
	 */
	public Integer getRec_cplt_ind() {
		return rec_cplt_ind;
	}

	/**
	 * @param rec_cplt_ind the rec_cplt_ind to set
	 */
	public void setRec_cplt_ind(final Integer rec_cplt_ind) {
		this.rec_cplt_ind = rec_cplt_ind;
	}

	/**
	 * @return the responsible_for_pay_ind
	 */
	public String getResponsible_for_pay_ind() {
		return responsible_for_pay_ind;
	}

	/**
	 * @param responsible_for_pay_ind the responsible_for_pay_ind to set
	 */
	public void setResponsible_for_pay_ind(final String responsible_for_pay_ind) {
		this.responsible_for_pay_ind = responsible_for_pay_ind;
	}

	/**
	 * @return the seq_num
	 */
	public Integer getSeq_num() {
		return seq_num;
	}

	/**
	 * @param seq_num the seq_num to set
	 */
	public void setSeq_num(final Integer seq_num) {
		this.seq_num = seq_num;
	}

	/**
	 * @return the src_app_ind
	 */
	public String getSrc_app_ind() {
		return src_app_ind;
	}

	/**
	 * @param src_app_ind the src_app_ind to set
	 */
	public void setSrc_app_ind(final String src_app_ind) {
		this.src_app_ind = src_app_ind;
	}

	/**
	 * @return the responsible_amt
	 */
	public Double getResponsible_amt() {
		return responsible_amt;
	}

	/**
	 * @param responsible_amt the responsible_amt to set
	 */
	public void setResponsible_amt(final Double responsible_amt) {
		this.responsible_amt = responsible_amt;
	}

	/**
	 * @return the responsible_fst_nam
	 */
	public String getResponsible_fst_nam() {
		return responsible_fst_nam;
	}

	/**
	 * @param responsible_fst_nam the responsible_fst_nam to set
	 */
	public void setResponsible_fst_nam(final String responsible_fst_nam) {
		this.responsible_fst_nam = responsible_fst_nam;
	}

	/**
	 * @return the responsible_lst_nam
	 */
	public String getResponsible_lst_nam() {
		return responsible_lst_nam;
	}

	/**
	 * @param responsible_lst_nam the responsible_lst_nam to set
	 */
	public void setResponsible_lst_nam(final String responsible_lst_nam) {
		this.responsible_lst_nam = responsible_lst_nam;
	}

	/**
	 * @return the otsd_ind
	 */
	public String getOtsd_ind() {
		return otsd_ind;
	}

	/**
	 * @param otsd_ind the otsd_ind to set
	 */
	public void setOtsd_ind(final String otsd_ind) {
		this.otsd_ind = otsd_ind;
	}

	/**
	 * @return the bill_own_seq_num
	 */
	public Integer getBill_own_seq_num() {
		return bill_own_seq_num;
	}

	/**
	 * @param bill_own_seq_num the bill_own_seq_num to set
	 */
	public void setBill_own_seq_num(final Integer bill_own_seq_num) {
		this.bill_own_seq_num = bill_own_seq_num;
	}

	/**
	 * @return the bill_indv_seq_num
	 */
	public Integer getBill_indv_seq_num() {
		return bill_indv_seq_num;
	}

	/**
	 * @param bill_indv_seq_num the bill_indv_seq_num to set
	 */
	public void setBill_indv_seq_num(final Integer bill_indv_seq_num) {
		this.bill_indv_seq_num = bill_indv_seq_num;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_num == null) ? 0 : app_num.hashCode());
		result = prime * result + ((bill_indv_seq_num == null) ? 0 : bill_indv_seq_num.hashCode());
		result = prime * result + ((bill_own_seq_num == null) ? 0 : bill_own_seq_num.hashCode());
		result = prime * result + ((bill_type == null) ? 0 : bill_type.hashCode());
		result = prime * result + indv_seq_num;
		result = prime * result + ((otsd_ind == null) ? 0 : otsd_ind.hashCode());
		result = prime * result + ((rec_cplt_ind == null) ? 0 : rec_cplt_ind.hashCode());
		result = prime * result + ((responsible_amt == null) ? 0 : responsible_amt.hashCode());
		result = prime * result + ((responsible_for_pay_ind == null) ? 0 : responsible_for_pay_ind.hashCode());
		result = prime * result + ((responsible_fst_nam == null) ? 0 : responsible_fst_nam.hashCode());
		result = prime * result + ((responsible_lst_nam == null) ? 0 : responsible_lst_nam.hashCode());
		result = prime * result + (int) (seq_num ^ (seq_num >>> 32));
		result = prime * result + ((src_app_ind == null) ? 0 : src_app_ind.hashCode());
		return result;
	}

	
}
