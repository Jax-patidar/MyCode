package gov.state.nextgen.financialinformation.business.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class APP_IN_UEI_Id implements Serializable {

	private static final long serialVersionUID = 1L;

	
	private Integer app_number;
	private Integer seq_num;
	private Integer indv_seq_num;
	private String uei_typ;

	public APP_IN_UEI_Id() {
	}

	public APP_IN_UEI_Id(Integer app_num, Integer seq_num, Integer indv_seq_num, String src_app_ind, String uei_typ) {
		super();
		this.app_number = app_num;
		this.seq_num = seq_num;
		this.indv_seq_num = indv_seq_num;
		this.uei_typ = uei_typ;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((app_number == null) ? 0 : app_number.hashCode());
		result = prime * result + ((indv_seq_num == null) ? 0 : indv_seq_num.hashCode());
		result = prime * result + ((seq_num == null) ? 0 : seq_num.hashCode());
		result = prime * result + ((uei_typ == null) ? 0 : uei_typ.hashCode());
		return result;
	}
@SuppressWarnings("squid:S3776")
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		APP_IN_UEI_Id other = (APP_IN_UEI_Id) obj;
		if (app_number == null) {
			if (other.app_number != null)
				return false;
		} else if (!app_number.equals(other.app_number))
			return false;
		if (indv_seq_num == null) {
			if (other.indv_seq_num != null)
				return false;
		} else if (!indv_seq_num.equals(other.indv_seq_num))
			return false;
		if (seq_num == null) {
			if (other.seq_num != null)
				return false;
		} else if (!seq_num.equals(other.seq_num))
			return false;
		if (uei_typ == null) {
			if (other.uei_typ != null)
				return false;
		} else if (!uei_typ.equals(other.uei_typ))
			return false;
		return true;
	}

	
}
